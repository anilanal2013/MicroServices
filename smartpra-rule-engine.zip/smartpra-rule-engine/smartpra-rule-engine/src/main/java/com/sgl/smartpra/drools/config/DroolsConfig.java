package com.sgl.smartpra.drools.config;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.builder.KieRepository;
import org.kie.api.builder.ReleaseId;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author lsivak1
 *
 */

@Configuration
@Slf4j
public class DroolsConfig {

	/*
	 * private KieServices kieServices = KieServices.Factory.get();
	 * 
	 * private KieFileSystem getKieFileSystem() {
	 * log.info("Rules file is loading..."); KieFileSystem kieFileSystem = null; try
	 * { kieFileSystem = kieServices.newKieFileSystem();
	 * kieFileSystem.write(ResourceFactory.newClassPathResource("rules-v1.xls")); }
	 * catch (Exception e) { log.error("Exception while file is loading..");
	 * e.printStackTrace(); } return kieFileSystem; }
	 */
	/*
	 * @Bean public KieContainer getKieContainer() {
	 * log.info("Container created..."); KieContainer kContainer = null; try {
	 * getKieRepository(); KieBuilder kb =
	 * kieServices.newKieBuilder(getKieFileSystem()); kb.buildAll(); KieModule
	 * kieModule = kb.getKieModule(); kContainer =
	 * kieServices.newKieContainer(kieModule.getReleaseId()); } catch (Exception e)
	 * { log.error("Exception while Container creating.."); e.printStackTrace(); }
	 * return kContainer; }
	 * 
	 * private void getKieRepository() { final KieRepository kieRepository =
	 * kieServices.getRepository(); kieRepository.addKieModule(new KieModule() {
	 * public ReleaseId getReleaseId() { return kieRepository.getDefaultReleaseId();
	 * } }); }
	 * 
	 * @Bean public KieSession getKieSession() { log.info("session created..."); try
	 * { return getKieContainer().newKieSession(); } catch (Exception e) {
	 * log.error("Exception while session creating.."); e.printStackTrace(); return
	 * null; } }
	 */
}
