package com.sgl.smartpra.drools.exception;

import com.sgl.smartpra.accounting.model.ErrorInfo;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
public class InfoNotFound extends RuntimeException {
    private ErrorInfo errorInfo;
    public InfoNotFound(String message) {
        super(message);
    }

    public InfoNotFound(Throwable t){
        super(t);
    }

    public InfoNotFound(String message, ErrorInfo errorInfo){
        super(message);
        this.errorInfo = errorInfo;
    }

    public ErrorInfo getErrorInfo() {
        return errorInfo;
    }
}
