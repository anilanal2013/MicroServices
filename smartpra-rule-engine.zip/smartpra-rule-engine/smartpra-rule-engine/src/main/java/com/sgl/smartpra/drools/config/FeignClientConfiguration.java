package com.sgl.smartpra.drools.config;

import java.util.Date;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.currency.model.CurrencyRate;
import com.sgl.smartpra.master.model.ListOfValues;
import com.sgl.smartpra.master.model.SystemParameter;

@Configuration
public class FeignClientConfiguration {

	@FeignClient(value = "smartpra-currency-master-app")
	public interface SmartpraCurrencyMasterAppClient {

		@GetMapping("/currency/{currencyRateType}/{currencyFromCode}/{currencyToCode}/{effectiveDate}")
		public CurrencyRate getEffectiveCurrencyRate(
				@PathVariable(value = "currencyRateType", required = true) String currencyRateType,
				@PathVariable(value = "currencyFromCode", required = true) String currencyFromCode,
				@PathVariable(value = "currencyToCode", required = true) String currencyToCode,
				@PathVariable(value = "effectiveDate", required = true) String effectiveDate); // "yyyy-MM-dd"
	}

	@FeignClient(value = "smartpra-master-app")
	public interface SmartpraMasterAppClient {

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(
				@PathVariable(value = "parameterName") String parameterName);

		@GetMapping("/system-parameters-with-date/clientId/{clientId}/parameterName/{parameterName}")
		public SystemParameter getSystemParameterByparameterNameAndClientId(
				@PathVariable(value = "parameterName") String parameterName,
				@PathVariable(value = "clientId") String clientId);

		@GetMapping("/listofvalues/{clientId}/{tableName}/{columnName}/{fieldValue}")
		public ListOfValues getListOfValues(@PathVariable(value = "clientId", required = true) String clientId,
											@PathVariable(value = "tableName", required = true) String tableName,
											@PathVariable(value = "columnName", required = true) String columnName,
											@PathVariable(value = "fieldValue", required = true) String fieldValue);

		@GetMapping("/system-parameters-with-date/clientId/parameterNames")
		public List<SystemParameter> getSystemParameterByparameterNameAndClientId(
				@RequestParam(value = "clientId", required = true) String clientId,
				@RequestParam(value = "parameterNames", required = true) List<String> parameterNames);


		@GetMapping("/billing-period/end-date/{billingMonth}/{billingPeriod}")
		public Date getOutwardBillingPeriodsEndDate(@PathVariable(value = "billingMonth") String billingMonth,
													@PathVariable(value = "billingPeriod") Integer billingPeriod);
	}

}
