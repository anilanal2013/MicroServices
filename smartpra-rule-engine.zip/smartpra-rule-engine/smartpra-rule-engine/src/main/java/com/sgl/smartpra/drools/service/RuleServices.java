package com.sgl.smartpra.drools.service;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.jni.Local;
import org.drools.core.impl.InternalKnowledgeBase;
import org.drools.core.impl.KnowledgeBaseFactory;
import org.hibernate.service.spi.ServiceException;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieSession;
import org.kie.internal.builder.KnowledgeBuilder;
import org.kie.internal.builder.KnowledgeBuilderError;
import org.kie.internal.builder.KnowledgeBuilderErrors;
import org.kie.internal.builder.KnowledgeBuilderFactory;
import org.kie.internal.io.ResourceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.accounting.model.AccountAttributeView;
import com.sgl.smartpra.accounting.model.AccountingAuditTrial;
import com.sgl.smartpra.accounting.model.AccountingEntryRequest;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.model.ErrorInfo;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.currency.model.CurrencyRate;
import com.sgl.smartpra.drools.config.FeignClientConfiguration;
import com.sgl.smartpra.drools.exception.InfoNotFound;
import com.sgl.smartpra.drools.utility.Constants;
import com.sgl.smartpra.drools.utility.DroolUtility;
import com.sgl.smartpra.interline.model.form3.InterlineForm3DetailsModel;
import com.sgl.smartpra.master.model.MasScenarioModel;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RuleServices {


	private static final String USD = "USD";
	@Value("${rulesPath:/opt/smartpra/account}")
	private String rulesPath;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	FeignClientConfiguration.SmartpraCurrencyMasterAppClient smartpraCurrencyMasterAppClient;

	@Autowired
	private FeignClientConfiguration.SmartpraMasterAppClient smartpraMasterAppClient;



	public MasScenarioModel fetchScenarioForMisc(AccountingTransaction accountingTransaction) {
		MasScenarioModel scenarioMaster = new MasScenarioModel();
		String st = new StringBuilder(rulesPath).append("misc_rules" ).append(File.separator).append("rules_misc_scenario.drl").toString();
		log.info("File drl : "+st);
		MiscBillingTrnInvoice miscBillingTrnInvoice = null;
		try {
			String ruleContent = new String(Files.readAllBytes(Paths.get(st)));

			KnowledgeBuilder kb = KnowledgeBuilderFactory.newKnowledgeBuilder();
			kb.add(ResourceFactory.newByteArrayResource(ruleContent.getBytes("utf-8")), ResourceType.DRL);

			KnowledgeBuilderErrors errors = kb.getErrors();
			for (KnowledgeBuilderError error : errors) {
				log.info("Error Messages :: "+error);
			}
			InternalKnowledgeBase kBase = KnowledgeBaseFactory.newKnowledgeBase();
			kBase.addPackages(kb.getKnowledgePackages());
			KieSession kieSession = kBase.newKieSession();
			kieSession.setGlobal("scenarioMaster", scenarioMaster);
			kieSession.insert(accountingTransaction);
			if (!StringUtils.equalsIgnoreCase("F3",
					OptionalUtil.getValue(accountingTransaction.getTransactionType()))) {
				miscBillingTrnInvoice = getVal(accountingTransaction);
				kieSession.insert(miscBillingTrnInvoice);
			}
			/*if (StringUtils.equalsAnyIgnoreCase(miscBillingTrnInvoice.getSupplierType(),"N")){
				kieSession.getAgenda().getAgendaGroup("scenarioInvoice-misc").setFocus();
			} else {
				kieSession.getAgenda().getAgendaGroup("scenario-misc").setFocus();
			}*/
			kieSession.getAgenda().getAgendaGroup("misc-scenario").setFocus();
			kieSession.fireAllRules();
		} catch (IOException e) {
			log.error("IN RuleServicesImpl :: applyAccountRules() :: Exception msg :: "+e);
		}
		log.info("OUT RuleServicesImpl :: applyAccountRules() :: Finished");
		return scenarioMaster;
	}
	private MiscBillingTrnInvoice getVal(AccountingTransaction accountingTransaction) throws IOException {
		MiscBillingTrnInvoice miscBillingTrnInvoice = null;
		if (StringUtils.equalsAnyIgnoreCase("M", accountingTransaction.getModule())
				&& OptionalUtil.isPresent(accountingTransaction.getRequest())) {
			miscBillingTrnInvoice = objectMapper.readValue(OptionalUtil.getValue(accountingTransaction.getRequest()),
					MiscBillingTrnInvoice.class);
		}
		return miscBillingTrnInvoice;
	}
	
	private InterlineForm3DetailsModel getF3ModelVal(AccountingTransaction accountingTransaction) throws IOException {
		InterlineForm3DetailsModel interlineForm3DetailsModel = null;
		if (StringUtils.equalsAnyIgnoreCase("F3", OptionalUtil.getValue(accountingTransaction.getTransactionType()))
				&& OptionalUtil.isPresent(accountingTransaction.getRequest())) {
			interlineForm3DetailsModel = objectMapper.readValue(OptionalUtil.getValue(accountingTransaction.getRequest()),
					InterlineForm3DetailsModel.class);
		}
		return interlineForm3DetailsModel;
	}

	public List<AccountingAuditTrial> calculateAccounts(AccountingEntryRequest accountingEntryRequest)
			throws InfoNotFound {
		List<AccountingAuditTrial> accountingEntrys = new ArrayList<>();
		String st = new StringBuilder(rulesPath).append("misc_rules").append(File.separator)
				.append("rule-misc-account.drl").toString();
		try {

			String ruleContent = new String(Files.readAllBytes(Paths.get(st)));

			KnowledgeBuilder kb = KnowledgeBuilderFactory.newKnowledgeBuilder();
			kb.add(ResourceFactory.newByteArrayResource(ruleContent.getBytes("utf-8")), ResourceType.DRL);

			KnowledgeBuilderErrors errors = kb.getErrors();
			for (KnowledgeBuilderError error : errors) {
				log.info("Exception : "+error);
			}
			InternalKnowledgeBase kBase = KnowledgeBaseFactory.newKnowledgeBase();
			kBase.addPackages(kb.getKnowledgePackages());
			KieSession kieSession = kBase.newKieSession();
			kieSession.getAgenda().getAgendaGroup("account-misc").setFocus();
			kieSession.setGlobal("listOfAccount", accountingEntrys);
			kieSession.setGlobal("droolUtility", new DroolUtility());
			MiscBillingTrnInvoice miscBillingTrnInvoiceEntity = getVal(accountingEntryRequest.getAccountingTransaction());
			String baseCurrency = fetchBaseCurrency(miscBillingTrnInvoiceEntity.getClientId());
			String defaultBuyerOrganizationId =  fetchDefaultBuyerOrganizationId(miscBillingTrnInvoiceEntity.getClientId());
			LocalDate excDate = LocalDate.now();
			BigDecimal exchangeRate = calaulateExc(USD,miscBillingTrnInvoiceEntity.getInvoiceDate(),baseCurrency,excDate);
			kieSession.setGlobal("exchangeRate", exchangeRate);
			kieSession.setGlobal("exchangeDate",excDate);
			kieSession.setGlobal("baseCurrency", baseCurrency);
			kieSession.setGlobal("defaultBuyerOrganizationId", defaultBuyerOrganizationId);
			kieSession.setGlobal("miscBillingTrnInvoiceEntity", miscBillingTrnInvoiceEntity);
			kieSession.setGlobal("invoiceNo",OptionalUtil.getValue(accountingEntryRequest.getAccountingTransaction().getInvoiceNo()));
			List<AccountAttributeView> accountAttributeViewList = accountingEntryRequest.getAccountAttributeView();
			for(AccountAttributeView accountAttributeView: accountAttributeViewList) {
				kieSession.insert(accountAttributeView);
			}
			kieSession.fireAllRules();
			kieSession.getAgenda().getAgendaGroup("account-misc-LGB").setFocus();
			BigDecimal totalTransDebitAmount = new BigDecimal(accountingEntrys.parallelStream().
					collect(Collectors.summingDouble(a -> a.getDrAmtInTransactionCurrency()!= null ? a.getDrAmtInTransactionCurrency().doubleValue() : 0.0d)));
			BigDecimal totalTransCreditAmount = new BigDecimal(accountingEntrys.parallelStream().
					collect(Collectors.summingDouble(a -> a.getCrAmtInTransactionCurrency()!= null ? a.getCrAmtInTransactionCurrency().doubleValue() : 0.0d)));
			BigDecimal totalBaseDebitAmount = new BigDecimal(accountingEntrys.parallelStream().
					collect(Collectors.summingDouble(a -> a.getDebitAmountInBaseCurrency()!= null ? a.getDebitAmountInBaseCurrency().doubleValue() : 0.0d)));
			BigDecimal totalBaseCreditAmount = new BigDecimal(accountingEntrys.parallelStream().
					collect(Collectors.summingDouble(a -> a.getCreditAmountInBaseCurrency()!= null ? a.getCreditAmountInBaseCurrency().doubleValue() : 0.0d)));

			kieSession.setGlobal("totalTransDebitAmount", totalTransDebitAmount);
			kieSession.setGlobal("totalTransCreditAmount", totalTransCreditAmount);
			kieSession.setGlobal("totalBaseDebitAmount", totalBaseDebitAmount);
			kieSession.setGlobal("totalBaseCreditAmount", totalBaseCreditAmount);
			kieSession.fireAllRules();
			kieSession.getAgenda().getAgendaGroup("account-misc-DEA").setFocus();
			totalBaseDebitAmount = new BigDecimal(accountingEntrys.parallelStream()
					.collect(Collectors.summingDouble(a -> a.getDebitAmountInBaseCurrency() != null
							? a.getDebitAmountInBaseCurrency().doubleValue()
							: 0.0d)));
			totalBaseCreditAmount = new BigDecimal(accountingEntrys.parallelStream()
					.collect(Collectors.summingDouble(a -> a.getCreditAmountInBaseCurrency() != null
							? a.getCreditAmountInBaseCurrency().doubleValue()
							: 0.0d)));
			kieSession.setGlobal("totalBaseDebitAmount", totalBaseDebitAmount);
			kieSession.setGlobal("totalBaseCreditAmount", totalBaseCreditAmount);
			kieSession.fireAllRules();
		} catch (IOException e) {
			log.error(e.getMessage());
			throw new InfoNotFound(e.getMessage());
		}
		return accountingEntrys;
	}


	public List<AccountingAuditTrial> calculateF3Accounts(AccountingEntryRequest accountingEntryRequest)
			throws InfoNotFound {
		List<AccountingAuditTrial> accountingEntrys = new ArrayList<>();
		String st = new StringBuilder(rulesPath).append("misc_rules").append(File.separator)
				.append("rule-f3-account.drl").toString();
		try {

			String ruleContent = new String(Files.readAllBytes(Paths.get(st)));

			KnowledgeBuilder kb = KnowledgeBuilderFactory.newKnowledgeBuilder();
			kb.add(ResourceFactory.newByteArrayResource(ruleContent.getBytes("utf-8")), ResourceType.DRL);

			KnowledgeBuilderErrors errors = kb.getErrors();
			for (KnowledgeBuilderError error : errors) {
				log.info("Exception : " + error);
			}
			InternalKnowledgeBase kBase = KnowledgeBaseFactory.newKnowledgeBase();
			kBase.addPackages(kb.getKnowledgePackages());
			KieSession kieSession = kBase.newKieSession();
			kieSession.getAgenda().getAgendaGroup("account-f3").setFocus();

			kieSession.setGlobal("listOfAccount", accountingEntrys);
			kieSession.setGlobal("droolUtility", new DroolUtility());
			InterlineForm3DetailsModel interlineForm3DetailsModel = getF3ModelVal(
					accountingEntryRequest.getAccountingTransaction());
			String baseCurrency = fetchBaseCurrency(interlineForm3DetailsModel.getClientId());

			LocalDate excDate = LocalDate.now();
			Date invoiceDate = fetchBillEndDate(interlineForm3DetailsModel.getBillingMonth(),interlineForm3DetailsModel.getBillingPeriod());
			BigDecimal exchangeRate = calaulateExc(interlineForm3DetailsModel.getInvoiceCurrency(),invoiceDate, baseCurrency, excDate);
			kieSession.setGlobal("exchangeRate", exchangeRate);
			kieSession.setGlobal("exchangeDate", excDate);
			kieSession.setGlobal("baseCurrency", baseCurrency);
			kieSession.setGlobal("interlineForm3DetailsModel", interlineForm3DetailsModel);
			List<AccountAttributeView> accountAttributeViewList = accountingEntryRequest.getAccountAttributeView();
			for (AccountAttributeView accountAttributeView : accountAttributeViewList) {
				kieSession.insert(accountAttributeView);
			}
			kieSession.fireAllRules();
			kieSession.getAgenda().getAgendaGroup("account-f3-LGB").setFocus();
			BigDecimal totalTransDebitAmount = new BigDecimal(accountingEntrys.parallelStream()
					.collect(Collectors.summingDouble(a -> a.getDrAmtInTransactionCurrency() != null
							? a.getDrAmtInTransactionCurrency().doubleValue()
							: 0.0d)));
			BigDecimal totalTransCreditAmount = new BigDecimal(accountingEntrys.parallelStream()
					.collect(Collectors.summingDouble(a -> a.getCrAmtInTransactionCurrency() != null
							? a.getCrAmtInTransactionCurrency().doubleValue()
							: 0.0d)));
			BigDecimal totalBaseDebitAmount = new BigDecimal(accountingEntrys.parallelStream()
					.collect(Collectors.summingDouble(a -> a.getDebitAmountInBaseCurrency() != null
							? a.getDebitAmountInBaseCurrency().doubleValue()
							: 0.0d)));
			BigDecimal totalBaseCreditAmount = new BigDecimal(accountingEntrys.parallelStream()
					.collect(Collectors.summingDouble(a -> a.getCreditAmountInBaseCurrency() != null
							? a.getCreditAmountInBaseCurrency().doubleValue()
							: 0.0d)));

			kieSession.setGlobal("totalTransDebitAmount", totalTransDebitAmount);
			kieSession.setGlobal("totalTransCreditAmount", totalTransCreditAmount);
			kieSession.setGlobal("totalBaseDebitAmount", totalBaseDebitAmount);
			kieSession.setGlobal("totalBaseCreditAmount", totalBaseCreditAmount);
			kieSession.fireAllRules();
			kieSession.getAgenda().getAgendaGroup("account-f3-DEA").setFocus();
			totalBaseDebitAmount = new BigDecimal(accountingEntrys.parallelStream()
					.collect(Collectors.summingDouble(a -> a.getDebitAmountInBaseCurrency() != null
							? a.getDebitAmountInBaseCurrency().doubleValue()
							: 0.0d)));
			totalBaseCreditAmount = new BigDecimal(accountingEntrys.parallelStream()
					.collect(Collectors.summingDouble(a -> a.getCreditAmountInBaseCurrency() != null
							? a.getCreditAmountInBaseCurrency().doubleValue()
							: 0.0d)));
			kieSession.setGlobal("totalBaseDebitAmount", totalBaseDebitAmount);
			kieSession.setGlobal("totalBaseCreditAmount", totalBaseCreditAmount);
			kieSession.fireAllRules();
		} catch (IOException e) {
			log.error(e.getMessage());
			throw new InfoNotFound(e.getMessage());
		}
		return accountingEntrys;
	}

	private BigDecimal calaulateExc(String currencyCode, Date localDate , String baseCurrency, LocalDate excDate)
			throws InfoNotFound {

		CurrencyRate currencyRate = null;
		String invoiceDate = new SimpleDateFormat("yyyy-MM-dd").format(localDate);

		try {
			currencyRate = smartpraCurrencyMasterAppClient.getEffectiveCurrencyRate(Constants.BKR,
					currencyCode,baseCurrency , invoiceDate);
		} catch (ServiceException se) {
			log.debug("Record not found for BKR " + currencyCode + " - BaseCurrency: "
					+ baseCurrency + " and invoiceDate: " + invoiceDate);
		} catch (Exception e) {
			log.debug("Exception thrown while getting data for BKR currency.");
			e.printStackTrace();
		}
		BigDecimal exchangeRate = null;
		if(currencyRate == null) {
			throw new InfoNotFound("Exchange rate is null",getErrorInfo("MISC9002","Exchange rate is null"));
		}

		if(currencyRate.getExchangeRate().isPresent()) {
			exchangeRate = new BigDecimal(currencyRate.getExchangeRate().get()).setScale(5, RoundingMode.HALF_UP);
			excDate = OptionalUtil.getLocalDateValue(currencyRate.getEffectiveFromDate());
		}

		return exchangeRate;
	}

	private ErrorInfo getErrorInfo(String errorCode, String errorMess) {
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorCode(errorCode);
		errorInfo.setErrorMessage(errorMess);
		return errorInfo;
	}

	public String fetchBaseCurrency(String clientId) {
		String baseCurrency = null;
		SystemParameter systemParameter =  smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(Constants.PARAM_DEFAULT_CURRENCY_CODE, clientId);
		if (systemParameter != null) {
			baseCurrency = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
		}

		return baseCurrency;

	}
	
	public String fetchDefaultBuyerOrganizationId(String clientId) {
		String defaultBuyerOrganizationId = null;
		SystemParameter systemParameter = smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(Constants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE, clientId);
		if (systemParameter != null) {
			defaultBuyerOrganizationId = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
		}
		return defaultBuyerOrganizationId;
	}

	private Date fetchBillEndDate(String billingMonth, Integer billingPeriod){
		Date date = null;
		date = smartpraMasterAppClient.getOutwardBillingPeriodsEndDate(billingMonth,billingPeriod);
		if (date == null){
			date = new Date();
		}
		return date;
	}
}
