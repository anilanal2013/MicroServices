package com.sgl.smartpra.drools.controller;

import java.util.List;

import com.sgl.smartpra.common.util.OptionalUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.accounting.model.AccountingAuditTrial;
import com.sgl.smartpra.accounting.model.AccountingEntryRequest;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.drools.service.RuleServices;
import com.sgl.smartpra.master.model.MasScenarioModel;

@RestController
public class RuleController {

    @Autowired
    RuleServices ruleServices;

    @PostMapping("/fetchScenario")
    public MasScenarioModel fetchScenarioMaster(
                                              @RequestBody AccountingTransaction accountingTransaction){
        return ruleServices.fetchScenarioForMisc(accountingTransaction);
    }

    @PostMapping("/calculateAccounts")
    public List<AccountingAuditTrial> calculateAccounts(@RequestBody AccountingEntryRequest accountingEntryRequest) {
       AccountingTransaction accountingTransaction = accountingEntryRequest.getAccountingTransaction();
       if (StringUtils.equalsAnyIgnoreCase("M", accountingTransaction.getModule()) &&
               StringUtils.equalsAnyIgnoreCase("F3", OptionalUtil.getValue(accountingTransaction.getTransactionType())) )   {
           return ruleServices.calculateF3Accounts(accountingEntryRequest);
       }
        return ruleServices.calculateAccounts(accountingEntryRequest);
    }
}
