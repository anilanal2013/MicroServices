package com.sgl.smartpra.drools.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "scenario_master")
public class ScenarioMaster {

	@Id
	@GeneratedValue
	private long id;
	private String clientID;
	private int scenarioNumber;
	private String moduleID;
	private String transactionType;
	private String selfOALIndicator;
	private String salesExistIndicator;
	private String documentType;
	private String preImplementationIndicator;
	private String miscDocumentUtilType;
	private String miscDocumentIssuedFor;
	private String invoiceType;
	private String sourceCode;
	private String deliveringCarrierIndicator;
	private String receivingCarrierIndicator;
	private String fopType;
	private String rejectionMemoType;
	private String ancillaryService;
	private String agentFlag;
	private String comments;
	private String chargeCategoryCode;
	private String chargeCode;
	private String samplingBilling;
	private String primeReissueIndicator;

	public ScenarioMaster() {
	}

	/*
	 * public ScenarioMaster(String clientID, int scenarioNumber, String moduleID,
	 * String transactionType, String selfOALIndicator, String salesExistIndicator,
	 * String documentType, String preImplementationIndicator, String
	 * miscDocumentUtilType, String miscDocumentIssuedFor, String invoiceType,
	 * String sourceCode, String deliveringCarrierIndicator, String
	 * receivingCarrierIndicator, String fopType, String rejectionMemoType, String
	 * ancillaryService, String agentFlag, String comments) { super(); this.clientID
	 * = clientID; this.scenarioNumber = scenarioNumber; this.moduleID = moduleID;
	 * this.transactionType = transactionType; this.selfOALIndicator =
	 * selfOALIndicator; this.salesExistIndicator = salesExistIndicator;
	 * this.documentType = documentType; this.preImplementationIndicator =
	 * preImplementationIndicator; this.miscDocumentUtilType = miscDocumentUtilType;
	 * this.miscDocumentIssuedFor = miscDocumentIssuedFor; this.invoiceType =
	 * invoiceType; this.sourceCode = sourceCode; this.deliveringCarrierIndicator =
	 * deliveringCarrierIndicator; this.receivingCarrierIndicator =
	 * receivingCarrierIndicator; this.fopType = fopType; this.rejectionMemoType =
	 * rejectionMemoType; this.ancillaryService = ancillaryService; this.agentFlag =
	 * agentFlag; this.comments = comments; }
	 */

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public int getScenarioNumber() {
		return scenarioNumber;
	}

	public void setScenarioNumber(int scenarioNumber) {
		this.scenarioNumber = scenarioNumber;
	}

	public String getModuleID() {
		return moduleID;
	}

	public void setModuleID(String moduleID) {
		this.moduleID = moduleID;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getSelfOALIndicator() {
		return selfOALIndicator;
	}

	public void setSelfOALIndicator(String selfOALIndicator) {
		this.selfOALIndicator = selfOALIndicator;
	}

	public String getSalesExistIndicator() {
		return salesExistIndicator;
	}

	public void setSalesExistIndicator(String salesExistIndicator) {
		this.salesExistIndicator = salesExistIndicator;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getPreImplementationIndicator() {
		return preImplementationIndicator;
	}

	public void setPreImplementationIndicator(String preImplementationIndicator) {
		this.preImplementationIndicator = preImplementationIndicator;
	}

	public String getMiscDocumentUtilType() {
		return miscDocumentUtilType;
	}

	public void setMiscDocumentUtilType(String miscDocumentUtilType) {
		this.miscDocumentUtilType = miscDocumentUtilType;
	}

	public String getMiscDocumentIssuedFor() {
		return miscDocumentIssuedFor;
	}

	public void setMiscDocumentIssuedFor(String miscDocumentIssuedFor) {
		this.miscDocumentIssuedFor = miscDocumentIssuedFor;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getSourceCode() {
		return sourceCode;
	}

	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}

	public String getDeliveringCarrierIndicator() {
		return deliveringCarrierIndicator;
	}

	public void setDeliveringCarrierIndicator(String deliveringCarrierIndicator) {
		this.deliveringCarrierIndicator = deliveringCarrierIndicator;
	}

	public String getReceivingCarrierIndicator() {
		return receivingCarrierIndicator;
	}

	public void setReceivingCarrierIndicator(String receivingCarrierIndicator) {
		this.receivingCarrierIndicator = receivingCarrierIndicator;
	}

	public String getFopType() {
		return fopType;
	}

	public void setFopType(String fopType) {
		this.fopType = fopType;
	}

	public String getRejectionMemoType() {
		return rejectionMemoType;
	}

	public void setRejectionMemoType(String rejectionMemoType) {
		this.rejectionMemoType = rejectionMemoType;
	}

	public String getAncillaryService() {
		return ancillaryService;
	}

	public void setAncillaryService(String ancillaryService) {
		this.ancillaryService = ancillaryService;
	}

	public String getAgentFlag() {
		return agentFlag;
	}

	public void setAgentFlag(String agentFlag) {
		this.agentFlag = agentFlag;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getChargeCategoryCode() {
		return chargeCategoryCode;
	}

	public void setChargeCategoryCode(String chargeCategoryCode) {
		this.chargeCategoryCode = chargeCategoryCode;
	}

	public String getChargeCode() {
		return chargeCode;
	}

	public void setChargeCode(String chargeCode) {
		this.chargeCode = chargeCode;
	}

	public String getSamplingBilling() {
		return samplingBilling;
	}

	public void setSamplingBilling(String samplingBilling) {
		this.samplingBilling = samplingBilling;
	}

	public String getPrimeReissueIndicator() {
		return primeReissueIndicator;
	}

	public void setPrimeReissueIndicator(String primeReissueIndicator) {
		this.primeReissueIndicator = primeReissueIndicator;
	}

	@Override
	public String toString() {
		return "ScenarioMaster [id=" + id + ", clientID=" + clientID + ", scenarioNumber=" + scenarioNumber
				+ ", moduleID=" + moduleID + ", transactionType=" + transactionType + ", selfOALIndicator="
				+ selfOALIndicator + ", salesExistIndicator=" + salesExistIndicator + ", documentType=" + documentType
				+ ", preImplementationIndicator=" + preImplementationIndicator + ", miscDocumentUtilType="
				+ miscDocumentUtilType + ", miscDocumentIssuedFor=" + miscDocumentIssuedFor + ", invoiceType="
				+ invoiceType + ", sourceCode=" + sourceCode + ", deliveringCarrierIndicator="
				+ deliveringCarrierIndicator + ", receivingCarrierIndicator=" + receivingCarrierIndicator + ", fopType="
				+ fopType + ", rejectionMemoType=" + rejectionMemoType + ", ancillaryService=" + ancillaryService
				+ ", agentFlag=" + agentFlag + ", comments=" + comments + "]";
	}

}
