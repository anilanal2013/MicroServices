package com.sgl.smartpra.drools.utility;

public class Constants {
	public static final String PARAM_DEFAULT_CURRENCY_CODE = "DEFAULT_CURRENCY_CODE";
	public static final String PARAM_DEFAULT_CARRIER_NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";
	public static final String BKR = "BKR";
	public static final String FDR = "FDR";
}
