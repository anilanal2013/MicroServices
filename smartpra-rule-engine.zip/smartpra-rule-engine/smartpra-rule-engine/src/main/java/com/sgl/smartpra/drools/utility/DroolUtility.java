package com.sgl.smartpra.drools.utility;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.drools.javaparser.utils.Log;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.accounting.model.AccountAttributeView;
import com.sgl.smartpra.accounting.model.AccountingAuditTrial;
import com.sgl.smartpra.interline.model.form3.InterlineForm3DetailsModel;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;

@Component
public class DroolUtility {

	private static final String USD = "USD";
	DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MMM-yy");

	public void getAccountingAuditTrial(AccountingAuditTrial accountingAuditTrial,
			AccountAttributeView accountAttributeView, MiscBillingTrnInvoice miscBillingTrnInvoice, String baseCurrency,
			BigDecimal exchangeRate, LocalDate exchangeDate, String invoiceNumber, String defaultBuyerOrganizationId) {
		accountingAuditTrial.setClientId(accountAttributeView.getClientId());
		accountingAuditTrial.setModule(accountAttributeView.getModule());
		String sellerOrganizationId = miscBillingTrnInvoice.getSellerOrganizationId();

		accountingAuditTrial.setTransIssAirline(sellerOrganizationId);
		accountingAuditTrial.setTransDocNumber(invoiceNumber);
		accountingAuditTrial.setMainIssAirline(sellerOrganizationId);
		accountingAuditTrial.setMainDocNumber(invoiceNumber);
		accountingAuditTrial.setRefIssuingCarrier(sellerOrganizationId);
		accountingAuditTrial.setRefDocumentNumber(invoiceNumber);
		accountingAuditTrial.setCouponNumber(0);
		accountingAuditTrial.setDocumentUniqueId(miscBillingTrnInvoice.getInvoiceUrn());
		accountingAuditTrial.setDocType(accountAttributeView.getDocType());
		Date invoiceDate = miscBillingTrnInvoice.getInvoiceDate();
		if (invoiceDate != null) {
			LocalDate dateOfIssue = invoiceDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			accountingAuditTrial.setDateOfIssue(dateOfIssue);
		}

		accountingAuditTrial.setBaseCurrency(baseCurrency);
		accountingAuditTrial.setAccountAlphaCode(accountAttributeView.getAccountAlphaCode());
		accountingAuditTrial.setAccountDesciption(accountAttributeView.getAccountDescription());
		accountingAuditTrial.setAccountCode(accountAttributeView.getAccountCode());
		accountingAuditTrial.setTransactionCurrency(USD);
		accountingAuditTrial.setScenarioNumber(accountAttributeView.getScenarioNumber());
		accountingAuditTrial.setAccountDefinitionIdentifier(accountAttributeView.getAccountDefinitionIdentifier());
		accountingAuditTrial.setConversionRate(exchangeRate.setScale(5, RoundingMode.HALF_UP));
		accountingAuditTrial.setAccountingDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		if (StringUtils.equalsIgnoreCase("I",miscBillingTrnInvoice.getInwardOutwardFlag())) {
			accountingAuditTrial.setSubModule("Inward");
			accountingAuditTrial.setBatchKey1(sellerOrganizationId);
			String buyerOrganizationId = miscBillingTrnInvoice.getBuyerOrganizationId();
			if (buyerOrganizationId != null && !buyerOrganizationId.isEmpty()) {
				accountingAuditTrial.setBatchKey2(miscBillingTrnInvoice.getBuyerOrganizationId());
			} else {
				accountingAuditTrial.setBatchKey2(defaultBuyerOrganizationId);
			}
		} else {
			accountingAuditTrial.setSubModule("Outward");
			accountingAuditTrial.setBatchKey2(sellerOrganizationId);
			String buyerOrganizationId = miscBillingTrnInvoice.getBuyerOrganizationId();
			if (buyerOrganizationId != null && !buyerOrganizationId.isEmpty()) {
				accountingAuditTrial.setBatchKey1(miscBillingTrnInvoice.getBuyerOrganizationId());
			} else {
				accountingAuditTrial.setBatchKey1(defaultBuyerOrganizationId);
			}
		}
		accountingAuditTrial.setBatchKey3(miscBillingTrnInvoice.getChargeCategoryCode());
		accountingAuditTrial.setBatchKey4(invoiceNumber);
		accountingAuditTrial.setBatchKey5(invoiceDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		accountingAuditTrial.setBatchKey6(invoiceDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		// In case of Rejection
		accountingAuditTrial.setMemoNo(miscBillingTrnInvoice.getRejInvoiceNo());
		accountingAuditTrial.setReportingCurrency(baseCurrency);
		String accountType = accountAttributeView.getAccountType();
		if ("AP".equals(accountType) || "AR".equals(accountType)) {
			accountingAuditTrial.setAccountType(accountType);
			/*
			 * accountingAuditTrial.setTransDocNumber(miscBillingTrnInvoice.
			 * getSellerOrganizationId());
			 * accountingAuditTrial.setRefDocumentNumber(miscBillingTrnInvoice.
			 * getSellerOrganizationId());
			 * accountingAuditTrial.setMainDocNumber(miscBillingTrnInvoice.
			 * getSellerOrganizationId());
			 */
		} else {
			accountingAuditTrial.setAccountType("GL");
		}

		accountingAuditTrial.setReversalIndicator("Y");

		accountingAuditTrial.setConversionDate(invoiceDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());

		// Same as Base info
		accountingAuditTrial.setConvRateReportingCurrency(accountingAuditTrial.getConversionRate());
		accountingAuditTrial.setConvDateReportingCurrency(accountingAuditTrial.getConversionDate());
		// This would be same as Base info
		accountingAuditTrial.setDrAmtInReportingCurrency(accountingAuditTrial.getDebitAmountInBaseCurrency());
		accountingAuditTrial.setCrAmtInReportingCurrency(accountingAuditTrial.getCreditAmountInBaseCurrency());
		fetchAccountingAttribueEntries(accountAttributeView, accountingAuditTrial);

	}

	public void getAccountingAuditTrialForF3(AccountingAuditTrial accountingAuditTrial,
			AccountAttributeView accountAttributeView, InterlineForm3DetailsModel interlineForm3DetailsModel,
			String baseCurrency, BigDecimal exchangeRate, LocalDate exchangeDate) {
		accountingAuditTrial.setClientId(accountAttributeView.getClientId());
		accountingAuditTrial.setModule(accountAttributeView.getModule());
		String sellerOrganizationId = interlineForm3DetailsModel.getBillingAirlineNumCode();
		String refDocNumber = String.valueOf(interlineForm3DetailsModel.getInterlineForm3Id());
		accountingAuditTrial.setTransIssAirline(sellerOrganizationId);
		accountingAuditTrial.setTransDocNumber(refDocNumber);
		accountingAuditTrial.setMainIssAirline(sellerOrganizationId);
		accountingAuditTrial.setMainDocNumber(refDocNumber);
		accountingAuditTrial.setRefIssuingCarrier(sellerOrganizationId);
		accountingAuditTrial.setRefDocumentNumber(refDocNumber);
		accountingAuditTrial.setCouponNumber(0);
		accountingAuditTrial.setDocumentUniqueId(refDocNumber);
		accountingAuditTrial.setDocType(accountAttributeView.getDocType());
		/*
		 * Date invoiceDate = miscBillingTrnInvoice.getInvoiceDate(); if(invoiceDate !=
		 * null) { LocalDate dateOfIssue =
		 * invoiceDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		 * accountingAuditTrial.setDateOfIssue(dateOfIssue); }
		 */

		accountingAuditTrial.setBaseCurrency(baseCurrency);
		accountingAuditTrial.setAccountAlphaCode(accountAttributeView.getAccountAlphaCode());
		accountingAuditTrial.setAccountDesciption(accountAttributeView.getAccountDescription());
		accountingAuditTrial.setAccountCode(accountAttributeView.getAccountCode());
		accountingAuditTrial.setTransactionCurrency(interlineForm3DetailsModel.getInvoiceCurrency());
		accountingAuditTrial.setScenarioNumber(accountAttributeView.getScenarioNumber());
		accountingAuditTrial.setAccountDefinitionIdentifier(accountAttributeView.getAccountDefinitionIdentifier());
		accountingAuditTrial.setConversionRate(exchangeRate.setScale(5, RoundingMode.HALF_UP));
		accountingAuditTrial.setAccountingDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		accountingAuditTrial.setBatchKey1(sellerOrganizationId);

		accountingAuditTrial.setBatchKey2(interlineForm3DetailsModel.getBilledAirlineNumCode());
		accountingAuditTrial.setBatchKey3("ICH");
		accountingAuditTrial.setBatchKey4(String.valueOf(interlineForm3DetailsModel.getBillingPeriod()));
		LocalDate conversionDate = getDate(interlineForm3DetailsModel.getBillingMonth());
		accountingAuditTrial
				.setBatchKey5(conversionDate);
		accountingAuditTrial
				.setBatchKey6(conversionDate);
		accountingAuditTrial.setSubModule("F3");
		// accountingAuditTrial.setBatchKey5(LocalDate.now());
		//accountingAuditTrial.setBatchKey6(LocalDate.now());
		// In case of Rejection
		accountingAuditTrial.setMemoNo(null);
		accountingAuditTrial.setReportingCurrency(baseCurrency);
		String accountType = accountAttributeView.getAccountType();
		if ("AP".equals(accountType)) {
			accountingAuditTrial.setAccountType(accountType);
		} else {
			accountingAuditTrial.setAccountType("GL");
		}
		//accountingAuditTrial.setAccountType(accountAttributeView.getAccountType());

		accountingAuditTrial.setReversalIndicator("Y");

		accountingAuditTrial.setConversionDate(conversionDate);

		// Same as Base info
		accountingAuditTrial.setConvRateReportingCurrency(accountingAuditTrial.getConversionRate());
		accountingAuditTrial.setConvDateReportingCurrency(accountingAuditTrial.getConversionDate());
		// This would be same as Base info
		accountingAuditTrial.setDrAmtInReportingCurrency(accountingAuditTrial.getDebitAmountInBaseCurrency());
		accountingAuditTrial.setCrAmtInReportingCurrency(accountingAuditTrial.getCreditAmountInBaseCurrency());
		fetchAccountingAttribueEntries(accountAttributeView, accountingAuditTrial);
	}

	private void fetchAccountingAttribueEntries(AccountAttributeView accountAttributeView,
			AccountingAuditTrial accountingAuditTrial) {
		accountingAuditTrial.setAccountingAttribute1(accountAttributeView.getAttribute1());
		accountingAuditTrial.setAccountingAttribute2(accountAttributeView.getAttribute2());
		accountingAuditTrial.setAccountingAttribute3(accountAttributeView.getAttribute3());
		accountingAuditTrial.setAccountingAttribute4(accountAttributeView.getAttribute4());
		accountingAuditTrial.setAccountingAttribute5(accountAttributeView.getAttribute5());
		accountingAuditTrial.setAccountingAttribute6(accountAttributeView.getAttribute6());
		accountingAuditTrial.setAccountingAttribute7(accountAttributeView.getAttribute7());
		accountingAuditTrial.setAccountingAttribute8(accountAttributeView.getAttribute8());
		accountingAuditTrial.setAccountingAttribute9(accountAttributeView.getAttribute9());
		accountingAuditTrial.setAccountingAttribute10(accountAttributeView.getAttribute10());
		accountingAuditTrial.setAccountingAttribute11(accountAttributeView.getAttribute11());
		accountingAuditTrial.setAccountingAttribute12(accountAttributeView.getAttribute12());
		accountingAuditTrial.setAccountingAttribute13(accountAttributeView.getAttribute13());
		accountingAuditTrial.setAccountingAttribute14(accountAttributeView.getAttribute14());
		accountingAuditTrial.setAccountingAttribute15(accountAttributeView.getAttribute15());
		accountingAuditTrial.setAccountingAttribute16(accountAttributeView.getAttribute16());
		accountingAuditTrial.setAccountingAttribute17(accountAttributeView.getAttribute17());
		accountingAuditTrial.setAccountingAttribute18(accountAttributeView.getAttribute18());
		accountingAuditTrial.setAccountingAttribute19(accountAttributeView.getAttribute19());
		accountingAuditTrial.setAccountingAttribute20(accountAttributeView.getAttribute20());
	}

	private LocalDate getDate(String monthDate) {
		LocalDate date = null;
		SimpleDateFormat formatter = new SimpleDateFormat("MMM-yy");
		try {
			date = formatter.parse(monthDate).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		} catch (ParseException e) {
			Log.error("Failed to parse month date " + monthDate + " : " + e.getMessage(), e);
		}
		return date;
	}
}
