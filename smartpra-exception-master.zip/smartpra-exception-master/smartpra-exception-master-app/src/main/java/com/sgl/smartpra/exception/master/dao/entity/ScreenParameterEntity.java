package com.sgl.smartpra.exception.master.dao.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(schema = "SmartPRAMaster", name = "mas_screen_parameter")
@Getter
@Setter
public class ScreenParameterEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "screen_param_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer screenParamId;

    private Long screenId;

    private String paramName;

    private String fieldName;

    @Column(name = "reference_indicator", nullable = false)
    private String referenceIndicator;

}
