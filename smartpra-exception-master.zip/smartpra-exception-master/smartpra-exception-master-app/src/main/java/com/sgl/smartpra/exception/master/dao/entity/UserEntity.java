package com.sgl.smartpra.exception.master.dao.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Data;

@Immutable
@Data
@Table(name = "user_view", schema = "dbo")
@Entity
public class UserEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private Long userId;

	private Long teamId;

	private Long groupId;

	private String userName;

	private String userEmail;

	private String userFullName;

}
