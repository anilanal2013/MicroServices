package com.sgl.smartpra.exception.master.dao.impl;

import com.sgl.smartpra.exception.master.dao.ScreenMasterDao;
import com.sgl.smartpra.exception.master.dao.entity.ScreenMasterEntity;
import com.sgl.smartpra.exception.master.dao.repository.ScreenMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ScreenMasterDaoImpl implements ScreenMasterDao {


	@Autowired
	ScreenMasterRepository screenMasterRepository;


	@Override
	public List<ScreenMasterEntity> findAll(Example<ScreenMasterEntity> screenMasterEntityExample) {
		return screenMasterRepository.findAll(screenMasterEntityExample);
	}
}
