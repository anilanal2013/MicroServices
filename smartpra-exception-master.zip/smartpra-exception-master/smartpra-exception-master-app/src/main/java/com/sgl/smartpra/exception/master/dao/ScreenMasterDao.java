package com.sgl.smartpra.exception.master.dao;

import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterEntity;
import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterViewEntity;
import com.sgl.smartpra.exception.master.dao.entity.ScreenMasterEntity;
import org.springframework.data.domain.Example;

import java.util.List;
import java.util.Optional;

public interface ScreenMasterDao {


    public List<ScreenMasterEntity> findAll(Example<ScreenMasterEntity> screenMasterEntityExample);


}
