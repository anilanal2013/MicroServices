package com.sgl.smartpra.exception.master.dao.impl;

import com.sgl.smartpra.exception.master.dao.ScreenParamterDao;
import com.sgl.smartpra.exception.master.dao.entity.ScreenParameterEntity;
import com.sgl.smartpra.exception.master.dao.repository.ScreenParameterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ScreenParameterDaoImpl implements ScreenParamterDao {


	@Autowired
	ScreenParameterRepository screenParameterRepository;

	@Override
	public List<ScreenParameterEntity> findAll(Example<ScreenParameterEntity> parameterEntityExample) {
		return screenParameterRepository.findAll(parameterEntityExample);
	}
}
