package com.sgl.smartpra.exception.master.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sgl.smartpra.exception.master.model.GroupModel;
import com.sgl.smartpra.exception.master.model.TeamModel;
import com.sgl.smartpra.exception.master.model.UserModel;
import com.sgl.smartpra.exception.master.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/groups")
    public List<GroupModel> getAllGroups() {
        return userService.findAllGroups();
    }

    @GetMapping("/allTeams")
    public List<TeamModel> getAllTeams() {
        return userService.findAllTeams();
    }
    @GetMapping("/allUsers")
    public List<UserModel> getAllUsers() {
        return userService.findAllUsers();
    }

    @GetMapping("/teams")
    public List<TeamModel> getTeamsByGroupId(@RequestParam(value = "groupId") Long groupId) {
        return userService.findAllTeamsByGroupId(Optional.of(groupId));
    }

    @GetMapping("/users")
    public List<UserModel> getUsersByTeamId(@RequestParam(value = "teamId") Long teamId) {
        return userService.findAllUsersByTeamId(Optional.of(teamId));
    }

    @GetMapping("/getuser")
    public UserModel getUserByNameOrEmail(@RequestParam(value = "user") String user) {
        return userService.findByUserNameOrEmail(user);
    }

    @GetMapping("/{userId}")
    public UserModel getUserByUserId(@PathVariable("userId") Long userId) {
        return userService.findByUserId(Optional.of(userId));
    }




}
