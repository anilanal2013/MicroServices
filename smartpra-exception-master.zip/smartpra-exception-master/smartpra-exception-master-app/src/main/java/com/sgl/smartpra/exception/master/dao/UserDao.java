package com.sgl.smartpra.exception.master.dao;

import java.util.List;

import com.sgl.smartpra.exception.master.model.GroupModel;
import com.sgl.smartpra.exception.master.model.TeamModel;
import com.sgl.smartpra.exception.master.model.UserModel;


public interface UserDao {

    public GroupModel findByGroupId(Long groupId);

    public TeamModel findByTeamId(Long teamId);

    public UserModel findByUserId(Long userId);

    public List<GroupModel> findAllGroups();

    public List<TeamModel> findAllTeams();

    public List<UserModel> findAllUsers();

    public List<TeamModel> findAllTeamsByGroupId(Long groupId);

    public List<UserModel> findAllUsersByTeamId(Long teamId);

    public UserModel findByUserNameOrEmail(String user);
}

