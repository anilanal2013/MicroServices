package com.sgl.smartpra.exception.master.dao.repository;

import com.sgl.smartpra.exception.master.dao.entity.GroupEntity;
import com.sgl.smartpra.exception.master.dao.entity.UserViewEntity;
import com.sgl.smartpra.exception.master.model.GroupModel;
import com.sgl.smartpra.exception.master.model.TeamModel;
import com.sgl.smartpra.exception.master.model.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GroupViewRepository extends JpaRepository<GroupEntity, Long>, JpaSpecificationExecutor<GroupEntity> {

    public GroupEntity findDistinctByGroupId(Long groupId);

    public List<GroupEntity> findDistinctByGroupIdIsNotNull();

}
