package com.sgl.smartpra.exception.master.mapper;

import java.util.List;

import com.sgl.smartpra.exception.master.dao.entity.UserEntity;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.exception.master.model.UserModel;


@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface UserViewMapper extends BaseMapper<UserModel, UserEntity> {

    UserModel mapToModel(UserEntity userEntity);

    UserEntity mapToEntity(UserModel userModel, @MappingTarget UserEntity userEntity);

    List<UserModel> mapToModel(List<UserEntity> userEntity);

    List<UserEntity> mapToEntity(List<UserModel> userModel);
}
