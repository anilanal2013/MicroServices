package com.sgl.smartpra.exception.master.dao.repository;

import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterViewEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExceptionMasterViewRepository
		extends JpaRepository<ExceptionMasterViewEntity, Integer>, JpaSpecificationExecutor<ExceptionMasterViewEntity> {

    List<ExceptionMasterViewEntity> findExceptionMasterEntitiesByExceptionMasIdIn(List<Integer> exceptionMasIds);
}
