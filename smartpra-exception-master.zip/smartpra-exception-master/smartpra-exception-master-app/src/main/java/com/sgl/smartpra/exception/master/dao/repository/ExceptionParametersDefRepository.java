package com.sgl.smartpra.exception.master.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.exception.master.dao.entity.ExceptionParametersDefinitionEntity;

@Repository
public interface ExceptionParametersDefRepository extends JpaRepository<ExceptionParametersDefinitionEntity, Long>,
		JpaSpecificationExecutor<ExceptionParametersDefinitionEntity> {

	public List<ExceptionParametersDefinitionEntity> findByExceptionMasterEntityExceptionMasterId(
			Integer exceptionMasterId);
}
