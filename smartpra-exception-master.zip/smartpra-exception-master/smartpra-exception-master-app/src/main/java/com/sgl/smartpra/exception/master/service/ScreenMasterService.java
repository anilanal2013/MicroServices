package com.sgl.smartpra.exception.master.service;

import java.util.List;

import com.sgl.smartpra.exception.master.model.ScreenMasterModel;
import com.sgl.smartpra.exception.master.model.ScreenParameterModel;

public interface ScreenMasterService {

	public List<ScreenMasterModel> searchScreen(ScreenMasterModel screenMasterModel);

	public List<ScreenParameterModel> searchScreenParameter(ScreenParameterModel screenParameterModel);

}
