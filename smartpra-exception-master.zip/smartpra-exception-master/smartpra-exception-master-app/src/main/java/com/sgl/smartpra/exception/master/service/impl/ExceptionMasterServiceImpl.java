package com.sgl.smartpra.exception.master.service.impl;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.master.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.exception.master.constants.LovConstants;
import com.sgl.smartpra.exception.master.constants.ModuleNameEnum;
import com.sgl.smartpra.exception.master.dao.ExceptionMasterDao;
import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterEntity;
import com.sgl.smartpra.exception.master.mapper.ExceptionMasterEditMapper;
import com.sgl.smartpra.exception.master.mapper.ExceptionMasterMapper;
import com.sgl.smartpra.exception.master.mapper.ExceptionMasterViewMapper;
import com.sgl.smartpra.exception.master.mapper.ExceptionParametersDefMapper;
import com.sgl.smartpra.exception.master.model.*;
import com.sgl.smartpra.exception.master.service.ExceptionMasterService;
import com.sgl.smartpra.exception.master.service.ScreenMasterService;
import com.sgl.smartpra.exception.master.service.UserService;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordAlreadyExistsException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
@Slf4j
public class ExceptionMasterServiceImpl implements ExceptionMasterService {

    @Autowired
    private ExceptionMasterMapper exceptionMasterMapper;

    @Autowired
    private ExceptionMasterEditMapper exceptionMasterEditMapper;

    @Autowired
    private ExceptionParametersDefMapper parametersDefinitionMapper;

    @Autowired
    private ExceptionMasterDao exceptionMasterDao;

    @Autowired
    private UserService userService;

    @Autowired
    private ExceptionMasterViewMapper exceptionMasterViewMapper;

    @Autowired
    private ScreenMasterService screenMasterService;

    @Autowired
    private MasterFeignClient masterFeignClient;

    private static final String RECORD_ALREADY_ACTIVE = "Given Record is already Active";

    private static final String RECORD_ALREADY_INACTIVE = "Given Record is already InActive";

    @Override
    public ExceptionMasterModel createExceptionMaster(ExceptionMasterModel exceptionMasterModel) {
        Optional<ExceptionMasterEntity> optionalExceptionMasterEntity = exceptionMasterDao
                .findByExceptionCode(OptionalUtil.getValue(exceptionMasterModel.getExceptionCode()));
        if (optionalExceptionMasterEntity.isPresent()) {
            throw new RecordAlreadyExistsException(String.valueOf(exceptionMasterModel.getExceptionCode()));
        }
        exceptionMasterModel.setActivate(Boolean.TRUE);
        return exceptionMasterMapper.mapToModel(exceptionMasterDao.create(addExceptionParametersDefinitionList(
                exceptionMasterMapper.mapToEntity(exceptionMasterModel), exceptionMasterModel)));
    }

    @Override
    public ExceptionMasterModel updateExceptionMaster(ExceptionMasterModel exceptionMasterModel) {
        if (!exceptionMasterDao.existsById(exceptionMasterModel.getExceptionMasterId())) {
            throw new RecordNotFoundException(String.valueOf(exceptionMasterModel.getExceptionMasterId()));
        }
        log.debug("{}", exceptionMasterModel);

        // retrieve exceptionMasterEntity Newly(To avoid detached object exception) and
        // perform
        // 1) update the ExceptionMasterEntity 2) Insert ParametersDefinition Entities
        ExceptionMasterEntity exceptionMasterEntity = exceptionMasterDao
                .getOne(exceptionMasterModel.getExceptionMasterId());
        // delete the existing parameters definition mapping
        exceptionMasterDao.deleteParamDefByExceptionMasterId(exceptionMasterModel.getExceptionMasterId());

        // Copy the Model (Update) objects into the entity
        exceptionMasterEntity = exceptionMasterMapper.mapToEntity(exceptionMasterModel, exceptionMasterEntity);
        return exceptionMasterMapper.mapToModel(exceptionMasterDao
                .update(addExceptionParametersDefinitionList(exceptionMasterEntity, exceptionMasterModel)));
    }

    @Override
    public ExceptionMasterEditModel editGlobalExceptionMaster(Integer exceptionMasterId,
                                                              ExceptionMasterEditModel exceptionMasterEditModel) {
        ExceptionMasterEntity exceptionMasterEntity = exceptionMasterDao
                .getOne(exceptionMasterId);
        exceptionMasterEntity = exceptionMasterEditMapper.mapToEntity(exceptionMasterEditModel, exceptionMasterEntity);
        exceptionMasterDao.update(exceptionMasterEntity);
        return exceptionMasterEditModel;
    }

    @Override
    public ExceptionMasterModel findByExceptionMasterId(Integer exceptionMasterId, String clientId) {
        ExceptionPreLoadModel exceptionPreLoadModel = new ExceptionPreLoadModel();
        ExceptionMasterModel exceptionMasterModel = exceptionMasterMapper
                .mapToModel(exceptionMasterDao.findById(exceptionMasterId)
                        .orElseThrow(() -> new RecordNotFoundException(String.valueOf(exceptionMasterId))));
        if (exceptionMasterModel != null) {
            if (exceptionMasterModel.getTeamId() != null && exceptionMasterModel.getTeamId().isPresent())
                exceptionPreLoadModel.setTeamList(userService.findAllTeamsByGroupId(exceptionMasterModel.getGroupId()));
            if (exceptionMasterModel.getUserId() != null && exceptionMasterModel.getUserId().isPresent())
                exceptionPreLoadModel.setUserList(userService.findAllUsersByTeamId(exceptionMasterModel.getTeamId()));
            exceptionMasterModel.setPreLoadModelList(exceptionPreLoadModel);
        }
        return exceptionMasterModel;
    }

    @Override
    public List<ExceptionMasterViewModel> search(ExceptionMasterViewModel exceptionMasterModel) {
        return mapGroupTeamUserName(exceptionMasterViewMapper
                .mapToModel(exceptionMasterDao.findAllExceptions(exceptionMasterModel)));
    }

    @Override
    public void activate(ExceptionMasterModel exceptionMasterModel) {
        ExceptionMasterEntity exceptionMasterEntity = exceptionMasterDao
                .findById(exceptionMasterModel.getExceptionMasterId()).orElseThrow(
                        () -> new RecordNotFoundException(String.valueOf(exceptionMasterModel.getExceptionMasterId())));
        if (exceptionMasterEntity.getActivate()) {
            throw new BusinessException(RECORD_ALREADY_ACTIVE);
        }
        exceptionMasterEntity.setActivate(Boolean.TRUE);
        exceptionMasterEntity.setLastUpdatedBy(OptionalUtil.getValue(exceptionMasterModel.getLastUpdatedBy()));
        exceptionMasterDao.update(exceptionMasterEntity);
    }

    @Override
    public void deActivate(ExceptionMasterModel exceptionMasterModel) {
        ExceptionMasterEntity exceptionMasterEntity = exceptionMasterDao
                .findById(exceptionMasterModel.getExceptionMasterId()).orElseThrow(
                        () -> new RecordNotFoundException(String.valueOf(exceptionMasterModel.getExceptionMasterId())));
        if (!exceptionMasterEntity.getActivate()) {
            throw new BusinessException(RECORD_ALREADY_INACTIVE);
        }
        exceptionMasterEntity.setActivate(Boolean.FALSE);
        exceptionMasterEntity.setLastUpdatedBy(OptionalUtil.getValue(exceptionMasterModel.getLastUpdatedBy()));
        exceptionMasterDao.update(exceptionMasterEntity);
    }

    @Override
    public List<ExceptionMasterModel> getAllExceptionsByModule(ModuleNameEnum exceptionCode) {
        return exceptionMasterMapper.mapToModel(exceptionMasterDao.getAllExceptionsByModule(exceptionCode));
    }

    @Override
    public List<ExceptionMasterViewModel> getAllExceptionsByMasterIds(List<Integer> exceptionMasIds) {
        return exceptionMasterViewMapper.mapToModel(exceptionMasterDao.getAllExceptionsByMasterIdsIn(exceptionMasIds));
    }

    @Override
    public ExceptionPreLoadModel getPreLoadingData(String clientId) {
        ExceptionPreLoadModel exceptionPreLoadModel = new ExceptionPreLoadModel();
        exceptionPreLoadModel
                .setLovList(masterFeignClient.getListOfValues(clientId, LovConstants.GENERAL, LovConstants.MODULE));
        exceptionPreLoadModel.setScreenList(screenMasterService.searchScreen(new ScreenMasterModel()));
        exceptionPreLoadModel.setGroupList(userService.findAllGroups());
        return exceptionPreLoadModel;
    }

    @Override
    public ExceptionMasterModel findByExceptionCode(String exceptionCode) {
        ExceptionMasterEntity exceptionMasterEntity = exceptionMasterDao.findByExceptionCode(exceptionCode)
                .orElseThrow(() -> new RecordNotFoundException(exceptionCode));
        ExceptionMasterModel exceptionMasterModel = exceptionMasterMapper.mapToModel(exceptionMasterEntity);
        if (exceptionMasterModel.getParametersDefinitionList() != null
                && exceptionMasterModel.getParametersDefinitionList().isEmpty()) {
            exceptionMasterModel.setParametersDefinitionList(null);
        }
        return exceptionMasterModel;
    }

    /*
     * Iterates the groups ,team , user name from the master model list
     */
    private List<ExceptionMasterViewModel> mapGroupTeamUserName(
            List<ExceptionMasterViewModel> exceptionMasterListModels) {
        for (ExceptionMasterViewModel exceptionMasModel : exceptionMasterListModels) {
            if (exceptionMasModel.getGroupId() != null) {
                GroupModel groupModel = userService.findByGroupId(Optional.of(exceptionMasModel.getGroupId()));
                if (groupModel != null && groupModel.getGroupName() != null)
                    exceptionMasModel.setGroupName(groupModel.getGroupName());
                if (exceptionMasModel.getTeamId() != null) {
                    TeamModel teamModel = userService.findByTeamId(Optional.of(exceptionMasModel.getTeamId()));
                    if (teamModel != null && teamModel.getTeamName() != null)
                        exceptionMasModel.setTeamName(teamModel.getTeamName());
                    if (exceptionMasModel.getUserId() != null) {
                        UserModel userModel = userService.findByUserId(Optional.of(exceptionMasModel.getUserId()));
                        if (userModel != null && userModel.getUserFullName() != null)
                            exceptionMasModel.setUserName(userModel.getUserFullName());
                    }
                }
            }
        }
        return exceptionMasterListModels;
    }

    private ExceptionMasterEntity addExceptionParametersDefinitionList(ExceptionMasterEntity exceptionMasterEntity,
                                                                       ExceptionMasterModel exceptionMasterModel) {
        // if ExceptionParametersDefinitionList is not empty, add it to MasterEntity
        List<ExceptionParametersDefinitionModel> parametersDefinitionModelList = exceptionMasterModel
                .getParametersDefinitionList();
        if (parametersDefinitionModelList != null) {
            parametersDefinitionModelList.forEach(parametersDefinitionModel -> exceptionMasterEntity
                    .addParametersDefinitionEntity(parametersDefinitionMapper.mapToEntity(parametersDefinitionModel,
                            getCreatedBy(exceptionMasterEntity, exceptionMasterModel),
                            getLastUpdatedBy(exceptionMasterEntity, exceptionMasterModel))));
        }
        log.debug("{}", exceptionMasterEntity);
        return exceptionMasterEntity;
    }

    private String getCreatedBy(ExceptionMasterEntity exceptionMasterEntity,
                                ExceptionMasterModel exceptionMasterModel) {
        if (OptionalUtil.isPresent(exceptionMasterModel.getCreatedBy())) {
            return OptionalUtil.getValue(exceptionMasterModel.getCreatedBy());
        } else {
            return exceptionMasterEntity.getCreatedBy();
        }
    }

    private String getLastUpdatedBy(ExceptionMasterEntity exceptionMasterEntity,
                                    ExceptionMasterModel exceptionMasterModel) {
        if (OptionalUtil.isPresent(exceptionMasterModel.getLastUpdatedBy())) {
            return OptionalUtil.getValue(exceptionMasterModel.getLastUpdatedBy());
        } else {
            return exceptionMasterEntity.getLastUpdatedBy();
        }
    }

}
