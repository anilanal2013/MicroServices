package com.sgl.smartpra.exception.master.util;


import java.util.Optional;

public class ExceptionUtil {

    private ExceptionUtil() {
    }

    public static Optional<String> generateExceptionCodeByCount(String exceptionCount, String moduleName) {
        return Optional.of(moduleName.concat(exceptionCount));
    }


}
