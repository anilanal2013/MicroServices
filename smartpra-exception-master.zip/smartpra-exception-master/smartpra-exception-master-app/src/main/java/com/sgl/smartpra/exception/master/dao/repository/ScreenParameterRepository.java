package com.sgl.smartpra.exception.master.dao.repository;

import com.sgl.smartpra.exception.master.dao.entity.ScreenParameterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface ScreenParameterRepository
		extends JpaRepository<ScreenParameterEntity, Integer>, JpaSpecificationExecutor<ScreenParameterRepository> {


}
