package com.sgl.smartpra.exception.master.mapper;

import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterEntity;
import com.sgl.smartpra.exception.master.model.ExceptionMasterEditModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionMasterEditMapper extends BaseMapper<ExceptionMasterEditModel, ExceptionMasterEntity> {


    ExceptionMasterEntity mapToEntity(ExceptionMasterEditModel exceptionMasterModel,
                                      @MappingTarget ExceptionMasterEntity exceptionMasterEntity);

}
