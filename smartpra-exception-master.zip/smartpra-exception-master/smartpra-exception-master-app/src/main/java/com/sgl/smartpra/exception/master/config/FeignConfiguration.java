package com.sgl.smartpra.exception.master.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.sgl.smartpra.master.model.ListOfValues;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-master-app")
	public interface MasterFeignClient {

		@GetMapping("/listofvalueslist/{clientId}/{tableName}/{columeName}")
		public List<ListOfValues> getListOfValues(@PathVariable(value = "clientId") String clientId,
				@PathVariable(value = "tableName") String tableName,
				@PathVariable(value = "columeName") String columeName);

	}

}
