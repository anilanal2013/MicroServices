package com.sgl.smartpra.exception.master.dao;

import com.sgl.smartpra.exception.master.constants.ModuleNameEnum;
import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterEntity;
import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterViewEntity;
import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;
import org.springframework.data.domain.Example;

import java.util.List;
import java.util.Optional;

public interface ExceptionMasterDao {

	// ------------- create -----------------
	public ExceptionMasterEntity create(ExceptionMasterEntity exceptionMasterEntity);

	// ------------ update -------------------
	public ExceptionMasterEntity update(ExceptionMasterEntity exceptionMasterEntity);

	// ------------- delete --------------
	public void deleteParamDefByExceptionMasterId(Integer exceptionMasterId);

	// ------------- Find / select --------------
	public Optional<ExceptionMasterEntity> findById(Integer exceptionMasterId);

	public ExceptionMasterEntity getOne(Integer exceptionMasterId);

	public Boolean existsById(Integer exceptionMasterId);

	public Optional<ExceptionMasterEntity> findByExceptionCode(String exceptionCode);

	public List<ExceptionMasterEntity> findAll(Example<ExceptionMasterEntity> exampleExceptionMasterEntity);

    public List<ExceptionMasterViewEntity> findAllExceptions(
            ExceptionMasterViewModel exceptionMasterViewModel);

    List<ExceptionMasterEntity> getAllExceptionsByModule(ModuleNameEnum exceptionCode);

    List<ExceptionMasterViewEntity> getAllExceptionsByMasterIdsIn(List<Integer> exceptionMasIds);

}
