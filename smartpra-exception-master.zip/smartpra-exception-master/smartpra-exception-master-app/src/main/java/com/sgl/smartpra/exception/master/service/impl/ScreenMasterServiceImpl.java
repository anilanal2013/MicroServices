package com.sgl.smartpra.exception.master.service.impl;

import java.util.List;

import com.sgl.smartpra.exception.master.dao.ScreenMasterDao;
import com.sgl.smartpra.exception.master.dao.ScreenParamterDao;
import com.sgl.smartpra.exception.master.mapper.ScreenParamterMapper;
import com.sgl.smartpra.exception.master.model.ScreenParameterModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.exception.master.mapper.ScreenMasterMapper;
import com.sgl.smartpra.exception.master.model.ScreenMasterModel;
import com.sgl.smartpra.exception.master.service.ScreenMasterService;
import org.springframework.data.domain.Example;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ScreenMasterServiceImpl implements ScreenMasterService {


    @Autowired
    private ScreenMasterDao screenMasterDao;

    @Autowired
    private ScreenParamterDao screenParameterDao;

    @Autowired
    private ScreenMasterMapper screenMasterMapper;

    @Autowired
    private ScreenParamterMapper screenParamterMapper;

    @Override
    public List<ScreenMasterModel> searchScreen(ScreenMasterModel screenMasterModel) {
        return screenMasterMapper.mapToModel(screenMasterDao.findAll(
                Example.of(screenMasterMapper.mapToEntity(screenMasterModel))));
    }

    @Override
    public List<ScreenParameterModel> searchScreenParameter(ScreenParameterModel screenParameterModel) {
        return screenParamterMapper.mapToModel(screenParameterDao.findAll(
                Example.of(screenParamterMapper.mapToEntity(screenParameterModel))));
    }


}
