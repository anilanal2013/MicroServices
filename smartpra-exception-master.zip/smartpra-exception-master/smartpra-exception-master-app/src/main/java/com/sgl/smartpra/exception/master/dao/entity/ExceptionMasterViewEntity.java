package com.sgl.smartpra.exception.master.dao.entity;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import lombok.Data;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@Immutable
@Table(name = "EXCEPTION_MASTER_VIEW", schema = "dbo")
public class ExceptionMasterViewEntity  implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private Integer exceptionMasId;

	private String clientId;

	private String exceptionCode;

	@Column(name = "module_lov_id")
	private Integer lovId;

	private String moduleName;

	private String exceptionDescription;

	@Column(name = "parameter1_id")
	private Integer parameter1Id;

	@Column(name = "parameter2_id")
	private Integer parameter2Id;

	@Column(name = "parameter3_id")
	private Integer parameter3Id;

	@Column(name = "parameter4_id")
	private Integer parameter4Id;

	@Column(name = "parameter5_id")
	private Integer parameter5Id;

	@Column(name = "parameter6_id")
	private Integer parameter6Id;

	@Column(name = "parameter7_id")
	private Integer parameter7Id;

	@Column(name = "parameter8_id")
	private Integer parameter8Id;

	@Column(name = "parameter9_id")
	private Integer parameter9Id;

	@Column(name = "parameter10_id")
	private Integer parameter10Id;

	@Column(name = "parameter11_id")
	private Integer parameter11Id;

	@Column(name = "parameter12_id")
	private Integer parameter12Id;

	@Column(name = "parameter1_name")
	private String parameter1Name;

	@Column(name = "parameter2_name")
	private String parameter2Name;

	@Column(name = "parameter3_name")
	private String parameter3Name;

	@Column(name = "parameter4_name")
	private String parameter4Name;

	@Column(name = "parameter5_name")
	private String parameter5Name;

	@Column(name = "parameter6_name")
	private String parameter6Name;

	@Column(name = "parameter7_name")
	private String parameter7Name;

	@Column(name = "parameter8_name")
	private String parameter8Name;

	@Column(name = "parameter9_name")
	private String parameter9Name;

	@Column(name = "parameter10_name")
	private String parameter10Name;

	@Column(name = "parameter11_name")
	private String parameter11Name;

	@Column(name = "parameter12_name")
	private String parameter12Name;

	private String exceptionCategory;

	private String exceptionType;

	private String exceptionSeverity;

	private String exceptionCause;

	private String exceptionAction;

	@Convert(converter = BooleanToStringConverter.class)
	@Column(name = "is_visible")
	private Boolean visible;

	@Column(name = "exp_resolution_time")
	private Integer expectedResolutionTime;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "screen_id")
	private Integer screenId;

	@Column(name = "group_id")
	private Long groupId;

	@Column(name = "team_id")
	private Long teamId;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "is_approval_required")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isApporvalRequired;

	@Column(name = "approver_group_id")
	private Long approverGroupId;

	@Column(name = "approver_team_id")
	private Integer approverTeamId;

	@Column(name = "approver_user_id")
	private Long approverUserId;

	@Column(name = "force_close_indicator")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean forceCloseIndicator;

	@Column(name = "exception_hint")
	private String exceptionHint;

	private String screenName;

    private String screenUrl;


}
