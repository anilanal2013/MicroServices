package com.sgl.smartpra.exception.master.mapper;

import com.sgl.smartpra.exception.master.dao.entity.GroupEntity;
import com.sgl.smartpra.exception.master.dao.entity.GroupEntity;
import com.sgl.smartpra.exception.master.model.GroupModel;
import com.sgl.smartpra.exception.master.model.GroupModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import java.security.acl.Group;
import java.util.List;


@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface GroupViewMapper extends BaseMapper<GroupModel, GroupEntity> {

    GroupModel mapToModel(GroupEntity groupEntity);

    GroupEntity mapToEntity(GroupModel groupModel, @MappingTarget GroupEntity groupEntity);

    List<GroupModel> mapToModel(List<GroupEntity> groupEntities);

    List<GroupEntity> mapToEntity(List<GroupModel> groupModels);
}
