package com.sgl.smartpra.exception.master.dao.impl;

import com.sgl.smartpra.exception.master.constants.ModuleNameEnum;
import com.sgl.smartpra.exception.master.dao.ExceptionMasterDao;
import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterEntity;
import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterViewEntity;
import com.sgl.smartpra.exception.master.dao.repository.ExceptionMasterRepository;
import com.sgl.smartpra.exception.master.dao.repository.ExceptionMasterViewRepository;
import com.sgl.smartpra.exception.master.dao.repository.ExceptionParametersDefRepository;
import com.sgl.smartpra.exception.master.dao.spec.ExceptionMasterSearchSpec;
import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class ExceptionMasterDaoImpl implements ExceptionMasterDao {

	@Autowired
	private ExceptionParametersDefRepository parametersDefinitionRepository;

	@Autowired
	private ExceptionMasterRepository exceptionMasterRepository;

	@Autowired
	private ExceptionMasterViewRepository exceptionMasterViewRepository;

	@Override
	public ExceptionMasterEntity create(ExceptionMasterEntity exceptionMasterEntity) {
		return exceptionMasterRepository.save(exceptionMasterEntity);
	}

	@Override
	public ExceptionMasterEntity update(ExceptionMasterEntity exceptionMasterEntity) {
		return exceptionMasterRepository.save(exceptionMasterEntity);
	}

    @Override
	public Optional<ExceptionMasterEntity> findById(Integer exceptionMasterId) {
		return exceptionMasterRepository.findById(exceptionMasterId);
	}

	@Override
	public ExceptionMasterEntity getOne(Integer exceptionMasterId) {
		return exceptionMasterRepository.getOne(exceptionMasterId);
	}

	@Override
	public List<ExceptionMasterEntity> findAll(Example<ExceptionMasterEntity> exampleExceptionMasterEntity) {
		return exceptionMasterRepository.findAll(exampleExceptionMasterEntity);
	}

	@Override
	public Optional<ExceptionMasterEntity> findByExceptionCode(String exceptionCode) {
		return exceptionMasterRepository.findByExceptionCode(exceptionCode);
	}

	@Override
	public Boolean existsById(Integer exceptionMasterId) {
		return exceptionMasterRepository.existsById(exceptionMasterId);
	}

	@Override
	public void deleteParamDefByExceptionMasterId(Integer exceptionMasterId) {
		parametersDefinitionRepository.deleteAll(
				parametersDefinitionRepository.findByExceptionMasterEntityExceptionMasterId(exceptionMasterId));
        parametersDefinitionRepository.flush();
	}

	@Override
	public List<ExceptionMasterViewEntity> findAllExceptions(
			ExceptionMasterViewModel exceptionMasterViewModel) {
		return exceptionMasterViewRepository.findAll(ExceptionMasterSearchSpec.search(exceptionMasterViewModel), Sort.by("exceptionCode"));
	}

	@Override
	public List<ExceptionMasterEntity> getAllExceptionsByModule(ModuleNameEnum exceptionCode) {
		return exceptionMasterRepository.findExceptionMasterEntitiesByExceptionCodeContainingAndActivateIsTrue(String.valueOf(exceptionCode));
	}

    @Override
    public List<ExceptionMasterViewEntity> getAllExceptionsByMasterIdsIn(List<Integer> exceptionMasIds) {
        return exceptionMasterViewRepository.findExceptionMasterEntitiesByExceptionMasIdIn(exceptionMasIds);
    }

}
