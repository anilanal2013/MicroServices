package com.sgl.smartpra.exception.master.dao.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "exception_parameter_definition", schema = "SmartPRAException")
@Getter
@Setter
@ToString(exclude = { "exceptionMasterEntity" })
public class ExceptionParametersDefinitionEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "param_def_id")
	private Long parameterDefinitionId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "exception_mas_id", nullable = false)
	private ExceptionMasterEntity exceptionMasterEntity;

	@Column(name = "param_name")
	private String parameterName;

	@Column(name = "param_type")
	private String parameterType;

	@Column(name = "is_active", nullable = false)
	private boolean isActive;

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof ExceptionParametersDefinitionEntity))
			return false;
		return parameterDefinitionId != null
				&& parameterDefinitionId.equals(((ExceptionParametersDefinitionEntity) o).parameterDefinitionId);
	}

	@Override
	public int hashCode() {
		return parameterDefinitionId.hashCode();
	}

}
