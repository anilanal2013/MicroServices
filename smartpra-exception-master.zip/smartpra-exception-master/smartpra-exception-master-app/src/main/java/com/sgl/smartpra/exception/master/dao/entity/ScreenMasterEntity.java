package com.sgl.smartpra.exception.master.dao.entity;

import javax.persistence.*;

import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(schema = "SmartPRAMaster", name = "mas_screen_master")
@Getter
@Setter
@DynamicUpdate
@ToString
public class ScreenMasterEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "screen_id", updatable = false, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer screenId;

	private String screenName;

	private String screenType;

	private String screenUrl;

	@Column(name = "is_active", nullable = true)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;


}
