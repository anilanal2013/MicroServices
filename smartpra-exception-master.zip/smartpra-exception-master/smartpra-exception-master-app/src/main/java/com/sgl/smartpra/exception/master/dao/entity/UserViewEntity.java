package com.sgl.smartpra.exception.master.dao.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Data;

@Entity
@Data
@Immutable
@Table(name = "user_view", schema = "dbo")
public class UserViewEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private Long userId;

	private Long groupId;

	private String groupName;

	private Long teamId;

	private String teamName;

	private String userFullName;

	private String categoryLevel;

	private Long userRoleId;

	private String userName;


}
