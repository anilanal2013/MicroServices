package com.sgl.smartpra.exception.master.dao.impl;

import java.util.List;

import com.sgl.smartpra.exception.master.dao.repository.GroupViewRepository;
import com.sgl.smartpra.exception.master.dao.repository.TeamViewRepository;
import com.sgl.smartpra.exception.master.mapper.GroupViewMapper;
import com.sgl.smartpra.exception.master.mapper.TeamViewMapper;
import com.sgl.smartpra.exception.master.mapper.UserViewMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.exception.master.dao.UserDao;
import com.sgl.smartpra.exception.master.dao.repository.UserViewRepository;
import com.sgl.smartpra.exception.master.model.GroupModel;
import com.sgl.smartpra.exception.master.model.TeamModel;
import com.sgl.smartpra.exception.master.model.UserModel;


@Component
public class UserDaoImpl implements UserDao {

    @Autowired
    private GroupViewRepository groupViewRepository;

    @Autowired
    private TeamViewRepository teamViewRepository;

    @Autowired
    private UserViewRepository userViewRepository;

    @Autowired
    private GroupViewMapper groupViewMapper;

    @Autowired
    private TeamViewMapper teamViewMapper;

    @Autowired
    private UserViewMapper userViewMapper;
    


    @Override
    public GroupModel findByGroupId(Long groupId) {
        return groupViewMapper.mapToModel(groupViewRepository.findDistinctByGroupId(groupId));
    }

    @Override
    public TeamModel findByTeamId(Long teamId) {
        return teamViewMapper.mapToModel(teamViewRepository.findDistinctByTeamId(teamId));
    }

    @Override
    public UserModel findByUserId(Long userId) {
        return userViewMapper.mapToModel(userViewRepository.findDistinctByUserId(userId));
    }

    @Override
    public List<GroupModel> findAllGroups() {
        return groupViewMapper.mapToModel(groupViewRepository.findDistinctByGroupIdIsNotNull());
    }

    @Override
    public List<TeamModel> findAllTeams() {
        return teamViewMapper.mapToModel(teamViewRepository.findDistinctByTeamIdIsNotNull());
    }

    @Override
    public List<UserModel> findAllUsers() {
        return userViewMapper.mapToModel(userViewRepository.findDistinctByUserIdIsNotNull());
    }

    @Override
    public List<TeamModel> findAllTeamsByGroupId(Long groupId) {
        return teamViewMapper.mapToModel(teamViewRepository.getDistinctByGroupId(groupId));
    }


    @Override
    public List<UserModel> findAllUsersByTeamId(Long teamId) {
        return userViewMapper.mapToModel(userViewRepository.getDistinctByTeamId(teamId));
    }

    @Override
    public UserModel findByUserNameOrEmail(String user) {
        return userViewMapper.mapToModel(userViewRepository.findAllByUserNameOrUserEmail(user,user));
    }
}
