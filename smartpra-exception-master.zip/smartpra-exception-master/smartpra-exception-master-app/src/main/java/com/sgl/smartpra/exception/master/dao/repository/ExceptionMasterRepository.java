package com.sgl.smartpra.exception.master.dao.repository;

import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ExceptionMasterRepository
		extends JpaRepository<ExceptionMasterEntity, Integer>, JpaSpecificationExecutor<ExceptionMasterEntity> {

	Optional<ExceptionMasterEntity> findByExceptionCode(String exceptionCode);

	List<ExceptionMasterEntity> findExceptionMasterEntitiesByExceptionCodeContainingAndActivateIsTrue(String exceptionCode);

    List<ExceptionMasterEntity> findExceptionMasterEntitiesByExceptionMasterIdIn(List<Integer> exceptionMasterId);



}
