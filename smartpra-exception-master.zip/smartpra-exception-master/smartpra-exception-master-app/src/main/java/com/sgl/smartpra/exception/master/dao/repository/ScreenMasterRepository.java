package com.sgl.smartpra.exception.master.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.exception.master.dao.entity.ScreenMasterEntity;

@Repository
public interface ScreenMasterRepository
		extends JpaRepository<ScreenMasterEntity, Integer>, JpaSpecificationExecutor<ScreenMasterRepository> {


}
