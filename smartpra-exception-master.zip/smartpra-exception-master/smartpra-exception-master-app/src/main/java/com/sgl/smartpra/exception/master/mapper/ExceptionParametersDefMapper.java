package com.sgl.smartpra.exception.master.mapper;


import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.exception.master.dao.entity.ExceptionParametersDefinitionEntity;
import com.sgl.smartpra.exception.master.model.ExceptionParametersDefinitionModel;


@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionParametersDefMapper
		extends BaseMapper<ExceptionParametersDefinitionModel, ExceptionParametersDefinitionEntity> {

	@Mapping(source = "createdBy", target = "createdBy")
	@Mapping(source = "lastUpdatedBy", target = "lastUpdatedBy")
	@Mapping(source = "parametersDefinitionModel.parameterDefinitionId", target = "parameterDefinitionId", ignore = true)
	ExceptionParametersDefinitionEntity mapToEntity(ExceptionParametersDefinitionModel parametersDefinitionModel,
													String createdBy, String lastUpdatedBy);

}
