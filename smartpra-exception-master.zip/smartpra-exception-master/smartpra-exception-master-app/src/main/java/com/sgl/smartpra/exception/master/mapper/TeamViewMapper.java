package com.sgl.smartpra.exception.master.mapper;

import com.sgl.smartpra.exception.master.dao.entity.TeamEntity;
import com.sgl.smartpra.exception.master.model.TeamModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import java.util.List;


@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface TeamViewMapper extends BaseMapper<TeamModel, TeamEntity> {

    TeamModel mapToModel(TeamEntity teamEntity);

    TeamEntity mapToEntity(TeamModel teamModel, @MappingTarget TeamEntity teamEntity);

    List<TeamModel> mapToModel(List<TeamEntity> teamEntities);

    List<TeamEntity> mapToEntity(List<TeamModel> teamModels);
}
