package com.sgl.smartpra.exception.master.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriUtils;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.exception.master.constants.ModuleNameEnum;
import com.sgl.smartpra.exception.master.model.ExceptionMasterEditModel;
import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;
import com.sgl.smartpra.exception.master.model.ExceptionPreLoadModel;
import com.sgl.smartpra.exception.master.service.ExceptionMasterService;

@RestController
@RequestMapping("/exception")
public class ExceptionMasterController {

    @Autowired
    private ExceptionMasterService exceptionMasterService;

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public ExceptionMasterModel createGlobalExceptionMaster(
            @RequestBody @Validated(value = Create.class) ExceptionMasterModel exceptionMasterModel) {
        return exceptionMasterService.createExceptionMaster(exceptionMasterModel);
    }

    @PutMapping(path = "/{exceptionMasterId}")
    public ExceptionMasterModel updateGlobalExceptionMaster(
            @PathVariable(value = "exceptionMasterId") Integer exceptionMasterId,
            @RequestBody @Validated(value = Update.class) ExceptionMasterModel exceptionMasterModel) {
        exceptionMasterModel.setExceptionMasterId(exceptionMasterId);
        return exceptionMasterService.updateExceptionMaster(exceptionMasterModel);
    }

    @PutMapping(path = "edit/{exceptionMasterId}")
    public ExceptionMasterEditModel editGlobalExceptionMaster(
            @PathVariable(value = "exceptionMasterId") Integer exceptionMasterId,
            @RequestBody @Validated(value = Update.class) ExceptionMasterEditModel exceptionMasterEditModel) {
        exceptionMasterEditModel.setExceptionMasterId(exceptionMasterId);
        return exceptionMasterService.editGlobalExceptionMaster(exceptionMasterId, exceptionMasterEditModel);
    }

    @GetMapping(path = "/{clientId}/{exceptionMasterId}")
    public ExceptionMasterModel findByExceptionMasterId(@PathVariable(value = "clientId") String clientId,
                                                        @PathVariable(value = "exceptionMasterId") Integer exceptionMasterId) {
        return exceptionMasterService.findByExceptionMasterId(exceptionMasterId, clientId);
    }

    @GetMapping
    public List<ExceptionMasterViewModel> search(
            @RequestParam(name = "lovId", required = false) Integer moduleId,
            @RequestParam(name = "activate", required = false) Boolean activate,
            @RequestParam(name = "exceptionCode", required = false) String exceptionCode,
            @RequestParam(name = "exceptionCategory", required = false) String exceptionCategory,
            @RequestParam(name = "exceptionType", required = false) String exceptionType,
            @RequestParam(name = "exceptionSeverity", required = false) String exceptionSeverity,
            @RequestParam(name = "forceCloseIndicator", required = false) Boolean forceCloseIndicator,
            @RequestParam(name = "exceptionDescription", required = false) String exceptionDescription,
            @RequestParam(name="screenId",required= false) Integer screenId) {
        ExceptionMasterViewModel exceptionMasterModel = new ExceptionMasterViewModel();
        exceptionMasterModel.setExceptionCode(exceptionCode);
        exceptionMasterModel.setForceCloseIndicator(forceCloseIndicator);
        exceptionMasterModel.setExceptionCategory(exceptionCategory);
        exceptionMasterModel.setExceptionType(exceptionType);
        exceptionMasterModel.setExceptionSeverity(exceptionSeverity);
        exceptionMasterModel.setActivate(activate);
        exceptionMasterModel.setLovId(moduleId);
        exceptionMasterModel.setVisible(true);
        exceptionMasterModel.setScreenId(screenId);
        if (exceptionDescription != null)
            exceptionMasterModel.setExceptionDescription(UriUtils.decode(exceptionDescription, "UTF-8"));
        else exceptionMasterModel.setExceptionDescription(null);
        return exceptionMasterService.search(exceptionMasterModel);
    }

    @PutMapping("/{exceptionMasterId}/deactivate")
    public void deactivateFOP(@PathVariable(value = "exceptionMasterId") Integer exceptionMasterId,
                              @RequestParam(value = "lastUpdatedBy", required = true) Optional<String> lastUpdatedBy) {
        ExceptionMasterModel exceptionMasterModel = new ExceptionMasterModel();
        exceptionMasterModel.setExceptionMasterId(exceptionMasterId);
        exceptionMasterModel.setLastUpdatedBy(lastUpdatedBy);
        exceptionMasterService.deActivate(exceptionMasterModel);
    }

    @PutMapping("/{exceptionMasterId}/activate")
    public void activateFOP(@PathVariable(value = "exceptionMasterId") Integer exceptionMasterId,
                            @RequestParam(value = "lastUpdatedBy", required = true) Optional<String> lastUpdatedBy) {
        ExceptionMasterModel exceptionMasterModel = new ExceptionMasterModel();
        exceptionMasterModel.setExceptionMasterId(exceptionMasterId);
        exceptionMasterModel.setLastUpdatedBy(lastUpdatedBy);
        exceptionMasterService.activate(exceptionMasterModel);
    }

    @GetMapping(path = "/{clientId}/preload")
    public ExceptionPreLoadModel getPreLoadingData(@PathVariable(value = "clientId") String clientId) {
        return exceptionMasterService.getPreLoadingData(clientId);
    }

    @GetMapping("/findByExceptionCode/{exceptionCode}")
    public ExceptionMasterModel findByExceptionCode(@PathVariable(value = "exceptionCode") String exceptionCode) {
        return exceptionMasterService.findByExceptionCode(exceptionCode);
    }

    @GetMapping("/{moduleName}")
    public List<ExceptionMasterModel> getAllExceptions(@PathVariable(value = "moduleName") ModuleNameEnum exceptionCode) {
        return exceptionMasterService.getAllExceptionsByModule(exceptionCode);
    }

    @PostMapping("/findByMasterIds")
    public List<ExceptionMasterViewModel> getAllExceptionsByMasterIds(@RequestBody() List<Integer> exceptionMasIds) {
        return exceptionMasterService.getAllExceptionsByMasterIds(exceptionMasIds);
    }

}
