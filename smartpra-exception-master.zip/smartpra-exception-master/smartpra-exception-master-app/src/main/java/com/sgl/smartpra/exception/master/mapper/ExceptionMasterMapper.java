package com.sgl.smartpra.exception.master.mapper;


import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterEntity;
import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;


@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionMasterMapper extends BaseMapper<ExceptionMasterModel, ExceptionMasterEntity> {

    @Mapping(source = "exceptionMasterEntity.parametersDefinitionEntityList", target = "parametersDefinitionList")
    ExceptionMasterModel mapToModel(ExceptionMasterEntity exceptionMasterEntity);

    ExceptionMasterEntity mapToEntity(ExceptionMasterModel exceptionMasterModel,
                                      @MappingTarget ExceptionMasterEntity exceptionMasterEntity);

}
