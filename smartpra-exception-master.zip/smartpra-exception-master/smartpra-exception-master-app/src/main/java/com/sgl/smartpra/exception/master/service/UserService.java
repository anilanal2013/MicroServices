package com.sgl.smartpra.exception.master.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.exception.master.model.GroupModel;
import com.sgl.smartpra.exception.master.model.TeamModel;
import com.sgl.smartpra.exception.master.model.UserModel;
import com.sgl.smartpra.exception.master.model.UserViewModel;


public interface UserService {

	public List<GroupModel> findAllGroups();

	public List<TeamModel> findAllTeams();

	public List<UserModel> findAllUsers();

	public GroupModel findByGroupId(Optional<Long> groupId);

	public TeamModel findByTeamId(Optional<Long> teamId);

	public UserModel findByUserId(Optional<Long> userId);

	public List<TeamModel> findAllTeamsByGroupId(Optional<Long> groupId);

	public List<UserModel> findAllUsersByTeamId(Optional<Long> teamId);

    public UserModel findByUserNameOrEmail(String user);
}





