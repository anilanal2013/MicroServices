package com.sgl.smartpra.exception.master.dao;

import com.sgl.smartpra.exception.master.dao.entity.ScreenParameterEntity;
import org.springframework.data.domain.Example;

import java.util.List;

public interface ScreenParamterDao {


    public List<ScreenParameterEntity> findAll(Example<ScreenParameterEntity> parameterEntityExample);


}
