package com.sgl.smartpra.exception.master.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterViewEntity;
import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;


@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionMasterViewMapper extends BaseMapper<ExceptionMasterViewModel, ExceptionMasterViewEntity> {

    ExceptionMasterViewModel mapToModel(ExceptionMasterViewEntity exceptionMasterEntity);

    ExceptionMasterViewEntity mapToEntity(ExceptionMasterViewModel exceptionMasterModel,
                                          @MappingTarget ExceptionMasterViewEntity exceptionMasterEntity);

}
