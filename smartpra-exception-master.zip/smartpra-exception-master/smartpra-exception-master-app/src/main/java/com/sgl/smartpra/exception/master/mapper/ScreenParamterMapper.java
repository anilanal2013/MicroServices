package com.sgl.smartpra.exception.master.mapper;

import com.sgl.smartpra.exception.master.dao.entity.ScreenParameterEntity;
import com.sgl.smartpra.exception.master.model.ScreenParameterModel;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ScreenParamterMapper extends BaseMapper<ScreenParameterModel, ScreenParameterEntity> {

     ScreenParameterModel mapToModel(ScreenParameterEntity screenParameterEntity);

}
