package com.sgl.smartpra.exception.master.controller;

import com.sgl.smartpra.exception.master.model.ScreenMasterModel;
import com.sgl.smartpra.exception.master.model.ScreenParameterModel;
import com.sgl.smartpra.exception.master.service.ScreenMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/screen")
public class ScreenMasterController {

	@Autowired
	private ScreenMasterService screenMasterService;


	@GetMapping
	public List<ScreenMasterModel> search(
			@RequestParam(name = "screenId", required = false) Integer screenId){
		ScreenMasterModel screenMasterModel =  new ScreenMasterModel();
		screenMasterModel.setScreenId(screenId);
		return screenMasterService.searchScreen(screenMasterModel);
	}

	@GetMapping("/parameter")
	public List<ScreenParameterModel> searchScreenParameter(
			@RequestParam(name = "screenId", required = false) Integer screenId){
		ScreenParameterModel screenParameterModel =  new ScreenParameterModel();
		screenParameterModel.setScreenId(screenId);
		return screenMasterService.searchScreenParameter(screenParameterModel);
	}

}
