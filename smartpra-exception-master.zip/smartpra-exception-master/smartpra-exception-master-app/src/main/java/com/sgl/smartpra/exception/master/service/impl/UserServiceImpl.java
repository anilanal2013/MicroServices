package com.sgl.smartpra.exception.master.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.exception.master.dao.UserDao;
import com.sgl.smartpra.exception.master.model.GroupModel;
import com.sgl.smartpra.exception.master.model.TeamModel;
import com.sgl.smartpra.exception.master.model.UserModel;
import com.sgl.smartpra.exception.master.model.UserViewModel;
import com.sgl.smartpra.exception.master.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Override
	public GroupModel findByGroupId(Optional<Long> groupId) {
		return userDao.findByGroupId(groupId.get());
	}

	@Override
	public TeamModel findByTeamId(Optional<Long> teamId) {
		return userDao.findByTeamId(teamId.get());
	}

	@Override
	public UserModel findByUserId(Optional<Long> userId) {
		return userDao.findByUserId(userId.get());
	}

	@Override
	public List<GroupModel> findAllGroups() {
		return userDao.findAllGroups();
	}

    @Override
    public List<TeamModel> findAllTeams() {
        return userDao.findAllTeams();
    }

	@Override
	public List<UserModel> findAllUsers() {
		return  userDao.findAllUsers();
	}

	@Override
	public List<TeamModel> findAllTeamsByGroupId(Optional<Long> groupId) {
		return userDao.findAllTeamsByGroupId(groupId.get());
	}

	@Override
	public List<UserModel> findAllUsersByTeamId(Optional<Long> teamId) {
		return userDao.findAllUsersByTeamId(teamId.get());
	}

	@Override
	public UserModel findByUserNameOrEmail(String user) {
		return userDao.findByUserNameOrEmail(user);
	}

}
