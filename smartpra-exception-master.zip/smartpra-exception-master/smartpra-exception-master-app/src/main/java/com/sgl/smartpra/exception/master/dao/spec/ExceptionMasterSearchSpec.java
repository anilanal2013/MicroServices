package com.sgl.smartpra.exception.master.dao.spec;

import com.sgl.smartpra.exception.master.dao.entity.ExceptionMasterViewEntity;
import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

public final class ExceptionMasterSearchSpec {
    private ExceptionMasterSearchSpec() {
    }

    public static Specification<ExceptionMasterViewEntity> search(ExceptionMasterViewModel exceptionMasterViewModel) {

        return (exceptionMasterViewEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (exceptionMasterViewModel.getLovId() != null) {
                predicates.add(criteriaBuilder.equal(exceptionMasterViewEntity.get("lovId"),
                        exceptionMasterViewModel.getLovId()));
            }

            if (exceptionMasterViewModel.getActivate() != null) {
                predicates.add(criteriaBuilder.equal(exceptionMasterViewEntity.get("activate"),
                        exceptionMasterViewModel.getActivate()));
            }

            if (exceptionMasterViewModel.getExceptionDescription() != null) {
                predicates.add(criteriaBuilder.like(exceptionMasterViewEntity.get("exceptionDescription"),
                        "%" + exceptionMasterViewModel.getExceptionDescription()
                                .replace("[","/[").replace("]","/]") + "%",'/'));
            }
            if (exceptionMasterViewModel.getExceptionCategory() != null) {
                predicates.add(criteriaBuilder.like(exceptionMasterViewEntity.get("exceptionCategory"),
                        "%" + exceptionMasterViewModel.getExceptionCategory() + "%"));

            }
            if (exceptionMasterViewModel.getExceptionCode() != null) {
                predicates.add(criteriaBuilder.like(exceptionMasterViewEntity.get("exceptionCode"),
                        "%" + exceptionMasterViewModel.getExceptionCode() + "%"));

            }
            if (exceptionMasterViewModel.getExceptionSeverity() != null) {
                predicates.add(criteriaBuilder.like(exceptionMasterViewEntity.get("exceptionSeverity"),
                        "%" + exceptionMasterViewModel.getExceptionSeverity() + "%"));

            }
            if (exceptionMasterViewModel.getExceptionType() != null) {
                predicates.add(criteriaBuilder.like(exceptionMasterViewEntity.get("exceptionType"),
                        "%" + exceptionMasterViewModel.getExceptionType() + "%"));

            }
            if (exceptionMasterViewModel.getVisible() != null) {
                predicates.add(criteriaBuilder.equal(exceptionMasterViewEntity.get("visible"),
                        exceptionMasterViewModel.getVisible()));
            }

            if (exceptionMasterViewModel.getForceCloseIndicator() != null) {
                predicates.add(criteriaBuilder.equal(exceptionMasterViewEntity.get("forceCloseIndicator"),
                        exceptionMasterViewModel.getForceCloseIndicator()));

            }
            if (exceptionMasterViewModel.getModuleName() != null) {
                predicates.add(criteriaBuilder.like(exceptionMasterViewEntity.get("moduleName"),
                        "%" + exceptionMasterViewModel.getModuleName() + "%"));

            }
            if (exceptionMasterViewModel.getScreenId() != null) {
                predicates.add(criteriaBuilder.equal(exceptionMasterViewEntity.get("screenId"),
                        exceptionMasterViewModel.getScreenId()));
            }
            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
        };

    }
}














