package com.sgl.smartpra.exception.master.service;

import com.sgl.smartpra.exception.master.constants.ModuleNameEnum;
import com.sgl.smartpra.exception.master.model.ExceptionMasterEditModel;
import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;
import com.sgl.smartpra.exception.master.model.ExceptionPreLoadModel;

import java.util.List;

public interface ExceptionMasterService {

	// --------- To get preload data ----------
	public ExceptionPreLoadModel getPreLoadingData(String clientId);

	// -------- create -------------
	public ExceptionMasterModel createExceptionMaster(ExceptionMasterModel exceptionMasterModel);

	// -------- update -------------
	public ExceptionMasterModel updateExceptionMaster(ExceptionMasterModel exceptionMasterModel);

	//----------edit -------------------
	public ExceptionMasterEditModel editGlobalExceptionMaster(Integer exceptionMasterId,
															  ExceptionMasterEditModel exceptionMasterEditModel);

	// --------- Find & Search -----------------
	public ExceptionMasterModel findByExceptionMasterId(Integer exceptionMasterId, String clientId);

	public ExceptionMasterModel findByExceptionCode(String exceptionCode);

	public List<ExceptionMasterViewModel> search(ExceptionMasterViewModel exceptionMasterModel);

	// ---------- activate and de-activate ---------
	public void activate(ExceptionMasterModel exceptionMasterModel);

	public void deActivate(ExceptionMasterModel exceptionMasterModel);

	List<ExceptionMasterModel> getAllExceptionsByModule(ModuleNameEnum exceptionCode);

    List<ExceptionMasterViewModel> getAllExceptionsByMasterIds(List<Integer> exceptionMasIds);
}
