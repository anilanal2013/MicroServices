package com.sgl.smartpra.exception.master.dao.repository;

import com.sgl.smartpra.exception.master.dao.entity.TeamEntity;
import com.sgl.smartpra.exception.master.dao.entity.UserViewEntity;
import com.sgl.smartpra.exception.master.model.GroupModel;
import com.sgl.smartpra.exception.master.model.TeamModel;
import com.sgl.smartpra.exception.master.model.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeamViewRepository extends JpaRepository<TeamEntity, Long>, JpaSpecificationExecutor<TeamEntity> {


	public TeamEntity findDistinctByTeamId(Long teamId);

	public List<TeamEntity> getDistinctByGroupId(Long groupId);

	public List<TeamEntity> findDistinctByTeamIdIsNotNull();


}
