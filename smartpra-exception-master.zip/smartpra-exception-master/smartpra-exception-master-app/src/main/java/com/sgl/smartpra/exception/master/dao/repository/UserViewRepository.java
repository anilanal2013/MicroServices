package com.sgl.smartpra.exception.master.dao.repository;

import java.util.List;

import com.sgl.smartpra.exception.master.dao.entity.TeamEntity;
import com.sgl.smartpra.exception.master.dao.entity.UserEntity;
import com.sgl.smartpra.exception.master.dao.entity.UserViewEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.exception.master.model.GroupModel;
import com.sgl.smartpra.exception.master.model.TeamModel;
import com.sgl.smartpra.exception.master.model.UserModel;

@Repository
public interface UserViewRepository extends JpaRepository<UserEntity, Long>, JpaSpecificationExecutor<UserEntity> {

    public UserEntity findDistinctByUserId(Long userId);

    public List<UserEntity> getDistinctByTeamId(Long teamId);

    public UserEntity findAllByUserNameOrUserEmail(String userName, String userEmail);

    public List<UserEntity> findDistinctByUserIdIsNotNull();
}
