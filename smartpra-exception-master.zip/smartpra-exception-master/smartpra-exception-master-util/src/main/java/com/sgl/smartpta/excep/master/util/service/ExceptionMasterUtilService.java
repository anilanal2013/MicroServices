package com.sgl.smartpta.excep.master.util.service;

import com.sgl.smartpta.excep.master.util.dao.ExceptionMasterUtilDao;
import com.sgl.smartpta.excep.master.util.entity.ExceptionMasterEntity;
import com.sgl.smartpta.excep.master.util.entity.ExceptionParametersDefinitionEntity;
import com.sgl.smartpta.excep.master.util.vo.ExceptionMasterDataVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
@Slf4j
public class ExceptionMasterUtilService {

    @Autowired
    private ExceptionMasterUtilDao exceptionMasterUtilDao;

    private static final String PARAMETER_KEY = "parameter";

    private static final String PARMETER_KEY_START = "[";

    private static final String PARMETER_KEY_END = "]";

    private static final String CREATED_BY_ADMIN = "Admin";

    private static final String PARAMETER_TYPE = "P";

    private static final String TABLE_NAME = "General";

    private static final String COLUMN_NAME = "Module";

    private static final String CLIENT_ID = "QR";

    private static final String EMPTY_SPACE_CHARACTER = " ";

    public void loadExceptionMasterData(String fileName, String performLoad) throws IOException {
        System.out.println("****** loadExceptionMasterData ********");
        List<ExceptionMasterDataVO> exceptionMasterDataVOList = readExceptionMasterDataFromExcelFile(fileName);
        List<ExceptionMasterEntity> exceptionMasterEntityList = new ArrayList<>();

        List<ExceptionMasterEntity> excludedDataExceptionMasterEntityList = new ArrayList<>();
        exceptionMasterDataVOList.forEach(exceptionMasterDataVO -> {
            ExceptionMasterEntity exceptionMasterEntity = exceptionMasterUtilDao
                    .getByExceptionCode(exceptionMasterDataVO.getExceptionCode());
            // if the given exception code already exist, then exlude the data from
            // insertion
            if (exceptionMasterEntity == null) {
                exceptionMasterEntityList.add(prepareExceptionMasterEntity(exceptionMasterDataVO));
            } else {
                excludedDataExceptionMasterEntityList.add(exceptionMasterEntity);
            }
        });
        printExcludedData(excludedDataExceptionMasterEntityList);

        List<ExceptionMasterEntity> unsavedExceptionMasterDataList = new ArrayList<>();
        createExceptionMasterRecords(exceptionMasterEntityList, performLoad, unsavedExceptionMasterDataList);
        printUnsavedData(unsavedExceptionMasterDataList);
    }

    private void printExcludedData(List<ExceptionMasterEntity> excludedDataExceptionMasterEntityList) {
        System.out.println("********* Excluded Data **************");
        excludedDataExceptionMasterEntityList.forEach(excludedDataList -> System.out.println(excludedDataList));
    }

    private void createExceptionMasterRecords(List<ExceptionMasterEntity> exceptionMasterEntityList, String performLoad,
                                              List<ExceptionMasterEntity> unsavedExceptionMasterDataList) {
        System.out.println(" ********** PerformLoad = " + performLoad + " ********");

        // Only when "peformLoad" is true, Insert ExceptonMasterData into DB
        if (performLoad.equalsIgnoreCase("true")) {
            exceptionMasterEntityList.forEach(exceptionMasterEntity -> {
                try {
                    // reason for inserting it one by one is to identify the record that has error
                    exceptionMasterUtilDao.createExceptionMasterRecord(exceptionMasterEntity);
                } catch (Exception e) {
                    System.out.println("Exception occured in " + exceptionMasterEntity);
                    unsavedExceptionMasterDataList.add(exceptionMasterEntity);
                }
            });
        }
    }

    private void printUnsavedData(List<ExceptionMasterEntity> unsavedExceptionMasterDataList) {
        System.out.println("********* Unsaved Data **************");
        unsavedExceptionMasterDataList.forEach(excludedDataList -> System.out.println(excludedDataList));
    }

    private ExceptionMasterEntity prepareExceptionMasterEntity(ExceptionMasterDataVO exceptionMasterDataVO) {
        System.out.println(exceptionMasterDataVO);
        ExceptionMasterEntity exceptionMasterEntity = new ExceptionMasterEntity();
        exceptionMasterEntity.setClientId(CLIENT_ID);
        exceptionMasterEntity.setActivate(exceptionMasterDataVO.getIsActive());
        exceptionMasterEntity.setCreatedBy(CREATED_BY_ADMIN);
        exceptionMasterEntity.setExceptionAction(exceptionMasterDataVO.getExpectedAction2());
        exceptionMasterEntity.setExceptionCategory(exceptionMasterDataVO.getExceptionCategory());
        exceptionMasterEntity.setExceptionCause(exceptionMasterDataVO.getExceptionCause());
        exceptionMasterEntity.setExceptionCode(exceptionMasterDataVO.getExceptionCode());
        exceptionMasterEntity.setExceptionDesc(exceptionMasterDataVO.getExceptionDesc());
        exceptionMasterEntity.setExceptionHint(exceptionMasterDataVO.getHint());
        exceptionMasterEntity.setExceptionSeverity(exceptionMasterDataVO.getExceptionComplexity());
        exceptionMasterEntity.setExceptionType(exceptionMasterDataVO.getExceptionType());
        exceptionMasterEntity.setExpectedResolutionTime(exceptionMasterDataVO.getResolutionMinutes());
        exceptionMasterEntity.setForceCloseIndicator(false);
        exceptionMasterEntity.setIsApporvalRequired(false);
        exceptionMasterEntity.setVisible(exceptionMasterDataVO.getIsVisible());

        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter1())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter1()));
        }
        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter2())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter2()));
        }
        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter3())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter3()));
        }
        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter4())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter4()));
        }
        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter5())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter5()));
        }

        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter6())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter6()));
        }

        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter7())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter7()));
        }

        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter8())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter8()));
        }

        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter9())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter9()));
        }

        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter10())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter10()));
        }

        if (StringUtils.isNotEmpty(exceptionMasterDataVO.getRuntimeParameter11())) {
            exceptionMasterEntity.addParametersDefinitionEntity(
                    prepareExceptionParameterDefinitionEntity(exceptionMasterDataVO.getRuntimeParameter11()));
        }


        Integer screenId = exceptionMasterUtilDao.getScreenId(exceptionMasterDataVO.getScreenName().trim());
        if (screenId != null) {
            exceptionMasterEntity.setScreenId(screenId);
        } else {
            exceptionMasterEntity.setScreenId(
                    exceptionMasterUtilDao.saveScreenMasterData(exceptionMasterDataVO.getScreenName().trim()));
        }

        Integer lovId = exceptionMasterUtilDao.getLovId(TABLE_NAME, COLUMN_NAME,
                exceptionMasterDataVO.getModuleName().trim(), CLIENT_ID);
        if (lovId != null) {
            exceptionMasterEntity.setLovId(lovId);
        } else {
          /*  exceptionMasterEntity.setLovId(exceptionMasterUtilDao.saveLOVData(TABLE_NAME, COLUMN_NAME,
                    exceptionMasterDataVO.getModuleName().trim(), CLIENT_ID));*/
            System.out.println("Module Lov not found");
        }
        System.out.println(exceptionMasterEntity);
        return exceptionMasterEntity;
    }

    private ExceptionParametersDefinitionEntity prepareExceptionParameterDefinitionEntity(String parameterName) {
        ExceptionParametersDefinitionEntity exceptionParametersDefinitionEntity = new ExceptionParametersDefinitionEntity();
        exceptionParametersDefinitionEntity.setCreatedBy(CREATED_BY_ADMIN);
        exceptionParametersDefinitionEntity.setActive(true);
        exceptionParametersDefinitionEntity.setParameterType(PARAMETER_TYPE);
        exceptionParametersDefinitionEntity.setParameterName(parameterName);
        return exceptionParametersDefinitionEntity;
    }

    private List<ExceptionMasterDataVO> readExceptionMasterDataFromExcelFile(String fileName) throws IOException {
        FileInputStream fileInputStream = null;
        XSSFWorkbook workbook = null;
        XSSFSheet sheet = null;
        int columnCounter = 0;
        int rowCounter = 0;
        List<String> headerList = new ArrayList<>();
        ExceptionMasterDataVO exceptionMasterDataVO = null;
        List<ExceptionMasterDataVO> exceptionMasterDataVOList = new ArrayList<>();
        try {
            fileInputStream = new FileInputStream(new File(fileName));
            workbook = new XSSFWorkbook(fileInputStream);
            sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                System.out.println("--------------- ROW (" + rowCounter + ") -----------------------");
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                columnCounter = 0;
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    if (rowCounter != 0 && columnCounter == 0) {
                        exceptionMasterDataVO = new ExceptionMasterDataVO();
                        exceptionMasterDataVOList.add(exceptionMasterDataVO);
                    }
                    if (rowCounter == 0) {
                        headerList.add(cell.getStringCellValue());
                    } else {
                        setExceptionMasterDataVO(exceptionMasterDataVO, cell, columnCounter);
                    }
                    columnCounter++;
                }
                rowCounter++;

            }
            System.out.println(headerList);
            System.out.println(exceptionMasterDataVOList);
        } catch (Exception e) {
            log.error("Exception occured in ExceptionMasterUtilService.readExceptionMasterDataFromExcelFile: {}", e);

        } finally {
            if (workbook != null) {
                workbook.close();
            }
            if (fileInputStream != null) {
                fileInputStream.close();
            }
        }
        return exceptionMasterDataVOList;
    }

    private void setExceptionMasterDataVO(ExceptionMasterDataVO exceptionMasterDataVO, Cell cell, int columnCounter) {
        switch (columnCounter) {
            case 0:
                exceptionMasterDataVO.setSerialNumber(new Double(cell.getNumericCellValue()).intValue());
                break;
            case 1:
                exceptionMasterDataVO.setModuleName(cell.getStringCellValue());
                break;
            case 2:
                exceptionMasterDataVO.setExceptionCode(cell.getStringCellValue());
                break;
            case 3:
                exceptionMasterDataVO.setExceptionDesc(formatExceptionDescription(cell.getStringCellValue()));
                break;
            case 4:
                exceptionMasterDataVO.setRuntimeParameter1(cell.getStringCellValue());
                break;
            case 5:
                exceptionMasterDataVO.setRuntimeParameter2(cell.getStringCellValue());
                break;
            case 6:
                exceptionMasterDataVO.setRuntimeParameter3(cell.getStringCellValue());
                break;
            case 7:
                exceptionMasterDataVO.setRuntimeParameter4(cell.getStringCellValue());
                break;
            case 8:
                exceptionMasterDataVO.setRuntimeParameter5(cell.getStringCellValue());
                break;
            case 9:
                exceptionMasterDataVO.setRuntimeParameter6(cell.getStringCellValue());
                break;
            case 10:
                exceptionMasterDataVO.setRuntimeParameter7(cell.getStringCellValue());
                break;
            case 11:
                exceptionMasterDataVO.setRuntimeParameter8(cell.getStringCellValue());
                break;
            case 12:
                exceptionMasterDataVO.setRuntimeParameter9(cell.getStringCellValue());
                break;
            case 13:
                exceptionMasterDataVO.setRuntimeParameter10(cell.getStringCellValue());
                break;
            case 14:
                exceptionMasterDataVO.setRuntimeParameter11(cell.getStringCellValue());
                break;
            case 15:
                exceptionMasterDataVO.setExceptionCategory(cell.getStringCellValue());
                break;
            case 16:
                exceptionMasterDataVO.setExceptionType(cell.getStringCellValue());
                break;
            case 17:
                exceptionMasterDataVO.setExceptionComplexity(cell.getStringCellValue());
                break;
            case 18:
                exceptionMasterDataVO.setExceptionCause(cell.getStringCellValue());
                break;
            case 19:
                exceptionMasterDataVO.setExceptedAction1(cell.getStringCellValue());
                break;
            case 20:
                exceptionMasterDataVO.setIsActive(cell.getStringCellValue().equalsIgnoreCase("Y") ? true : false);
                break;
            case 21:
                exceptionMasterDataVO.setIsVisible(cell.getStringCellValue().equalsIgnoreCase("Y") ? true : false);
                break;
            case 22:
                exceptionMasterDataVO.setResolutionMinutes((new Double(cell.getNumericCellValue()).intValue()));
                break;
            case 23:
                exceptionMasterDataVO.setScreenName(cell.getStringCellValue());
                break;
            case 24:
                exceptionMasterDataVO.setHint(cell.getStringCellValue());
                break;
            case 25:
                exceptionMasterDataVO.setExpectedAction2(cell.getStringCellValue());
                break;
        }

    }

    private String formatExceptionDescription(String exceptionDescription) {
        System.out.println("Unformatted Exception Details =" + exceptionDescription);
        int numberOfParameters = StringUtils.countMatches(exceptionDescription, "@");
        System.out.println("numberOfParameters=" + numberOfParameters);
        if (numberOfParameters > 0) {
            for (int i = 1; i <= numberOfParameters; i++) {
                int parameterStartIndexPosition = exceptionDescription.indexOf("@");
                int parameterEndIndexPosition = parameterStartIndexPosition + PARAMETER_KEY.length() + 2;
                exceptionDescription = exceptionDescription.replace(
                        exceptionDescription.substring(parameterStartIndexPosition, parameterEndIndexPosition),
                        PARMETER_KEY_START + PARAMETER_KEY + i + PARMETER_KEY_END + EMPTY_SPACE_CHARACTER);
            }
        }
        System.out.println("formatted Exception Details " + exceptionDescription);
        return exceptionDescription;
    }
}
