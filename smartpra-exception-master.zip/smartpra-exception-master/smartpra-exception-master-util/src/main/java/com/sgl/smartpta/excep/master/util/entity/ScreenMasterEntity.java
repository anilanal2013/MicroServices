package com.sgl.smartpta.excep.master.util.entity;


import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpta.excep.master.util.converter.BooleanToStringConverter;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(schema = "SmartPRAMaster", name = "mas_screen_master")
@Getter
@Setter
@DynamicUpdate
@ToString
public class ScreenMasterEntity extends BaseEntity {

	@Id
	@Column(name = "screen_id", updatable = false, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer screenId;

	@Column(name = "screen_name", nullable = false)
	private String screenName;

	@Column(name = "screen_type", nullable = false)
	private String screenType;

	@Column(name = "screen_url", nullable = true)
	private String screenUrl;

	@Column(name = "is_active", nullable = true)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;


}
