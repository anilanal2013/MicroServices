package com.sgl.smartpta.excep.master.util.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@EnableJpaRepositories(basePackages = { "com.sgl.smartpta.excep.master.util.repo" })
@EntityScan(basePackages = { "com.sgl.smartpta.excep.master.util.entity" })
public class RepositoryConfig {

}
