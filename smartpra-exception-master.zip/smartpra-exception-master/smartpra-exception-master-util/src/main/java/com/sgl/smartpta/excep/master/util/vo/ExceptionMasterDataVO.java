package com.sgl.smartpta.excep.master.util.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class ExceptionMasterDataVO implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private Integer serialNumber;
	
	private String moduleName;
	
	private String exceptionCode;
	
	private String exceptionDesc;
	
	private String runtimeParameter1;
	
	private String runtimeParameter2;
	
	private String runtimeParameter3;
	
	private String runtimeParameter4;
	
	private String runtimeParameter5;

	private String runtimeParameter6;

	private String runtimeParameter7;

	private String runtimeParameter8;

	private String runtimeParameter9;

	private String runtimeParameter10;

	private String runtimeParameter11;

	private String runtimeParameter12;

	private String exceptionCategory;
	
	private String exceptionType;
	
	private String exceptionComplexity;
	
	private String exceptionCause;
	
	private String exceptedAction1;
	
	private Boolean isActive;
	
	private Boolean isVisible;
	
	private Integer resolutionMinutes;
	
	private String screenName;
	
	private String hint;
	
	private String expectedAction2;
	
	
	
}
