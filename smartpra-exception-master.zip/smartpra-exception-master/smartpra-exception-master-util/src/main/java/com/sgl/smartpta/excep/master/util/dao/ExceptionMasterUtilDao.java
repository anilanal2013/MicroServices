package com.sgl.smartpta.excep.master.util.dao;

import java.util.List;

import com.sgl.smartpta.excep.master.util.entity.ExceptionMasterEntity;

public interface ExceptionMasterUtilDao {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    

	public Integer getScreenId(String screenName);
	
	public Integer saveScreenMasterData(String screenName);

	public Integer getLovId(String tableName, String columnName, String addlDescription, String clientId);
	
	public Integer saveLOVData(String tableName, String columnName, String addlDescription, String clientId);

	public void createExceptionMasterRecord(List<ExceptionMasterEntity> exceptionMasterEntityList);
	
	public void createExceptionMasterRecord(ExceptionMasterEntity exceptionMasterEntity);
	
	public ExceptionMasterEntity getByExceptionCode(String exceptionCode);
}


