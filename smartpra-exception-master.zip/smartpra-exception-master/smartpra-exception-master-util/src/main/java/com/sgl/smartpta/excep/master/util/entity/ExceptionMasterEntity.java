package com.sgl.smartpta.excep.master.util.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpta.excep.master.util.converter.BooleanToStringConverter;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(schema = "SmartPRAMaster", name = "mas_exception")
@Getter
@Setter
@DynamicUpdate
@ToString
public class ExceptionMasterEntity extends BaseEntity implements Serializable {

	@Id
	@Column(name = "exception_mas_id", updatable = false, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer exceptionMasterId;

	@Column(name = "client_id", nullable = false)
	private String clientId;

	@Column(name = "exception_code", nullable = false)
	private String exceptionCode;

	@Column(name = "module_lov_id", nullable = false)
	private Integer lovId;

	@Column(name = "exception_description", nullable = false)
	private String exceptionDesc;

	@Column(name = "exception_category", nullable = false)
	private String exceptionCategory;

	@Column(name = "exception_type", nullable = false)
	private String exceptionType;

	@Column(name = "exception_severity", nullable = false)
	private String exceptionSeverity;

	@Column(name = "exception_cause", nullable = false)
	private String exceptionCause;

	@Column(name = "exception_action", nullable = false)
	private String exceptionAction;

	@Column(name = "is_visible", nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean visible;

	@Column(name = "exp_resolution_time")
	private Integer expectedResolutionTime;

	@Column(name = "is_active", nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "screen_id")
	private Integer screenId;

	@Column(name = "group_id")
	private Long groupId;

	@Column(name = "team_id")
	private Long teamId;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "is_approval_required")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isApporvalRequired;

	@Column(name = "approver_group_id")
	private Long approverGroupId;

	@Column(name = "approver_team_id")
	private Integer approverTeamId;

	@Column(name = "approver_user_id")
	private Long approverUserId;

	@Column(name = "force_close_indicator")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean forceCloseIndicator;

	@Column(name = "is_aggregatable")
	@Convert(converter = BooleanToStringConverter.class)
	private Optional<Boolean> isAggregatable;

	@Column(name = "exception_hint", nullable = false)
	private String exceptionHint;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER, mappedBy = "exceptionMasterEntity")
	private List<ExceptionParametersDefinitionEntity> parametersDefinitionEntityList = new ArrayList<>();

	public void addParametersDefinitionEntity(ExceptionParametersDefinitionEntity parametersDefinitionEntity) {
		parametersDefinitionEntity.setExceptionMasterEntity(this);
		this.parametersDefinitionEntityList.add(parametersDefinitionEntity);
	}

}
