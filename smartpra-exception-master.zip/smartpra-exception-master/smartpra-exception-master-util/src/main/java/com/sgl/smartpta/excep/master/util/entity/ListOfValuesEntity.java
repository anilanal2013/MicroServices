package com.sgl.smartpta.excep.master.util.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpta.excep.master.util.converter.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_list_of_values", schema = "smartpramaster")
@Data
@EqualsAndHashCode(callSuper=false)
@DynamicUpdate
@DynamicInsert
public class ListOfValuesEntity extends BaseEntity {

	@Id
	@Column(name = "lov_id")
	private Integer lovId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "table_name")
	private String tableName;

	@Column(name = "column_name")
	private String columnName;

	@Column(name = "field_value")
	private String fieldValue;

	@Column(name = "field_short_desc")
	private String fieldShortDescription;

	@Column(name = "addl_description")
	private String addlDescription;

	@Column(name = "display_order")
	private Integer displayOrder;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;

	@Column(name = "dependent_column_name")
	private String dependentColumnName;
	
	@Column(name = "dependent_field_value")
	private String dependentFieldValue;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastupdatedDate(LocalDateTime.now());
	}

}
