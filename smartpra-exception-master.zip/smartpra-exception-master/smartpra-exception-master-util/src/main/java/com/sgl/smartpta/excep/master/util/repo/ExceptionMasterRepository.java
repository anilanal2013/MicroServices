package com.sgl.smartpta.excep.master.util.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpta.excep.master.util.entity.ExceptionMasterEntity;

@Repository
public interface ExceptionMasterRepository
		extends JpaRepository<ExceptionMasterEntity, Integer>, JpaSpecificationExecutor<ExceptionMasterEntity> {

	ExceptionMasterEntity findByExceptionCode(String exceptionCode);

}
