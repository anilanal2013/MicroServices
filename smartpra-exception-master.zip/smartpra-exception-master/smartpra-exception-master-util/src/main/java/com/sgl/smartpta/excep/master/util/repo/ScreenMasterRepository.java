package com.sgl.smartpta.excep.master.util.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpta.excep.master.util.entity.ScreenMasterEntity;



@Repository
public interface ScreenMasterRepository
		extends JpaRepository<ScreenMasterEntity, Integer>, JpaSpecificationExecutor<ScreenMasterRepository> {

	public ScreenMasterEntity findByScreenName(String screenName);

}
