package com.sgl.smartpta.excep.master.util.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "exception_parameter_definition", schema = "SmartPRAException")
@Getter
@Setter
@ToString(exclude = { "exceptionMasterEntity" })
public class ExceptionParametersDefinitionEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "param_def_id")
	private Integer parameterDefinitionId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "exception_mas_id", nullable = false)
	private ExceptionMasterEntity exceptionMasterEntity;

	@Column(name = "param_name")
	private String parameterName;

	@Column(name = "param_type")
	private String parameterType;

	@Column(name = "is_active", nullable = false)
	private boolean isActive;

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof ExceptionParametersDefinitionEntity))
			return false;
		return parameterDefinitionId != null
				&& parameterDefinitionId.equals(((ExceptionParametersDefinitionEntity) o).parameterDefinitionId);
	}

	@Override
	public int hashCode() {
		return parameterDefinitionId.hashCode();
	}

}
