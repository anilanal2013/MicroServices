package com.sgl.smartpta.excep.master.util.repo;

import com.sgl.smartpta.excep.master.util.entity.ListOfValuesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface ListOfValuesRepository
		extends JpaRepository<ListOfValuesEntity, Integer>, JpaSpecificationExecutor<ListOfValuesEntity> {

	public ListOfValuesEntity findByTableNameAndColumnNameAndAddlDescriptionAndClientId(String tableName,
																						String columnName, String addlDescription, String clientId);
}
