package com.sgl.smartpta.excep.master.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.sgl.smartpta.excep.master.util.service.ExceptionMasterUtilService;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class ExceptionMasterUtilApplication implements CommandLineRunner {

	@Autowired
	private ExceptionMasterUtilService exceptionMasterUtilService;

	public static void main(String[] args) {
		SpringApplication.run(ExceptionMasterUtilApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		for (int i = 0; i < args.length; i++) {
			System.out.println("args[" + i + "]=" + args[i]);
			log.debug("args[{}]={}", i, args[i]);
		}

		
		exceptionMasterUtilService.loadExceptionMasterData(args[2], args[3]);
	}
}
