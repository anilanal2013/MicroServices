package com.sgl.smartpta.excep.master.util.dao.impl;

import com.sgl.smartpta.excep.master.util.dao.ExceptionMasterUtilDao;
import com.sgl.smartpta.excep.master.util.entity.ExceptionMasterEntity;
import com.sgl.smartpta.excep.master.util.entity.ListOfValuesEntity;
import com.sgl.smartpta.excep.master.util.entity.ScreenMasterEntity;
import com.sgl.smartpta.excep.master.util.repo.ExceptionMasterRepository;
import com.sgl.smartpta.excep.master.util.repo.ListOfValuesRepository;
import com.sgl.smartpta.excep.master.util.repo.ScreenMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ExceptionMasterUtilDaoImpl implements ExceptionMasterUtilDao {

	@Autowired
	private ExceptionMasterRepository exceptionMasterRepository;

	@Autowired
	private ScreenMasterRepository screenMasterRepository;

	@Autowired
	private ListOfValuesRepository listOfValuesRepository;

	@Override
	public Integer getScreenId(String screenName) {
		ScreenMasterEntity screenMasterEntity = screenMasterRepository.findByScreenName(screenName);
		if (screenMasterEntity != null) {
			return screenMasterEntity.getScreenId();
		} else {
			return null;
		}
	}

	@Override
	public Integer getLovId(String tableName, String columnName, String addlDescription, String clientId) {
		ListOfValuesEntity listOfValuesEntity = listOfValuesRepository
                .findByTableNameAndColumnNameAndAddlDescriptionAndClientId(tableName, columnName,
                        addlDescription, clientId);
		if (listOfValuesEntity != null) {
			return listOfValuesEntity.getLovId();
		} else {
			return null;
		}
	}

	@Override
	public void createExceptionMasterRecord(List<ExceptionMasterEntity> exceptionMasterEntityList) {
		exceptionMasterRepository.saveAll(exceptionMasterEntityList);
	}

	@Override
	public Integer saveScreenMasterData(String screenName) {
		ScreenMasterEntity screenMasterEntity = new ScreenMasterEntity();
		screenMasterEntity.setActivate(true);
		screenMasterEntity.setCreatedBy("Admin");
		screenMasterEntity.setScreenName(screenName);
		screenMasterEntity.setScreenType("P");
		return screenMasterRepository.save(screenMasterEntity).getScreenId();
	}

	@Override
	public Integer saveLOVData(String tableName, String columnName, String addlDescription, String clientId) {
		ListOfValuesEntity listOfValuesEntity = new ListOfValuesEntity();
		listOfValuesEntity.setAddlDescription(addlDescription);
		listOfValuesEntity.setClientId(clientId);
		listOfValuesEntity.setColumnName(columnName);
		listOfValuesEntity.setTableName(tableName);
		listOfValuesEntity.setCreatedBy("Admin");
		listOfValuesEntity.setDisplayOrder(1);
		listOfValuesEntity.setFieldShortDescription(addlDescription);
		listOfValuesEntity.setFieldValue(addlDescription);
		listOfValuesEntity.setIsActive(true);
		return listOfValuesRepository.save(listOfValuesEntity).getLovId();
	}

	@Override
	public ExceptionMasterEntity getByExceptionCode(String exceptionCode) {
		return exceptionMasterRepository.findByExceptionCode(exceptionCode);
	}

	@Override
	public void createExceptionMasterRecord(ExceptionMasterEntity exceptionMasterEntity) {
		exceptionMasterRepository.save(exceptionMasterEntity);
	}
}
