package com.sgl.smartpra.exception.master.model;

import java.io.Serializable;
import java.util.Optional;

import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.ValidValues;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;

@Data
public class ExceptionParametersDefinitionModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long parameterDefinitionId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> parameterName;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@ValidValues(values = "P,A", message = "Accepted values are P,A", groups = { Create.class, Update.class })
	private Optional<String> parameterType;

}
