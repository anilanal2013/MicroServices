package com.sgl.smartpra.exception.master.model;

import com.sgl.smartpra.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;


@Data
@EqualsAndHashCode(callSuper = false)
public class ScreenMasterModel extends BaseModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer screenId;

    private String screenName;

    private String screenType;

    private String screenUrl;

    private Boolean activate;


}
