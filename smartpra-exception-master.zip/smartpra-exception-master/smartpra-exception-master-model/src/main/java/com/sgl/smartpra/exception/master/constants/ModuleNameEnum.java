package com.sgl.smartpra.exception.master.constants;

public enum ModuleNameEnum {

    SALE, LIFT, INWARD, OUTWARD, MISC, GEN, PROR
}
