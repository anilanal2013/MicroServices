package com.sgl.smartpra.exception.master.constants;

public class   LovConstants {

    public static final String GENERAL = "GENERAL";
    public static final String MODULE = "MODULE";

}
