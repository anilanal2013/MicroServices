package com.sgl.smartpra.exception.master.model;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.ValidValues;
import com.sgl.smartpra.common.validator.group.Update;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Optional;
@Data
@EqualsAndHashCode(callSuper = false)
public class ExceptionMasterEditModel extends BaseModel {

    private Integer exceptionMasterId;

    @ValidValues(values = "B,C,L,S,T", message = "Accepted values are B,C,L,S,T", groups = {
            Update.class})
    private Optional<String> exceptionCategory;

    @ValidValues(values = "E,W,I", message = "Accepted values are E,W,I", groups = {Update.class})
    private Optional<String> exceptionType;

    @ValidValues(values = "S,M,C", message = "Accepted values are S,M,C", groups = {Update.class})
    private Optional<String> exceptionSeverity;

    private Optional<Integer> expectedResolutionTime;

    private Optional<Boolean> visible;

    private Optional<String> exceptionCause;

    private Optional<String> exceptionAction;

    private Optional<String> exceptionHint;

    private Optional<Long> groupId;

    private Optional<Long> teamId;

    private Optional<Long> userId;
    
    private Optional<Integer> screenId;

    private Optional<String> groupName;

    private Optional<String> teamName;

    private Optional<String> userName;

    private Optional<String> screenName;

    private Optional<Boolean> isApporvalRequired;

    private Optional<Boolean> isAggregatable;

    private Optional<Boolean> forceCloseIndicator;


}
