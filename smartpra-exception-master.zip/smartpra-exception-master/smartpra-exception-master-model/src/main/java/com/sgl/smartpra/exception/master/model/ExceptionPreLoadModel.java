package com.sgl.smartpra.exception.master.model;

import com.sgl.smartpra.master.model.ListOfValues;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class ExceptionPreLoadModel  implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<ListOfValues> lovList;

    private List<ScreenMasterModel> screenList;

    private List<GroupModel> groupList;

    private List<TeamModel> teamList;

    private List<UserModel> userList;

}
