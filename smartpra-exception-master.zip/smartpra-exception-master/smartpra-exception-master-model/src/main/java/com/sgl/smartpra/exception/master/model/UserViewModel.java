package com.sgl.smartpra.exception.master.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Id;
import java.io.Serializable;
import java.util.Optional;

@Data
public class UserViewModel implements Serializable {

    private static final long serialVersionUID = 1L;


    @Id
    private Long userId;

    private Long groupId;

    private String groupName;

    private Long teamId;

    private String teamName;

    private String userFullName;

    private String categoryLevel;

    private Long userRoleId;


}
