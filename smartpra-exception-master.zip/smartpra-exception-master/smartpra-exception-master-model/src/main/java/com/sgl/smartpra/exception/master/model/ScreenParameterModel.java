package com.sgl.smartpra.exception.master.model;

import com.sgl.smartpra.common.model.BaseModel;
import lombok.Data;

@Data
public class ScreenParameterModel extends BaseModel {

    private static final long serialVersionUID = 1L;

    private Integer screenParamId;

    private Integer screenId;

    private String paramName;

    private String fieldName;

    private String referenceIndicator;



}
