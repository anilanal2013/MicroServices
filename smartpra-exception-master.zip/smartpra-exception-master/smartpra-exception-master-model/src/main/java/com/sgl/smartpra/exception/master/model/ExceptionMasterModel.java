package com.sgl.smartpra.exception.master.model;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.ValidValues;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import com.sun.org.apache.xpath.internal.operations.Bool;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ExceptionMasterModel extends BaseModel {

    private static final long serialVersionUID = 1L;

    private Integer exceptionMasterId;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    private Optional<String> clientId;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    private Optional<String> exceptionCode;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    private Optional<Integer> lovId;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    private Optional<String> exceptionDesc;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @ValidValues(values = "B,C,L,S,T", message = "Accepted values are B,C,L,S,T", groups = {Create.class,
            Update.class})
    private Optional<String> exceptionCategory;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @ValidValues(values = "E,W,I", message = "Accepted values are E,W,I", groups = {Create.class, Update.class})
    private Optional<String> exceptionType;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @ValidValues(values = "S,M,C", message = "Accepted values are S,M,C", groups = {Create.class, Update.class})
    private Optional<String> exceptionSeverity;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    private Optional<String> exceptionCause;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    private Optional<String> exceptionAction;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    private Optional<Integer> expectedResolutionTime;

    @Valid
    private List<ExceptionParametersDefinitionModel> parametersDefinitionList;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    private Optional<Boolean> visible;

    @Null(message = "activate is not a valid input", groups = {Create.class, Update.class})
    private Boolean activate;

    private Optional<Long> groupId;

    private Optional<Long> teamId;

    private Optional<Long> userId;

    private Optional<Integer> screenId;

    private Optional<Long> approverGroupId;

    private Optional<Integer> approverTeamId;

    private Optional<Long> approverUserId;

    private Optional<Boolean> forceCloseIndicator;

    private Optional<Boolean> isApporvalRequired;

    private Optional<Boolean> isAggregatable;

    private String moduleName;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    private Optional<String> exceptionHint;

    private ExceptionPreLoadModel preLoadModelList;

    private String groupName;

    private String teamName;

    private String userName;

    private String screenName;





}
