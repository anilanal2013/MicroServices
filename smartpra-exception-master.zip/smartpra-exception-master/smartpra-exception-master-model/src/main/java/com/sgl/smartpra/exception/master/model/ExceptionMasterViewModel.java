package com.sgl.smartpra.exception.master.model;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Convert;
import javax.persistence.Id;
import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
public class ExceptionMasterViewModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	private Integer exceptionMasId;

	private String clientId;

	private String exceptionCode;

	private Integer lovId;

	private String moduleName;

	private String exceptionDescription;

	private Integer parameter1Id;

	private Integer parameter2Id;

	private Integer parameter3Id;

	private Integer parameter4Id;

	private Integer parameter5Id;

	private Integer parameter6Id;

	private Integer parameter7Id;

	private Integer parameter8Id;

	private Integer parameter9Id;

	private Integer parameter10Id;

	private Integer parameter11Id;

	private Integer parameter12Id;

	private String parameter1Name;

	private String parameter2Name;

	private String parameter3Name;

	private String parameter4Name;

	private String parameter5Name;

	private String parameter6Name;

	private String parameter7Name;

	private String parameter8Name;

	private String parameter9Name;

	private String parameter10Name;

	private String parameter11Name;

	private String parameter12Name;

	private String exceptionCategory;

	private String exceptionType;

	private String exceptionSeverity;

	private String exceptionCause;

	private String exceptionAction;

	@Convert(converter = BooleanToStringConverter.class)
	private Boolean visible;

	private Integer expectedResolutionTime;

	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	private Integer screenId;

	private Long groupId;

	private Long teamId;

	private Long userId;

	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isApporvalRequired;

	private Long approverGroupId;

	private Integer approverTeamId;

	private Long approverUserId;

	@Convert(converter = BooleanToStringConverter.class)
	private Boolean forceCloseIndicator;

	private String exceptionHint;

	private String screenName;

    private String screenUrl;

	private String groupName;

	private String teamName;

	private String userName;


}
