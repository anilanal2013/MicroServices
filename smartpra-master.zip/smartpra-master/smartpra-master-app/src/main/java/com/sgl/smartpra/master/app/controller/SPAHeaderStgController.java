package com.sgl.smartpra.master.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.master.app.service.impl.SPAHeaderStgServiceImpl;
import com.sgl.smartpra.master.model.SPAHeaderStg;

@RestController
@RequestMapping("/spa/header/stg")
public class SPAHeaderStgController {

	@Autowired
	private SPAHeaderStgServiceImpl spaHeaderStgServiceImpl;

	@GetMapping("/search")
	public List<SPAHeaderStg> getSpaHeaderBySpecificField(
			@RequestParam(value = "cxrCode", required = false) String cxrCode,
			@RequestParam(value = "spaCodeSeqNumber", required = false) Integer spaCodeSeqNumber,
			@RequestParam(value = "spaKey", required = false) Integer spaKey,
			@RequestParam(value = "spaId", required = false) String spaId,
			@RequestParam(value = "effectiveIssueDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveIssueDate,
			@RequestParam(value = "effectiveUpliftDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveUpliftDate) {
		return spaHeaderStgServiceImpl.getSpaHeaderBySpecSerach(cxrCode, spaCodeSeqNumber, spaKey, spaId,
				effectiveIssueDate, effectiveUpliftDate);
	}
	
	@GetMapping("/searchspaprocess")
	public List<SPAHeaderStg> getSpaHeaderForProcessingCoupon(
			@RequestParam(value = "clientId", required = true) String clientId,			
			@RequestParam(value = "cxrCode", required = true) String cxrCode,
			@RequestParam(value = "effectiveIssueDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveIssueDate,
			@RequestParam(value = "effectiveOriginalDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveOriginalDate,			
			@RequestParam(value = "effectiveUpliftDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveUpliftDate) {
		return spaHeaderStgServiceImpl.getSpaHeaderForProcessingCoupon(clientId, cxrCode, effectiveIssueDate, effectiveOriginalDate, effectiveUpliftDate);
	}
}
