package com.sgl.smartpra.master.app.repository.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mas_region_country")
public class RegionCountryEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "region_country_id", nullable = false)
	private Integer regionCountryId;

	@Column(name = "country_code", nullable = false, length = 2)
	private String countryCode;

	@Column(name = "region_code", nullable = false, length = 3)
	private String regionCode;

	@Column(name = "created_by", nullable = false, length = 15)
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;

	@Column(name = "last_updated_by", nullable = true, length = 15)
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name = "client_id", nullable = true, length = 3)
	private String clientId;

	public RegionCountryEntity() {
		super();
	}

	public Integer getRegionCountryId() {
		return regionCountryId;
	}

	public void setRegionCountryId(Integer regionCountryId) {
		this.regionCountryId = regionCountryId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

}