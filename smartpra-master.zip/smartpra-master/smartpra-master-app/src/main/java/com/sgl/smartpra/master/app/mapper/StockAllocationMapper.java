package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.StockAllocationEntity;
import com.sgl.smartpra.master.model.StockAllocation;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface StockAllocationMapper extends BaseMapper<StockAllocation, StockAllocationEntity> {

	StockAllocationEntity mapToEntity(StockAllocation stockAllocation,
			@MappingTarget StockAllocationEntity stockAllocationEntity);

	//@Mapping(source = "stockAllocationId", target = "stockAllocationId", ignore = true)
	StockAllocationEntity mapToEntity(StockAllocation stockAllocation);
}
