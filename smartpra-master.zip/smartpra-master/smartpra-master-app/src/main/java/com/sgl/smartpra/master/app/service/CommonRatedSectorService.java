package com.sgl.smartpra.master.app.service;

import com.sgl.smartpra.master.model.CommonRatedSector;

import java.util.List;
import java.util.Optional;

public interface CommonRatedSectorService {
    public List<CommonRatedSector> getAllCommonRatedSector(Optional<String> clientId, Optional<String> fromAirport,
                                                           Optional<String> toAirport, Optional<String> commonRatedFromAirport, Optional<String> commonRatedToAirport);

    CommonRatedSector createCommonRateSectors(CommonRatedSector commonRatedSector);

    CommonRatedSector updateCommonRateSectors(Integer commonRatedID, CommonRatedSector commonRatedSector);

    CommonRatedSector findCommonRatedSectorByCommonRatedSectorId(Integer commonRatedID);

    List<CommonRatedSector> getAllCommonRatedSectors( Optional<String> fromAirport, Optional<String> toAirport, Optional<String> commonRatedFromAirport, Optional<String> commonRatedToAirport, Optional<String> effectiveFromDate, Optional<String> effectiveToDate);
}
