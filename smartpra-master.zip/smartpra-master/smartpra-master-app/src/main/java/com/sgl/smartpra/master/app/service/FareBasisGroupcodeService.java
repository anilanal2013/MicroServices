package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.FareBasisGroupcode;

public interface FareBasisGroupcodeService {

	public FareBasisGroupcode createFareBasisGroupcode(FareBasisGroupcode fareBasisGroupcode);

	public FareBasisGroupcode updateFareBasisGroupcode(Integer fbGroupId, FareBasisGroupcode fareBasisGroupcode);

	public void deactivateFareBasisGroupcode(FareBasisGroupcode fareBasisGroupcode);

	public void activateFareBasisGroupcode(FareBasisGroupcode fareBasisGroupcode);

	public List<FareBasisGroupcode> getFareBasisGroupcode(Optional<Boolean> isPattern, Optional<Boolean> nonRevenueFlag,
			Optional<Boolean> unpublishFlag, Optional<String> atpcoFareType, Optional<String> btItIndicator,
			Optional<String> cabin, Optional<String> dayOfWeek, Optional<String> discountCode,
			Optional<String> fareOwnerCXR, Optional<String> fareText,  Optional<String> iataFareType, Optional<String> issueCXR,
			Optional<String> journeyType, Optional<String> normalSpecial, Optional<String> passengerName,
			Optional<String> paxType, Optional<String> seasonalCode, Optional<String> ticketedFareBasis,
			Optional<String> ticketedTD, Optional<String> zedIdentifier,Boolean isActive);

	public FareBasisGroupcode getfareBasisGroupcodeByFBGroupId(Integer fbGroupId);

	public List<FareBasisGroupcode> getFareBasisGroupcodeByGroupCode(String fbGroupCode);

	public List<FareBasisGroupcode> getAllFareBasisGroupcode();

	public List<FareBasisGroupcode> getfareBasisGroupcodeIsPattern();

	public List<FareBasisGroupcode> search(Optional<String> fbGroupCode, Optional<String> fbDescription,
			Optional<Boolean> isActive);

	public List<FareBasisGroupcode> getFareBasisGroupcodeSpecificClientId(Optional<Boolean> isPattern,
			Optional<Boolean> nonRevenueFlag, Optional<Boolean> unpublishFlag, Optional<String> atpcoFareType,
			Optional<String> btItIndicator, Optional<String> cabin, Optional<String> dayOfWeek,
			Optional<String> discountCode, Optional<String> fareOwnerCXR, Optional<String> fareText,
			Optional<String> iataFareType, Optional<String> issueCXR, Optional<String> journeyType,
			Optional<String> normalSpecial, Optional<String> passengerName, Optional<String> paxType,
			Optional<String> seasonalCode, Optional<String> ticketedFareBasis, Optional<String> ticketedTD,
			Optional<String> zedIdentifier, Optional<String> clientId, Boolean isActive);

}