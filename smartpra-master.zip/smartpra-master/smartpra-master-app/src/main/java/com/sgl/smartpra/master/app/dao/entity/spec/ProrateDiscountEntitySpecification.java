package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.ProrateDiscountEntity;

public class ProrateDiscountEntitySpecification {

	private static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";
	private static final String EFFECTIVE_TO_DATE = "effectiveToDate";
	private static final String DISCOUNT_CODE = "discountCode";

	ProrateDiscountEntitySpecification() {
	}

	public static Specification<ProrateDiscountEntity> search(String discountCode, Optional<String> effectiveDate) {
		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (discountCode != null) {
				predicates.add(criteriaBuilder.equal(prorateDiscountEntity.get(DISCOUNT_CODE), discountCode));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
						prorateDiscountEntity.get(EFFECTIVE_FROM_DATE), prorateDiscountEntity.get(EFFECTIVE_TO_DATE)));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<ProrateDiscountEntity> searchByCodeDateType(String discountCode,
			LocalDate effectiveDate, String discountType, String clientId) {
		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (discountCode != null) {
				predicates.add(criteriaBuilder.equal(prorateDiscountEntity.get(DISCOUNT_CODE), discountCode));
			}
			if (effectiveDate != null) {
				predicates.add(criteriaBuilder.between(criteriaBuilder.literal(effectiveDate),
						prorateDiscountEntity.get(EFFECTIVE_FROM_DATE), prorateDiscountEntity.get(EFFECTIVE_TO_DATE)));
			}
			if (discountType != null) {
				predicates.add(criteriaBuilder.equal(prorateDiscountEntity.get("discountType"), discountType));
			}

			if (clientId != null) {
				predicates.add(criteriaBuilder.equal(prorateDiscountEntity.get("clientId"), clientId));
			}

			orderByAsc(prorateDiscountEntity, criteriaQuery, criteriaBuilder, "cxr", "areaFBWIndicator");

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProrateDiscountEntity> isActive() {
		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateDiscountEntity.get("isActive"), true);
	}

	public static Specification<ProrateDiscountEntity> searchProrateDiscount(String discountCode, String discountType,
			Optional<String> fbGroupCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> cxr) {
		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (discountCode != null) {
				predicates.add(criteriaBuilder.like(prorateDiscountEntity.get(DISCOUNT_CODE), discountCode + "%"));
			}
			if (discountType != null) {
				predicates.add(criteriaBuilder.like(prorateDiscountEntity.get("discountType"), discountType + "%"));
			}
			if (OptionalUtil.isPresent(fbGroupCode)) {
				predicates.add(criteriaBuilder.like(prorateDiscountEntity.get("fbGroupCode"),
						OptionalUtil.getValue(fbGroupCode) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
						prorateDiscountEntity.get(EFFECTIVE_FROM_DATE), prorateDiscountEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								prorateDiscountEntity.get(EFFECTIVE_FROM_DATE),
								prorateDiscountEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(prorateDiscountEntity.get(EFFECTIVE_FROM_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate)),
						criteriaBuilder.between(prorateDiscountEntity.get(EFFECTIVE_TO_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate))));

			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							prorateDiscountEntity.get(EFFECTIVE_FROM_DATE),
							prorateDiscountEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							prorateDiscountEntity.get(EFFECTIVE_FROM_DATE),
							prorateDiscountEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			if (OptionalUtil.isPresent(cxr)) {
				predicates.add(criteriaBuilder.equal(prorateDiscountEntity.get("cxr"), OptionalUtil.getValue(cxr)));
			}
			orderByAscByDiscounteCode(prorateDiscountEntity, criteriaQuery, criteriaBuilder, DISCOUNT_CODE);
			predicates.add(criteriaBuilder.equal(prorateDiscountEntity.get("isActive"), Boolean.TRUE));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static void orderByAsc(Root<ProrateDiscountEntity> prorateDiscountEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String cxr, String areaFBWIndicator) {
		criteriaQuery.orderBy(criteriaBuilder.asc(prorateDiscountEntity.get(cxr)),
				criteriaBuilder.asc(prorateDiscountEntity.get(areaFBWIndicator)));

	}

	public static void orderByAscByDiscounteCode(Root<ProrateDiscountEntity> prorateDiscountEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String discountCode) {
		criteriaQuery.orderBy(criteriaBuilder.asc(prorateDiscountEntity.get(discountCode)));

	}

	public static Specification<ProrateDiscountEntity> equalsDiscountCode(String discountCode) {

		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateDiscountEntity.get(DISCOUNT_CODE), discountCode);
	}

	public static Specification<ProrateDiscountEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), prorateDiscountEntity.get(EFFECTIVE_FROM_DATE),
				prorateDiscountEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<ProrateDiscountEntity> equalsClientId(String clientId) {

		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateDiscountEntity.get("clientId"), clientId);
	}

	public static Specification<ProrateDiscountEntity> equalsFbGroupCode(String fbGroupCode) {

		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateDiscountEntity.get("fbGroupCode"), fbGroupCode);
	}

	public static Specification<ProrateDiscountEntity> equalsCxr(String cxr) {

		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateDiscountEntity.get("cxr"), cxr);
	}

	public static Specification<ProrateDiscountEntity> equalsAreaFBWIndicator(String areaFBWIndicator) {

		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateDiscountEntity.get("areaFBWIndicator"), areaFBWIndicator);
	}

	public static Specification<ProrateDiscountEntity> equalsFromArea(String fromArea) {

		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateDiscountEntity.get("fromArea"), fromArea);
	}

	public static Specification<ProrateDiscountEntity> equalsToArea(String toArea) {

		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateDiscountEntity.get("toArea"), toArea);
	}

	public static Specification<ProrateDiscountEntity> notEqualsProrateDiscountId(Integer prorateDiscountId) {
		return (prorateDiscountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(prorateDiscountEntity.get("prorateDiscountId"), prorateDiscountId);
	}

}
