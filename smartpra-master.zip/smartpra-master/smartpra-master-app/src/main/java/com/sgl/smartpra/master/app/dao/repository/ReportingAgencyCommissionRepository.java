package com.sgl.smartpra.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sgl.smartpra.master.app.dao.entity.ReportingAgencyCommissionEntity;

public interface ReportingAgencyCommissionRepository extends JpaRepository<ReportingAgencyCommissionEntity, Integer>,
JpaSpecificationExecutor<ReportingAgencyCommissionEntity> {

}
