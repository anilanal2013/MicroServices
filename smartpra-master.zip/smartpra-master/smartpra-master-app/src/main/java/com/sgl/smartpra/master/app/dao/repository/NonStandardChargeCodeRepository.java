package com.sgl.smartpra.master.app.dao.repository;

/**
 * @author kanprasa
 *
 */

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCodeEntity;

@Repository
public interface NonStandardChargeCodeRepository
		extends JpaRepository<NonStandardChargeCodeEntity, Integer>, JpaSpecificationExecutor<NonStandardChargeCodeEntity> {

	@Modifying
	@Query("update NonStandardChargeCodeEntity set isActive = 'Y' where clientId = :clientId and nonStdChargeCode = :nonStdChargeCode ")
	public int activateNonStdChargeCode(@Param("clientId") String clientId, @Param("nonStdChargeCode") String nonStdChargeCode);
	
	@Modifying
	@Query("update NonStandardChargeCodeEntity set isActive = 'N' where clientId = :clientId and nonStdChargeCode = :nonStdChargeCode ")
	public int deActivateNonStdChargeCode(@Param("clientId") String clientId, @Param("nonStdChargeCode") String nonStdChargeCode);
	
	@Query(value = "select max(nonStdChargeCode) from NonStandardChargeCodeEntity where clientId = :clientId and nonStdChargeCode like :initial% ") 
	public String getMaxNonStdChargeCode(@Param("clientId") String clientId,
			@Param("initial") String initial);
	
	@Query(value = "select nonStdChargeCode from NonStandardChargeCodeEntity where clientId = :clientId "
			+ " and nonStdChargeCodeName = :nonStdChargeCodeName ") 
	public String getNonStdChargeCode(@Param("clientId") String clientId, @Param("nonStdChargeCodeName") String nonStdChargeCodeName);
	
}