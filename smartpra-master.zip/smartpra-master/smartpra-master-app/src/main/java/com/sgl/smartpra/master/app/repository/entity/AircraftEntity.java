package com.sgl.smartpra.master.app.repository.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_aircraft database table.
 * 
 */
@Entity
@Data
@Table(name = "mas_aircraft")
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class AircraftEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "aircraft_id")
	private Integer aircraftId;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "aircraft_category")
	private String aircraftCategory;

	@Column(name = "aircraft_operating_carrier")
	private String aircraftOperatingCarrier;

	@Column(name = "aircraft_owner")
	private String aircraftOwner;

	@Column(name = "aircraft_registration")
	private String aircraftRegistration;

	@Column(name = "aircraft_type")
	private String aircraftType;

	@Column(name = "business_class_capacity")
	private int businessClassCapacity;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "cost_center")
	private String costCenter;

	@Column(name = "economy_class_capacity")
	private int economyClassCapacity;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Column(name = "first_class_capacity")
	private int firstClassCapacity;

	@Column(name = "hire_date")
	private LocalDate hireDate;

	@Column(name = "iata_code_aircraft_type")
	private String iataCodeAircraftType;

	@Column(name = "icao_code_aircraft_type")
	private String icaoCodeAircraftType;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@Column(name = "manufacturer")
	private String manufacturer;

	@Column(name = "mtom")
	private Long mtom;

	@Column(name = "payload")
	private long payload;

	@Column(name = "premium_economy_class_capacity")
	private int premiumEconomyClassCapacity;

	@Column(name = "profit_center")
	private String profitCenter;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "retire_date")
	private LocalDate retireDate;

	@Column(name = "wake_category")
	private String wakeCategory;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

	public String getAircraftCategory() {
		if (aircraftCategory != null) {
			String trim = aircraftCategory.trim();
			return trim;
		}
		return aircraftCategory;
	}

	public void setAircraftCategory(String aircraftCategory) {
		if (aircraftCategory != null) {
			this.aircraftCategory = aircraftCategory.trim();
		}
		this.aircraftCategory = aircraftCategory;
	}

	public String getAircraftOperatingCarrier() {
		if (aircraftOperatingCarrier != null) {
			String trim = aircraftOperatingCarrier.trim();
			return trim;
		}
		return aircraftOperatingCarrier;
	}

	public void setAircraftOperatingCarrier(String aircraftOperatingCarrier) {
		if (aircraftOperatingCarrier != null) {
			aircraftOperatingCarrier.trim();
		}
		this.aircraftOperatingCarrier = aircraftOperatingCarrier;
	}

	public String getWakeCategory() {
		if (wakeCategory != null) {
			String trim = wakeCategory.trim();
			return trim;
		}
		return wakeCategory;
	}

	public void setWakeCategory(String wakeCategory) {
		if (wakeCategory != null) {
			wakeCategory.trim();
		}
		this.wakeCategory = wakeCategory;
	}

}
