package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "mas_spa_main_stg")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class SPAMainStgEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "spa_main_id", nullable = false, insertable = false, updatable = false)
	private Integer spaMainId;
	@Column(name = "spa_key", unique = true, nullable = false, insertable = false, updatable = false)
	private Integer spaKey;
	@Column(name = "client_id", nullable = false, length = 2)
	private String clientId;
	@Column(name = "place_of_sale", length = 4)
	private String placeOfSale;
	@Column(name = "gateway_apply", length = 1)
	private String gatewayApply;
	@Column(name = "gateway_point", length = 4)
	private String gatewayPoint;
	@Column(name = "joint_cxr_flag", length = 1)
	private String jointCxrFlag;
	@Column(name = "third_cxr_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean thirdCxrFlag;
	@Column(name = "uplift_restriction", length = 1)
	private String upliftRestriction;
	@Column(name = "transportation", length = 1)
	private String transportation;
	@Column(name = "appl_fim", length = 1)
	private String applFim;
	@Column(name = "appl_orig_reissue", length = 1)
	private String applOrigReissue;
	@Column(name = "appl_side_trip", length = 1)
	private String applSideTrip;
	@Column(name = "appl_invol", length = 1)
	private String applInvol;
	@Column(name = "invol_reroute_days")
	private Integer involRerouteDays;
	@Column(name = "appl_local", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean applLocal;
	@Column(name = "appl_schedule_changes", length = 1)
	private String applScheduleChanges;
	@Column(name = "unspecified_disc_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean unspecifiedDiscFlag;
	@Column(name = "thru_spa_flag", length = 1)
	private String thruSPAFlag;
	@Column(name = "thru_spa_diff_rbd_flag", length = 1)
	private String thruSPADiffRbdFlag;
	@Column(name = "thru_cs_noncs_cpn", length = 1)
	private String thruCsNoncsCpn;
	@Column(name = "compare_spa_check", length = 2)
	private String compareSPACheck;
	@Column(name = "mpr_check", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean mprCheck;
	@Column(name = "alliance_proration", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean allianceProration;
	@Column(name = "surcharge_id", length = 10)
	private String surchargeId;
	@Column(name = "own_surcharge_billing", length = 1)
	private String ownSurchargeBilling;
	@Column(name = "oal_surcharge_billing", length = 1)
	private String oalSurchargeBilling;
	@Column(name = "apply_yq_yr", length = 1)
	private Boolean applyYqYr;
	@Column(name = "apply_isc", length = 1)
	private Boolean applyIsc;
	@Column(name = "apply_uatp", length = 1)
	private Boolean applyUatp;
	@Column(name = "residual_ref", length = 10)
	private String residualRef;
	@Column(name = "indemnification_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean indemnificationFlag;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

	// bi-directional many-to-one association to SPARoutingStgEntity
	@OneToMany(targetEntity = SPARoutingStgEntity.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "spa_main_id", nullable = false, insertable = false, updatable = false)
	@OrderBy("routing_rec_seq_no ASC")
	private List<SPARoutingStgEntity> spaRoutingStgEntity;

	// bi-directional many-to-one association to SPASectorStgEntity
	@OneToMany(targetEntity = SPASectorStgEntity.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "spa_main_id", nullable = false, insertable = false, updatable = false)
	@OrderBy("sector_rec_seq_number ASC")
	private List<SPASectorStgEntity> spaSectorStgEntity;

	// bi-directional many-to-one association to SPAMiscDataStgEntity
	@OneToMany(targetEntity = SPAMiscDataStgEntity.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "spa_main_id", nullable = false, insertable = false, updatable = false)
	@OrderBy("record_type ASC, misc_seq_no ASC")
	private List<SPAMiscDataStgEntity> spaMiscDataStgEntity;

}
