package com.sgl.smartpra.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.InterlineServiceChargeEntity;

@Repository
public interface InterlineServiceChargeRepository extends JpaRepository<InterlineServiceChargeEntity, Integer>,
		JpaSpecificationExecutor<InterlineServiceChargeEntity> {

//	@Query(value = "select count(*) from InterlineServiceChargeEntity d where"
//			+ " ((?1 between d.effectiveFromDate and d.effectiveToDate) or "
//			+ "(?2 between d.effectiveFromDate and d.effectiveToDate)) and d.isActive = 1")
//	int verifyIfOverlapExits(Date effectiveFromDate, Date effectiveToDate);

//	@Query(value = "select a from InterlineServiceChargeEntity a  where (:effectiveDate between a.effectiveFromDate  AND a.effectiveToDate) AND a.isActive = 1")
//	public List<InterlineServiceChargeEntity> getAllInterlineCharges(@Param("effectiveDate") Date effectiveDate);
}	