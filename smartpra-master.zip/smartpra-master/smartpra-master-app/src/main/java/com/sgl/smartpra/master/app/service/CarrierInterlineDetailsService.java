package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;

import com.sgl.smartpra.master.enums.SettlementMethod;
import com.sgl.smartpra.master.model.CarrierInterlineDetailsModel;

public interface CarrierInterlineDetailsService {
	
	public boolean isValidPassengerSis(Optional<String> carrierCode, Optional<Boolean> passengerSis,Optional<String> effectiveDate);
	
	public List<CarrierInterlineDetailsModel> getListOfCarrierInterlineDetailsByEffectiveDate(Optional<String> carrierCode, Optional<String> clientId, Optional<String> effectiveDate);
	
	public CarrierInterlineDetailsModel getCarrierInterlineByCarrierInterlineDtlId(Optional<String> carrierCode, Integer carrierInterlineDtlId);
	
	public CarrierInterlineDetailsModel createCarrierInterlineDetail(String carrierCode, CarrierInterlineDetailsModel carrierInterlineDetailsModel);
	
	public CarrierInterlineDetailsModel updateCarrierInterlineDetail(String carrierCode, int carrierInterlineDtlId, CarrierInterlineDetailsModel carrierInterlineModel);
	
	public void deactivateCarrierInterlineDetail(String carrierCode, int carrierInterlineDtlId, String lastUpdatedBy);
				
	public void activateCarrierInterlineDetail(String carrierCode, int carrierInterlineDtlId, String lastUpdatedBy);

	public CarrierInterlineDetailsModel getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(
			Optional<String> carrierCode, Optional<String> effectiveDate);

	public List<CarrierInterlineDetailsModel> getCarrierInterlineDetailsByZoneAndEffectiveDate(
			Optional<String> clientId, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> zone);
	
	SettlementMethod getSettlementMethod(Optional<String> billingCarrierCode, Optional<String> billedCarriedCode,
			Optional<String> currentBillingDate);

}
