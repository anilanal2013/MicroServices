package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.repository.entity.AircraftEntity;

public class AircraftEntitySpecificaton {

	public static Specification<AircraftEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (aircraftEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), aircraftEntity.get("effectiveFromDate"),
				aircraftEntity.get("effectiveToDate"));
	}

	public static Specification<AircraftEntity> isActive() {
		return (aircraftEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(aircraftEntity.get("activate"),
				true);
	}

	public static Specification<AircraftEntity> equalsClientId(String clientId) {
		return (aircraftEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(aircraftEntity.get("clientId"),
				clientId);
	}

	public static Specification<AircraftEntity> equalsAircraftRegistration(String aircraftRegistration) {
		return (aircraftEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(aircraftEntity.get("aircraftRegistration"), aircraftRegistration);
	}

	public static Specification<AircraftEntity> notEqualsAircraftId(Integer aircraftId) {
		return (aircraftEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(aircraftEntity.get("aircraftId"), aircraftId);
	}

	public static Specification<AircraftEntity> search(Optional<String> clientId, Optional<String> aircraftRegistration,
			Optional<String> aircraftType, Boolean activate, Optional<String> exceptionCall) {
		return (aircraftEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(aircraftRegistration)) {
				predicates.add(criteriaBuilder.like(aircraftEntity.get("aircraftRegistration"),
						OptionalUtil.getValue(aircraftRegistration) + "%"));
			}
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(aircraftEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(aircraftType)) {
				predicates.add(criteriaBuilder.like(aircraftEntity.get("aircraftType"),
						OptionalUtil.getValue(aircraftType) + "%"));
			}

			if (!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (activate != null) {
					predicates.add(criteriaBuilder.equal(aircraftEntity.get("activate"), activate));
				}
				if (activate == null) {
					predicates.add(criteriaBuilder.equal(aircraftEntity.get("activate"), true));
				}
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AircraftEntity> getAllAircraftDetails(Integer firstClassCapacity,
			Integer businessClassCapacity, Integer premiumEconomyClassCapacity, Integer economyClassCapacity) {
		return (aircraftEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (firstClassCapacity != null) {
				predicates.add(criteriaBuilder.equal(aircraftEntity.get("firstClassCapacity"), firstClassCapacity));
			}
			if (businessClassCapacity != null) {
				predicates
						.add(criteriaBuilder.equal(aircraftEntity.get("businessClassCapacity"), businessClassCapacity));
			}
			if (premiumEconomyClassCapacity != null) {
				predicates.add(criteriaBuilder.equal(aircraftEntity.get("premiumEconomyClassCapacity"),
						premiumEconomyClassCapacity));
			}
			if (economyClassCapacity != null) {
				predicates.add(criteriaBuilder.equal(aircraftEntity.get("economyClassCapacity"), economyClassCapacity));
			}

			predicates.add(criteriaBuilder.equal(aircraftEntity.get("activate"), true));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
