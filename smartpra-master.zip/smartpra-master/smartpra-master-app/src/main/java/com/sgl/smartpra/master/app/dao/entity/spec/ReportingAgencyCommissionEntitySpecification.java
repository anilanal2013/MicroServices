package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.ReportingAgencyCommissionEntity;

public class ReportingAgencyCommissionEntitySpecification {
	public static Specification<ReportingAgencyCommissionEntity> equalsClientId(String clientId) {
		return (reportingAgencyCommissionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(reportingAgencyCommissionEntity.get("clientId"), clientId);
	}

	public static Specification<ReportingAgencyCommissionEntity> equalsAgencyCode(String agencyCode) {
		return (reportingAgencyCommissionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(reportingAgencyCommissionEntity.get("agencyCode"), agencyCode);
	}

	public static Specification<ReportingAgencyCommissionEntity> equalsReportingAgency(String reportingAgency) {
		return (reportingAgencyCommissionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(reportingAgencyCommissionEntity.get("reportingAgency"), reportingAgency);
	}

	public static Specification<ReportingAgencyCommissionEntity> equalsORCCurrency(String orcCurrency) {
		return (reportingAgencyCommissionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(reportingAgencyCommissionEntity.get("orcCurrency"), orcCurrency);
	}

	public static Specification<ReportingAgencyCommissionEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (reportingAgencyCommissionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), reportingAgencyCommissionEntity.get("effectiveFromDate"),
				reportingAgencyCommissionEntity.get("effectiveToDate"));
	}

	public static Specification<ReportingAgencyCommissionEntity> notEqualsReportingAgencyCommId(
			Integer reportingAgencyCommId) {
		return (reportingAgencyCommissionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(reportingAgencyCommissionEntity.get("reportingAgencyCommId"), reportingAgencyCommId);
	}

	public static Specification<ReportingAgencyCommissionEntity> search(Optional<String> agencyCode,
			Optional<String> reportingAgency, Optional<Boolean> activate) {
		return (reportingAgencyCommissionEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(agencyCode)) {
				predicates.add(criteriaBuilder.like(reportingAgencyCommissionEntity.get("agencyCode"),
						OptionalUtil.getValue(agencyCode) + "%"));
			}
			if (OptionalUtil.isPresent(reportingAgency)) {
				predicates.add(criteriaBuilder.like(reportingAgencyCommissionEntity.get("reportingAgency"),
						OptionalUtil.getValue(reportingAgency) + "%"));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(reportingAgencyCommissionEntity.get("activate"),
						OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(reportingAgencyCommissionEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static void orderByAsc(Root<ReportingAgencyCommissionEntity> reportingAgencyCommissionEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(reportingAgencyCommissionEntity.get(orderByString)));
	}

	public static Specification<ReportingAgencyCommissionEntity> searchReportingAgencyCommissionByAgencyId(
			Integer agencyId, Optional<String> agencyCode, Optional<String> reportingAgency,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> orcCurrency,
			Optional<Boolean> activate) {
		return (reportingAgencyCommissionEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (agencyId != null) {
				predicates.add(criteriaBuilder.equal(reportingAgencyCommissionEntity.get("agencyId"), agencyId));
			}
			if (OptionalUtil.isPresent(agencyCode)) {
				predicates.add(criteriaBuilder.equal(reportingAgencyCommissionEntity.get("agencyCode"),
						OptionalUtil.getValue(agencyCode)));
			}
			if (OptionalUtil.isPresent(reportingAgency)) {
				predicates.add(criteriaBuilder.equal(reportingAgencyCommissionEntity.get("reportingAgency"),
						OptionalUtil.getValue(reportingAgency)));
			}
			if (OptionalUtil.isPresent(orcCurrency)) {
				predicates.add(criteriaBuilder.equal(reportingAgencyCommissionEntity.get("orcCurrency"),
						OptionalUtil.getValue(orcCurrency)));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								reportingAgencyCommissionEntity.get("effectiveFromDate"),
								reportingAgencyCommissionEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								reportingAgencyCommissionEntity.get("effectiveFromDate"),
								reportingAgencyCommissionEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							reportingAgencyCommissionEntity.get("effectiveFromDate"),
							reportingAgencyCommissionEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							reportingAgencyCommissionEntity.get("effectiveFromDate"),
							reportingAgencyCommissionEntity.get("effectiveToDate")));
				}
			}

			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(reportingAgencyCommissionEntity.get("activate"),
						OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(reportingAgencyCommissionEntity.get("activate"), true));
			}

			orderByAsc(reportingAgencyCommissionEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
