package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.model.Currency;
import com.sgl.smartpra.master.app.dao.RegionDao;
import com.sgl.smartpra.master.app.dao.entity.RegionEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.RegionEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.RegionRepository;
import com.sgl.smartpra.master.model.Region;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RegionDaoImpl extends CommonSearchDao<Currency> implements RegionDao {

	@Autowired
	private RegionRepository regionRepository;

	@Override
	@Cacheable(value = "region", key = "#id")
	public Optional<RegionEntity> findById(Integer id) {
		log.info("Cacheable Region Entity's ID= {}", id);
		return regionRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "region", key = "#regionEntity.regionCode") })
	public RegionEntity create(RegionEntity regionEntity) {
		return regionRepository.save(regionEntity);
	}

	@Override
	@CachePut(value = "region", key = "#regionEntity.regionCode")
	public RegionEntity update(RegionEntity regionEntity) {
		return regionRepository.save(regionEntity);
	}

	@Override
	public List<RegionEntity> getAllRegion(Region region, Optional<String> exceptionCall) {
		return regionRepository.findAll(RegionEntitySpecification.search(region, exceptionCall));
	}

	@Override
	public List<RegionEntity> findAllRegionList() {
		return regionRepository.findAll();
	}

	@Override
	public List<RegionEntity> findAllRegionListForUpdate(Integer regionId, Boolean Active) {
		return regionRepository.findAll(Specification.where(
				RegionEntitySpecification.isActive(Active).and(RegionEntitySpecification.notEqualsRegionId(regionId))));
	}

	@Override
	public long getOverLapRecordCount(Optional<String> regionCode, Optional<String> clientId) {
		return regionRepository
				.count(Specification.where(RegionEntitySpecification.equalsClientId(OptionalUtil.getValue(clientId))
						.and(RegionEntitySpecification.equalsRegionCode(OptionalUtil.getValue(regionCode)))));
	}

	@Override
	public long getOverLapRecordCount(String regionCode, String clientId, Integer id) {
		return regionRepository.count(Specification.where(RegionEntitySpecification.equalsClientId(clientId)
				.and(RegionEntitySpecification.equalsRegionCode(regionCode))
				.and(RegionEntitySpecification.notEqualsRegionId(id))));
	}

	@Override
	public List<RegionEntity> getAllRegion(Optional<String> regionCode, Optional<String> regionName,
			Optional<String> continentName, Optional<Boolean> isActive) {

		Region region = new Region();
		region.setRegionCode(regionCode);
		region.setRegionName(regionName);
		region.setContinentName(continentName);
		region.setIsActive(OptionalUtil.getValue(isActive));

		return regionRepository.findAll(RegionEntitySpecification.search(region, Optional.of("")));
	}
}
