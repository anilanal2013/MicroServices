package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.ProrateDiscountEntity;

@Repository
public interface ProrateDiscountDao {
	List<ProrateDiscountEntity> getProrateDiscountByEffectiveDate(String discountCode, Optional<String> effectiveDate);

	ProrateDiscountEntity create(ProrateDiscountEntity prorateDiscountEntity);

	Optional<ProrateDiscountEntity> findById(Integer prorateDiscountId);

	int verifyIfOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	public long getOverlapRecordCount(String discountCode, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String clientId, String fbGroupCode, String cxr, String areaFBWIndicator, String fromArea, String toArea);

	ProrateDiscountEntity update(ProrateDiscountEntity prorateDiscountEntity);

	List<ProrateDiscountEntity> getProrateDiscountByEffectiveDateDiscountType(String discountCode,
			LocalDate effectiveDate, String discountType, String clientId);

	List<ProrateDiscountEntity> searchProrateDiscount(String discountCode, String discountType,
			Optional<String> fbGroupCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> cxr);

	public long getOverlapRecordCount(String discountCode, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String clientId, String fbGroupCode, String cxr, String areaFBWIndicator, String fromArea, String toArea,
			Integer prorateDiscountId);

}
