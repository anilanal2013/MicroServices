package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_stock_detail")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class StcokDetails extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "stock_dtl_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer stackDetId;

	@Column(name = "stock_id")
	private Integer stockId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "document_number")
	private String documentNumber;
	
	@Column(name = "document_type", nullable = false, length = 3)
	private String documentType;

	@Column(name = "effective_from_date")
	private LocalDate effectiveDate;

	@Column(name = "effective_to_date")
	private LocalDate expiryDate;

	@Column(name = "agent_code")
	private String agentCode;

	@Column(name = "blacklist_reason_code")
	private String blockListReason;

	@Column(name = "is_utilized")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isUtilized;

	@Column(name = "utilized_date")
	private Date utilizedDate;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean isActive;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
