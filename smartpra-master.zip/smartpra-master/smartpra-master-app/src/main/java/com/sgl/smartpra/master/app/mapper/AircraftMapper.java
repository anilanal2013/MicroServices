package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.repository.entity.AircraftEntity;
import com.sgl.smartpra.master.model.Aircraft;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AircraftMapper extends BaseMapper<Aircraft, AircraftEntity> {

	@Mapping(source = "aircraftId", target = "aircraftId", ignore = true)
	AircraftEntity mapToEntity(Aircraft aircraft, @MappingTarget AircraftEntity aircraftEntity);

	@Mapping(source = "aircraftId", target = "aircraftId", ignore = true)
	AircraftEntity mapToEntity(Aircraft aircraft);

}
