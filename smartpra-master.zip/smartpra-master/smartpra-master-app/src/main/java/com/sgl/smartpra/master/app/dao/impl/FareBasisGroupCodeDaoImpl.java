package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.FareBasisGroupcodeDao;
import com.sgl.smartpra.master.app.dao.entity.FareBasisGroupcodeEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.FareBasisGroupCodeEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.FareBasisGroupcodeRepository;
import com.sgl.smartpra.master.app.mapper.FareBasisGroupcodeMapper;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FareBasisGroupCodeDaoImpl implements FareBasisGroupcodeDao {
	
	@Autowired
	FareBasisGroupcodeRepository fareBasisGroupcodeRepository;
	
	@Autowired
	FareBasisGroupcodeMapper fareBasisGroupcodeMapper;
	
	@Override
	@Cacheable(value = "fareBasisGroupCode", key = "#id")
	public Optional<FareBasisGroupcodeEntity> findById(Integer id) {
		log.info("Cacheable FareBasis Group code Entity's ID= {}", id);
		return fareBasisGroupcodeRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fareBasisGroupCode", key = "#fareBasisGroupcodeEntity.fbGroupId") })
	public FareBasisGroupcodeEntity create(FareBasisGroupcodeEntity fareBasisGroupcodeEntity) {
		return fareBasisGroupcodeRepository.save(fareBasisGroupcodeEntity);
	}

	@Override
	@CachePut(value = "fareBasisGroupCode", key = "#fareBasisGroupcodeEntity.fbGroupId")
	public FareBasisGroupcodeEntity update(FareBasisGroupcodeEntity fareBasisGroupcodeEntity) {
		return fareBasisGroupcodeRepository.save(fareBasisGroupcodeEntity);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fareBasisGroupCode", key = "#id") })
	public void delete(Integer id) {
		fareBasisGroupcodeRepository.deleteById(id);
	}

	@Override
	public List<FareBasisGroupcodeEntity> searchFareBasisGroupcode(FareBasisGroupcodeEntity fareBasisGroupcodeEntity) {
		return fareBasisGroupcodeRepository.findAll(Specification.where(
				(FareBasisGroupCodeEntitySpecification.isATPCOFareTypeNull().or(FareBasisGroupCodeEntitySpecification.equalATPCOFareType(fareBasisGroupcodeEntity.getAtpcoFareType())))
				.and(FareBasisGroupCodeEntitySpecification.isBTITIndicatorNull().or(FareBasisGroupCodeEntitySpecification.equalBTITIndicator(fareBasisGroupcodeEntity.getBtItIndicator())))
				.and(FareBasisGroupCodeEntitySpecification.isCabinNull().or(FareBasisGroupCodeEntitySpecification.equalCabin(fareBasisGroupcodeEntity.getCabin())))
				.and(FareBasisGroupCodeEntitySpecification.isDOWNull().or(FareBasisGroupCodeEntitySpecification.equalDOW(fareBasisGroupcodeEntity.getDayOfWeek())))
				.and(FareBasisGroupCodeEntitySpecification.isDiscountCodeNull().or(FareBasisGroupCodeEntitySpecification.equalDiscountCode(fareBasisGroupcodeEntity.getDiscountCode())))
				.and(FareBasisGroupCodeEntitySpecification.isFareOwnerCXRNull().or(FareBasisGroupCodeEntitySpecification.equalFareOwnerCXR(fareBasisGroupcodeEntity.getFareOwnerCXR())))
				.and(FareBasisGroupCodeEntitySpecification.isFareTextNull().or(FareBasisGroupCodeEntitySpecification.equalFareText(fareBasisGroupcodeEntity.getFareText())))
				.and(FareBasisGroupCodeEntitySpecification.isIATAFareTypeNull().or(FareBasisGroupCodeEntitySpecification.equalIATAFareType(fareBasisGroupcodeEntity.getIataFareType())))
				.and(FareBasisGroupCodeEntitySpecification.isIsPatternNull().or(FareBasisGroupCodeEntitySpecification.equalIsPattern(fareBasisGroupcodeEntity.getIsPattern())))
				.and(FareBasisGroupCodeEntitySpecification.isIssueCXRNull().or(FareBasisGroupCodeEntitySpecification.equalIssueCXR(fareBasisGroupcodeEntity.getIssueCXR())))
				.and(FareBasisGroupCodeEntitySpecification.isJourneyTypeNull().or(FareBasisGroupCodeEntitySpecification.equalJourneyType(fareBasisGroupcodeEntity.getJourneyType())))
				.and(FareBasisGroupCodeEntitySpecification.isNormalSpecialNull().or(FareBasisGroupCodeEntitySpecification.equalNormalSpecial(fareBasisGroupcodeEntity.getNormalSpecial())))
				.and(FareBasisGroupCodeEntitySpecification.isNonRevenueFlagNull().or(FareBasisGroupCodeEntitySpecification.equalNonRevenueFlag(fareBasisGroupcodeEntity.getNonRevenueFlag())))
				.and(FareBasisGroupCodeEntitySpecification.isPassengerNameNull().or(FareBasisGroupCodeEntitySpecification.equalPassengerName(fareBasisGroupcodeEntity.getPassengerName())))
				.and(FareBasisGroupCodeEntitySpecification.isPaxTypeNull().or(FareBasisGroupCodeEntitySpecification.equalPaxType(fareBasisGroupcodeEntity.getPaxType())))
				.and(FareBasisGroupCodeEntitySpecification.isSeasonalCodeNull().or(FareBasisGroupCodeEntitySpecification.equalSeasonalCode(fareBasisGroupcodeEntity.getSeasonalCode())))
				.and(FareBasisGroupCodeEntitySpecification.isTicketedFareBasisNull().or(FareBasisGroupCodeEntitySpecification.equalTicketedFareBasis(fareBasisGroupcodeEntity.getTicketedFareBasis())))
				.and(FareBasisGroupCodeEntitySpecification.isTicketedTDNull().or(FareBasisGroupCodeEntitySpecification.equalTicketedTD(fareBasisGroupcodeEntity.getTicketedTD())))
				.and(FareBasisGroupCodeEntitySpecification.isUnPublishFlagNull().or(FareBasisGroupCodeEntitySpecification.equalUnPublishFlag(fareBasisGroupcodeEntity.getUnpublishFlag())))
				.and(FareBasisGroupCodeEntitySpecification.isZedIdentifierNull().or(FareBasisGroupCodeEntitySpecification.equalZedIdentifier(fareBasisGroupcodeEntity.getZedIdentifier())))
				.and(
					FareBasisGroupCodeEntitySpecification.isATPCOFareTypeNotNull()
					.or(FareBasisGroupCodeEntitySpecification.isBTITIndicatorNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isCabinNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isDOWNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isDiscountCodeNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isFareOwnerCXRNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isFareTextNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isIATAFareTypeNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isIssueCXRNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isJourneyTypeNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isNormalSpecialNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isNonRevenueFlagNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isPassengerNameNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isPaxTypeNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isSeasonalCodeNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isTicketedFareBasisNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isTicketedTDNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isUnPublishFlagNotNull())
					.or(FareBasisGroupCodeEntitySpecification.isZedIdentifierNotNull())
					)
				.and(FareBasisGroupCodeEntitySpecification.isActive())
				));
	}

	@Override
	public int getExistingRecord(String fbGroupCode, String clientId) {
		return (int) fareBasisGroupcodeRepository.count(Specification.where(FareBasisGroupCodeEntitySpecification.equalsFBGroupCode(fbGroupCode)
				.and(FareBasisGroupCodeEntitySpecification.equalsClientId(clientId))));
	}
	

	@Override
	public int getExistingRecord(String fbGroupCode) {
		return (int) fareBasisGroupcodeRepository.count(Specification.where(FareBasisGroupCodeEntitySpecification.equalsFBGroupCode(fbGroupCode)
				.and(FareBasisGroupCodeEntitySpecification.equalsClientId(null))));
	}

	@Override
	public List<FareBasisGroupcodeEntity> findByFbGroupCode(String fbgroupcode) {
		return fareBasisGroupcodeRepository.findAll(Specification.where(FareBasisGroupCodeEntitySpecification.equalsFBGroupCode(fbgroupcode)));
	}

	@Override
	public List<FareBasisGroupcodeEntity> getAllFareBasisGroupcode() {
		return fareBasisGroupcodeRepository.findAll(Specification.where(FareBasisGroupCodeEntitySpecification.getActiveFBGroupCode()));
	}

	@Override
	public List<FareBasisGroupcodeEntity> checkUniqueRecord(String fbGroupCode, String clientId,
			Integer seqLineNumber) {
		return fareBasisGroupcodeRepository.findAll(Specification.where(FareBasisGroupCodeEntitySpecification.isActive()
				.and(FareBasisGroupCodeEntitySpecification.equalsFBGroupCode(fbGroupCode))
				.and(FareBasisGroupCodeEntitySpecification.equalsClientId(clientId))
				.and(FareBasisGroupCodeEntitySpecification.equalsSeqLineNumber(seqLineNumber))));
	}

	@Override
	public List<FareBasisGroupcodeEntity> getFBTByIsPattern() {
		return fareBasisGroupcodeRepository.findAll(Specification.where(FareBasisGroupCodeEntitySpecification.equalIsPattern(Boolean.TRUE))
				.and(FareBasisGroupCodeEntitySpecification.isActive()));
	}

	@Override
	public List<FareBasisGroupcodeEntity> search(Optional<String> fbGroupCode, Optional<String> fbDescription,
			Optional<Boolean> isActive) {
		return fareBasisGroupcodeRepository.findAll(Specification.where(FareBasisGroupCodeEntitySpecification.
				search(fbGroupCode, fbDescription, isActive)));
	}

	
	


}
