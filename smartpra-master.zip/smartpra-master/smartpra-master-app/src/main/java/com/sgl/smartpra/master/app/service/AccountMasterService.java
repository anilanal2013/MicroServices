package com.sgl.smartpra.master.app.service;

import java.util.List;

import com.sgl.smartpra.master.model.MasAccountModel;

public interface AccountMasterService {

	List<MasAccountModel> getListOfAccountMasters();

	List<MasAccountModel> getListOfAccountMastersByAccountAlphaCode(String string);

}
