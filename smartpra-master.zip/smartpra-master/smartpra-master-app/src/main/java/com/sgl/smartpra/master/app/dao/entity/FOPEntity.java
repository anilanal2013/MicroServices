package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_fop")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class FOPEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fop_id")
	private Integer fopId;

	@Column(name = "client_id", nullable = false)
	@NotEmpty
	private String clientId;

	@Column(name = "control_id", nullable = false)
	@NotEmpty
	private String controlId;

	@Column(name = "fop_code", nullable = false)
	@NotEmpty
	private String fopCode;

	@Column(name = "fop_description", nullable = true)
	private String fopDescription;

	@Column(name = "fop_identifier", nullable = false)
	@NotEmpty
	private String fopIdentifier;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "negative_fop_flag", nullable = false)
	@NotEmpty
	private String negativeFopFlag;

	@Column(name = "transaction_type", nullable = true)
	private String transactionType;

	@Column(name = "profit_centre")
	private String profitCenter;

	@Column(name = "cost_centre")
	private String costCenter;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@Column(name = "attribute_3")
	private String attribute3;

	@Column(name = "attribute_4")
	private String attribute4;

	@Column(name = "attribute_5")
	private String attribute5;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		if (transactionType != null) {
			transactionType.trim();
		}
		this.transactionType = transactionType;
	}
}
