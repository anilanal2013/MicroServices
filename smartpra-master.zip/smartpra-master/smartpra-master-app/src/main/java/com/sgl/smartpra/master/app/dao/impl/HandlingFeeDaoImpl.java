package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.HandlingFeeDao;
import com.sgl.smartpra.master.app.dao.entity.HandlingFeeEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.HandlingFeeEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.HandlingFeeRepository;

@Component
public class HandlingFeeDaoImpl implements HandlingFeeDao {

	@Autowired
	private HandlingFeeRepository handlingFeeRepository;

	@Override
	public List<HandlingFeeEntity> getAllHandlingFee(Optional<String> issueCxr, Optional<String> operatingCxr,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return handlingFeeRepository.findAll(
				HandlingFeeEntitySpecification.search(issueCxr, operatingCxr, effectiveFromDate, effectiveToDate));
	}

	@Override
	@Cacheable(value = "handlingFee", key = "#id")
	public Optional<HandlingFeeEntity> findById(Integer id) {
		return handlingFeeRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "handlingFee", key = "#handlingFeeEntity.handlingFeeId") })
	public HandlingFeeEntity createHandlingFee(HandlingFeeEntity handlingFeeEntity) {
		return handlingFeeRepository.save(handlingFeeEntity);
	}

	@Override
	@CachePut(value = "handlingFee", key = "#handlingFeeEntity.handlingFeeId")
	public HandlingFeeEntity updateHandlingFee(HandlingFeeEntity handlingFeeEntity) {
		return handlingFeeRepository.save(handlingFeeEntity);
	}

	@Override
	public long getOverLapForCreate(Optional<String> clientId, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> salesSource, Optional<String> issueCxr,
			Optional<String> operatingCxr, Optional<String> couponFromArea, Optional<String> couponToArea) {
		return handlingFeeRepository.count(HandlingFeeEntitySpecification
				.equalsClientId(OptionalUtil.getValue(clientId))
				.and(HandlingFeeEntitySpecification.equalsSalesSource(OptionalUtil.getValue(salesSource)))
				.and(HandlingFeeEntitySpecification.equalsIssueCxr(OptionalUtil.getValue(issueCxr)))
				.and(HandlingFeeEntitySpecification.equalsOperatingCxr(OptionalUtil.getValue(operatingCxr)))
				.and(HandlingFeeEntitySpecification.equalsCouponFromArea(OptionalUtil.getValue(couponFromArea)))
				.and(HandlingFeeEntitySpecification.equalsCouponToArea(OptionalUtil.getValue(couponToArea)))
				.and((HandlingFeeEntitySpecification
						.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate))
						.or(HandlingFeeEntitySpecification.betweenEffectiveFromAndEffectiveToDate(
								OptionalUtil.getLocalDateValue(effectiveToDate))))
										.or(HandlingFeeEntitySpecification
												.greaterThanOrEqualTo(OptionalUtil.getLocalDateValue(effectiveFromDate))
												.and(HandlingFeeEntitySpecification.lessThanOrEqualTo(
														OptionalUtil.getLocalDateValue(effectiveToDate))))));

	}

	@Override
	public long getOverLapForUpdate(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String salesSource, String issueCxr, String operatingCxr, String couponFromArea, String couponToArea,
			Integer handlingFeeId) {
		return handlingFeeRepository.count(HandlingFeeEntitySpecification.equalsClientId(clientId)
				.and(HandlingFeeEntitySpecification.equalsSalesSource(salesSource))
				.and(HandlingFeeEntitySpecification.equalsIssueCxr(issueCxr))
				.and(HandlingFeeEntitySpecification.equalsOperatingCxr(operatingCxr))
				.and(HandlingFeeEntitySpecification.equalsCouponFromArea(couponFromArea))
				.and(HandlingFeeEntitySpecification.equalsCouponToArea(couponToArea))
				.and((HandlingFeeEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(HandlingFeeEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
								.or(HandlingFeeEntitySpecification.greaterThanOrEqualTo(effectiveFromDate)
										.and(HandlingFeeEntitySpecification.lessThanOrEqualTo(effectiveToDate))))
				.and(HandlingFeeEntitySpecification.notEqualsHandlingFeeId(handlingFeeId)));

	}

}
