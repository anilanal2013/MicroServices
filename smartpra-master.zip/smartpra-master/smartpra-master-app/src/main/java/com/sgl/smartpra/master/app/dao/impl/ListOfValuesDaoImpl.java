package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.ListOfValuesDao;
import com.sgl.smartpra.master.app.dao.entity.ListOfValuesEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.ListOfValuesEntitySpec;
import com.sgl.smartpra.master.app.dao.repository.ListOfValuesRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ListOfValuesDaoImpl implements ListOfValuesDao {

	@Autowired
	private ListOfValuesRepository listOfValuesRepository;
	

	@Override
	@Cacheable(value = "listOfValues", key = "#lovId")
	public Optional<ListOfValuesEntity> findById(Integer lovId) {
		log.info("Cacheable ListOfValuesEntity's ID= {}", lovId);
		return listOfValuesRepository.findById(lovId);
	}
	
	@Override
	@Caching(evict = { @CacheEvict(value = "listOfValues", key = "#listOfValuesEntity.lovId"),
			@CacheEvict(value = "clientId" ,allEntries = true),@CacheEvict(value = "tableName",allEntries = true),
			@CacheEvict(value = "columnName" ,allEntries = true),@CacheEvict(value = "fieldValue",allEntries = true)})
	public ListOfValuesEntity create(ListOfValuesEntity listOfValuesEntity) {
		return listOfValuesRepository.save(listOfValuesEntity);
	}

	@Override
	@CachePut(value = "listOfValues", key = "#listOfValuesEntity.lovId")
	@Caching(evict = { @CacheEvict(value = "clientId" ,allEntries = true),@CacheEvict(value = "tableName",allEntries = true),
			@CacheEvict(value = "columnName" ,allEntries = true),@CacheEvict(value = "fieldValue",allEntries = true)})
	public ListOfValuesEntity update(ListOfValuesEntity listOfValuesEntity) {
		return listOfValuesRepository.save(listOfValuesEntity);
	}

	@Override
	@Cacheable(cacheNames={"clientId","tableName","columnName","fieldValue"})
	public ListOfValuesEntity fetchListOfValues(Optional<String> clientId, Optional<String> tableName,
			Optional<String> columnName, Optional<String> fieldValue) {
		return listOfValuesRepository.findOne(ListOfValuesEntitySpec.fetchListOfValues(clientId, tableName, columnName, fieldValue))
				.orElse(new ListOfValuesEntity());
	}

	@Override
	@Cacheable(cacheNames={"clientId","tableName","columnName"})
	public List<ListOfValuesEntity> fetchListOfValuesList(Optional<String> clientId, Optional<String> tableName,
			Optional<String> columnName) {
		return listOfValuesRepository.findAll(ListOfValuesEntitySpec.fetchListOfValuesList(clientId, tableName, columnName));
	}

	@Override
	@Cacheable(cacheNames={"clientId","tableName","columnName"})
	public List<String> fetchListOfValue(String clientId, String tableName,
			String columnName) {
		return listOfValuesRepository.getListOfFieldValues(clientId, tableName, columnName);
	}
}
