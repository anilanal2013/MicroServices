package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.CurrencyToleranceDetailsDao;
import com.sgl.smartpra.master.app.dao.entity.CurrencyToleranceDetailsEntity;
import com.sgl.smartpra.master.app.mapper.CurrencyToleranceDetailsMapper;
import com.sgl.smartpra.master.app.service.CurrencyToleranceDetailsService;
import com.sgl.smartpra.master.model.CurrencyToleranceDetails;

@Service
@Transactional
public class CurrencyToleranceDetailsServiceImpl implements CurrencyToleranceDetailsService {

	@Autowired
	private CurrencyToleranceDetailsDao currencyToleranceDao;

	@Autowired
	private CurrencyToleranceDetailsMapper currencyToleranceMapper;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	public static final String REGEX_PATTERN = "^[0-9]{1,13}(\\.[0-9]{0,3})?$";
	public static final String PERCENTAGE_REGEX_PATTERN = "^[0-9]{1,3}(\\.[0-9]{0,3})?$";
	public static final String OVER_LAP_CHECKING = "Record already exists";

	@Override
	public CurrencyToleranceDetails createCurrencyTolerance(String currencyCode,
			CurrencyToleranceDetails currencyToleranceDetails) {

		if (!globalMasterFeignClient.validateCurrencyCode(currencyCode)) {
			throw new BusinessException("Invalid Currency Code " + currencyCode);
		}
		currencyToleranceDetails.setCurrencyCode(Optional.of(currencyCode));
		validateBusinessConstrianrsForCreate(currencyToleranceDetails);

		return currencyToleranceMapper.mapToModel(currencyToleranceDao
				.createCurrencyTolerance(currencyToleranceMapper.mapToEntity(currencyToleranceDetails)));
	}

	@Override
	public CurrencyToleranceDetails updateCurrencyTolerance(String currencyCode, Integer currencyToleranceDtlId,
			CurrencyToleranceDetails currencyToleranceDetails) {
		CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity = currencyToleranceDao
				.findById(currencyToleranceDtlId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(currencyToleranceDtlId)));

		if (!globalMasterFeignClient.validateCurrencyCode(currencyCode)) {
			throw new BusinessException("Invalid Currency Code " + currencyCode);
		}
		currencyToleranceDetails.setCurrencyCode(Optional.of(currencyCode));
		validateBusinessConstrintsForUpdate(currencyToleranceDetails, currencyToleranceDetailsEntity);

		return currencyToleranceMapper.mapToModel(currencyToleranceDao.updateCurrencyTolerance(
				currencyToleranceMapper.mapToEntity(currencyToleranceDetails, currencyToleranceDetailsEntity)));
	}

	@Override
	public CurrencyToleranceDetails getCurrencyToleranceById(Integer currencyToleranceDtlId) {
		return currencyToleranceMapper.mapToModel(currencyToleranceDao.findById(currencyToleranceDtlId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(currencyToleranceDtlId))));
	}

	@Override
	public List<CurrencyToleranceDetails> getListOfCurrencyTolerance(String currencyCode, String clientId,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return currencyToleranceMapper.mapToModel(
				currencyToleranceDao.getListOfCurrencyTolerance(currencyCode, clientId, effectiveFromDate, effectiveToDate));
	}
	

	@Override
	public CurrencyToleranceDetails getCurrencyToleranceByDate(String currencyCode, String clientId,
			Optional<String> effectiveFromDate) {
		return currencyToleranceMapper.mapToModel(
				currencyToleranceDao.getCurrencyToleranceByDate(currencyCode, clientId, effectiveFromDate));
	}

	private void validateBusinessConstrianrsForCreate(CurrencyToleranceDetails currencyToleranceDetails) {
		clientIdToCarrierDesignatorValidation(currencyToleranceDetails);
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(currencyToleranceDetails.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(currencyToleranceDetails.getEffectiveToDate()));
		validatePositiveValues(currencyToleranceDetails);
		validateOverLapForCreate(currencyToleranceDetails);
	}

	private void validateBusinessConstrintsForUpdate(CurrencyToleranceDetails currencyToleranceDetails,
			CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity) {
		validateOverLapForUpdate(currencyToleranceDetails, currencyToleranceDetailsEntity);
		validateEffectiveToDate(currencyToleranceDetails, currencyToleranceDetailsEntity);
		clientIdToCarrierDesignatorValidation(currencyToleranceDetails);
		validatePositiveValues(currencyToleranceDetails);
	}

	private void validatePositiveValues(CurrencyToleranceDetails currencyToleranceDetails) {
		validateMinimunValue(currencyToleranceDetails.getMinimumValue());
		validateGrossAcceptableVarianceAmt(currencyToleranceDetails.getGrossAcceptableVarianceAmt());
		validateGrossAcceptableVarianceValue(currencyToleranceDetails.getGrossAcceptVarPercentage());
		validateTaxAcceptableVarianceAmt(currencyToleranceDetails.getTaxAcceptableVarianceAmt());
		validateTaxAcceptableVarianceValue(currencyToleranceDetails.getTaxAcceptVarPercentage());
	}

	private void validateOverLapForCreate(CurrencyToleranceDetails currencyToleranceDetails) {
		if (currencyToleranceDao.findOverLapRecord(currencyToleranceDetails.getClientId(),
				currencyToleranceDetails.getCurrencyCode(), currencyToleranceDetails.getEffectiveFromDate(),
				currencyToleranceDetails.getEffectiveToDate()) != 0) {
			throw new BusinessException(OVER_LAP_CHECKING);
		}
	}

	private void validateOverLapForUpdate(CurrencyToleranceDetails currencyToleranceDetails,
			CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity) {
		String clientId = getClientId(currencyToleranceDetails, currencyToleranceDetailsEntity);
		String currencyCode = getCurrencyCode(currencyToleranceDetails, currencyToleranceDetailsEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(currencyToleranceDetails, currencyToleranceDetailsEntity);
		LocalDate effectiveToDate = getEffectiveToDate(currencyToleranceDetails, currencyToleranceDetailsEntity);

		if (currencyToleranceDao.findOverLapRecord(clientId, currencyCode, effectiveFromDate, effectiveToDate,
				currencyToleranceDetailsEntity.getCurrencyToleranceDtlId()) != 0) {
			throw new BusinessException(OVER_LAP_CHECKING);
		}
	}

	private String getCurrencyCode(CurrencyToleranceDetails currencyToleranceDetails,
			CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity) {
		return OptionalUtil.isPresent(currencyToleranceDetails.getCurrencyCode())
				? OptionalUtil.getValue(currencyToleranceDetails.getCurrencyCode())
				: currencyToleranceDetailsEntity.getCurrencyCode();
	}

	private String getClientId(CurrencyToleranceDetails currencyToleranceDetails,
			CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity) {
		return OptionalUtil.isPresent(currencyToleranceDetails.getClientId())
				? OptionalUtil.getValue(currencyToleranceDetails.getClientId())
				: currencyToleranceDetailsEntity.getClientId();

	}

	private void clientIdToCarrierDesignatorValidation(CurrencyToleranceDetails currencyToleranceDetails) {
		if (OptionalUtil.isPresent(currencyToleranceDetails.getClientId())) {
			String carrierDesignatorCode = OptionalUtil.getValue(currencyToleranceDetails.getClientId());
			if (!globalMasterFeignClient.isValidCarrierDesignatorCode(carrierDesignatorCode)) {
				throw new BusinessException("Invalid Client Id " + carrierDesignatorCode);
			}
		}
	}

	private void validateEffectiveToDate(CurrencyToleranceDetails currencyToleranceDetails,
			CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity) {
		if (OptionalUtil.isPresent(currencyToleranceDetails.getEffectiveFromDate())
				|| OptionalUtil.isPresent(currencyToleranceDetails.getEffectiveToDate())) {
			validateEffectiveToDate(getEffectiveFromDate(currencyToleranceDetails, currencyToleranceDetailsEntity),
					getEffectiveToDate(currencyToleranceDetails, currencyToleranceDetailsEntity));
		}
	}

	private LocalDate getEffectiveToDate(CurrencyToleranceDetails currencyToleranceDetails,
			CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity) {
		return OptionalUtil.isPresent(currencyToleranceDetails.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(currencyToleranceDetails.getEffectiveToDate())
				: currencyToleranceDetailsEntity.getEffectiveToDate();
	}

	private LocalDate getEffectiveFromDate(CurrencyToleranceDetails currencyToleranceDetails,
			CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity) {
		return OptionalUtil.isPresent(currencyToleranceDetails.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(currencyToleranceDetails.getEffectiveFromDate())
				: currencyToleranceDetailsEntity.getEffectiveFromDate();
	}

	protected void validateEffectiveToDate(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}

	private void validateTaxAcceptableVarianceValue(Optional<String> taxAcceptVarPercentage) {

		if (OptionalUtil.isPresent(taxAcceptVarPercentage)) {
			String taxAcceptVarPer = OptionalUtil.getValue(taxAcceptVarPercentage);
			Pattern digitPattern = Pattern.compile(PERCENTAGE_REGEX_PATTERN);
			verifyTaxPositiveValuesAndPercentage(taxAcceptVarPercentage);
			if (!digitPattern.matcher(taxAcceptVarPer).matches()) {
				throw new BusinessException("Invalid Tax Accept Var Percentage " + taxAcceptVarPer);
			}
		}
	}

	private void validateTaxAcceptableVarianceAmt(Optional<String> taxAcceptableVarianceAmt) {

		if (OptionalUtil.isPresent(taxAcceptableVarianceAmt)) {
			String taxAcceptVarAmt = OptionalUtil.getValue(taxAcceptableVarianceAmt);
			Pattern digitPattern = Pattern.compile(REGEX_PATTERN);
			verifyPositiveValues(taxAcceptableVarianceAmt);
			if (!digitPattern.matcher(taxAcceptVarAmt).matches()) {
				throw new BusinessException("Invalid Tax Acceptable Variance Amt " + taxAcceptVarAmt);
			}
		}
	}

	private void validateGrossAcceptableVarianceValue(Optional<String> grossAcceptVarPercentage) {
		if (OptionalUtil.isPresent(grossAcceptVarPercentage)) {
			String grossAcceptVarPer = OptionalUtil.getValue(grossAcceptVarPercentage);
			Pattern digitPattern = Pattern.compile(PERCENTAGE_REGEX_PATTERN);
			verifyPositiveValuesAndPercentage(grossAcceptVarPercentage);
			if (!digitPattern.matcher(grossAcceptVarPer).matches()) {
				throw new BusinessException("Invalid Gross Accept Var Percentage " + grossAcceptVarPer);
			}
		}
	}

	private void verifyPositiveValuesAndPercentage(Optional<String> grossAcceptVarPercentage) {
		if (OptionalUtil.isPresent(grossAcceptVarPercentage)) {
			Double positiveValue = Double.valueOf(OptionalUtil.getValue(grossAcceptVarPercentage));
			if (positiveValue < 0 || positiveValue > 100) {
				throw new BusinessException("Invalid Gross Accept Var Percentage " + positiveValue);

			}
		}
	}

	private void verifyTaxPositiveValuesAndPercentage(Optional<String> taxAcceptVarPercentage) {
		if (OptionalUtil.isPresent(taxAcceptVarPercentage)) {
			Double positiveValue = Double.valueOf(OptionalUtil.getValue(taxAcceptVarPercentage));
			if (positiveValue < 0 || positiveValue > 100) {
				throw new BusinessException("Invalid Tax Accept Var Percentage " + positiveValue);
			}
		}
	}

	private void validateGrossAcceptableVarianceAmt(Optional<String> grossAcceptableVarianceAmt) {

		if (OptionalUtil.isPresent(grossAcceptableVarianceAmt)) {
			String grossAcceptVarAmt = OptionalUtil.getValue(grossAcceptableVarianceAmt);
			Pattern digitPattern = Pattern.compile(REGEX_PATTERN);
			verifyPositiveValues(grossAcceptableVarianceAmt);
			if (!digitPattern.matcher(grossAcceptVarAmt).matches()) {
				throw new BusinessException("Invalid Gross Acceptable Variance Amt " + grossAcceptVarAmt);
			}
		}
	}

	private void validateMinimunValue(Optional<String> minimumValue) {

		if (OptionalUtil.isPresent(minimumValue)) {
			String miniValue = OptionalUtil.getValue(minimumValue);
			Pattern digitPattern = Pattern.compile(REGEX_PATTERN);
			verifyPositiveValues(minimumValue);
			if (!digitPattern.matcher(miniValue).matches()) {
				throw new BusinessException("Invalid Minimum Value " + miniValue);
			}
		}
	}

	private void verifyPositiveValues(Optional<String> value) {
		if (OptionalUtil.isPresent(value)) {
			Double positiveValue = Double.valueOf(OptionalUtil.getValue(value));
			if (positiveValue < 0) {
				throw new BusinessException("Please provide positive value " + OptionalUtil.getValue(value));
			}
		}
	}
}
