package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.CustomerEntity;
import com.sgl.smartpra.master.model.Customer;

public class CustomerEntitySpecification {

	public static Specification<CustomerEntity> equalsClientId(String clientId) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(customerEntity.get("clientId"),
				clientId);
	}

	public static Specification<CustomerEntity> equalsCustomerCode(String customerCode) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(customerEntity.get("customerCode"), customerCode);
	}

	public static Specification<CustomerEntity> equalsCustomerName(String customerName) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(customerEntity.get("customerName"), customerName);
	}

	public static Specification<CustomerEntity> equalsCustomerType(String customerType) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(customerEntity.get("customerType"), customerType);
	}

	public static Specification<CustomerEntity> equalsFopCode(String fopCode) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(customerEntity.get("fopCode"),
				fopCode);
	}

	public static Specification<CustomerEntity> equalsSubFopCode(String subFopCode) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(customerEntity.get("subFopCode"), subFopCode);
	}

	public static Specification<CustomerEntity> equalsLpoNumber(String lpoNumber) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(customerEntity.get("lpoNumber"), lpoNumber);
	}

	public static Specification<CustomerEntity> equalsDebtorCode(String debtorCode) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(customerEntity.get("debtorCode"), debtorCode);
	}

	public static Specification<CustomerEntity> equalsAgencyCode(String agencyCode) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(customerEntity.get("agencyCode"), agencyCode);
	}

	public static Specification<CustomerEntity> isActive() {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(customerEntity.get("activate"),
				true);
	}

	public static Specification<CustomerEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), customerEntity.get("effectiveFromDate"),
				customerEntity.get("effectiveToDate"));
	}

	public static Specification<CustomerEntity> notEqualsCustomerMasId(Integer customerMasId) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(customerEntity.get("customerMasId"), customerMasId);
	}

	public static void orderByAsc(Root<CustomerEntity> customerEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(customerEntity.get(orderByString)));
	}

	public static Specification<CustomerEntity> search(Customer customer, Optional<String> exceptionCall) {
		return (customerEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(customer.getClientId())) {
				predicates.add(criteriaBuilder.equal(customerEntity.get("clientId"),
						OptionalUtil.getValue(customer.getClientId())));
			}

			if (OptionalUtil.isPresent(customer.getCustomerCode())) {
				predicates.add(criteriaBuilder.like(customerEntity.get("customerCode"),
						OptionalUtil.getValue(customer.getCustomerCode()) + "%"));
			}
			if (OptionalUtil.isPresent(customer.getCustomerType())) {
				predicates.add(criteriaBuilder.like(customerEntity.get("customerType"),
						OptionalUtil.getValue(customer.getCustomerType()) + "%"));
			}
			if (OptionalUtil.isPresent(customer.getCustomerName())) {
				predicates.add(criteriaBuilder.like(customerEntity.get("customerName"),
						OptionalUtil.getValue(customer.getCustomerName()) + "%"));
			}
			if (OptionalUtil.isPresent(customer.getBillingFrequency())) {
				predicates.add(criteriaBuilder.like(customerEntity.get("billingFrequency"),
						OptionalUtil.getValue(customer.getBillingFrequency()) + "%"));
			}
			if (OptionalUtil.isPresent(customer.getFinancialDocType())) {
				predicates.add(criteriaBuilder.like(customerEntity.get("financialDocType"),
						OptionalUtil.getValue(customer.getFinancialDocType()) + "%"));
			}
			if (!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (customer.getActivate() != null) {
					predicates.add(criteriaBuilder.equal(customerEntity.get("activate"), customer.getActivate()));
				}
				if (customer.getActivate() == null) {
					predicates.add(criteriaBuilder.equal(customerEntity.get("activate"), true));
				}
			}
			orderByAsc(customerEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
