package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.EMDModel;

public interface EMDService {

	public List<EMDModel> getListOfEMD(EMDModel emdModel, Optional<String> exceptionCall);

	public EMDModel getEMDByEmdId(Integer emdId);

	public EMDModel createEMD(EMDModel emdId);

	public EMDModel updateEMD(Integer emdId, EMDModel emdModel);

	public void deactivateEMD(Integer emdId, String lastUpdatedBy);

	public void activateEMD(Integer emdId, String lastUpdatedBy);

}
