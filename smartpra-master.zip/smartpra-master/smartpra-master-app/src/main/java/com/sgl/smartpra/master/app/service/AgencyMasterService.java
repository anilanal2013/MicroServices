package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.master.app.dao.entity.AgencyMasterEntity;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.master.model.AgencyMasterResponse;

public interface AgencyMasterService {
	public List<AgencyMaster> getListOfAgency(Optional<String> agencyCode, Optional<String> reportingAgency,
			Optional<String> agencyType, Optional<String> areaOfOperation, Optional<String> reportingAgencyType,
			Optional<Boolean> activate);

	public List<AgencyMaster> getSearchAllAgency(Optional<String> agencyCode, Optional<String> reportingAgency,
			Optional<String> agencyType, Optional<String> areaOfOperation, Optional<String> reportingAgencyType,
			Optional<String> cityCode, Optional<String> countryCode, Optional<Boolean> activate, Optional<String> clientId);

	public AgencyMaster getAgencyByAgencyId(Integer agencyId);

	public AgencyMaster createAgency(AgencyMaster agencyMaster);

	public AgencyMaster updateAgency(Integer agencyId, AgencyMaster agencyMaster);

	public void deactivateAgency(Integer agencyId, String lastUpdatedBy);

	public void activateAgency(Integer agencyId, String lastUpdatedBy);

	public List<AgencyMasterEntity> isValidAgencyCode(String agencyCode);

	public AgencyMasterResponse getListOfAgency(AgencyMaster agencyMaster, Optional<String> exceptionCall, Pageable pageable);

	public AgencyMaster getAgencyByAgencyCode(String agencyCode, String clientId);

}
