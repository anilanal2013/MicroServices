package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.AccountingScenarioEntity;

public class AccountingScenarioEntitySpecification {
	AccountingScenarioEntitySpecification() {
	}

	public static Specification<AccountingScenarioEntity> search(String transactionType, String selfOalIndicator,
			Boolean salesExistIndicator, String docType, String chargeCatCode, String chargeCode) {
		return (accoutingScenarioEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (transactionType != null) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("transactionType"), transactionType));
			}
			if (selfOalIndicator != null) {
				predicates
						.add(criteriaBuilder.equal(accoutingScenarioEntity.get("selfOalIndicator"), selfOalIndicator));
			}
			if (salesExistIndicator != null) {
				predicates.add(
						criteriaBuilder.equal(accoutingScenarioEntity.get("salesExistIndicator"), salesExistIndicator));
			}
			if (docType != null) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("docType"), docType));
			}
			if (chargeCatCode != null) {
				predicates.add(criteriaBuilder.like(accoutingScenarioEntity.get("chargeCatCode"), chargeCatCode + "%"));
			}
			if (chargeCode != null) {
				predicates.add(criteriaBuilder.like(accoutingScenarioEntity.get("chargeCode"), chargeCode + "%"));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<AccountingScenarioEntity> isActive() {
		return (accountingScenarioEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingScenarioEntity.get("isActive"), true);
	}

	public static Specification<AccountingScenarioEntity> searchWithIsActiveParam(String module, String transactionType,
			String selfOalIndicator, Boolean salesExistIndicator, String docType, String chargeCatCode,
			String chargeCode, Boolean isActive) {

		return (accoutingScenarioEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (module != null) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("module"), module));
			}
			if (transactionType != null) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("transactionType"), transactionType));
			}
			if (selfOalIndicator != null) {
				predicates
						.add(criteriaBuilder.equal(accoutingScenarioEntity.get("selfOalIndicator"), selfOalIndicator));
			}
			if (salesExistIndicator != null) {
				predicates.add(
						criteriaBuilder.equal(accoutingScenarioEntity.get("salesExistIndicator"), salesExistIndicator));
			}
			if (docType != null) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("docType"), docType));
			}
			if (chargeCatCode != null) {
				predicates.add(criteriaBuilder.like(accoutingScenarioEntity.get("chargeCatCode"), chargeCatCode + "%"));
			}
			if (chargeCode != null) {
				predicates.add(criteriaBuilder.like(accoutingScenarioEntity.get("chargeCode"), chargeCode + "%"));
			}
			if (isActive != null) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("isActive"), isActive));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<AccountingScenarioEntity> checkOverlapping(Optional<String> clientId,
			Optional<String> module, Optional<String> transactionType, Optional<String> selfOalIndicator,
			Optional<Boolean> salesExistIndicator, Optional<String> docType, Optional<String> chargeCatCode,
			Optional<String> chargeCode, Optional<Boolean> preImplementationIndicator,
			Optional<String> miscDocumentUtilType, Optional<String> miscDocumentIssuedFor, Optional<String> invoiceType,
			Optional<String> sourceCode, Optional<Boolean> deliveringCarrierIndicator,
			Optional<Boolean> receivingCarrierIndicator, Optional<String> fopType, Optional<String> rejectionMemoType,
			Optional<String> ancillaryService, Optional<Boolean> bspAgentFlag) {

		return (accoutingScenarioEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("clientId"),
						OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(module)) {
				predicates.add(
						criteriaBuilder.equal(accoutingScenarioEntity.get("module"), OptionalUtil.getValue(module)));
			}
			if (OptionalUtil.isPresent(transactionType)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("transactionType"),
						OptionalUtil.getValue(transactionType)));
			}
			if (OptionalUtil.isPresent(selfOalIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("selfOalIndicator"),
						OptionalUtil.getValue(selfOalIndicator)));
			}
			if (OptionalUtil.isPresent(salesExistIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("salesExistIndicator"),
						OptionalUtil.getValue(salesExistIndicator)));
			}
			if (OptionalUtil.isPresent(docType)) {
				predicates.add(
						criteriaBuilder.equal(accoutingScenarioEntity.get("docType"), OptionalUtil.getValue(docType)));
			}
			if (OptionalUtil.isPresent(chargeCatCode)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("chargeCatCode"),
						OptionalUtil.getValue(chargeCatCode)));
			}
			if (OptionalUtil.isPresent(chargeCode)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("chargeCode"),
						OptionalUtil.getValue(chargeCode)));
			}
			if (OptionalUtil.isPresent(preImplementationIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("preImplementationIndicator"),
						OptionalUtil.getValue(preImplementationIndicator)));
			}
			if (OptionalUtil.isPresent(miscDocumentUtilType)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("miscDocumentUtilType"),
						OptionalUtil.getValue(miscDocumentUtilType)));
			}
			if (OptionalUtil.isPresent(miscDocumentIssuedFor)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("miscDocumentIssuedFor"),
						OptionalUtil.getValue(miscDocumentIssuedFor)));
			}
			if (OptionalUtil.isPresent(invoiceType)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("invoiceType"),
						OptionalUtil.getValue(invoiceType)));
			}
			if (OptionalUtil.isPresent(sourceCode)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("sourceCode"),
						OptionalUtil.getValue(sourceCode)));
			}
			if (OptionalUtil.isPresent(deliveringCarrierIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("deliveringCarrierIndicator"),
						OptionalUtil.getValue(deliveringCarrierIndicator)));
			}
			if (OptionalUtil.isPresent(receivingCarrierIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("receivingCarrierIndicator"),
						OptionalUtil.getValue(receivingCarrierIndicator)));
			}
			if (OptionalUtil.isPresent(fopType)) {
				predicates.add(
						criteriaBuilder.equal(accoutingScenarioEntity.get("fopType"), OptionalUtil.getValue(fopType)));
			}
			if (OptionalUtil.isPresent(rejectionMemoType)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("rejectionMemoType"),
						OptionalUtil.getValue(rejectionMemoType)));
			}
			if (OptionalUtil.isPresent(ancillaryService)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("ancillaryService"),
						OptionalUtil.getValue(ancillaryService)));
			}
			if (OptionalUtil.isPresent(bspAgentFlag)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("bspAgentFlag"),
						OptionalUtil.getValue(bspAgentFlag)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AccountingScenarioEntity> checkOverlappingForUpdate(Optional<String> clientId,
			Optional<String> module, Optional<String> transactionType, Optional<String> selfOalIndicator,
			Optional<Boolean> salesExistIndicator, Optional<String> docType, Optional<String> chargeCatCode,
			Optional<String> chargeCode, Optional<Boolean> preImplementationIndicator,
			Optional<String> miscDocumentUtilType, Optional<String> miscDocumentIssuedFor, Optional<String> invoiceType,
			Optional<String> sourceCode, Optional<Boolean> deliveringCarrierIndicator,
			Optional<Boolean> receivingCarrierIndicator, Optional<String> fopType, Optional<String> rejectionMemoType,
			Optional<String> ancillaryService, Optional<Boolean> bspAgentFlag, Integer scenarioNumber) {

		return (accoutingScenarioEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("clientId"),
						OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(module)) {
				predicates.add(
						criteriaBuilder.equal(accoutingScenarioEntity.get("module"), OptionalUtil.getValue(module)));
			}
			if (OptionalUtil.isPresent(transactionType)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("transactionType"),
						OptionalUtil.getValue(transactionType)));
			}
			if (OptionalUtil.isPresent(selfOalIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("selfOalIndicator"),
						OptionalUtil.getValue(selfOalIndicator)));
			}
			if (OptionalUtil.isPresent(salesExistIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("salesExistIndicator"),
						OptionalUtil.getValue(salesExistIndicator)));
			}
			if (OptionalUtil.isPresent(docType)) {
				predicates.add(
						criteriaBuilder.equal(accoutingScenarioEntity.get("docType"), OptionalUtil.getValue(docType)));
			}
			if (OptionalUtil.isPresent(chargeCatCode)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("chargeCatCode"),
						OptionalUtil.getValue(chargeCatCode)));
			}
			if (OptionalUtil.isPresent(chargeCode)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("chargeCode"),
						OptionalUtil.getValue(chargeCode)));
			}
			if (OptionalUtil.isPresent(preImplementationIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("preImplementationIndicator"),
						OptionalUtil.getValue(preImplementationIndicator)));
			}
			if (OptionalUtil.isPresent(miscDocumentUtilType)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("miscDocumentUtilType"),
						OptionalUtil.getValue(miscDocumentUtilType)));
			}
			if (OptionalUtil.isPresent(miscDocumentIssuedFor)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("miscDocumentIssuedFor"),
						OptionalUtil.getValue(miscDocumentIssuedFor)));
			}
			if (OptionalUtil.isPresent(invoiceType)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("invoiceType"),
						OptionalUtil.getValue(invoiceType)));
			}
			if (OptionalUtil.isPresent(sourceCode)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("sourceCode"),
						OptionalUtil.getValue(sourceCode)));
			}
			if (OptionalUtil.isPresent(deliveringCarrierIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("deliveringCarrierIndicator"),
						OptionalUtil.getValue(deliveringCarrierIndicator)));
			}
			if (OptionalUtil.isPresent(receivingCarrierIndicator)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("receivingCarrierIndicator"),
						OptionalUtil.getValue(receivingCarrierIndicator)));
			}
			if (OptionalUtil.isPresent(fopType)) {
				predicates.add(
						criteriaBuilder.equal(accoutingScenarioEntity.get("fopType"), OptionalUtil.getValue(fopType)));
			}
			if (OptionalUtil.isPresent(rejectionMemoType)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("rejectionMemoType"),
						OptionalUtil.getValue(rejectionMemoType)));
			}
			if (OptionalUtil.isPresent(ancillaryService)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("ancillaryService"),
						OptionalUtil.getValue(ancillaryService)));
			}
			if (OptionalUtil.isPresent(bspAgentFlag)) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("bspAgentFlag"),
						OptionalUtil.getValue(bspAgentFlag)));
			}
			if (scenarioNumber != null) {
				predicates.add(criteriaBuilder.equal(accoutingScenarioEntity.get("scenarioNumber"), scenarioNumber));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
