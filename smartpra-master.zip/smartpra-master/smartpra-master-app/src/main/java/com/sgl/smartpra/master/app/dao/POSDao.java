package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.POSEntity;

@Repository
public interface POSDao {

	public POSEntity create(POSEntity posEntity);

	public POSEntity update(POSEntity posEntity);

	public List<POSEntity> search(Optional<String> clientId, Optional<String> posCode, Optional<String> posName, Optional<String> accountCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	public Optional<POSEntity> findByPosCode(Integer posCode);

	public long getOverLapForCreate(String posCode, String clientId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate);

	public long getOverLapForUpdate(String posCode, String clientId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, Integer posId);

}