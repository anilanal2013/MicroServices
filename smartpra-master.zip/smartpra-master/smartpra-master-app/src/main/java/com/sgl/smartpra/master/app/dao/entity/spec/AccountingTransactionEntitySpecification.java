package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.AccountingTransactionEntity;

public class AccountingTransactionEntitySpecification {
	AccountingTransactionEntitySpecification() {
	}

	public static Specification<AccountingTransactionEntity> findByAccountingId(Optional<Integer> scenarioNumber,
			Optional<Integer> accountDefinitionIdentifier, Integer accountingTransactionId) {

		return (accountingTransactionEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(scenarioNumber)) {
				predicates.add(criteriaBuilder.equal(accountingTransactionEntity.get("scenarioNumber"),
						OptionalUtil.getValue(scenarioNumber)));
			}
			if (OptionalUtil.isPresent(accountDefinitionIdentifier)) {
				predicates.add(criteriaBuilder.equal(accountingTransactionEntity.get("accountDefinitionIdentifier"),
						OptionalUtil.getValue(accountDefinitionIdentifier)));
			}
			if (accountingTransactionId != null) {
				predicates.add(criteriaBuilder.equal(accountingTransactionEntity.get("accountingTransactionId"),
						accountingTransactionId));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AccountingTransactionEntity> findByFkId(Integer scenarioNumber,
			Optional<Integer> accountDefinitionIdentifier, Optional<String> accountAlphaCode, Boolean isActive) {

		return (accountingTransactionEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (scenarioNumber != null) {
				predicates.add(
						criteriaBuilder.equal(accountingTransactionEntity.get("scenarioNumber"), scenarioNumber));
			}
			if (OptionalUtil.isPresent(accountDefinitionIdentifier)) {
				predicates.add(criteriaBuilder.equal(accountingTransactionEntity.get("accountDefinitionIdentifier"),
						OptionalUtil.getValue(accountDefinitionIdentifier)));
			}
			if (OptionalUtil.isPresent(accountAlphaCode)) {
				predicates.add(criteriaBuilder.like(accountingTransactionEntity.get("accountAlphaCode"),
						OptionalUtil.getValue(accountAlphaCode) + "%"));
			}
			if (isActive != null) {
				predicates.add(criteriaBuilder.equal(accountingTransactionEntity.get("isActive"), isActive));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AccountingTransactionEntity> isActive() {
		return (accountingTransactionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingTransactionEntity.get("isActive"), true);
	}

	public static Specification<AccountingTransactionEntity> equalsClientId(String clientId) {
		return (accountingTransactionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingTransactionEntity.get("clientId"), clientId);
	}

	public static Specification<AccountingTransactionEntity> equalsScenarioNumber(Integer scenarioNumber) {
		return (accountingTransactionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingTransactionEntity.get("scenarioNumber"), scenarioNumber);
	}

	public static Specification<AccountingTransactionEntity> equalsTransactionSerialNo(Integer transactionSerialNo) {
		return (accountingTransactionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingTransactionEntity.get("transactionSerialNo"), transactionSerialNo);
	}

	public static Specification<AccountingTransactionEntity> notEqualsAccountingTransactionId(
			Integer accountingTransactionId) {

		return (accountingTransactionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(accountingTransactionEntity.get("accountingTransactionId"), accountingTransactionId);
	}

	public static Specification<AccountingTransactionEntity> findByScenarioNumber(Optional<Integer> scenarioNumber) {
		return (accountingTransactionEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(scenarioNumber)) {
				predicates.add(criteriaBuilder.equal(accountingTransactionEntity.get("scenarioNumber"),
						OptionalUtil.getValue(scenarioNumber)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
