package com.sgl.smartpra.master.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.OutwardBillingModuleEntity;

@Repository
public interface OutwardBillingModuleRepository extends JpaRepository<OutwardBillingModuleEntity, Integer>,
		JpaSpecificationExecutor<OutwardBillingModuleEntity> {

	List<OutwardBillingModuleEntity> findByBillingPeriodAndBillingMonthAndModuleNameAndClientId(Integer billingPeriod,
			String billingMonth, String moduleName, String clientId);

	List<OutwardBillingModuleEntity> findByBillingPeriodAndBillingMonthAndModuleName(Integer billingPeriod,
			String billingMonth, String moduleName);

	@Query(value = "select top 1 * ,CONVERT(datetime,SUBSTRING(billing_month,1,3)+SUBSTRING(convert(varchar(4), YEAR(getdate())),1,2)+SUBSTRING(billing_month,5,6)) as date from SmartPRAMaster.mas_outward_billing_module where close_indicator='Y' and module_name=?1 order by date desc,billing_period desc", nativeQuery = true)
	OutwardBillingModuleEntity getLatestClosedOutwardBillingModule(String moduleName);

	@Query(value = "select top 1 * ,CONVERT(datetime,SUBSTRING(billing_month,1,3)+SUBSTRING(convert(varchar(4), YEAR(getdate())),1,2)+SUBSTRING(billing_month,5,6)) as date from SmartPRAMaster.mas_outward_billing_module where close_indicator='N' and module_name=?1 order by date asc,billing_period ", nativeQuery = true)
	OutwardBillingModuleEntity getCurrentOpenOutwardBillingModule(String moduleName);

}
