package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_route_code")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class RouteCodeEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "route_code_id")
	private Integer routeCodeId;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "cost_center")
	private String costCenter;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Column(name = "responsibility_centre")
	private String responsibilityCentre;

	@Column(name = "route_code")
	private String routeCode;

	@Column(name = "routing")
	private String routing;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLadtUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
