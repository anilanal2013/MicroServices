package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.CommonRatedDao;
import com.sgl.smartpra.master.app.dao.entity.spec.ComonRatedSectorEntitySpecification;
import com.sgl.smartpra.master.app.repository.CommonRatedSectorRepository;
import com.sgl.smartpra.master.app.repository.entity.CommonRatedSectorEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CommonRatedSectorDaoImpl implements CommonRatedDao {

	@Autowired
	private CommonRatedSectorRepository commonRatedSectorRepository;

	@Override
	public List<CommonRatedSectorEntity> search(Optional<String> clientId, Optional<String> fromAirport,
			Optional<String> toAirport, Optional<String> commonRatedFromAirport,
			Optional<String> commonRatedToAirport) {
		return commonRatedSectorRepository.findAll(ComonRatedSectorEntitySpecification.search(clientId, fromAirport,
				toAirport, commonRatedFromAirport, commonRatedToAirport));
	}

	@Override
	public List<CommonRatedSectorEntity> getAllCommonRatedSectors(Optional<String> fromAirport,
			Optional<String> toAirport, Optional<String> commonRatedFromAirport, Optional<String> commonRatedToAirport,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return commonRatedSectorRepository.findAll(ComonRatedSectorEntitySpecification.search(fromAirport, toAirport,
				commonRatedFromAirport, commonRatedToAirport, effectiveFromDate, effectiveToDate));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "commonRatedSector", key = "#commonRatedSectorEntity.commonRatedID") })
	public CommonRatedSectorEntity createCommonRateSectors(CommonRatedSectorEntity commonRatedSectorEntity) {
		return commonRatedSectorRepository.save(commonRatedSectorEntity);
	}

	@Override
	@Cacheable(value = "commonRatedSector", key = "#id")
	public Optional<CommonRatedSectorEntity> findById(Integer id) {
		log.info("Cacheable CommonRatedSector Entity's ID= {}", id);
		return commonRatedSectorRepository.findById(id);
	}

	@Override
	@CachePut(value = "commonRatedSector", key = "#commonRatedSectorEntity.commonRatedID")
	public CommonRatedSectorEntity updateCommonRateSectors(CommonRatedSectorEntity commonRatedSectorEntity) {
		return commonRatedSectorRepository.save(commonRatedSectorEntity);
	}

	@Override
	public Optional<CommonRatedSectorEntity> findCommonRatedSectorByCommonRatedSectorId(Integer commonRatedID) {
		return commonRatedSectorRepository.findById(commonRatedID);
	}

	@Override
	public long validateOverLapForCreate(Optional<String> clientId, Optional<String> fromAirport,
			Optional<String> toAirport, Optional<String> commonRatedFromAirport, Optional<String> commonRatedToAirport,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return commonRatedSectorRepository.count(ComonRatedSectorEntitySpecification
				.equalsClientId(OptionalUtil.getValue(clientId))
				.and(ComonRatedSectorEntitySpecification.equalsFromAirport(OptionalUtil.getValue(fromAirport)))
				.and(ComonRatedSectorEntitySpecification.equalsToAirport(OptionalUtil.getValue(toAirport)))
				.and(ComonRatedSectorEntitySpecification
						.equalsCommonRatedToAirport(OptionalUtil.getValue(commonRatedToAirport)))
				.and(ComonRatedSectorEntitySpecification
						.equalsCommonRatedFromAirport(OptionalUtil.getValue(commonRatedFromAirport)))
				.and((ComonRatedSectorEntitySpecification
						.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate))
						.or(ComonRatedSectorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(
								OptionalUtil.getLocalDateValue(effectiveToDate))))
										.or(ComonRatedSectorEntitySpecification
												.greaterThanOrEqualTo(OptionalUtil.getLocalDateValue(effectiveFromDate))
												.and(ComonRatedSectorEntitySpecification.lessThanOrEqualTo(
														OptionalUtil.getLocalDateValue(effectiveToDate))))));
	}

	@Override
	public long validateOverLapForUpdate(String clientId, String fromAirport, String toAirport,
			String commonRatedFromAirport, String commonRatedToAirport, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, Integer commonRatedID) {
		return commonRatedSectorRepository.count(ComonRatedSectorEntitySpecification.equalsClientId(clientId)
				.and(ComonRatedSectorEntitySpecification.equalsFromAirport(fromAirport))
				.and(ComonRatedSectorEntitySpecification.equalsToAirport(toAirport))
				.and(ComonRatedSectorEntitySpecification.equalsCommonRatedToAirport(commonRatedToAirport))
				.and(ComonRatedSectorEntitySpecification.equalsCommonRatedFromAirport(commonRatedFromAirport))
				.and((ComonRatedSectorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate).or(
						ComonRatedSectorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
								.or(ComonRatedSectorEntitySpecification.greaterThanOrEqualTo(effectiveFromDate)
										.and(ComonRatedSectorEntitySpecification.lessThanOrEqualTo(effectiveToDate))))
				.and(ComonRatedSectorEntitySpecification.notEqualsCommonRatedId(commonRatedID)));
	}

}
