package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.FormCodeEntity;

@Repository
public interface FormCodeDao {

	public List<FormCodeEntity> findAllFormCode(Optional<String> clientId, Optional<String> formCode, Optional<String> documentType,
			Optional<String> numberOfCoupon, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate,Optional<String> exceptionCall);

	public Optional<FormCodeEntity> findById(Integer formCodeId);

	public FormCodeEntity create(FormCodeEntity mapToEntity);

	public long getOverLapRecordCount(Optional<String> clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			Optional<String> formCode, Optional<String> documentType);

	public long getOverLapRecordCount(String clientId, String documentType, String formCode1,
			LocalDate effectiveFromDate, LocalDate effectiveToDate, Integer formCodeId);

	public FormCodeEntity update(FormCodeEntity mapToEntity);

	public Page<FormCodeEntity> findAll(FormCodeEntity mapToEntity, Optional<String> exceptionCall, Pageable pageable);

	public Long getCount(FormCodeEntity mapToEntity, Optional<String> exceptionCall);   
	
	public Optional<FormCodeEntity> getFormCodeByfromCodeAndEffectiveDate(Optional<String> clientId, Optional<String> formCode,Optional<String> effectiveDate);

	List<FormCodeEntity> findFormCode(Optional<String> formCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<Boolean> activate);

}
