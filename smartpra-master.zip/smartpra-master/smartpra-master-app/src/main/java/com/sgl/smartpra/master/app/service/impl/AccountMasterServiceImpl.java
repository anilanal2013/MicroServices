/**
 * 
 */
package com.sgl.smartpra.master.app.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.master.app.dao.AccountMasterDao;
import com.sgl.smartpra.master.app.mapper.AccountMasterMapper;
import com.sgl.smartpra.master.app.service.AccountMasterService;
import com.sgl.smartpra.master.model.MasAccountModel;

import lombok.extern.slf4j.Slf4j;

/**
 * @author nacsanth
 *
 */
@Service
@Slf4j
@Transactional
public class AccountMasterServiceImpl implements AccountMasterService {
	@Autowired
	private AccountMasterMapper accountMasterServiceImpl;
	@Autowired
	private AccountMasterDao accountMasterDao;

	@Override
	public List<MasAccountModel> getListOfAccountMasters() {
		log.info("converting entityt to model");
		return accountMasterServiceImpl.mapToModel(accountMasterDao.findAll());
	}

	@Override
	public List<MasAccountModel> getListOfAccountMastersByAccountAlphaCode(String ByAccountAlphaCode) {
		log.info("converting entityt to model");
		return accountMasterServiceImpl.mapToModel(accountMasterDao.findByAccountAlphaCode(ByAccountAlphaCode));
	}
}
