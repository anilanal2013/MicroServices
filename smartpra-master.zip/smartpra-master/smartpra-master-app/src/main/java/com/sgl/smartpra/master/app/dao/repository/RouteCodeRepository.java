package com.sgl.smartpra.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.RouteCodeEntity;

@Repository
public interface RouteCodeRepository
		extends JpaRepository<RouteCodeEntity, Integer>, JpaSpecificationExecutor<RouteCodeEntity> {

}

