package com.sgl.smartpra.master.app.dao.entity;

/**
 * @author kanprasa
 *
 */

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_non_std_charge_category")
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicUpdate
@DynamicInsert
public class NonStandardChargeCategoryEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "non_std_category_id")
	private Integer nonStdCategoryId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "non_std_category_name")
	private String nonStdCategoryName;

	@Column(name = "non_std_category_code")
	private String nonStdCategoryCode;

	@Column(name = "std_category_code")
	private String stdCategoryCode;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "cost_center_code")
	private String costCenterCode;

	@Column(name = "is_active")
	private String isActive;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
