package com.sgl.smartpra.master.app.repository.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

@Entity
@Table(name = "mas_outward_billing_period")
public class OutwardBillingPeriodsEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "outward_billing_id")
	Integer outwardBillingId;
	@Column(name = "client_id")
	String clientId;
	@Column(name = "billing_month")
	String billingMonth;
	@Column(name = "billing_period")
	Integer billingPeriod;
	@Column(name = "start_date")
	LocalDate startDate;
	@Column(name = "end_date")
	LocalDate endDate;
	@Column(name = "closing_indicator")
	String closingIndicator;
	@Column(name = "created_by")
	String createdBy;
	@Column(name = "created_date")
	Timestamp createdDate;
	@Column(name = "last_updated_by")
	String lastUpdatedBy;
	@Column(name = "last_updated_date")
	Timestamp lastUpdatedDate;

	@Column(name = "skip_ind")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean skipInd;

	@Column(name = "remarks")
	private String remarks;

	public Boolean getSkipInd() {
		return skipInd;
	}

	public void setSkipInd(Boolean skipInd) {
		this.skipInd = skipInd;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getOutwardBillingId() {
		return outwardBillingId;
	}

	public void setOutwardBillingId(Integer outwardBillingId) {
		this.outwardBillingId = outwardBillingId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getBillingMonth() {
		return billingMonth;
	}

	public void setBillingMonth(String billingMonth) {
		this.billingMonth = billingMonth;
	}

	public Integer getBillingPeriod() {
		return billingPeriod;
	}

	public void setBillingPeriod(Integer billingPeriod) {
		this.billingPeriod = billingPeriod;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getClosingIndicator() {
		return closingIndicator;
	}

	public void setClosingIndicator(String closingIndicator) {
		this.closingIndicator = closingIndicator;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
