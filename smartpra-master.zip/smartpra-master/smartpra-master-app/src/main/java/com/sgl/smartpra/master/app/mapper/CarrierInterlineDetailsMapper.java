package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.repository.entity.CarrierInterlineDetailsEntity;
import com.sgl.smartpra.master.model.CarrierInterlineDetailsModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CarrierInterlineDetailsMapper extends BaseMapper<CarrierInterlineDetailsModel, CarrierInterlineDetailsEntity> {
	
	CarrierInterlineDetailsEntity mapToEntity(CarrierInterlineDetailsModel carrierInterlineDetailsModel, @MappingTarget CarrierInterlineDetailsEntity carrierInterlineDetailsEntity);

	@Mapping(source = "carrierInterlineDtlId", target = "carrierInterlineDtlId", ignore = true)
	CarrierInterlineDetailsEntity mapToEntity(CarrierInterlineDetailsModel carrierInterlineDetailsModel);
}