package com.sgl.smartpra.master.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.SourceCodeEntity;

@Repository
public interface SourceCodeRepository
		extends JpaRepository<SourceCodeEntity, Integer>, JpaSpecificationExecutor<SourceCodeEntity> {

	@Query(value = "select sourceCodeId from SourceCodeEntity d where d.sourceCode=?1 and d.clientId=?2 and d.activate = 'Y'")
	List<Integer> sameSourceCode(String sourceCode, String clientId);

	@Query(value = "select outwardSourceCode from SourceCodeEntity d where d.sourceCode=?1 and d.clientId=?2 and d.activate = 'Y'")
	List<String> getOutWardSourceCodeBySourceCode(String sourceCode, String clientId);

	@Query(value = "select d from SourceCodeEntity d where d.sourceCode=?1 and d.clientId=?2 and d.activate = 'Y'")
	List<SourceCodeEntity> getSourceCodeBySourceCodeAndClientId(String sourceCode, String clientId);

	@Query(value = "select distinct(sourceCode) from SourceCodeEntity sourcecodemas where activate='Y'")
	List<String> getSourceCodeFromSourceCodeMaster();

}
