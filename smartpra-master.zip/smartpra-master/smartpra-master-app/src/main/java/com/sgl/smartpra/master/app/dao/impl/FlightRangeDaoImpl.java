package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.FlightRangeDao;
import com.sgl.smartpra.master.app.dao.entity.FlightRangeEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.FlightRangeEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.FlightRangeRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FlightRangeDaoImpl implements FlightRangeDao {

	@Autowired
	private FlightRangeRepository flightRangeRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "flightRange", key = "#flightRangeEntity.flightRangeAutoId"),
			@CacheEvict(value = "flightRangeId", allEntries = true),
			@CacheEvict(value = "isMarketingOperating", allEntries = true),
			@CacheEvict(value = "cxrCode", allEntries = true), @CacheEvict(value = "flightNumber", allEntries = true),
			@CacheEvict(value = "saleDate", allEntries = true), @CacheEvict(value = "travelDate", allEntries = true) })
	public FlightRangeEntity create(FlightRangeEntity flightRangeEntity) {
		return flightRangeRepository.save(flightRangeEntity);
	}

	@Override
	@CachePut(value = "flightRange", key = "#flightRangeEntity.flightRangeAutoId")
	@Caching(evict = { @CacheEvict(value = "flightRangeId", allEntries = true),
			@CacheEvict(value = "isMarketingOperating", allEntries = true),
			@CacheEvict(value = "cxrCode", allEntries = true), @CacheEvict(value = "flightNumber", allEntries = true),
			@CacheEvict(value = "saleDate", allEntries = true), @CacheEvict(value = "travelDate", allEntries = true) })
	public FlightRangeEntity update(FlightRangeEntity flightRangeEntity) {
		return flightRangeRepository.save(flightRangeEntity);
	}

	@Override
	@Cacheable(cacheNames = { "flightRangeId", "isMarketingOperating", "cxrCode", "flightNumber" })
	public List<FlightRangeEntity> searchFlightRange(Optional<String> flightRangeId,
			Optional<String> isMarketingOperating, Optional<String> cxrCode, Optional<String> flightNumber,
			Optional<Boolean> activate) {
		return flightRangeRepository.findAll(FlightRangeEntitySpecification.searchFlightRange(flightRangeId,
				isMarketingOperating, cxrCode, flightNumber, activate));
	}

	@Override
	@Cacheable(value = "flightRange", key = "#flightRangeAutoId")
	public Optional<FlightRangeEntity> findById(Integer flightRangeAutoId) {
		log.info("Cacheable Flight Range Entity's ID = {}", flightRangeAutoId);
		return flightRangeRepository.findById(flightRangeAutoId);
	}

	@Override
	@Cacheable(cacheNames = { "flightRangeId", "isMarketingOperating", "cxrCode", "flightNumber", "saleDate",
			"travelDate" })
	public List<FlightRangeEntity> getAllFlightEntity(String flightRangeId, String isMarketingOperating, String cxrCode,
			String flightNumber, LocalDate saleDate, LocalDate travelDate) {
		return flightRangeRepository.getAllFlightEntity(flightNumber, saleDate, travelDate, cxrCode,
				isMarketingOperating, flightRangeId);
	}

	@Override
	public List<FlightRangeEntity> valiadateIssueDate(Integer flightRangeAutoId, LocalDate ticketedIssueDate,String clientId,
			String flag) {

		if (flag.equals("sale")) {
			return flightRangeRepository.findAll(
					Specification.where(FlightRangeEntitySpecification.equalsFlightRangeAutoId(flightRangeAutoId)
							.and(FlightRangeEntitySpecification.betweenSalesFromAndSalesToDate(ticketedIssueDate))
							.and(FlightRangeEntitySpecification.equalsCliendId(clientId))
							.and(FlightRangeEntitySpecification.isActive())));
		} else {
			return flightRangeRepository.findAll(
					Specification.where(FlightRangeEntitySpecification.equalsFlightRangeAutoId(flightRangeAutoId)
							.and(FlightRangeEntitySpecification.betweenTravelFromAndTravelToDate(ticketedIssueDate))
							.and(FlightRangeEntitySpecification.equalsCliendId(clientId))
							.and(FlightRangeEntitySpecification.isActive())));
		}
	}

	@Override
	public long getOverLapForCreate(Optional<String> clientId, Optional<String> flightRangeId,
			Optional<Integer> recordSeqNumber) {

		return 0;
	}

	@Override
	public int flightNumberVerifyIfOverlapExits(String fromFlightNumber, String toFlightNumber, String flightRangeId,
			String isMarketingOperating, String cxrCode) {
		return flightRangeRepository.flightNumberVerifyIfOverlapExits(fromFlightNumber, toFlightNumber, flightRangeId,
				isMarketingOperating, cxrCode);
	}

	@Override
	public int recordSeqNumberVerifyIfOverlapExits(String flightRangeId, String isMarketingOperating, String cxrCode,
			Integer recordSeqNumber) {
		return flightRangeRepository.recordSeqNumberVerifyIfOverlapExits(flightRangeId, isMarketingOperating, cxrCode,
				recordSeqNumber);
	}

	@Override
	public List<FlightRangeEntity> flightRangeUniqueKey(String clientId, String flightRangeId) {
		return flightRangeRepository.flightRangeUniqueKey(clientId, flightRangeId);
	}

	@Override
	public List<Integer> verifyIfSameSaleRecordExits(LocalDate saleFromDate, LocalDate saleToDate) {
		return flightRangeRepository.verifyIfSameSaleRecordExits(saleFromDate, saleToDate);
	}

	@Override
	public List<Integer> verifyIfSameTravelRecordExits(LocalDate travelFromDate, LocalDate travelToDate) {
		return flightRangeRepository.verifyIfSameTravelRecordExits(travelFromDate, travelToDate);
	}
}
