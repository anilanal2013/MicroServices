package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.master.app.dao.AgencyMasterDao;
import com.sgl.smartpra.master.app.dao.entity.AgencyMasterEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.AgencyMasterEntitySpec;
import com.sgl.smartpra.master.app.repository.AgencyMasterRepository;

@Component
public class AgencyMasterDaoImpl<T> extends CommonSearchDao<T> implements AgencyMasterDao {

	@Autowired
	private AgencyMasterRepository agencyMasterRepository;
	

	@Override
	@Cacheable(value = "agencyMaster", key = "#agencyId")
	public Optional<AgencyMasterEntity> findById(Integer agencyId) {
		return agencyMasterRepository.findById(agencyId);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "agencyMaster", key = "#agencyEntity.agencyId"),
			@CacheEvict(value = "agencyCode" ,allEntries = true),@CacheEvict(value = "clientId",allEntries = true)})
	public AgencyMasterEntity create(AgencyMasterEntity agencyEntity) {
		return agencyMasterRepository.save(agencyEntity);
	}

	@Override
	@CachePut(value = "agencyMaster", key = "#agencyEntity.agencyId")
	@Caching(evict = { @CacheEvict(value = "agencyCode",allEntries = true),@CacheEvict(value = "clientId",allEntries = true)})
	public AgencyMasterEntity update(AgencyMasterEntity agencyEntity) {
		return agencyMasterRepository.save(agencyEntity);
	}

	@Override
	public List<AgencyMasterEntity> getSearchAllAgency(Optional<String> hostCarrierDesigCode,
			Optional<String> agencyCode, Optional<String> reportingAgency, Optional<String> agencyType,
			Optional<String> areaOfOperation, Optional<String> reportingAgencyType, Optional<String> cityCode,
			Optional<String> countryCode, Optional<Boolean> activate) {

		return agencyMasterRepository
				.findAll(AgencyMasterEntitySpec.getSearchAllAgency(hostCarrierDesigCode, agencyCode, reportingAgency,
						agencyType, areaOfOperation, reportingAgencyType, cityCode, countryCode, activate));

	}

	@Override
	public List<AgencyMasterEntity> findAll(Optional<String> agencyCode, Optional<String> reportingAgency,
			Optional<String> agencyType, Optional<String> areaOfOperation, Optional<String> reportingAgencyType,
			Optional<Boolean> activate) {
		return agencyMasterRepository.findAll(AgencyMasterEntitySpec.search(agencyCode, reportingAgency, agencyType,
				areaOfOperation, reportingAgencyType, activate));

	}

	@Override
	public List<AgencyMasterEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return agencyMasterRepository
				.findAll((AgencyMasterEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(AgencyMasterEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(AgencyMasterEntitySpec.isActive())));
	}

	@Override
	public long getOverLapRecordCount(String clientId, String agencyCode) {
		return agencyMasterRepository.count(Specification.where(AgencyMasterEntitySpec.equalsClientId(clientId))
				.and(AgencyMasterEntitySpec.equalsAgencyCode(agencyCode)));

	}

	@Override
	public long getOverLapRecordCount(String clientId, String agencyCode, Integer agencyId) {
		return agencyMasterRepository.count(
				AgencyMasterEntitySpec.equalsClientId(clientId).and(AgencyMasterEntitySpec.equalsAgencyCode(agencyCode))
						.and(AgencyMasterEntitySpec.notEqualsAgencyDetailsId(agencyId)));

	}

	@Override
	public List<AgencyMasterEntity> getByAgencyCode(String agencyCode) {
		return agencyMasterRepository.findAll(AgencyMasterEntitySpec.getByAgencyCode(agencyCode));
	}

	@Override
	public Page<AgencyMasterEntity> getSearchAllAgency(AgencyMasterEntity agencyMasterEntity, Optional<String> exceptionCall, Pageable pageable) {
		return agencyMasterRepository.findAll(AgencyMasterEntitySpec.findAll(agencyMasterEntity, exceptionCall), pageable);

	}

	@Override
	public Long getCount(AgencyMasterEntity mapToEntity,Optional<String> exceptionCall) {
		return agencyMasterRepository.count(AgencyMasterEntitySpec.findAll(mapToEntity,exceptionCall));
	}

	@Override
	@Cacheable(cacheNames={"agencyCode","clientId"})
	public Optional<AgencyMasterEntity> getAgencyByAgencyCode(String agencyCode, String clientId) {
		 return  agencyMasterRepository.findOne(AgencyMasterEntitySpec.equalsAgencyCode(agencyCode)
				 .and(AgencyMasterEntitySpec.equalsClientId(clientId))
				 .and(AgencyMasterEntitySpec.isActive()));
		 
	}
}
