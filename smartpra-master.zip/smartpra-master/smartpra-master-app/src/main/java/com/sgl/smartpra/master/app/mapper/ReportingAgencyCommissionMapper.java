package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.ReportingAgencyCommissionEntity;
import com.sgl.smartpra.master.model.ReportingAgencyCommission;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ReportingAgencyCommissionMapper
		extends BaseMapper<ReportingAgencyCommission, ReportingAgencyCommissionEntity> {

	ReportingAgencyCommissionEntity mapToEntity(ReportingAgencyCommission reportingAgencyCommission,
			@MappingTarget ReportingAgencyCommissionEntity reportingAgencyCommissionEntity);

	@Mapping(source = "reportingAgencyCommId", target = "reportingAgencyCommId", ignore = true)
	ReportingAgencyCommissionEntity mapToEntity(ReportingAgencyCommission reportingAgencyCommission);
}
