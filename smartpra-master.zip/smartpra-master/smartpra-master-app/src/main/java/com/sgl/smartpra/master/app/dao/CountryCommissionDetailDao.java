package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.CountryCommissionDetailEntity;

public interface CountryCommissionDetailDao {
	
	public Optional<CountryCommissionDetailEntity> findById(Integer id);
	
	public CountryCommissionDetailEntity create(CountryCommissionDetailEntity countryCommissionDetail);
	
	public CountryCommissionDetailEntity update(CountryCommissionDetailEntity countryCommissionDetail);
	
	public List<CountryCommissionDetailEntity> searchCountryCommissionDetail(Optional<String> effectiveFromDate,
		Optional<String> effectiveToDate, Optional<String> countryCode, Optional<String> cabinClass);	

	Long getOverLapCount(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String countryCode, String cabinClass,String clientId, String netGrossFlag);
	
	public List<CountryCommissionDetailEntity> verifyIfSameRecordExits(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String countryCode, String cabinClass,String clientId, String netGrossFlag);	
	
	public List<CountryCommissionDetailEntity> searchCountryCommissionDetailByCountryCode(
			String issueDate, String countryCode);
}
