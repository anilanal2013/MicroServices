package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.CarrierAllianceDao;
import com.sgl.smartpra.master.app.dao.entity.CarrierAllianceEntity;
import com.sgl.smartpra.master.app.mapper.CarrierAllianceMapper;
import com.sgl.smartpra.master.app.service.CarrierAllianceService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.CarrierAllianceBaseModel;
import com.sgl.smartpra.master.model.ListOfValues;
import com.sgl.smartpra.master.model.OneWorldCarrierAlliance;

import lombok.extern.slf4j.Slf4j;

@Service(value = "CarrierAllianceService")
@Transactional
@Slf4j
public class CarrierAllianceServiceImpl implements CarrierAllianceService {

	@Autowired
	private ListOfValuesService listOfValuesService;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private CarrierAllianceUpdateService carrierAllianceUpdateService;

	@Autowired
	private CarrierAllianceCreateService carrierAllianceCreateService;

	@Autowired
	protected CarrierAllianceMapper carrierAllianceMapper;

	@Autowired
	protected CarrierAllianceDao carrierAllianceDao;

	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	private static final String CARRIER_ALLIANCE_LOV_COLUMN_VALUE = LOVEnum.ALLIANCE_NAME.getLOVEnum();

	private static final String ONE_WORLD_ALLIANCE_NAME = "OWC";
	protected static final String OVERLAP_COMBINATION_EXIST = "Record already exist";
	private static final String ONE_WORLD_API_USABLE_ERROR_MSG = "This API Can only be used for Creating OneWorld Alliance Object";
	private static final String ONE_WORLD_API_NOT_USABLE_ERROR_MSG = "This API cannot be used for Creating OneWorld Alliance Object";
	private static final String INACTIVE_CARRIER_ALLIANCE = "Given FOP record is not active";
	private static final String ACTIVE_CARRIER_ALLIANCE = "Given FOP record is already active";

	@Override
	public CarrierAlliance createCarrierAlliance(CarrierAlliance carrierAlliance) {
		validateAPIUsage(OptionalUtil.getValue(carrierAlliance.getAllianceName()), false);
		return carrierAllianceCreateService.createCarrierAlliance(carrierAlliance);
	}

	@Override
	public OneWorldCarrierAlliance createCarrierAlliance(OneWorldCarrierAlliance oneWorldCarrierAlliance) {
		validateAPIUsage(OptionalUtil.getValue(oneWorldCarrierAlliance.getAllianceName()), true);
		return carrierAllianceCreateService.createCarrierAlliance(oneWorldCarrierAlliance);
	}

	@Override
	public CarrierAlliance updateCarrierAlliance(CarrierAlliance carrierAlliance) {
		log.info("{}", carrierAlliance);
		CarrierAllianceEntity carrierAllianceEntity = carrierAllianceDao
				.findById(carrierAlliance.getCarrierAllianceDtlId()).orElseThrow(
						() -> new RecordNotFoundException(String.valueOf(carrierAlliance.getCarrierAllianceDtlId())));
		validateAPIUsage(getAllianceName(carrierAlliance, carrierAllianceEntity), false);
		return carrierAllianceUpdateService.updateCarrierAlliance(carrierAlliance, carrierAllianceEntity);
	}

	@Override
	public OneWorldCarrierAlliance updateCarrierAlliance(OneWorldCarrierAlliance oneWorldCarrierAlliance) {
		CarrierAllianceEntity carrierAllianceEntity = carrierAllianceDao
				.findById(oneWorldCarrierAlliance.getCarrierAllianceDtlId())
				.orElseThrow(() -> new RecordNotFoundException(
						String.valueOf(oneWorldCarrierAlliance.getCarrierAllianceDtlId())));
		validateAPIUsage(getAllianceName(oneWorldCarrierAlliance, carrierAllianceEntity), true);
		return carrierAllianceUpdateService.updateCarrierAlliance(oneWorldCarrierAlliance, carrierAllianceEntity);

	}

	@Override
	public CarrierAlliance getCarrierAllianceByCarrierAllianceDtlId(Integer carrierAllianceDtlId) {
		return carrierAllianceMapper.mapToModel(carrierAllianceDao.findById(carrierAllianceDtlId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(carrierAllianceDtlId))));
	}

	@Override
	public List<CarrierAlliance> search(String carrierCode, Optional<String> effectiveDate) {
		if (!OptionalUtil.isPresent(effectiveDate)) {
			return carrierAllianceMapper.mapToModel(carrierAllianceDao.search(carrierCode));
		} else {
			return carrierAllianceMapper
					.mapToModel(carrierAllianceDao.search(carrierCode, OptionalUtil.getLocalDateValue(effectiveDate)));
		}
	}

	@Override
	public List<CarrierAlliance> search(String allianceName, Optional<String> effectiveDate, String clientId) {
		if (OptionalUtil.isPresent(effectiveDate)) {
			return carrierAllianceMapper.mapToModel(
					carrierAllianceDao.search(allianceName, clientId, OptionalUtil.getLocalDateValue(effectiveDate)));
		} else {
			return carrierAllianceMapper.mapToModel(carrierAllianceDao.search(allianceName, clientId));
		}
	}

	@Override
	public List<CarrierAlliance> findAll(String clientId) {
		return carrierAllianceMapper.mapToModel(carrierAllianceDao.findAll(clientId));
	}

	@Override
	public void deactivateCarrierAlliance(CarrierAlliance carrierAlliance) {
		CarrierAllianceEntity carrierAllianceEntity = carrierAllianceDao
				.findById(carrierAlliance.getCarrierAllianceDtlId()).orElseThrow(
						() -> new RecordNotFoundException(String.valueOf(carrierAlliance.getCarrierAllianceDtlId())));

		if (!carrierAllianceEntity.getActivate()) {
			throw new BusinessException(INACTIVE_CARRIER_ALLIANCE);
		}

		carrierAllianceEntity.setActivate(Boolean.FALSE);

		carrierAllianceDao.update(carrierAllianceMapper.mapToEntity(carrierAlliance, carrierAllianceEntity));

	}

	@Override
	public void activateCarrierAlliance(CarrierAlliance carrierAlliance) {
		CarrierAllianceEntity carrierAllianceEntity = carrierAllianceDao
				.findById(carrierAlliance.getCarrierAllianceDtlId()).orElseThrow(
						() -> new RecordNotFoundException(String.valueOf(carrierAlliance.getCarrierAllianceDtlId())));

		if (carrierAllianceEntity.getActivate()) {
			throw new BusinessException(ACTIVE_CARRIER_ALLIANCE);
		}

		carrierAllianceEntity.setActivate(Boolean.TRUE);

		carrierAllianceDao.update(carrierAllianceMapper.mapToEntity(carrierAlliance, carrierAllianceEntity));

	}

	protected void validateCarrierDesignatorCode(CarrierAllianceBaseModel carrierAllianceBaseModel) {
		if (OptionalUtil.isPresent(carrierAllianceBaseModel.getClientId())) {
			String carrierDesignatorCode = OptionalUtil.getValue(carrierAllianceBaseModel.getClientId());
			if (!globalMasterFeignClient.isValidCarrierDesignatorCode(carrierDesignatorCode)) {
				throw new BusinessException("Invalid Client Id " + carrierDesignatorCode);
			}
		}
	}

	protected void validateCarrierCode(CarrierAllianceBaseModel carrierAllianceBaseModel) {
		if (OptionalUtil.isPresent(carrierAllianceBaseModel.getCarrierCode())) {
			String carrierCode = OptionalUtil.getValue(carrierAllianceBaseModel.getCarrierCode());
			if (!globalMasterFeignClient.validateCarrierCode(carrierCode)) {
				throw new BusinessException("Invalid Carrier code " + carrierCode);
			}
		}
	}

	protected void validateAllianceName(String clientId, String allianceName) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(CARRIER_ALLIANCE_LOV_COLUMN_VALUE));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(allianceName));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Alliance Name[" + allianceName + "] is Not Valid");
		}
	}

	protected void validateEffectiveToDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To Date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To Date[" + effectiveToDate
					+ "] should be greater than Effective From Date[" + effectiveFromDate + "]");
		}
	}

	protected String getAllianceName(CarrierAllianceBaseModel carrierAllianceBaseModel,
			CarrierAllianceEntity carrierAllianceEntity) {
		return OptionalUtil.isPresent(carrierAllianceBaseModel.getAllianceName())
				? OptionalUtil.getValue(carrierAllianceBaseModel.getAllianceName())
				: carrierAllianceEntity.getAllianceName();
	}

	private void validateAPIUsage(String allianceName, boolean isOneWorldAPI) {
		if (!isOneWorldAPI && ONE_WORLD_ALLIANCE_NAME.equalsIgnoreCase(allianceName)) {
			throw new BusinessException(ONE_WORLD_API_NOT_USABLE_ERROR_MSG);
		}

		if (isOneWorldAPI && !ONE_WORLD_ALLIANCE_NAME.equalsIgnoreCase(allianceName)) {
			throw new BusinessException(ONE_WORLD_API_USABLE_ERROR_MSG);
		}
	}

	@Override
	public List<CarrierAlliance> search(Optional<String> carrierCode, Optional<String> clientId,
			Optional<String> allianceName, Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return carrierAllianceMapper.mapToModel(
				carrierAllianceDao.search(carrierCode, clientId, allianceName, effectiveFromDate, effectiveToDate));
	}

	@Override
	public CarrierAlliance getAllianceByCarrierCodeAndEffectiveDate(String clientId,
			 String carrierCode, Optional<String> effectiveDate) {
		return carrierAllianceMapper.mapToModel(carrierAllianceDao.getAllianceByCarrierCodeAndEffectiveDate(clientId, carrierCode, effectiveDate)
				.orElseThrow(() -> new BusinessException("Record Not Found")));
	}

}
