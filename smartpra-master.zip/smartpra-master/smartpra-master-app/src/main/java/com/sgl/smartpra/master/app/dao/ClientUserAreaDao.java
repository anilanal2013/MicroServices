package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.ClientUserAreaEntity;

@Repository
public interface ClientUserAreaDao {

	List<ClientUserAreaEntity> search(Optional<String> userAreaCode, Optional<String> userAreaName,
			Optional<Boolean> activate);

	Optional<ClientUserAreaEntity> findById(Integer globalUserAreaId);

	public ClientUserAreaEntity update(ClientUserAreaEntity clientUserAreaEntity);

	public ClientUserAreaEntity create(ClientUserAreaEntity mapToEntity);

	public Optional<ClientUserAreaEntity> getOverLapRecordCount(String userAreaCode, String areaKey1, String areaKey2, String areaKey3,
			String areaKey4);

	public List<ClientUserAreaEntity> getClientUserArea(String userAreaCode, String areaKey1, String areaKey2, String areaKey3,
			String areaKey4,Boolean activate);
   
	
	
}
