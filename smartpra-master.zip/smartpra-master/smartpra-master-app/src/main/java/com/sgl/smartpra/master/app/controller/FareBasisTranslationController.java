package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.master.app.service.FareBasisTranslationService;
import com.sgl.smartpra.master.model.FareBasisTranslation;

@RestController
public class FareBasisTranslationController {

	@Autowired
	private FareBasisTranslationService fareBasisTranslationService;

	@PostMapping("/fare-basis-translations")
	public FareBasisTranslation createfareBasisTranslation(
			@Validated(Create.class) @RequestBody FareBasisTranslation fareBasisTranslation) {
		FareBasisTranslation createFareBasisTranslation = null;
		try {
			createFareBasisTranslation = fareBasisTranslationService.createFareBasisTranslation(fareBasisTranslation);
		} catch (DataIntegrityViolationException e) {
			throw new BusinessException("Record already exists");
		}
		return createFareBasisTranslation;
	}

	@GetMapping("/fare-basis-translations")
	public List<FareBasisTranslation> getAllfareBasisTranslation(
			@RequestParam(value = "marketingFareBasis", required = false) Optional<String> marketingFareBasis,
			@RequestParam(value = "marketingTD", required = false) Optional<String> marketingTD,
			@RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate,
			@RequestParam(value = "fareOwnerCXR", required = false) Optional<String> fareOwnerCXR) {
		return fareBasisTranslationService.getFareBasisTranslation(marketingFareBasis, marketingTD, fareOwnerCXR,
				effectiveDate);
	}

	@GetMapping("/fare-basis-translations/{fbtId}")
	public FareBasisTranslation getfareBasisTranslationByIscId(@PathVariable(value = "fbtId") Integer fbtId) {
		return fareBasisTranslationService.getFareBasisTranslationByFbtId(fbtId);
	}

	@PutMapping("/fare-basis-translations/{fbtId}")
	public FareBasisTranslation updatefareBasisTranslation(@PathVariable(value = "fbtId") Integer fbtId,
			@Validated(Update.class) @RequestBody FareBasisTranslation fareBasisTranslation) {
		FareBasisTranslation updateFareBasisTranslation = null;
		try {
			updateFareBasisTranslation = fareBasisTranslationService.updateFareBasisTranslation(fbtId,
					fareBasisTranslation);

		} catch (DataIntegrityViolationException e) {
			throw new BusinessException("Record already exists");
		}
		return updateFareBasisTranslation;
	}

	@PutMapping("/fare-basis-translations/{fbtId}/deactivate")
	public void deactivatefareBasisTranslation(@Valid @PathVariable(value = "fbtId") Integer fbtId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		fareBasisTranslationService.deactivateFareBasisTranslation(fbtId, lastUpdatedBy);
	}

	@PutMapping("/fare-basis-translations/{fbtId}/activate")
	public void activatefareBasisTranslation(@Valid @PathVariable(value = "fbtId") Integer fbtId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		fareBasisTranslationService.activateFareBasisTranslation(fbtId, lastUpdatedBy);
	}

	@GetMapping("/fbtMaster")
	public List<FareBasisTranslation> getAllfbtMaster(
			@RequestParam(value = "marketingFareBasis", required = false) Optional<String> marketingFareBasis,
			@RequestParam(value = "marketingTD", required = false) Optional<String> marketingTD,
			@RequestParam(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return fareBasisTranslationService.getFareBasisTranslation(marketingFareBasis, marketingTD, effectiveDate);
	}
	
	@GetMapping("/fbtMaster-clientId")
	public List<FareBasisTranslation> getAllfbtMasterSpecificClient(
			@RequestParam(value = "marketingFareBasis", required = false) Optional<String> marketingFareBasis,
			@RequestParam(value = "marketingTD", required = false) Optional<String> marketingTD,
			@RequestParam(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return fareBasisTranslationService.getAllfbtMasterSpecificClient(marketingFareBasis, marketingTD,clientId, effectiveDate);
	}

	@GetMapping("/fare-basis-translations/fbtPatternRecords")
	public List<FareBasisTranslation> getFBTByPattern() {
		return fareBasisTranslationService.getFBTIsPattern();
	}

}
