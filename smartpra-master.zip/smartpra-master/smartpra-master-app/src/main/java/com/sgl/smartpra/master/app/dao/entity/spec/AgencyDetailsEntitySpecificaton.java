package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.AgencyDetailsEntity;

public class AgencyDetailsEntitySpecificaton {
	public static Specification<AgencyDetailsEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), agencyDetailsEntity.get("effectiveFromDate"),
				agencyDetailsEntity.get("effectiveToDate"));

	}

	public static Specification<AgencyDetailsEntity> equalsAgencyCode(String agencyCode) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyDetailsEntity.get("agencyCode"), agencyCode);

	}

	public static Specification<AgencyDetailsEntity> equalsAgencyId(Integer agencyId) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyDetailsEntity.get("agencyId"), agencyId);

	}

	public static Specification<AgencyDetailsEntity> equalsReportingFrequency(String reportingFrequency) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyDetailsEntity.get("reportingFrequency"), reportingFrequency);

	}

	public static Specification<AgencyDetailsEntity> equalsTransactionCurrency(String transactionCurrency) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyDetailsEntity.get("transactionCurrency"), transactionCurrency);

	}

	public static Specification<AgencyDetailsEntity> equalsTransactionType(String transactionType) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyDetailsEntity.get("transactionType"), transactionType);

	}

	public static Specification<AgencyDetailsEntity> equalsClientId(String clientId) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyDetailsEntity.get("clientId"), clientId);

	}

	public static Specification<AgencyDetailsEntity> equalsReportingType(String reportingType) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyDetailsEntity.get("reportingType"), reportingType);

	}

	public static Specification<AgencyDetailsEntity> notEqualsAgencyDetailsId(Integer agencyDetailsId) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(agencyDetailsEntity.get("agencyDetailsId"), agencyDetailsId);

	}

	public static Specification<AgencyDetailsEntity> isActive() {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyDetailsEntity.get("activate"), true);
	}

	public static Specification<AgencyDetailsEntity> search(Optional<String> clientId, Optional<String> agencyCode,
			Optional<String> effectiveDate) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			predicates.add(
					criteriaBuilder.like(agencyDetailsEntity.get("clientId"), OptionalUtil.getValue(clientId) + "%"));
			predicates.add(
					criteriaBuilder.equal(agencyDetailsEntity.get("agencyCode"), OptionalUtil.getValue(agencyCode)));
			predicates
					.add(criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
							agencyDetailsEntity.get("effectiveFromDate"), agencyDetailsEntity.get("effectiveToDate")));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AgencyDetailsEntity> search(Optional<String> agencyCode, Optional<String> clientId,
			Optional<String> transactionType, Optional<String> reportingFrequency, Optional<String> transactionCurrency,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(agencyCode)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("agencyCode"),
						OptionalUtil.getValue(agencyCode) + "%"));
			}
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("clientId"),
						OptionalUtil.getValue(clientId) + "%"));
			}
			if (OptionalUtil.isPresent(transactionType)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("transactionType"),
						OptionalUtil.getValue(transactionType) + "%"));
			}
			if (OptionalUtil.isPresent(reportingFrequency)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("reportingFrequency"),
						OptionalUtil.getValue(reportingFrequency) + "%"));
			}
			if (OptionalUtil.isPresent(transactionCurrency)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("transactionCurrency"),
						OptionalUtil.getValue(transactionCurrency) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
						agencyDetailsEntity.get("effectiveFromDate"), agencyDetailsEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								agencyDetailsEntity.get("effectiveFromDate"),
								agencyDetailsEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							agencyDetailsEntity.get("effectiveFromDate"), agencyDetailsEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							agencyDetailsEntity.get("effectiveFromDate"), agencyDetailsEntity.get("effectiveToDate")));
				}
			}

			if (OptionalUtil.isPresent(activate)) {
				predicates.add(
						criteriaBuilder.equal(agencyDetailsEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(agencyDetailsEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AgencyDetailsEntity> searchAgencyDetailsByAgencyCode(Optional<String> clientId,
			Optional<String> agencyCode, Optional<String> effectiveDate) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(agencyCode)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("agencyCode"),
						OptionalUtil.getValue(agencyCode) + "%"));
			}
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("clientId"),
						OptionalUtil.getValue(clientId) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
						agencyDetailsEntity.get("effectiveFromDate"), agencyDetailsEntity.get("effectiveToDate")));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static void orderByAsc(Root<AgencyDetailsEntity> agencyDetailsEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(agencyDetailsEntity.get(orderByString)));
	}

	public static Specification<AgencyDetailsEntity> findByAgencyId(Integer agencyId, Optional<String> agencyCode,
			Optional<String> clientId, Optional<String> transactionType, Optional<String> reportingFrequency,
			Optional<String> transactionCurrency, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate,Optional<String> exceptionCall) {
		return (agencyDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (agencyId != null) {
				predicates.add(criteriaBuilder.equal(agencyDetailsEntity.get("agencyId"), agencyId));
			}
			if (OptionalUtil.isPresent(agencyCode)) {
				predicates.add(criteriaBuilder.equal(agencyDetailsEntity.get("agencyCode"),
						OptionalUtil.getValue(agencyCode)));
			}
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.equal(agencyDetailsEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(transactionType)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("transactionType"),
						OptionalUtil.getValue(transactionType) + "%"));
			}
			if (OptionalUtil.isPresent(reportingFrequency)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("reportingFrequency"),
						OptionalUtil.getValue(reportingFrequency) + "%"));
			}
			if (OptionalUtil.isPresent(transactionCurrency)) {
				predicates.add(criteriaBuilder.like(agencyDetailsEntity.get("transactionCurrency"),
						OptionalUtil.getValue(transactionCurrency) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
						agencyDetailsEntity.get("effectiveFromDate"), agencyDetailsEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								agencyDetailsEntity.get("effectiveFromDate"),
								agencyDetailsEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							agencyDetailsEntity.get("effectiveFromDate"), agencyDetailsEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							agencyDetailsEntity.get("effectiveFromDate"), agencyDetailsEntity.get("effectiveToDate")));
				}
			}
			if(!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (OptionalUtil.isPresent(activate)) {
					predicates.add(
							criteriaBuilder.equal(agencyDetailsEntity.get("activate"), OptionalUtil.getValue(activate)));
				}
				if (!OptionalUtil.isPresent(activate)) {
					predicates.add(criteriaBuilder.equal(agencyDetailsEntity.get("activate"), true));
				}
			}
			orderByAsc(agencyDetailsEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
