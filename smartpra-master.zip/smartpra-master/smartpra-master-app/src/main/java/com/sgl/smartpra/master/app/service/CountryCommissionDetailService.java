package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.CountryCommissionDetail;

public interface CountryCommissionDetailService {
	
	public CountryCommissionDetail create(CountryCommissionDetail countryCommissionDetail);
	
	public CountryCommissionDetail update(CountryCommissionDetail countryCommissionDetail);
	
	public List<CountryCommissionDetail> findAll(Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> countryCode, Optional<String> cabinClass);
	
	public void activate(Integer countryCommissionDetailId);
	
	public void deactivate(Integer countryCommissionDetailId);

	public CountryCommissionDetail getCountryCommissionDetailById (Integer countryCommissionDetailId);
	
	public List<CountryCommissionDetail> getCountryCommissionDetailByCountryCode(String issueDate,
			String countryCode);

}
