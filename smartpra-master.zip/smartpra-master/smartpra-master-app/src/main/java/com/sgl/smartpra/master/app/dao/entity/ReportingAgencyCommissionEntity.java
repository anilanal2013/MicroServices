package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_reporting_agency_comm database table.
 * 
 */
@Entity
@Table(name = "mas_reporting_agency_comm")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class ReportingAgencyCommissionEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "reporting_agency_comm_id")
	private Integer reportingAgencyCommId;

	@Column(name = "agency_id")
	private Integer agencyId;

	@Column(name = "client_id", nullable = false)
	private String clientId;

	@Column(name = "reporting_agency", nullable = false)
	private String reportingAgency;

	@Column(name = "agency_code", nullable = false)
	private String agencyCode;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;

	@Column(name = "orc_currency", nullable = false)
	private String orcCurrency;

	@Column(name = "fare_orc_perc_own", nullable = false)
	private Double fareOrcPercOwn;

	@Column(name = "fare_orc_perc_oal", nullable = false)
	private Double fareOrcPercOal;

	@Column(name = "surcharge_orc_perc_own")
	private Double surchargeOrcPercOwn;

	@Column(name = "surcharge_orc_perc_oal")
	private Double surchargeOrcPercOal;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
