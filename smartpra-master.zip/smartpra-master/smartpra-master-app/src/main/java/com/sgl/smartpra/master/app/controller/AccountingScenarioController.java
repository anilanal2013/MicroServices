package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.AccountingScenarioService;
import com.sgl.smartpra.master.model.AccountingScenario;

@RestController
@RequestMapping("/accounting-scenario")
public class AccountingScenarioController {

	@Autowired
	private AccountingScenarioService accountingScenarioService;

	@PostMapping
	@ResponseStatus(value = HttpStatus.CREATED)
	public AccountingScenario createAccountingScenario(
			@Validated(Create.class) @RequestBody AccountingScenario accountingScenario) {
		return accountingScenarioService.createAccountingScenario(accountingScenario);
	}

	@PutMapping("/{scenarioNumber}")
	@ResponseStatus(value = HttpStatus.OK)
	public AccountingScenario updateProvisoCodeshare(@PathVariable(value = "scenarioNumber") Integer scenarioNumber,
			@Validated(Update.class) @RequestBody AccountingScenario accountingScenario) {
		return accountingScenarioService.updateAccountingScenario(scenarioNumber, accountingScenario);
	}

	@GetMapping("/{scenarioNumber}")
	public AccountingScenario getAccountingScenarioByScenarioNumber(
			@PathVariable(value = "scenarioNumber") Integer scenarioNumber) {
		return accountingScenarioService.getAccountingScenarioByScenarioNumber(scenarioNumber);
	}

	@GetMapping
	public List<AccountingScenario> getSearchAllAccountingScenario(
			@RequestParam(value = "transactionType", required = false) String transactionType,
			@RequestParam(value = "selfOalIndicator", required = false) String selfOalIndicator,
			@RequestParam(value = "salesExistIndicator", required = false) Boolean salesExistIndicator,
			@RequestParam(value = "docType", required = false) String docType,
			@RequestParam(value = "chargeCatCode", required = false) String chargeCatCode,
			@RequestParam(value = "chargeCode", required = false) String chargeCode) {
		return accountingScenarioService.getSearchAllAccountingScenario(transactionType, selfOalIndicator,
				salesExistIndicator, docType, chargeCatCode, chargeCode);
	}

	@GetMapping("/search")
	public List<AccountingScenario> getSearchAllAccountingScenarioWithIsActiveParam(
			@RequestParam(value = "module", required = false) String module,
			@RequestParam(value = "transactionType", required = false) String transactionType,
			@RequestParam(value = "selfOalIndicator", required = false) String selfOalIndicator,
			@RequestParam(value = "salesExistIndicator", required = false) Boolean salesExistIndicator,
			@RequestParam(value = "docType", required = false) String docType,
			@RequestParam(value = "chargeCatCode", required = false) String chargeCatCode,
			@RequestParam(value = "chargeCode", required = false) String chargeCode,
			@RequestParam(value = "isActive", required = false) Boolean isActive) {
		return accountingScenarioService.getSearchAllAccountingScenarioWithIsActiveParam(module,transactionType,
				selfOalIndicator, salesExistIndicator, docType, chargeCatCode, chargeCode, isActive);
	}

	@PutMapping("/active/{scenarioNumber}")
	public void activateAccountingScenario(@Valid @PathVariable(value = "scenarioNumber") Integer scenarioNumber,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		AccountingScenario accountingScenario = new AccountingScenario();
		accountingScenario.setScenarioNumber(scenarioNumber);
		accountingScenario.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		accountingScenarioService.activateAccountingScenario(accountingScenario);
	}

	@PutMapping("/inactive/{scenarioNumber}")
	public void deactivateAccountingScenario(@Valid @PathVariable(value = "scenarioNumber") Integer scenarioNumber,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		AccountingScenario accountingScenario = new AccountingScenario();
		accountingScenario.setScenarioNumber(scenarioNumber);
		accountingScenario.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		accountingScenarioService.deactivateAccountingScenario(accountingScenario);
	}
}
