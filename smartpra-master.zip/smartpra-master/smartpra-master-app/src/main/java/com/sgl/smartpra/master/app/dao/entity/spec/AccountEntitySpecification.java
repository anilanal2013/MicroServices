package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.AccountEntity;
import com.sgl.smartpra.master.app.repository.entity.POSEntity;
import com.sgl.smartpra.master.model.AccountModel;

public class AccountEntitySpecification {

	private static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";

	private static final String EFFECTIVE_TO_DATE = "effectiveToDate";

	public static Specification<AccountEntity> equalsClientId(String clientId) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("clientId"),
				clientId);
	}

	public static Specification<AccountEntity> equalsAccountAlphaCode(String accountAlphaCode) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("accountAlphaCode"), accountAlphaCode);
	}

	public static Specification<AccountEntity> equalsAccountNumCode(String accountNumCode) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("accountNumCode"), accountNumCode);
	}

	public static Specification<AccountEntity> equalsAccountType(String accountType) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("accountType"), accountType);
	}

	public static Specification<AccountEntity> equalsAttribute8(String attribute8) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("attribute8"),
				attribute8);
	}

	public static Specification<AccountEntity> equalsAttribute1(String attribute1) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("attribute1"),
				attribute1);
	}

	public static Specification<AccountEntity> equalsAttribute2(String attribute2) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("attribute2"),
				attribute2);
	}

	public static Specification<AccountEntity> equalsAttribute3(String attribute3) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("attribute3"),
				attribute3);
	}

	public static Specification<AccountEntity> equalsAttribute4(String attribute4) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("attribute4"),
				attribute4);
	}

	public static Specification<AccountEntity> equalsAttribute5(String attribute5) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("attribute5"),
				attribute5);
	}

	public static Specification<AccountEntity> equalsAttribute6(String attribute6) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("attribute6"),
				attribute6);
	}

	public static Specification<AccountEntity> equalsAttribute7(String attribute7) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("attribute7"),
				attribute7);
	}

	public static Specification<AccountEntity> equalsAttribute9(String attribute9) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(accountEntity.get("attribute9"),
				attribute9);
	}

	public static Specification<AccountEntity> equalsAttribute10(String attribute10) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute10"), attribute10);
	}

	public static Specification<AccountEntity> equalsAttribute11(String attribute11) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute11"), attribute11);
	}

	public static Specification<AccountEntity> equalsAttribute14(String attribute14) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute14"), attribute14);
	}

	public static Specification<AccountEntity> equalsAttribute19(String attribute19) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute19"), attribute19);
	}

	public static Specification<AccountEntity> equalsAttribute17(String attribute17) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute17"), attribute17);
	}

	public static Specification<AccountEntity> equalsAttribute20(String attribute20) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute20"), attribute20);
	}

	public static Specification<AccountEntity> equalsAttribute18(String attribute18) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute18"), attribute18);
	}

	public static Specification<AccountEntity> equalsAttribute16(String attribute16) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute16"), attribute16);
	}

	public static Specification<AccountEntity> equalsAttribute15(String attribute15) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute15"), attribute15);
	}

	public static Specification<AccountEntity> equalsAttribute13(String attribute13) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute13"), attribute13);
	}

	public static Specification<AccountEntity> equalsAttribute12(String attribute12) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountEntity.get("attribute12"), attribute12);
	}

	public static Specification<AccountEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), accountEntity.get(EFFECTIVE_FROM_DATE),
				accountEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<AccountEntity> greaterThanOrEqualTo(LocalDate effectiveFromDate) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(accountEntity.get(EFFECTIVE_FROM_DATE), effectiveFromDate);
	}

	public static Specification<AccountEntity> lessThanOrEqualTo(LocalDate effectiveToDate) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(accountEntity.get(EFFECTIVE_TO_DATE), effectiveToDate);
	}

	public static Specification<AccountEntity> notEqualsAccountAlphaCodeId(Integer accountAlphaCodeId) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(accountEntity.get("accountAlphaCodeId"), accountAlphaCodeId);
	}

	private static void orderByAsc(Root<AccountEntity> accountEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String effectiveToDate) {
		criteriaQuery.orderBy(criteriaBuilder.asc(accountEntity.get(effectiveToDate)));
	}

	public static Specification<AccountEntity> search(AccountModel accountModel) {
		return (accountEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(accountModel.getAccountAlphaCode())) {
				predicates.add(criteriaBuilder.like(accountEntity.get("accountAlphaCode"),
						OptionalUtil.getValue(accountModel.getAccountAlphaCode()) + "%"));
			}
			if (OptionalUtil.isPresent(accountModel.getAccountNumCode())) {
				predicates.add(criteriaBuilder.like(accountEntity.get("accountNumCode"),
						OptionalUtil.getValue(accountModel.getAccountNumCode()) + "%"));
			}
			if (OptionalUtil.isPresent(accountModel.getAccountType())) {
				predicates.add(criteriaBuilder.like(accountEntity.get("accountType"),
						OptionalUtil.getValue(accountModel.getAccountType()) + "%"));
			}

			if (OptionalUtil.isPresent(accountModel.getClientId())) {
				predicates.add(criteriaBuilder.like(accountEntity.get("clientId"),
						OptionalUtil.getValue(accountModel.getClientId()) + "%"));
			}
			if (OptionalUtil.isPresent(accountModel.getEffectiveFromDate())
					&& OptionalUtil.isPresent(accountModel.getEffectiveToDate())) {
				predicates
						.add(criteriaBuilder.or(
								criteriaBuilder.between(
										criteriaBuilder.literal(
												OptionalUtil.getLocalDateValue(accountModel.getEffectiveFromDate())),
										accountEntity.get(EFFECTIVE_FROM_DATE), accountEntity.get(EFFECTIVE_TO_DATE)),
								criteriaBuilder.between(
										criteriaBuilder.literal(
												OptionalUtil.getLocalDateValue(accountModel.getEffectiveToDate())),
										accountEntity.get(EFFECTIVE_FROM_DATE), accountEntity.get(EFFECTIVE_TO_DATE)),
								criteriaBuilder.between(accountEntity.get(EFFECTIVE_FROM_DATE),
										OptionalUtil.getLocalDateValue(accountModel.getEffectiveFromDate()),
										OptionalUtil.getLocalDateValue(accountModel.getEffectiveToDate())),
								criteriaBuilder.between(accountEntity.get(EFFECTIVE_TO_DATE),
										OptionalUtil.getLocalDateValue(accountModel.getEffectiveFromDate()),
										OptionalUtil.getLocalDateValue(accountModel.getEffectiveToDate()))));

			} else {
				if (OptionalUtil.isPresent(accountModel.getEffectiveFromDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder
									.literal(OptionalUtil.getLocalDateValue(accountModel.getEffectiveFromDate())),
							accountEntity.get(EFFECTIVE_FROM_DATE), accountEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(accountModel.getEffectiveToDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(accountModel.getEffectiveToDate())),
							accountEntity.get(EFFECTIVE_FROM_DATE), accountEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			orderByAsc(accountEntity, criteriaQuery, criteriaBuilder, EFFECTIVE_TO_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
