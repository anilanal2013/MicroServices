package com.sgl.smartpra.master.app;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.sgl.smartpra.exceptions.enums.ErrorTypeEnum;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.ConstraintValidationException;
import com.sgl.smartpra.exceptions.exception.RecordAlreadyExistsException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.exceptions.response.ErrorResponseDTO;

@org.springframework.web.bind.annotation.ControllerAdvice
public class ControllerAdvice {

	@Autowired
	private HttpServletRequest httpServletRequest;

	@ExceptionHandler(RecordNotFoundException.class)
	public ResponseEntity<ErrorResponseDTO> handle(final RecordNotFoundException recordNotFoundException) {
		return buildResponseEntity(recordNotFoundException, ErrorTypeEnum.TECHNICAL, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(RecordAlreadyExistsException.class)
	public ResponseEntity<ErrorResponseDTO> handle(final RecordAlreadyExistsException recordAlreadyExistsException) {
		return buildResponseEntity(recordAlreadyExistsException, ErrorTypeEnum.TECHNICAL, HttpStatus.CONFLICT);
	}

	@ExceptionHandler(BusinessException.class)
	public ResponseEntity<ErrorResponseDTO> handle(final BusinessException businessException) {
		return buildResponseEntity(businessException, ErrorTypeEnum.BUSINESS, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(value = InvalidFormatException.class)
	private ResponseEntity<?> handle(InvalidFormatException invalidFormatException) {
		return new ResponseEntity<>(
				new ErrorResponseDTO(Arrays.asList(invalidFormatException.getOriginalMessage()),
						ErrorTypeEnum.TECHNICAL, httpServletRequest.getRequestURI(), LocalDateTime.now()),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(value = HttpMessageNotReadableException.class)
	private ResponseEntity<?> handle(HttpMessageNotReadableException httpMessageNotReadableException) {
		return new ResponseEntity<>(
				new ErrorResponseDTO(Arrays.asList(httpMessageNotReadableException.getMostSpecificCause().getMessage()),
						ErrorTypeEnum.TECHNICAL, httpServletRequest.getRequestURI(), LocalDateTime.now()),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(value = ConstraintValidationException.class)
	private ResponseEntity<?> handle(ConstraintValidationException constraintValidationException) {
		List<String> errorMessageList = new ArrayList<>();
		constraintValidationException.getConstraintViolations()
				.forEach(constraintViolationError -> errorMessageList.add(constraintViolationError.getMessage()));
		return new ResponseEntity<>(new ErrorResponseDTO(Arrays.asList(constraintValidationException.getMessage()),
				ErrorTypeEnum.TECHNICAL, httpServletRequest.getRequestURI(), LocalDateTime.now()),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handle(final MethodArgumentNotValidException methodArgumentNotValidException) {
		List<String> errorMessageList = new ArrayList<>();
		methodArgumentNotValidException.getBindingResult().getFieldErrors().forEach(
				fieldError -> errorMessageList.add(fieldError.getField() + ": " + fieldError.getDefaultMessage()));
		return new ResponseEntity<>(new ErrorResponseDTO(errorMessageList, ErrorTypeEnum.TECHNICAL,
				httpServletRequest.getRequestURI(), LocalDateTime.now()), HttpStatus.BAD_REQUEST);

	}

	@ExceptionHandler(value = DataIntegrityViolationException.class)
	private ResponseEntity<?> handle(DataIntegrityViolationException dataIntegrityViolationException) {
		return new ResponseEntity<>(
				new ErrorResponseDTO(
						Arrays.asList(Optional.ofNullable(dataIntegrityViolationException.getMostSpecificCause())
								.orElse(dataIntegrityViolationException.getRootCause()).getMessage()),
						ErrorTypeEnum.TECHNICAL, httpServletRequest.getRequestURI(), LocalDateTime.now()),
				HttpStatus.BAD_REQUEST);
	}

	private ResponseEntity<ErrorResponseDTO> buildResponseEntity(Exception exception, ErrorTypeEnum errorTypeEnum,
			HttpStatus httpStatus) {
		return new ResponseEntity<>(new ErrorResponseDTO(Arrays.asList(exception.getMessage()), errorTypeEnum,
				httpServletRequest.getRequestURI(), LocalDateTime.now()), httpStatus);
	}

}
