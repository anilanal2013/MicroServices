package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.InterlineServiceChargeEntity;

@Repository
public interface InterlineServiceChargeDao {

	Optional<InterlineServiceChargeEntity> findById(Integer iscId);

	List<InterlineServiceChargeEntity> search(Optional<String> documentType, Optional<String> iscRecordType,
			Optional<String> issueCxr, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> billingCxr, Optional<Boolean> activate);

	InterlineServiceChargeEntity create(InterlineServiceChargeEntity mapToEntity);

	InterlineServiceChargeEntity update(InterlineServiceChargeEntity mapToEntity);

	List<InterlineServiceChargeEntity> verifyIfOverlapForUtilDateExists(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate);

	long getOverLapRecordCount(String clientId, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> documentType, Optional<String> settlementIndicator, Optional<String> iscRecordType,
			String issueCxr, String billingCxr, String salesSource, String pointOfSale, String travelFromArea,
			String travelToArea, String couponFromArea, String couponToArea, String flightRangeId, String fbGroupCode);

	long getOverLapRecordCount(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String documentType, String settlementIndicator, String iscRecordType, String issueCxr, String billingCxr,
			String salesSource, String pointOfSale, String travelFromArea, String travelToArea, String couponFromArea,
			String couponToArea, String flightRangeId, String fbGroupCode, Integer iscId);

	// Added new parameters
	List<InterlineServiceChargeEntity> searchISC(Optional<String> documentType, Optional<String> iscRecordType,
			Optional<String> effectiveFromDate, Optional<String> settlementIndicator, Optional<String> clientId,
			Optional<String> issueCxr, Optional<String> billingCxr);

}