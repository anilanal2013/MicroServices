package com.sgl.smartpra.master.app.controller;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.repository.entity.OutwardBillingPeriodsEntity;
import com.sgl.smartpra.master.app.service.OutwardBillingPeriodsService;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;

@RestController
public class OutwardBillingPeriodsController {

	@Autowired
	OutwardBillingPeriodsService outwardBillingPeriodsService;

	public static final String CHECKBILLINGPERIOD = "The given billingPeriod is not a valid one and it should be an integer";

	@PostMapping("/billing-period")
	public OutwardBillingPeriods createOutwardBillingPeriods(
			@Validated(Create.class) @RequestBody OutwardBillingPeriods outwardBillingPeriods) {
		return outwardBillingPeriodsService.createOutwardBillingPeriods(outwardBillingPeriods);
	}

	@PutMapping("/billing-period/{outwardBillingId}")
	public OutwardBillingPeriods updateOutwardBillingPeriods(
			@PathVariable(value = "outwardBillingId") Integer outwardBillingId,
			@Validated(Update.class) @RequestBody OutwardBillingPeriods outwardBillingPeriods) {

		return outwardBillingPeriodsService.updateOutwardBillingPeriods(outwardBillingId, outwardBillingPeriods);
	}

	@GetMapping("/billing-period/billing-month-period/{billingMonth}/{billingPeriod}")
	public List<OutwardBillingPeriodsEntity> getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriod(
			@PathVariable(value = "billingMonth", required = true) String billingMonth,
			@PathVariable(value = "billingPeriod", required = true) Integer billingPeriod) {
		return outwardBillingPeriodsService.getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriod(billingMonth,
				billingPeriod);
	}

	@GetMapping("/billing-period/billing-month-periods/{billingMonth}/{billingPeriod}")
	public List<OutwardBillingPeriods> getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriodV(
			@PathVariable(value = "billingMonth", required = true) String billingMonth,
			@PathVariable(value = "billingPeriod", required = true) Integer billingPeriod) {
		return outwardBillingPeriodsService.getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriodV(billingMonth,
				billingPeriod);
	}

	@GetMapping("/billing-period/billing-month")
	public List<OutwardBillingPeriodsEntity> getOutwardBillingPeriodsUsingBillingMonth(
			@RequestParam(value = "billingMonth", required = true) String billingMonth,
			@RequestParam(value = "billingPeriod", required = false) Integer billingPeriod) {
		return outwardBillingPeriodsService.getOutwardBillingPeriodsUsingBillingMonth(billingMonth, billingPeriod);
	}

	@GetMapping("/billing-period/latest-closed")
	public OutwardBillingPeriodsEntity getLatestClosedOutwardBillingPeriods() {
		return outwardBillingPeriodsService.getLatestClosedOutwardBillingPeriods();
	}

	@GetMapping("/billing-period/current-open")
	public OutwardBillingPeriods getCurrentOpenOutwardBillingPeriods(
			@RequestParam(value = "clientId", required = false) String clientId) {
		if (StringUtils.isNotBlank(clientId)) {
			return outwardBillingPeriodsService.getCurrentOpenOutwardBillingPeriodsByClientId(clientId);
		} else {
			return outwardBillingPeriodsService.getCurrentOpenOutwardBillingPeriods();
		}
	}

	@GetMapping("/billing-period/{date}")
	public OutwardBillingPeriodsEntity getOutwardBillingPeriodsUsingDate(@PathVariable(value = "date") String date) {
		return outwardBillingPeriodsService.getOutwardBillingPeriodsUsingDate(date);
	}

	@GetMapping("/billing-period/start-date/{billingMonth}/{billingPeriod}")
	public LocalDate getOutwardBillingPeriodsStartDate(@PathVariable(value = "billingMonth") String billingMonth,
			@PathVariable(value = "billingPeriod") Integer billingPeriod) {
		return outwardBillingPeriodsService.getOutwardBillingPeriodsStartDate(billingPeriod, billingMonth);
	}

	@GetMapping("/billing-period/end-date/{billingMonth}/{billingPeriod}")
	public LocalDate getOutwardBillingPeriodsEndDate(@PathVariable(value = "billingMonth") String billingMonth,
			@PathVariable(value = "billingPeriod") Integer billingPeriod) {
		return outwardBillingPeriodsService.getOutwardBillingPeriodsEndDate(billingPeriod, billingMonth);
	}

	@GetMapping("/billing-period/previous-billing-period/{billingMonth}/{billingPeriod}")
	public OutwardBillingPeriodsEntity getPreviousOutwardBillingPeriodsUsingBillingPeriod(
			@PathVariable(value = "billingPeriod") Integer billingPeriod,
			@PathVariable(value = "billingMonth") String billingMonth) {
		return outwardBillingPeriodsService.getPreviousOutwardBillingPeriodsUsingBillingPeriod(billingPeriod,
				billingMonth);
	}

	@GetMapping("/billing-period/next-billing-period/{billingMonth}/{billingPeriod}")
	public OutwardBillingPeriodsEntity getNextOutwardBillingPeriodsUsingBillingPeriod(
			@PathVariable(value = "billingPeriod") Integer billingPeriod,
			@PathVariable(value = "billingMonth") String billingMonth) {
		return outwardBillingPeriodsService.getNextOutwardBillingPeriodsUsingBillingPeriod(billingPeriod, billingMonth);
	}

	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(NumberFormatException.class)
	public String handleNoFormatException(NumberFormatException ex) {
		return CHECKBILLINGPERIOD;
	}

}
