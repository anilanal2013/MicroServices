package com.sgl.smartpra.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sgl.smartpra.master.app.dao.entity.CountryCommissionDetailEntity;

public interface CountryCommissionDetailRepository extends JpaRepository<CountryCommissionDetailEntity, Integer>, 
	JpaSpecificationExecutor<CountryCommissionDetailEntity>{
	
	

}
