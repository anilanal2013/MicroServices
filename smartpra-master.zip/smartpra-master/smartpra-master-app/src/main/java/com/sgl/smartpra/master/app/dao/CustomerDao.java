package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.CustomerEntity;
import com.sgl.smartpra.master.model.Customer;

@Repository
public interface CustomerDao {
	public Optional<CustomerEntity> findById(Integer id);

	public Optional<CustomerEntity> findOne(Integer id);

	public CustomerEntity create(CustomerEntity customerEntity);

	public CustomerEntity update(CustomerEntity customerEntity);

	public void delete(Integer id);

	public List<CustomerEntity> search(Customer customer, Optional<String> exceptionCall);

	public long getOverlapRecordCountForCreate(String customerType, String fopCode, String subFopCode, String lpoNumber,
			String debtorCode, String customerCode, String agencyCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate);

	public long getOverlapRecordCountForUpdate(String agencyCode,String customerType, String fopCode, String subFopCode, String lpoNumber,
			String debtorCode, String customerCode, Integer customerMasId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate);

}
