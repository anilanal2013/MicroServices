package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.SPAHeaderStgEntity;
import com.sgl.smartpra.master.model.SPAHeaderStg;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SPAHeaderStgMapper extends BaseMapper<SPAHeaderStg, SPAHeaderStgEntity> {
	SPAHeaderStgEntity mapToEntity(SPAHeaderStg spaHeaderStg, @MappingTarget SPAHeaderStgEntity spaHeaderStgEntity);
	@Mapping(source = "spaHeaderId", target = "spaHeaderId", ignore = true)
	SPAHeaderStgEntity mapToEntity(SPAHeaderStg spaHeaderStg);
}
