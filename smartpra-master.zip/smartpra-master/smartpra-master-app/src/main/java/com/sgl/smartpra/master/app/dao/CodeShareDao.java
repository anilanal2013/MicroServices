package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.app.dao.entity.CodeShareEntity;

public interface CodeShareDao {

	public CodeShareEntity create(CodeShareEntity codeShareEntity);

	public Optional<CodeShareEntity> findById(Integer id);

	public CodeShareEntity update(CodeShareEntity codeShareEntity);

	public List<CodeShareEntity> findAll(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> travelFromDate, Optional<String> travelToDate, Optional<String> saleFromDate,
			Optional<String> saleToDate, Optional<Boolean> isActive);

	public List<CodeShareEntity> search(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> marketedRBDList, Optional<String> effectiveDate);

	public long saleVerifyIfOverlapExits(LocalDate saleFromDate, LocalDate saleToDate);

	public long travelVerifyIfOverlapExits(LocalDate travelFromDate, LocalDate travelToDate);

 //	public long overlappingCXRWithFlightNumber(String marketingCXR, Integer fromBookedFlightNumber,
//			Integer toBookedFlightNumber, LocalDate saleFromDate, LocalDate saleToDate, LocalDate travelFromDate,
//			LocalDate travelToDate, String clientId);
	
	public long overlappingCXRWithFlightNumber(Optional<String> marketingCXR, Optional<String> fromBookedFlightNumber,
			Optional<String> toBookedFlightNumber, Optional<String> saleFromDate, Optional<String> saleToDate, Optional<String> travelFromDate,
			Optional<String> travelToDate, Optional<Integer> codeShareId,Optional<String> clientId);

	public Optional<CodeShareEntity> findByCodeShareId(Integer codeShareId);

	public Optional<CodeShareEntity> getCodeShareBymarketingCXRForBSP(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> marketedRBDList, Optional<String> effectiveDate, Optional<String> flightNumber);

	//public long overlappingCXRWithFlightNumberForUpdate(String marketingCXR, Integer fromBookedFlightNumber,
	//		Integer toBookedFlightNumber, LocalDate saleFromDate, LocalDate saleToDate, LocalDate travelFromDate,
	//		LocalDate travelToDate, String clientId, Integer codeShareId);
}
