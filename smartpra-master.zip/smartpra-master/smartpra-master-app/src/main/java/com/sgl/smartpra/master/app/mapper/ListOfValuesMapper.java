package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.ListOfValuesEntity;
import com.sgl.smartpra.master.model.ListOfValues;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ListOfValuesMapper extends BaseMapper<ListOfValues, ListOfValuesEntity>{

	ListOfValuesEntity mapToEntity(ListOfValues listOfValues,  @MappingTarget ListOfValuesEntity listOfValuesEntity );
	
	@Mapping(source = "lovId", target = "lovId", ignore = true)
	ListOfValuesEntity mapToEntity(ListOfValues listOfValues);
	
}
