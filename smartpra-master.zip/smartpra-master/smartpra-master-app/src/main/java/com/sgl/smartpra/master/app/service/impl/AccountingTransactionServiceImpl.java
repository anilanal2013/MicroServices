package com.sgl.smartpra.master.app.service.impl;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.dao.AccountDao;
import com.sgl.smartpra.master.app.dao.AccountingDefinitionDao;
import com.sgl.smartpra.master.app.dao.AccountingTransactionDao;
import com.sgl.smartpra.master.app.dao.entity.AccountingTransactionEntity;
import com.sgl.smartpra.master.app.mapper.AccountingTransactionMapper;
import com.sgl.smartpra.master.app.service.AccountingTransactionService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.AccountingTransaction;

@Service
@Transactional
public class AccountingTransactionServiceImpl implements AccountingTransactionService {
	public static final String ACCOUNTINGTRANSACTION_LOV_TABLE_VALUE1 = LOVEnum.TABLENAME.getLOVEnum();
	public static final String DEBITCREDITINDICATOR_LOV_COLUMN_VALUE1 = LOVEnum.DEBITCREDITINDICATOR.getLOVEnum();
	public static final String BALANCEFLAG_LOV_COLUMN_VALUE2 = LOVEnum.BALANCEFLAG.getLOVEnum();
	public static final String OVERLAP_COMBINATION_EXIST = "Record Already Exits";
	private static final String ACTIVE_ACCOUNTING_TRANSACTION = "Given Accounting Transaction record is already active";
	public static final String ACCOUNTING_TRANSACTION_ALREADY_INACTIVE = "Accounting Transaction is already in deactive state";
	@Autowired
	private AccountingTransactionDao accountingTransactionDao;

	@Autowired
	private AccountingTransactionMapper accountingTransactionMapper;

	@Autowired
	private ListOfValuesService listOfValuesService;

	@Autowired
	private AccountingDefinitionDao accountingDefinitionDao;

	@Autowired
	private AccountDao accountDao;

	@Override
	public AccountingTransaction crerateAccountingTransaction(AccountingTransaction accountingTransaction) {
		validateBusinessConstraintsForCreate(accountingTransaction);

		return accountingTransactionMapper.mapToModel(
				accountingTransactionDao.create(accountingTransactionMapper.mapToEntity(accountingTransaction)));
	}

	private void validateBusinessConstraintsForCreate(AccountingTransaction accountingTransaction) {
		validateOverlapForCreate(accountingTransaction);
		validatedebitCreditIndicatorLOVValidation(accountingTransaction);
		validateBalanceFlagLOVValidation(accountingTransaction);
		validateAccountDefinitionIdentifierValidation(accountingTransaction);
		validateAccountAlphaCodeValidation(accountingTransaction);
		validateProvisionalAccountCodeValidation(accountingTransaction);
	}

	private void validateProvisionalAccountCodeValidation(AccountingTransaction accountingTransaction) {
		List<String> listOfAccountAlphaCodeValues = accountDao.getAccountAlphaCodeFromAccountMaster();
		if (OptionalUtil.isPresent(accountingTransaction.getProvisionalAccountCode()) && !(listOfAccountAlphaCodeValues
				.contains(OptionalUtil.getValue(accountingTransaction.getProvisionalAccountCode())))) {
			throw new BusinessException("Invalid Provisional Account Code "
					+ OptionalUtil.getValue(accountingTransaction.getProvisionalAccountCode()));
		}
	}

	private void validateAccountAlphaCodeValidation(AccountingTransaction accountingTransaction) {
		List<String> listOfAccountAlphaCodeValues = accountingDefinitionDao
				.getAccountAlphaCodeFromAccountDefinitionMaster();
		if (!(listOfAccountAlphaCodeValues
				.contains(OptionalUtil.getValue(accountingTransaction.getAccountAlphaCode())))) {
			throw new BusinessException(
					"Invalid Account Alpha Code " + OptionalUtil.getValue(accountingTransaction.getAccountAlphaCode()));
		}
	}

	private void validateAccountDefinitionIdentifierValidation(AccountingTransaction accountingTransaction) {
		List<Integer> listOfAccountDefinitionIdentifierValues = accountingDefinitionDao
				.getAccountDefinitionIdentifierFromAccountDefinitionMaster();
		if (!(listOfAccountDefinitionIdentifierValues
				.contains(OptionalUtil.getValue(accountingTransaction.getAccountDefinitionIdentifier())))) {
			throw new BusinessException("Invalid Account Definition Identifier "
					+ OptionalUtil.getValue(accountingTransaction.getAccountDefinitionIdentifier()));
		}
	}

	private void validateBalanceFlagLOVValidation(AccountingTransaction accountingTransaction) {
		List<String> listOfValues = listOfValuesService.getListOfValues(accountingTransaction.getClientId(),
				Optional.of(ACCOUNTINGTRANSACTION_LOV_TABLE_VALUE1), Optional.of(BALANCEFLAG_LOV_COLUMN_VALUE2));
		if (OptionalUtil.isPresent(accountingTransaction.getBalanceFlag())
				&& !(listOfValues.contains(OptionalUtil.getValue(accountingTransaction.getBalanceFlag())))) {
			throw new BusinessException(
					"Invalid BalanceFlag " + OptionalUtil.getValue(accountingTransaction.getBalanceFlag()));
		}

	}

	private void validatedebitCreditIndicatorLOVValidation(AccountingTransaction accountingTransaction) {
		List<String> listOfDebitCreditIndicatorValues = listOfValuesService.getListOfValues(
				accountingTransaction.getClientId(), Optional.of(ACCOUNTINGTRANSACTION_LOV_TABLE_VALUE1),
				Optional.of(DEBITCREDITINDICATOR_LOV_COLUMN_VALUE1));
		if (OptionalUtil.isPresent(accountingTransaction.getDebitCreditIndicator())
				&& !(listOfDebitCreditIndicatorValues
						.contains(OptionalUtil.getValue(accountingTransaction.getDebitCreditIndicator()).trim()))) {
			throw new BusinessException("Invalid Debit Credit Indicator "
					+ OptionalUtil.getValue(accountingTransaction.getDebitCreditIndicator()));
		}

	}

	private void validateOverlapForCreate(AccountingTransaction accountingTransaction) {
		if (OptionalUtil.isPresent(accountingTransaction.getClientId())
				&& OptionalUtil.isPresent(accountingTransaction.getScenarioNumber())
				&& OptionalUtil.isPresent(accountingTransaction.getTransactionSerialNo())) {
			if (accountingTransactionDao.getOverlapRecordCount(
					OptionalUtil.getValue(accountingTransaction.getClientId()),
					OptionalUtil.getValue(accountingTransaction.getScenarioNumber()),
					OptionalUtil.getValue(accountingTransaction.getTransactionSerialNo())) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	@Override
	public AccountingTransaction updateAccountingTransaction(Optional<Integer> scenarioNumber,
			Optional<Integer> accountDefinitionIdentifier, Integer accountingTransactionId,
			AccountingTransaction accountingTransaction) {
		AccountingTransactionEntity accountingTransactionEntity = accountingTransactionDao
				.findByAccountingId(accountingTransactionId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountingTransactionId)));
		validateBusinessConstraintsForUpdate(accountingTransaction, accountingTransactionEntity);
		return accountingTransactionMapper.mapToModel(accountingTransactionDao
				.update(accountingTransactionMapper.mapToEntity(accountingTransaction, accountingTransactionEntity)));
	}

	private void validateBusinessConstraintsForUpdate(AccountingTransaction accountingTransaction,
			AccountingTransactionEntity accountingTransactionEntity) {
		validateOverlapForUpdate(accountingTransaction, accountingTransactionEntity);
		validatedebitCreditIndicatorLOVValidation(accountingTransaction);
		validateBalanceFlagLOVValidation(accountingTransaction);
		validateAccountDefinitionIdentifierValidation(accountingTransaction);
		validateAccountAlphaCodeValidation(accountingTransaction);
		validateProvisionalAccountCodeValidation(accountingTransaction);
	}

	private void validateOverlapForUpdate(AccountingTransaction accountingTransaction,
			AccountingTransactionEntity accountingTransactionEntity) {

		String clientId = getClientId(accountingTransaction, accountingTransactionEntity);
		Integer scenarioNumber = getScenarioNumber(accountingTransaction, accountingTransactionEntity);
		Integer transactionSerialNo = getTransactionSerialNo(accountingTransaction, accountingTransactionEntity);
		if (!clientId.equalsIgnoreCase(accountingTransactionEntity.getClientId())
				|| !scenarioNumber.equals(accountingTransactionEntity.getScenarioNumber())
				|| !transactionSerialNo.equals(accountingTransactionEntity.getTransactionSerialNo())) {
			if (accountingTransactionDao.getOverlapRecordCount(clientId, scenarioNumber, transactionSerialNo,
					accountingTransactionEntity.getAccountingTransactionId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private Integer getTransactionSerialNo(AccountingTransaction accountingTransaction,
			AccountingTransactionEntity accountingTransactionEntity) {
		return OptionalUtil.isPresent(accountingTransaction.getTransactionSerialNo())
				? OptionalUtil.getValue(accountingTransaction.getTransactionSerialNo())
				: accountingTransactionEntity.getTransactionSerialNo();
	}

	private Integer getScenarioNumber(AccountingTransaction accountingTransaction,
			AccountingTransactionEntity accountingTransactionEntity) {
		return OptionalUtil.isPresent(accountingTransaction.getScenarioNumber())
				? OptionalUtil.getValue(accountingTransaction.getScenarioNumber())
				: accountingTransactionEntity.getScenarioNumber();
	}

	private String getClientId(AccountingTransaction accountingTransaction,
			AccountingTransactionEntity accountingTransactionEntity) {
		return OptionalUtil.isPresent(accountingTransaction.getClientId())
				? OptionalUtil.getValue(accountingTransaction.getClientId())
				: accountingTransactionEntity.getClientId();
	}

	@Override
	public AccountingTransaction getAccountingTransactionByAccountingId(Integer accountingTransactionId) {

		return accountingTransactionMapper
				.mapToModel(accountingTransactionDao.findByAccountingId(accountingTransactionId)
						.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountingTransactionId))));
	}

	@Override
	public List<AccountingTransaction> getAccountingTransactionListByFkId(Integer scenarioNumber,
			Optional<Integer> accountDefinitionIdentifier, Optional<String> accountAlphaCode, Boolean isActive) {

		return accountingTransactionMapper.mapToModel(accountingTransactionDao.getAccountingTransactionListByFkId(
				scenarioNumber, accountDefinitionIdentifier, accountAlphaCode, isActive));
	}

	@Override
	public void activateAccountingTransaction(AccountingTransaction accountingTransaction) {

		AccountingTransactionEntity accountingTransactionEntity = accountingTransactionDao
				.findByAccountingId(accountingTransaction.getAccountingTransactionId())
				.orElseThrow(() -> new RecordNotFoundException(
						String.valueOf(accountingTransaction.getAccountingTransactionId())));

		if (OptionalUtil.getValue(accountingTransaction.getLastUpdatedBy()).isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (OptionalUtil.getValue(accountingTransaction.getLastUpdatedBy()).length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (accountingTransactionEntity.getIsActive())
			throw new BusinessException(ACTIVE_ACCOUNTING_TRANSACTION);

		accountingTransactionEntity.setIsActive(Boolean.TRUE);

		accountingTransactionDao
				.update(accountingTransactionMapper.mapToEntity(accountingTransaction, accountingTransactionEntity));
	}

	@Override
	public void deactivateAccountingTransaction(AccountingTransaction accountingTransaction) {

		AccountingTransactionEntity accountingTransactionEntity = accountingTransactionDao
				.findByAccountingId(accountingTransaction.getAccountingTransactionId())
				.orElseThrow(() -> new RecordNotFoundException(
						String.valueOf(accountingTransaction.getAccountingTransactionId())));

		if (OptionalUtil.getValue(accountingTransaction.getLastUpdatedBy()).isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (OptionalUtil.getValue(accountingTransaction.getLastUpdatedBy()).length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (!accountingTransactionEntity.getIsActive()) {
			throw new BusinessException(ACCOUNTING_TRANSACTION_ALREADY_INACTIVE);
		}
		accountingTransactionEntity.setIsActive(Boolean.FALSE);

		accountingTransactionDao
				.update(accountingTransactionMapper.mapToEntity(accountingTransaction, accountingTransactionEntity));
	}

	@Override
	public List<AccountingTransaction> getAccountingTransactionByScenarioNumber(Optional<Integer> scenarioNumber) {

		return accountingTransactionMapper.mapToModel(accountingTransactionDao.findByScenarioNumber(scenarioNumber));
	}
}
