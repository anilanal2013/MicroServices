package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.EMDEntity;
import com.sgl.smartpra.master.model.EMDModel;

@Repository
public interface EMDDao {

	public Optional<EMDEntity> findById(Integer emdId);

	public EMDEntity create(EMDEntity emdEntity);

	public EMDEntity update(EMDEntity mapToEntity);

	public List<EMDEntity> findAll(EMDModel emdModel, Optional<String> exceptionCall);

	List<EMDEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	// -- This is for Create- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, Optional<String> clientId,
			Optional<String> reasonForIssuanceCode, Optional<String> reasonForIssuanceSubCode, Optional<String> emdType,
			Optional<String> serviceType);

	// -- This is for Update- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String reasonForIssuanceCode, String reasonForIssuanceSubCode, String emdType, String serviceType,
			Integer emdId);

}
