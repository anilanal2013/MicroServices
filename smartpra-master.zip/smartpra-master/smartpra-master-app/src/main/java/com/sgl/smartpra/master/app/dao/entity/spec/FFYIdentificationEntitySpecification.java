package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.FFYIdentificationEntity;

public class FFYIdentificationEntitySpecification {
	
	private static final String SALE_FROM_DATE = "saleFromDate";
	private static final String SALE_TO_DATE = "saleToDate";
	private static final String ACTIVATE = "activate";

	public static Specification<FFYIdentificationEntity> search(Optional<String> issueCxrCode,
			Optional<String> marketingCxrCode, Optional<String> operatingCxrCode, Optional<String> saleFromDate,
			Optional<String> saleToDate, Optional<Boolean> activate) {
		return (ffyIdentificationEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(issueCxrCode)) {
				predicates.add(criteriaBuilder.like(ffyIdentificationEntity.get("issueCxrCode"),
						OptionalUtil.getValue(issueCxrCode) + "%"));
			}
			if (OptionalUtil.isPresent(marketingCxrCode)) {
				predicates.add(criteriaBuilder.like(ffyIdentificationEntity.get("marketingCxrCode"),
						OptionalUtil.getValue(marketingCxrCode) + "%"));
			}
			if (OptionalUtil.isPresent(operatingCxrCode)) {
				predicates.add(criteriaBuilder.like(ffyIdentificationEntity.get("operatingCxrCode"),
						OptionalUtil.getValue(operatingCxrCode) + "%"));
			}
			if (OptionalUtil.isPresent(saleFromDate) && OptionalUtil.isPresent(saleToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleFromDate)),
								ffyIdentificationEntity.get(SALE_FROM_DATE), ffyIdentificationEntity.get(SALE_TO_DATE)),
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleToDate)),
								ffyIdentificationEntity.get(SALE_FROM_DATE),
								ffyIdentificationEntity.get(SALE_TO_DATE)),
						criteriaBuilder.between(ffyIdentificationEntity.get(SALE_FROM_DATE),
								OptionalUtil.getLocalDateValue(saleFromDate),
								OptionalUtil.getLocalDateValue(saleToDate)),
						criteriaBuilder.between(ffyIdentificationEntity.get(SALE_TO_DATE),
								OptionalUtil.getLocalDateValue(saleFromDate),
								OptionalUtil.getLocalDateValue(saleToDate))));
			} else {
				if (OptionalUtil.isPresent(saleFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleFromDate)),
							ffyIdentificationEntity.get(SALE_FROM_DATE), ffyIdentificationEntity.get(SALE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(saleToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleToDate)),
							ffyIdentificationEntity.get(SALE_FROM_DATE), ffyIdentificationEntity.get(SALE_TO_DATE)));
				}
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(ffyIdentificationEntity.get(ACTIVATE), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(ffyIdentificationEntity.get(ACTIVATE), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FFYIdentificationEntity> betweenSaleFromAndSaleToDate(LocalDate saleDate) {
		return (ffyIdentificationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(saleDate), ffyIdentificationEntity.get(SALE_FROM_DATE),
				ffyIdentificationEntity.get(SALE_TO_DATE));
	}

	public static Specification<FFYIdentificationEntity> greaterThanOrEqualTo(LocalDate saleFromDate) {
		return (ffyIdentificationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(ffyIdentificationEntity.get(SALE_FROM_DATE), saleFromDate);
	}

	public static Specification<FFYIdentificationEntity> lessThanOrEqualTo(LocalDate saleToDate) {
		return (ffyIdentificationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(ffyIdentificationEntity.get(SALE_TO_DATE), saleToDate);
	}

	public static Specification<FFYIdentificationEntity> isActive() {
		return (ffyIdentificationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(ffyIdentificationEntity.get(ACTIVATE), true);
	}

	public static Specification<FFYIdentificationEntity> betweenUpliftFromAndUpliftoDate(LocalDate upliftFromDate) {
		return (ffyIdentificationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(upliftFromDate), ffyIdentificationEntity.get("upliftFromDate"),
				ffyIdentificationEntity.get("upliftToDate"));
	}

	public static Specification<FFYIdentificationEntity> greaterThanOrEqualToUpliftFrom(LocalDate upliftFromDate) {
		return (ffyIdentificationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(ffyIdentificationEntity.get("upliftFromDate"), upliftFromDate);
	}

	public static Specification<FFYIdentificationEntity> lessThanOrEqualToUpliftTo(LocalDate upliftToDate) {
		return (ffyIdentificationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(ffyIdentificationEntity.get("upliftToDate"), upliftToDate);
	}

	public static Specification<FFYIdentificationEntity> notEqualsFfyIdentifyId(Integer ffyIdentifyId) {
		return (ffyIdentificationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(ffyIdentificationEntity.get("ffyIdentifyId"), ffyIdentifyId);
	}
}
