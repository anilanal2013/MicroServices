package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.FareBasisTranslationEntity;

@Repository
public interface FareBasisTranslationDao {

	FareBasisTranslationEntity create(FareBasisTranslationEntity mapToEntity);

	FareBasisTranslationEntity update(FareBasisTranslationEntity fareBasisTranslationEntityUpdated);

	List<FareBasisTranslationEntity> getFareBasisTranslationResult(Optional<String> marketingFareBasis, Optional<String> marketingTD,
			Optional<String> fareOwnerCXR, Optional<String> effectiveDate);

	public Optional<FareBasisTranslationEntity> findById(Integer fbtId);

	int verifyIfOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	List<FareBasisTranslationEntity> getFBTByIsPattern();

	List<FareBasisTranslationEntity> getFareBasisTranslationList(Optional<String> marketingFareBasis,
			Optional<String> marketingTD,Optional<String> clientId, Optional<String> effectiveDate);

	int getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String marketingFareBasis, String marketingTD, String fareOwnerCXR, String areaFBWIndicator,
			String fromArea, String toArea, Integer fbtId);

	int getOverLapRecordCountCreate(String clientId, String marketingFareBasis, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String marketingTD, String fareOwnerCXR, String areaFBWIndicator, String fromArea, String toArea);

}
