package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.master.app.service.AccountMasterService;
import com.sgl.smartpra.master.model.MasAccountModel;
import com.sgl.smartpra.master.model.MasScenarioModel;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class AccountMasterController {
	public static final Logger log = LoggerFactory.getLogger(AccountMasterController.class);
	@Autowired
	private AccountMasterService accountMasterService;

	@GetMapping("/account-master")
	public List<MasAccountModel> getListOfAccountMasters() {
		log.info("Fetching List Of Account Masters");
		return accountMasterService.getListOfAccountMasters();
	}

	@GetMapping("/account-master/{accountAplhaCode}")
	public List<MasAccountModel> getListOfAccountMastersByAccountAlphaCode(
			@PathVariable("accountAplhaCode") Optional<String> accountAplhaCode) {
		log.info("Fetching List Of Account Masters for accountAplhaCode  {}", accountAplhaCode);
		if (accountAplhaCode.isPresent()) {
			return accountMasterService.getListOfAccountMastersByAccountAlphaCode(accountAplhaCode.get());
		} else {
			throw new IllegalArgumentException(accountAplhaCode.get());
		}
	}
	
}
