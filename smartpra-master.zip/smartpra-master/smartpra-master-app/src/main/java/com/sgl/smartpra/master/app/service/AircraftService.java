package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.Aircraft;

public interface AircraftService {
	public List<Aircraft> getListOfAircraft(Aircraft aircraft, Optional<String> exceptionCall);

	public Aircraft getAircraftByAircraftId(Integer aircraftId);

	public Aircraft createAircraft(Aircraft aircraft);

	public Aircraft updateAircraft(Integer aircraftId, Aircraft aircraft);

	public void deactivateAircraft(Integer aircraftId, String lastUpdatedBy);

	public void activateAircraft(Integer aircraftId, String lastUpdatedBy);

	public List<Aircraft> getAllAircraftDetails(Integer firstClassCapacity, Integer businessClassCapacity,
			Integer premiumEconomyClassCapacity, Integer economyClassCapacity);

}
