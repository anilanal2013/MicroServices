package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.ReasonCodeEntity;

@Repository
public interface ReasonCodeDao {

	ReasonCodeEntity create(ReasonCodeEntity reasonCodeEntity);

	Optional<ReasonCodeEntity> findById(Integer reasonCodeId);

	ReasonCodeEntity update(ReasonCodeEntity reasonCodeEntity);

	List<ReasonCodeEntity> search(Optional<String> clientId, Optional<String> reasonType, Optional<String> reasonCategory,
			Optional<String> isCpnBreakdownMandatory, Optional<Boolean> activate);

	long getOverLapForCreate(Optional<String> clientId, Optional<String> reasonCode);

	long getOverLapForUpdate(String clientId, String reasonCode, Integer reasonCodeId);

}
