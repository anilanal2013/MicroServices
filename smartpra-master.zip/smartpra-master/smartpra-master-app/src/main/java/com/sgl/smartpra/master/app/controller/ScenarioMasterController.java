package com.sgl.smartpra.master.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.master.app.service.ScenarioMasterService;
import com.sgl.smartpra.master.model.MasScenarioModel;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class ScenarioMasterController {

	@Autowired
	private ScenarioMasterService scenarioMasterService;
	
	@GetMapping("/senario-masters")
	public List<MasScenarioModel> getAllMasScenarios(){
		log.info("fetching all MasterScenarios");
		return scenarioMasterService.getAllMasScenarios();
	}
	
	@PostMapping("/fetch_scenario-master")
	public List<MasScenarioModel> fetchScenarioMaster(@RequestBody MasScenarioModel scenarioMaster) {
		log.info("Fetching List Of Scenario Masters for scenario master  {}", scenarioMaster);
		return scenarioMasterService.getMasScenariosByMaster(scenarioMaster);
		
	}
}
