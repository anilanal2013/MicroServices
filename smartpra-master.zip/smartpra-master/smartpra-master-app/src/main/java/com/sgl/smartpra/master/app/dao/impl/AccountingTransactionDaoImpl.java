package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.AccountingTransactionDao;
import com.sgl.smartpra.master.app.dao.entity.AccountingTransactionEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.AccountingTransactionEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.AccountingTransactionRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AccountingTransactionDaoImpl implements AccountingTransactionDao {

	@Autowired
	private AccountingTransactionRepository accountingTransactionRepository;

	@Override
	@Caching(evict = {
			@CacheEvict(value = "accountingTransaction", key = "#accountingTransactionEntity.accountingTransactionId") })
	public AccountingTransactionEntity create(AccountingTransactionEntity accountingTransactionEntity) {
		return accountingTransactionRepository.save(accountingTransactionEntity);
	}

	@Override
	@CachePut(value = "accountingTransaction", key = "{#accountingTransactionEntity.scenarioNumber,#accountingTransactionEntity.accountDefinitionIdentifier,#accountingTransactionEntity.accountingTransactionId}")
	@CacheEvict(value = "AccountingTransactionSearch", allEntries = true)
	public AccountingTransactionEntity update(AccountingTransactionEntity accountingTransactionEntity) {
		return accountingTransactionRepository.save(accountingTransactionEntity);
	}

	@Override
	public Optional<AccountingTransactionEntity> findByAccountingId(Integer accountingTransactionId) {
		return accountingTransactionRepository.findById(accountingTransactionId);
	}

	@Override
	public List<AccountingTransactionEntity> getAccountingTransactionListByFkId(Integer scenarioNumber,
			Optional<Integer> accountDefinitionIdentifier, Optional<String> accountAlphaCode, Boolean isActive) {
		return accountingTransactionRepository.findAll(AccountingTransactionEntitySpecification
				.findByFkId(scenarioNumber, accountDefinitionIdentifier, accountAlphaCode, isActive));
	}

	@Override
	public long getOverlapRecordCount(String clientId, Integer scenarioNumber, Integer transactionSerialNo) {

		return accountingTransactionRepository
				.count(Specification.where(AccountingTransactionEntitySpecification.equalsClientId(clientId)
						.and(AccountingTransactionEntitySpecification.equalsScenarioNumber(scenarioNumber))
						.and(AccountingTransactionEntitySpecification.equalsTransactionSerialNo(transactionSerialNo))));
	}

	@Override
	public long getOverlapRecordCount(String clientId, Integer scenarioNumber, Integer transactionSerialNo,
			Integer accountingTransactionId) {

		return accountingTransactionRepository
				.count(Specification.where(AccountingTransactionEntitySpecification.equalsClientId(clientId)
						.and(AccountingTransactionEntitySpecification.equalsScenarioNumber(scenarioNumber))
						.and(AccountingTransactionEntitySpecification.equalsTransactionSerialNo(transactionSerialNo))
						.and(AccountingTransactionEntitySpecification
								.notEqualsAccountingTransactionId(accountingTransactionId))));
	}

	@Override
	public List<AccountingTransactionEntity> findByScenarioNumber(Optional<Integer> scenarioNumber) {
		return accountingTransactionRepository.findAll(AccountingTransactionEntitySpecification
				.findByScenarioNumber(scenarioNumber).and(AccountingTransactionEntitySpecification.isActive()));
	}

}
