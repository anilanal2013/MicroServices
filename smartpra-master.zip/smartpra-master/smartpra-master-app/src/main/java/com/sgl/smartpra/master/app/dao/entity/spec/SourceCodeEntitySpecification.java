package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.SourceCodeEntity;

public final class SourceCodeEntitySpecification {

	private static final String CLIENT_ID = "clientId";
	private static final String ACTIVATE = "activate";
	private static final String SOURCE_CODE = "sourceCode";

	public static Specification<SourceCodeEntity> search(Optional<String> clientId, Optional<String> sourceType,
			Optional<String> sourceCategory, Optional<Boolean> activate) {
		return (sourceCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(sourceCodeEntity.get(CLIENT_ID), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(sourceType)) {
				predicates.add(
						criteriaBuilder.equal(sourceCodeEntity.get("sourceType"), OptionalUtil.getValue(sourceType)));
			}
			if (OptionalUtil.isPresent(sourceCategory)) {
				predicates.add(criteriaBuilder.equal(sourceCodeEntity.get("sourceCategory"),
						OptionalUtil.getValue(sourceCategory)));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(sourceCodeEntity.get(ACTIVATE), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(sourceCodeEntity.get(ACTIVATE), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<SourceCodeEntity> getSourceCode(String sourceCode) {
		return (sourceCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(sourceCodeEntity.get(SOURCE_CODE), sourceCode);
	}

	public static Specification<SourceCodeEntity> getClientId(String clientId) {
		return (sourceCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(sourceCodeEntity.get(CLIENT_ID), clientId);
	}

	public static Specification<SourceCodeEntity> isActive() {
		return (sourceCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(sourceCodeEntity.get(ACTIVATE), true);
	}

	public static Specification<SourceCodeEntity> findByClientIdAndSourceCode(Optional<String> clientId,
			Optional<String> sourceCode) {
		return (sourceCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(sourceCodeEntity.get(CLIENT_ID), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(sourceCode)) {
				predicates.add(
						criteriaBuilder.equal(sourceCodeEntity.get(SOURCE_CODE), OptionalUtil.getValue(sourceCode)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<SourceCodeEntity> findBySourceCode(String sourceCode) {
		return (sourceCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(sourceCodeEntity.get(SOURCE_CODE), sourceCode);
	}

	public static Specification<SourceCodeEntity> equalsClientId(String clientId) {
		return (sourceCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(sourceCodeEntity.get(CLIENT_ID), clientId);
	}

	public static Specification<SourceCodeEntity> equalsSourceCode(String sourceCode) {
		return (sourceCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(sourceCodeEntity.get(SOURCE_CODE), sourceCode);
	}

	public static Specification<SourceCodeEntity> notEqualsSourceCodeId(Integer sourceCodeId) {
		return (sourceCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(sourceCodeEntity.get("sourceCodeId"), sourceCodeId);
	}
}
