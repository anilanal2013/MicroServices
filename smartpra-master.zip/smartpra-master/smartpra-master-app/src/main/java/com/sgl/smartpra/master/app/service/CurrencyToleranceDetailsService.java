package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.CurrencyToleranceDetails;

public interface CurrencyToleranceDetailsService {

	public CurrencyToleranceDetails createCurrencyTolerance(String currencyCode,
			CurrencyToleranceDetails currencyToleranceDetails);

	public CurrencyToleranceDetails updateCurrencyTolerance(String currencyCode, Integer currencyToleranceDtlId,
			CurrencyToleranceDetails currencyToleranceDetails);

	public CurrencyToleranceDetails getCurrencyToleranceById(Integer currencyToleranceDtlId);

	public List<CurrencyToleranceDetails> getListOfCurrencyTolerance(String currencyCode, String clientId,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	public CurrencyToleranceDetails getCurrencyToleranceByDate(String currencyCode, String clientId,
			Optional<String> effectiveFromDate);

}
