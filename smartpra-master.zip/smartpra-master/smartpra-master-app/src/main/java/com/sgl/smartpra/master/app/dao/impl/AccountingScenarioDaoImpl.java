package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.AccountingScenarioDao;
import com.sgl.smartpra.master.app.dao.entity.AccountingScenarioEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.AccountingScenarioEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.AccountingScenarioRepository;
import com.sgl.smartpra.master.model.AccountingScenario;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AccountingScenarioDaoImpl implements AccountingScenarioDao {

	@Autowired
	private AccountingScenarioRepository accountingScenarioRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "accountingScenario", key = "#accountingScenarioEntity.scenarioNumber") })
	public AccountingScenarioEntity create(AccountingScenarioEntity accountingScenarioEntity) {
		return accountingScenarioRepository.save(accountingScenarioEntity);
	}

	@Override
	@CachePut(value = "accountingScenario", key = "#accountingScenarioEntity.scenarioNumber")
	@CacheEvict(value = "AccountingScenarioSearch", allEntries = true)
	public AccountingScenarioEntity update(AccountingScenarioEntity accountingScenarioEntity) {
		return accountingScenarioRepository.save(accountingScenarioEntity);
	}

	@Override
	@Cacheable(value = "accountingScenario", key = "#scenarioNumber")
	public Optional<AccountingScenarioEntity> findById(Integer scenarioNumber) {
		log.info("Cacheable Accounting Scenario Entity's ID= {}", scenarioNumber);
		return accountingScenarioRepository.findById(scenarioNumber);
	}

	@Override
	public List<AccountingScenarioEntity> getSearchAllAccountingScenario(String transactionType,
			String selfOalIndicator, Boolean salesExistIndicator, String docType, String chargeCatCode,
			String chargeCode) {
		return accountingScenarioRepository.findAll(Specification.where(AccountingScenarioEntitySpecification
				.search(transactionType, selfOalIndicator, salesExistIndicator, docType, chargeCatCode, chargeCode)
				.and(AccountingScenarioEntitySpecification.isActive())));
	}

	@Override
	public List<AccountingScenarioEntity> getSearchAllAccountingScenarioWithIsActiveParam(String module,
			String transactionType, String selfOalIndicator, Boolean salesExistIndicator, String docType,
			String chargeCatCode, String chargeCode, Boolean isActive) {

		return accountingScenarioRepository.findAll(Specification
				.where(AccountingScenarioEntitySpecification.searchWithIsActiveParam(module, transactionType,
						selfOalIndicator, salesExistIndicator, docType, chargeCatCode, chargeCode, isActive)));
	}

	@Override
	public long getOverlapRecordCount(AccountingScenario accountingScenario) {

		return accountingScenarioRepository.count(AccountingScenarioEntitySpecification.checkOverlapping(
				accountingScenario.getClientId(), accountingScenario.getModule(),
				accountingScenario.getTransactionType(), accountingScenario.getSelfOalIndicator(),
				accountingScenario.getSalesExistIndicator(), accountingScenario.getDocType(),
				accountingScenario.getChargeCatCode(), accountingScenario.getChargeCode(),
				accountingScenario.getPreImplementationIndicator(), accountingScenario.getMiscDocumentUtilType(),
				accountingScenario.getMiscDocumentIssuedFor(), accountingScenario.getInvoiceType(),
				accountingScenario.getSourceCode(), accountingScenario.getDeliveringCarrierIndicator(),
				accountingScenario.getReceivingCarrierIndicator(), accountingScenario.getFopType(),
				accountingScenario.getRejectionMemoType(), accountingScenario.getAncillaryService(),
				accountingScenario.getBspAgentFlag()));
	}

	@Override
	public long getOverlapRecordCount(AccountingScenario accountingScenario, Integer scenarioNumber) {

		return accountingScenarioRepository.count(AccountingScenarioEntitySpecification.checkOverlappingForUpdate(
				accountingScenario.getClientId(), accountingScenario.getModule(),
				accountingScenario.getTransactionType(), accountingScenario.getSelfOalIndicator(),
				accountingScenario.getSalesExistIndicator(), accountingScenario.getDocType(),
				accountingScenario.getChargeCatCode(), accountingScenario.getChargeCode(),
				accountingScenario.getPreImplementationIndicator(), accountingScenario.getMiscDocumentUtilType(),
				accountingScenario.getMiscDocumentIssuedFor(), accountingScenario.getInvoiceType(),
				accountingScenario.getSourceCode(), accountingScenario.getDeliveringCarrierIndicator(),
				accountingScenario.getReceivingCarrierIndicator(), accountingScenario.getFopType(),
				accountingScenario.getRejectionMemoType(), accountingScenario.getAncillaryService(),
				accountingScenario.getBspAgentFlag(), accountingScenario.getScenarioNumber()));

	}
}
