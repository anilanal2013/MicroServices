package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.FareBasisGroupcodeEntity;
import com.sgl.smartpra.master.model.FareBasisGroupcode;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FareBasisGroupcodeMapper extends BaseMapper<FareBasisGroupcode, FareBasisGroupcodeEntity> {
	
	FareBasisGroupcodeEntity mapToEntity(FareBasisGroupcode fareBasisGroupcode, @MappingTarget FareBasisGroupcodeEntity fareBasisGroupcodeEntity);
	
	@Mapping(source = "fbGroupId", target = "fbGroupId", ignore = true)
	FareBasisGroupcodeEntity mapToEntity(FareBasisGroupcode fareBasisGroupcode);
	
}

