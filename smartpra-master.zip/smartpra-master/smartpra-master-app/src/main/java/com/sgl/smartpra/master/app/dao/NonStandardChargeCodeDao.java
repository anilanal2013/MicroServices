package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCodeEntity;

public interface NonStandardChargeCodeDao {

	public Optional<NonStandardChargeCodeEntity> findById(Integer nonStdChargeCodeId);
	
	public NonStandardChargeCodeEntity create(NonStandardChargeCodeEntity nonStdChargeCodeEntity);

	public NonStandardChargeCodeEntity update(NonStandardChargeCodeEntity nonStdChargeCodeEntity);
	
	public List<NonStandardChargeCodeEntity> searchNonStdChargeCode(String clientId, Optional<String> nonStdCategoryCode,
			Optional<String> nonStdChargeCode, Optional<String> stdChargeCode, Optional<String> isActive);

	public int activateNonStdChargeCode(String clientId, String nonStdChargeCode);
	
	public int deActivateNonStdChargeCode(String clientId, String nonStdChargeCode);
	
	public String getMaxNonStdChargeCode(String clientId, String stdChargeCode, String initial);
	
	public String getNonStdChargeCode(String clientId, String nonStdChargeCodeName, String nonStdCategoryCode, String stdChargeCode);
}
