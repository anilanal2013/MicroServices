package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.SPAHeaderStgDao;
import com.sgl.smartpra.master.app.dao.entity.SPAHeaderStgEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.SPAHeaderStgEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.SPAHeaderStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SPAHeaderStgDaoImpl implements SPAHeaderStgDao {

	@Autowired
	private SPAHeaderStgRepository spaHeaderStgRepository;

	@Override
	public List<SPAHeaderStgEntity> getSpaHeaderBySpecSerach(String cxrCode, Integer spaCodeSeqNumber, Integer spaKey,
			String spaId, String effectiveIssueDate, String effectiveUpliftDate) {

		return spaHeaderStgRepository.findAll(SPAHeaderStgEntitySpecification.search(cxrCode, spaCodeSeqNumber, spaKey,
				spaId, effectiveIssueDate, effectiveUpliftDate));
	}
	
	@Override
	public List<SPAHeaderStgEntity> getSpaHeaderForProcessingCoupon(String clientId, String cxrCode, String effectiveIssueDate, String effectiveOriginalDate, String effectiveUpliftDate) {
		return spaHeaderStgRepository.findAll(SPAHeaderStgEntitySpecification.searchForProcessingCoupon(clientId, cxrCode, effectiveIssueDate, effectiveOriginalDate, effectiveUpliftDate));
	}
}
