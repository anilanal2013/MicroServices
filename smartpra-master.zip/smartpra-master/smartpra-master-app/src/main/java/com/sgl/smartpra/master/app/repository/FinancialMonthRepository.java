package com.sgl.smartpra.master.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.FinancialMonthEntity;

@Repository
public interface FinancialMonthRepository
		extends JpaRepository<FinancialMonthEntity, Integer>, JpaSpecificationExecutor<FinancialMonthEntity> {

	@Query(value = "select d from FinancialMonthEntity d where d.financialYear = ?1 and d.financialMonth =?2")
	FinancialMonthEntity getFinancialMonthCalendarByFinancialYearAndMonth(String financialYear, String financialMonth);

	@Query(value = "select top 1 * ,CONVERT(datetime,SUBSTRING(financial_month,1,3)+SUBSTRING(convert(varchar(4), YEAR(getdate())),1,2)+SUBSTRING(financial_month,5,6)) as date"
			+ " from SmartPRAMaster.mas_financial_month where close_indicator='N' order by date asc", nativeQuery = true)
	FinancialMonthEntity getCurrentOpenFinancialMonthForFinancialCalendar();

	@Query(value = "select top 1 * ,CONVERT(datetime,SUBSTRING(financial_month,1,3)+SUBSTRING(convert(varchar(4), YEAR(getdate())),1,2)+SUBSTRING(financial_month,5,6)) as date"
			+ " from SmartPRAMaster.mas_financial_month where close_indicator='N' and client_id = :clientId order by date asc", nativeQuery = true)
	FinancialMonthEntity getCurrentOpenFinancialMonthForFinancialCalendarByClientId(@Param("clientId") String clientId);
	
	@Query(value = "select top 1 * ,CONVERT(datetime,SUBSTRING(financial_month,1,3)+SUBSTRING(convert(varchar(4), YEAR(getdate())),1,2)+SUBSTRING(financial_month,5,6)) as date"
			+ " from SmartPRAMaster.mas_financial_month where close_indicator='Y' order by date desc", nativeQuery = true)
	FinancialMonthEntity getLatestClosedFinancialMonthForFinancialCalendar();

	FinancialMonthEntity findByFinancialMonthAndFinancialYearAndCloseIndicatorAndClientId(
			String financialMonth, String financialYear, String closeIndicator,String clientId);
	
	FinancialMonthEntity findByFinancialMonthAndClientId(
			String financialMonth, String clientId);

}
