package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.AccountEntity;
import com.sgl.smartpra.master.model.AccountModel;

@Repository
public interface AccountDao {

	AccountEntity createAccount(AccountEntity accountEntity);

	Optional<AccountEntity> findById(Integer accountAlphaCodeId);

	AccountEntity updateAccount(AccountEntity mapToEntity);

	long validateOverlapForCreate(AccountModel accountModel);

	List<AccountEntity> getAllAccount(AccountModel accountModel);

	long validateOverlapForUpdate(String accountAlphaCode, String clientId, String accountNumCode,
			LocalDate effectiveFromDate, LocalDate effectiveToDate, String accountType, String attribute1,
			String attribute2, String attribute3, String attribute4, String attribute5, String attribute6,
			String attribute7, String attribute8, String attribute9, String attribute10, String attribute11,
			String attribute12, String attribute13, String attribute14, String attribute15, String attribute16,
			String attribute17, String attribute18, String attribute19, String attribute20, Integer accountAlphaCodeId);

	long findByAccountAlphaCode(Optional<String> accountAlphaCode);

	List<AccountEntity> getListOfAccountBYAccountAphaCode(List<String> accountAlphaCode);
	
	public List<String> getAccountAlphaCodeFromAccountMaster();
}
