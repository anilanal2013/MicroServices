package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.repository.entity.InterfaceReferenceEntity;
import com.sgl.smartpra.master.model.InterfaceReference;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface InterfaceReferenceMapper extends BaseMapper<InterfaceReference, InterfaceReferenceEntity> {
	
	InterfaceReferenceEntity mapToEntity(InterfaceReference interfaceReference, @MappingTarget InterfaceReferenceEntity interfaceReferenceEntity);

	@Mapping(source = "interfaceRefId", target = "interfaceRefId", ignore = true)
	InterfaceReferenceEntity mapToEntity(InterfaceReference interfaceReference);
}
