package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.RateAndAgreementTimeValidityEntity;
import com.sgl.smartpra.master.app.mapper.BaseMapper;
import com.sgl.smartpra.master.model.RateAndAgreementTimeValidityModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface RateAndAgreementTimeValidityMapper extends BaseMapper<RateAndAgreementTimeValidityModel, RateAndAgreementTimeValidityEntity> {
	
	RateAndAgreementTimeValidityEntity mapToEntity(RateAndAgreementTimeValidityModel rateAndAgreementTimeValidityModel);
	
	RateAndAgreementTimeValidityEntity mapToEntity(RateAndAgreementTimeValidityModel rateAndAgreementTimeValidityModel, @MappingTarget RateAndAgreementTimeValidityEntity rateAndAgreementTimeValidityEntity);
}