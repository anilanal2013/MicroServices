package com.sgl.smartpra.master.app.mapper;

import java.util.HashSet;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.AccountingDefinitionEntity;
import com.sgl.smartpra.master.model.AccountingDefinition;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AccountingDefinitionMapper extends BaseMapper<AccountingDefinition, AccountingDefinitionEntity> {

	AccountingDefinitionEntity mapToEntity(AccountingDefinition accountDefinition,
			@MappingTarget AccountingDefinitionEntity accountDefinitionEntity);

	@Mapping(source = "accountDefinitionIdentifier", target = "accountDefinitionIdentifier", ignore = true)
	AccountingDefinitionEntity mapToEntity(AccountingDefinition accountDefinition);

	List<String> mapToList(List<String> data1);

}
