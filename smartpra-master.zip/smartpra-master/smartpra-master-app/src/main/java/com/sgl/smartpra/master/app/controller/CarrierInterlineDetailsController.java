package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.master.app.service.CarrierInterlineDetailsService;
import com.sgl.smartpra.master.enums.SettlementMethod;
import com.sgl.smartpra.master.model.CarrierInterlineDetailsModel;

@RestController
public class CarrierInterlineDetailsController {

	private static final String CARRIER_CODE_LENGTH = "carrierCode should be 3 characters";
	private static final String DATA_CONSTARINT_VIOALATION = "Record already exists";

	@Autowired
	private CarrierInterlineDetailsService carrierInterlineDetailsService;

	@GetMapping("/carriers/{carrierCode}/carrier-interline-details/clientId/{clientId}")
	public List<CarrierInterlineDetailsModel> getListOfCarrierInterlineDetailsByEffectiveDate(
			@PathVariable(value = "carrierCode") Optional<String> carrierCode,
			@PathVariable(value = "clientId", required = true) Optional<String> clientId,
			@RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {

		if (!(OptionalUtil.getValue(carrierCode).length() == 3)) {
			throw new BusinessException(CARRIER_CODE_LENGTH);
		}
		return carrierInterlineDetailsService.getListOfCarrierInterlineDetailsByEffectiveDate(carrierCode,clientId, 
				effectiveDate);
	}

	@GetMapping("/carriers/{carrierCode}/carrier-interline-details/{carrierInterlineDtlId}")
	public CarrierInterlineDetailsModel getCarrierInterlineByCarrierInterlineDtlId(
			@PathVariable(value = "carrierCode") Optional<String> carrierCode,
			@PathVariable(value = "carrierInterlineDtlId") Integer carrierInterlineDtlId) {
		if (!(OptionalUtil.getValue(carrierCode).length() >= 1 && OptionalUtil.getValue(carrierCode).length() <= 3)) {
			throw new BusinessException(CARRIER_CODE_LENGTH);
		}
		return carrierInterlineDetailsService.getCarrierInterlineByCarrierInterlineDtlId(carrierCode,
				carrierInterlineDtlId);
	}

	@PostMapping("/carriers/{carrierCode}/carrier-interline-details")
	public CarrierInterlineDetailsModel createCarrierInterlineDetail(
			@PathVariable(value = "carrierCode") String carrierCode,
			@Validated(Create.class) @RequestBody CarrierInterlineDetailsModel carrierInterlineDetailsModel) {
		if (!(carrierCode.length() >= 1 && carrierCode.length() <= 3)) {
			throw new BusinessException(CARRIER_CODE_LENGTH);
		}
		return carrierInterlineDetailsService.createCarrierInterlineDetail(carrierCode, carrierInterlineDetailsModel);
	}

	@PutMapping("/carriers/{carrierCode}/carrier-interline-details/{carrierInterlineDtlId}")
	public CarrierInterlineDetailsModel updateCarrierInterlineDetail(
			@PathVariable(value = "carrierCode") String carrierCode,
			@PathVariable(value = "carrierInterlineDtlId") int carrierInterlineDtlId,
			@Validated(Update.class) @RequestBody CarrierInterlineDetailsModel carrierInterlineDetailsModel) {
		CarrierInterlineDetailsModel carrier = null;
		try {
			carrier = carrierInterlineDetailsService.updateCarrierInterlineDetail(carrierCode, carrierInterlineDtlId,
					carrierInterlineDetailsModel);
		} catch (DataIntegrityViolationException e) {
			throw new BusinessException(DATA_CONSTARINT_VIOALATION);
		}
		return carrier;
	}

	@PutMapping("/carriers/{carrierCode}/carrier-interline-details/{carrierInterlineDtlId}/deactivate")
	public void deactivateCarrierInterlineDetail(@PathVariable(value = "carrierCode") String carrierCode,
			@Valid @PathVariable(value = "carrierInterlineDtlId") int carrierInterlineDtlId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		carrierInterlineDetailsService.deactivateCarrierInterlineDetail(carrierCode, carrierInterlineDtlId,
				lastUpdatedBy);
	}

	@PutMapping("/carriers/{carrierCode}/carrier-interline-details/{carrierInterlineDtlId}/activate")
	public void activateCarrierInterlineDetail(@PathVariable(value = "carrierCode") String carrierCode,
			@Valid @PathVariable(value = "carrierInterlineDtlId") int carrierInterlineDtlId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		carrierInterlineDetailsService.activateCarrierInterlineDetail(carrierCode, carrierInterlineDtlId,
				lastUpdatedBy);
	}
	
	@GetMapping("/carriers/{carrierCode}/carrier-interline-details/validate")
	public boolean isValidPassengerSis(
			@PathVariable(value = "carrierCode") Optional<String> carrierCode,
			@RequestParam(value = "passengerSis") Optional<Boolean>  passengerSis ,
			@RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {

		if (!(OptionalUtil.getValue(carrierCode).length() == 3)) {
			throw new BusinessException(CARRIER_CODE_LENGTH);
		}
		return carrierInterlineDetailsService.isValidPassengerSis(carrierCode,passengerSis,
				effectiveDate);
	}
	
	@GetMapping("/carrier/{carrierCode}/carrier-interline-details")
	public CarrierInterlineDetailsModel getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(
			@PathVariable(value = "carrierCode") Optional<String> carrierCode,
			@RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {

		if (!(OptionalUtil.getValue(carrierCode).length() == 3)) {
			throw new BusinessException(CARRIER_CODE_LENGTH);
		}
		return carrierInterlineDetailsService.getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(carrierCode,
				effectiveDate);
	}
	
	@GetMapping("/carrier/carrier-interline-details-with-zone")
	public List<CarrierInterlineDetailsModel> getCarrierInterlineDetailsByZoneAndEffectiveDate(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "effectiveFromDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveToDate,
			@RequestParam(value = "zone", required = false) Optional<String> zone) {
		
		return carrierInterlineDetailsService.getCarrierInterlineDetailsByZoneAndEffectiveDate(Optional.of(clientId),Optional.of(effectiveFromDate),
				Optional.of(effectiveToDate),zone);
	}
	
	@GetMapping("/carrier/{billingCarrierCode}/carrier-interline-details/{billedCarriedCode}")
	public SettlementMethod getSettlementMethod(
			@PathVariable(value = "billingCarrierCode") Optional<String> billingCarrierCode,
			@PathVariable(value = "billedCarriedCode") Optional<String> billedCarriedCode,
			@RequestParam(value = "currentBillingDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> currentBillingDate) {

		return carrierInterlineDetailsService.getSettlementMethod(billingCarrierCode, billedCarriedCode, currentBillingDate);
	}
}
