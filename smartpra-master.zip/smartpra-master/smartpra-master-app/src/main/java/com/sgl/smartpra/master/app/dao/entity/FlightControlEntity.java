package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_flight_control")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class FlightControlEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "flight_control_autoid")
	private Integer flightControlAutoId;

	@Column(name = "flight_control_id")
	private String flightControlId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "control_description")
	private String controlDescription;

	@Column(name = "control_formula")
	private String controlFormula;

	@Column(name = "control_identification")
	private String controlIdentification;

	@Column(name = "control_indicator_1")
	private String controlIndicator1;

	@Column(name = "control_indicator_2")
	private String controlIndicator2;

	@Column(name = "control_indicator_3")
	private String controlIndicator3;

	@Column(name = "control_indicator_4")
	private String controlIndicator4;

	@Column(name = "control_indicator_5")
	private String controlIndicator5;

	@Column(name = "control_type")
	private String controlType;

	@Column(name = "control_value_1")
	private String controlValue1;

	@Column(name = "control_value_2")
	private String controlValue2;

	@Column(name = "control_value_3")
	private String controlValue3;

	@Column(name = "control_value_4")
	private String controlValue4;

	@Column(name = "control_value_5")
	private String controlValue5;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "match_control")
	private String matchControl;

	@Column(name = "self_oal_indicator")
	private String selfOalIndicator;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}