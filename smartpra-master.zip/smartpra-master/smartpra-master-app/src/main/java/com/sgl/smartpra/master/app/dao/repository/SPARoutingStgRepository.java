package com.sgl.smartpra.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.SPARoutingStgEntity;

@Repository
public interface SPARoutingStgRepository extends JpaRepository<SPARoutingStgEntity, Integer>, JpaSpecificationExecutor<SPARoutingStgEntity>{

}
