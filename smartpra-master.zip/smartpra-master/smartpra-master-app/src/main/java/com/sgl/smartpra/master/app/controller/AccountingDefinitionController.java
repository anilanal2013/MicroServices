package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.AccountingDefinitionService;
import com.sgl.smartpra.master.model.AccountDefIdentifierResponse;
import com.sgl.smartpra.master.model.AccountingDefinition;

@RestController
public class AccountingDefinitionController {

	@Autowired
	private AccountingDefinitionService accountingDefinitionService;
	
	
	@GetMapping("/account-definition")
	public List<AccountingDefinition> getAllAccountingDefinition(
			@RequestParam(value = "componentIdentifier", required = false) Optional<String> componentIdentifier,
			@RequestParam(value = "conversionDateUse", required = false) Optional<String> conversionDateUse) {
		return accountingDefinitionService.getAllAccountingDefinition(componentIdentifier, conversionDateUse);
	}
	@GetMapping("/account-definition/searchWithIsActiveParam")
	public List<AccountingDefinition> getAllAccountingDefinitionWithIsActiveParam(
			@RequestParam(value = "componentIdentifier", required = false) Optional<String> componentIdentifier,
			@RequestParam(value = "conversionDateUse", required = false) Optional<String> conversionDateUse,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return accountingDefinitionService.getAllAccountingDefinitionWithIsActiveParam(componentIdentifier, conversionDateUse, activate);
	}

	@GetMapping(value = "/account-definition/{accountDefinitionIdentifier}")
	public AccountingDefinition getAccountingDefinitionByIdentifier(
			@PathVariable(value = "accountDefinitionIdentifier") Integer accountDefinitionIdentifier) {
		return accountingDefinitionService.getAccountingDefinitionByIdentifier(accountDefinitionIdentifier);
	}

	@PostMapping("/account-definition")
	public AccountingDefinition createAccountingDefinition(
			@Validated(Create.class) @RequestBody AccountingDefinition accountingDefinition) {
		return accountingDefinitionService.createAccountingDefinition(accountingDefinition);
	}

	@PutMapping("/account-definition/{accountDefinitionIdentifier}")
	public AccountingDefinition updateAccountingDefinition(
			@PathVariable(value = "accountDefinitionIdentifier") Integer accountDefinitionIdentifier,
			@Validated(Update.class) @RequestBody AccountingDefinition accountingDefinition) {
		return accountingDefinitionService.updateAccountingDefinition(accountDefinitionIdentifier,
				accountingDefinition);
	}

	@PutMapping("/account-definition/{accountDefinitionIdentifier}/deactivate")
	public void deactivateAccountingDefinition(
			@Valid @PathVariable(value = "accountDefinitionIdentifier") Integer accountDefinitionIdentifier,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		accountingDefinitionService.deactivateAccountingDefinition(accountDefinitionIdentifier, lastUpdatedBy);
	}

	@PutMapping("/account-definition/{accountDefinitionIdentifier}/activate")
	public void activateAccountingDefinition(
			@Valid @PathVariable(value = "accountDefinitionIdentifier") Integer accountDefinitionIdentifier,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		accountingDefinitionService.activateAccountingDefinition(accountDefinitionIdentifier, lastUpdatedBy);
	}

	@PostMapping("/account-definition/account-alpha-code/account-def-identifier")
	public AccountDefIdentifierResponse getListOfAccountingDefByAccountAphaCodeAndAccountDef(
			@RequestBody AccountingDefinition accountDefinition) {
		return accountingDefinitionService.getListOfAccountingDefByAccountAphaCodeAndAccountDef(accountDefinition);
	}
	
	@GetMapping("/account-definition/getAccountingAtrMasterTab")
	public List<String> getAccountAttrMasterTabs(){
     return accountingDefinitionService.getAccountAttrMasterTabs();
	}
	
	@GetMapping("/account-definition/getAccountingAtrColumn")
	public List<String> getAccountAttrColumns(){
	     return accountingDefinitionService.getAccountAttrColumns();
	}

}
