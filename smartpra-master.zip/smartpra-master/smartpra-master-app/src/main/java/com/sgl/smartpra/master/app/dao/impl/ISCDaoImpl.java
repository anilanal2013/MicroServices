package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.InterlineServiceChargeDao;
import com.sgl.smartpra.master.app.dao.entity.InterlineServiceChargeEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.ISCEntitySpec;
import com.sgl.smartpra.master.app.dao.repository.InterlineServiceChargeRepository;

@Component
public class ISCDaoImpl<T> extends CommonSearchDao<T> implements InterlineServiceChargeDao {

	@Autowired
	private InterlineServiceChargeRepository interlineServiceRepo;

	@Override
	@Cacheable(value = "isc", key = "#iscId")
	public Optional<InterlineServiceChargeEntity> findById(Integer iscId) {
		return interlineServiceRepo.findById(iscId);
	}

	@Override
	public List<InterlineServiceChargeEntity> search(Optional<String> documentType, Optional<String> iscRecordType,
			Optional<String> issueCxr, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> billingCxr, Optional<Boolean> activate) {
		return interlineServiceRepo.findAll(ISCEntitySpec.search(documentType, iscRecordType, issueCxr,
				effectiveFromDate, effectiveToDate, billingCxr, activate));
	}

	// Added new parameters
	@Override
	public List<InterlineServiceChargeEntity> searchISC(Optional<String> documentType, Optional<String> iscRecordType,
			Optional<String> effectiveFromDate, Optional<String> settlementIndicator, Optional<String> clientId,
			Optional<String> issueCxr, Optional<String> billingCxr) {
		return interlineServiceRepo.findAll(ISCEntitySpec.searchISC(documentType, iscRecordType, effectiveFromDate,
				settlementIndicator, clientId, issueCxr, billingCxr));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "isc", key = "#mapToEntity.iscId") })
	public InterlineServiceChargeEntity create(InterlineServiceChargeEntity mapToEntity) {
		return interlineServiceRepo.save(mapToEntity);
	}

	@Override
	@CachePut(value = "isc", key = "#mapToEntity.iscId")
	public InterlineServiceChargeEntity update(InterlineServiceChargeEntity mapToEntity) {
		return interlineServiceRepo.save(mapToEntity);
	}

	@Override
	public List<InterlineServiceChargeEntity> verifyIfOverlapForUtilDateExists(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate) {
		return interlineServiceRepo.findAll(
				ISCEntitySpec.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate))
						.or(ISCEntitySpec
								.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveToDate))
								.and(ISCEntitySpec.isActive())));
	}

	@Override
	public long getOverLapRecordCount(String clientId, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> documentType, Optional<String> settlementIndicator,
			Optional<String> iscRecordType, String issueCxr, String billingCxr, String salesSource, String pointOfSale,
			String travelFromArea, String travelToArea, String couponFromArea, String couponToArea,
			String flightRangeId, String fbGroupCode) {
		return interlineServiceRepo.count(Specification
				.where(ISCEntitySpec.equalsClientId(clientId).and(ISCEntitySpec
						.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate))
						.or(ISCEntitySpec.betweenEffectiveFromAndEffectiveToDate(
								OptionalUtil.getLocalDateValue(effectiveToDate))))
						.and(ISCEntitySpec.equalsDocumentType(OptionalUtil.getValue(documentType))))
				.and(ISCEntitySpec.euqalsSettlementIndicator(OptionalUtil.getValue(settlementIndicator)))
				.and(ISCEntitySpec.equalsIscRecordType(OptionalUtil.getValue(iscRecordType)))
				.and(ISCEntitySpec.equalsIssueCxr(issueCxr)).and(ISCEntitySpec.equalsBillingCxr(billingCxr))
				.and(ISCEntitySpec.equalsSalesSource(salesSource)).and(ISCEntitySpec.equalsPointOfSale(pointOfSale))
				.and(ISCEntitySpec.equalsTravelFromArea(travelFromArea))
				.and(ISCEntitySpec.equalsTravelToArea(travelToArea))
				.and(ISCEntitySpec.equalsCouponFromArea(couponFromArea))
				.and(ISCEntitySpec.equalsCouponToArea(couponToArea))
				.and(ISCEntitySpec.equalsFlightRangeId(flightRangeId))
				.and(ISCEntitySpec.equalsFBGroupCode(fbGroupCode)));
	}

	@Override
	public long getOverLapRecordCount(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String documentType, String settlementIndicator, String iscRecordType, String issueCxr, String billingCxr,
			String salesSource, String pointOfSale, String travelFromArea, String travelToArea, String couponFromArea,
			String couponToArea, String flightRangeId, String fbGroupCode, Integer iscId) {
		return interlineServiceRepo.count(Specification
				.where(ISCEntitySpec.equalsClientId(clientId)
						.and(ISCEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
								.or(ISCEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
						.and(ISCEntitySpec.equalsDocumentType(documentType)))
				.and(ISCEntitySpec.euqalsSettlementIndicator(settlementIndicator))
				.and(ISCEntitySpec.equalsIscRecordType(iscRecordType)).and(ISCEntitySpec.equalsIssueCxr(issueCxr))
				.and(ISCEntitySpec.equalsBillingCxr(billingCxr)).and(ISCEntitySpec.equalsSalesSource(salesSource))
				.and(ISCEntitySpec.equalsPointOfSale(pointOfSale))
				.and(ISCEntitySpec.equalsTravelFromArea(travelFromArea))
				.and(ISCEntitySpec.equalsTravelToArea(travelToArea))
				.and(ISCEntitySpec.equalsCouponFromArea(couponFromArea))
				.and(ISCEntitySpec.equalsCouponToArea(couponToArea))
				.and(ISCEntitySpec.equalsFlightRangeId(flightRangeId)).and(ISCEntitySpec.equalsFBGroupCode(fbGroupCode))
				.and(ISCEntitySpec.notEqualsISCId(iscId)));
	}

}