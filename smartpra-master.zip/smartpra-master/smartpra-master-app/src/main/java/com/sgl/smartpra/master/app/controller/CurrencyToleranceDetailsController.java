package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.CurrencyToleranceDetailsService;
import com.sgl.smartpra.master.model.CurrencyToleranceDetails;

@RestController
public class CurrencyToleranceDetailsController {

	@Autowired
	private CurrencyToleranceDetailsService currencyToleranceService;

	@PostMapping(value = "/currency-tolerance/{currencyCode}/details")
	@ResponseStatus(HttpStatus.CREATED)
	public CurrencyToleranceDetails createCurrencyTolerance(@PathVariable(value = "currencyCode") String currencyCode,
			@Validated(Create.class) @RequestBody CurrencyToleranceDetails currencyToleranceDetails) {
		return currencyToleranceService.createCurrencyTolerance(currencyCode, currencyToleranceDetails);

	}

	@PutMapping(value = "/currency-tolerance/{currencyCode}/details/{currencyToleranceDtlId}")
	@ResponseStatus(HttpStatus.OK)
	public CurrencyToleranceDetails updateCurrencyTolerance(@PathVariable(value = "currencyCode") String currencyCode,
			@PathVariable(value = "currencyToleranceDtlId") Integer currencyToleranceDtlId,
			@Validated(Update.class) @RequestBody CurrencyToleranceDetails currencyToleranceDetails) {
		return currencyToleranceService.updateCurrencyTolerance(currencyCode, currencyToleranceDtlId,
				currencyToleranceDetails);

	}

	@GetMapping(value = "/currency-tolerance/{currencyCode}/details/{currencyToleranceDtlId}")
	public CurrencyToleranceDetails getCurrencyToleranceById(@PathVariable(value = "currencyCode") String currencyCode,
			@PathVariable(value = "currencyToleranceDtlId") Integer currencyToleranceDtlId) {
		return currencyToleranceService.getCurrencyToleranceById(currencyToleranceDtlId);

	}

	@GetMapping(value = "/currency-tolerance/{currencyCode}/details/clientId/{clientId}")
	public List<CurrencyToleranceDetails> getListOfCurrencyTolerance(
			@PathVariable(value = "currencyCode") String currencyCode,
			@PathVariable(value = "clientId") String clientId,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {
		return currencyToleranceService.getListOfCurrencyTolerance(currencyCode, clientId, effectiveFromDate, effectiveToDate);
	}
	
	@GetMapping(value = "/currency-tolerance/{currencyCode}/clientId/{clientId}")
	public CurrencyToleranceDetails getCurrencyToleranceByDate(
			@PathVariable(value = "currencyCode") String currencyCode,
			@PathVariable(value = "clientId") String clientId,
			@RequestParam(value = "effectiveFromDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate) {
		return currencyToleranceService.getCurrencyToleranceByDate(currencyCode, clientId, effectiveFromDate);
	}
	

}
