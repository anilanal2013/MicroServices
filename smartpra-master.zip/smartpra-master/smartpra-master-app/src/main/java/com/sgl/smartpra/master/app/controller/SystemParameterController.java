package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.SystemParameterService;
import com.sgl.smartpra.master.model.SystemParamWrapper;
import com.sgl.smartpra.master.model.SystemParameter;

@RestController
public class SystemParameterController {

	@Autowired
	private SystemParameterService systemParameterService;

	@GetMapping("/system-parameters")
	public List<SystemParameter> getAllSystemParameter(
			@RequestParam(value = "groupName", required = false) Optional<String> groupName,
			@RequestParam(value = "moduleName", required = false) Optional<String> moduleName,
			@RequestParam(value = "parameterName", required = false) Optional<String> parameterName,
			@RequestParam(value = "parameterId", required = false) String parameterId,
			@RequestParam(value = "clientId", required = false) Optional<String> clientId,
			@RequestParam(value = "parameterFormat", required = false) Optional<String> parameterFormat,
			@RequestParam(value = "isVisible", required = false) Optional<Boolean> isVisible,
			@RequestParam(value = "isActive", required = false) Optional<Boolean> isActive) {
		return systemParameterService.getAllSystemParameters(clientId, groupName, moduleName, parameterName, parameterFormat, parameterId,isVisible,isActive);
	}

	@GetMapping("/system-parameters/{parameterId}")
	public SystemParameter getSystemParameterByparameterId(@PathVariable(value = "parameterId") String parameterId) {
		return systemParameterService.findSystemParameterByParameterIdAndClientId(parameterId,null);
	}
	
	@GetMapping("/system-parameters/clientId/{clientId}/parameterId/{parameterId}")
	public SystemParameter getSystemParameterByparameterIdAndClientId(
			@PathVariable(value = "parameterId") String parameterId,
			@PathVariable(value = "clientId") String clientId) {
		return systemParameterService.findSystemParameterByParameterIdAndClientId(parameterId, clientId);
	}

	// not mentions is Documents just keeping this api for safer side
	@GetMapping("/system-parameters-with-date/{parameterName}")
	public List<SystemParameter> getSystemParameterByparameterName(
			@PathVariable(value = "parameterName") String parameterName) {

		return systemParameterService.findSystemParameterByParameterName(parameterName);
	}

	@GetMapping("/system-parameters-with-date/clientId/{clientId}/parameterName/{parameterName}")
	public SystemParameter getSystemParameterByparameterNameAndClientId(
			@PathVariable(value = "parameterName", required = true) String parameterName,
			@PathVariable(value = "clientId", required = true) String clientId) {

		return systemParameterService.findSystemParameterByParameterNameAndClientId(parameterName, clientId);
	}	
	
	@GetMapping("/system-parameters-with-date/clientId/parameterNames")
	public List<SystemParameter> getSystemParameterByparameterNameAndClientId(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "parameterNames", required = true) List<String> parameterNames) {

		return systemParameterService.findSystemParameterListByParameterNameAndClientId(clientId, parameterNames);
	}
	
	@GetMapping("/system-parameters-with-date/clientId/list-parameterNames")
	public List<SystemParameter> getSystemParameterByListParameterNameAndClientId(
			@RequestBody SystemParamWrapper systemParamWrapper) {

		return systemParameterService.findSystemParameterListByParameterNameAndClientId(systemParamWrapper.getClientId(), 
				systemParamWrapper.getParameterNames());
	}
	
	@GetMapping("/system-parameters/getGroupNameByModuleName/{clientId}")
	public Map<String, Set<String>> getGroupNameByModuleName(
			@PathVariable(value = "clientId") String clientId){
		return systemParameterService.findGroupNameByModuleName(clientId);
	}
	
	@GetMapping("/system-parameters/parameter-list")
	public List<SystemParameter> getSystemParameterListByparameterNameAndClientId(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "parameterName", required = true) String parameterName) {

		return systemParameterService.findSystemParameterListByParameterNameAndClient(clientId,parameterName);
	}

	@PostMapping("/system-parameters")
	@ResponseStatus(value = HttpStatus.CREATED)
	public SystemParameter createSystemParameter(
			@Validated(Create.class) @RequestBody SystemParameter systemParameter) {
		return systemParameterService.createSystemParameter(systemParameter);
	}

	@PutMapping("/system-parameters/{parameterId}")
	public SystemParameter updateSystemParameter(@Valid @PathVariable(value = "parameterId") Integer parameterId,
			@Validated(Update.class) @RequestBody SystemParameter systemParameter) {
		return systemParameterService.updateSystemParameter(parameterId, systemParameter);
	}

	@PutMapping("/system-parameters/clientId/{clientId}/{parameterId}")
	public SystemParameter updateSystemParameterWithClientId(
			@Valid @PathVariable(value = "parameterId") String parameterId,
			@Valid @PathVariable(value = "clientId") String clientId,
			@Validated(Update.class) @RequestBody SystemParameter systemParameter) {
		return systemParameterService.updateSystemParameterWithClientId(parameterId, clientId, systemParameter);
	}

	@PutMapping("/system-parameters/{parameterId}/deactivate")
	public void deactivateSystemParameter(@Valid @PathVariable(value = "parameterId") Integer parameterId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		systemParameterService.deactivateSystemParameter(parameterId, lastUpdatedBy);
	}

	@PutMapping("/system-parameters/clientId/{clientId}/parameterId/{parameterId}/deactivate")
	public void deactivateSystemParameterWithClient(@Valid @PathVariable(value = "parameterId") String parameterId,
			@Valid @PathVariable(value = "clientId") String clientId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		systemParameterService.deactivateSystemParameterWithClientId(parameterId, clientId, lastUpdatedBy);
	}

	@PutMapping("/system-parameters/{parameterId}/activate")
	public void activateSystemParameter(@Valid @PathVariable(value = "parameterId") Integer parameterId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		systemParameterService.activateSystemParameter(parameterId, lastUpdatedBy);
	}

	@PutMapping("/system-parameters/clientId/{clientId}/parameterId/{parameterId}/activate")
	public void activateSystemParameterWithClient(@Valid @PathVariable(value = "parameterId") String parameterId,
			@Valid @PathVariable(value = "clientId") String clientId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		// systemParameterService.activateSystemParameterWithClientId(parameterId,
		// clientId, lastUpdatedBy);
		systemParameterService.activateSystemParameterWithClientId(parameterId, clientId, lastUpdatedBy);
	}
}
