package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_agency database table.
 * 
 */
@Entity
@Table(name = "mas_agency")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class AgencyMasterEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "agency_id")
	private int agencyId;

	@Column(name = "account_code")
	private String accountCode;

	private String address;

	@Column(name = "agency_code")
	private String agencyCode;

	@Column(name = "agency_name")
	private String agencyName;

	@Column(name = "agency_type")
	private String agencyType;

	@Column(name = "area_of_operation")
	private String areaOfOperation;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@Column(name = "bsp_indicator")
	private String bspIndicator;

	@Column(name = "city_code")
	private String cityCode;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "cost_centre")
	private String costCentre;

	@Column(name = "country_code")
	private String countryCode;

	@Column(name = "customer_code")
	private String customerCode;

	@Column(name = "email_address")
	private String emailAddress;

	@Column(name = "fare_audit_flag")
	private String fareAuditFlag;

	@Column(name = "fax_no")
	private String faxNo;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "phone_no")
	private String phoneNo;

	@Column(name = "profilt_centre")
	private String profiltCentre;

	@Column(name = "reporting_agency")
	private String reportingAgency;

	@Column(name = "reporting_agency_type")
	private String reportingAgencyType;

	@Column(name = "zip_code")
	private String zipCode;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}