package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.RouteCodeService;
import com.sgl.smartpra.master.model.RouteCode;
import com.sgl.smartpra.master.model.RouteCodeResponse;

@RestController
public class RouteCodeController {

	@Autowired
	private RouteCodeService routeCodeService;

	@GetMapping(value = "/route-codes")
	public List<RouteCode> getAllRouteCode(@RequestParam(value = "routing", required = false) Optional<String> routing,
			@RequestParam(value = "routeCode", required = false) Optional<String> routeCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {
		
		RouteCode routeCodeModel = new RouteCode();
		routeCodeModel.setRouting(routing);
		routeCodeModel.setRouteCode(routeCode);
		routeCodeModel.setEffectiveFromDate(effectiveFromDate);
		routeCodeModel.setEffectiveToDate(effectiveToDate);
		return routeCodeService.getAllRouteCode(routeCodeModel);
	}

	@GetMapping(value = "/route-codes/search/clientid/{clientId}")
	public List<RouteCode> getAllRouteCode(@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "routing", required = false) Optional<String> routing,
			@RequestParam(value = "routeCode", required = false) Optional<String> routeCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {

		RouteCode routeCodeModel = new RouteCode();
		routeCodeModel.setClientId(clientId);
		routeCodeModel.setRouting(routing);
		routeCodeModel.setRouteCode(routeCode);
		routeCodeModel.setEffectiveFromDate(effectiveFromDate);
		routeCodeModel.setEffectiveToDate(effectiveToDate);

		return routeCodeService.getAllRouteCode(routeCodeModel);
	}


	@GetMapping(value = "/route-codes/list")
	public RouteCodeResponse getAllRouteCode(Pageable pageable,
			@RequestParam(value = "routing", required = false) Optional<String> routing,
			@RequestParam(value = "routeCode", required = false) Optional<String> routeCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {

		RouteCode routeCodeModel = new RouteCode();
		routeCodeModel.setRouting(routing);
		routeCodeModel.setRouteCode(routeCode);
		if (OptionalUtil.isPresent(effectiveFromDate)) {
			routeCodeModel.setEffectiveFromDate(effectiveFromDate);
		}
		if (OptionalUtil.isPresent(effectiveToDate)) {
			routeCodeModel.setEffectiveToDate(effectiveToDate);
		}
		return routeCodeService.getAllRouteCode(pageable, routeCodeModel);
	}

	@GetMapping(value = "/route-codes/{routeCodeId}")
	public RouteCode getRouteCodeById(@PathVariable(value = "routeCodeId") Integer routeCodeId) {
		return routeCodeService.getRouteCodeById(routeCodeId);
	}

	@PostMapping(value = "/route-codes")
	@ResponseStatus(value = HttpStatus.CREATED)
	public RouteCode createRouteCode(@Validated(Create.class) @RequestBody RouteCode routeCode) {
		return routeCodeService.createRouteCode(routeCode);
	}

	@PutMapping(value = "/route-codes/{routeCodeId}")
	@ResponseStatus(value = HttpStatus.OK)
	public RouteCode updateRouteCode(@PathVariable(value = "routeCodeId") Integer routeCodeId,
			@Validated(Update.class) @RequestBody RouteCode routeCode) {
		return routeCodeService.updateRouteCode(routeCodeId, routeCode);
	}
}
