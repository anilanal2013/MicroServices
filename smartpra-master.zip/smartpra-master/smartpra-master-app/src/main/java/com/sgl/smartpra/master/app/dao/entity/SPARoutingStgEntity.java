package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "mas_spa_routing_stg")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class SPARoutingStgEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "spa_routing_id", nullable = false)
	private Integer spaRoutingId;

	@Column(name = "spa_key",unique = true, nullable = false)
	private Integer spaKey;

	@Column(name = "spa_main_id", nullable = false)
	private Integer spaMainId;

	@Column(name = "client_id", unique = true, nullable = false, length = 2)
	private String clientId;

	@Column(name = "routing_rec_seq_no", unique = true,  nullable = false)
	private Integer routingRecSeqNo;

	@Column(name = "routing_level", nullable = false, length = 7)
	private String routingLevel;

	@Column(name = "routing_flag", nullable = false, length = 1)
	private String routingFlag;

	@Column(name = "marketing_cxr", nullable = false, length = 3)
	private String marketingCxr;

	@Column(name = "operating_cxr", nullable = false, length = 3)
	private String operatingCxr;

	@Column(name = "area_from", nullable = false, length = 4)
	private String areaFrom;

	@Column(name = "area_to", length = 4)
	private String areaTo;

	@Column(name = "area_via", length = 4)
	private String areaVia;

	@Column(name = "vv_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean vvFlag;

	@Column(name = "or_journey_flag", length = 1)
	private String orJourneyFlag;

	@Column(name = "applicability", nullable = false, length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean applicability;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}
	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

	//bi-directional many-to-one association to SPAMainStgEntity
	@ManyToOne(fetch = FetchType.EAGER,optional = false)
	@JoinColumn(name="spa_main_id", insertable=false, updatable=false)
	@JsonIgnore
	private SPAMainStgEntity masSpaMain;
}
