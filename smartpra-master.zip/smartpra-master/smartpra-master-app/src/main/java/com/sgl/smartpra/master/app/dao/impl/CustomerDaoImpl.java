package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.CustomerDao;
import com.sgl.smartpra.master.app.dao.entity.CustomerEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.CustomerEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.CustomerRepository;
import com.sgl.smartpra.master.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	@Cacheable(value = "customer", key = "#id")
	public Optional<CustomerEntity> findById(Integer id) {
		return customerRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "customer", key = "#customerEntity.customerMasId") })
	public CustomerEntity create(CustomerEntity customerEntity) {
		return customerRepository.save(customerEntity);
	}

	@Override
	@CachePut(value = "customer", key = "#customerEntity.customerMasId")
	public CustomerEntity update(CustomerEntity customerEntity) {
		return customerRepository.save(customerEntity);
	}

	@Override
	public void delete(Integer id) {
		customerRepository.deleteById(id);
	}
	@Override
	public List<CustomerEntity> search(Customer customer, Optional<String> exceptionCall) {
		return customerRepository.findAll(CustomerEntitySpecification.search(customer, exceptionCall));
	}

	@Override
	public long getOverlapRecordCountForCreate(String customerType, String fopCode, String subFopCode, String lpoNumber,
			String debtorCode, String customerCode, String agencyCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return customerRepository.count(Specification.where(CustomerEntitySpecification.equalsCustomerType(customerType)
				.and(CustomerEntitySpecification.equalsCustomerCode(customerCode))
				.and(CustomerEntitySpecification.equalsFopCode(fopCode))
				.and(CustomerEntitySpecification.equalsSubFopCode(subFopCode))
				.and(CustomerEntitySpecification.equalsLpoNumber(lpoNumber))
				.and(CustomerEntitySpecification.equalsDebtorCode(debtorCode))
				.and(CustomerEntitySpecification.equalsAgencyCode(agencyCode))
				.and(CustomerEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate))
				.and(CustomerEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))));
	}

	@Override
	public long getOverlapRecordCountForUpdate(String agencyCode, String customerType, String fopCode,
			String subFopCode, String lpoNumber, String debtorCode, String customerCode, Integer customerMasId,
			LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return customerRepository.count(Specification.where(CustomerEntitySpecification.equalsCustomerType(customerType)
				.and(CustomerEntitySpecification.equalsCustomerCode(customerCode))
				.and(CustomerEntitySpecification.equalsAgencyCode(agencyCode))
				.and(CustomerEntitySpecification.equalsFopCode(fopCode))
				.and(CustomerEntitySpecification.equalsSubFopCode(subFopCode))
				.and(CustomerEntitySpecification.equalsLpoNumber(lpoNumber))
				.and(CustomerEntitySpecification.equalsDebtorCode(debtorCode))
				.and(CustomerEntitySpecification.notEqualsCustomerMasId(customerMasId))
				.and(CustomerEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate))
				.and(CustomerEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))));
	}

	@Override
	public Optional<CustomerEntity> findOne(Integer id) {
		return customerRepository.findById(id);
	}

}
