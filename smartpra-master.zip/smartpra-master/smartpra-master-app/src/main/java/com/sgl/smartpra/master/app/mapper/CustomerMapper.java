package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.CustomerEntity;
import com.sgl.smartpra.master.model.Customer;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CustomerMapper extends BaseMapper<Customer, CustomerEntity> {

	CustomerEntity mapToEntity(Customer customer, @MappingTarget CustomerEntity customerEntity);

	@Mapping(source = "customerMasId", target = "customerMasId", ignore = true)
	CustomerEntity mapToEntity(Customer customer);
}
