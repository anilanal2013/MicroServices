package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.master.model.EstimationAverage;
import com.sgl.smartpra.master.model.EstimationAverageResponse;
import com.sgl.smartpra.master.model.RBD;

public interface EstimationAverageService {

	public List<EstimationAverage> getAllEstimationAverages(EstimationAverage estimationAverage,
			Optional<String> exceptionCall);

	public EstimationAverage findEstimationAverage(Optional<String> flightNumber, Optional<String> fromAirport,
			Optional<String> toAirport, Optional<String> rbd, Optional<String> cabin, Optional<String> passengerType,
			Optional<String> selfOc, Optional<String> flightDate);

	public EstimationAverage createEstimationAverage(EstimationAverage estimationAverage);

	public EstimationAverage updateEstimationAverage(Integer estimationAverageId, EstimationAverage estimationAverage);

	public EstimationAverage findByEstimationAverageId(Integer estimationAverageId);

	public void deactivateEstimationAverage(@Valid Integer estimationAverageId, String lastUpdatedBy);

	public void activateEstimationAverage(@Valid Integer estimationAverageId, String lastUpdatedBy);

	public EstimationAverageResponse getAllEstimationAverages(Pageable pageable, EstimationAverage estimationAverage,
			Optional<String> exceptionCall);

	public List<RBD> getRbdByCabin(String cabin);
}