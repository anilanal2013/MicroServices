package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.ReasonCodeDao;
import com.sgl.smartpra.master.app.dao.entity.spec.ReasonCodeEntitySpec;
import com.sgl.smartpra.master.app.repository.ReasonCodeRepository;
import com.sgl.smartpra.master.app.repository.entity.ReasonCodeEntity;

@Repository
public class ReasonCodeDaoImpl implements ReasonCodeDao {

	@Autowired
	private ReasonCodeRepository reasonCodeRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "reasonCode", key = "#reasonCodeEntity.reasonCodeId") })
	public ReasonCodeEntity create(ReasonCodeEntity reasonCodeEntity) {
		return reasonCodeRepository.save(reasonCodeEntity);
	}

	@Override
	@Cacheable(value = "reasonCode", key = "#id")
	public Optional<ReasonCodeEntity> findById(Integer id) {
		return reasonCodeRepository.findById(id);
	}

	@Override
	@CachePut(value = "reasonCode", key = "#reasonCodeEntity.reasonCodeId")
	public ReasonCodeEntity update(ReasonCodeEntity reasonCodeEntity) {
		return reasonCodeRepository.save(reasonCodeEntity);
	}

	@Override
	public List<ReasonCodeEntity> search(Optional<String> clientId, Optional<String> reasonType, Optional<String> reasonCategory,
			Optional<String> isCpnBreakdownMandatory, Optional<Boolean> activate) {
		return reasonCodeRepository
				.findAll(ReasonCodeEntitySpec.search(clientId, reasonType, reasonCategory, isCpnBreakdownMandatory, activate));
	}

	@Override
	public long getOverLapForCreate(Optional<String> clientId, Optional<String> reasonCode) {
		return reasonCodeRepository
				.count(Specification.where(ReasonCodeEntitySpec.equalsClientId(OptionalUtil.getValue(clientId)))
						.and(ReasonCodeEntitySpec.equalsReasonCode(OptionalUtil.getValue(reasonCode))));
	}

	@Override
	public long getOverLapForUpdate(String clientId, String reasonCode, Integer reasonCodeId) {
		return reasonCodeRepository.count(Specification.where(ReasonCodeEntitySpec.equalsClientId(clientId))
				.and(ReasonCodeEntitySpec.equalsReasonCode(reasonCode))
				.and(ReasonCodeEntitySpec.notEqualsSourceCodeId(reasonCodeId)));
	}

}
