package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.EstimationAverageEntity;
import com.sgl.smartpra.master.model.EstimationAverage;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface EstimationAverageMapper extends BaseMapper<EstimationAverage, EstimationAverageEntity> {

	EstimationAverageEntity mapToEntity(EstimationAverage estimationAverage,
			@MappingTarget EstimationAverageEntity estimationAverageEntity);

	@Mapping(source = "estimationAverageId", target = "estimationAverageId", ignore = true)
	EstimationAverageEntity mapToEntity(EstimationAverage estimationAverage);
}
