package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.FlightControlEntity;
import com.sgl.smartpra.master.model.FlightControl;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FlightControlMapper extends BaseMapper<FlightControl, FlightControlEntity> {

	FlightControlEntity mapToEntity(FlightControl flightControl,
			@MappingTarget FlightControlEntity flightControlEntity);

	@Mapping(source = "flightControlAutoId", target = "flightControlAutoId", ignore = true)
	FlightControlEntity mapToEntity(FlightControl flightControl);

}
