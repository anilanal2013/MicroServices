package com.sgl.smartpra.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.master.app.repository.entity.OutwardBillingPeriodsEntity;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;

@Mapper
public interface OutwardBillingPeriodsMapper {
	OutwardBillingPeriods mapToOutwardBillingPeriodsModel(OutwardBillingPeriodsEntity outwardBillingPeriods);

	List<OutwardBillingPeriods> mapToOutwardBillingPeriodsModellList(List<OutwardBillingPeriodsEntity> outwardBillingPeriodsEntities);

	OutwardBillingPeriodsEntity mapToOutwardBillingPeriodsEntity(OutwardBillingPeriods outwardBillingPeriods);

	List<OutwardBillingPeriodsEntity> mapToOutwardBillingPeriodsEntityList(List<OutwardBillingPeriods> OutwardBillingPeriodsList);
}
