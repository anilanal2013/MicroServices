package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.sgl.smartpra.master.model.AccountDefIdentifierResponse;
import com.sgl.smartpra.master.model.AccountingDefinition;

public interface AccountingDefinitionService {
	
	List<AccountingDefinition> getAllAccountingDefinition(Optional<String> componentIdentifier,
			Optional<String> conversionDateUse);
	
	List<AccountingDefinition> getAllAccountingDefinitionWithIsActiveParam(Optional<String> componentIdentifier,
			Optional<String> conversionDateUse, Optional<Boolean> activate);

	AccountingDefinition getAccountingDefinitionByIdentifier(Integer accountDefinitionIdentifier);

	AccountingDefinition createAccountingDefinition(AccountingDefinition accountingDefinition);

	AccountingDefinition updateAccountingDefinition(Integer accountDefinitionIdentifier,
			AccountingDefinition accountingDefinition);

	void deactivateAccountingDefinition(@Valid Integer accountDefinitionIdentifier, String lastUpdatedBy);

	void activateAccountingDefinition(@Valid Integer accountDefinitionIdentifier, String lastUpdatedBy);

	AccountDefIdentifierResponse getListOfAccountingDefByAccountAphaCodeAndAccountDef(
			AccountingDefinition accountDefinition);
	
	public List<String> getAccountAttrMasterTabs();
	
	public List<String> getAccountAttrColumns();  
}
