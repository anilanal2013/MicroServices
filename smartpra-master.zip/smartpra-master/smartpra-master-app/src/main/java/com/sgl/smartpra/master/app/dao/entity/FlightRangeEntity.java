package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_flight_range")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class FlightRangeEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "flight_range_autoid", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer flightRangeAutoId;

	@Column(name = "flight_range_id", nullable = false, length = 8)
	private String flightRangeId;

	@Column(name = "flight_range_description", nullable = false, length = 25)
	private String flightRangeDescription;

	@Column(name = "is_marketing_operating", nullable = false, length = 1)
	private String isMarketingOperating;

	@Column(name = "cxr_code", nullable = false, length = 2)
	private String cxrCode;

	@Column(name = "record_seq_number", nullable = false)
	private Integer recordSeqNumber;

	@Column(name = "from_flight_number", nullable = false)
	private String fromFlightNumber;

	@Column(name = "to_flight_number", nullable = false)
	private String toFlightNumber;

	@Column(name = "sale_from_date")
	private LocalDate saleFromDate;

	@Column(name = "sale_to_date")
	private LocalDate saleToDate;

	@Column(name = "travel_from_date")
	private LocalDate travelFromDate;

	@Column(name = "travel_to_date")
	private LocalDate travelToDate;

	@Column(name = "is_active", nullable = false, length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "client_id", nullable = false)
	private String clientId;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
