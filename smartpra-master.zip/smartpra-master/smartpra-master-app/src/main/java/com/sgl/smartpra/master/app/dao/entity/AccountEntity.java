package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_account")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class AccountEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "account_alpha_code_id")
	private Integer accountAlphaCodeId;

	@Column(name = "account_alpha_code")
	private String accountAlphaCode;

	@Column(name = "account_description")
	private String accountDescription;

	@Column(name = "account_num_code")
	private String accountNumCode;

	@Column(name = "account_type")
	private String accountType;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@Column(name = "attribute_3")
	private String attribute3;

	@Column(name = "attribute_4")
	private String attribute4;

	@Column(name = "attribute_5")
	private String attribute5;

	@Column(name = "attribute_6")
	private String attribute6;

	@Column(name = "attribute_7")
	private String attribute7;

	@Column(name = "attribute_8")
	private String attribute8;

	@Column(name = "attribute_9")
	private String attribute9;

	@Column(name = "attribute_10")
	private String attribute10;

	@Column(name = "attribute_11")
	private String attribute11;

	@Column(name = "attribute_12")
	private String attribute12;

	@Column(name = "attribute_13")
	private String attribute13;

	@Column(name = "attribute_14")
	private String attribute14;

	@Column(name = "attribute_15")
	private String attribute15;

	@Column(name = "attribute_16")
	private String attribute16;

	@Column(name = "attribute_17")
	private String attribute17;

	@Column(name = "attribute_18")
	private String attribute18;

	@Column(name = "attribute_19")
	private String attribute19;

	@Column(name = "attribute_20")
	private String attribute20;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
