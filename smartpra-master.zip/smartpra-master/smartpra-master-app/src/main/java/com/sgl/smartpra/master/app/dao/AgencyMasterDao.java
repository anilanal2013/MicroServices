package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.AgencyMasterEntity;
import com.sgl.smartpra.master.model.AgencyMaster;

@Repository
public interface AgencyMasterDao {

	public Optional<AgencyMasterEntity> findById(Integer agencyId);

	public AgencyMasterEntity create(AgencyMasterEntity agencyEntity);

	public AgencyMasterEntity update(AgencyMasterEntity mapToEntity);

	public List<AgencyMasterEntity> getSearchAllAgency(Optional<String> hostCarrierDesigCode,
			Optional<String> agencyCode, Optional<String> reportingAgency, Optional<String> agencyType,
			Optional<String> areaOfOperation, Optional<String> reportingAgencyType, Optional<String> cityCode,
			Optional<String> countryCode, Optional<Boolean> activate);

	public List<AgencyMasterEntity> findAll(Optional<String> agencyCode, Optional<String> reportingAgency,
			Optional<String> agencyType, Optional<String> areaOfOperation, Optional<String> reportingAgencyType,
			Optional<Boolean> activate);

	List<AgencyMasterEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	// -- This is for Create- Overlap Count Validation
	public long getOverLapRecordCount(String clientId, String agencyCode);

	// -- This is for Update- Overlap Count Validation
	public long getOverLapRecordCount(String clientId, String agencyCode, Integer agencyId);

	public List<AgencyMasterEntity> getByAgencyCode(String agencyCode);

	public Page<AgencyMasterEntity> getSearchAllAgency(AgencyMasterEntity agencyMasterEntity,Optional<String> exceptionCall, Pageable pageable);

	public Long getCount(AgencyMasterEntity mapToEntity,Optional<String> exceptionCall);

	public Optional<AgencyMasterEntity> getAgencyByAgencyCode(String agencyCode, String clientId); 

}
