package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
@Table(name = "mas_code_share")
public class CodeShareEntity extends BaseEntity  {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "code_share_id")
	private Integer codeShareId;
	
	@Column(name = "client_id")
	private String clientId;
	
	@Column(name = "marketing_cxr")
	private String marketingCXR;
	
	@Column(name = "marketed_rbd_list")
	private String marketedRBDList;
	
	@Column(name = "sale_from_date")
	private LocalDate saleFromDate;
	
	@Column(name = "sale_to_date")
	private LocalDate saleToDate;
	
	@Column(name = "travel_from_date")
	private LocalDate travelFromDate;
	
	@Column(name = "travel_to_date")
	private LocalDate travelToDate;
	
	@Column(name = "travel_dow")
	private String travelDOW;
	
	@Column(name = "from_booked_flight_number")
	private String fromBookedFlightNumber;
	
	@Column(name = "to_booked_flight_number")
	private String toBookedFlightNumber;
	
	@Column(name = "from_operating_flight_number")
	private String fromOperatingFlightNumber;
	
	@Column(name = "to_operating_flight_number")
	private String toOperatingFlightNumber;
	
	@Column(name = "area_fbw_indicator")
	private String areaFBWIndicator;
	
	@Column(name = "from_area")
	private String fromArea;
	
	@Column(name = "to_area")
	private String toArea;
	
	@Column(name = "operating_cxr")
	private String operatingCXR;
	
	@Column(name = "link_cxr")
	private String linkCXR;
	
	@Column(name = "operated_rbd_list")
	private String operatedRBDList;
	
	@Column(name = "billing_to")
	private String billingTo;
	
	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
