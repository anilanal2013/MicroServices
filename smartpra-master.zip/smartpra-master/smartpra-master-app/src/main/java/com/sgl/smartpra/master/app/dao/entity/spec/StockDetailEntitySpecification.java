package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.master.app.dao.entity.StcokDetails;

public class StockDetailEntitySpecification {
	private StockDetailEntitySpecification() {
	}

	

	public static Specification<StcokDetails> equalsDocumentNumber(String documentNumber) {
		return (stockDetailsEntity, criteriaQuery, criteriaBuilder)
				-> criteriaBuilder.equal(stockDetailsEntity.get("documentNumber"),
				documentNumber);
	}
	
	public static Specification<StcokDetails> isNotNullBlockListReason() {
		return (stockDetailsEntity, criteriaQuery, criteriaBuilder)
				-> criteriaBuilder.isNotNull(stockDetailsEntity.get("blockListReason"));
	}

	public static Specification<StcokDetails> isTrueIsUtilized() {
		return (stockDetailsEntity, criteriaQuery, criteriaBuilder)
				-> criteriaBuilder.isTrue(stockDetailsEntity.get("isUtilized"));
	}
	
	public static Specification<StcokDetails> isTrueisActive() {
		return (stockDetailsEntity, criteriaQuery, criteriaBuilder)
				-> criteriaBuilder.isTrue(stockDetailsEntity.get("isActive"));
	}
	
	public static Specification<StcokDetails> search(String documentNumber) {
		return (stockDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
				predicates.add(criteriaBuilder.equal(stockDetailsEntity.get("documentNumber"),
						documentNumber));
				predicates.add(criteriaBuilder.isNotNull(stockDetailsEntity.get("blockListReason")));
				predicates.add(criteriaBuilder.isTrue(stockDetailsEntity.get("isUtilized")));
			predicates.add(criteriaBuilder.equal(stockDetailsEntity.get("isActive"), true));
			
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}



	public static Specification<StcokDetails> equalStockId(Integer stockId) {
		return (stockDetailsEntity, criteriaQuery, criteriaBuilder)
				-> criteriaBuilder.equal(stockDetailsEntity.get("stockId"),
						stockId);
	}
	
	public static Specification<StcokDetails> equalClientId(String clientId) {
		return (stockDetailsEntity, criteriaQuery, criteriaBuilder)
				-> criteriaBuilder.equal(stockDetailsEntity.get("clientId"),
						clientId);
	}
	
	public static Specification<StcokDetails> betweenDates(LocalDate effectiveDate) {
		return (stockDetailsEntity, criteriaQuery, criteriaBuilder)
				-> criteriaBuilder.between(
						criteriaBuilder.literal(effectiveDate), stockDetailsEntity.get("effectiveDate"), 
						stockDetailsEntity.get("expiryDate"));
	}

}
