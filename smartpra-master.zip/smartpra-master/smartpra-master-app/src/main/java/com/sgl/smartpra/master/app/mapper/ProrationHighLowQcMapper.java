package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.ProrationHighLowQcEntity;
import com.sgl.smartpra.master.model.ProrationHighLowQc;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProrationHighLowQcMapper extends BaseMapper<ProrationHighLowQc, ProrationHighLowQcEntity> {

	ProrationHighLowQcEntity mapToEntity(ProrationHighLowQc prorationHighLowQc,
			@MappingTarget ProrationHighLowQcEntity prorationHighLowQcEntity);

	@Mapping(source = "lowHighQcId", target = "lowHighQcId", ignore = true)
	ProrationHighLowQcEntity mapToEntity(ProrationHighLowQc prorationHighLowQc);
}
