package com.sgl.smartpra.master.app.service.impl;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.AccountingScenarioDao;
import com.sgl.smartpra.master.app.dao.FOPDao;
import com.sgl.smartpra.master.app.dao.SourceCodeDao;
import com.sgl.smartpra.master.app.dao.entity.AccountingScenarioEntity;
import com.sgl.smartpra.master.app.mapper.AccountingScenarioMapper;
import com.sgl.smartpra.master.app.service.AccountingScenarioService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.AccountingScenario;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class AccountingScenarioServiceImpl implements AccountingScenarioService {

	public static final String ACCOUNTINGSCENARIO_LOV_TABLE_VALUE = LOVEnum.TABLENAME.getLOVEnum();
	public static final String MODULE_LOV_COLUMN_VALUE = LOVEnum.ACCOUNT_MODULE.getLOVEnum();
	public static final String TRANSTYPE_LOV_COLUMN_VALUE = LOVEnum.ACCT_TRANSACTION_TYPE.getLOVEnum();
	public static final String DOCTYPE_LOV_COLUMN_VALUE = LOVEnum.DOCTYPE.getLOVEnum();
	public static final String SELFOALIND_LOV_COLUMN_VALUE = LOVEnum.COUPON_CXR_TYPE.getLOVEnum();
	public static final String REJMEMOTYPE_LOV_COLUMN_VALUE = LOVEnum.REJ_MEMOTYPE.getLOVEnum();
	public static final String OVERLAP_COMBINATION_EXIST = "Record Already Exits";
	private static final String ACTIVE_ACCOUNTING_SCENARIO = "Given Accounting Scenario record is already active";
	public static final String ACCOUNTING_SCENARIO_ALREADY_INACTIVE = "Accounting Scenario is already in deactive state";

	@Autowired
	FOPDao fopDao;

	@Autowired
	SourceCodeDao sourceCodeDao;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;
	@Autowired
	private AccountingScenarioDao accountingScenarioDao;

	@Autowired
	private AccountingScenarioMapper accountingScenarioMapper;

	@Autowired
	private ListOfValuesService listOfValuesService;

	@Override
	public AccountingScenario createAccountingScenario(AccountingScenario accountingScenario) {
		validateBusinessConstraintsForCreate(accountingScenario);
		return accountingScenarioMapper
				.mapToModel(accountingScenarioDao.create(accountingScenarioMapper.mapToEntity(accountingScenario)));
	}

	private void validateBusinessConstraintsForCreate(AccountingScenario accountingScenario) {
		validateOverlapForCreate(accountingScenario);
		validateLovValidation(accountingScenario);
		validateChargeCatCodeValidation(accountingScenario);
		validateChargeCodeValidation(accountingScenario);
		validateSourceCodeValidation(accountingScenario);
		validateFOPValidation(accountingScenario);
		validateMiscDocUtilAndMiscDocIssuedCaptured(accountingScenario);
	}

	private void validateSourceCodeValidation(AccountingScenario accountingScenario) {
		List<String> listOfSourceCodeValues = sourceCodeDao.getSourceCodeFromSourceCodeMaster();
		if (OptionalUtil.isPresent(accountingScenario.getSourceCode())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getSourceCode()).trim())) {
			if (!(listOfSourceCodeValues.contains(OptionalUtil.getValue(accountingScenario.getSourceCode())))) {
				throw new BusinessException(
						"Invalid Source Code " + OptionalUtil.getValue(accountingScenario.getSourceCode()));
			}
		}
	}

	private void validateFOPValidation(AccountingScenario accountingScenario) {
		List<String> listOfFOPIdentifierValues = fopDao.getFOPIdentifierFromFOPMaster();
		if (OptionalUtil.isPresent(accountingScenario.getFopType())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getFopType()).trim())) {
			if (!((listOfFOPIdentifierValues.toString())
					.contains(OptionalUtil.getValue(accountingScenario.getFopType())))) {
				throw new BusinessException(
						"Invalid FOP Type " + OptionalUtil.getValue(accountingScenario.getFopType()));
			}
		}
	}

	private void validateChargeCodeValidation(AccountingScenario accountingScenario) {
		List<String> listOfChargeCodeValues = globalMasterFeignClient.getChargeCodeFromChargeCodeMaster();
		if (OptionalUtil.isPresent(accountingScenario.getChargeCode())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getChargeCode()).trim())) {
			if (!(listOfChargeCodeValues.contains(OptionalUtil.getValue(accountingScenario.getChargeCode())))) {
				throw new BusinessException(
						"Invalid Charge Code " + OptionalUtil.getValue(accountingScenario.getChargeCode()));
			}
		}
	}

	private void validateChargeCatCodeValidation(AccountingScenario accountingScenario) {
		List<String> listOfChargeCatValues = globalMasterFeignClient.getChargeCatCodeFromChargeCatMaster();
		if (OptionalUtil.getValue(accountingScenario.getChargeCatCode()) != null
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getChargeCatCode()).trim())) {
			if (!(listOfChargeCatValues
					.contains(OptionalUtil.getValue(accountingScenario.getChargeCatCode()).trim()))) {
				throw new BusinessException(
						"Invalid Charge Category Code " + OptionalUtil.getValue(accountingScenario.getChargeCatCode()));
			}
		}
	}

	@SuppressWarnings("unlikely-arg-type")
	private void validateLovValidation(AccountingScenario accountingScenario) {
		List<String> listOfModuleValues = listOfValuesService.getListOfValues(accountingScenario.getClientId(),
				Optional.of(ACCOUNTINGSCENARIO_LOV_TABLE_VALUE), Optional.of(MODULE_LOV_COLUMN_VALUE));
		if (!(listOfModuleValues.contains(OptionalUtil.getValue(accountingScenario.getModule())))) {
			throw new BusinessException("Invalid Module " + OptionalUtil.getValue(accountingScenario.getModule()));
		}
		List<String> listOfTransTypeValues = listOfValuesService.getListOfValues(accountingScenario.getClientId(),
				Optional.of(ACCOUNTINGSCENARIO_LOV_TABLE_VALUE), Optional.of(TRANSTYPE_LOV_COLUMN_VALUE));
		if (!(listOfTransTypeValues.contains(OptionalUtil.getValue(accountingScenario.getTransactionType())))) {
			throw new BusinessException(
					"Invalid Transaction Type " + OptionalUtil.getValue(accountingScenario.getTransactionType()));
		}
		List<String> listOfDocTypeValues = listOfValuesService.getListOfValues(accountingScenario.getClientId(),
				Optional.of(ACCOUNTINGSCENARIO_LOV_TABLE_VALUE), Optional.of(DOCTYPE_LOV_COLUMN_VALUE));
		if (OptionalUtil.isPresent(accountingScenario.getDocType())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getDocType()).trim())) {
			if (!(listOfDocTypeValues.contains(OptionalUtil.getValue(accountingScenario.getDocType())))) {
				throw new BusinessException(
						"Invalid Document Type " + OptionalUtil.getValue(accountingScenario.getDocType()));
			}
		}
		List<String> listOfSelfOalIndValues = listOfValuesService.getListOfValues(accountingScenario.getClientId(),
				Optional.of(ACCOUNTINGSCENARIO_LOV_TABLE_VALUE), Optional.of(SELFOALIND_LOV_COLUMN_VALUE));
		if (OptionalUtil.isPresent(accountingScenario.getSelfOalIndicator())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getSelfOalIndicator()).trim())) {
			if (!(listOfSelfOalIndValues.contains(OptionalUtil.getValue(accountingScenario.getSelfOalIndicator())))) {
				throw new BusinessException("Invalid Self oal Indicator "
						+ OptionalUtil.getValue(accountingScenario.getSelfOalIndicator()));
			}
		}

		List<String> listOfRejectionMamoTypeValues = listOfValuesService.getListOfValues(
				accountingScenario.getClientId(), Optional.of(ACCOUNTINGSCENARIO_LOV_TABLE_VALUE),
				Optional.of(REJMEMOTYPE_LOV_COLUMN_VALUE));
		if (OptionalUtil.isPresent(accountingScenario.getRejectionMemoType())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getRejectionMemoType()).trim())) {
			if (!(listOfRejectionMamoTypeValues
					.contains(OptionalUtil.getValue(accountingScenario.getRejectionMemoType())))) {
				throw new BusinessException("Invalid Rejection MemoType "
						+ OptionalUtil.getValue(accountingScenario.getRejectionMemoType()));
			}
		}
	}

	private void validateOverlapForCreate(AccountingScenario accountingScenario) {

		if (accountingScenarioDao.getOverlapRecordCount(accountingScenario) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}

	}

	@Override
	public AccountingScenario updateAccountingScenario(Integer scenarioNumber, AccountingScenario accountingScenario) {

		AccountingScenarioEntity accountingScenarioEntity = accountingScenarioDao.findById(scenarioNumber)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(scenarioNumber)));
		validateBusinessConstraintsForUpdate(accountingScenario, accountingScenarioEntity);
		return accountingScenarioMapper.mapToModel(accountingScenarioDao
				.update(accountingScenarioMapper.mapToEntity(accountingScenario, accountingScenarioEntity)));
	}

	private void validateBusinessConstraintsForUpdate(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {
		validateOverlapForUpdate(accountingScenario, accountingScenarioEntity);
		validateLovValidation(accountingScenario);
		validateChargeCatCodeValidation(accountingScenario);
		validateChargeCodeValidation(accountingScenario);
		validateSourceCodeValidation(accountingScenario);
		validateFOPValidation(accountingScenario);
		validateMiscDocUtilAndMiscDocIssuedCaptured(accountingScenario);
	}

	private void validateMiscDocUtilAndMiscDocIssuedCaptured(AccountingScenario accountingScenario) {
		if (OptionalUtil.isPresent(accountingScenario.getDocType())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getDocType()).trim())
				&& !OptionalUtil.getValue(accountingScenario.getDocType()).equalsIgnoreCase("MCO")
				&& OptionalUtil.isPresent(accountingScenario.getMiscDocumentUtilType())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getMiscDocumentUtilType()).trim())
				&& OptionalUtil.isPresent(accountingScenario.getMiscDocumentIssuedFor()) && StringUtils
						.isNotEmpty(OptionalUtil.getValue(accountingScenario.getMiscDocumentIssuedFor()).trim())) {
			throw new BusinessException("Misc Document UtilType and Misc Document IssuedFor can not be captured");
		}
		if (OptionalUtil.isPresent(accountingScenario.getDocType())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getDocType()).trim())
				&& !OptionalUtil.getValue(accountingScenario.getDocType()).equalsIgnoreCase("MCO")
				&& OptionalUtil.isPresent(accountingScenario.getMiscDocumentUtilType())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getMiscDocumentUtilType()).trim())) {
			throw new BusinessException("Misc Document UtilType can not be captured");
		}
		if (OptionalUtil.isPresent(accountingScenario.getDocType())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(accountingScenario.getDocType()).trim())
				&& !OptionalUtil.getValue(accountingScenario.getDocType()).equalsIgnoreCase("MCO")
				&& OptionalUtil.isPresent(accountingScenario.getMiscDocumentIssuedFor()) && StringUtils
						.isNotEmpty(OptionalUtil.getValue(accountingScenario.getMiscDocumentIssuedFor()).trim())) {
			throw new BusinessException("Misc Document IssuedFor can not be captured");
		}

	}

	private void validateOverlapForUpdate(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		String clientId = getClientId(accountingScenario, accountingScenarioEntity);
		String module = getModule(accountingScenario, accountingScenarioEntity);
		String transactionType = getTransactionType(accountingScenario, accountingScenarioEntity);
		String selfOalIndicator = getSelfOalIndicator(accountingScenario, accountingScenarioEntity);
		Boolean salesExistIndicator = getSalesExistIndicator(accountingScenario, accountingScenarioEntity);
		String docType = getDocType(accountingScenario, accountingScenarioEntity);
		String chargeCatCode = getChargeCatCode(accountingScenario, accountingScenarioEntity);
		String chargeCode = getChargeCode(accountingScenario, accountingScenarioEntity);
		Boolean preImplementationIndicato = getPreImplementationIndicator(accountingScenario, accountingScenarioEntity);
		String miscDocumentUtilType = getMiscDocumentUtilType(accountingScenario, accountingScenarioEntity);
		String miscDocumentIssuedFor = getMiscDocumentIssuedFor(accountingScenario, accountingScenarioEntity);
		String invoiceType = getInvoiceType(accountingScenario, accountingScenarioEntity);
		String sourceCode = getSourceCode(accountingScenario, accountingScenarioEntity);
		Boolean deliveringCarrierIndicator = getDeliveringCarrierIndicator(accountingScenario,
				accountingScenarioEntity);
		Boolean receivingCarrierIndicator = getReceivingCarrierIndicator(accountingScenario, accountingScenarioEntity);
		String fopType = getFopType(accountingScenario, accountingScenarioEntity);
		String rejectionMemoType = getRejectionMemoType(accountingScenario, accountingScenarioEntity);
		String ancillaryService = getAncillaryService(accountingScenario, accountingScenarioEntity);
		Boolean bspAgentFlag = getBspAgentFlag(accountingScenario, accountingScenarioEntity);

		if (!clientId.equalsIgnoreCase(accountingScenarioEntity.getClientId())
				|| !module.equalsIgnoreCase(accountingScenarioEntity.getModule())
				|| !transactionType.equalsIgnoreCase(accountingScenarioEntity.getTransactionType())
				|| (selfOalIndicator != null
						&& !selfOalIndicator.equals(accountingScenarioEntity.getSelfOalIndicator()))
				|| (salesExistIndicator != null
						&& !salesExistIndicator.equals(accountingScenarioEntity.getSalesExistIndicator()))
				|| (docType != null && !docType.equalsIgnoreCase(accountingScenarioEntity.getDocType()))
				|| (chargeCatCode != null
						&& !chargeCatCode.equalsIgnoreCase(accountingScenarioEntity.getChargeCatCode()))
				|| (chargeCode != null && !chargeCode.equalsIgnoreCase(accountingScenarioEntity.getChargeCode()))
				|| (preImplementationIndicato != null
						&& !preImplementationIndicato.equals(accountingScenarioEntity.getPreImplementationIndicator()))
				|| (miscDocumentUtilType != null
						&& !miscDocumentUtilType.equalsIgnoreCase(accountingScenarioEntity.getMiscDocumentUtilType()))
				|| (miscDocumentIssuedFor != null
						&& !miscDocumentIssuedFor.equalsIgnoreCase(accountingScenarioEntity.getMiscDocumentIssuedFor()))
				|| (invoiceType != null && !invoiceType.equalsIgnoreCase(accountingScenarioEntity.getInvoiceType()))
				|| (sourceCode != null && !sourceCode.equals(accountingScenarioEntity.getSourceCode()))
				|| (deliveringCarrierIndicator != null
						&& !deliveringCarrierIndicator.equals(accountingScenarioEntity.getDeliveringCarrierIndicator()))
				|| (receivingCarrierIndicator != null
						&& !receivingCarrierIndicator.equals(accountingScenarioEntity.getReceivingCarrierIndicator()))
				|| (fopType != null && !fopType.equalsIgnoreCase(accountingScenarioEntity.getFopType()))
				|| (rejectionMemoType != null
						&& !rejectionMemoType.equalsIgnoreCase(accountingScenarioEntity.getRejectionMemoType()))
				|| (ancillaryService != null
						&& !ancillaryService.equalsIgnoreCase(accountingScenarioEntity.getAncillaryService()))
				|| (bspAgentFlag != null && !bspAgentFlag.equals(accountingScenarioEntity.getBspAgentFlag()))) {
			if (accountingScenarioDao.getOverlapRecordCount(accountingScenario,
					accountingScenarioEntity.getScenarioNumber()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private Boolean getBspAgentFlag(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getBspAgentFlag())
				? OptionalUtil.getValue(accountingScenario.getBspAgentFlag())
				: accountingScenarioEntity.getBspAgentFlag();
	}

	private String getAncillaryService(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getAncillaryService())
				? OptionalUtil.getValue(accountingScenario.getAncillaryService())
				: accountingScenarioEntity.getAncillaryService();
	}

	private String getRejectionMemoType(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getRejectionMemoType())
				? OptionalUtil.getValue(accountingScenario.getRejectionMemoType())
				: accountingScenarioEntity.getRejectionMemoType();
	}

	private String getFopType(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getFopType())
				? OptionalUtil.getValue(accountingScenario.getFopType())
				: accountingScenarioEntity.getFopType();
	}

	private Boolean getReceivingCarrierIndicator(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getReceivingCarrierIndicator())
				? OptionalUtil.getValue(accountingScenario.getReceivingCarrierIndicator())
				: accountingScenarioEntity.getReceivingCarrierIndicator();
	}

	private Boolean getDeliveringCarrierIndicator(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getDeliveringCarrierIndicator())
				? OptionalUtil.getValue(accountingScenario.getDeliveringCarrierIndicator())
				: accountingScenarioEntity.getDeliveringCarrierIndicator();
	}

	private String getSourceCode(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getSourceCode())
				? OptionalUtil.getValue(accountingScenario.getSourceCode())
				: accountingScenarioEntity.getSourceCode();
	}

	private String getInvoiceType(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getInvoiceType())
				? OptionalUtil.getValue(accountingScenario.getInvoiceType())
				: accountingScenarioEntity.getInvoiceType();
	}

	private String getMiscDocumentIssuedFor(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getMiscDocumentIssuedFor())
				? OptionalUtil.getValue(accountingScenario.getMiscDocumentIssuedFor())
				: accountingScenarioEntity.getMiscDocumentIssuedFor();
	}

	private String getMiscDocumentUtilType(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getMiscDocumentUtilType())
				? OptionalUtil.getValue(accountingScenario.getMiscDocumentUtilType())
				: accountingScenarioEntity.getMiscDocumentUtilType();
	}

	private Boolean getPreImplementationIndicator(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getPreImplementationIndicator())
				? OptionalUtil.getValue(accountingScenario.getPreImplementationIndicator())
				: accountingScenarioEntity.getPreImplementationIndicator();
	}

	private String getChargeCode(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getChargeCode())
				? OptionalUtil.getValue(accountingScenario.getChargeCode())
				: accountingScenarioEntity.getChargeCode();
	}

	private String getChargeCatCode(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getChargeCatCode())
				? OptionalUtil.getValue(accountingScenario.getChargeCatCode())
				: accountingScenarioEntity.getChargeCatCode();
	}

	private String getDocType(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getDocType())
				? OptionalUtil.getValue(accountingScenario.getDocType())
				: accountingScenarioEntity.getDocType();
	}

	private Boolean getSalesExistIndicator(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getSalesExistIndicator())
				? OptionalUtil.getValue(accountingScenario.getSalesExistIndicator())
				: accountingScenarioEntity.getSalesExistIndicator();
	}

	private String getSelfOalIndicator(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getSelfOalIndicator())
				? OptionalUtil.getValue(accountingScenario.getSelfOalIndicator())
				: accountingScenarioEntity.getSelfOalIndicator();
	}

	private String getTransactionType(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getTransactionType())
				? OptionalUtil.getValue(accountingScenario.getTransactionType())
				: accountingScenarioEntity.getTransactionType();
	}

	private String getModule(AccountingScenario accountingScenario, AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getModule())
				? OptionalUtil.getValue(accountingScenario.getModule())
				: accountingScenarioEntity.getModule();
	}

	private String getClientId(AccountingScenario accountingScenario,
			AccountingScenarioEntity accountingScenarioEntity) {

		return OptionalUtil.isPresent(accountingScenario.getClientId())
				? OptionalUtil.getValue(accountingScenario.getClientId())
				: accountingScenarioEntity.getClientId();
	}

	@Override
	public AccountingScenario getAccountingScenarioByScenarioNumber(Integer scenarioNumber) {

		return accountingScenarioMapper.mapToModel(accountingScenarioDao.findById(scenarioNumber)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(scenarioNumber))));
	}

	@Override
	public List<AccountingScenario> getSearchAllAccountingScenario(String transactionType, String selfOalIndicator,
			Boolean salesExistIndicator, String docType, String chargeCatCode, String chargeCode) {

		return accountingScenarioMapper.mapToModel(accountingScenarioDao.getSearchAllAccountingScenario(transactionType,
				selfOalIndicator, salesExistIndicator, docType, chargeCatCode, chargeCode));
	}

	@Override
	public List<AccountingScenario> getSearchAllAccountingScenarioWithIsActiveParam(String module,
			String transactionType, String selfOalIndicator, Boolean salesExistIndicator, String docType,
			String chargeCatCode, String chargeCode, Boolean isActive) {

		return accountingScenarioMapper.mapToModel(
				accountingScenarioDao.getSearchAllAccountingScenarioWithIsActiveParam(module, transactionType,
						selfOalIndicator, salesExistIndicator, docType, chargeCatCode, chargeCode, isActive));
	}

	@Override
	public void activateAccountingScenario(AccountingScenario accountingScenario) {

		AccountingScenarioEntity accountingScenarioEntity = accountingScenarioDao
				.findById(accountingScenario.getScenarioNumber())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountingScenario.getScenarioNumber())));

		if (OptionalUtil.getValue(accountingScenario.getLastUpdatedBy()).isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (OptionalUtil.getValue(accountingScenario.getLastUpdatedBy()).length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (accountingScenarioEntity.getIsActive())
			throw new BusinessException(ACTIVE_ACCOUNTING_SCENARIO);

		accountingScenarioEntity.setIsActive(Boolean.TRUE);

		accountingScenarioDao
				.update(accountingScenarioMapper.mapToEntity(accountingScenario, accountingScenarioEntity));
	}

	@Override
	public void deactivateAccountingScenario(AccountingScenario accountingScenario) {
		AccountingScenarioEntity accountingScenarioEntity = accountingScenarioDao
				.findById(accountingScenario.getScenarioNumber())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountingScenario.getScenarioNumber())));

		if (OptionalUtil.getValue(accountingScenario.getLastUpdatedBy()).isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (OptionalUtil.getValue(accountingScenario.getLastUpdatedBy()).length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (!accountingScenarioEntity.getIsActive()) {
			throw new BusinessException(ACCOUNTING_SCENARIO_ALREADY_INACTIVE);
		}
		accountingScenarioEntity.setIsActive(Boolean.FALSE);

		accountingScenarioDao
				.update(accountingScenarioMapper.mapToEntity(accountingScenario, accountingScenarioEntity));
	}
}
