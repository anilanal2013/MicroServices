package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.repository.entity.EMDEntity;
import com.sgl.smartpra.master.model.EMDModel;

public class EMDEntitySpecification {

	public static Specification<EMDEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (emdEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), emdEntity.get("effectiveFromDate"),
				emdEntity.get("effectiveToDate"));
	}

	public static Specification<EMDEntity> isActive() {
		return (emdEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(emdEntity.get("activate"), true);
	}

	public static Specification<EMDEntity> equalsClientId(String clientId) {
		return (emdEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(emdEntity.get("clientId"),
				clientId);
	}

	public static Specification<EMDEntity> equalsReasonForIssuanceCode(String reasonForIssuanceCode) {
		return (emdEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(emdEntity.get("reasonForIssuanceCode"), reasonForIssuanceCode);
	}

	public static Specification<EMDEntity> equalsReasonForIssuanceSubCode(String reasonForIssuanceSubCode) {
		return (emdEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(emdEntity.get("reasonForIssuanceSubCode"), reasonForIssuanceSubCode);
	}

	public static Specification<EMDEntity> notEqualsAgencyDetailsId(Integer emdId) {
		return (emdEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(emdEntity.get("emdId"), emdId);
	}

	public static void orderByAsc(Root<EMDEntity> emdEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String effectiveToDate) {
		criteriaQuery.orderBy(criteriaBuilder.asc(emdEntity.get(effectiveToDate)));
	}

	public static Specification<EMDEntity> search(EMDModel emdModel, Optional<String> exceptionCall) {
		return (emdEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (OptionalUtil.isPresent(emdModel.getClientId())) {
				predicates.add(criteriaBuilder.equal(emdEntity.get("clientId"),
						OptionalUtil.getValue(emdModel.getClientId()) ));
			}
			if (OptionalUtil.isPresent(emdModel.getReasonForIssuanceCode())) {
				predicates.add(criteriaBuilder.like(emdEntity.get("reasonForIssuanceCode"),
						OptionalUtil.getValue(emdModel.getReasonForIssuanceCode()) + "%"));
			}
			if (OptionalUtil.isPresent(emdModel.getReasonForIssuanceSubCode())) {
				predicates.add(criteriaBuilder.like(emdEntity.get("reasonForIssuanceSubCode"),
						OptionalUtil.getValue(emdModel.getReasonForIssuanceSubCode()) + "%"));
			}
			if (OptionalUtil.isPresent(emdModel.getSalesSource())) {
				predicates.add(
						criteriaBuilder.like(emdEntity.get("salesSource"), OptionalUtil.getValue(emdModel.getSalesSource()) + "%"));
			}
			if (OptionalUtil.isPresent(emdModel.getEffectiveFromDate()) && OptionalUtil.isPresent(emdModel.getEffectiveToDate())
					&& OptionalUtil.getValue(emdModel.getEffectiveFromDate()) != null
					&& OptionalUtil.getValue(emdModel.getEffectiveToDate()) != null
					&& !OptionalUtil.getValue(emdModel.getEffectiveFromDate()).isEmpty()
					&& !OptionalUtil.getValue(emdModel.getEffectiveToDate()).isEmpty()) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(emdModel.getEffectiveFromDate())),
								emdEntity.get("effectiveFromDate"), emdEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(emdModel.getEffectiveToDate())),
								emdEntity.get("effectiveFromDate"), emdEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(emdModel.getEffectiveFromDate()) && OptionalUtil.getValue(emdModel.getEffectiveFromDate()) != null
						&& !OptionalUtil.getValue(emdModel.getEffectiveFromDate()).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(emdModel.getEffectiveFromDate())),
							emdEntity.get("effectiveFromDate"), emdEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(emdModel.getEffectiveToDate()) && OptionalUtil.getValue(emdModel.getEffectiveToDate()) != null
						&& !OptionalUtil.getValue(emdModel.getEffectiveToDate()).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(emdModel.getEffectiveToDate())),
							emdEntity.get("effectiveFromDate"), emdEntity.get("effectiveToDate")));
				}
			}
			if(!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (emdModel.getActivate() != null) {
					predicates.add(criteriaBuilder.equal(emdEntity.get("activate"), emdModel.getActivate()));
				}
				if (emdModel.getActivate() == null) {
					predicates.add(criteriaBuilder.equal(emdEntity.get("activate"), true));
				}
			}
			orderByAsc(emdEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<EMDEntity> equalsEmdType(String emdType) {
		return (emdEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(emdEntity.get("emdType"), emdType);
	}

	public static Specification<EMDEntity> equalsServiceType(String serviceType) {
		return (emdEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(emdEntity.get("serviceType"),
				serviceType);
	}

}
