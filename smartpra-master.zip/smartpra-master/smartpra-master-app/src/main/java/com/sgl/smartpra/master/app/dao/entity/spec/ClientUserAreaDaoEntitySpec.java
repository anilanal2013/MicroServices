package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.ClientUserAreaEntity;

public class ClientUserAreaDaoEntitySpec {
	ClientUserAreaDaoEntitySpec() {
	}
	public static Specification<ClientUserAreaEntity> search(Optional<String> userAreaCode,
			Optional<String> userAreaName, Optional<Boolean> activate) {
		return (clientUserAreaEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(userAreaCode)) {
				predicates.add(criteriaBuilder.equal(clientUserAreaEntity.get("userAreaCode"),
						OptionalUtil.getValue(userAreaCode)));
			}
			if (OptionalUtil.isPresent(userAreaName)) {
				predicates.add(criteriaBuilder.like(clientUserAreaEntity.get("userAreaName"),
						OptionalUtil.getValue(userAreaName) + "%"));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(
						criteriaBuilder.equal(clientUserAreaEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(clientUserAreaEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ClientUserAreaEntity> equalsUserAreaCode(String userAreaCode) {
		return (clientUserAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(clientUserAreaEntity.get("userAreaCode"), userAreaCode);
	}

	public static Specification<ClientUserAreaEntity> equalsAreaKey1(String areaKey1) {
		return (clientUserAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(clientUserAreaEntity.get("areaKey1"), areaKey1);
	}

	public static Specification<ClientUserAreaEntity> equalsAreaKey2(String areaKey2) {
		return (clientUserAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(clientUserAreaEntity.get("areaKey2"), areaKey2);
	}

	public static Specification<ClientUserAreaEntity> equalsAreaKey3(String areaKey3) {
		return (clientUserAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(clientUserAreaEntity.get("areaKey3"), areaKey3);
	}

	public static Specification<ClientUserAreaEntity> equalsAreaKey4(String areaKey4) {
		return (clientUserAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(clientUserAreaEntity.get("areaKey4"), areaKey4);
	}

	public static Specification<ClientUserAreaEntity> isActive() {
		return (clientUserAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(clientUserAreaEntity.get("activate"), true);
	}

	public static Specification<ClientUserAreaEntity> getClientUserArea(String userAreaCode, String areaKey1,
			String areaKey2, String areaKey3, String areaKey4, Boolean activate) {
		return (clientUserAreaEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (userAreaCode != null) {
				predicates.add(criteriaBuilder.equal(clientUserAreaEntity.get("userAreaCode"), userAreaCode));
			}
			if (areaKey1 != null) {
				predicates.add(criteriaBuilder.equal(clientUserAreaEntity.get("areaKey1"), areaKey1));
			}
			if (areaKey2 != null) {
				predicates.add(criteriaBuilder.equal(clientUserAreaEntity.get("areaKey2"), areaKey2));
			}
			if (areaKey3 != null) {
				predicates.add(criteriaBuilder.equal(clientUserAreaEntity.get("areaKey3"), areaKey3));
			}
			if (areaKey4 != null) {
				predicates.add(criteriaBuilder.equal(clientUserAreaEntity.get("areaKey4"), areaKey4));
			}
			if (activate != null) {
				predicates.add(criteriaBuilder.equal(clientUserAreaEntity.get("activate"), activate));
			}
			if (activate == null) {
				predicates.add(criteriaBuilder.equal(clientUserAreaEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ClientUserAreaEntity> findByAreaKey3(String areaKey3) {
		return (clientUserAreaEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (areaKey3!=null) {
				predicates.add(
						criteriaBuilder.equal(clientUserAreaEntity.get("areaKey3"), areaKey3));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
