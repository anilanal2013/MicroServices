package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.RegionEntity;
import com.sgl.smartpra.master.model.Region;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface RegionMapper  extends BaseMapper<Region, RegionEntity> {
	
	RegionEntity mapToEntity(Region region, @MappingTarget RegionEntity regionEntity);

	RegionEntity mapToEntity(Region region);

}