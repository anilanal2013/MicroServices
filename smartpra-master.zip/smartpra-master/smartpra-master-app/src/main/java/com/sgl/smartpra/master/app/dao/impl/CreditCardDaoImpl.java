package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.CreditCardDao;
import com.sgl.smartpra.master.app.dao.entity.CreditCardEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.CreditCardEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.CreditCardRepository;
import com.sgl.smartpra.master.model.CreditCard;

@Component
public class CreditCardDaoImpl implements CreditCardDao {

	@Autowired
	private CreditCardRepository creditCardRepository;

	@Override
	public List<CreditCardEntity> getAllCreditCard(CreditCard creditCard, Optional<String> exceptionCall) {
		return creditCardRepository.findAll(CreditCardEntitySpecification.search(creditCard, exceptionCall));
	}

	@Override
	@Cacheable(value = "creditCard", key = "#id")
	public Optional<CreditCardEntity> findById(Integer id) {
		return creditCardRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "creditCard", key = "#creditCardEntity.creditCardId") })
	public CreditCardEntity createCreditCard(CreditCardEntity creditCardEntity) {
		return creditCardRepository.save(creditCardEntity);
	}

	@Override
	@CachePut(value = "creditCard", key = "#creditCardEntity.creditCardId")
	public CreditCardEntity updateCreditCard(CreditCardEntity creditCardEntity) {
		return creditCardRepository.save(creditCardEntity);
	}

	@Override
	public long getOverLapForCreate(Optional<String> clientId, Optional<String> ccCompanyCode,
			Optional<String> uatpAirlineCode) {
		return creditCardRepository
				.count(Specification.where(CreditCardEntitySpecification.equalsClientId(OptionalUtil.getValue(clientId))
						.and(CreditCardEntitySpecification.equalsCcCompanyCode(OptionalUtil.getValue(ccCompanyCode))
								.and(CreditCardEntitySpecification
										.equalsUatpAirlineCode(OptionalUtil.getValue(uatpAirlineCode))
										.and(CreditCardEntitySpecification.isActive())))));
	}

	@Override
	public long getOverLapForUpdate(String clientId, String ccCompanyCode, String uatpAirlineCode,
			Integer creditCardId) {
		return creditCardRepository.count(Specification.where(CreditCardEntitySpecification.equalsClientId(clientId)
				.and(CreditCardEntitySpecification.equalsCcCompanyCode(ccCompanyCode)
						.and(CreditCardEntitySpecification.equalsUatpAirlineCode(uatpAirlineCode)
								.and(CreditCardEntitySpecification.isActive())
								.and(CreditCardEntitySpecification.notEqualsCreditCardId(creditCardId))))));
	}
}
