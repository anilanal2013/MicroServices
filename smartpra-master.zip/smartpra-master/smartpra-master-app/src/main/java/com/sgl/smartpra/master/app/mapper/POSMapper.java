package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.repository.entity.POSEntity;
import com.sgl.smartpra.master.model.POS;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface POSMapper extends BaseMapper<POS, POSEntity> {

	POSEntity mapToEntity(POS pos, @MappingTarget POSEntity posEntity);

	@Mapping(source = "posId", target = "posId", ignore = true)
	POSEntity mapToEntity(POS pos);
}
