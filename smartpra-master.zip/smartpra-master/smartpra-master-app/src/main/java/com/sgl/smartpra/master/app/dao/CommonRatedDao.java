package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;
import com.sgl.smartpra.master.app.repository.entity.CommonRatedSectorEntity;

@Repository
public interface CommonRatedDao {


    public List<CommonRatedSectorEntity> search(Optional<String> clientId, Optional<String> fromAirport,
                                                Optional<String> toAirport, Optional<String> commonRatedFromAirport,
                                                Optional<String> commonRatedToAirport);

    CommonRatedSectorEntity createCommonRateSectors(CommonRatedSectorEntity commonRatedSectorEntity);

    Optional<CommonRatedSectorEntity> findById(Integer commonRatedID);

    CommonRatedSectorEntity updateCommonRateSectors(CommonRatedSectorEntity commonRatedSectorEntity);

    Optional<CommonRatedSectorEntity> findCommonRatedSectorByCommonRatedSectorId(Integer commonRatedID);

    long validateOverLapForCreate(Optional<String> clientId, Optional<String> fromAirport, Optional<String> toAirport,
                                  Optional<String> commonRatedFromAirport, Optional<String> commonRatedToAirport,
                                  Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

    long validateOverLapForUpdate(String clientId, String fromAirport, String toAirport,
                                  String commonRatedFromAirport, String commonRatedToAirport,
                                  LocalDate effectiveFromDate, LocalDate effectiveToDate, Integer commonRatedID);

    List<CommonRatedSectorEntity> getAllCommonRatedSectors( Optional<String> fromAirport,
                                                     Optional<String> toAirport, Optional<String> commonRatedFromAirport,
                                                     Optional<String> commonRatedToAirport, Optional<String> effectiveFromDate,
                                                     Optional<String> effectiveToDate);
}
