package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.FlightRangeEntity;

@Repository
public interface FlightRangeDao {

	public FlightRangeEntity create(FlightRangeEntity flightRangeEntity);

	public FlightRangeEntity update(FlightRangeEntity flightRangeEntity);

	public List<FlightRangeEntity> searchFlightRange(Optional<String> flightRangeId,
			Optional<String> isMarketingOperating, Optional<String> cxrCode, Optional<String> flightNumber,
			Optional<Boolean> activate);

	public Optional<FlightRangeEntity> findById(Integer flightRangeAutoId);

	public List<FlightRangeEntity> getAllFlightEntity(String flightRangeId, String isMarketingOperating, String cxrCode,
			String flightNumber, LocalDate saleDate, LocalDate travelDate);

	public List<FlightRangeEntity> valiadateIssueDate(Integer flightRangeAutoId, LocalDate utilDate, String clientId,
			String flag);

	public long getOverLapForCreate(Optional<String> clientId, Optional<String> flightRangeId,
			Optional<Integer> recordSeqNumber);

	public int flightNumberVerifyIfOverlapExits(String fromFlightNumber, String toFlightNumber, String flightRangeId,
			String isMarketingOperating, String cxrCode);

	public int recordSeqNumberVerifyIfOverlapExits(String flightRangeId, String isMarketingOperating, String cxrCode,
			Integer recordSeqNumber);

	public List<FlightRangeEntity> flightRangeUniqueKey(String clientId, String flightRangeId);

	public List<Integer> verifyIfSameSaleRecordExits(LocalDate saleFromDate, LocalDate saleToDate);

	public List<Integer> verifyIfSameTravelRecordExits(LocalDate travelFromDate, LocalDate travelToDate);
}
