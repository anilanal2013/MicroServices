package com.sgl.smartpra.master.app.service;

import java.util.Date;
import java.util.List;

import com.sgl.smartpra.master.model.Flight;

public interface FlightService {
	public Flight getFlightByEffectiveDate(Date effectiveDate, String flightFrom, String flightTo, String from,
			String to);
	
	public Flight getFlightByFlightNumber(String clientId, String effectiveDate, String flightNumber, String from,
			String to);

	public Flight getFlightByFlightId(Integer flightId);

	public Flight createFlight(Flight flight);

	public Flight updateFlight(Integer flightId, Flight flight);

	public void deactivateFlight(Integer flightId, String lastUpdatedBy);

	public void activateFlight(Integer flightId, String lastUpdatedBy);

	public List<Flight> getFlightByFlightDetails(String flightAttribute1, String flightAttribute2,
			String flightAttribute3, String flightAttribute4, String flightAttribute5);
}
