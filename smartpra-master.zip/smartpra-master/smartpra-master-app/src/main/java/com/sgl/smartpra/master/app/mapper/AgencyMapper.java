package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.AgencyMasterEntity;
import com.sgl.smartpra.master.model.AgencyMaster;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AgencyMapper extends BaseMapper<AgencyMaster, AgencyMasterEntity> {

	AgencyMasterEntity mapToEntity(AgencyMaster agencyMaster, @MappingTarget AgencyMasterEntity agencyMasterList);

	@Mapping(source = "agencyId", target = "agencyId", ignore = true)
	AgencyMasterEntity mapToEntity(AgencyMaster agencyMaster);
}
