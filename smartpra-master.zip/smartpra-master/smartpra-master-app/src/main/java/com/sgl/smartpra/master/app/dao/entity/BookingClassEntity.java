package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_booking_class")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class BookingClassEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "booking_class_id")
	private int bookingClassId;

	@Column(name = "client_id", nullable = false, length = 2)
	private String clientId;

	@Column(name = "util_effective_fm_date", nullable = false)
	private LocalDate utilEffectiveFromDate;

	@Column(name = "util_effective_to_date", nullable = false)
	private LocalDate utilEffectiveToDate;

	@Column(name = "sales_effective_fm_date", nullable = true)
	private LocalDate salesEffectiveFromDate;

	@Column(name = "sales_effective_to_date", nullable = true)
	private LocalDate salesEffectiveToDate;

	@Column(name = "rbd", nullable = false, length = 1)
	private String rbd;

	@Column(name = "cabin", nullable = false, length = 1)
	private String cabin;

	@Column(name = "marketing_carrier", length = 2, nullable = true)
	private String marketingCarrier;

	@Column(name = "operating_carrier", nullable = true)
	private String operatingCarrier;

	@Column(name = "from_airport", length = 3, nullable = true)
	private String fromAirport;

	@Column(name = "to_airport", length = 3, nullable = true)
	private String toAirport;

	@Column(name = "cabin_priority", nullable = true)
	private Integer cabinPriority;

	@Column(name = "rbd_description")
	private String rbdDescription;

	@Column(name = "is_active", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

}
