package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.InterfaceReferenceService;
import com.sgl.smartpra.master.model.InterfaceReference;
import com.sgl.smartpra.master.model.InterfaceReferenceRes;

@RestController
public class InterfaceReferenceController {

	@Autowired
	private InterfaceReferenceService interfaceReferenceService;

	@GetMapping("/interface-reference")
	public List<InterfaceReference> getAllInterfaceReference(
			@RequestParam(value = "dataSource", required = false) Optional<String> dataSource,
			@RequestParam(value = "stationCode", required = false) Optional<String> stationCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return interfaceReferenceService.getListOfInterfaceReference(Optional.of("QR"),dataSource, stationCode, effectiveFromDate,
				effectiveToDate, activate,Optional.of(""));
	}
	
	@GetMapping("/interface-reference/search/clientid/{clientId}")
	public List<InterfaceReference> getAllInterfaceReference(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "dataSource", required = false) Optional<String> dataSource,
			@RequestParam(value = "stationCode", required = false) Optional<String> stationCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {
		return interfaceReferenceService.getListOfInterfaceReference(clientId,dataSource, stationCode, effectiveFromDate,
				effectiveToDate, activate,exceptionCall);
	}

	@GetMapping("/interface-reference/{interfaceRefId}")
	public InterfaceReference getInterfaceReferenceByInterfaceReferenceCode(
			@PathVariable(value = "interfaceRefId") Integer interfaceRefId) {
		return interfaceReferenceService.getInterfaceReferenceByRefId(interfaceRefId);
	}

	@GetMapping("/interface-reference/interface-reference-date-search")
	public InterfaceReference getInterfaceReferenceByDataSourceAndStationCodeWithEffectiveDate(
			@RequestParam(value = "clientId", required = true) Optional<String> clientId,
			@RequestParam(value = "dataSource", required = true) Optional<String> dataSource,
			@RequestParam(value = "stationCode", required = true) Optional<String> stationCode,
			@RequestParam(value = "effectiveDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return interfaceReferenceService.getInterfaceReferenceByDataSourceAndStationCodeWithEffectiveDate(clientId,
				dataSource, stationCode, effectiveDate);
	}

	@PostMapping("/interface-reference")
	@ResponseStatus(value = HttpStatus.CREATED)
	public InterfaceReference createInterfaceReference(
			@Validated(Create.class) @RequestBody InterfaceReference interfaceReference) {
		return interfaceReferenceService.createInterfaceRef(interfaceReference);
	}

	@PutMapping("/interface-reference/{interfaceRefId}")
	@ResponseStatus(value = HttpStatus.OK)
	public InterfaceReference updateInterfaceReference(@PathVariable(value = "interfaceRefId") Integer interfaceRefId,
			@Validated(Update.class) @RequestBody InterfaceReference interfaceReference) {
		return interfaceReferenceService.updateInterfaceRef(interfaceRefId, interfaceReference);
	}

	@PutMapping("/interface-reference/{interfaceRefId}/deactivate")
	public void deactivateInterfaceReference(@Valid @PathVariable(value = "interfaceRefId") Integer interfaceRefId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		interfaceReferenceService.deactivateInterfaceReference(interfaceRefId, lastUpdatedBy);
	}

	@PutMapping("/interface-reference/{interfaceRefId}/activate")
	public void activateInterfaceReference(@Valid @PathVariable(value = "interfaceRefId") Integer interfaceRefId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		interfaceReferenceService.activateInterfaceReference(interfaceRefId, lastUpdatedBy);
	}

	@GetMapping("/interface-reference/list")
	public InterfaceReferenceRes getAllInterfaceReference(Pageable pageable,
			@RequestParam(value = "dataSource", required = false) Optional<String> dataSource,
			@RequestParam(value = "stationCode", required = false) Optional<String> stationCode,
			@RequestParam(value = "effectiveFromDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Boolean activate) {

		InterfaceReference interfaceReference = new InterfaceReference();
		interfaceReference.setDataSource(dataSource);
		interfaceReference.setStationCode(stationCode);
		interfaceReference.setActivate(activate);
		if (OptionalUtil.isPresent(effectiveFromDate)) {
			interfaceReference.setEffectiveFromDate(effectiveFromDate);
		}
		if (OptionalUtil.isPresent(effectiveToDate)) {
			interfaceReference.setEffectiveToDate(effectiveToDate);
		}
		return interfaceReferenceService.getListOfInterfaceReference(pageable, interfaceReference);
	}
}
