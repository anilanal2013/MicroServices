package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.AccountEntity;
import com.sgl.smartpra.master.app.repository.entity.POSEntity;

public final class POSEntitySpecification {

	private static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";

	private static final String EFFECTIVE_TO_DATE = "effectiveToDate";

	private static void orderByAsc(Root<POSEntity> posEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String effectiveToDate) {
		criteriaQuery.orderBy(criteriaBuilder.asc(posEntity.get(effectiveToDate)));
	}

	public static Specification<POSEntity> search(Optional<String> clientId, Optional<String> posCode, Optional<String> posName,
			Optional<String> accountCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return (posEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(posEntity.get("clientId"),
						OptionalUtil.getValue(clientId) ));
			}
			if (OptionalUtil.isPresent(posCode)) {
				predicates.add(criteriaBuilder.like(posEntity.get("posCode"), OptionalUtil.getValue(posCode) + "%"));
			}
			if (OptionalUtil.isPresent(accountCode)) {
				predicates.add(
						criteriaBuilder.like(posEntity.get("accountCode"), OptionalUtil.getValue(accountCode) + "%"));
			}
			if (OptionalUtil.isPresent(posName)) {
				predicates.add(criteriaBuilder.like(posEntity.get("posName"), OptionalUtil.getValue(posName) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								posEntity.get(EFFECTIVE_FROM_DATE), posEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								posEntity.get(EFFECTIVE_FROM_DATE), posEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(posEntity.get(EFFECTIVE_FROM_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate)),
						criteriaBuilder.between(posEntity.get(EFFECTIVE_TO_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							posEntity.get(EFFECTIVE_FROM_DATE), posEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							posEntity.get(EFFECTIVE_FROM_DATE), posEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			orderByAsc(posEntity, criteriaQuery, criteriaBuilder, EFFECTIVE_TO_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<POSEntity> equalsPosCode(String posCode) {
		return (posEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(posEntity.get("posCode"), posCode);
	}

	public static Specification<POSEntity> equalsClientId(String clientId) {
		return (posEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(posEntity.get("clientId"),
				clientId);
	}

	public static Specification<POSEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (posEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), posEntity.get(EFFECTIVE_FROM_DATE),
				posEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<POSEntity> greaterThanOrEqualTo(LocalDate effectiveFromDate) {
		return (posEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(posEntity.get(EFFECTIVE_FROM_DATE), effectiveFromDate);
	}

	public static Specification<POSEntity> lessThanOrEqualTo(LocalDate effectiveToDate) {
		return (posEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(posEntity.get(EFFECTIVE_TO_DATE), effectiveToDate);
	}

	public static Specification<POSEntity> notEqualsfopId(Integer posId) {
		return (posEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(posEntity.get("posId"), posId);

	}
}