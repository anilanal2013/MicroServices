package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.Length;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_carrier_alliance database table.
 * 
 */
@Entity
@Table(name = "mas_carrier_alliance")
@Data
@EqualsAndHashCode(callSuper=false)
@DynamicUpdate
@DynamicInsert
public class CarrierAllianceEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "carrier_alliance_dtl_id")
	private Integer carrierAllianceDtlId;

	@Column(name = "alliance_name", nullable = false)
	@NotEmpty
	private String allianceName;

	@Column(name = "carrier_code", nullable = false)
	@NotEmpty
	private String carrierCode;

	@Column(name = "client_id", length = 2)
	@NotEmpty
	private String clientId;

	@Column(name = "deferred_billing")
	private Integer deferredBilling;

	@Column(name = "effective_from_date")
	@NotNull
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	@NotNull
	private LocalDate effectiveToDate;

	@Column(name = "esal_mom_cutoff_months")
	private Integer esalMomCutoffMonths;

	@Column(name = "generate_empty_files")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean generateEmptyFiles;

	@Column(name = "tax_billing_for_ffy_coupon")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean taxBillingForFFYCoupon;

	@Column(name = "fare_billing_for_ffy_coupon")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean fareBillingForFFYCoupon;

	@Column(name = "response_circulation_period")
	private Integer responseCirculationPeriod;

	@Column(name = "response_out_methods")
	@Length(min = 2, max = 2)
	private String responseOutMethods;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}