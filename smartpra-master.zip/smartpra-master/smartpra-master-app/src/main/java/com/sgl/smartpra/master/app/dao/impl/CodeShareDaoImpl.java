package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.master.app.dao.CodeShareDao;
import com.sgl.smartpra.master.app.dao.entity.CodeShareEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.CodeShareEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.CodeShareRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CodeShareDaoImpl<T> extends CommonSearchDao<T> implements CodeShareDao  {

	@Autowired
	private CodeShareRepository codeShareRepository;
	
	@Override
	@Caching(evict = { @CacheEvict(value = "codeShare", key = "#codeShareEntity.codeShareId"),
			@CacheEvict(value = "clientId", allEntries = true),@CacheEvict(value = "marketingCXR", allEntries = true),
			@CacheEvict(value = "marketedRBDList", allEntries = true), @CacheEvict(value = "effectiveDate", allEntries = true),
			@CacheEvict(value = "flightNumber", allEntries = true)})
	public CodeShareEntity create(CodeShareEntity codeShareEntity) {
		return codeShareRepository.save(codeShareEntity);
	}

	@Override
	@Cacheable(value = "codeShare", key = "#id")
	public Optional<CodeShareEntity> findById(Integer id) {
		log.info("Cacheable CodeShare Entity's ID= {}", id);
		return codeShareRepository.findById(id);
	}

	@Override
	@CachePut(value = "codeShare", key = "#codeShareEntity.codeShareId")
	@Caching(evict = { @CacheEvict(value = "clientId", allEntries = true),@CacheEvict(value = "marketingCXR", allEntries = true),
			@CacheEvict(value = "marketedRBDList", allEntries = true), @CacheEvict(value = "effectiveDate", allEntries = true),
			@CacheEvict(value = "flightNumber", allEntries = true)})
	public CodeShareEntity update(CodeShareEntity codeShareEntity) {
		return codeShareRepository.save(codeShareEntity);
	}


	@Override
	public List<CodeShareEntity> findAll(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> travelFromDate, Optional<String> travelToDate,Optional<String> saleFromDate, Optional<String> saleToDate,
			Optional<Boolean> isActive) {
		return codeShareRepository
				.findAll(CodeShareEntitySpecification.search(clientId, marketingCXR, travelFromDate, travelToDate, saleFromDate, saleToDate, isActive));
	}

	@Override
	public List<CodeShareEntity> search(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> marketedRBDList, Optional<String> effectiveDate) {
		return codeShareRepository
				.findAll(CodeShareEntitySpecification.getCodeShareByEffectiveDate(clientId, marketingCXR,marketedRBDList,effectiveDate));
	}
	
	@Override
	public long saleVerifyIfOverlapExits(LocalDate saleFromDate, LocalDate saleToDate) {
		return codeShareRepository.count(Specification
				.where(CodeShareEntitySpecification.betweenSaleFromAndSaleToDate(saleFromDate)
						.or(CodeShareEntitySpecification.betweenSaleFromAndSaleToDate(saleToDate))
						.and(CodeShareEntitySpecification.isActive())));
	}
	
	@Override
	public long travelVerifyIfOverlapExits(LocalDate travelFromDate, LocalDate travelToDate) {
		return codeShareRepository.count(Specification
				.where(CodeShareEntitySpecification.betweenTravelFromAndTravelToDate(travelFromDate)
						.or(CodeShareEntitySpecification.betweenTravelFromAndTravelToDate(travelToDate))
						.and(CodeShareEntitySpecification.isActive())));
	}
	
	
//	@Override
//	public long overlappingCXRWithFlightNumber(String marketingCXR, Integer fromBookedFlightNumber,Integer toBookedFlightNumber,
//			LocalDate saleFromDate,LocalDate saleToDate,LocalDate travelFromDate,LocalDate travelToDate,String clientId){
//		return codeShareRepository.count(Specification
//				.where(CodeShareEntitySpecification.equalsClientId(clientId)
//				.and(CodeShareEntitySpecification.equalsMarketingCXR(marketingCXR))
//				.and(CodeShareEntitySpecification.equalsFromBookedFlightNumber(fromBookedFlightNumber))
//				.and(CodeShareEntitySpecification.equalsToBookedFlightNumber(toBookedFlightNumber))
//				.and((CodeShareEntitySpecification.betweenTravelFromAndTravelToDate(travelFromDate)
//						.or(CodeShareEntitySpecification.betweenTravelFromAndTravelToDate(travelToDate)))
//						.or(CodeShareEntitySpecification.travelGreaterThanOrEqualTo(travelFromDate)
//						.and(CodeShareEntitySpecification.travelLessThanOrEqualTo(travelToDate))))
//				.and((CodeShareEntitySpecification.betweenSaleFromAndSaleToDate(saleFromDate)
//						.or(CodeShareEntitySpecification.betweenSaleFromAndSaleToDate(saleToDate)))
//						.or(CodeShareEntitySpecification.saleGreaterThanOrEqualTo(saleFromDate)
//						.and(CodeShareEntitySpecification.saleLessThanOrEqualTo(saleToDate))))));
//	}
	
	
//	@Override
//	public long overlappingCXRWithFlightNumberForUpdate(String marketingCXR, Integer fromBookedFlightNumber,Integer toBookedFlightNumber,
//			LocalDate saleFromDate,LocalDate saleToDate,LocalDate travelFromDate,LocalDate travelToDate,String clientId, Integer codeShareId){
//		return codeShareRepository.count(Specification
//				.where(CodeShareEntitySpecification.equalsClientId(clientId)
//				.and(CodeShareEntitySpecification.equalsMarketingCXR(marketingCXR))
//				.and(CodeShareEntitySpecification.equalsFromBookedFlightNumber(fromBookedFlightNumber))
//				.and(CodeShareEntitySpecification.equalsToBookedFlightNumber(toBookedFlightNumber))
//				.and(CodeShareEntitySpecification.notEqualsCodeShareId(codeShareId))
//				.and((CodeShareEntitySpecification.betweenTravelFromAndTravelToDate(travelFromDate)
//						.or(CodeShareEntitySpecification.betweenTravelFromAndTravelToDate(travelToDate)))
//						.or(CodeShareEntitySpecification.travelGreaterThanOrEqualTo(travelFromDate)
//						.and(CodeShareEntitySpecification.travelLessThanOrEqualTo(travelToDate))))
//				.and((CodeShareEntitySpecification.betweenSaleFromAndSaleToDate(saleFromDate)
//						.or(CodeShareEntitySpecification.betweenSaleFromAndSaleToDate(saleToDate)))
//						.or(CodeShareEntitySpecification.saleGreaterThanOrEqualTo(saleFromDate)
//						.and(CodeShareEntitySpecification.saleLessThanOrEqualTo(saleToDate))))));
//	}

	@Override
	@Cacheable(value = "codeShare", key = "#id")
	public Optional<CodeShareEntity> findByCodeShareId(Integer id) {
		log.info("Cacheable Code Share Entity's ID= {}", id);
		return codeShareRepository.findById(id);
	}
	
	@Override
	@Cacheable(cacheNames={"clientId","marketingCXR", "marketedRBDList","effectiveDate","flightNumber"})
	public Optional<CodeShareEntity> getCodeShareBymarketingCXRForBSP(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> marketedRBDList, Optional<String> effectiveDate, Optional<String> flightNumber) {
		return codeShareRepository.findOne(Specification.where(CodeShareEntitySpecification.
				getCodeShareBySaleEffectiveDate(clientId, marketingCXR, marketedRBDList, effectiveDate,flightNumber)));
	}

	@Override
	public long overlappingCXRWithFlightNumber(Optional<String> marketingCXR, Optional<String> fromBookedFlightNumber,
			Optional<String> toBookedFlightNumber, Optional<String> saleFromDate, Optional<String> saleToDate,
			Optional<String> travelFromDate, Optional<String> travelToDate, Optional<Integer> codeShareId,Optional<String> clientId) {
		return codeShareRepository.count(CodeShareEntitySpecification.checkOverlapping(marketingCXR, fromBookedFlightNumber, toBookedFlightNumber, saleFromDate, saleToDate, 
				travelFromDate, travelToDate, clientId, codeShareId));
	}

}
