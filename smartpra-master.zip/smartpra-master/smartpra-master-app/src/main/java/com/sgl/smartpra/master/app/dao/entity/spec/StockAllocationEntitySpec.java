package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.StockAllocationEntity;

public class StockAllocationEntitySpec {
	private StockAllocationEntitySpec() {
	}

	public static void orderByAsc(Root<StockAllocationEntity> stockAllocationEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(stockAllocationEntity.get(orderByString)));
	}

	public static Specification<StockAllocationEntity> searchAll(Integer stockId, Optional<String> documentSeriesFrom,
			Optional<String> documentSeriesTo, Optional<String> documentType, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate) {
		return (stockAllocationEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (stockId != null) {
				predicates.add(criteriaBuilder.equal(stockAllocationEntity.get("stockId"),stockId));
			}
			
			if (OptionalUtil.isPresent(documentSeriesFrom) && OptionalUtil.isPresent(documentSeriesTo)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getValue(documentSeriesFrom)),
								stockAllocationEntity.get("documentSeriesFrom"),
								stockAllocationEntity.get("documentSeriesTo")),
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getValue(documentSeriesTo)),
								stockAllocationEntity.get("documentSeriesFrom"),
								stockAllocationEntity.get("documentSeriesTo"))));
			} else {
				if (OptionalUtil.isPresent(documentSeriesFrom)) {
					predicates.add(
							criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getValue(documentSeriesFrom)),
									stockAllocationEntity.get("documentSeriesFrom"),
									stockAllocationEntity.get("documentSeriesTo")));
				}
				if (OptionalUtil.isPresent(documentSeriesTo)) {
					predicates.add(
							criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getValue(documentSeriesTo)),
									stockAllocationEntity.get("documentSeriesFrom"),
									stockAllocationEntity.get("documentSeriesTo")));
				}
			}
			if (OptionalUtil.isPresent(documentType)) {
				predicates.add(criteriaBuilder.like(stockAllocationEntity.get("documentType"),
						OptionalUtil.getValue(documentType) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
						stockAllocationEntity.get("effectiveFromDate"), stockAllocationEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								stockAllocationEntity.get("effectiveFromDate"),
								stockAllocationEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							stockAllocationEntity.get("effectiveFromDate"),
							stockAllocationEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							stockAllocationEntity.get("effectiveFromDate"),
							stockAllocationEntity.get("effectiveToDate")));
				}
			}
			orderByAsc(stockAllocationEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<StockAllocationEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (stockAllocationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), stockAllocationEntity.get("effectiveFromDate"),
				stockAllocationEntity.get("effectiveToDate"));
	}
	
	public static Specification<StockAllocationEntity> betweenDocumentSeries(String documentSeries) {
		return (stockAllocationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(documentSeries), stockAllocationEntity.get("documentFromSeries"),
				stockAllocationEntity.get("documentToSeries"));
	}
	
	public static Specification<StockAllocationEntity> effectiveToDateGreaterThan() {
		return (stockAllocationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThan(stockAllocationEntity.get("effectiveToDate"), LocalDate.now());
	}

	public static Specification<StockAllocationEntity> equalsClientId(String clientId) {
		return (stockAllocationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(stockAllocationEntity.get("clientId"), clientId);
	}

	public static Specification<StockAllocationEntity> equalsStockId(Integer stockId) {
		return (stockAllocationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(stockAllocationEntity.get("stockId"), stockId);
	}

	public static Specification<StockAllocationEntity> equalsAgencyCode(String agencyCode) {
		return (stockAllocationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(stockAllocationEntity.get("agencyCode"), agencyCode);
	}

	public static Specification<StockAllocationEntity> notEqualsStockAllocationId(Integer stockAllocationId) {
		return (stockAllocationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(stockAllocationEntity.get("stockAllocationId"), stockAllocationId);
	}
}
