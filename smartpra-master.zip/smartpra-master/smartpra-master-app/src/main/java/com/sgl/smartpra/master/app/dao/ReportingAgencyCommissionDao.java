package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.ReportingAgencyCommissionEntity;

@Repository
public interface ReportingAgencyCommissionDao {
	public ReportingAgencyCommissionEntity create(ReportingAgencyCommissionEntity reportingAgencyCommissionEntity);

	public ReportingAgencyCommissionEntity update(ReportingAgencyCommissionEntity reportingAgencyCommissionEntity);

	public Optional<ReportingAgencyCommissionEntity> findById(Integer id);

	public void delete(Integer id);

	public List<ReportingAgencyCommissionEntity> searchReportingAgencyCommission(Optional<String> agencyCode,
			Optional<String> reportingAgency, Optional<Boolean> activate);

	public long getOverlapRecordCount(String clientId, String reportingAgency, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, String agencyCode, String orcCurrency);

	public long getOverlapRecordCount(String clientId, String reportingAgency, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, String agencyCode, String orcCurrency, Integer reportingAgencyCommId);

	public Optional<ReportingAgencyCommissionEntity> findOne(Integer reportingAgencyCommId);

	public List<ReportingAgencyCommissionEntity> searchReportingAgencyCommissionByAgencyId(Integer agencyId,
			Optional<String> agencyCode, Optional<String> reportingAgency, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> orcCurrency, Optional<Boolean> activate);
}
