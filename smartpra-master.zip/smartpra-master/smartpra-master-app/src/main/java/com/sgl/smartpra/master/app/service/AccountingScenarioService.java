package com.sgl.smartpra.master.app.service;

import java.util.List;

import com.sgl.smartpra.master.model.AccountingScenario;

public interface AccountingScenarioService {
	public AccountingScenario createAccountingScenario(AccountingScenario accountingScenario);

	public AccountingScenario updateAccountingScenario(Integer scenarioNumber, AccountingScenario accountingScenario);

	public AccountingScenario getAccountingScenarioByScenarioNumber(Integer scenarioNumber);

	public List<AccountingScenario> getSearchAllAccountingScenario(String transactionType, String selfOalIndicator,
			Boolean salesExistIndicator, String docType, String chargeCatCode, String chargeCode);

	public List<AccountingScenario> getSearchAllAccountingScenarioWithIsActiveParam(String module,String transactionType,
			String selfOalIndicator, Boolean salesExistIndicator, String docType, String chargeCatCode,
			String chargeCode, Boolean isActive);

	public void activateAccountingScenario(AccountingScenario accountingScenario);

	public void deactivateAccountingScenario(AccountingScenario accountingScenario);
}
