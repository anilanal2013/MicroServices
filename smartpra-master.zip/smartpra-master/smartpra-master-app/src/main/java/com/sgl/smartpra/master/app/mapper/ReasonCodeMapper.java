package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.repository.entity.ReasonCodeEntity;
import com.sgl.smartpra.master.model.ReasonCode;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ReasonCodeMapper extends BaseMapper<ReasonCode, ReasonCodeEntity> {

	ReasonCodeEntity mapToEntity(ReasonCode reasonCode, @MappingTarget ReasonCodeEntity reasonCodeEntity);

	@Mapping(source = "reasonCodeId", target = "reasonCodeId", ignore = true)
	ReasonCodeEntity mapToEntity(ReasonCode reasonCode);

}
