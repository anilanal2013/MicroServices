package com.sgl.smartpra.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.master.app.repository.entity.FlightEntity;
import com.sgl.smartpra.master.model.Flight;

@Mapper
public interface FlightMapper {
	Flight mapToFlightModel(FlightEntity flightEntity);

	List<Flight> mapToFlightModelList(List<FlightEntity> FlightEntitieList);

	FlightEntity mapToFlightEntity(Flight flight);

	List<FlightEntity> mapToFlightEntityList(List<Flight> FlightList);
}
