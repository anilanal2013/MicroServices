package com.sgl.smartpra.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "mas_currency_tolerance_details")
@DynamicInsert
@DynamicUpdate
@EqualsAndHashCode(callSuper = false)
public class CurrencyToleranceDetailsEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "currency_tolerance_dtl_id")
	private Integer currencyToleranceDtlId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "currency_code")
	private String currencyCode;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Column(name = "exchange_diff_account")
	private String exchangeDiffAccount;

	@Column(name = "gross_accept_var_percentage")
	private BigDecimal grossAcceptVarPercentage;

	@Column(name = "gross_acceptable_variance_amt")
	private BigDecimal grossAcceptableVarianceAmt;

	@Column(name = "minimum_value")
	private BigDecimal minimumValue;

	@Column(name = "tax_accept_var_percentage")
	private BigDecimal taxAcceptVarPercentage;

	@Column(name = "tax_acceptable_variance_amt")
	private BigDecimal taxAcceptableVarianceAmt;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}