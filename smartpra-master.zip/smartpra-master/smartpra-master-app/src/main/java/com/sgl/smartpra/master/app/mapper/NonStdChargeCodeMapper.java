package com.sgl.smartpra.master.app.mapper;

/**
 * @author kanprasa
 *
 */

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCodeEntity;
import com.sgl.smartpra.master.model.NonStandardChargeCode;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface NonStdChargeCodeMapper extends BaseMapper<NonStandardChargeCode, NonStandardChargeCodeEntity>{

	public NonStandardChargeCodeEntity mapToEntity(NonStandardChargeCode nonStdChargeCode, @MappingTarget NonStandardChargeCodeEntity nonStandardChargeCodeEntity);
	
	public NonStandardChargeCodeEntity mapToEntity(NonStandardChargeCode nonStdChargeCode);
	
}