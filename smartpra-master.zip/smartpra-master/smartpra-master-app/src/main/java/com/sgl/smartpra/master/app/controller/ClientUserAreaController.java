package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.exception.ServiceException;
import com.sgl.smartpra.master.app.service.ClientUserAreaService;
import com.sgl.smartpra.master.model.ClientUserArea;
import com.sgl.smartpra.proration.model.farebasis.UserAreaDefine;

@RestController
public class ClientUserAreaController {

	@Autowired
	private ClientUserAreaService clientUserAreaService;
	int parseClientUserAreaId = 0;
	private static final String CLIENTUSERDIDCHECK = "clientUserAreaId should be in digit";

	@GetMapping("/client-user-areas")
	public List<ClientUserArea> getClientListOfUserArea(
			@RequestParam(value = "userAreaCode", required = false) Optional<String> userAreaCode,
			@RequestParam(value = "userAreaName", required = false) Optional<String> userAreaName,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return clientUserAreaService.getClientListOfUserArea(userAreaCode, userAreaName, activate);
	}
	
	@GetMapping("/client-user-areas-list")
	public List<ClientUserArea> getClientListOfUserAreaForCaptureArea(
			@RequestParam(value = "userAreaCode", required = false) Optional<String> userAreaCode,
			@RequestParam(value = "areaKey1", required = false) Optional<String> areaKey1,
			@RequestParam(value = "areaKey2", required = false) Optional<String> areaKey2,
			@RequestParam(value = "areaKey3", required = false) Optional<String> areaKey3,
			@RequestParam(value = "areaKey4", required = false) Optional<String> areaKey4,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return clientUserAreaService.getClientListOfUserAreaForCaptureArea(userAreaCode, areaKey1, areaKey2, areaKey3, areaKey4, activate);
	}

	@PostMapping("/client-user-area")
	public UserAreaDefine getClientUserArea(@RequestBody UserAreaDefine userAreaDefine) {
		return clientUserAreaService.getClientUserArea(userAreaDefine);
	}

	@GetMapping("/client-user-areas/{userAreaId}")
	public ClientUserArea getClientUserAreaByUserAreaCode(@PathVariable(value = "userAreaId") String userAreaId) {
		try {
			parseClientUserAreaId = Integer.parseInt(userAreaId);
		} catch (NumberFormatException nfe) {
			throw new ServiceException(CLIENTUSERDIDCHECK);
		}
		return clientUserAreaService.getClientUserAreaByUserAreaCode(parseClientUserAreaId);
	}

	@PostMapping("/client-user-areas")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ClientUserArea createClientUserArea(@Validated(Create.class) @RequestBody ClientUserArea clientUserArea) {
		return clientUserAreaService.createClientUserArea(clientUserArea);
	}

	@PutMapping("/client-user-areas/{userAreaId}")
	@ResponseStatus(value = HttpStatus.OK)
	public ClientUserArea updateClientUserArea(@PathVariable(value = "userAreaId") String userAreaId,
			@Validated(Update.class) @RequestBody ClientUserArea clientUserArea) {
		try {
			parseClientUserAreaId = Integer.parseInt(userAreaId);
		} catch (NumberFormatException nfe) {
			throw new ServiceException(CLIENTUSERDIDCHECK);
		}
		return clientUserAreaService.updateClientUserArea(parseClientUserAreaId, clientUserArea);
	}

	@PutMapping("/client-user-areas/{userAreaId}/deactivate")
	public void deactivateClientUserArea(@Valid @PathVariable(value = "userAreaId") String userAreaId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		try {
			parseClientUserAreaId = Integer.parseInt(userAreaId);
		} catch (NumberFormatException nfe) {
			throw new ServiceException(CLIENTUSERDIDCHECK);
		}
		clientUserAreaService.deactivateClientUserArea(parseClientUserAreaId, lastUpdatedBy);

	}

	@PutMapping("/client-user-areas/{userAreaId}/activate")
	public void activateClientUserArea(@Valid @PathVariable(value = "userAreaId") String userAreaId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		try {
			parseClientUserAreaId = Integer.parseInt(userAreaId);
		} catch (NumberFormatException nfe) {
			throw new ServiceException(CLIENTUSERDIDCHECK);
		}
		clientUserAreaService.activateClientUserArea(parseClientUserAreaId, lastUpdatedBy);

	}

	@PostMapping("/user-area/insert")
	public void clientSpecificUserAreaInsertOrUpdate(@RequestBody Map<String, String> map) {
		clientUserAreaService.clientSpecificUserAreaInsertOrUpdate(map);
	}

	@GetMapping("/user-area/validate/{areaCode}")
	public boolean isAreaCode(@PathVariable(value = "areaCode") String areaCode) {
		return clientUserAreaService.isValidateAreaCode(areaCode);
	}

}