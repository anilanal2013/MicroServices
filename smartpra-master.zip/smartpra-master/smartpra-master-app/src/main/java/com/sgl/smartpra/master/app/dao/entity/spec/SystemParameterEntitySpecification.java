package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.SystemParameterEntity;

public final class SystemParameterEntitySpecification {

	public static Specification<SystemParameterEntity> searchAll(Optional<String> clientId, Optional<String> groupName, Optional<String> moduleName,
			Optional<String> parameterName, Optional<String> parameterFormat, String parameterId, Optional<Boolean> isVisible, Optional<Boolean> isActive) {
		return (systemParameterEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("clientId"), OptionalUtil.getValue(clientId)+"%"));
			}
			if (OptionalUtil.isPresent(groupName)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("groupName"), OptionalUtil.getValue(groupName)+"%"));
			}
			if (OptionalUtil.isPresent(moduleName)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("moduleName"), OptionalUtil.getValue(moduleName)+ "%"));
			}
			if (OptionalUtil.isPresent(parameterName)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("parameterName"), OptionalUtil.getValue(parameterName)+"%"));
			}
			if (OptionalUtil.isPresent(parameterFormat)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("parameterFormat"), OptionalUtil.getValue(parameterFormat)+"%"));
			}
			if (parameterId != null && !parameterId.isEmpty()) {
				predicates.add(criteriaBuilder.equal(systemParameterEntity.get("parameterId"), parameterId));
			}
			if (OptionalUtil.isPresent(isActive) ) {
				predicates.add(
						criteriaBuilder.equal(systemParameterEntity.get("isActive"),  OptionalUtil.getValue(isActive)));
			}
			if (!OptionalUtil.isPresent(isActive)) {
				predicates.add(criteriaBuilder.equal(systemParameterEntity.get("isActive"), true));
			}
			if (OptionalUtil.isPresent(isVisible) ) {
				predicates.add(
						criteriaBuilder.equal(systemParameterEntity.get("isVisible"),  OptionalUtil.getValue(isVisible)));
			}
			if (!OptionalUtil.isPresent(isVisible)) {
				predicates.add(criteriaBuilder.equal(systemParameterEntity.get("isVisible"), true));
			}
			orderByDesc(systemParameterEntity, criteriaQuery, criteriaBuilder, "lastUpdatedDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
	
	public static Specification<SystemParameterEntity> search(Optional<String> clientId, Optional<String> groupName, Optional<String> moduleName,
			Optional<String> parameterName, Optional<String> parameterFormat, String parameterId) {
		return (systemParameterEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("clientId"), OptionalUtil.getValue(clientId)+"%"));
			}
			if (OptionalUtil.isPresent(groupName)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("groupName"), OptionalUtil.getValue(groupName)+"%"));
			}
			if (OptionalUtil.isPresent(moduleName)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("moduleName"), OptionalUtil.getValue(moduleName)+ "%"));
			}
			if (OptionalUtil.isPresent(parameterName)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("parameterName"), OptionalUtil.getValue(parameterName)+"%"));
			}
			if (OptionalUtil.isPresent(parameterFormat)) {
				predicates.add(criteriaBuilder.like(systemParameterEntity.get("parameterFormat"), OptionalUtil.getValue(parameterFormat)+"%"));
			}
			if (parameterId != null && !parameterId.isEmpty()) {
				predicates.add(criteriaBuilder.equal(systemParameterEntity.get("parameterId"), parameterId));
			}
			orderByDesc(systemParameterEntity, criteriaQuery, criteriaBuilder, "lastUpdatedDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
	
	public static void orderByDesc(Root<SystemParameterEntity> systemParameterEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.desc(systemParameterEntity.get(orderByString)));
	}
	
	public static Specification<SystemParameterEntity> isActive() {
		return (systemParameterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(systemParameterEntity.get("isActive"), true);
	}
	
	public static Specification<SystemParameterEntity> equalsClientId(String clientId) {
		return (systemParameterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(systemParameterEntity.get("clientId"), clientId);
	}
	
	public static Specification<SystemParameterEntity> equalsParameterName(String parameterName) {
		return (systemParameterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(systemParameterEntity.get("parameterName"), parameterName);
	}
	
	public static Specification<SystemParameterEntity> equalsEffectiveToDateGreaterThanEqual() {
		return (systemParameterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(systemParameterEntity.get("effectiveToDate"), LocalDate.now());
	}
	
	public static Specification<SystemParameterEntity> equalsListParameterName(List<String> names) {
		return (systemParameterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.and(systemParameterEntity.get("parameterName").in(names));
	}

}
