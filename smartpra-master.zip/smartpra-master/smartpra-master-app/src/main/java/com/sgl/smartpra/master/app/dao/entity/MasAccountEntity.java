package com.sgl.smartpra.master.app.dao.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_account database table.
 * 
 */
@Entity
@Table(name = "mas_account")
@Data
@EqualsAndHashCode(callSuper = false)
public class MasAccountEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "account_alpha_code_id")
	private Integer accountAlphaCodeId;
	@Column(name = "account_alpha_code", length = 100)
	private String accountAlphaCode;
	@Column(name = "account_description", length = 100)
	private String accountDescription;
	@Column(name = "account_num_code", length = 50)
	private String accountNumCode;
	@Column(name = "account_type")
	private String accountType;
	@Column(name = "attribute_1", length = 50)
	private String attribute1;
	@Column(name = "attribute_10", length = 50)
	private String attribute10;
	@Column(name = "attribute_11", length = 50)
	private String attribute11;
	@Column(name = "attribute_12", length = 50)
	private String attribute12;
	@Column(name = "attribute_13", length = 50)
	private String attribute13;
	@Column(name = "attribute_14", length = 50)
	private String attribute14;
	@Column(name = "attribute_15", length = 50)
	private String attribute15;
	@Column(name = "attribute_16", length = 50)
	private String attribute16;
	@Column(name = "attribute_17", length = 50)
	private String attribute17;
	@Column(name = "attribute_18", length = 50)
	private String attribute18;
	@Column(name = "attribute_19", length = 50)
	private String attribute19;
	@Column(name = "attribute_2", length = 50)
	private String attribute2;
	@Column(name = "attribute_20", length = 50)
	private String attribute20;
	@Column(name = "attribute_3", length = 50)
	private String attribute3;
	@Column(name = "attribute_4", length = 50)
	private String attribute4;
	@Column(name = "attribute_5", length = 50)
	private String attribute5;
	@Column(name = "attribute_6", length = 50)
	private String attribute6;
	@Column(name = "attribute_7", length = 50)
	private String attribute7;
	@Column(name = "attribute_8", length = 50)
	private String attribute8;
	@Column(name = "attribute_9", length = 50)
	private String attribute9;
	@Column(name = "client_id", length = 2)
	private String clientId;
	@Column(name = "effective_from_date", length = 50)
	private LocalDate effectiveFromDate;
	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;


	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}