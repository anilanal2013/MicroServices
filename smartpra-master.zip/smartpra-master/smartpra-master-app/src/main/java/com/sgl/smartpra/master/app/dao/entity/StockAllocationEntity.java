package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_stock_allocation database table.
 * 
 */
@Entity
@Table(name = "mas_stock_allocation")
@Data
@DynamicInsert
@DynamicUpdate
@EqualsAndHashCode(callSuper = false)
public class StockAllocationEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "stock_allocation_id")
	private Integer stockAllocationId;

	@Column(name = "agency_code")
	private String agencyCode;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "country_code")
	private String countryCode;

	@Column(name = "document_from_series")
	private String documentFromSeries;

	@Column(name = "document_to_series")
	private String documentToSeries;

	@Column(name = "document_type")
	private String documentType;
	
	@Column(name = "document_quantity")
	private Integer documentQuantity;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Column(name = "reporting_agency")
	private String reportingAgency;

	@Column(name = "stock_id")
	private Integer stockId;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
