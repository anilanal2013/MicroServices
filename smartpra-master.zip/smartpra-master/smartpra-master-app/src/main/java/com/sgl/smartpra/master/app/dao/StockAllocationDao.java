package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.StockAllocationEntity;

@Repository
public interface StockAllocationDao {

	Optional<StockAllocationEntity> findByStockAllocationId(Integer stockAllocationId);

	List<StockAllocationEntity> search(Integer stockId, Optional<String> documentSeriesFrom, Optional<String> documentSeriesTo,
			Optional<String> documentType, Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	StockAllocationEntity create(StockAllocationEntity stockAllocation);

	StockAllocationEntity update(StockAllocationEntity stockAllocationEntity);

	long getOverLapRecordCount(Optional<String> clientId, Integer stockId, 
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId, Integer stockId,
			 Integer stockAllocationId);
	
	String getLastDocumentToSeries(String clientId, Integer stockId);

	void createAgentStaockDetails(StockAllocationEntity entity, String document);
	
	void updateAgencyCodeDetails(StockAllocationEntity entity, String document);
	
	void updateStock(Integer stockId);

	StockAllocationEntity getDocSeriesByDate(Optional<String> clientId, Integer stockId, Optional<String> documentFromSeries,
			Optional<String> documentToSeries); 

}
