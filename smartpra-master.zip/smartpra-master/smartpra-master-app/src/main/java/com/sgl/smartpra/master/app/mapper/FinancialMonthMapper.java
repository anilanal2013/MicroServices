package com.sgl.smartpra.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.master.app.repository.entity.FinancialMonthEntity;
import com.sgl.smartpra.master.model.FinancialMonthModel;

@Mapper
public interface FinancialMonthMapper {
	
	FinancialMonthModel mapToFinancialMonthModel(FinancialMonthEntity financialMonthEntity);
	
	List<FinancialMonthModel> mapToFinancialMonthModelList(List<FinancialMonthEntity> financialMonthEntitiesList);
	
	FinancialMonthEntity mapToFinancialMonthEntity(FinancialMonthModel financialMonthModel);
	
	List<FinancialMonthEntity> mapToFinancialMonthEntityList(List<FinancialMonthModel> financialMonthModelList);

}
