package com.sgl.smartpra.master.app.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.master.app.dao.entity.StcokDetails;

@Repository
public interface StockDetailsRepository
		extends JpaRepository<StcokDetails, Integer>, JpaSpecificationExecutor<StcokDetails> {
	

	@Query(value = "select max(documentNumber) from StcokDetails where  stockId =:stockId and"
			+ " clientId =:clientId   and agentCode is not null and"
			+ "  ((:effectiveDate between effectiveDate and expiryDate) or "
			+ "	  (:expiryDate between effectiveDate and expiryDate) )")	  
	  String getMaxDocumentNumber(@Param("stockId")Integer stockId, @Param("clientId")String clientId, 
			  @Param("effectiveDate") LocalDate effectiveDate, @Param("expiryDate") LocalDate expiryDate );
	
	
	@Transactional
	@Modifying
	@Query("delete from StcokDetails where  stockId =:stockId and "
			+ "  clientId =:clientId and documentNumber=:documentNumber  and agentCode is null and "
			+ "  ((:effectiveDate between effectiveDate and expiryDate) or "
			+ "  (:expiryDate between effectiveDate and expiryDate)) ")
	void deleteUnusedStock(@Param("stockId")Integer stockId, @Param("clientId")String clientId, @Param("documentNumber")String documentNumber, 
			  @Param("effectiveDate") LocalDate effectiveDate, @Param("expiryDate") LocalDate expiryDate );
	
}