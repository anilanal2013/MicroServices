package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.JobEntity;
import com.sgl.smartpra.master.model.Job;

@Repository
public interface JobDao {
	
	public Optional<JobEntity> findById(Integer jobId);
	
	public List<JobEntity> search(Job job);

	JobEntity create(JobEntity jobEntity);

	JobEntity update(JobEntity jobEntity);

	long getOverLapForCreate(String jobName, String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate);

	long getOverLapForUpdate(String jobName, String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			Integer jobId);

	public List<JobEntity> getAllJobByEffectiveDate(Optional<String> effectiveFromDate);
	
}
