package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.repository.entity.CarrierInterlineDetailsEntity;

public final class CarrierInterlineDetailsEntitySpecification {
	public static void orderByAsc(Root<CarrierInterlineDetailsEntity> carrierInterlineDetailsEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(carrierInterlineDetailsEntity.get(orderByString)));
	}

	public static Specification<CarrierInterlineDetailsEntity> searchAll(Optional<String> carrierCode,  Optional<String> clientId, 
			Optional<String> effectiveDate) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(carrierInterlineDetailsEntity.get("clientId"),
						OptionalUtil.getValue(clientId)));
			}			
			if (OptionalUtil.isPresent(carrierCode)) {
				predicates.add(criteriaBuilder.like(carrierInterlineDetailsEntity.get("carrierCode"),
						OptionalUtil.getValue(carrierCode) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								carrierInterlineDetailsEntity.get("effectiveFromDate"),
								carrierInterlineDetailsEntity.get("effectiveToDate")));
			}
			orderByAsc(carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<CarrierInterlineDetailsEntity> search(Optional<String> carrierCode, Optional<String> effectiveDate) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (OptionalUtil.isPresent(carrierCode)) {
				predicates.add(criteriaBuilder.like(carrierInterlineDetailsEntity.get("carrierCode"),
						OptionalUtil.getValue(carrierCode) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								carrierInterlineDetailsEntity.get("effectiveFromDate"),
								carrierInterlineDetailsEntity.get("effectiveToDate")));
			}
			orderByAsc(carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<CarrierInterlineDetailsEntity> findUniqueKeyForColumns(Optional<String> clientId,
			Optional<String> carrierCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(carrierInterlineDetailsEntity.get("clientId"),
						OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(carrierCode)) {
				predicates.add(criteriaBuilder.like(carrierInterlineDetailsEntity.get("carrierCode"),
						OptionalUtil.getValue(carrierCode) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate)) {
				predicates.add(criteriaBuilder.like(carrierInterlineDetailsEntity.get("effectiveFromDate"),
						OptionalUtil.getValue(effectiveFromDate)));
			}
			if (OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.like(carrierInterlineDetailsEntity.get("effectiveToDate"),
						OptionalUtil.getValue(effectiveToDate)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<CarrierInterlineDetailsEntity> getByCarrierCode(Optional<String> carrierCode) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierCode)) {
				predicates.add(criteriaBuilder.like(carrierInterlineDetailsEntity.get("carrierCode"),
						OptionalUtil.getValue(carrierCode) + "%"));
			}
			orderByAsc(carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<CarrierInterlineDetailsEntity> equalsClientId(String clientId) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierInterlineDetailsEntity.get("clientId"), clientId);
	}
	
	public static Specification<CarrierInterlineDetailsEntity> equalsZone(String zone) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierInterlineDetailsEntity.get("zone"), zone);
	}

	public static Specification<CarrierInterlineDetailsEntity> equalsCarrierCode(String carrierCode) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierInterlineDetailsEntity.get("carrierCode"), carrierCode);
	}

	public static Specification<CarrierInterlineDetailsEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), carrierInterlineDetailsEntity.get("effectiveFromDate"),
				carrierInterlineDetailsEntity.get("effectiveToDate"));
	}
	
	public static Specification<CarrierInterlineDetailsEntity> betweenEffectiveFrom(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				carrierInterlineDetailsEntity.get("effectiveFromDate"), criteriaBuilder.literal(effectiveFromDate),
				criteriaBuilder.literal(effectiveToDate));
	}

	public static Specification<CarrierInterlineDetailsEntity> isActive() {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierInterlineDetailsEntity.get("activate"), true);
	}

	public static Specification<CarrierInterlineDetailsEntity> notEqualsCarrierInterlineDtlId(
			Integer carrierInterlineDtlId) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(carrierInterlineDetailsEntity.get("carrierInterlineDtlId"), carrierInterlineDtlId);
	}

	public static Specification<CarrierInterlineDetailsEntity> isPassengerSis() {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierInterlineDetailsEntity.get("passengerSis"), true);
	}
	
	public static Specification<CarrierInterlineDetailsEntity> searchPassengerSis(Optional<String> carrierCode,Optional<Boolean> passengerSis,
			Optional<String> effectiveDate) {
		return searchByCarrierCodeAndEffectiveDate(carrierCode, effectiveDate).and(isPassengerSis());
	}
	
	public static Specification<CarrierInterlineDetailsEntity> searchByCarrierCodeAndEffectiveDate(Optional<String> carrierCode,
			Optional<String> effectiveDate) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierCode)) {
				predicates.add(criteriaBuilder.like(carrierInterlineDetailsEntity.get("carrierCode"),
						OptionalUtil.getValue(carrierCode)));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								carrierInterlineDetailsEntity.get("effectiveFromDate"),
								carrierInterlineDetailsEntity.get("effectiveToDate")));
			}
			predicates.add(criteriaBuilder.equal(carrierInterlineDetailsEntity.get("activate"), true));
			orderByAsc(carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<CarrierInterlineDetailsEntity> carrierInterlineDetailsByZoneAndEffectiveDate(Optional<String> clientId, Optional<String> zone) {
		return (carrierInterlineDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(carrierInterlineDetailsEntity.get("clientId"),
						OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(zone)) {
				predicates.add(criteriaBuilder.equal(carrierInterlineDetailsEntity.get("zone"),
						OptionalUtil.getValue(zone)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}