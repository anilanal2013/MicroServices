package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.BookingClassEntity;
import com.sgl.smartpra.master.model.BookingClassModel;

public class BookingClassEntitySpecification {

	public static Specification<BookingClassEntity> equalsClientId(String clientId) {
		return (bookingClassEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(bookingClassEntity.get("clientId"), clientId);
	}

	public static Specification<BookingClassEntity> equalsMarktingCarrier(String marketingCarrier) {
		return (bookingClassEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(bookingClassEntity.get("marketingCarrier"), marketingCarrier);
	}

	public static Specification<BookingClassEntity> equalsRbd(String rbd) {
		return (bookingClassEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(bookingClassEntity.get("rbd"), rbd);
	}

	public static Specification<BookingClassEntity> equalsActive() {
		return (bookingClassEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(bookingClassEntity.get("activate"), true);
	}

	public static Specification<BookingClassEntity> betweenUtilEffectiveFromAndUtilEffectiveToDate(
			LocalDate utilEffectiveDate) {
		return (bookingClassEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(utilEffectiveDate), bookingClassEntity.get("utilEffectiveFromDate"),
				bookingClassEntity.get("utilEffectiveToDate"));
	}

	public static Specification<BookingClassEntity> betweenSalesEffectiveFromAndSalesEffectiveToDate(
			LocalDate salesEffectiveDate) {
		return (bookingClassEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(salesEffectiveDate), bookingClassEntity.get("salesEffectiveFromDate"),
				bookingClassEntity.get("salesEffectiveToDate"));
	}

	public static Specification<BookingClassEntity> notEqualsbookingClassId(Integer bookingClassId) {
		return (bookingClassEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(bookingClassEntity.get("bookingClassId"), bookingClassId);
	}

	public static void orderByAsc(Root<BookingClassEntity> bookingClassEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String oredrByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(bookingClassEntity.get(oredrByString)));
	}

	public static Specification<BookingClassEntity> search(BookingClassModel bookingClassModel,
			Optional<String> exceptionCall) {
		return (bookingClassEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(bookingClassModel.getClientId())) {
				predicates.add(criteriaBuilder.equal(bookingClassEntity.get("clientId"),
						OptionalUtil.getValue(bookingClassModel.getClientId())));
			}
			if (OptionalUtil.isPresent(bookingClassModel.getToAirport())) {
				predicates.add(criteriaBuilder.like(bookingClassEntity.get("toAirport"),
						OptionalUtil.getValue(bookingClassModel.getToAirport()) + "%"));
			}
			if (OptionalUtil.isPresent(bookingClassModel.getFromAirport())) {
				predicates.add(criteriaBuilder.like(bookingClassEntity.get("fromAirport"),
						OptionalUtil.getValue(bookingClassModel.getFromAirport()) + "%"));
			}
			if (OptionalUtil.isPresent(bookingClassModel.getMarketingCarrier())) {
				predicates.add(criteriaBuilder.equal(bookingClassEntity.get("marketingCarrier"),
						OptionalUtil.getValue(bookingClassModel.getMarketingCarrier())));
			}
			if (OptionalUtil.isPresent(bookingClassModel.getCabin())) {
				predicates.add(criteriaBuilder.equal(bookingClassEntity.get("cabin"),
						OptionalUtil.getValue(bookingClassModel.getCabin())));
			}
			if (OptionalUtil.isPresent(bookingClassModel.getRbd())) {
				predicates.add(criteriaBuilder.equal(bookingClassEntity.get("rbd"),
						OptionalUtil.getValue(bookingClassModel.getRbd())));
			}
			if (OptionalUtil.isPresent(bookingClassModel.getUtilEffectiveFromDate())
					&& OptionalUtil.isPresent(bookingClassModel.getUtilEffectiveToDate())) {
				predicates
						.add(criteriaBuilder.or(
								criteriaBuilder.between(
										criteriaBuilder.literal(OptionalUtil
												.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate())),
										bookingClassEntity.get("utilEffectiveFromDate"),
										bookingClassEntity.get("utilEffectiveToDate")),
								criteriaBuilder.between(
										criteriaBuilder.literal(OptionalUtil
												.getLocalDateValue(bookingClassModel.getUtilEffectiveToDate())),
										bookingClassEntity.get("utilEffectiveFromDate"),
										bookingClassEntity.get("utilEffectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(bookingClassModel.getUtilEffectiveFromDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(
									OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate())),
							bookingClassEntity.get("utilEffectiveFromDate"),
							bookingClassEntity.get("utilEffectiveToDate")));
				}
				if (OptionalUtil.isPresent(bookingClassModel.getUtilEffectiveToDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(
									OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveToDate())),
							bookingClassEntity.get("utilEffectiveFromDate"),
							bookingClassEntity.get("utilEffectiveToDate")));
				}
			}
			if (OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveFromDate())
					&& OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveToDate())) {
				predicates
						.add(criteriaBuilder.or(
								criteriaBuilder.between(
										criteriaBuilder.literal(OptionalUtil
												.getLocalDateValue(bookingClassModel.getSalesEffectiveFromDate())),
										bookingClassEntity.get("salesEffectiveFromDate"),
										bookingClassEntity.get("salesEffectiveToDate")),
								criteriaBuilder.between(
										criteriaBuilder.literal(OptionalUtil
												.getLocalDateValue(bookingClassModel.getSalesEffectiveToDate())),
										bookingClassEntity.get("salesEffectiveFromDate"),
										bookingClassEntity.get("salesEffectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveFromDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(
									OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveFromDate())),
							bookingClassEntity.get("salesEffectiveFromDate"),
							bookingClassEntity.get("salesEffectiveToDate")));
				}
				if (OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveToDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(
									OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveToDate())),
							bookingClassEntity.get("salesEffectiveFromDate"),
							bookingClassEntity.get("salesEffectiveToDate")));
				}
			}
			if (!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (bookingClassModel.getActivate() != null) {
					predicates.add(
							criteriaBuilder.equal(bookingClassEntity.get("activate"), bookingClassModel.getActivate()));
				}
				if (bookingClassModel.getActivate() == null) {
					predicates.add(criteriaBuilder.equal(bookingClassEntity.get("activate"), true));
				}
			}
			orderByAsc(bookingClassEntity, criteriaQuery, criteriaBuilder, "rbd");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
}
