package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.CurrencyToleranceDetailsEntity;
import com.sgl.smartpra.master.model.CurrencyToleranceDetails;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CurrencyToleranceDetailsMapper
		extends BaseMapper<CurrencyToleranceDetails, CurrencyToleranceDetailsEntity> {

	CurrencyToleranceDetailsEntity mapToEntity(CurrencyToleranceDetails currencyToleranceDetails,
			@MappingTarget CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity);

	@Mapping(source = "currencyToleranceDtlId", target = "currencyToleranceDtlId", ignore = true)
	CurrencyToleranceDetailsEntity mapToEntity(CurrencyToleranceDetails currencyToleranceDetails);

}