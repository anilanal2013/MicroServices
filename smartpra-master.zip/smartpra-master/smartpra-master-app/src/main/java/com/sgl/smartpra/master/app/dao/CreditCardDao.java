package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.CreditCardEntity;
import com.sgl.smartpra.master.model.CreditCard;

@Repository
public interface CreditCardDao {

	List<CreditCardEntity> getAllCreditCard(CreditCard creditCard, Optional<String> exceptionCall);

	Optional<CreditCardEntity> findById(Integer creditCardId);

	CreditCardEntity createCreditCard(CreditCardEntity mapToEntity);

	CreditCardEntity updateCreditCard(CreditCardEntity mapToEntity);

	long getOverLapForCreate(Optional<String> clientId, Optional<String> ccCompanyCode,
			Optional<String> uatpAirlineCode);

	long getOverLapForUpdate(String clientId, String ccCompanyCode, String uatpAirlineCode, Integer creditCardId);

}
