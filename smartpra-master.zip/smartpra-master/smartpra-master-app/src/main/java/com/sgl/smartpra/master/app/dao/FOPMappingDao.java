package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.FOPMappingEntity;

@Repository
public interface FOPMappingDao {
	public Optional<FOPMappingEntity> findById(Integer id);

	public FOPMappingEntity create(FOPMappingEntity fopMappingEntity);

	public FOPMappingEntity update(FOPMappingEntity fopMappingEntity);

	public List<FOPMappingEntity> searchFOPMapping(Optional<String> stationCode, Optional<String> effectiveFromDate,Optional<String> effectiveToDate,
			Optional<String> source,Optional<String> fopCode);

	public void delete(Integer id);

	List<FOPMappingEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	// -- This is for Create- Overlap Count Validation
	public long getOverlapRecoedCount(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String source, String stationCode, String fopCode);

	// -- This is for Update- Overlap Count Validation
	public long getOverlapRecoedCount(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String source, String stationCode, String fopCode, Integer fopMapId);

}
