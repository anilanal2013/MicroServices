package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hazelcast.util.StringUtil;
import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.AgencyMasterDao;
import com.sgl.smartpra.master.app.dao.entity.AgencyMasterEntity;
import com.sgl.smartpra.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.master.app.mapper.AgencyMapper;
import com.sgl.smartpra.master.app.service.AgencyMasterService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.app.service.SystemParameterService;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.master.model.AgencyMasterResponse;
import com.sgl.smartpra.master.model.ListOfValues;

@Service
@Transactional
public class AgencyMasterServiceImpl implements AgencyMasterService {

	@Autowired
	private AgencyMapper agencyMapper;

	@Autowired
	private AgencyMasterDao agencyMasterDao;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private ListOfValuesService listOfValuesService;

	@Autowired
	private SystemParameterService systemParameterService;

	public static final String AGENCY = "Agency master";
	public static final String LASTUPDATEDBYMSG = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	public static final String LASTUPDATEDBYMANDATORYMSG = "Please provide Last Updated By";
	public static final String AGENCYMASTERINACTIVE = "Agency master is already in deactivated state";
	public static final String AGENCYMASTERACTIVE = "Agency master  is already in activate state";
	public static final String BSPINDICATOR = "Valid values for Bsp Indicator field are 'Y|'N'";
	public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
			Pattern.CASE_INSENSITIVE);
	public static final String AGENCYMASTERID = "Agency master id not found";
	public static final String DEFAULTBSPINDICATOR = "N";
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	private static final String LOVAGENCYTYPE = LOVEnum.AGENCY_TYPE.getLOVEnum();
	private static final String LOVREPORTINGAGENCYTYPE = LOVEnum.REPORTING_AGENCY_TYPE.getLOVEnum();
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	private String airportCode = null;
	private String airportName = null;
	private String cityName = null;
	private String countryCode = null;
	private String carrierName1 = null;
	private String carrierName2 = null;
	private String carrierCode = null;
	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";
	Optional<String> hostCarrierDesigCode;

	private String agencyType;

	@Override
	public List<AgencyMaster> getSearchAllAgency(Optional<String> agencyCode, Optional<String> reportingAgency,
			Optional<String> agencyType, Optional<String> areaOfOperation, Optional<String> reportingAgencyType,
			Optional<String> cityCode, Optional<String> countryCode, Optional<Boolean> activate, Optional<String> clientId) {
		
		return agencyMapper.mapToModel(agencyMasterDao.getSearchAllAgency(clientId, agencyCode,
				reportingAgency, agencyType, areaOfOperation, reportingAgencyType, cityCode, countryCode, activate));
	}

	@Override
	public List<AgencyMaster> getListOfAgency(Optional<String> agencyCode, Optional<String> reportingAgency,
			Optional<String> agencyType, Optional<String> areaOfOperation, Optional<String> reportingAgencyType,
			Optional<Boolean> activate) {
		return agencyMapper.mapToModel(agencyMasterDao.findAll(agencyCode, reportingAgency, agencyType, areaOfOperation,
				reportingAgencyType, activate));
	}

	@Override
	public AgencyMaster getAgencyByAgencyId(Integer agencyId) {
		return agencyMapper.mapToModel(agencyMasterDao.findById(agencyId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(agencyId))));
	}

	@Override
	public AgencyMaster createAgency(AgencyMaster agencyMaster) {
		validateBusinessConstraintsForCreate(agencyMaster);
		agencyMaster.setActivate(Boolean.TRUE);
		agencyMaster.setCreatedDate(LocalDateTime.now());
		long count = agencyMasterDao.getOverLapRecordCount(OptionalUtil.getValue(agencyMaster.getClientId()),
				OptionalUtil.getValue(agencyMaster.getAgencyCode()));
		if (count > 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}
		return agencyMapper.mapToModel(agencyMasterDao.create(agencyMapper.mapToEntity(agencyMaster)));
	}

	@Override
	public AgencyMaster updateAgency(Integer agencyId, AgencyMaster agencyMaster) {
		AgencyMasterEntity agencyMasterEntity = agencyMasterDao.findById(agencyId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(agencyId)));
		if (!agencyMasterEntity.getActivate())
			throw new BusinessException(AGENCYMASTERINACTIVE);
		validateBusinessConstraintsForUpdate(agencyMaster, agencyMasterEntity);
		agencyMaster.setLastUpdatedDate(LocalDateTime.now());
		return agencyMapper
				.mapToModel(agencyMasterDao.update(agencyMapper.mapToEntity(agencyMaster, agencyMasterEntity)));

	}

	@Override
	public void deactivateAgency(Integer agencyId, String lastUpdatedBy) {
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMANDATORYMSG);
		}
		Optional<AgencyMasterEntity> agencyMasterEntity = Optional.ofNullable(agencyMasterDao.findById(agencyId))
				.orElseThrow(() -> new BusinessException(AGENCYMASTERID));
		if (!agencyMasterEntity.isPresent())
			throw new ResourceNotFoundException(AGENCY, "code", agencyId);
		if (!agencyMasterEntity.get().getActivate())
			throw new BusinessException(AGENCYMASTERINACTIVE);
		agencyMasterEntity.get().setActivate(Boolean.FALSE);
		agencyMasterEntity.get().setLastUpdatedBy(lastUpdatedBy);
		agencyMasterEntity.get().setLastUpdatedDate(LocalDateTime.now());
		agencyMasterDao.update(agencyMasterEntity.get());

	}

	@Override
	public void activateAgency(Integer agencyId, String lastUpdatedBy) {
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMANDATORYMSG);
		}
		Optional<AgencyMasterEntity> agencyMasterEntity = Optional.ofNullable(agencyMasterDao.findById(agencyId))
				.orElseThrow(() -> new BusinessException(AGENCYMASTERID));
		if (!agencyMasterEntity.isPresent())
			throw new ResourceNotFoundException(AGENCY, "code", agencyId);
		if (agencyMasterEntity.get().getActivate())
			throw new BusinessException(AGENCYMASTERACTIVE);
		agencyMasterEntity.get().setActivate(Boolean.TRUE);
		agencyMasterEntity.get().setLastUpdatedBy(lastUpdatedBy);
		agencyMasterEntity.get().setLastUpdatedDate(LocalDateTime.now());
		agencyMasterDao.update(agencyMasterEntity.get());
	}

	private void clientIdToCarrierDesignatorValidation(String clientId) {
		if (globalMasterFeignClient.getAllCarrier(carrierCode, clientId, carrierName1, carrierName2, true).isEmpty()) {
			throw new BusinessException("Invalid Client Id " + clientId);
		}
	}

	private void countryCodeToCountryValidation(String countryCode) {
		if (!globalMasterFeignClient.validateCountryCode(countryCode)) {
			throw new BusinessException("Invalid Country Code " + countryCode);
		}
	}

	private void validateBusinessConstraintsForCreate(AgencyMaster agencyMaster) {
		if (OptionalUtil.isPresent(agencyMaster.getCityCode())) {
			if (OptionalUtil.getValue(agencyMaster.getCityCode()).trim().length() > 0) {
				cityCodeToAirport(OptionalUtil.getValue(agencyMaster.getCityCode()));
				cityCodeToAirporCode(OptionalUtil.getValue(agencyMaster.getCityCode()));
			}
		}
		clientIdToCarrierDesignatorValidation(OptionalUtil.getValue(agencyMaster.getClientId()));
		if (OptionalUtil.isPresent(agencyMaster.getCountryCode()))
			if (OptionalUtil.getValue(agencyMaster.getCountryCode()).trim().length() > 0) {
				countryCodeToCountryValidation(OptionalUtil.getValue(agencyMaster.getCountryCode()));
			}
		if (OptionalUtil.isPresent(agencyMaster.getAreaOfOperation())) {
			if (OptionalUtil.getValue(agencyMaster.getAreaOfOperation()).trim().length() > 0) {
				areaOfOperationToAirport(OptionalUtil.getValue(agencyMaster.getAreaOfOperation()));
				areaOfOperationToAirportCode(OptionalUtil.getValue(agencyMaster.getAreaOfOperation()));
			}
		}
		if (OptionalUtil.isPresent(agencyMaster.getReportingAgencyType())) {
			validateReportingAgencyType(OptionalUtil.getValue(agencyMaster.getClientId()),
					OptionalUtil.getValue(agencyMaster.getReportingAgencyType()));
		}
		if (OptionalUtil.isPresent(agencyMaster.getAgencyType())) {
			String value = OptionalUtil.getValue(agencyMaster.getAgencyType());
			if (value.trim().length() > 0)
				validateAgencyType(OptionalUtil.getValue(agencyMaster.getClientId()),
						OptionalUtil.getValue(agencyMaster.getAgencyType()));
		}
		if (OptionalUtil.isPresent(agencyMaster.getBspIndicator())) {
			String bspIndicator = OptionalUtil.getValue(agencyMaster.getBspIndicator());
			if (!(bspIndicator.equalsIgnoreCase("Y") || bspIndicator.equalsIgnoreCase("N"))) {
				throw new BusinessException(BSPINDICATOR);
			}
		}
		if (!OptionalUtil.isPresent(agencyMaster.getBspIndicator())) {
			agencyMaster.setBspIndicator(Optional.ofNullable(DEFAULTBSPINDICATOR));
		}
		if (OptionalUtil.isPresent(agencyMaster.getEmailAddress())) {
			if (OptionalUtil.getValue(agencyMaster.getEmailAddress()).trim().length() > 0) {
				boolean email = validationForEmailAddress(agencyMaster);
				if (!email) {
					throw new BusinessException(
							"Invalid Email Address " + OptionalUtil.getValue(agencyMaster.getEmailAddress()));
				}
			}
		}
	}

	private void validateBusinessConstraintsForUpdate(AgencyMaster agencyMaster,
			AgencyMasterEntity agencyMasterEntity) {
		if (OptionalUtil.isPresent(agencyMaster.getReportingAgencyType())) {
			validateReportAgencyTypeForUpdate(agencyMaster, agencyMasterEntity);
		}
		validateAgencyTypeForUpdate(agencyMaster, agencyMasterEntity);
		overLapForUpdate(agencyMaster, agencyMasterEntity);
		if (OptionalUtil.isPresent(agencyMaster.getCityCode())) {
			if (OptionalUtil.getValue(agencyMaster.getCityCode()).trim().length() > 0) {
				cityCodeToAirport(OptionalUtil.getValue(agencyMaster.getCityCode()));
				cityCodeToAirporCode(OptionalUtil.getValue(agencyMaster.getCityCode()));
			}
		}
		if (OptionalUtil.isPresent(agencyMaster.getClientId())) {
			clientIdToCarrierDesignatorValidation(getClientId(agencyMaster, agencyMasterEntity));
		}
		if (OptionalUtil.isPresent(agencyMaster.getCountryCode())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(agencyMaster.getCountryCode()))) {
			countryCodeToCountryValidation(getCountryCode(agencyMaster, agencyMasterEntity));
		}
		if (OptionalUtil.isPresent(agencyMaster.getAreaOfOperation())) {
			if (OptionalUtil.getValue(agencyMaster.getAreaOfOperation()).trim().length() > 0) {
				areaOfOperationToAirport(OptionalUtil.getValue(agencyMaster.getAreaOfOperation()));
				areaOfOperationToAirportCode(OptionalUtil.getValue(agencyMaster.getAreaOfOperation()));
			}
		}
		if (OptionalUtil.isPresent(agencyMaster.getBspIndicator())) {
			String bspIndicator = OptionalUtil.getValue(agencyMaster.getBspIndicator());
			if (!(bspIndicator.equalsIgnoreCase("Y") || bspIndicator.equalsIgnoreCase("N"))) {
				throw new BusinessException(BSPINDICATOR);
			}
		} 
		if (!OptionalUtil.isPresent(agencyMaster.getBspIndicator())) {
			agencyMaster.setBspIndicator(Optional.ofNullable(DEFAULTBSPINDICATOR));
		}
		if (OptionalUtil.isPresent(agencyMaster.getEmailAddress())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(agencyMaster.getEmailAddress()))) {
			boolean email = validationForEmailAddress(agencyMaster);
			if (!email) {
				throw new BusinessException(
						"Invalid Email Address " + OptionalUtil.getValue(agencyMaster.getEmailAddress()));
			}
		}
	}

	private void overLapForUpdate(AgencyMaster agencyMaster, AgencyMasterEntity agencyMasterEntity) {
		String clientId = getClientId(agencyMaster, agencyMasterEntity);
		String agencyCode = getAgencyCode(agencyMaster, agencyMasterEntity);
		if (!clientId.equalsIgnoreCase(agencyMasterEntity.getClientId())
				|| !agencyCode.equalsIgnoreCase(agencyMasterEntity.getAgencyCode())) {
			if (agencyMasterDao.getOverLapRecordCount(OptionalUtil.getValue(agencyMaster.getClientId()),
					OptionalUtil.getValue(agencyMaster.getAgencyCode()), agencyMaster.getAgencyId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	public static boolean validationForEmailAddress(AgencyMaster agencyMaster) {
		Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(OptionalUtil.getValue(agencyMaster.getEmailAddress()));
		return matcher.find();
	}

	private void cityCodeToAirport(String cityCode) {
		if (globalMasterFeignClient.getAllAirport(airportCode, airportName, cityCode, cityName, countryCode)
				.isEmpty()) {
			throw new BusinessException("Invalid City Code " + cityCode);
		}
	}

	private void cityCodeToAirporCode(String cityCode) {
		if (globalMasterFeignClient.getAllAirport(cityCode, airportName, null, cityName, countryCode).isEmpty()) {
			throw new BusinessException("Invalid City Code " + cityCode);
		}
	}

	private void areaOfOperationToAirport(String areaOfOperation) {
		if (globalMasterFeignClient.getAllAirport(airportCode, airportName, areaOfOperation, cityName, countryCode)
				.isEmpty()) {
			throw new BusinessException("Invalid Area Of Operation " + areaOfOperation);
		}
	}

	private void areaOfOperationToAirportCode(String areaOfOperation) {
		if (globalMasterFeignClient.getAllAirport(areaOfOperation, airportName, null, cityName, countryCode)
				.isEmpty()) {
			throw new BusinessException("Invalid Area Of Operation " + areaOfOperation);
		}
	}

	private void validateReportingAgencyType(String clientId, String reportingAgencyType) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(LOVREPORTINGAGENCYTYPE));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(reportingAgencyType));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Reporting Agency Type[" + reportingAgencyType + "] is Not Valid");
		}
	}

	private void validateAgencyType(String clientId, String agencyType) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(LOVAGENCYTYPE));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(agencyType));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Agency Type[" + agencyType + "] is Not Valid");
		}
	}

	private void validateReportAgencyTypeForUpdate(AgencyMaster agencyMaster, AgencyMasterEntity agencyMasterEntity) {
		if (OptionalUtil.isPresent(agencyMaster.getClientId())
				&& OptionalUtil.isPresent(agencyMaster.getReportingAgencyType()))
			validateReportingAgencyType(getClientId(agencyMaster, agencyMasterEntity),
					getReportingAgencyType(agencyMaster, agencyMasterEntity));
	}

	private void validateAgencyTypeForUpdate(AgencyMaster agencyMaster, AgencyMasterEntity agencyMasterEntity) {
		if (OptionalUtil.isPresent(agencyMaster.getClientId()) || OptionalUtil.isPresent(agencyMaster.getAgencyType()))
			agencyType = getAgencyType(agencyMaster, agencyMasterEntity);
		if (!StringUtil.isNullOrEmpty(agencyType)) {
			validateAgencyType(getClientId(agencyMaster, agencyMasterEntity), agencyType);
		}
	}

	private String getClientId(AgencyMaster agencyMaster, AgencyMasterEntity agencyMasterEntity) {
		return OptionalUtil.isPresent(agencyMaster.getClientId()) ? OptionalUtil.getValue(agencyMaster.getClientId())
				: agencyMasterEntity.getClientId();
	}

	private String getAgencyCode(AgencyMaster agencyMaster, AgencyMasterEntity agencyMasterEntity) {
		return OptionalUtil.isPresent(agencyMaster.getAgencyCode())
				? OptionalUtil.getValue(agencyMaster.getAgencyCode())
				: agencyMasterEntity.getAgencyCode();
	}

	private String getCountryCode(AgencyMaster agencyMaster, AgencyMasterEntity agencyMasterEntity) {
		return OptionalUtil.isPresent(agencyMaster.getCountryCode())
				? OptionalUtil.getValue(agencyMaster.getCountryCode())
				: agencyMasterEntity.getCountryCode();
	}

	private String getReportingAgencyType(AgencyMaster agencyMaster, AgencyMasterEntity agencyMasterEntity) {
		return OptionalUtil.isPresent(agencyMaster.getReportingAgencyType())
				? OptionalUtil.getValue(agencyMaster.getReportingAgencyType()).trim()
				: agencyMasterEntity.getReportingAgencyType();
	}

	private String getAgencyType(AgencyMaster agencyMaster, AgencyMasterEntity agencyMasterEntity) {
		return OptionalUtil.isPresent(agencyMaster.getAgencyType())
				? OptionalUtil.getValue(agencyMaster.getAgencyType())
				: agencyMasterEntity.getAgencyType();
	}

	@Override
	public List<AgencyMasterEntity> isValidAgencyCode(String agencyCode) {
		return agencyMasterDao.getByAgencyCode(agencyCode);
	}

	@Override
	public AgencyMasterResponse getListOfAgency(AgencyMaster agencyMaster, Optional<String> exceptionCall, Pageable pageable) {

		AgencyMasterResponse agencyMasterResponse = new AgencyMasterResponse();

		Page<AgencyMasterEntity> pageData = agencyMasterDao.getSearchAllAgency(agencyMapper.mapToEntity(agencyMaster),
				exceptionCall, pageable);
		agencyMasterResponse.setTotalCount(agencyMasterDao.getCount(agencyMapper.mapToEntity(agencyMaster), exceptionCall));
		agencyMasterResponse.setData(agencyMapper.mapToModel(pageData.getContent()));

		return agencyMasterResponse;
	}

	@Override
	public AgencyMaster getAgencyByAgencyCode(String agencyCode, String clientId) {
		return agencyMapper.mapToModel(agencyMasterDao.getAgencyByAgencyCode(agencyCode, clientId)
				.orElseThrow(() -> new BusinessException("Agency Not Found")));
	}
}
