package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.InterlineServiceChargeService;
import com.sgl.smartpra.master.model.InterlineServiceCharge;

@RestController
public class InterlineServiceChargeController {

	@Autowired
	private InterlineServiceChargeService interlineServiceChargeService;

	@PostMapping("/interlineServiceCharge")
	public InterlineServiceCharge createInterlineServiceCharge(
			@Validated(Create.class) @RequestBody InterlineServiceCharge interlineServiceCharge) {
		return interlineServiceChargeService.createInterlineServiceCharge(interlineServiceCharge);
	}
  
	@GetMapping("/interlineServiceCharge")
	public List<InterlineServiceCharge> getAllInterlineServiceCharge(
			@RequestParam(value = "documentType", required = true) Optional<String> documentType,
			@RequestParam(value = "iscRecordType", required = true) Optional<String> iscRecordType,
			@RequestParam(value = "effectiveFromDate", required = false) Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) Optional<String> effectiveToDate,
			@RequestParam(value = "issueCxr", required = false) Optional<String> issueCxr,
			@RequestParam(value = "billingCxr", required = false) Optional<String> billingCxr,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return interlineServiceChargeService.getInterlineServiceCharge(documentType, iscRecordType, issueCxr,
				effectiveFromDate,effectiveToDate, billingCxr, activate);
	}

	@GetMapping("/interlineServiceCharge/{iscId}")
	public InterlineServiceCharge getInterlineServiceChargeByIscId(@PathVariable(value = "iscId") Integer iscId) {
		return interlineServiceChargeService.getInterlineServiceChargeByIscId(iscId);
	}

	@PutMapping("/interlineServiceCharge/{iscId}")
	public InterlineServiceCharge updateInterlineServiceCharge(@PathVariable(value = "iscId") Integer iscId,
			@Validated(Update.class) @RequestBody InterlineServiceCharge interlineServiceCharge) {
		return interlineServiceChargeService.updateInterlineServiceCharge(iscId, interlineServiceCharge);
	}

	@PutMapping("/interlineServiceCharge/{iscId}/deactivate")
	public void deactivateInterlineServiceCharge(@Valid @PathVariable(value = "iscId") Integer iscId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		interlineServiceChargeService.deactivateInterlineServiceCharge(iscId, lastUpdatedBy);
	}

	@PutMapping("/interlineServiceCharge/{iscId}/activate")
	public void activateInterlineServiceCharge(@Valid @PathVariable(value = "iscId") Integer iscId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		interlineServiceChargeService.activateInterlineServiceCharge(iscId, lastUpdatedBy);
		
	}
		
		//Added new parameters
		@GetMapping("/interlineServiceCharge/proration")
		public List<InterlineServiceCharge> getInterlineServiceChargeProration(
				@RequestParam(value = "documentType", required = true)  Optional<String> documentType,
				@RequestParam(value = "iscRecordType", required = true)  Optional<String> iscRecordType,
				@RequestParam(value = "effectiveFromDate", required = false)  Optional<String> effectiveFromDate,
				@RequestParam(value = "settlementIndicator", required = false) Optional<String> settlementIndicator,
				@RequestParam(value = "clientId", required = false)  Optional<String> clientId,
				@RequestParam(value = "issueingCxr", required = false)  Optional<String> issueingCxr,
				@RequestParam(value = "billingCxr", required = false)  Optional<String> billingCxr){
			return interlineServiceChargeService.getInterlineServiceChargeProration(documentType, iscRecordType, effectiveFromDate, settlementIndicator, clientId,issueingCxr,billingCxr);
		}
		
}