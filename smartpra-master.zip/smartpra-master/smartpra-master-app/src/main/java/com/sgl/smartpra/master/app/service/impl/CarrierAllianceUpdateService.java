package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.master.app.dao.entity.CarrierAllianceEntity;
import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.CarrierAllianceBaseModel;
import com.sgl.smartpra.master.model.OneWorldCarrierAlliance;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CarrierAllianceUpdateService extends CarrierAllianceServiceImpl {

	public CarrierAlliance updateCarrierAlliance(CarrierAlliance carrierAlliance,
			CarrierAllianceEntity carrierAllianceEntity) {
		validateBusinessConstraints(carrierAlliance, carrierAllianceEntity);
		carrierAlliance.setActivate(Optional.of(true));
		return carrierAllianceMapper.mapToModel(
				carrierAllianceDao.update(carrierAllianceMapper.mapToEntity(carrierAlliance, carrierAllianceEntity)));
	}

	public OneWorldCarrierAlliance updateCarrierAlliance(OneWorldCarrierAlliance oneWorldCarrierAlliance,
			CarrierAllianceEntity carrierAllianceEntity) {
		validateBusinessConstraints(oneWorldCarrierAlliance, carrierAllianceEntity);
		oneWorldCarrierAlliance.setActivate(Optional.of(true));
		return carrierAllianceMapper.mapToOneWorldCarrierAllianceModel(carrierAllianceDao
				.update(carrierAllianceMapper.mapToEntity(oneWorldCarrierAlliance, carrierAllianceEntity)));
	}

	private void validateBusinessConstraints(CarrierAllianceBaseModel carrierAllianceBaseModel,
			CarrierAllianceEntity carrierAllianceEntity) {
		validateEffectiveToDate(carrierAllianceBaseModel, carrierAllianceEntity);
		super.validateCarrierDesignatorCode(carrierAllianceBaseModel);
		super.validateCarrierCode(carrierAllianceBaseModel);
		validateAllianceName(carrierAllianceBaseModel, carrierAllianceEntity);
		validateOverlap(carrierAllianceBaseModel, carrierAllianceEntity);
	}

	private void validateAllianceName(CarrierAllianceBaseModel carrierAllianceBaseModel,
			CarrierAllianceEntity carrierAllianceEntity) {
		if (OptionalUtil.isPresent(carrierAllianceBaseModel.getClientId())
				|| OptionalUtil.isPresent(carrierAllianceBaseModel.getAllianceName())) {
			super.validateAllianceName(getClientId(carrierAllianceBaseModel, carrierAllianceEntity),
					getAllianceName(carrierAllianceBaseModel, carrierAllianceEntity));
		}
	}

	private void validateEffectiveToDate(CarrierAllianceBaseModel carrierAllianceBaseModel,
			CarrierAllianceEntity carrierAllianceEntity) {
		if (OptionalUtil.isPresent(carrierAllianceBaseModel.getEffectiveFromDate())
				|| OptionalUtil.isPresent(carrierAllianceBaseModel.getEffectiveToDate())) {
			super.validateEffectiveToDate(getEffectiveToDate(carrierAllianceBaseModel, carrierAllianceEntity),
					getEffectiveFromDate(carrierAllianceBaseModel, carrierAllianceEntity));
		}
	}

	private void validateOverlap(CarrierAllianceBaseModel carrierAllianceBaseModel,
			CarrierAllianceEntity carrierAllianceEntity) {

		// During Update input for "effectiveFromDate" can be null if the element is not
		// sent in json. if that is the case take the value from the db(entity) to
		// validate overlap
		LocalDate effectiveFromDate = getEffectiveFromDate(carrierAllianceBaseModel, carrierAllianceEntity);

		// During Update input for "effectiveToDate" can be null if the element is not
		// sent in json. if that is the case take the value from the db(entity) to
		// validate overlap
		LocalDate effectiveToDate = getEffectiveToDate(carrierAllianceBaseModel, carrierAllianceEntity);

		// During Update input for "clientId" can be null if the element is not sent in
		// json. if that is the case take the value from the db(entity) to validate
		// overlap
		String clientId = getClientId(carrierAllianceBaseModel, carrierAllianceEntity);

		// During Update input for "allianceName" can be null if the element is not sent
		// in json. if that is the case take the value from the db(entity) to validate
		// overlap
		String allianceName = getAllianceName(carrierAllianceBaseModel, carrierAllianceEntity);

		// During Update input for "carrierCode" can be null if the element is not sent
		// in json. if that is the case take the value from the db(entity) to validate
		// overlap
		String carrierCode = OptionalUtil.isPresent(carrierAllianceBaseModel.getCarrierCode())
				? OptionalUtil.getValue(carrierAllianceBaseModel.getCarrierCode())
				: carrierAllianceEntity.getCarrierCode();

		if (!carrierCode.equalsIgnoreCase(carrierAllianceEntity.getCarrierCode())
				|| !clientId.equalsIgnoreCase(carrierAllianceEntity.getClientId())
				|| !allianceName.equalsIgnoreCase(carrierAllianceEntity.getAllianceName())
				|| !effectiveFromDate.isEqual(carrierAllianceEntity.getEffectiveFromDate())
				|| !effectiveToDate.isEqual(carrierAllianceEntity.getEffectiveToDate())) {
			if (carrierAllianceDao.getOverLapRecordCount(effectiveFromDate, effectiveToDate, allianceName, carrierCode,
					clientId, carrierAllianceEntity.getCarrierAllianceDtlId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private String getClientId(CarrierAllianceBaseModel carrierAllianceBaseModel,
			CarrierAllianceEntity carrierAllianceEntity) {
		return OptionalUtil.isPresent(carrierAllianceBaseModel.getClientId())
				? OptionalUtil.getValue(carrierAllianceBaseModel.getClientId())
				: carrierAllianceEntity.getClientId();
	}

	private LocalDate getEffectiveFromDate(CarrierAllianceBaseModel carrierAllianceBaseModel,
			CarrierAllianceEntity carrierAllianceEntity) {
		return OptionalUtil.isPresent(carrierAllianceBaseModel.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(carrierAllianceBaseModel.getEffectiveFromDate())
				: carrierAllianceEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(CarrierAllianceBaseModel carrierAllianceBaseModel,
			CarrierAllianceEntity carrierAllianceEntity) {
		return OptionalUtil.isPresent(carrierAllianceBaseModel.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(carrierAllianceBaseModel.getEffectiveToDate())
				: carrierAllianceEntity.getEffectiveToDate();
	}

}
