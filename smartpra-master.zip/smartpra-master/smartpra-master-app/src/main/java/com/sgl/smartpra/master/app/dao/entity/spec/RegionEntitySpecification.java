package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.RegionEntity;
import com.sgl.smartpra.master.model.Region;

public class RegionEntitySpecification {

	private static final String REGION_CODE = "regionCode";
	private static final String ISACTIVE = "isActive";

	private RegionEntitySpecification() {
	}

	public static Specification<RegionEntity> likeRegionCode(String regionCode) {
		return (regionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.like(regionEntity.get(REGION_CODE),
				regionCode + "%");
	}

	public static Specification<RegionEntity> likeRegionName(String regionName) {
		return (regionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.like(regionEntity.get("regionName"),
				regionName + "%");
	}

	public static Specification<RegionEntity> likeContinentName(String continentName) {
		return (regionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.like(regionEntity.get("continentName"),
				continentName + "%");
	}

	public static Specification<RegionEntity> isActive(Boolean isActive) {
		return (regionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(regionEntity.get(ISACTIVE),
				isActive);
	}

	public static Specification<RegionEntity> search(Region region, Optional<String> exceptionCall) {
		return (regionEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(region.getRegionCode())
					&& OptionalUtil.getValue(region.getRegionCode()) != null) {
				predicates.add(criteriaBuilder.like(regionEntity.get(REGION_CODE),
						OptionalUtil.getValue(region.getRegionCode()) + "%"));
			}
			if (OptionalUtil.isPresent(region.getClientId())) {
				predicates.add(criteriaBuilder.equal(regionEntity.get("clientId"),
						OptionalUtil.getValue(region.getClientId())));
			}
			if (OptionalUtil.isPresent(region.getRegionName())
					&& OptionalUtil.getValue(region.getRegionName()) != null) {
				predicates.add(criteriaBuilder.like(regionEntity.get("regionName"),
						OptionalUtil.getValue(region.getRegionName()) + "%"));
			}

			if (OptionalUtil.isPresent(region.getContinentName())
					&& OptionalUtil.getValue(region.getContinentName()) != null) {
				predicates.add(criteriaBuilder.like(regionEntity.get("continentName"),
						OptionalUtil.getValue(region.getContinentName()) + "%"));
			}
			if (!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (region.getIsActive() == null || region.getIsActive()) {
					predicates.add(criteriaBuilder.isTrue(regionEntity.get(ISACTIVE)));
				} else {
					predicates.add(criteriaBuilder.isFalse(regionEntity.get(ISACTIVE)));
				}
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<RegionEntity> equalsClientId(String clientId) {
		return (regionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(regionEntity.get("clientId"),
				clientId);
	}

	public static Specification<RegionEntity> equalsRegionCode(String regionCode) {
		return (regionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(regionEntity.get(REGION_CODE),
				regionCode);
	}

	public static Specification<RegionEntity> notEqualsRegionId(Integer regionId) {
		return (regionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(regionEntity.get("regionId"),
				regionId);
	}

}
