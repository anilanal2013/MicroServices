package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.CodeShareEntity;

public class CodeShareEntitySpecification {

	private CodeShareEntitySpecification() {
	}

	public static Specification<CodeShareEntity> betweenTravelFromAndTravelToDate(LocalDate travelDate) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(travelDate), codeShareEntity.get("travelFromDate"),
				codeShareEntity.get("travelToDate"));
	}
	
	public static Specification<CodeShareEntity> betweenTravelFromDate(LocalDate travelFromDate,
			LocalDate travelToDate) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				codeShareEntity.get("travelFromDate"), criteriaBuilder.literal(travelFromDate),
				criteriaBuilder.literal(travelToDate));
	}

	public static Specification<CodeShareEntity> betweenSaleFromAndSaleToDate(LocalDate saleDate) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(saleDate), codeShareEntity.get("saleFromDate"),
				codeShareEntity.get("saleToDate"));
	}
	
	public static Specification<CodeShareEntity> betweenSaleFromDate(LocalDate saleFromDate,
			LocalDate saleToDate) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				codeShareEntity.get("saleFromDate"), criteriaBuilder.literal(saleFromDate),
				criteriaBuilder.literal(saleToDate));
	}
	
	public static Specification<CodeShareEntity> travelGreaterThanOrEqualTo(LocalDate travelFromDate) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(codeShareEntity.get("travelFromDate"), travelFromDate);
	}

	public static Specification<CodeShareEntity> travelLessThanOrEqualTo(LocalDate travelToDate) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(codeShareEntity.get("travelToDate"), travelToDate);
	}
	
	public static Specification<CodeShareEntity> saleGreaterThanOrEqualTo(LocalDate saleFromDate) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(codeShareEntity.get("saleFromDate"), saleFromDate);
	}

	public static Specification<CodeShareEntity> saleLessThanOrEqualTo(LocalDate saleToDate) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(codeShareEntity.get("saleToDate"), saleToDate);
	}


	public static Specification<CodeShareEntity> betweenFromBookedAndToBookedFlightNumber(String flightNumber) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(Integer.parseInt(flightNumber)), codeShareEntity.get("fromBookedFlightNumber"),
				codeShareEntity.get("toBookedFlightNumber"));
	}

	public static Specification<CodeShareEntity> equalsMarketingCXR(String marketingCXR) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(codeShareEntity.get("marketingCXR"), marketingCXR);

	}

	public static Specification<CodeShareEntity> equalsFromBookedFlightNumber(String fromBookedFlightNumber) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(codeShareEntity.get("fromBookedFlightNumber"), fromBookedFlightNumber);

	}

	public static Specification<CodeShareEntity> equalsToBookedFlightNumber(String toBookedFlightNumber) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(codeShareEntity.get("toBookedFlightNumber"), toBookedFlightNumber);

	}

	public static Specification<CodeShareEntity> equalsClientId(String clientId) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(codeShareEntity.get("clientId"), clientId);

	}
	
	public static Specification<CodeShareEntity> notEqualsCodeShareId(Integer codeShareId) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(codeShareEntity.get("codeShareId"),
				codeShareId);
	}

	public static Specification<CodeShareEntity> isActive() {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(codeShareEntity.get("isActive"), true);
	}

	public static void orderByAsc(Root<CodeShareEntity> codeShareEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String marketingCXR, String fromBookedFlightNumber, String fromArea) {
		criteriaQuery.orderBy(criteriaBuilder.asc(codeShareEntity.get(marketingCXR)),
				criteriaBuilder.asc(codeShareEntity.get(fromBookedFlightNumber)),
				criteriaBuilder.asc(codeShareEntity.get(fromArea)));

	}

	public static Specification<CodeShareEntity> search(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> travelFromDate, Optional<String> travelToDate,Optional<String> saleFromDate, Optional<String> saleToDate,
			Optional<Boolean> isActive) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.like(codeShareEntity.get("clientId"), OptionalUtil.getValue(clientId) + "%"));
			}
			if (OptionalUtil.isPresent(marketingCXR)) {
				predicates.add(criteriaBuilder.like(codeShareEntity.get("marketingCXR"),
						OptionalUtil.getValue(marketingCXR) + "%"));
			}

			if (OptionalUtil.isPresent(travelFromDate) && OptionalUtil.isPresent(travelToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(travelFromDate)),
								codeShareEntity.get("travelFromDate"),
								codeShareEntity.get("travelToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(travelToDate)),
								codeShareEntity.get("travelFromDate"),
								codeShareEntity.get("travelToDate")),
						criteriaBuilder.between(codeShareEntity.get("travelFromDate"),
								OptionalUtil.getLocalDateValue(travelFromDate),
								OptionalUtil.getLocalDateValue(travelToDate)),
						criteriaBuilder.between(codeShareEntity.get("travelToDate"),
								OptionalUtil.getLocalDateValue(travelFromDate),
								OptionalUtil.getLocalDateValue(travelToDate))));
			} else {
				if (OptionalUtil.isPresent(travelFromDate) && OptionalUtil.getValue(travelFromDate) != null
						&& !OptionalUtil.getValue(travelFromDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(travelFromDate)),
							codeShareEntity.get("travelFromDate"), codeShareEntity.get("travelToDate")));
				}
				if (OptionalUtil.isPresent(travelToDate) && OptionalUtil.getValue(travelToDate) != null
						&& !OptionalUtil.getValue(travelToDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(travelToDate)),
							codeShareEntity.get("travelFromDate"), codeShareEntity.get("travelToDate")));
				}
			}
			
			if (OptionalUtil.isPresent(saleFromDate) && OptionalUtil.isPresent(saleToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleFromDate)),
								codeShareEntity.get("saleFromDate"),
								codeShareEntity.get("saleToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleToDate)),
								codeShareEntity.get("saleFromDate"),
								codeShareEntity.get("saleToDate")),
						criteriaBuilder.between(codeShareEntity.get("saleFromDate"),
								OptionalUtil.getLocalDateValue(saleFromDate),
								OptionalUtil.getLocalDateValue(saleToDate)),
						criteriaBuilder.between(codeShareEntity.get("saleToDate"),
								OptionalUtil.getLocalDateValue(saleFromDate),
								OptionalUtil.getLocalDateValue(saleToDate))));
			} else {
				if (OptionalUtil.isPresent(saleFromDate) && OptionalUtil.getValue(saleFromDate) != null
						&& !OptionalUtil.getValue(saleFromDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleFromDate)),
							codeShareEntity.get("saleFromDate"), codeShareEntity.get("saleToDate")));
				}
				if (OptionalUtil.isPresent(saleToDate) && OptionalUtil.getValue(saleToDate) != null
						&& !OptionalUtil.getValue(saleToDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleToDate)),
							codeShareEntity.get("saleFromDate"), codeShareEntity.get("saleToDate")));
				}
			}

			if (OptionalUtil.getValue(isActive) == null || OptionalUtil.getValue(isActive)) {
				predicates.add(criteriaBuilder.isTrue(codeShareEntity.get("isActive")));
			} else {
				predicates.add(criteriaBuilder.isFalse(codeShareEntity.get("isActive")));
			}
			orderByAsc(codeShareEntity, criteriaQuery, criteriaBuilder, "marketingCXR", "fromBookedFlightNumber",
					"fromArea");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<CodeShareEntity> getCodeShareByEffectiveDate(Optional<String> clientId,
			Optional<String> marketingCXR, Optional<String> marketedRBDList, Optional<String> effectiveDate) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.like(codeShareEntity.get("clientId"), OptionalUtil.getValue(clientId) + "%"));
			}
			if (OptionalUtil.isPresent(marketingCXR)) {
				predicates.add(criteriaBuilder.like(codeShareEntity.get("marketingCXR"),
						OptionalUtil.getValue(marketingCXR) + "%"));
			}
			if (OptionalUtil.isPresent(marketedRBDList)) {
				predicates.add(criteriaBuilder.like(codeShareEntity.get("marketedRBDList"),
						OptionalUtil.getValue(marketedRBDList) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								codeShareEntity.get("travelFromDate"), codeShareEntity.get("travelToDate")));
			}
			predicates.add(criteriaBuilder.isTrue(codeShareEntity.get("isActive")));

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
	
	public static Specification<CodeShareEntity> getCodeShareBySaleEffectiveDate(Optional<String> clientId,
			Optional<String> marketingCXR, Optional<String> marketedRBDList, Optional<String> effectiveDate,Optional<String> flightNumber) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.equal(codeShareEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(marketingCXR)) {
				predicates.add(criteriaBuilder.equal(codeShareEntity.get("marketingCXR"), OptionalUtil.getValue(marketingCXR)));
			}
			if (OptionalUtil.isPresent(marketedRBDList)) {
				predicates.add(criteriaBuilder.like(codeShareEntity.get("marketedRBDList"),
						 "%" +OptionalUtil.getValue(marketedRBDList) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								codeShareEntity.get("saleFromDate"), codeShareEntity.get("saleToDate")));
			}
			if (OptionalUtil.isPresent(flightNumber)) {
				predicates.add(
						criteriaBuilder.between(criteriaBuilder.literal(Integer.parseInt(OptionalUtil.getValue(flightNumber))),
								codeShareEntity.get("fromBookedFlightNumber"), codeShareEntity.get("toBookedFlightNumber")));
			}
			predicates.add(criteriaBuilder.isTrue(codeShareEntity.get("isActive")));

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
	
	public static Specification<CodeShareEntity> checkOverlapping(Optional<String> marketingCXR, Optional<String> fromBookedFlightNumber, Optional<String> toBookedFlightNumber, 
			Optional<String> saleFromDate, Optional<String> saleToDate, Optional<String> travelFromDate, Optional<String> travelToDate, Optional<String> clientId,Optional<Integer> codeShareId) {
		return (codeShareEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(codeShareEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(marketingCXR)) {
				predicates.add(criteriaBuilder.equal(codeShareEntity.get("marketingCXR"),OptionalUtil.getValue(marketingCXR)));
			}
			if (OptionalUtil.isPresent(fromBookedFlightNumber)) {
				predicates.add(criteriaBuilder.equal(codeShareEntity.get("fromBookedFlightNumber"), OptionalUtil.getValue(fromBookedFlightNumber)));
			}
			if (OptionalUtil.isPresent(toBookedFlightNumber)) {
				predicates.add(criteriaBuilder.equal(codeShareEntity.get("toBookedFlightNumber"),OptionalUtil.getValue(toBookedFlightNumber)));
			}
			if (OptionalUtil.isPresent(codeShareId)) {
				predicates.add(criteriaBuilder.notEqual(codeShareEntity.get("codeShareId"),OptionalUtil.getValue(codeShareId)));
			}

			if (OptionalUtil.isPresent(travelFromDate) && OptionalUtil.isPresent(travelToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(travelFromDate)),
								codeShareEntity.get("travelFromDate"),
								codeShareEntity.get("travelToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(travelToDate)),
								codeShareEntity.get("travelFromDate"),
								codeShareEntity.get("travelToDate")),
						criteriaBuilder.or(
								criteriaBuilder.and(
								criteriaBuilder.greaterThanOrEqualTo(codeShareEntity.get("travelFromDate"), (OptionalUtil.getLocalDateValue(travelFromDate))),
								criteriaBuilder.lessThanOrEqualTo(codeShareEntity.get("travelToDate"), (OptionalUtil.getLocalDateValue(travelToDate)))))
						));
				
//				predicates.add(criteriaBuilder.or(
//						criteriaBuilder.and(
//						criteriaBuilder.greaterThanOrEqualTo(codeShareEntity.get("travelFromDate"), (OptionalUtil.getLocalDateValue(travelFromDate))),
//						criteriaBuilder.lessThanOrEqualTo(codeShareEntity.get("travelToDate"), (OptionalUtil.getLocalDateValue(travelToDate)))))
//						
//						
//						);
			}
			
			if (OptionalUtil.isPresent(saleFromDate) && OptionalUtil.isPresent(saleToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleFromDate)),
								codeShareEntity.get("saleFromDate"),
								codeShareEntity.get("saleToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(saleToDate)),
								codeShareEntity.get("saleFromDate"),
								codeShareEntity.get("saleToDate")),
						criteriaBuilder.or(
								criteriaBuilder.greaterThanOrEqualTo(codeShareEntity.get("saleFromDate"), (OptionalUtil.getLocalDateValue(saleFromDate))),
								criteriaBuilder.lessThanOrEqualTo(codeShareEntity.get("saleToDate"), (OptionalUtil.getLocalDateValue(saleToDate))))
						));
				
//				predicates.add(criteriaBuilder.or(
//						criteriaBuilder.greaterThanOrEqualTo(codeShareEntity.get("saleFromDate"), (OptionalUtil.getLocalDateValue(saleFromDate))),
//						criteriaBuilder.lessThanOrEqualTo(codeShareEntity.get("saleToDate"), (OptionalUtil.getLocalDateValue(saleToDate))))
//						
//						
//						);
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
