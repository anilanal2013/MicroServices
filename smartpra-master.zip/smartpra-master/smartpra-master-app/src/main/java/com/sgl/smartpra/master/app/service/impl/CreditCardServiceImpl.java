package com.sgl.smartpra.master.app.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.CreditCardDao;
import com.sgl.smartpra.master.app.dao.entity.CreditCardEntity;
import com.sgl.smartpra.master.app.mapper.CreditCardMapper;
import com.sgl.smartpra.master.app.service.CreditCardService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.CreditCard;
import com.sgl.smartpra.master.model.ListOfValues;

@Service
@Transactional
public class CreditCardServiceImpl implements CreditCardService {

	@Autowired
	private CreditCardDao creditCardDao;

	@Autowired
	private CreditCardMapper creditCardMapper;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private ListOfValuesService listOfValuesService;

	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String REPORTING_FREQUENCY_LOV_COLUMN_VALUE = LOVEnum.REPORTING_FREQUENCY.getLOVEnum();
	public static final String CREDITCARD_ALREADY_INACTIVE = "Credit Card is already in deactive state";
	public static final String CREDITCARD_ALREADY_ACTIVE = "Credit Card is already in active state";
	private static final String SERVICE_CHARGE_PATTERN = "^[0-9]{1,3}(\\.[0-9]{0,2})?$";
	private static final String STARTING_DIGITS_PATTERN = "^\\d{4,4}?$";
	private static final String MIN_DIGITS_PATTERN = "^\\d{1,2}?$";

	@Override
	public List<CreditCard> getAllCreditCard(CreditCard creditCard, Optional<String> exceptionCall) {
		return creditCardMapper.mapToModel(creditCardDao.getAllCreditCard(creditCard, exceptionCall));
	}

	@Override
	public CreditCard getCreditCardById(Integer creditCardId) {
		return creditCardMapper.mapToModel(creditCardDao.findById(creditCardId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(creditCardId))));
	}

	@Override
	public CreditCard createCreditCard(CreditCard creditCard) {

		validateStartingDigits(creditCard);
		validateMinAndMax(creditCard);
		if (!OptionalUtil.isPresent(creditCard.getUatpAirlineCode())) {
			creditCard.setUatpAirlineCode(Optional.of(""));
		}
		validateBusinessConstrainsForCreate(creditCard);
		creditCard.setActivate(Optional.of(Boolean.TRUE));
		return creditCardMapper.mapToModel(creditCardDao.createCreditCard(creditCardMapper.mapToEntity(creditCard)));
	}

	private void validateMinAndMax(CreditCard creditCard) {
		Pattern serviceChargePattern = Pattern.compile(MIN_DIGITS_PATTERN);
		if (OptionalUtil.isPresent(creditCard.getMinLength())) {
			Integer minDigits = OptionalUtil.getValue(creditCard.getMinLength());
			if (!serviceChargePattern.matcher(minDigits.toString()).matches()) {
				throw new BusinessException("Invalid Min Length Size " + minDigits);
			}
		}  
		if (OptionalUtil.isPresent(creditCard.getMaxLength())) { 
			Integer maxDigits = OptionalUtil.getValue(creditCard.getMaxLength());
			if (!serviceChargePattern.matcher(maxDigits.toString()).matches()) {
				throw new BusinessException("Invalid Max Length Size " + maxDigits);
			}
		}
	}

	@Override
	public CreditCard updateCreditCard(Integer creditCardId, CreditCard creditCard) {
		if (OptionalUtil.isPresent(creditCard.getStartingDigits())) {
			validateStartingDigits(creditCard);
		}
		CreditCardEntity creditCardEntity = creditCardDao.findById(creditCardId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(creditCardId)));

		validateBusinessConstrainsForUpdate(creditCard, creditCardEntity);
		return creditCardMapper
				.mapToModel(creditCardDao.updateCreditCard(creditCardMapper.mapToEntity(creditCard, creditCardEntity)));
	}

	@Override
	public void deactivateCreditCard(@Valid Integer creditCardId, String lastUpdatedBy) {

		CreditCardEntity creditCardEntity = creditCardDao.findById(creditCardId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(creditCardId)));

		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (!creditCardEntity.getActivate()) {
			throw new BusinessException(CREDITCARD_ALREADY_INACTIVE);
		}

		creditCardEntity.setActivate(Boolean.FALSE);
		creditCardEntity.setLastUpdatedBy(lastUpdatedBy);
		creditCardDao.updateCreditCard(creditCardEntity);

	}

	@Override
	public void activateCreditCard(@Valid Integer creditCardId, String lastUpdatedBy) {
		CreditCardEntity creditCardEntity = creditCardDao.findById(creditCardId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(creditCardId)));

		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (creditCardEntity.getActivate()) {
			throw new BusinessException(CREDITCARD_ALREADY_ACTIVE);
		}

		creditCardEntity.setActivate(Boolean.TRUE);
		creditCardEntity.setLastUpdatedBy(lastUpdatedBy);
		creditCardDao.updateCreditCard(creditCardEntity);
	}

	private void validateBusinessConstrainsForCreate(CreditCard creditCard) {
		validateOverLapForCreate(creditCard);
		validateServiceCharge(creditCard.getServiceCharge());

		if (!OptionalUtil.isPresent(creditCard.getUatpFlag())) {
			creditCard.setUatpFlag(Optional.of(Boolean.FALSE));
		}

		if (OptionalUtil.isPresent(creditCard.getUatpAirlineCode())) {
			validateUATPAirlineCode(OptionalUtil.getValue(creditCard.getUatpAirlineCode()));
		}

		if (OptionalUtil.isPresent(creditCard.getBillingFrequency())) {
			validateBillingFrequency(OptionalUtil.getValue(creditCard.getClientId()),
					OptionalUtil.getValue(creditCard.getBillingFrequency()));
		}
	}

	private void validateBusinessConstrainsForUpdate(CreditCard creditCard, CreditCardEntity creditCardEntity) {
		validateMinAndMax(creditCard);
		validateServiceCharge(creditCard.getServiceCharge());
		validateOverLapForUpdate(creditCard, creditCardEntity);

		if (OptionalUtil.isPresent(creditCard.getUatpAirlineCode())) {
			validateUATPAirlineCode(OptionalUtil.getValue(creditCard.getUatpAirlineCode()));
		}
		if (OptionalUtil.isPresent(creditCard.getBillingFrequency())) {
			validateBillingFrequency(getClientId(creditCard, creditCardEntity),
					OptionalUtil.getValue(creditCard.getBillingFrequency()));
		}
	}

	private void validateBillingFrequency(String clientId, String billingFrequency) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(REPORTING_FREQUENCY_LOV_COLUMN_VALUE));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(billingFrequency));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Invalid Billing Frequency " + billingFrequency);
		}

	}

	private void validateOverLapForUpdate(CreditCard creditCard, CreditCardEntity creditCardEntity) {
		if (creditCardDao.getOverLapForUpdate(getClientId(creditCard, creditCardEntity),
				getCcCompanyCode(creditCard, creditCardEntity), getUatpAirlineCode(creditCard, creditCardEntity),
				creditCardEntity.getCreditCardId()) != 0) {
			throw new BusinessException("Record already exists");
		}
	}

	private String getUatpAirlineCode(CreditCard creditCard, CreditCardEntity creditCardEntity) {
		return OptionalUtil.isPresent(creditCard.getUatpAirlineCode())
				? OptionalUtil.getValue(creditCard.getUatpAirlineCode())
				: creditCardEntity.getUatpAirlineCode();
	}

	private String getCcCompanyCode(CreditCard creditCard, CreditCardEntity creditCardEntity) {
		return OptionalUtil.isPresent(creditCard.getCcCompanyCode())
				? OptionalUtil.getValue(creditCard.getCcCompanyCode())
				: creditCardEntity.getCcCompanyCode();
	}

	private String getClientId(CreditCard creditCard, CreditCardEntity creditCardEntity) {
		return OptionalUtil.isPresent(creditCard.getClientId()) ? OptionalUtil.getValue(creditCard.getClientId())
				: creditCardEntity.getClientId();
	}

	private void validateOverLapForCreate(CreditCard creditCard) {
		if (creditCardDao.getOverLapForCreate(creditCard.getClientId(), creditCard.getCcCompanyCode(),
				creditCard.getUatpAirlineCode()) != 0) {
			throw new BusinessException("Record already exists");
		}
	}

	private void validateUATPAirlineCode(String uatpAirlineCode) {

		if (globalMasterFeignClient.getAllCarrier(uatpAirlineCode, null, null, null, true).isEmpty()) {
			throw new BusinessException("Invalid UATP Airline Code " + uatpAirlineCode);
		}
	}

	private void validateServiceCharge(Optional<String> serviceCharge) {
		Pattern serviceChargePattern = Pattern.compile(SERVICE_CHARGE_PATTERN);
		if (OptionalUtil.isPresent(serviceCharge)) {
			String serCharge = OptionalUtil.getValue(serviceCharge);
			if (!serviceChargePattern.matcher(serCharge).matches()) {
				throw new BusinessException("Invalid Service Charge " + serCharge);
			}
		}
	}

	private void validateStartingDigits(CreditCard creditCard) {
		Pattern serviceChargePattern = Pattern.compile(STARTING_DIGITS_PATTERN);
		if (OptionalUtil.isPresent(creditCard.getStartingDigits())) {
			Integer startingDigits = OptionalUtil.getValue(creditCard.getStartingDigits());
			if (!serviceChargePattern.matcher(startingDigits.toString()).matches()) {
				throw new BusinessException("Invald Starting Digits Size " + startingDigits);
			}
		}
	}
}
