package com.sgl.smartpra.master.app.repository.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_reason_code")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class ReasonCodeEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "reason_code_id")
	private Integer reasonCodeId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "reason_code")
	private String reasonCode;

	@Column(name = "reason_category")
	private String reasonCategory;

	@Column(name = "reason_type")
	private String reasonType;

	@Column(name = "reason_description")
	private String reasonDescription;

	@Column(name = "is_cpn_breakdown_mandatory")
	private String isCpnBreakdownMandatory;

	@Column(name = "gross_allowed")
	private String grossAllowed;

	@Column(name = "isc_allowed")
	private String iscAllowed;

	@Column(name = "tax_allowed")
	private String taxAllowed;

	@Column(name = "other_commission_allowed")
	private String otherCommissionAllowed;

	@Column(name = "handling_fee_allowed")
	private String handlingFeeAllowed;

	@Column(name = "uatp_allowed")
	private String uatpAllowed;

	@Column(name = "vat_allowed")
	private String vatAllowed;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "profit_centre")
	private String profitCentre;

	@Column(name = "cost_centre")
	private String costCentre;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@Column(name = "attribute_3")
	private String attribute3;

	@Column(name = "attribute_4")
	private String attribute4;

	@Column(name = "attribute_5")
	private String attribute5;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "action_indicator")
	private String actionIndicator;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
