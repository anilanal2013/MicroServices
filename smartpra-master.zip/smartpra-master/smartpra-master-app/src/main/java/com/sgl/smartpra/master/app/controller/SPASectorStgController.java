package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.master.app.service.SPASectorStgService;
import com.sgl.smartpra.master.model.SPASectorStg;

@RestController
@RequestMapping("/spa/sector/stg")
public class SPASectorStgController {

	@Autowired
	private SPASectorStgService spaSectorStgService;

	@GetMapping("/{spaSectorId}")
	public SPASectorStg getSPASectorBySpaSectorId(@PathVariable(value = "spaSectorId") Integer spaSectorId) {
		return spaSectorStgService.findById(spaSectorId);
	}

	@GetMapping("/{spaKey}/{spaMainId}/{clientId}")
	public List<SPASectorStg> getSPASectorBySpaKey(@PathVariable(value = "spaKey") Optional<Integer> spaKey,
			@PathVariable(value = "spaMainId") Optional<Integer> spaMainId,
			@PathVariable(value = "clientId") Optional<String> clientId) {
		return spaSectorStgService.findBySpaKeyMainIdClientId(spaKey, spaMainId, clientId);
	}

}
