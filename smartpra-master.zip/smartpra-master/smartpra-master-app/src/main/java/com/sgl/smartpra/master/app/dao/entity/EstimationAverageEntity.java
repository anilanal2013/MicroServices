package com.sgl.smartpra.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
@Table(name = "mas_estimation_average")
public class EstimationAverageEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "estimation_average_id")
	private Integer estimationAverageId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "flight_number")
	private String flightNumber;

	@Column(name = "from_airport")
	private String fromAirport;

	@Column(name = "to_airport")
	private String toAirport;

	@Column(name = "flight_date")
	private LocalDate flightDate;

	@Column(name = "rbd")
	private String rbd;

	@Column(name = "cabin")
	private String cabin;

	@Column(name = "self_oc")
	private String selfOc;

	@Column(name = "passenger_type")
	private String passengerType;

	@Column(name = "threshold_percentage")
	private String thresholdPercentage;

	@Column(name = "provisional_currency")
	private String provisionalCurrency;

	@Column(name = "average_revenue")
	private BigDecimal averageRevenue;

	@Column(name = "average_discount")
	private BigDecimal averageDiscount;

	@Column(name = "average_commission")
	private BigDecimal averageCommission;

	@Column(name = "average_surcharge")
	private BigDecimal averageSurcharge;

	@Column(name = "average_orc")
	private BigDecimal averageOrc;

	@Column(name = "total_pax_count")
	private Integer totalPaxCount;

	@Column(name = "average_rebate_revenue")
	private BigDecimal averageRebateRevenue;

	@Column(name = "total_rebate_count")
	private Integer totalRebateCount;

	@Column(name = "source")
	private String source;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}