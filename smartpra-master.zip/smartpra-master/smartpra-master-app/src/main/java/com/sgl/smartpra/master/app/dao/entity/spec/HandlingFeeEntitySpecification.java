package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.HandlingFeeEntity;

public class HandlingFeeEntitySpecification {

	private static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";
	private static final String EFFECTIVE_TO_DATE = "effectiveToDate";
	private static final String ISSUE_CXR = "issueCxr";
	private static final String OPERATING_CXR = "operatingCxr";

	public static Specification<HandlingFeeEntity> search(Optional<String> issueCxr, Optional<String> operatingCxr,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(issueCxr)) {
				predicates.add(
						criteriaBuilder.like(handlingFeeEntity.get(ISSUE_CXR), OptionalUtil.getValue(issueCxr) + "%"));
			}
			if (OptionalUtil.isPresent(operatingCxr)) {
				predicates.add(criteriaBuilder.like(handlingFeeEntity.get(OPERATING_CXR),
						OptionalUtil.getValue(operatingCxr) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								handlingFeeEntity.get(EFFECTIVE_FROM_DATE), handlingFeeEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								handlingFeeEntity.get(EFFECTIVE_FROM_DATE), handlingFeeEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(handlingFeeEntity.get(EFFECTIVE_FROM_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate)),
						criteriaBuilder.between(handlingFeeEntity.get(EFFECTIVE_TO_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate))));

			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							handlingFeeEntity.get(EFFECTIVE_FROM_DATE), handlingFeeEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							handlingFeeEntity.get(EFFECTIVE_FROM_DATE), handlingFeeEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			orderByValidation(handlingFeeEntity, criteriaQuery, criteriaBuilder, ISSUE_CXR, OPERATING_CXR,
					EFFECTIVE_FROM_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));

		};
	}

	private static void orderByValidation(Root<HandlingFeeEntity> handlingFeeEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String issueCxr, String operatingCxr, String effectiveFromDate) {
		criteriaQuery.orderBy(criteriaBuilder.asc(handlingFeeEntity.get(issueCxr)),
				criteriaBuilder.asc(handlingFeeEntity.get(operatingCxr)),
				criteriaBuilder.desc(handlingFeeEntity.get(effectiveFromDate)));
	}

	public static Specification<HandlingFeeEntity> equalsClientId(String clientId) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(handlingFeeEntity.get("clientId"), clientId);
	}

	public static Specification<HandlingFeeEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), handlingFeeEntity.get(EFFECTIVE_FROM_DATE),
				handlingFeeEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<HandlingFeeEntity> greaterThanOrEqualTo(LocalDate effectiveFromDate) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(handlingFeeEntity.get(EFFECTIVE_FROM_DATE), effectiveFromDate);
	}

	public static Specification<HandlingFeeEntity> lessThanOrEqualTo(LocalDate effectiveToDate) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(handlingFeeEntity.get(EFFECTIVE_TO_DATE), effectiveToDate);
	}

	public static Specification<HandlingFeeEntity> equalsSalesSource(String salesSource) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(handlingFeeEntity.get("salesSource"), salesSource);
	}

	public static Specification<HandlingFeeEntity> equalsIssueCxr(String issueCxr) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(handlingFeeEntity.get(ISSUE_CXR), issueCxr);
	}

	public static Specification<HandlingFeeEntity> equalsOperatingCxr(String operatingCxr) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(handlingFeeEntity.get(OPERATING_CXR), operatingCxr);
	}

	public static Specification<HandlingFeeEntity> equalsCouponFromArea(String couponFromArea) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(handlingFeeEntity.get("couponFromArea"), couponFromArea);
	}

	public static Specification<HandlingFeeEntity> equalsCouponToArea(String couponToArea) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(handlingFeeEntity.get("couponToArea"), couponToArea);
	}

	public static Specification<HandlingFeeEntity> notEqualsHandlingFeeId(Integer handlingFeeId) {
		return (handlingFeeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(handlingFeeEntity.get("handlingFeeId"), handlingFeeId);
	}
}
