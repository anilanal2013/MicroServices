package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.CreditCardEntity;
import com.sgl.smartpra.master.model.CreditCard;

public class CreditCardEntitySpecification {

	public static Specification<CreditCardEntity> search(CreditCard creditCard, Optional<String> exceptionCall) {
		return (creditCardEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(creditCard.getClientId())) {
				predicates.add(criteriaBuilder.equal(creditCardEntity.get("clientId"),
						OptionalUtil.getValue(creditCard.getClientId())));
			}
			if (OptionalUtil.isPresent(creditCard.getCcCompanyCode())) {
				predicates.add(criteriaBuilder.like(creditCardEntity.get("ccCompanyCode"),
						OptionalUtil.getValue(creditCard.getCcCompanyCode()) + "%"));
			}
			if (OptionalUtil.isPresent(creditCard.getCcCompanyName())) {
				predicates.add(criteriaBuilder.like(creditCardEntity.get("ccCompanyName"),
						OptionalUtil.getValue(creditCard.getCcCompanyName()) + "%"));
			}
			if (OptionalUtil.isPresent(creditCard.getLocallyInvoiced())) {
				predicates.add(criteriaBuilder.equal(creditCardEntity.get("locallyInvoiced"),
						OptionalUtil.getValue(creditCard.getLocallyInvoiced())));
			}
			if (OptionalUtil.isPresent(creditCard.getUatpFlag())) {
				predicates
						.add(criteriaBuilder.equal(creditCardEntity.get("uatpFlag"), 
								OptionalUtil.getValue(creditCard.getUatpFlag())));
			}
			if (OptionalUtil.isPresent(creditCard.getUatpAirlineCode())) {
				predicates.add(criteriaBuilder.like(creditCardEntity.get("uatpAirlineCode"),
						OptionalUtil.getValue(creditCard.getUatpAirlineCode()) + "%"));
			}
			if(!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (OptionalUtil.isPresent(creditCard.getActivate())) {
					predicates
							.add(criteriaBuilder.equal(creditCardEntity.get("activate"), OptionalUtil.getValue(creditCard.getActivate())));
				}
				if (!OptionalUtil.isPresent(creditCard.getActivate())) {
					predicates.add(criteriaBuilder.equal(creditCardEntity.get("activate"), true));
				}
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<CreditCardEntity> equalsClientId(String clientId) {
		return (creditCardEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(creditCardEntity.get("clientId"), clientId);
	}

	public static Specification<CreditCardEntity> equalsCcCompanyCode(String ccCompanyCode) {
		return (creditCardEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(creditCardEntity.get("ccCompanyCode"), ccCompanyCode);
	}

	public static Specification<CreditCardEntity> equalsUatpAirlineCode(String uatpAirlineCode) {
		return (creditCardEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(creditCardEntity.get("uatpAirlineCode"), uatpAirlineCode);
	}

	public static Specification<CreditCardEntity> isActive() {
		return (creditCardEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(creditCardEntity.get("activate"), true);
	}

	public static Specification<CreditCardEntity> notEqualsCreditCardId(Integer creditCardId) {
		return (creditCardEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(creditCardEntity.get("creditCardId"), creditCardId);
	}

}
