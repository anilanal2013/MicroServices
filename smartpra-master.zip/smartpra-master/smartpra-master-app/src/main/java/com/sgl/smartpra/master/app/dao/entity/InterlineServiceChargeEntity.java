package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_isc")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class InterlineServiceChargeEntity extends BaseEntity {
	@Id
	@Column(name = "isc_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer iscId;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;

	@Column(name = "document_type", nullable = false, length = 1)
	private String documentType;

	@Column(name = "settlement_indicator", nullable = false, length = 1)
	private String settlementIndicator;

	@Column(name = "isc_record_type", nullable = false, length = 1)
	private String iscRecordType;

	@Column(name = "issue_cxr", length = 3)
	private String issueCxr;

	@Column(name = "billing_cxr", length = 3)
	private String billingCxr;

	@Column(name = "sales_source", nullable = false, length = 4)
	private String salesSource;

	@Column(name = "point_of_sale", nullable = false, length = 4)
	private String pointOfSale;

	@Column(name = "travel_fbwt_indicator", length = 1)
	private String travelFBWTIndicator;

	@Column(name = "travel_from_area", length = 4)
	private String travelFromArea;

	@Column(name = "travel_to_area", length = 4)
	private String travelToArea;

	@Column(name = "coupon_from_area", length = 4)
	private String couponFromArea;

	@Column(name = "coupon_to_area", length = 4)
	private String couponToArea;

	@Column(name = "flight_range_id", length = 8)
	private String flightRangeId;

	@Column(name = "fb_group_code", length = 5)
	private String fbGroupCode;

	@Column(name = "isc_percentage")
	private Double iscPercentage;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@Column(name = "client_id", nullable = true, length = 3)
	private String clientId;

	@Column(name = "isc_currency")
	private String iscCurrency;

	@Column(name = "isc_amount")
	private Double iscAmount;

	private Integer priority;

	@Column(name = "rfic")
	private String rfic;

	@Column(name = "travel_via_area")
	private String travelViaArea;

}