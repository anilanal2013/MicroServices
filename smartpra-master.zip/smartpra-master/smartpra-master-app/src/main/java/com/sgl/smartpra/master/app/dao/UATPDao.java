package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.UATPEntity;

@Repository
public interface UATPDao {

	List<UATPEntity> getListOfUATP(Optional<String> clientId, Optional<String> uatpRecType, Optional<String> issueCxr,
			Optional<String> operatingCxr, Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	Optional<UATPEntity> findById(Integer uatpId);

	UATPEntity createUATP(UATPEntity uatpEntity);

	UATPEntity updateUATP(UATPEntity mapToEntity);

	long getOverLapForCreate(Optional<String> clientId, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> issueCxr, Optional<String> operatingCxr);

	long getOverLapForUpdate(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate, String issueCxr,
			String operatingCxr, Integer uatpId);

}
