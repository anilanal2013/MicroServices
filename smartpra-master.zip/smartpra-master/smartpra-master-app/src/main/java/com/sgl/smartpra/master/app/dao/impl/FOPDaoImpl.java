package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.FOPDao;
import com.sgl.smartpra.master.app.dao.entity.FOPEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.FOPEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.FOPRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FOPDaoImpl implements FOPDao {

	@Autowired
	private FOPRepository fopRepository;

	@Override
	@Cacheable(value = "fop", key = "#id")
	public Optional<FOPEntity> findById(Integer id) {
		log.info("Cacheable FOP Entity's ID= {}", id);
		return fopRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fop", key = "#fopEntity.fopId") })
	public FOPEntity create(FOPEntity fopEntity) {
		return fopRepository.save(fopEntity);
	}

	@Override
	@CachePut(value = "fop", key = "#fopEntity.fopId")
	public FOPEntity update(FOPEntity fopEntity) {
		return fopRepository.save(fopEntity);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fop", key = "#id") })
	public void delete(Integer id) {
		fopRepository.deleteById(id);
	}

	@Override
	public List<FOPEntity> findAll() {
		return fopRepository.findAll();
	}

	@Override
	public List<FOPEntity> search(Optional<String> fopCode, Optional<String> fopIdentifier,
			Optional<Boolean> activate) {
		return fopRepository.findAll(FOPEntitySpecification.search(fopCode,fopIdentifier, activate));
	}

	@Override
	public List<FOPEntity> searchByTransactionType(String fopIdentifier, String transactionType) {
		return fopRepository.findAll(FOPEntitySpecification.searchByTransactionType(fopIdentifier, transactionType));
	}

	@Override
	public List<FOPEntity> searchByFOPIdentifier(String fopIdentifier) {
		return fopRepository.findAll(FOPEntitySpecification.searchByFOPIdentifier(fopIdentifier));
	}

	@Override
	public long getOverLapRecordCount(String clientId, String fopCode, String fopIdentifier, String negativeFopFlag,
			String transactionType, String controlId, LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return fopRepository.count(Specification.where(
				FOPEntitySpecification.equalsClientId(clientId).and(FOPEntitySpecification.equalsFOPCode(fopCode))
						.and(FOPEntitySpecification.equalsFOPIdentifier(fopIdentifier))
						.and(FOPEntitySpecification.equalsNegativeFopFlag(negativeFopFlag))
						.and(FOPEntitySpecification.equalsTransactionType(transactionType))
						.and(FOPEntitySpecification.equalsControlId(controlId))
						.and(FOPEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate))
						.and(FOPEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(FOPEntitySpecification.isActive())));
	}

	@Override
	public long getOverLapRecordCount(String clientId, String fopCode, String fopIdentifier, String negativeFopFlag,
			String transactionType, String controlId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			Integer fopId) {
		return fopRepository.count(Specification.where(
				FOPEntitySpecification.equalsClientId(clientId).and(FOPEntitySpecification.equalsFOPCode(fopCode))
						.and(FOPEntitySpecification.equalsFOPIdentifier(fopIdentifier))
						.and(FOPEntitySpecification.equalsNegativeFopFlag(negativeFopFlag))
						.and(FOPEntitySpecification.equalsTransactionType(transactionType))
						.and(FOPEntitySpecification.equalsControlId(controlId))
						.and(FOPEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate))
						.and(FOPEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(FOPEntitySpecification.isActive()).and(FOPEntitySpecification.notEqualsfopId(fopId))));
	}
	@Override
	public List<String> getFOPIdentifierFromFOPMaster() {

		return fopRepository.getFOPIdentifierFromFOPmaster();
	}
}
