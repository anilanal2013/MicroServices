package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.repository.entity.InterfaceReferenceEntity;

public final class InterfaceReferenceEntitySpecification {
	public static final String EFFECTIVE_TO_DATE = "effectiveToDate";

	InterfaceReferenceEntitySpecification() {
	}

	public static void orderByEffectiveToDateByAsc(Root<InterfaceReferenceEntity> interfaceReferenceEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(interfaceReferenceEntity.get(orderByString)));
	}

	public static Specification<InterfaceReferenceEntity> search(Optional<String> clientId, Optional<String> dataSource,
			Optional<String> stationCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate, Optional<String> exceptionCall) {

		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(interfaceReferenceEntity.get("clientId"),
						OptionalUtil.getValue(clientId) ));
			}
			if (OptionalUtil.isPresent(dataSource)) {
				predicates.add(criteriaBuilder.like(interfaceReferenceEntity.get("dataSource"),
						OptionalUtil.getValue(dataSource) + "%"));
			}
			if (OptionalUtil.isPresent(stationCode)) {
				predicates.add(criteriaBuilder.like(interfaceReferenceEntity.get("stationCode"),
						OptionalUtil.getValue(stationCode) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								interfaceReferenceEntity.get("effectiveFromDate"),
								interfaceReferenceEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								interfaceReferenceEntity.get("effectiveFromDate"),
								interfaceReferenceEntity.get("effectiveToDate")),
						criteriaBuilder.between(interfaceReferenceEntity.get("effectiveFromDate"),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate)),
						criteriaBuilder.between(interfaceReferenceEntity.get("effectiveToDate"),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate))));

			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							interfaceReferenceEntity.get("effectiveFromDate"),
							interfaceReferenceEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							interfaceReferenceEntity.get("effectiveFromDate"),
							interfaceReferenceEntity.get("effectiveToDate")));
				}
			}
			if(!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (OptionalUtil.isPresent(activate)) {
					predicates.add(criteriaBuilder.equal(interfaceReferenceEntity.get("activate"),
							OptionalUtil.getValue(activate)));
				}
				if (!OptionalUtil.isPresent(activate)) {
					predicates.add(criteriaBuilder.equal(interfaceReferenceEntity.get("activate"), true));
				}
			}
			orderByEffectiveToDateByAsc(interfaceReferenceEntity, criteriaQuery, criteriaBuilder, EFFECTIVE_TO_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<InterfaceReferenceEntity> equalsClientId(String clientId) {
		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(interfaceReferenceEntity.get("clientId"), clientId);
	}

	public static Specification<InterfaceReferenceEntity> equalsDataSource(String dataSource) {
		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(interfaceReferenceEntity.get("dataSource"), dataSource);
	}

	public static Specification<InterfaceReferenceEntity> equalsStationCode(String stationCode) {
		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(interfaceReferenceEntity.get("stationCode"), stationCode);
	}

	public static Specification<InterfaceReferenceEntity> notEqualsInterfaceRefId(Integer interfaceRefId) {
		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(interfaceReferenceEntity.get("interfaceRefId"), interfaceRefId);
	}

	public static Specification<InterfaceReferenceEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), interfaceReferenceEntity.get("effectiveFromDate"),
				interfaceReferenceEntity.get("effectiveToDate"));
	}

	public static Specification<InterfaceReferenceEntity> greaterThanorEqualEffectiveFromDate(LocalDate effectiveDate) {
		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(interfaceReferenceEntity.get("effectiveFromDate"), effectiveDate);
	}

	public static Specification<InterfaceReferenceEntity> lessThanorEqualEffectiveToDate(LocalDate effectiveDate) {
		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(interfaceReferenceEntity.get("effectiveToDate"), effectiveDate);
	}

	public static Specification<InterfaceReferenceEntity> equalsActivate() {
		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(interfaceReferenceEntity.get("activate"), true);
	}

	public static Specification<InterfaceReferenceEntity> search(InterfaceReferenceEntity interfaceReferenceEntities) {
		return (interfaceReferenceEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (isEmptyOrNull(interfaceReferenceEntities.getDataSource())) {
				predicates.add(criteriaBuilder.like(interfaceReferenceEntity.get("dataSource"),
						interfaceReferenceEntities.getDataSource() + "%"));
			}
			if (isEmptyOrNull(interfaceReferenceEntities.getStationCode())) {
				predicates.add(criteriaBuilder.equal(interfaceReferenceEntity.get("stationCode"),
						interfaceReferenceEntities.getStationCode()));
			}
			if (interfaceReferenceEntities.getEffectiveFromDate() != null
					&& interfaceReferenceEntities.getEffectiveToDate() != null) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(interfaceReferenceEntities.getEffectiveFromDate()),
								interfaceReferenceEntity.get("effectiveFromDate"),
								interfaceReferenceEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(interfaceReferenceEntities.getEffectiveToDate()),
								interfaceReferenceEntity.get("effectiveFromDate"),
								interfaceReferenceEntity.get("effectiveToDate")),
						criteriaBuilder.between(interfaceReferenceEntity.get("effectiveFromDate"),
								interfaceReferenceEntities.getEffectiveFromDate(),
								interfaceReferenceEntities.getEffectiveToDate()),
						criteriaBuilder.between(interfaceReferenceEntity.get("effectiveToDate"),
								interfaceReferenceEntities.getEffectiveFromDate(),
								interfaceReferenceEntities.getEffectiveToDate())));
			} else {
				if (interfaceReferenceEntities.getEffectiveFromDate() != null) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(interfaceReferenceEntities.getEffectiveFromDate()),
							interfaceReferenceEntity.get("effectiveFromDate"),
							interfaceReferenceEntity.get("effectiveToDate")));
				}
				if (interfaceReferenceEntities.getEffectiveToDate() != null) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(interfaceReferenceEntities.getEffectiveToDate()),
							interfaceReferenceEntity.get("effectiveFromDate"),
							interfaceReferenceEntity.get("effectiveToDate")));
				}
			}
			if (interfaceReferenceEntities.getActivate() != null) {
				predicates.add(criteriaBuilder.equal(interfaceReferenceEntity.get("activate"),
						interfaceReferenceEntities.getActivate()));
			}
			if (interfaceReferenceEntities.getActivate() == null) {
				predicates.add(criteriaBuilder.equal(interfaceReferenceEntity.get("activate"), true));
			}
			orderByEffectiveToDateByAsc(interfaceReferenceEntity, criteriaQuery, criteriaBuilder, EFFECTIVE_TO_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	private static boolean isEmptyOrNull(String value) {
		return value != null && !value.isEmpty();
	}
}
