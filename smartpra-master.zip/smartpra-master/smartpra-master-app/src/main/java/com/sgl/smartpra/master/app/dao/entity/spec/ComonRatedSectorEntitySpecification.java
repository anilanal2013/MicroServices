package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.repository.entity.CommonRatedSectorEntity;

public class ComonRatedSectorEntitySpecification {

	private static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";
	private static final String EFFECTIVE_TO_DATE = "effectiveToDate";
	private static final String CLIENT_ID = "clientId";
	private static final String FROM_AIRPORT = "fromAirport";
	private static final String TO_AIRPORT = "toAirport";
	private static final String COMMON_RATED_FROM_AIRPORT = "commonRatedFromAirport";
	private static final String COMMON_RATED_TO_AIRPORT = "commonRatedToAirport";

	public static Specification<CommonRatedSectorEntity> search(Optional<String> clientId, Optional<String> fromAirport,
			Optional<String> toAirport, Optional<String> commonRatedFromAirport,
			Optional<String> commonRatedToAirport) {

		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId) && OptionalUtil.getValue(clientId) != null
					&& !OptionalUtil.getValue(clientId).isEmpty()) {
				predicates.add(
						criteriaBuilder.equal(commonRatedSectorEntity.get(CLIENT_ID), OptionalUtil.getValue(clientId)));

			}

			if (OptionalUtil.isPresent(fromAirport) && OptionalUtil.getValue(fromAirport) != null
					&& !OptionalUtil.getValue(fromAirport).isEmpty()) {
				predicates.add(criteriaBuilder.equal(commonRatedSectorEntity.get(FROM_AIRPORT),
						OptionalUtil.getValue(fromAirport)));
			}

			if (OptionalUtil.isPresent(toAirport) && OptionalUtil.getValue(toAirport) != null
					&& !OptionalUtil.getValue(toAirport).isEmpty()) {
				predicates.add(criteriaBuilder.equal(commonRatedSectorEntity.get(TO_AIRPORT),
						OptionalUtil.getValue(toAirport)));
			}

			if (OptionalUtil.isPresent(commonRatedFromAirport) && OptionalUtil.getValue(commonRatedFromAirport) != null
					&& !OptionalUtil.getValue(commonRatedFromAirport).isEmpty()) {
				predicates.add(criteriaBuilder.equal(commonRatedSectorEntity.get(COMMON_RATED_FROM_AIRPORT),
						OptionalUtil.getValue(commonRatedFromAirport)));
			}

			if (OptionalUtil.isPresent(commonRatedToAirport) && OptionalUtil.getValue(commonRatedToAirport) != null
					&& !OptionalUtil.getValue(commonRatedToAirport).isEmpty()) {
				predicates.add(criteriaBuilder.equal(commonRatedSectorEntity.get(COMMON_RATED_TO_AIRPORT),
						OptionalUtil.getValue(commonRatedToAirport)));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<CommonRatedSectorEntity> equalsClientId(String clientId) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(commonRatedSectorEntity.get(CLIENT_ID), clientId);
	}

	public static Specification<CommonRatedSectorEntity> equalsFromAirport(String fromAirport) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(commonRatedSectorEntity.get(FROM_AIRPORT), fromAirport);
	}

	public static Specification<CommonRatedSectorEntity> equalsToAirport(String toAirport) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(commonRatedSectorEntity.get(TO_AIRPORT), toAirport);
	}

	public static Specification<CommonRatedSectorEntity> equalsCommonRatedToAirport(String commonRatedToAirport) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(commonRatedSectorEntity.get(COMMON_RATED_TO_AIRPORT), commonRatedToAirport);
	}

	public static Specification<CommonRatedSectorEntity> equalsCommonRatedFromAirport(String commonRatedFromAirport) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(commonRatedSectorEntity.get(COMMON_RATED_FROM_AIRPORT), commonRatedFromAirport);
	}

	public static Specification<CommonRatedSectorEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), commonRatedSectorEntity.get(EFFECTIVE_FROM_DATE),
				commonRatedSectorEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<CommonRatedSectorEntity> greaterThanOrEqualTo(LocalDate effectiveFromDate) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(commonRatedSectorEntity.get(EFFECTIVE_FROM_DATE), effectiveFromDate);
	}

	public static Specification<CommonRatedSectorEntity> lessThanOrEqualTo(LocalDate effectiveToDate) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(commonRatedSectorEntity.get(EFFECTIVE_TO_DATE), effectiveToDate);
	}

	public static Specification<CommonRatedSectorEntity> notEqualsCommonRatedId(Integer commonRatedID) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(commonRatedSectorEntity.get("commonRatedID"), commonRatedID);
	}

	public static void orderByEffectiveToDateByAsc(Root<CommonRatedSectorEntity> commonRatedSectorEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String effectiveToDate) {
		criteriaQuery.orderBy(criteriaBuilder.asc(commonRatedSectorEntity.get(effectiveToDate)));
	}

	public static Specification<CommonRatedSectorEntity> search(Optional<String> fromAirport,
			Optional<String> toAirport, Optional<String> commonRatedFromAirport, Optional<String> commonRatedToAirport,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return (commonRatedSectorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(fromAirport) && OptionalUtil.getValue(fromAirport) != null
					&& !OptionalUtil.getValue(fromAirport).isEmpty()) {
				predicates.add(criteriaBuilder.equal(commonRatedSectorEntity.get(FROM_AIRPORT),
						OptionalUtil.getValue(fromAirport)));
			}

			if (OptionalUtil.isPresent(toAirport) && OptionalUtil.getValue(toAirport) != null
					&& !OptionalUtil.getValue(toAirport).isEmpty()) {
				predicates.add(criteriaBuilder.equal(commonRatedSectorEntity.get(TO_AIRPORT),
						OptionalUtil.getValue(toAirport)));
			}

			if (OptionalUtil.isPresent(commonRatedFromAirport) && OptionalUtil.getValue(commonRatedFromAirport) != null
					&& !OptionalUtil.getValue(commonRatedFromAirport).isEmpty()) {
				predicates.add(criteriaBuilder.equal(commonRatedSectorEntity.get(COMMON_RATED_FROM_AIRPORT),
						OptionalUtil.getValue(commonRatedFromAirport)));
			}

			if (OptionalUtil.isPresent(commonRatedToAirport) && OptionalUtil.getValue(commonRatedToAirport) != null
					&& !OptionalUtil.getValue(commonRatedToAirport).isEmpty()) {
				predicates.add(criteriaBuilder.equal(commonRatedSectorEntity.get(COMMON_RATED_TO_AIRPORT),
						OptionalUtil.getValue(commonRatedToAirport)));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								commonRatedSectorEntity.get(EFFECTIVE_FROM_DATE),
								commonRatedSectorEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								commonRatedSectorEntity.get(EFFECTIVE_FROM_DATE),
								commonRatedSectorEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(commonRatedSectorEntity.get(EFFECTIVE_FROM_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate)),
						criteriaBuilder.between(commonRatedSectorEntity.get(EFFECTIVE_TO_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate))));

			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							commonRatedSectorEntity.get(EFFECTIVE_FROM_DATE),
							commonRatedSectorEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							commonRatedSectorEntity.get(EFFECTIVE_FROM_DATE),
							commonRatedSectorEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			orderByEffectiveToDateByAsc(commonRatedSectorEntity, criteriaQuery, criteriaBuilder, EFFECTIVE_TO_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
}
