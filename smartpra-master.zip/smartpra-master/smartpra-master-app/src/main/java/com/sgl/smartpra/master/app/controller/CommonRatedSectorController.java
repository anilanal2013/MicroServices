package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.model.CommonRatedSector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.sgl.smartpra.master.app.service.CommonRatedSectorService;

@RestController
public class CommonRatedSectorController {
	@Autowired
	CommonRatedSectorService commonRatedSectorService;

	@GetMapping("/common-rated-sectors")
	public List<CommonRatedSector> getCommonRatedSectors(
			@RequestParam(value = "clientId", required = false) Optional<String> clientId,
			@RequestParam(value = "fromAirport", required = false) Optional<String> fromAirport,
			@RequestParam(value = "toAirport", required = false) Optional<String> toAirport,
			@RequestParam(value = "commonRatedFromAirport", required = false) Optional<String> commonRatedFromAirport,
			@RequestParam(value = "commonRatedToAirport", required = false) Optional<String> commonRatedToAirport) {
		return commonRatedSectorService.getAllCommonRatedSector(clientId, fromAirport, toAirport,
				commonRatedFromAirport, commonRatedToAirport);
	}

	@GetMapping("/common-rated-sectors/search/clientId/{clientId}")
	public List<CommonRatedSector> getAllCommonRatedSectors(@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "fromAirport", required = false) Optional<String> fromAirport,
			@RequestParam(value = "toAirport", required = false) Optional<String> toAirport,
			@RequestParam(value = "commonRatedFromAirport", required = false) Optional<String> commonRatedFromAirport,
			@RequestParam(value = "commonRatedToAirport", required = false) Optional<String> commonRatedToAirport) {
		return commonRatedSectorService.getAllCommonRatedSector(clientId, fromAirport, toAirport,
				commonRatedFromAirport, commonRatedToAirport);
	}

	@GetMapping("/common-rated-sectors/list")
	public List<CommonRatedSector> getAllCommonRatedSectors(
			@RequestParam(value = "fromAirport", required = false) Optional<String> fromAirport,
			@RequestParam(value = "toAirport", required = false) Optional<String> toAirport,
			@RequestParam(value = "commonRatedFromAirport", required = false) Optional<String> commonRatedFromAirport,
			@RequestParam(value = "commonRatedToAirport", required = false) Optional<String> commonRatedToAirport,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {

		return commonRatedSectorService.getAllCommonRatedSectors(fromAirport, toAirport, commonRatedFromAirport,
				commonRatedToAirport, effectiveFromDate, effectiveToDate);
	}

	@GetMapping(value = "/common-rated-sectors/{commonRatedID}")
	public CommonRatedSector findCommonRatedSectorByCommonRatedSectorId(
			@PathVariable("commonRatedID") Integer commonRatedID) {

		return commonRatedSectorService.findCommonRatedSectorByCommonRatedSectorId(commonRatedID);
	}

	@PostMapping(value = "/common-rated-sectors")
	public CommonRatedSector createCommonRateSectors(
			@Validated(Create.class) @RequestBody CommonRatedSector commonRatedSector) {
		return commonRatedSectorService.createCommonRateSectors(commonRatedSector);
	}

	@PutMapping(value = "/common-rated-sectors/{commonRatedID}")
	public CommonRatedSector updateCommonRateSectors(@PathVariable("commonRatedID") Integer commonRatedID,
			@Validated(Update.class) @RequestBody CommonRatedSector commonRatedSector) {

		return commonRatedSectorService.updateCommonRateSectors(commonRatedID, commonRatedSector);
	}

}
