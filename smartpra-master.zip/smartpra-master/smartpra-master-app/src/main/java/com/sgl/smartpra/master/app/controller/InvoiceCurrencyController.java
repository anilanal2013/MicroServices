package com.sgl.smartpra.master.app.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.master.app.configuration.InvoiceCurrencyConfig.InvoiceCurrency;
import com.sgl.smartpra.master.app.service.InvoiceCurrencyService;
@RestController
public class InvoiceCurrencyController {
	@Autowired
	InvoiceCurrencyService invoiceCurrencyService;
	
	@GetMapping("/currency-of-clearence/{hostCarrierNumericCode}/{billingCarrierNumericCode}")
	public InvoiceCurrency getCurrencyOfClearence(
			@PathVariable(value = "hostCarrierNumericCode") Optional<String> hostCarrierNumericCode,
			@PathVariable(value = "billingCarrierNumericCode") Optional<String> billingCarrierNumericCode,
			@RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {

	
		return invoiceCurrencyService.getCurrencyOfClearence(hostCarrierNumericCode,billingCarrierNumericCode,
				effectiveDate);
	}
	
	@GetMapping("/currency-of-clearence/{hostCarrierNumericCode}/{billingCarrierNumericCode}/validate/{currency}")
	public boolean validateCurrencyOfClearence(
			@PathVariable(value = "hostCarrierNumericCode") Optional<String> hostCarrierNumericCode,
			@PathVariable(value = "billingCarrierNumericCode") Optional<String> billingCarrierNumericCode,
			@PathVariable(value = "currency") Optional<String> currency,
			@RequestParam(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {

	
		return invoiceCurrencyService.validateCurrencyOfClearence(hostCarrierNumericCode,billingCarrierNumericCode,
				effectiveDate,currency);
	}
}
