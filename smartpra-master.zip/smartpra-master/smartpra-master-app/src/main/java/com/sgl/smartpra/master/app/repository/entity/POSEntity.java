package com.sgl.smartpra.master.app.repository.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_pos")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class POSEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pos_id")
	private Integer posId;

	@Column(name = "pos_code", nullable = false, length = 3)
	private String posCode;

	@Column(name = "pos_name", nullable = false, length = 25)
	private String posName;

	@Column(name = "account_code", nullable = false, length = 8)
	private String accountCode;

	@Column(name = "cost_center", nullable = false, length = 8)
	private String costCenter;

	@Column(name = "profit_center", nullable = false, length = 8)
	private String profitCenter;

	@Column(name = "channel", nullable = false, length = 8)
	private String channel;

	@Column(name = "client_id", nullable = false, length = 2)
	private String clientId;

	private LocalDate effectiveFromDate;

	private LocalDate effectiveToDate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
