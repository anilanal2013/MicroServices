package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.exception.ServiceException;
import com.sgl.smartpra.master.app.service.FormCodeService;
import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.master.model.FormCodeResponse;

@RestController
public class FormCodeController {

	@Autowired
	FormCodeService formCodeService;

	public static final String CHECKUNIQUE = "Record already exists";

	@GetMapping("/form-code/clientid/{clientId}")
	public List<FormCode> getAllFormCode(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "formCode", required = false) Optional<String> formCode,
			@RequestParam(value = "documentType", required = false) Optional<String> documentType,
			@RequestParam(value = "numberOfCoupon", required = false) Optional<String> numberOfCoupon,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {
		return formCodeService.getListOfFormCode(clientId,formCode, documentType, numberOfCoupon, effectiveFromDate,
				effectiveToDate, activate,exceptionCall);
	}
	
	@GetMapping("/form-code")
	public List<FormCode> getAllFormCode(@RequestParam(value = "formCode", required = false) Optional<String> formCode,
			@RequestParam(value = "documentType", required = false) Optional<String> documentType,
			@RequestParam(value = "numberOfCoupon", required = false) Optional<String> numberOfCoupon,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return formCodeService.getListOfFormCode(formCode, documentType, numberOfCoupon, effectiveFromDate,
				effectiveToDate, activate);
	}

	@GetMapping("/form-code/list/{clientId}")
	public FormCodeResponse getAllFormCode(Pageable pageable,
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "formCode", required = false) Optional<String> formCode,
			@RequestParam(value = "documentType", required = false) Optional<String> documentType,
			@RequestParam(value = "numberOfCoupon", required = false) Optional<String> numberOfCoupon,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Boolean activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {

		FormCode formCodeModel = new FormCode();
		formCodeModel.setClientId(clientId);
		formCodeModel.setFormCode(formCode);
		formCodeModel.setDocumentType(documentType);
		formCodeModel.setNumberOfCoupon(numberOfCoupon);
		formCodeModel.setActivate(activate);
		if (OptionalUtil.isPresent(effectiveFromDate)) {
			formCodeModel.setEffectiveFromDate(effectiveFromDate);
		}
		if (OptionalUtil.isPresent(effectiveToDate)) {
			formCodeModel.setEffectiveToDate(effectiveToDate);
		}
		return formCodeService.getListOfFormCode(formCodeModel, exceptionCall, pageable);
	}

	@GetMapping("/form-code/{formCodeId}")
	public FormCode getFormCodeByfromCodeId(@PathVariable(value = "formCodeId") Integer formCodeId) {
		return formCodeService.getFormCodeByformCodeId(formCodeId);
	}
	
	@GetMapping("/form-code/formcode-date-search")
	public FormCode getFormCodeByfromCodeAndEffectiveDate(
			@RequestParam(value = "formCode", required = true) Optional<String> formCode,
			@RequestParam(value = "effectiveDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return formCodeService.getFormCodeByfromCodeAndEffectiveDate(Optional.of("QR"),formCode,effectiveDate);
	}
	
	@GetMapping("/form-code/formcode-date-search/{clientId}")
	public FormCode getFormCodeByfromCodeAndEffectiveDate(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "formCode", required = true) Optional<String> formCode,
			@RequestParam(value = "effectiveDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return formCodeService.getFormCodeByfromCodeAndEffectiveDate(clientId,formCode,effectiveDate);
	}

	@PostMapping("/form-code")
	public FormCode createFormCode(@Validated(Create.class) @RequestBody FormCode formCode) {
		return formCodeService.createFormCode(formCode);
	}

	@PutMapping("/form-code/{formCodeId}")
	public FormCode updateFormCode(@PathVariable(value = "formCodeId") Integer formCodeId,
			@Validated(Update.class) @RequestBody FormCode formCode) {
		try {
			formCode = formCodeService.updateFormCode(formCodeId, formCode);
		} catch (DataIntegrityViolationException e) {
			throw new ServiceException(CHECKUNIQUE);
		}
		return formCode;
	}

	@PutMapping("/form-code/{formCodeId}/deactivate")
	public void deactivateFormCode(@Valid @PathVariable(value = "formCodeId") Integer formCodeId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		formCodeService.deactivateFormCode(formCodeId, lastUpdatedBy);
	}

	@PutMapping("/form-code/{formCodeId}/activate")
	public void activateFormCode(@Valid @PathVariable(value = "formCodeId") Integer formCodeId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		formCodeService.activateFormCode(formCodeId, lastUpdatedBy);
	}

}
