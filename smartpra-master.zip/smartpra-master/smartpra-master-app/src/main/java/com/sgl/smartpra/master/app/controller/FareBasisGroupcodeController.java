package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.FareBasisGroupcodeService;
import com.sgl.smartpra.master.model.FareBasisGroupcode;

@RestController
@RequestMapping("/farebasis-groupcode")
public class FareBasisGroupcodeController {

	@Autowired
	private FareBasisGroupcodeService fareBasisGroupcodeService;

	@PostMapping
	@ResponseStatus(value = HttpStatus.CREATED)
	public FareBasisGroupcode createFareBasisGroupcode(
			@Validated(Create.class) @RequestBody FareBasisGroupcode fareBasisGroupcode) {
		return fareBasisGroupcodeService.createFareBasisGroupcode(fareBasisGroupcode);
	}

	@PutMapping("/{fbGroupId}")
	@ResponseStatus(value = HttpStatus.OK)
	public FareBasisGroupcode updateFareBasisGroupcode(@PathVariable(value = "fbGroupId") Integer fbGroupId,
			@Validated(Update.class) @RequestBody FareBasisGroupcode fareBasisGroupcode) {
		fareBasisGroupcode.setFbGroupId(fbGroupId);
		return fareBasisGroupcodeService.updateFareBasisGroupcode(fbGroupId, fareBasisGroupcode);
	}
	
	@GetMapping("/search")
	public List<FareBasisGroupcode> search(
			@RequestParam(value = "fbGroupCode", required=false) Optional<String> fbGroupCode,
			@RequestParam(value = "fbDescription", required=false) Optional<String> fbDescription,
			@RequestParam(value = "isActive", required=false) Optional<Boolean> isActive) {
		return fareBasisGroupcodeService.search(fbGroupCode,fbDescription,isActive);
	}
	
	@GetMapping("/fareBasisGroupcodePatternRecords")
	public List<FareBasisGroupcode> getFareBasisGroupcodePattern() {
		return fareBasisGroupcodeService.getfareBasisGroupcodeIsPattern();
	}

	@GetMapping
	public List<FareBasisGroupcode> getFareBasisGroupcode(
			@RequestParam(value = "isPattern", required = false) Optional<Boolean> isPattern,
			@RequestParam(value = "nonRevenueFlag", required = false) Optional<Boolean> nonRevenueFlag,
			@RequestParam(value = "unpublishFlag", required = false) Optional<Boolean> unpublishFlag,
			@RequestParam(value = "atpcoFareType", required = false) Optional<String> atpcoFareType,
			@RequestParam(value = "btItIndicator", required = false) Optional<String> btItIndicator,
			@RequestParam(value = "cabin", required = false) Optional<String> cabin,
			@RequestParam(value = "dayOfWeek", required = false) Optional<String> dayOfWeek,
			@RequestParam(value = "discountCode", required = false) Optional<String> discountCode,
			@RequestParam(value = "fareOwnerCXR", required = false) Optional<String> fareOwnerCXR,
			@RequestParam(value = "fareText", required = false) Optional<String> fareText,
			@RequestParam(value = "iataFareType", required = false) Optional<String> iataFareType,
			@RequestParam(value = "issueCXR", required = false) Optional<String> issueCXR,
			@RequestParam(value = "journeyType", required = false) Optional<String> journeyType,
			@RequestParam(value = "normalSpecial", required = false) Optional<String> normalSpecial,
			@RequestParam(value = "passengerName", required = false) Optional<String> passengerName,
			@RequestParam(value = "paxType", required = false) Optional<String> paxType,
			@RequestParam(value = "seasonalCode", required = false) Optional<String> seasonalCode,
			@RequestParam(value = "ticketedFareBasis", required = false) Optional<String> ticketedFareBasis,
			@RequestParam(value = "ticketedTD", required = false) Optional<String> ticketedTD,
			@RequestParam(value = "zedIdentifier", required = false) Optional<String> zedIdentifier,
			@RequestParam(value = "isActive", required = false) Boolean isActive) {
		return fareBasisGroupcodeService.getFareBasisGroupcode(isPattern, nonRevenueFlag, unpublishFlag, atpcoFareType,
				btItIndicator, cabin, dayOfWeek, discountCode, fareOwnerCXR, fareText,
				iataFareType, issueCXR, journeyType, normalSpecial, passengerName, paxType, seasonalCode,
				ticketedFareBasis, ticketedTD, zedIdentifier,isActive);
	}

	//newly added for proration along with clientId
	@GetMapping("/client")
	public List<FareBasisGroupcode> getFareBasisGroupcodeSpecificClientId(
			@RequestParam(value = "isPattern", required = false) Optional<Boolean> isPattern,
			@RequestParam(value = "nonRevenueFlag", required = false) Optional<Boolean> nonRevenueFlag,
			@RequestParam(value = "unpublishFlag", required = false) Optional<Boolean> unpublishFlag,
			@RequestParam(value = "atpcoFareType", required = false) Optional<String> atpcoFareType,
			@RequestParam(value = "btItIndicator", required = false) Optional<String> btItIndicator,
			@RequestParam(value = "cabin", required = false) Optional<String> cabin,
			@RequestParam(value = "dayOfWeek", required = false) Optional<String> dayOfWeek,
			@RequestParam(value = "discountCode", required = false) Optional<String> discountCode,
			@RequestParam(value = "fareOwnerCXR", required = false) Optional<String> fareOwnerCXR,
			@RequestParam(value = "fareText", required = false) Optional<String> fareText,
			@RequestParam(value = "iataFareType", required = false) Optional<String> iataFareType,
			@RequestParam(value = "issueCXR", required = false) Optional<String> issueCXR,
			@RequestParam(value = "journeyType", required = false) Optional<String> journeyType,
			@RequestParam(value = "normalSpecial", required = false) Optional<String> normalSpecial,
			@RequestParam(value = "passengerName", required = false) Optional<String> passengerName,
			@RequestParam(value = "paxType", required = false) Optional<String> paxType,
			@RequestParam(value = "seasonalCode", required = false) Optional<String> seasonalCode,
			@RequestParam(value = "ticketedFareBasis", required = false) Optional<String> ticketedFareBasis,
			@RequestParam(value = "ticketedTD", required = false) Optional<String> ticketedTD,
			@RequestParam(value = "zedIdentifier", required = false) Optional<String> zedIdentifier,
			@RequestParam(value = "clientId", required = false) Optional<String> clientId,
			@RequestParam(value = "isActive", required = false) Boolean isActive) {
		return fareBasisGroupcodeService.getFareBasisGroupcodeSpecificClientId(isPattern, nonRevenueFlag, unpublishFlag, atpcoFareType,
				btItIndicator, cabin, dayOfWeek, discountCode, fareOwnerCXR, fareText,
				iataFareType, issueCXR, journeyType, normalSpecial, passengerName, paxType, seasonalCode,
				ticketedFareBasis, ticketedTD, zedIdentifier,clientId,isActive);
	}
	
	// it will return based on fb_group_code
	@GetMapping("/{fbGroupCode}")
	public List<FareBasisGroupcode> getFareBasisGroupcodeByGroupCode(
			@PathVariable(value = "fbGroupCode") String fbGroupCode) {
		return fareBasisGroupcodeService.getFareBasisGroupcodeByGroupCode(fbGroupCode);
	}

	// it will return all records which are active
	@GetMapping("/fb-groupcode")
	public List<FareBasisGroupcode> getAllFareBasisGroupcode() {
		return fareBasisGroupcodeService.getAllFareBasisGroupcode();
	}
	
	@GetMapping("/fb-groupcode/{fbGroupId}")
	public FareBasisGroupcode getFBGroupCodeByFBGroupId(@PathVariable(value = "fbGroupId") Integer fbGroupId) {
		return fareBasisGroupcodeService.getfareBasisGroupcodeByFBGroupId(fbGroupId);
	}

	@PutMapping("/{fbGroupId}/deactivate")
	public void deactivateBookingClassMaster(@Valid @PathVariable(value = "fbGroupId") Integer fbGroupId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		FareBasisGroupcode fareBasisGroupcode = new FareBasisGroupcode();
		fareBasisGroupcode.setFbGroupId(fbGroupId);
		fareBasisGroupcode.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		fareBasisGroupcodeService.deactivateFareBasisGroupcode(fareBasisGroupcode);
	}

	@PutMapping("/{fbGroupId}/activate")
	public void activateBookingClassMaster(@Valid @PathVariable(value = "fbGroupId") Integer fbGroupId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		FareBasisGroupcode fareBasisGroupcode = new FareBasisGroupcode();
		fareBasisGroupcode.setFbGroupId(fbGroupId);
		fareBasisGroupcode.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		fareBasisGroupcodeService.activateFareBasisGroupcode(fareBasisGroupcode);
	}

}