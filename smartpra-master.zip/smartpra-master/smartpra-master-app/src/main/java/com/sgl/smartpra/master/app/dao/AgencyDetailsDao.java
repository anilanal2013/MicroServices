package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.AgencyDetailsEntity;

@Repository
public interface AgencyDetailsDao {

	public AgencyDetailsEntity create(AgencyDetailsEntity agencyDetailsEntity);

	public Optional<AgencyDetailsEntity> findById(Integer id);

	public AgencyDetailsEntity update(AgencyDetailsEntity mapToEntity);

	public List<AgencyDetailsEntity> findAll(Optional<String> agencyCode, Optional<String> clientId,
			Optional<String> transactionType, Optional<String> reportingFrequency, Optional<String> transactionCurrency,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate);
	
	public List<AgencyDetailsEntity> findByAgencyId(Integer agencyId,Optional<String> agencyCode, Optional<String> clientId,
			Optional<String> transactionType, Optional<String> reportingFrequency, Optional<String> transactionCurrency,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate,Optional<String> exceptionCall);

	List<AgencyDetailsEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	// -- This is for Create- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String agencyCode, Optional<String> transactionType, Optional<String> transactionCurrency,
			Optional<String> reportingFrequency);

	// -- This is for Update- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String transactionCurrency, String transactionType, String agencyCode, String reportingFrequency,
			Integer agencyDetailsId);

	public List<AgencyDetailsEntity> searchAgencyDetailsByAgencyCode(Optional<String> clientId,
			Optional<String> agencyCode, Optional<String> effectiveDate);
}
