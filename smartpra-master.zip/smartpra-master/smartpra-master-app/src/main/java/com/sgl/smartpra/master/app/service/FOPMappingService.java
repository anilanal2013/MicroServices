package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.FOPMapping;

public interface FOPMappingService {

	public FOPMapping createFOPMapping(FOPMapping fopMapping);

	public FOPMapping updateFOPMapping(FOPMapping fopMapping);

	public List<FOPMapping> search(Optional<String> stationCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> source, Optional<String> fopCode);

	public FOPMapping getFOPMappingByFOPMapId(Integer fopMapId);

	public void deactivateFOPMapping(FOPMapping fopMapping);

	public void activateFOPMapping(FOPMapping fopMapping);

}
