package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.AccountDao;
import com.sgl.smartpra.master.app.dao.entity.AccountEntity;
import com.sgl.smartpra.master.app.mapper.AccountMapper;
import com.sgl.smartpra.master.app.service.AccountService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.AccountModel;
import com.sgl.smartpra.master.model.FOP;
import com.sgl.smartpra.master.model.ListOfValues;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao accountDao;

	@Autowired
	private AccountMapper accountMapper;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private ListOfValuesService listOfValuesService;

	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	private static final String ACCOUNT_TYPE = LOVEnum.ACCOUNT_TYPE.getLOVEnum();
	private static final String RECORD_EXISTS = "Record already exists";
	private static final String PATTERN = "^[a-zA-Z]*$";

	@Override
	public AccountModel createAccount(AccountModel accountModel) {
		validateBusinessConstrainsForCreate(accountModel);
		return accountMapper.mapToModel(accountDao.createAccount(accountMapper.mapToEntity(accountModel)));
	}

	@Override
	public AccountModel updateAccount(Integer accountAlphaCodeId, AccountModel accountModel) {
		AccountEntity accountEntity = accountDao.findById(accountAlphaCodeId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountAlphaCodeId)));
		validateBusinessConstrainsForUpdate(accountModel, accountEntity);

		return accountMapper
				.mapToModel(accountDao.updateAccount(accountMapper.mapToEntity(accountModel, accountEntity)));
	}

	@Override
	public AccountModel findByAccount(Integer accountAlphaCodeId) {
		return accountMapper.mapToModel(accountDao.findById(accountAlphaCodeId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountAlphaCodeId))));
	}

	@Override
	public List<AccountModel> getAllAccount(AccountModel accountModel) {
		return accountMapper.mapToModel(accountDao.getAllAccount(accountModel));
	}

	private void validateBusinessConstrainsForCreate(AccountModel accountModel) {
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(accountModel.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(accountModel.getEffectiveToDate()));
		validateCarrierDesignatorCode(accountModel);
		validateOptionalFields(accountModel);
		validateAccountAlphaCode(accountModel);
		validateOverlapForCreate(accountModel);
		validateAccountType(accountModel);

	}

	private void validateBusinessConstrainsForUpdate(AccountModel accountModel, AccountEntity accountEntity) {
		validateEffectiveToDate(getEffectiveFromDate(accountModel, accountEntity),
				getEffectiveToDate(accountModel, accountEntity));
		validateCarrierDesignatorCode(accountModel);
		if (OptionalUtil.isPresent(accountModel.getAccountAlphaCode())) {
			validateAccountAlphaCode(accountModel);
		}

		validateOverlapForUpdate(accountModel, accountEntity);
		validateAccountTypeForUpdate(accountModel, accountEntity);
	}

	private void validateOptionalFields(AccountModel accountModel) {
		accountModel.setAccountType(checkString(accountModel.getAccountType()));
		accountModel.setAttribute1(checkString(accountModel.getAttribute1()));
		accountModel.setAttribute2(checkString(accountModel.getAttribute2()));
		accountModel.setAttribute3(checkString(accountModel.getAttribute3()));
		accountModel.setAttribute4(checkString(accountModel.getAttribute4()));
		accountModel.setAttribute5(checkString(accountModel.getAttribute5()));
		accountModel.setAttribute6(checkString(accountModel.getAttribute6()));
		accountModel.setAttribute7(checkString(accountModel.getAttribute7()));
		accountModel.setAttribute8(checkString(accountModel.getAttribute8()));
		accountModel.setAttribute9(checkString(accountModel.getAttribute9()));
		accountModel.setAttribute10(checkString(accountModel.getAttribute10()));
		accountModel.setAttribute11(checkString(accountModel.getAttribute11()));
		accountModel.setAttribute12(checkString(accountModel.getAttribute12()));
		accountModel.setAttribute13(checkString(accountModel.getAttribute13()));
		accountModel.setAttribute14(checkString(accountModel.getAttribute14()));
		accountModel.setAttribute15(checkString(accountModel.getAttribute15()));
		accountModel.setAttribute16(checkString(accountModel.getAttribute16()));
		accountModel.setAttribute17(checkString(accountModel.getAttribute17()));
		accountModel.setAttribute18(checkString(accountModel.getAttribute18()));
		accountModel.setAttribute19(checkString(accountModel.getAttribute19()));
		accountModel.setAttribute20(checkString(accountModel.getAttribute20()));
	}

	private LocalDate getEffectiveToDate(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(accountModel.getEffectiveToDate())
				: accountEntity.getEffectiveToDate();
	}

	private LocalDate getEffectiveFromDate(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(accountModel.getEffectiveFromDate())
				: accountEntity.getEffectiveFromDate();
	}

	protected void validateEffectiveToDate(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}

	private void validateOverlapForCreate(AccountModel accountModel) {
		if (accountDao.validateOverlapForCreate(accountModel) != 0) {
			throw new BusinessException(RECORD_EXISTS);
		}
	}

	private void validateOverlapForUpdate(AccountModel accountModel, AccountEntity accountEntity) {
		String accountAlphaCode = getAccountAlphaCode(accountModel, accountEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(accountModel, accountEntity);
		LocalDate effectiveToDate = getEffectiveToDate(accountModel, accountEntity);
		String clientId = getClientId(accountModel, accountEntity);
		String accountNumCode = getAccountNumCode(accountModel, accountEntity);
		String accountType = getAccountType(accountModel, accountEntity);
		String attribute1 = checkString(getAttribute1(accountModel, accountEntity));
		String attribute2 = checkString(getAttribute2(accountModel, accountEntity));
		String attribute3 = checkString(getAttribute3(accountModel, accountEntity));
		String attribute4 = checkString(getAttribute4(accountModel, accountEntity));
		String attribute5 = checkString(getAttribute5(accountModel, accountEntity));
		String attribute6 = checkString(getAttribute6(accountModel, accountEntity));
		String attribute7 = checkString(getAttribute7(accountModel, accountEntity));
		String attribute8 = checkString(getAttribute8(accountModel, accountEntity));
		String attribute9 = checkString(getAttribute9(accountModel, accountEntity));
		String attribute10 = checkString(getAttribute10(accountModel, accountEntity));
		String attribute11 = checkString(getAttribute11(accountModel, accountEntity));
		String attribute12 = checkString(getAttribute12(accountModel, accountEntity));
		String attribute13 = checkString(getAttribute13(accountModel, accountEntity));
		String attribute14 = checkString(getAttribute14(accountModel, accountEntity));
		String attribute15 = checkString(getAttribute15(accountModel, accountEntity));
		String attribute16 = checkString(getAttribute16(accountModel, accountEntity));
		String attribute17 = checkString(getAttribute17(accountModel, accountEntity));
		String attribute18 = checkString(getAttribute18(accountModel, accountEntity));
		String attribute19 = checkString(getAttribute19(accountModel, accountEntity));
		String attribute20 = checkString(getAttribute20(accountModel, accountEntity));

		if (accountDao.validateOverlapForUpdate(accountAlphaCode, clientId, accountNumCode, effectiveFromDate,
				effectiveToDate, accountType, attribute1, attribute2, attribute3, attribute4, attribute5, attribute6,
				attribute7, attribute8, attribute9, attribute10, attribute11, attribute12, attribute13, attribute14,
				attribute15, attribute16, attribute17, attribute18, attribute19, attribute20,
				accountEntity.getAccountAlphaCodeId()) != 0) {
			throw new BusinessException(RECORD_EXISTS);
		}
	}

	private String getAccountNumCode(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAccountNumCode())
				? OptionalUtil.getValue(accountModel.getAccountNumCode())
				: accountEntity.getAccountNumCode();
	}

	private String getAccountAlphaCode(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAccountAlphaCode())
				? OptionalUtil.getValue(accountModel.getAccountAlphaCode())
				: accountEntity.getAccountAlphaCode();

	}

	private String getAttribute1(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute1())
				? OptionalUtil.getValue(accountModel.getAttribute1())
				: accountEntity.getAttribute1();
	}

	private String getAttribute2(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute2())
				? OptionalUtil.getValue(accountModel.getAttribute2())
				: accountEntity.getAttribute2();
	}

	private String getAttribute3(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute3())
				? OptionalUtil.getValue(accountModel.getAttribute3())
				: accountEntity.getAttribute3();
	}

	private String getAttribute4(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute4())
				? OptionalUtil.getValue(accountModel.getAttribute4())
				: accountEntity.getAttribute4();
	}

	private String getAttribute5(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute5())
				? OptionalUtil.getValue(accountModel.getAttribute5())
				: accountEntity.getAttribute5();
	}

	private String getAttribute6(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute6())
				? OptionalUtil.getValue(accountModel.getAttribute6())
				: accountEntity.getAttribute6();
	}

	private String getAttribute7(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute7())
				? OptionalUtil.getValue(accountModel.getAttribute7())
				: accountEntity.getAttribute7();
	}

	private String getAttribute8(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute8())
				? OptionalUtil.getValue(accountModel.getAttribute8())
				: accountEntity.getAttribute8();
	}

	private String getAttribute9(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute9())
				? OptionalUtil.getValue(accountModel.getAttribute9())
				: accountEntity.getAttribute9();
	}

	private String getAttribute10(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute10())
				? OptionalUtil.getValue(accountModel.getAttribute10())
				: accountEntity.getAttribute10();
	}

	private String getAttribute11(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute11())
				? OptionalUtil.getValue(accountModel.getAttribute11())
				: accountEntity.getAttribute11();
	}

	private String getAttribute12(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute12())
				? OptionalUtil.getValue(accountModel.getAttribute12())
				: accountEntity.getAttribute12();
	}

	private String getAttribute13(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute13())
				? OptionalUtil.getValue(accountModel.getAttribute13())
				: accountEntity.getAttribute14();
	}

	private String getAttribute14(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute14())
				? OptionalUtil.getValue(accountModel.getAttribute14())
				: accountEntity.getAttribute14();
	}

	private String getAttribute15(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute15())
				? OptionalUtil.getValue(accountModel.getAttribute15())
				: accountEntity.getAttribute15();
	}

	private String getAttribute16(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute16())
				? OptionalUtil.getValue(accountModel.getAttribute16())
				: accountEntity.getAttribute16();
	}

	private String getAttribute17(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute17())
				? OptionalUtil.getValue(accountModel.getAttribute17())
				: accountEntity.getAttribute17();
	}

	private String getAttribute18(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute18())
				? OptionalUtil.getValue(accountModel.getAttribute18())
				: accountEntity.getAttribute18();
	}

	private String getAttribute19(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute19())
				? OptionalUtil.getValue(accountModel.getAttribute19())
				: accountEntity.getAttribute19();
	}

	private String getAttribute20(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAttribute20())
				? OptionalUtil.getValue(accountModel.getAttribute20())
				: accountEntity.getAttribute20();
	}

	private void validateAccountTypeForUpdate(AccountModel accountModel, AccountEntity accountEntity) {
		if (OptionalUtil.isPresent(accountModel.getAccountType())) {
			validateAccountType(getAccountType(accountModel, accountEntity), getClientId(accountModel, accountEntity));
		}
	}

	private String getClientId(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getClientId()) ? OptionalUtil.getValue(accountModel.getClientId())
				: accountEntity.getClientId();
	}

	private String getAccountType(AccountModel accountModel, AccountEntity accountEntity) {
		return OptionalUtil.isPresent(accountModel.getAccountType())
				? OptionalUtil.getValue(accountModel.getAccountType())
				: accountEntity.getAccountType();
	}

	private void validateAccountType(AccountModel accountModel) {

		if (OptionalUtil.isPresent(accountModel.getAccountType())) {
			validateAccountType(OptionalUtil.getValue(accountModel.getAccountType()),
					OptionalUtil.getValue(accountModel.getClientId()));
		} else {
			accountModel.setAccountType(Optional.of("GL"));
		}
	}

	private void validateAccountType(String accountType, String clientId) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(ACCOUNT_TYPE));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(accountType));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Account Type[" + accountType + "] is Not Valid");
		}
	}

	protected void validateCarrierDesignatorCode(AccountModel accountModel) {
		if (OptionalUtil.isPresent(accountModel.getClientId())) {
			String carrierDesignatorCode = OptionalUtil.getValue(accountModel.getClientId());
			if (!globalMasterFeignClient.isValidCarrierDesignatorCode(carrierDesignatorCode)) {
				throw new BusinessException("Invalid Client Id " + carrierDesignatorCode);
			}
		}
	}

	private void validateAccountAlphaCode(AccountModel accountModel) {
		if (!Pattern.compile(PATTERN).matcher(OptionalUtil.getValue(accountModel.getAccountAlphaCode())).find()) {
			throw new BusinessException(
					"Invalid Account Alpha Code " + OptionalUtil.getValue(accountModel.getAccountAlphaCode()));
		}
	}

	private Optional<String> checkString(Optional<String> name) {
		return OptionalUtil.isPresent(name) ? name : Optional.of("");
	}

	private String checkString(String name) {
		return name != null ? name : "";
	}

	@Override
	public Boolean findByAccountAlphaCode(Optional<String> accountAlphaCode) {
		if (accountDao.findByAccountAlphaCode(accountAlphaCode) > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public List<AccountModel> getListOfAccountBYAccountAphaCode(List<String> accountAlphaCode) {

		return accountMapper.mapToModel(accountDao.getListOfAccountBYAccountAphaCode(accountAlphaCode));
	}
}
