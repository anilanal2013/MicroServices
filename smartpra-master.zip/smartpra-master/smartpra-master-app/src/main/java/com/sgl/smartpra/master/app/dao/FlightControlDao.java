package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.FlightControlEntity;

@Repository
public interface FlightControlDao{
	public Optional<FlightControlEntity> findById(Integer id);

	public FlightControlEntity create(FlightControlEntity flightControlEntity);

	public FlightControlEntity update(FlightControlEntity flightControlEntity);
	
	public void delete(Integer id);

	public List<FlightControlEntity> search(String clientId,String flightControlId, Boolean activate,Optional<String> exceptionCall);
	
	public List<FlightControlEntity> search(String clientId);
	
	public long getOverlapCount(String clientId,String flightControlId);
	
	public long getOverlapCount(String clientId,String flightControlId,Integer flightControlAutoId);
	
	public long validateControlFormulae(String flightControlId);
	
}
