package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.SPAMiscDataStgEntity;
@Repository
public interface SPAMiscDataStgDao {
	Optional<SPAMiscDataStgEntity> findById(Integer spaMiscDataId);

	List<SPAMiscDataStgEntity> findBySpaKeyMainIdClientIdRecordType(Optional<Integer> spaKey, Optional<Integer> spaMainId,
			Optional<String> clientId);
	
	List<SPAMiscDataStgEntity> getSPAMiscDataBySpaKeyProcessing(Optional<String> clientId, Optional<Integer> spaKey, Optional<Integer> recordType);
}
