package com.sgl.smartpra.master.app.dao.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sgl.smartpra.master.app.dao.entity.FlightRangeEntity;

public interface FlightRangeRepository
		extends JpaRepository<FlightRangeEntity, Integer>, JpaSpecificationExecutor<FlightRangeEntity> {

	@Query(value = "select count(*) from FlightRangeEntity d where"
			+ " (( CONVERT(numeric,?1) between d.fromFlightNumber and d.toFlightNumber) or "
			+ "( CONVERT(numeric,?2) between d.fromFlightNumber and d.toFlightNumber) or "
			+ " (d.fromFlightNumber >=CONVERT(numeric,?1) and d.toFlightNumber<=CONVERT(numeric,?2) )) and"
			+ " d.flightRangeId = ?3 and d.isMarketingOperating = ?4 and d.cxrCode = ?5 and d.activate =TRUE")
	int flightNumberVerifyIfOverlapExits(String fromFlightNumber, String toFlightNumber, String flightRangeId,
			String isMarketingOperating, String cxrCode);

	@Query(value = "select d from FlightRangeEntity d where"
			+ " d.flightRangeId = ?2 and d.clientId = ?1 and d.activate =TRUE")
	public List<FlightRangeEntity> flightRangeUniqueKey(String clientId, String flightRangeId);

	@Query(value = "select flightRangeAutoId from FlightRangeEntity d where"
			+ " (( CONVERT(numeric,?1) between d.fromFlightNumber and d.toFlightNumber) or "
			+ "( CONVERT(numeric,?2) between d.fromFlightNumber and d.toFlightNumber) or "
			+ " (d.fromFlightNumber >=CONVERT(numeric,?1) and d.toFlightNumber<=CONVERT(numeric,?2) )) and"
			+ " d.flightRangeId = ?3 and d.isMarketingOperating = ?4 and d.cxrCode = ?5 and d.recordSeqNumber = ?6  and d.activate =TRUE")
	List<Integer> updateNumberVerifyIfOverlapExits(String fromFlightNumber, String toFlightNumber,
			String flightRangeId, String isMarketingOperating, String cxrCode, Integer recordSeqNumber);

	@Query(value = "select count(*) from FlightRangeEntity d where"
			+ " d.flightRangeId = ?1 and d.isMarketingOperating = ?2 and d.cxrCode = ?3 and d.recordSeqNumber = ?4 and d.activate =TRUE")
	int recordSeqNumberVerifyIfOverlapExits(String flightRangeId, String isMarketingOperating, String cxrCode,
			Integer recordSeqNumber);

	@Query(value = "select a from FlightRangeEntity a where"
			+ " (( CONVERT(numeric,:flightNumber) between a.fromFlightNumber  AND a.toFlightNumber) or "
			+ " (a.fromFlightNumber >=CONVERT(numeric,:flightNumber) and a.toFlightNumber <=CONVERT(numeric,:flightNumber)))and a.activate =TRUE")
	public List<FlightRangeEntity> getFlightNumber(@Param("flightNumber") String flightNumber);

	@Query(value = "select a from FlightRangeEntity a where "
			+ "  (a.cxrCode =:cxrCode and a.isMarketingOperating =:isMarketingOperating and a.flightRangeId =:flightRangeId) and"
			+ "	(( CONVERT(numeric,:flightNumber) between a.fromFlightNumber  AND a.toFlightNumber) or"
			+ "	(a.fromFlightNumber >=CONVERT(numeric,:flightNumber) and a.toFlightNumber <=CONVERT(numeric,:flightNumber))) or"
			+ "	((:saleDate between a.saleFromDate  AND a.saleToDate) or"
			+ "	(a.saleFromDate >=:saleDate and a.saleToDate <=:saleDate) and"
			+ "	((:travelDate between a.travelFromDate  AND a.travelToDate) or"
			+ "	(a.travelFromDate >=:travelDate and a.travelToDate <=:travelDate ))) and a.activate=TRUE")
	public List<FlightRangeEntity> getAllFlightEntity(@Param("flightNumber") String flightNumber,
			@Param("saleDate") LocalDate saleDate, @Param("travelDate") LocalDate travelDate,
			@Param("cxrCode") String cxrCode, @Param("isMarketingOperating") String isMarketingOperating,
			@Param("flightRangeId") String flightRangeId);

	@Query(value = "select flightRangeAutoId from FlightRangeEntity d where"
			+ " ((?1 between d.saleFromDate and d.saleToDate) or "
			+ "	(?2 between d.saleFromDate and d.saleToDate)) and d.activate =TRUE")
	List<Integer> verifyIfSameSaleRecordExits(LocalDate saleFromDate, LocalDate saleToDate);

	@Query(value = "select flightRangeAutoId from FlightRangeEntity d where"
			+ " ((?1 between d.travelFromDate and d.travelToDate) or "
			+ "	(?2 between d.travelFromDate and d.travelToDate)) and d.activate =TRUE")
	List<Integer> verifyIfSameTravelRecordExits(LocalDate travelFromDate, LocalDate travelToDate);

	@Query(value = "select flightRangeAutoId from FlightRangeEntity d where"
			+ " (( CONVERT(numeric,?1) between d.fromFlightNumber and d.toFlightNumber) or "
			+ "	( CONVERT(numeric,?2) between d.fromFlightNumber and d.toFlightNumber)) and d.recordSeqNumber = ?3 and d.activate =TRUE")
	List<Integer> verifyIfSameFlightNumberExits(String fromFlightNumber, String toFlightNumber,
			Integer recordSeqNumber);

	@Query(value = "select d from FlightRangeEntity d where (?2 between d.saleFromDate and d.saleToDate) and d.flightRangeAutoId=?1 and d.activate =TRUE")
	Optional<FlightRangeEntity> valiadateIssueDate(Integer flightRangeAutoId, LocalDate ticketedIssueDate);

}
