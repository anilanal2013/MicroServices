package com.sgl.smartpra.master.app.common.aspects;

import java.util.Optional;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.BatchGlobalMasterFeignClient;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class MasterAuditAspect {

	private Object oldObj = null;
	private Optional<Object> oldObject = null;
	private Object newObj = null;
	String tableName = null;
	String serviceName = null;
	private static final String CONTEXT = "CONTEXT ";

	@Autowired
	private BatchGlobalMasterFeignClient batchGlobalMasterFeignClient;

	@SuppressWarnings("unchecked")
	@Around("methodToUpdate()")
	public Object updateEntry(ProceedingJoinPoint joinpoint) throws Throwable {
		try {

			newObj = joinpoint.proceed();

			tableName = joinpoint.proceed().getClass().getSimpleName();
			serviceName = joinpoint.getSignature().getName();

		} catch (Throwable e) {
			log.error(CONTEXT, e);
		}

		try {
			// Optional<String> currentUserLogin = HeaderUtil.getCurrentUserLogin();
			oldObject = (Optional<Object>) oldObj;
			log.info("Updating Master audit service starting " + newObj);
			batchGlobalMasterFeignClient.updateMasterAudit(newObj, OptionalUtil.getValue(oldObject), tableName,
					serviceName);
			log.info("Updated Master audit service successfully " + newObj);

		} catch (Exception e) {
			log.error(CONTEXT, e);
		}
		return newObj;
	}

	@Around("methodToFindById()")
	public Object findByEntry(ProceedingJoinPoint joinpoint) throws Throwable {

		try {
			oldObj = joinpoint.proceed();
		} catch (Throwable e) {
			log.error(CONTEXT, e);
		}
		return oldObj;
	}

	@Pointcut("execution(* com.sgl.smartpra.master.app.dao.*.update*(..))")
	public void methodToUpdate() {

	}

	@Pointcut("execution(* com.sgl.smartpra.master.app.dao.*.findBy*(..))")
	public void methodToFindById() {
	}

}
