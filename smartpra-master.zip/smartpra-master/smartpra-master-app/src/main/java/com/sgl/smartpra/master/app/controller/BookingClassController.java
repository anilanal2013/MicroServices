package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.BookingClassService;
import com.sgl.smartpra.master.model.BookingClassModel;

@RestController
public class BookingClassController {

	@Autowired
	private BookingClassService bookingClassService;

	@GetMapping("/booking-class")
	public List<BookingClassModel> getListOfBookingClassByUtilizationEffectiveDate(
			@RequestParam(value = "utilizationEffectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> utilizationEffectiveFromDate,
			@RequestParam(value = "utilizationEffectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> utilizationEffectiveToDate,
			@RequestParam(value = "rbd", required = false) Optional<String> rbd,
			@RequestParam(value = "salesEffectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> salesEffectiveFromDate,
			@RequestParam(value = "salesEffectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> salesEffectiveToDate,
			@RequestParam(value = "cabin", required = false) Optional<String> cabin,
			@RequestParam(value = "marketingCarrier", required = false) Optional<String> marketingCarrier,
			@RequestParam(value = "fromAirport", required = false) Optional<String> fromAirport,
			@RequestParam(value = "toAirport", required = false) Optional<String> toAirport) {

		BookingClassModel bookingClassModel = new BookingClassModel();
		bookingClassModel.setUtilEffectiveFromDate(utilizationEffectiveFromDate);
		bookingClassModel.setUtilEffectiveToDate(utilizationEffectiveToDate);
		bookingClassModel.setRbd(rbd);
		bookingClassModel.setSalesEffectiveFromDate(salesEffectiveFromDate);
		bookingClassModel.setSalesEffectiveToDate(salesEffectiveToDate);
		bookingClassModel.setCabin(cabin);
		bookingClassModel.setMarketingCarrier(marketingCarrier);
		bookingClassModel.setFromAirport(fromAirport);
		bookingClassModel.setToAirport(toAirport);
		return bookingClassService.getListOfBookingClassByUtilizationEffectiveDate(bookingClassModel, Optional.of(""));
	}

	// for exception call service
	@GetMapping("/booking-class/search/clientid/{clientId}")
	public List<BookingClassModel> getListOfBookingClassByUtilizationEffectiveDate(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "utilizationEffectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> utilizationEffectiveFromDate,
			@RequestParam(value = "utilizationEffectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> utilizationEffectiveToDate,
			@RequestParam(value = "rbd", required = false) Optional<String> rbd,
			@RequestParam(value = "salesEffectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> salesEffectiveFromDate,
			@RequestParam(value = "salesEffectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> salesEffectiveToDate,
			@RequestParam(value = "cabin", required = false) Optional<String> cabin,
			@RequestParam(value = "marketingCarrier", required = false) Optional<String> marketingCarrier,
			@RequestParam(value = "fromAirport", required = false) Optional<String> fromAirport,
			@RequestParam(value = "toAirport", required = false) Optional<String> toAirport,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {

		BookingClassModel bookingClassModel = new BookingClassModel();
		bookingClassModel.setClientId(clientId);
		bookingClassModel.setUtilEffectiveFromDate(utilizationEffectiveFromDate);
		bookingClassModel.setUtilEffectiveToDate(utilizationEffectiveToDate);
		bookingClassModel.setRbd(rbd);
		bookingClassModel.setSalesEffectiveFromDate(salesEffectiveFromDate);
		bookingClassModel.setSalesEffectiveToDate(salesEffectiveToDate);
		bookingClassModel.setCabin(cabin);
		bookingClassModel.setMarketingCarrier(marketingCarrier);
		bookingClassModel.setFromAirport(fromAirport);
		bookingClassModel.setToAirport(toAirport);
		bookingClassModel.setActivate(OptionalUtil.getValue(activate));

		return bookingClassService.getListOfBookingClassByUtilizationEffectiveDate(bookingClassModel, exceptionCall);
	}



	@GetMapping("/booking-class/{bookingClassId}")
	public BookingClassModel getBookingClassByBookingClassId(
			@PathVariable(value = "bookingClassId") int bookingClassId) {
		return bookingClassService.getBookingClassByBookingClassId(bookingClassId);
	}

	@GetMapping("/booking-class/rbd-search")
	public BookingClassModel getBookingClassByRBD(
			@RequestParam(value = "clientId", required = true) Optional<String> clientId,
			@RequestParam(value = "rbd", required = true) Optional<String> rbd,
			@RequestParam(value = "marketingCarrier", required = true) Optional<String> marketingCarrier,
			@RequestParam(value = "utilizationDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> utilizationDate,
			@RequestParam(value = "salesDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> salesDate) {
		return bookingClassService.getBookingClassByRBD(clientId, rbd, marketingCarrier, utilizationDate, salesDate);
	}

	@PostMapping("/booking-class")
	public BookingClassModel createBookingClassMaster(
			@Validated(Create.class) @RequestBody BookingClassModel bookingClassModel) {
		return bookingClassService.createBookingClassMaster(bookingClassModel);
	}

	@PutMapping("/booking-class/{bookingClassId}")
	public BookingClassModel updateBookingClassMaster(@PathVariable(value = "bookingClassId") int bookingClassId,
			@Validated(Update.class) @RequestBody BookingClassModel bookingClassModel) {
		return bookingClassService.updateBookingClassMaster(bookingClassId, bookingClassModel);
	}

	@PutMapping("/booking-class/{bookingClassId}/deactivate")
	public void deactivateBookingClassMaster(@Valid @PathVariable(value = "bookingClassId") int bookingClassId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		bookingClassService.deactivateBookingClassMaster(bookingClassId, lastUpdatedBy);
	}

	@PutMapping("/booking-class/{bookingClassId}/activate")
	public void activateBookingClassMaster(@Valid @PathVariable(value = "bookingClassId") int bookingClassId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		bookingClassService.activateBookingClassMaster(bookingClassId, lastUpdatedBy);
	}

	@GetMapping("/booking-class/cabin-rbd-list")
	public Map<String, Set<String>> getListOfRDBFromCabin(@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "salesDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") String salesDate,
			@RequestParam(value = "utilDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") String utilDate) {
		return bookingClassService.getListOfRDBFromCabin(clientId, salesDate, utilDate);
	}
}
