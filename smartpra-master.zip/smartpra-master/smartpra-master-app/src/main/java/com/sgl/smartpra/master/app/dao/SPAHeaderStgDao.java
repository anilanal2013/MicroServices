package com.sgl.smartpra.master.app.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.SPAHeaderStgEntity;

@Repository
public interface SPAHeaderStgDao {
	List<SPAHeaderStgEntity> getSpaHeaderBySpecSerach(String cxrCode, Integer spaCodeSeqNumber, Integer spaKey,
			String spaId, String effectiveIssueDate, String effectiveUpliftDate);
	List<SPAHeaderStgEntity> getSpaHeaderForProcessingCoupon(String clientId, String cxrCode, String effectiveIssueDate, String effectiveOriginalDate, String effectiveUpliftDate);
}
