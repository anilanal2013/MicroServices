package com.sgl.smartpra.master.app.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sgl.smartpra.master.app.repository.entity.FlightEntity;

public interface FlightRepository extends JpaRepository<FlightEntity, Integer>, JpaSpecificationExecutor<FlightEntity> {

	@Query(value = "select a from FlightEntity a  where " + "((?1 between a.fromDate  AND a.toDate) "
			+ " or (a.fromDate >=?1 and a.toDate <=?1 )) "
			+ "and  a.flightFrom =?2 and a.flightTo =?3 and a.from =?4 and a.to =?5" + " AND a.isActive = 1")
	FlightEntity getFlightByEffectiveDate(Date effectiveDate, String flightFrom, String flightTo, String from,
			String to);
	
	@Query(value = "select a from FlightEntity a  where a.clientId=:clientId AND ((:effectiveDate between a.fromDate  AND a.toDate) "
			+ " OR (a.fromDate >=:effectiveDate and a.toDate <=:effectiveDate )) "
			+ " AND (( :flightNumber between a.flightFrom AND a.flightTo ) OR (a.flightFrom =:flightNumber OR a.flightTo =:flightNumber)) "
			+ " AND a.from =:from AND a.to =:to AND a.isActive = 1")
	FlightEntity getFlightByFlightNumber(@Param("clientId") String clientId, @Param("effectiveDate") Date effectiveDate,
			@Param("flightNumber") String flightNumber, @Param("from") String from, @Param("to") String to);

/*	@Query(value = "select count(*) from FlightEntity d where"
			+ " ((?1 between d.effectiveFromDate and d.effectiveToDate) or "
			+ "(?2 between d.effectiveFromDate and d.effectiveToDate)) and d.isActive = 1")
	int verifyIfOverlapExits(Timestamp effectiveFromDate, Timestamp effectiveToDate);

	@Query(value = "select flightId from FlightEntity d where"
			+ " ((?1 between d.effectiveFromDate and d.effectiveToDate) or "
			+ "	(?2 between d.effectiveFromDate and d.effectiveToDate)) and d.isActive = 1")
	List<Integer> verifyIfSameRecordExits(Timestamp effectiveFromDate, Timestamp effectiveToDate);
*/
	List<FlightEntity> findByFromDateAndToDateAndFlightFromAndFlightToAndClientIdAndFromAndTo(Date fromDate,
			Date toDate, String flightFrom, String flightTo, String clientId, String from, String to);
	
	@Query(value="select d from FlightEntity d where d.flightId=?1")
	Optional<FlightEntity> getFlightsByFlightid(int flightId);
}
