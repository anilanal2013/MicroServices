package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.RouteCodeEntity;
import com.sgl.smartpra.master.model.RouteCode;

@Repository
public interface RouteCodeDao {

	public List<RouteCodeEntity> getAllRouteCode(RouteCode routeCodeModel);

	public Optional<RouteCodeEntity> findById(Integer routeCodeId);

	public RouteCodeEntity createRouteCode(RouteCodeEntity routeCodeEntity);

	public RouteCodeEntity updateRouteCode(RouteCodeEntity routeCodeEntity);

	public long getOverLapForCreate(String clientId, String routeCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate);
 
	public long getOverLapForUpdate(String clientId, String routeCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, Integer routeCodeId);

	public Page<RouteCodeEntity> getAllRouteCode(RouteCodeEntity mapToEntity, Pageable pageable);

	public long getTotalCount(RouteCodeEntity routeCodeEntity);  

}
