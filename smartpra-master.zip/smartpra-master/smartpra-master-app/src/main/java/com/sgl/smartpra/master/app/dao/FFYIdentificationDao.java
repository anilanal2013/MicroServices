package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.FFYIdentificationEntity;

@Repository
public interface FFYIdentificationDao {

	public List<FFYIdentificationEntity> search(Optional<String> issueCxrCode, Optional<String> marketingCxrCode,
			Optional<String> operatingCxrCode, Optional<String> saleFromDate, Optional<String> saleToDate,
			Optional<Boolean> activate);

	public Optional<FFYIdentificationEntity> findById(Integer ffyIdentifyId);

	public FFYIdentificationEntity update(FFYIdentificationEntity mapToEntity);

	public FFYIdentificationEntity create(FFYIdentificationEntity mapToEntity);

	public long saleVerifyIfOverlapExits(LocalDate saleFromDate, LocalDate saleToDate);

	public long upLiftVerifyIfOverlapExits(LocalDate upliftFromDate, LocalDate upliftToDate);

	public long verifyIfSameSaleRecordExits(LocalDate saleFromDate, LocalDate saleToDate, Integer ffyIdentifyId);

	public long verifyIfSameUpliftRecordExits(LocalDate upliftFromDate, LocalDate upliftToDate, Integer ffyIdentifyId);
}
