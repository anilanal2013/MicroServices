package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.CarrierInterlineDetailsDao;
import com.sgl.smartpra.master.app.dao.entity.spec.CarrierInterlineDetailsEntitySpecification;
import com.sgl.smartpra.master.app.repository.CarrierInterlineDetailsRepository;
import com.sgl.smartpra.master.app.repository.entity.CarrierInterlineDetailsEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CarrierInterlineDetailsDaoImpl<T> extends CommonSearchDao<T> implements CarrierInterlineDetailsDao {
	@Autowired
	private CarrierInterlineDetailsRepository carrierInterlineDetailsRepository;

	@Override
	@Caching(evict = {
			@CacheEvict(value = "carrierInterlineDetailsModel", key = "#interfaceReferenceEntity.carrierInterlineDtlId") })
	public CarrierInterlineDetailsEntity create(CarrierInterlineDetailsEntity carrierInterlineDetailsEntity) {
		return carrierInterlineDetailsRepository.save(carrierInterlineDetailsEntity);
	}

	@Override
	@CachePut(value = "carrierInterlineDetailsModel", key = "#carrierInterlineDetailsEntity.carrierInterlineDtlId")
	public CarrierInterlineDetailsEntity update(CarrierInterlineDetailsEntity carrierInterlineDetailsEntity) {
		return carrierInterlineDetailsRepository.save(carrierInterlineDetailsEntity);
	}

	@Override
	@Cacheable(value = "carrierInterlineDetailsModel", key = "#carrierInterlineDtlId")
	public Optional<CarrierInterlineDetailsEntity> findById(Integer carrierInterlineDtlId) {
		return carrierInterlineDetailsRepository.findById(carrierInterlineDtlId);
	}

	@Override
	public List<CarrierInterlineDetailsEntity> search(Optional<String> carrierCode, Optional<String> effectiveDate) {
		return carrierInterlineDetailsRepository
				.findAll(CarrierInterlineDetailsEntitySpecification.search(carrierCode, effectiveDate));
	}

	@Override
	public List<CarrierInterlineDetailsEntity> getCarrierCodeByCarrierCode(Optional<String> carrierCode) {
		return carrierInterlineDetailsRepository
				.findAll(CarrierInterlineDetailsEntitySpecification.getByCarrierCode(carrierCode));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String carrierCode) {
		return carrierInterlineDetailsRepository
				.count(Specification.where(CarrierInterlineDetailsEntitySpecification.equalsClientId(clientId))
						.and(CarrierInterlineDetailsEntitySpecification.equalsCarrierCode(carrierCode))
						.and(CarrierInterlineDetailsEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
							.or(CarrierInterlineDetailsEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
							.or(CarrierInterlineDetailsEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate))));
	}

	@Override
	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String carrierCode, Integer carrierInterlineDtlId) {
		return carrierInterlineDetailsRepository
				.count(Specification.where(CarrierInterlineDetailsEntitySpecification.equalsClientId(clientId))
						.and(CarrierInterlineDetailsEntitySpecification.equalsCarrierCode(carrierCode))
						.and(CarrierInterlineDetailsEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(CarrierInterlineDetailsEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.or(CarrierInterlineDetailsEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate)))
						.and(CarrierInterlineDetailsEntitySpecification.notEqualsCarrierInterlineDtlId(carrierInterlineDtlId)));
	}

	@Override
	public List<CarrierInterlineDetailsEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return carrierInterlineDetailsRepository.findAll((CarrierInterlineDetailsEntitySpecification
				.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(CarrierInterlineDetailsEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.and(CarrierInterlineDetailsEntitySpecification.isActive())));
	}

	@Override
	public List<CarrierInterlineDetailsEntity> findAll(Optional<String> carrierCode, Optional<String> clientId, Optional<String> effectiveDate) {

		return carrierInterlineDetailsRepository
				.findAll(CarrierInterlineDetailsEntitySpecification.searchAll(carrierCode, clientId,  effectiveDate));
	}

	@Override
	public List<CarrierInterlineDetailsEntity> findAllValidPassengerSis( Optional<String> carrierCode, Optional<Boolean> passengerSis,
			Optional<String> effectiveDate) {
		return carrierInterlineDetailsRepository
				.findAll(CarrierInterlineDetailsEntitySpecification.searchPassengerSis(carrierCode, passengerSis, effectiveDate));
	}

	@Override
	public Optional<CarrierInterlineDetailsEntity> find(Optional<String> carrierCode,
			Optional<String> effectiveDate) {
		
		return carrierInterlineDetailsRepository.findOne(CarrierInterlineDetailsEntitySpecification.searchByCarrierCodeAndEffectiveDate(carrierCode, effectiveDate));
	}

	@Override
	public List<CarrierInterlineDetailsEntity> getCarrierInterlineDetailsByZoneAndEffectiveDate(Optional<String> clientId,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> zone) {
		return carrierInterlineDetailsRepository.findAll(
				Specification.where(CarrierInterlineDetailsEntitySpecification.carrierInterlineDetailsByZoneAndEffectiveDate(clientId, zone)
						.and(CarrierInterlineDetailsEntitySpecification.isActive())
						.and(CarrierInterlineDetailsEntitySpecification.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate))
								.or(CarrierInterlineDetailsEntitySpecification.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveToDate))))));
	}
}
