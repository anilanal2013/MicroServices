package com.sgl.smartpra.master.app.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.RateAndAgreementTimeValidityEntity;

import java.util.List;
import java.util.Optional;

@Repository
public interface RateAndAgreementTimeValidityDao  {

    public RateAndAgreementTimeValidityEntity create(RateAndAgreementTimeValidityEntity rateAndAgreementTimeValidityEntity);

    RateAndAgreementTimeValidityEntity update(RateAndAgreementTimeValidityEntity mapToEntity);

    Optional<RateAndAgreementTimeValidityEntity> findById(Integer id);

    List<RateAndAgreementTimeValidityEntity> fetchAll(Integer rateAgreementId);

    Boolean delete(Integer id);
}
