package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.Length;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author nacsanth
 *
 */
@Entity
@Table(name = "mas_accounting_definition")
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicUpdate
@DynamicInsert
public class MassAccountingDefinitionEntity extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "account_definition_identifier")
	private Integer accountDefinitionIdentifier;
	@Column(name = "client_id", unique = true, length = 2)
	private String clientId;
	@Column(name = "account_code_alpha", unique = true, length = 3)
	private String accountCodeAlpha;
	@Column(name = "component_identifier", length = 50)
	private String componentIdentifier;
	@Column(name = "conversion_date_use")
	private String conversionDate;
	@Column(name = "accounting_attributes_master_1", length = 50)
	private String accountingAttributeMaster1;
	@Column(name = "accounting_attributes_1", length = 50)
	private String accountingAttributes1;
	@Column(name = "attribute_validation_indicator_1", length = 50)
	private String attributeValidationindi1;
	@Column(name = "accounting_attributes_master_2", length = 50)
	private String accountingAttributeMaster2;
	@Column(name = "accounting_attributes_2", length = 50)
	private String accountingAttributes2;
	@Column(name = "attribute_validation_indicator_2", length = 50)
	private String attributeValidationindi2;
	@Column(name = "accounting_attributes_master_3", length = 50)
	private String accountingAttributeMaster3;
	@Column(name = "accounting_attributes_3", length = 50)
	private String accountingAttributes3;
	@Column(name = "attribute_validation_indicator_3", length = 50)
	private String attributeValidationindi3;
	@Column(name = "accounting_attributes_master_4", length = 50)
	private String accountingAttributeMaster4;
	@Column(name = "accounting_attributes_4", length = 50)
	private String accountingAttributes4;
	@Column(name = "attribute_validation_indicator_4", length = 50)
	private String attributeValidationindi4;
	@Column(name = "accounting_attributes_master_5", length = 50)
	private String accountingAttributeMaster5;
	@Column(name = "accounting_attributes_5", length = 50)
	private String accountingAttributes5;
	@Column(name = "attribute_validation_indicator_5", length = 50)
	private String attributeValidationindi5;
	@Column(name = "accounting_attributes_master_6", length = 50)
	private String accountingAttributeMaster6;
	@Column(name = "accounting_attributes_6", length = 50)
	private String accountingAttributes6;
	@Column(name = "attribute_validation_indicator_6", length = 50)
	private String attributeValidationindi6;
	@Column(name = "accounting_attributes_master_7", length = 50)
	private String accountingAttributeMaster7;
	@Column(name = "accounting_attributes_7", length = 50)
	private String accountingAttributes7;
	@Column(name = "attribute_validation_indicator_7", length = 50)
	private String attributeValidationindi7;
	@Column(name = "accounting_attributes_master_8", length = 50)
	private String accountingAttributeMaster8;
	@Column(name = "accounting_attributes_8", length = 50)
	private String accountingAttributes8;
	@Column(name = "attribute_validation_indicator_8", length = 50)
	private String attributeValidationindi8;
	@Column(name = "accounting_attributes_master_9", length = 50)
	private String accountingAttributeMaster9;
	@Length(max = 50)
	@Column(name = "accounting_attributes_9", length = 50)
	private String accountingAttributes9;
	@Column(name = "attribute_validation_indicator_9", length = 50)
	private String attributeValidationindi9;
	@Column(name = "accounting_attributes_master_10", length = 50)
	private String accountingAttributeMaster10;
	@Column(name = "accounting_attributes_10", length = 50)
	private String accountingAttributes10;
	@Column(name = "attribute_validation_indicator_10", length = 50)
	private String attributeValidationindi10;
	@Column(name = "accounting_attributes_master_11", length = 50)
	private String accountingAttributeMaster11;
	@Column(name = "accounting_attributes_11", length = 50)
	private String accountingAttributes11;
	@Column(name = "attribute_validation_indicator_11", length = 50)
	private String attributeValidationindi11;
	@Column(name = "accounting_attributes_master_12", length = 50)
	private String accountingAttributeMaster12;
	@Column(name = "accounting_attributes_12", length = 50)
	private String accountingAttributes12;
	@Column(name = "attribute_validation_indicator_12", length = 50)
	private String attributeValidationindi12;
	@Column(name = "accounting_attributes_master_13", length = 50)
	private String accountingAttributeMaster13;
	@Column(name = "accounting_attributes_13", length = 50)
	private String accountingAttributes13;
	@Column(name = "attribute_validation_indicator_13", length = 50)
	private String attributeValidationindi13;
	@Column(name = "accounting_attributes_master_14", length = 50)
	private String accountingAttributeMaster14;
	@Column(name = "accounting_attributes_14", length = 50)
	private String accountingAttributes14;
	@Column(name = "attribute_validation_indicator_14", length = 50)
	private String attributeValidationindi14;
	@Column(name = "accounting_attributes_master_15", length = 50)
	private String accountingAttributeMaster15;
	@Column(name = "accounting_attributes_15", length = 50)
	private String accountingAttributes15;
	@Column(name = "attribute_validation_indicator_15", length = 50)
	private String attributeValidationindi15;
	@Column(name = "accounting_attributes_master_16", length = 50)
	private String accountingAttributeMaster16;
	@Column(name = "accounting_attributes_16", length = 50)
	private String accountingAttributes16;
	@Column(name = "attribute_validation_indicator_16", length = 50)
	private String attributeValidationindi16;
	@Column(name = "accounting_attributes_master_17", length = 50)
	private String accountingAttributeMaster17;
	@Column(name = "accounting_attributes_17", length = 50)
	private String accountingAttributes17;
	@Column(name = "attribute_validation_indicator_17", length = 50)
	private String attributeValidationindi17;
	@Column(name = "accounting_attributes_master_18", length = 50)
	private String accountingAttributeMaster18;
	@Column(name = "accounting_attributes_18", length = 50)
	private String accountingAttributes18;
	@Column(name = "attribute_validation_indicator_18", length = 50)
	private String attributeValidationindi18;
	@Column(name = "accounting_attributes_master_19", length = 50)
	private String accountingAttributeMaster19;
	@Column(name = "accounting_attributes_19", length = 50)
	private String accountingAttributes19;
	@Column(name = "attribute_validation_indicator_19", length = 50)
	private String attributeValidationindi19;
	@Column(name = "accounting_attributes_master_20", length = 50)
	private String accountingAttributeMaster20;
	@Column(name = "accounting_attributes_20", length = 50)
	private String accountingAttributes20;
	@Column(name = "attribute_validation_indicator_20", length = 50)
	private String attributeValidationindi20;
	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
