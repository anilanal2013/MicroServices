package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.ClientUserAreaEntity;
import com.sgl.smartpra.master.model.ClientUserArea;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ClientUserAreaMapper extends BaseMapper<ClientUserArea, ClientUserAreaEntity> {

	ClientUserAreaEntity mapToEntity(ClientUserArea clientUserArea,
			@MappingTarget ClientUserAreaEntity clientUserAreaEntity);

	@Mapping(source = "userAreaId", target = "userAreaId", ignore = true)
	ClientUserAreaEntity mapToEntity(ClientUserArea clientUserArea);
	
	
}
