package com.sgl.smartpra.master.app.dao.entity.spec;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.RateAndAgreementEntity;

import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class RateAndAgreementEntitySpecifcation {


    public static Specification<RateAndAgreementEntity> search(Optional<String> supplierCode, Optional<String> baseLocation, Optional<String> chargeCategory, Optional<String> chargeCode, Optional<String> effectivePeriodFrom, Optional<String> effectivePeriodTo, Optional<String> airport) {
    return (entity, criteriaQuery,criteriaBuilder) ->{
        List<Predicate> predicates = new ArrayList<>();
        if (OptionalUtil.isPresent(supplierCode)){
            predicates.add(criteriaBuilder.equal(entity.get("supplierCode"), OptionalUtil.getValue(supplierCode)));
        }
        if (OptionalUtil.isPresent(baseLocation)){
            predicates.add(criteriaBuilder.equal(entity.get("locationCode"),OptionalUtil.getValue(baseLocation)));
        }
        if (OptionalUtil.isPresent(chargeCategory)){
            predicates.add(criteriaBuilder.equal(entity.get("chargeCategory"),OptionalUtil.getValue(chargeCategory)));
        }
        if (OptionalUtil.isPresent(chargeCode)){
            predicates.add(criteriaBuilder.equal(entity.get("chargeCode"),OptionalUtil.getValue(chargeCode)));
        }
        if (OptionalUtil.isPresent(effectivePeriodFrom)){
            predicates.add(criteriaBuilder.greaterThanOrEqualTo(entity.get("effectiveFromDate"),OptionalUtil.getValue(effectivePeriodFrom)));
        }
        if (OptionalUtil.isPresent(effectivePeriodTo)){
            predicates.add(criteriaBuilder.greaterThanOrEqualTo(entity.get("effectiveToDate"),OptionalUtil.getValue(effectivePeriodTo)));
        }
        if (OptionalUtil.isPresent(airport)){
            predicates.add(criteriaBuilder.equal(entity.get("airport"),OptionalUtil.getValue(airport)));
        }

        return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
    };
    }
}
