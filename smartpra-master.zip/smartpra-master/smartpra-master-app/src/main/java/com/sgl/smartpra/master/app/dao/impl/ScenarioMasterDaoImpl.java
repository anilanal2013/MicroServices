package com.sgl.smartpra.master.app.dao.impl;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.master.app.dao.ScenarioMasterDao;
import com.sgl.smartpra.master.app.dao.entity.MasScenarioEntity;
import com.sgl.smartpra.master.app.repository.ScenarioMasterRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ScenarioMasterDaoImpl<T> extends CommonSearchDao<T> implements ScenarioMasterDao {
	@Autowired
	private ScenarioMasterRepository scenarioMasterRepository;

	@Override
	public List<MasScenarioEntity> findAll() {
		log.info("fetching MasScenarioEntitys ");
		return scenarioMasterRepository.findAll();
	}
	
	@SuppressWarnings("serial")
	@Override
	public List<MasScenarioEntity> findByScenarioMaster(MasScenarioEntity scenarioMaster) {
		List<MasScenarioEntity> scenarioMasters = scenarioMasterRepository.findAll(new Specification<MasScenarioEntity>() {

			@Override
			public Predicate toPredicate(Root<MasScenarioEntity> root, CriteriaQuery<?> query,
					CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicates = new ArrayList<>();
				try {
					for(PropertyDescriptor propertyDescriptor : 
					    Introspector.getBeanInfo(scenarioMaster.getClass()).getPropertyDescriptors()){
						String attributeName = propertyDescriptor.getName();
						if(!"class".equals(attributeName)) {
							Method getter = propertyDescriptor.getReadMethod();
							Object value = getter.invoke(scenarioMaster);
							if (value != null && !Objects.equals(value, 0) && !Objects.equals(value, 0L) && !Objects.equals(value, 0D)) {
								predicates.add(criteriaBuilder
										.and(criteriaBuilder.equal(root.get(attributeName), value)));
							}
						}
					}
				} catch (IntrospectionException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
			}
		});
		return scenarioMasters;
	}

}
