package com.sgl.smartpra.master.app.service;

import java.util.List;

import com.sgl.smartpra.master.model.FinancialMonthModel;

public interface FinancialMonthService {

	public List<FinancialMonthModel> getListOfFinancialMonthCalendar(String financialYear, String financialMonth);

	public FinancialMonthModel getFinancialMonthCalendarByFinancialYearAndMonth(String financialYear,
			String financialMonth);

	public FinancialMonthModel getCurrentOpenFinancialMonthForFinancialCalendar();
	
	public FinancialMonthModel getCurrentOpenFinancialMonthForFinancialCalendarByClientId(String clientId);

	public FinancialMonthModel getLatestClosedFinancialMonthForFinancialCalendar();

	public FinancialMonthModel createFinancialMonthCalendar(FinancialMonthModel financialMonthModel);

	public FinancialMonthModel updateFinancialMonthCalendar(int financialMonthId,
			FinancialMonthModel financialMonthModel);

	public FinancialMonthModel getFinancialYearByFinancialMonth(String clientId, String financialMonth);

}
