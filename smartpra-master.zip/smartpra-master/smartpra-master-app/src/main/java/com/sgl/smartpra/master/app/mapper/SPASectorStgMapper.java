package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.SPASectorStgEntity;
import com.sgl.smartpra.master.model.SPASectorStg;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SPASectorStgMapper extends BaseMapper<SPASectorStg, SPASectorStgEntity> {
	SPASectorStgEntity mapToEntity(SPASectorStg spaSectorStg, @MappingTarget SPASectorStgEntity spaSectorStgEntity);
	@Mapping(source = "spaSectorId", target = "spaSectorId", ignore = true)
	SPASectorStgEntity mapToEntity(SPASectorStg spaSectorStg);
}
