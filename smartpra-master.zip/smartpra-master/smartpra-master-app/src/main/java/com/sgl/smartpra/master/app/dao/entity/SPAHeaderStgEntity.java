package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_spa_header")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class SPAHeaderStgEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "spa_header_id", nullable = false)
	private Integer spaHeaderId;

	@Column(name = "spa_key", nullable = false)
	private Integer spaKey;

	@Column(name = "client_id", nullable = false, length = 2)
	private String clientId;

	@Column(name = "cxr_code", nullable = false, length = 3)
	private String cxrCode;

	@Column(name = "spa_code_seq_number", nullable = false)
	private Integer spaCodeSeqNumber;

	@Column(name = "priority", nullable = false)
	private Integer priority;

	@Column(name = "spa_id", nullable = false, length = 10)
	private String spaId;

	@Column(name = "effective_issue_from_date")
	private LocalDate effectiveIssueFromDate;

	@Column(name = "effective_issue_to_date")
	private LocalDate effectiveIssueToDate;

	@Column(name = "effective_orig_issue_from_date")
	private LocalDate effectiveOrigIssueFromDate;

	@Column(name = "effective_orig_issue_to_date")
	private LocalDate effectiveOrigIssueToDate;

	@Column(name = "effective_uplift_from_date")
	private LocalDate effectiveUpliftFromDate;

	@Column(name = "effective_uplift_to_date")
	private LocalDate effectiveUpliftToDate;

	@Column(name = "description", nullable = false, length = 60)
	private String description;

	@Column(name = "utilization_apply", length = 1)
	private String utilizationApply;

	@Column(name = "review_date")
	private LocalDate reviewDate;

	@Column(name = "review_notes", length = 1000)
	private String reviewNotes;

	@Column(name = "status", nullable = false, length = 1)
	private String status;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}
	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
