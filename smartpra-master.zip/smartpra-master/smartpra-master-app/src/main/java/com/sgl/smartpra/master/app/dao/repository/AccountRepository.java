package com.sgl.smartpra.master.app.dao.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.AccountEntity;

@Repository
public interface AccountRepository
		extends JpaRepository<AccountEntity, Integer>, JpaSpecificationExecutor<AccountEntity> {

	Optional<AccountEntity> findByAccountAlphaCode(Optional<String> accountAlphaCode);

	List<AccountEntity> findByAccountAlphaCodeIn(List<String> accountAlphaCode);

	@Query(value = "select distinct(accountAlphaCode) from AccountEntity")
	List<String> getAccountAlphaCodeFromAccountMaster();

}
