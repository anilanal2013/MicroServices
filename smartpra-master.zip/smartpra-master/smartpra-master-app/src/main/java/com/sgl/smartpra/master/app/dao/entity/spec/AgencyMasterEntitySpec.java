package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.AgencyMasterEntity;

public class AgencyMasterEntitySpec {

	public static Specification<AgencyMasterEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (agencyMasterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), agencyMasterEntity.get("effectiveFromDate"),
				agencyMasterEntity.get("effectiveToDate"));

	}

	public static Specification<AgencyMasterEntity> isActive() {
		return (agencyMasterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyMasterEntity.get("activate"), true);
	}

	public static Specification<AgencyMasterEntity> equalsClientId(String clientId) {
		return (agencyMasterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyMasterEntity.get("clientId"), clientId);

	}

	public static Specification<AgencyMasterEntity> equalsAgencyCode(String agencyCode) {
		return (agencyMasterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyMasterEntity.get("agencyCode"), agencyCode);
	}

	public static Specification<AgencyMasterEntity> equalsReportingAgency(String reportingAgency) {
		return (agencyMasterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(agencyMasterEntity.get("reportingAgency"), reportingAgency);
	}

	public static Specification<AgencyMasterEntity> notEqualsAgencyDetailsId(Integer agencyId) {
		return (agencyMasterEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(agencyMasterEntity.get("agencyId"), agencyId);

	}

	public static Specification<AgencyMasterEntity> getSearchAllAgency(Optional<String> clientId,
			Optional<String> agencyCode, Optional<String> reportingAgency, Optional<String> agencyType,
			Optional<String> areaOfOperation, Optional<String> reportingAgencyType, Optional<String> cityCode,
			Optional<String> countryCode, Optional<Boolean> activate) {
		return (agencyMasterEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.equal(agencyMasterEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(agencyCode)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("agencyCode"),
						OptionalUtil.getValue(agencyCode) + "%"));
			}
			if (OptionalUtil.isPresent(reportingAgency)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("reportingAgency"),
						OptionalUtil.getValue(reportingAgency) + "%"));
			}
			if (OptionalUtil.isPresent(agencyType)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("agencyType"),
						OptionalUtil.getValue(agencyType) + "%"));
			}
			if (OptionalUtil.isPresent(areaOfOperation)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("areaOfOperation"),
						OptionalUtil.getValue(areaOfOperation) + "%"));
			}
			if (OptionalUtil.isPresent(reportingAgencyType)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("reportingAgencyType"),
						OptionalUtil.getValue(reportingAgencyType) + "%"));
			}
			if (OptionalUtil.isPresent(cityCode)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("cityCode"),
						OptionalUtil.getValue(cityCode) + "%"));
			}
			if (OptionalUtil.isPresent(countryCode)) {
				predicates.add(criteriaBuilder.equal(agencyMasterEntity.get("countryCode"),
						OptionalUtil.getValue(countryCode)));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(
						criteriaBuilder.equal(agencyMasterEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(agencyMasterEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AgencyMasterEntity> search(Optional<String> agencyCode,
			Optional<String> reportingAgency, Optional<String> agencyType, Optional<String> areaOfOperation,
			Optional<String> reportingAgencyType, Optional<Boolean> activate) {
		return (agencyMasterEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(agencyCode)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("agencyCode"),
						OptionalUtil.getValue(agencyCode) + "%"));
			}
			if (OptionalUtil.isPresent(reportingAgency)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("reportingAgency"),
						OptionalUtil.getValue(reportingAgency) + "%"));
			}
			if (OptionalUtil.isPresent(agencyType)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("agencyType"),
						OptionalUtil.getValue(agencyType) + "%"));
			}
			if (OptionalUtil.isPresent(areaOfOperation)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("areaOfOperation"),
						OptionalUtil.getValue(areaOfOperation) + "%"));
			}
			if (OptionalUtil.isPresent(reportingAgencyType)) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("reportingAgencyType"),
						OptionalUtil.getValue(reportingAgencyType) + "%"));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(
						criteriaBuilder.equal(agencyMasterEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(agencyMasterEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AgencyMasterEntity> getByAgencyCode(String agencyCode) {
		return (agencyMasterEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (!agencyCode.isEmpty()) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("agencyCode"), agencyCode));
			}
			predicates.add(criteriaBuilder.equal(agencyMasterEntity.get("activate"), Boolean.TRUE));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AgencyMasterEntity> findAll(AgencyMasterEntity agencyEntity, Optional<String> exceptionCall) {
		return (agencyMasterEntity, criteriaQuery , criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (isEmptyOrNull(agencyEntity.getClientId())) {
				predicates.add(criteriaBuilder.equal(agencyMasterEntity.get("clientId"), agencyEntity.getClientId()));
			}
			if (isEmptyOrNull(agencyEntity.getAgencyCode())) {
				predicates.add(
						criteriaBuilder.like(agencyMasterEntity.get("agencyCode"), agencyEntity.getAgencyCode() + "%"));
			}
			if (isEmptyOrNull(agencyEntity.getReportingAgency())) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("reportingAgency"),
						agencyEntity.getReportingAgency() + "%"));
			}
			if (isEmptyOrNull(agencyEntity.getAgencyType())) {
				predicates.add(
						criteriaBuilder.like(agencyMasterEntity.get("agencyType"), agencyEntity.getAgencyType() + "%"));
			}
			if (isEmptyOrNull(agencyEntity.getAreaOfOperation())) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("areaOfOperation"),
						agencyEntity.getAreaOfOperation() + "%"));
			}
			if (isEmptyOrNull(agencyEntity.getReportingAgencyType())) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("reportingAgencyType"),
						agencyEntity.getReportingAgencyType() + "%"));
			}
			if (isEmptyOrNull(agencyEntity.getCityCode())) {
				predicates.add(
						criteriaBuilder.like(agencyMasterEntity.get("cityCode"), agencyEntity.getCityCode() + "%"));
			}
			if (isEmptyOrNull(agencyEntity.getCountryCode())) {
				predicates.add(criteriaBuilder.like(agencyMasterEntity.get("countryCode"),
						agencyEntity.getCountryCode() + "%"));
			}
			if(!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (agencyEntity.getActivate() != null) {
					predicates.add(criteriaBuilder.equal(agencyMasterEntity.get("activate"), agencyEntity.getActivate()));
				}
				if (agencyEntity.getActivate() == null) {
					predicates.add(criteriaBuilder.equal(agencyMasterEntity.get("activate"), true));
				}
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private static boolean isEmptyOrNull(String value) {
		return value != null && !value.isEmpty();
	}
}
