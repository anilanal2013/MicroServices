package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.FOPService;
import com.sgl.smartpra.master.model.FOP;

@RestController
@RequestMapping("/fop")
public class FOPController {
	@Autowired
	@Qualifier("FOPService")
	private FOPService fopService;

	@PostMapping
	@ResponseStatus(value = HttpStatus.CREATED)
	public FOP createFOP(@Validated(Create.class) @RequestBody FOP fop) {
		return fopService.createFOP(fop);
	}

	@PutMapping("/{fopId}")
	@ResponseStatus(value = HttpStatus.OK)
	public FOP updateFOP(@PathVariable(value = "fopId") Integer fopId, @Validated(Update.class) @RequestBody FOP fop) {
		fop.setFopId(fopId);
		return fopService.updateFOP(fop);
	}

	@GetMapping("/search")
	public List<FOP> getAllFOP(@RequestParam(value = "fopCode", required = false) Optional<String> fopCode,
			@RequestParam(value = "fopIdentifier", required = false) Optional<String> fopIdentifier,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return fopService.getListOfFOP(fopCode,fopIdentifier, activate);
	}

	@GetMapping("/searchByTransactionType")
	public List<FOP> getListOfFOPByTransactionType(@RequestParam(value="fopIdentifier", required = false) String fopIdentifier,
																@RequestParam(value="transactionType", required = true) String transactionType){
		return fopService.getListOfFOPByTransactionType(fopIdentifier, transactionType);
	}

	@GetMapping("/searchByFopIdentifier")
	public List<FOP> getListOfFOPByFopIdentifier(@RequestParam(value="fopIdentifier", required = true) String fopIdentifier){
		return fopService.getListOfFOPByFopIdentifier(fopIdentifier);
	}

	@GetMapping("/{fopId}")
	public FOP getFOPByfopId(@PathVariable(value = "fopId") Integer fopId) {
		return fopService.getFOPByfopId(fopId);
	}

	@PutMapping("/{fopId}/deactivate")
	public void deactivateFOP(@PathVariable(value = "fopId") Integer fopId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		FOP fop = new FOP();
		fop.setFopId(fopId);
		fop.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		fopService.deactivateFOP(fop);
	}

	@PutMapping("/{fopId}/activate")
	public void activateFOP(@PathVariable(value = "fopId") Integer fopId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		FOP fop = new FOP();
		fop.setFopId(fopId);
		fop.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		fopService.activateFOP(fop);
	}

}
