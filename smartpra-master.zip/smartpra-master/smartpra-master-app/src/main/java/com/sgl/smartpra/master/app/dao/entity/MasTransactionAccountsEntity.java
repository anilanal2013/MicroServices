package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.Length;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author nacsanth
 *
 */
@Entity
@Table(name = "mas_transaction_accounts")
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicUpdate
@DynamicInsert
public class MasTransactionAccountsEntity extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="accounting_transaction_id")
	private Integer accountingTransactionId;
	@Length(min=1,max=2,message="Client Id is mandatory")
	@Column(name="client_id")
	private String clientId;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="scenario_number")
	@NotNull(message="Scenario number is mandatory")
	private MasScenarioEntity masScenarioEntity;
	@Column(name="transaction_serial_no")
	private Integer transactionSerialNo;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="account_definition_identifier")
	@NotNull(message="Account Definition Identifier is mandatory")
	private MassAccountingDefinitionEntity accountDefinitionId;
	@Column(name="account_alpha_code")
	@Length(min=1,max=3,message="Account Alpha Code is mandatory")
	private String accountAlphaCode;
	@Column(name="provisional_account_code")
	@Length(max=3)
	private String provisionalAccountCode;
	@Length(max=2)
	@Column(name="debit_credit_indicator")
	private String debitCreditIndicatior;
	@Length(max=1)
	@Column(name="balance_flag")
	private String balanceFlag;
	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate; 
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
	
}
