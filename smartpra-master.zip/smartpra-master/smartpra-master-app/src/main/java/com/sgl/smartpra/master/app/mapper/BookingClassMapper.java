package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.BookingClassEntity;
import com.sgl.smartpra.master.model.BookingClassModel;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface BookingClassMapper extends BaseMapper<BookingClassModel, BookingClassEntity> {

	BookingClassEntity mapToEntity(BookingClassModel bookingClassModel,
			@MappingTarget BookingClassEntity bookingClassEntity);

	@Mapping(source = "bookingClassId", target = "bookingClassId", ignore = true)
	BookingClassEntity mapToEntity(BookingClassModel bookingClassModel);
}
