package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.master.app.dao.StockDetailDao;
import com.sgl.smartpra.master.app.dao.entity.StcokDetails;
import com.sgl.smartpra.master.app.dao.entity.spec.StockDetailEntitySpecification;
import com.sgl.smartpra.master.app.repository.StockDetailsRepository;

@Component
@Repository
@Transactional(rollbackFor=DataAccessException.class)
public class StockDetailAllocationDaoImpl implements StockDetailDao {

	@Autowired
	private StockDetailsRepository stockDetailsRepository;

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<StcokDetails>  getBlockListedStockDetails(long documentNumber, Integer stockId) {
		return stockDetailsRepository.findAll(
				Specification.where(StockDetailEntitySpecification.equalsDocumentNumber(String.valueOf(documentNumber))
						.and(StockDetailEntitySpecification.equalStockId(stockId))
						.and((StockDetailEntitySpecification.isNotNullBlockListReason())
						.or(StockDetailEntitySpecification.isTrueIsUtilized()))
						.and(StockDetailEntitySpecification.isTrueisActive())
						));
	}

	@Override
	public List<StcokDetails> getStockDetailByEffective(long documentNumber, Integer stockId, String clientId,
			LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return stockDetailsRepository.findAll(
				Specification.where(StockDetailEntitySpecification.equalStockId(stockId))
				.and(StockDetailEntitySpecification.equalClientId(clientId))
				.and(StockDetailEntitySpecification.equalsDocumentNumber(String.valueOf(documentNumber)))
				.and(
						(StockDetailEntitySpecification.betweenDates(effectiveFromDate))
					.or(StockDetailEntitySpecification.betweenDates(effectiveToDate))
					)
				);
	}

	@Override
	public String getMaxDocumentNumber(Integer stockId, String clientId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return stockDetailsRepository.getMaxDocumentNumber(stockId, clientId, effectiveFromDate, effectiveToDate);
	}

	@Override
	public void deleteUnusedStock(Integer stockId, String clientId, String documentNumber, LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		stockDetailsRepository.deleteUnusedStock(stockId, clientId, documentNumber, effectiveFromDate, effectiveToDate);
	}
	
}
