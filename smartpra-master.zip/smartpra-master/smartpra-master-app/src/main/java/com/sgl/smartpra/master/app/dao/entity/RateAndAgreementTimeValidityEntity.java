package com.sgl.smartpra.master.app.dao.entity;


import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_rate_agmt_time_validity",schema = "SmartPRAMaster")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class RateAndAgreementTimeValidityEntity extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
	  	@Id
	    @Column(name = "rate_agreemt_time_validity_id")
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer rateAgreementTimeValID;
	  	
	    @Column(name = "client_id", nullable = false, length = 2)
	    private String clientId;
	  	
	    @Column(name = "rate_agreement_id", nullable = false, length = 2)
	    private Integer rateAgreementId;
	    
	   
	    
	    @Column(name = "monday")
	    @Convert(converter = BooleanToStringConverter.class)
	    private Boolean monday;
	    
	    @Column(name = "tuesday")
	    @Convert(converter = BooleanToStringConverter.class)
	    private Boolean tuesday;

	    @Column(name = "wednesday")
	    @Convert(converter = BooleanToStringConverter.class)
	    private Boolean wednesday;

	    @Column(name = "thursday")
	    @Convert(converter = BooleanToStringConverter.class)
	    private Boolean thursday;

	    @Column(name = "friday")
	    @Convert(converter = BooleanToStringConverter.class)
	    private Boolean friday;

	    @Column(name = "saturday")
	    @Convert(converter = BooleanToStringConverter.class)
	    private Boolean saturday;

	    @Column(name = "sunday")
	    @Convert(converter = BooleanToStringConverter.class)
	    private Boolean sunday;

	    @Column(name = "effective_from_date", nullable = false)
	    private LocalDate effectiveFromDate;

	    @Column(name = "effective_to_date", nullable = false)
	    private LocalDate effectiveToDate;

	    @PrePersist
	    public void prePersist() {
	        setCreatedDate(LocalDateTime.now());
	    }

	    @PreUpdate
	    public void preUpdate() {
	        setLastUpdatedDate(LocalDateTime.now());
	    }
}
