package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.repository.entity.ReasonCodeEntity;

public class ReasonCodeEntitySpec {

	public static Specification<ReasonCodeEntity> search(Optional<String> clientId, Optional<String> reasonType, Optional<String> reasonCategory,
			Optional<String> isCpnBreakdownMandatory, Optional<Boolean> activate) {
		return (reasonCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.equal(reasonCodeEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(reasonType)) {
				predicates.add(
						criteriaBuilder.like(reasonCodeEntity.get("reasonType"), OptionalUtil.getValue(reasonType)));
			}
			if (OptionalUtil.isPresent(reasonCategory)) {
				predicates.add(criteriaBuilder.like(reasonCodeEntity.get("reasonCategory"),
						OptionalUtil.getValue(reasonCategory)));
			}
			if (OptionalUtil.isPresent(isCpnBreakdownMandatory)) {
				predicates.add(criteriaBuilder.like(reasonCodeEntity.get("isCpnBreakdownMandatory"),
						OptionalUtil.getValue(isCpnBreakdownMandatory)));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates
						.add(criteriaBuilder.equal(reasonCodeEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(reasonCodeEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ReasonCodeEntity> equalsClientId(String clientId) {
		return (reasonCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(reasonCodeEntity.get("clientId"), clientId);
	}

	public static Specification<ReasonCodeEntity> equalsReasonCode(String reasonCode) {
		return (reasonCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(reasonCodeEntity.get("reasonCode"), reasonCode);
	}

	public static Specification<ReasonCodeEntity> notEqualsSourceCodeId(Integer reasonCodeId) {
		return (reasonCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(reasonCodeEntity.get("reasonCodeId"), reasonCodeId);
	}

}
