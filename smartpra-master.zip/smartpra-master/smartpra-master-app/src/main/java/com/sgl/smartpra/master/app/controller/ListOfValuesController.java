

package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.ListOfValues;

@RestController
public class ListOfValuesController {

	@Autowired
	private ListOfValuesService lovService;

	@GetMapping("/listofvalues/{clientId}/{tableName}/{columnName}")
	public List<String> getListOfValues(@PathVariable(value = "clientId") Optional<String> clientId,
			@PathVariable(value = "tableName") Optional<String> tableName,
			@PathVariable(value = "columnName") Optional<String> columnName) {
		return lovService.getListOfValues(clientId, tableName, columnName);
	}

	@PutMapping("/listofvalues/{listofvaluesId}/deactivate")
	public void deactivateListOfValues(@Valid @PathVariable(value = "listofvaluesId") Integer listofvaluesId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		lovService.deactivateListOfValues(listofvaluesId, lastUpdatedBy);
	}

	@PutMapping("/listofvalues/{listofvaluesId}/activate")
	public void activateListOfValues(@Valid @PathVariable(value = "listofvaluesId") Integer listofvaluesId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		lovService.activateListOfValues(listofvaluesId, lastUpdatedBy);
	}
	
	
	@GetMapping("/listofvalues/{clientId}/{tableName}/{columnName}/{fieldValue}")
	public ListOfValues getListOfValues(@PathVariable(value = "clientId") Optional<String> clientId,
			@PathVariable(value = "tableName") Optional<String> tableName,
			@PathVariable(value = "columnName") Optional<String> columnName,
			@PathVariable(value = "fieldValue") Optional<String> fieldValue) {
		return lovService.getListOfValues(clientId, tableName, columnName,fieldValue);
	}

	@GetMapping("/listofvalueslist/{clientId}/{tableName}/{columnName}")
	public List<ListOfValues> getListOfValuesList(@PathVariable(value = "clientId") Optional<String> clientId,
			@PathVariable(value = "tableName") Optional<String> tableName,
			@PathVariable(value = "columnName") Optional<String> columnName) {
		return lovService.getListOfValuesList(clientId, tableName, columnName);
	}
	
	@GetMapping("/listofvalues/{listofvaluesId}")
	public ListOfValues getListOfValue(@PathVariable(value = "listofvaluesId") Integer listofvaluesId) {
		return lovService.getListOfValuesByLovId(listofvaluesId);
	}

}
