package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "mas_region")
@DynamicUpdate
@DynamicInsert
public class RegionEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "region_id")
	private Integer regionId;

	@Column(name = "region_code", nullable = false, length = 6)
	private String regionCode;

	@Column(name = "client_id", nullable = true, length = 2)
	private String clientId;

	@Column(name = "region_name", nullable = false, length = 30)
	private String regionName;

	@Column(name = "country_code_list", nullable = false, length = 100)
	private String countryCodeList;

	@Column(name = "continent_name", nullable = false, length = 13)
	private String continentName;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
