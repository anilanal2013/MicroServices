package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.sgl.smartpra.master.model.CreditCard;

public interface CreditCardService {

	public List<CreditCard> getAllCreditCard(CreditCard creditCard, Optional<String> exceptionCall);

	public CreditCard getCreditCardById(Integer creditCardId);

	public CreditCard createCreditCard(CreditCard creditCard);

	public CreditCard updateCreditCard(Integer creditCardId, CreditCard creditCard);

	public void deactivateCreditCard(@Valid Integer creditCardId, String lastUpdatedBy);

	public void activateCreditCard(@Valid Integer creditCardId, String lastUpdatedBy);

}
