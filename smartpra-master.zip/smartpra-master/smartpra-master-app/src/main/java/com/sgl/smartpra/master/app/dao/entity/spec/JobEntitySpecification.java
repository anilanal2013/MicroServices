package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.JobEntity;
import com.sgl.smartpra.master.model.Job;

public final class JobEntitySpecification {

	private static void orderByAsc(Root<JobEntity> jobEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String effectiveToDate) {
		criteriaQuery.orderBy(criteriaBuilder.asc(jobEntity.get(effectiveToDate)));
	}

	public static Specification<JobEntity> search(Job job) {
		return (jobEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (OptionalUtil.isPresent(job.getClientId())) {
				predicates.add(criteriaBuilder.equal(jobEntity.get("clientId"), OptionalUtil.getValue(job.getClientId())));
			}
			if (OptionalUtil.isPresent(job.getJobName())) {
				predicates.add(
						criteriaBuilder.like(jobEntity.get("jobName"), OptionalUtil.getValue(job.getJobName()) + "%"));
			}
			if (OptionalUtil.isPresent(job.getJobType())) {
				predicates.add(criteriaBuilder.like(jobEntity.get("jobType"), OptionalUtil.getValue(job.getJobType()) + "%"));
			}
			if (OptionalUtil.isPresent(job.getCategory())) {
				predicates.add(
						criteriaBuilder.like(jobEntity.get("category"), OptionalUtil.getValue(job.getCategory()) + "%"));
			}
			if (OptionalUtil.isPresent(job.getModuleName())) {
				predicates.add(criteriaBuilder.like(jobEntity.get("moduleName"), OptionalUtil.getValue(job.getModuleName()) + "%"));
			}
			if (OptionalUtil.isPresent(job.getFrequency())) {
				predicates.add(
						criteriaBuilder.like(jobEntity.get("frequency"), OptionalUtil.getValue(job.getFrequency()) + "%"));
			}
			if (OptionalUtil.isPresent(job.getSkipIndicator())) {
				predicates.add(criteriaBuilder.equal(jobEntity.get("skipIndicator"), OptionalUtil.getValue(job.getSkipIndicator())));
			}
			if (OptionalUtil.isPresent(job.getTimeLimitIndicator())) {
				predicates.add(
						criteriaBuilder.equal(jobEntity.get("timeLimitIndicator"), OptionalUtil.getValue(job.getTimeLimitIndicator())));
			}
			if (OptionalUtil.isPresent(job.getEffectiveFromDate()) && OptionalUtil.isPresent(job.getEffectiveToDate())) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(job.getEffectiveFromDate())),
								jobEntity.get("effectiveFromDate"), jobEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(job.getEffectiveToDate())),
								jobEntity.get("effectiveFromDate"), jobEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(job.getEffectiveFromDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(job.getEffectiveFromDate())),
							jobEntity.get("effectiveFromDate"), jobEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(job.getEffectiveToDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(job.getEffectiveToDate())),
							jobEntity.get("effectiveFromDate"), jobEntity.get("effectiveToDate")));
				}
			}
			orderByAsc(jobEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<JobEntity> searchByEffectiveDate(Optional<String> effectiveFromDate) {
		return (jobEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (OptionalUtil.isPresent(effectiveFromDate)) {
				predicates.add(criteriaBuilder.and(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								jobEntity.get("effectiveFromDate"), jobEntity.get("effectiveToDate")),
						criteriaBuilder.or(criteriaBuilder
								.greaterThanOrEqualTo(jobEntity.get("effectiveFromDate"), OptionalUtil.getLocalDateValue(effectiveFromDate)),
								criteriaBuilder.or(criteriaBuilder
										.lessThanOrEqualTo(jobEntity.get("effectiveFromDate"), OptionalUtil.getLocalDateValue(effectiveFromDate))
										))));
						
			}
			
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<JobEntity> equalsJobName(String jobName) {
		return (jobEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(jobEntity.get("jobName"), jobName);
	}

	public static Specification<JobEntity> equalsClientId(String clientId) {
		return (jobEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(jobEntity.get("clientId"), clientId);
	}

	public static Specification<JobEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveFromDate) {
		return (jobEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
		criteriaBuilder.literal(effectiveFromDate), jobEntity.get("effectiveFromDate"),
		jobEntity.get("effectiveToDate"));
	}

	public static Specification<JobEntity> greaterThanOrEqualToEffectiveFromDate(LocalDate effectiveFromDate) {
		return (jobEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(jobEntity.get("effectiveFromDate"), effectiveFromDate);
	}

	public static Specification<JobEntity> lessThanOrEqualToEffectiveToDate(LocalDate effectiveToDate) {
		return (jobEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(jobEntity.get("effectiveToDate"), effectiveToDate);
	}


	public static Specification<JobEntity> notEqualsJobId(Integer jobId) {
		return (jobEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(jobEntity.get("jobId"), jobId);

	}
}