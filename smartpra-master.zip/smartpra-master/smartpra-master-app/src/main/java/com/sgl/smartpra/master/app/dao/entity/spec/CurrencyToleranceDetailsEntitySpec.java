package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.CurrencyToleranceDetailsEntity;

public class CurrencyToleranceDetailsEntitySpec {
	
	

	public CurrencyToleranceDetailsEntitySpec() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";
	public static final String EFFECTIVE_TO_DATE = "effectiveToDate";

	public static Specification<CurrencyToleranceDetailsEntity> search(String currencyCode, String clientId, 
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return (currencyToleranceDetailsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (clientId != null) {
				predicates.add(
						criteriaBuilder.equal(currencyToleranceDetailsEntity.get("clientId"), clientId));
			}
			if (currencyCode != null) {
				predicates.add(
						criteriaBuilder.like(currencyToleranceDetailsEntity.get("currencyCode"), currencyCode + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								currencyToleranceDetailsEntity.get(EFFECTIVE_FROM_DATE),
								currencyToleranceDetailsEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								currencyToleranceDetailsEntity.get(EFFECTIVE_FROM_DATE),
								currencyToleranceDetailsEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(currencyToleranceDetailsEntity.get(EFFECTIVE_FROM_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate)),
						criteriaBuilder.between(currencyToleranceDetailsEntity.get(EFFECTIVE_TO_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.getValue(effectiveFromDate) != null
						&& !OptionalUtil.getValue(effectiveFromDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							currencyToleranceDetailsEntity.get(EFFECTIVE_FROM_DATE),
							currencyToleranceDetailsEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(effectiveToDate) && OptionalUtil.getValue(effectiveToDate) != null
						&& !OptionalUtil.getValue(effectiveToDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							currencyToleranceDetailsEntity.get(EFFECTIVE_FROM_DATE),
							currencyToleranceDetailsEntity.get(EFFECTIVE_TO_DATE)));
				}
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<CurrencyToleranceDetailsEntity> equalsClientId(String clientId) {
		return (currencyToleranceDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(currencyToleranceDetailsEntity.get("clientId"), clientId);
	}

	public static Specification<CurrencyToleranceDetailsEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (currencyToleranceDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), currencyToleranceDetailsEntity.get(EFFECTIVE_FROM_DATE),
				currencyToleranceDetailsEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<CurrencyToleranceDetailsEntity> greaterThanOrEqualTo(LocalDate effectiveFromDate) {
		return (currencyToleranceDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(currencyToleranceDetailsEntity.get(EFFECTIVE_FROM_DATE), effectiveFromDate);
	}

	public static Specification<CurrencyToleranceDetailsEntity> lessThanOrEqualTo(LocalDate effectiveToDate) {
		return (currencyToleranceDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(currencyToleranceDetailsEntity.get(EFFECTIVE_TO_DATE), effectiveToDate);

	}

	public static Specification<CurrencyToleranceDetailsEntity> equalsCurrencyCode(String currencyCode) {
		return (currencyToleranceDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(currencyToleranceDetailsEntity.get("currencyCode"), currencyCode);
	}

	public static Specification<CurrencyToleranceDetailsEntity> notEqualsCurrencyToleranceId(
			Integer currencyToleranceDtlId) {
		return (currencyToleranceDetailsEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(currencyToleranceDetailsEntity.get("currencyToleranceDtlId"), currencyToleranceDtlId);
	}

}