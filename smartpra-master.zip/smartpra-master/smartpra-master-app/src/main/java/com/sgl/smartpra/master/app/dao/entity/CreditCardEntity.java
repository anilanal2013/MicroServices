package com.sgl.smartpra.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "mas_credit_card")
@DynamicInsert
@DynamicUpdate
@EqualsAndHashCode(callSuper = false)
public class CreditCardEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "credit_card_id")
	private Integer creditCardId;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "agreement_reference")
	private String agreementReference;

	@Column(name = "atrribute_1")
	private String atrribute1;

	@Column(name = "atrribute_2")
	private String atrribute2;

	@Column(name = "atrribute_3")
	private String atrribute3;

	@Column(name = "atrribute_4")
	private String atrribute4;

	@Column(name = "atrribute_5")
	private String atrribute5;

	@Column(name = "bill_address")
	private String billAddress;

	@Column(name = "billing_frequency")
	private String billingFrequency;

	@Column(name = "cc_company_code")
	private String ccCompanyCode;

	@Column(name = "cc_company_name")
	private String ccCompanyName;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "contact_email_id")
	private String contactEmailId;

	@Column(name = "contact_fax_no")
	private String contactFaxNo;

	@Column(name = "contact_person")
	private String contactPerson;

	@Column(name = "contact_tel_no")
	private String contactTelNo;

	@Column(name = "cost_centre")
	private String costCentre;

	@Column(name = "locally_invoiced")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean locallyInvoiced;

	@Column(name = "max_length")
	private Integer maxLength;

	@Column(name = "min_length")
	private Integer minLength;

	@Column(name = "profit_centre")
	private String profitCentre;

	@Column(name = "service_charge")
	private BigDecimal serviceCharge;

	@Column(name = "starting_digits")
	private Integer startingDigits;

	@Column(name = "uatp_airline_code")
	private String uatpAirlineCode;

	@Column(name = "uatp_flag")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean uatpFlag;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
