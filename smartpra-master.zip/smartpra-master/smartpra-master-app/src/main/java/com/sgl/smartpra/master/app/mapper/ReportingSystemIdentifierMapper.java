package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.ReportingSystemIdentifierEntity;
import com.sgl.smartpra.master.model.ReportingSystemIdentifier;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ReportingSystemIdentifierMapper
		extends BaseMapper<ReportingSystemIdentifier, ReportingSystemIdentifierEntity> {

	@Mapping(source = "rpsiAutoId", target = "rpsiAutoId", ignore = true)
	ReportingSystemIdentifierEntity mapToEntity(ReportingSystemIdentifier reportingSystemIdentifier);

	ReportingSystemIdentifierEntity mapToEntity(ReportingSystemIdentifier reportingSystemIdentifier,
			@MappingTarget ReportingSystemIdentifierEntity reportingSystemIdentifierEntity);

}
