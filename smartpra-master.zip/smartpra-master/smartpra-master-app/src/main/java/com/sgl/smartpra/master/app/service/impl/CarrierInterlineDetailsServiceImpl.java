package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.CarrierDetail;
import com.sgl.smartpra.global.master.model.Country;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.configuration.InvoiceCurrencyConfig;
import com.sgl.smartpra.master.app.controller.CustomerController;
import com.sgl.smartpra.master.app.dao.CarrierInterlineDetailsDao;
import com.sgl.smartpra.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.master.app.mapper.CarrierInterlineDetailsMapper;
import com.sgl.smartpra.master.app.repository.CarrierInterlineDetailsRepository;
import com.sgl.smartpra.master.app.repository.entity.CarrierInterlineDetailsEntity;
import com.sgl.smartpra.master.app.service.CarrierInterlineDetailsService;
import com.sgl.smartpra.master.enums.SettlementMethod;
import com.sgl.smartpra.master.model.CarrierInterlineDetailsModel;
import com.sgl.smartpra.master.model.Customer;

@Service
@Transactional
public class CarrierInterlineDetailsServiceImpl implements CarrierInterlineDetailsService {

	@Autowired
	private CarrierInterlineDetailsRepository carrierInterlineDetailsRepository;

	@Autowired
	private CarrierInterlineDetailsMapper carrierInterlineDetailsMapper;

	@Autowired
	CarrierInterlineDetailsDao carrierInterlineDetailsDao;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private CustomerController customerController;

	@Autowired
	InvoiceCurrencyConfig invoiceCurrencyConfig;

	public static final String CARRIERINTERLINEDETAILSIDINACTIVE = "Carrier Interline Detail is not active";
	public static final String CARRIERINTERLINEDETAILSIDACTIVE = "Carrier Interline Detail is already in active state";
	public static final String CARRIERINTERLINEDETAILS = "Carrier Interline Details";
	public static final String LASTUPDATEDBYMSG = "LastUpdatedBy should be minimum of 1 and maximum of 15 characters";
	public static final String LASTUPDATEDBYMENDATORYMSG = "Please provide lastupdatedby";
	public static final String CARRIERINTERLINEDETAILSID = "Record not found";
	private static final String INVALID_CARRIER_CODE = "Invalid Carrier code ";
	private static final String INVALID_CURRENCY_CODE = "Invalid Billing Currency code ";
	private static final String INVALID_IB_CURRENCY_CODE = "IB Tolerance Check Currency code ";
	private static final String INVALID_COUNTRY_CODE = "Invalid Country code";
	private static final String MIS_MATCH = "Mismatch between: Carrier code ";
	private static final String CARRIER_INTERLINE_ID = " and Carrier Interline details ID ";
	String carrierCode1 = null;
	String carrierName1 = null;
	String carrierName2 = null;
	private static final String INVALID_CLIENTID = "Invalid Client code ";
	public static final String RECORD_NOT_FOUND = "Record not found";
	private static final String IBTOLERANCE_PATTERN = "^\\d{0,13}(\\.\\d{0,3})?$";
	private Boolean operationCheck = false;
	private static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	private static final String CARRIER_CODE_MISMATCH = "Carrier code in Json should be same as URL ";

	private static final String ICH = "ICH";
	private static final String BOTH = "BOTH";
	private static final String ACH = "ACH";

	@Override
	public List<CarrierInterlineDetailsModel> getListOfCarrierInterlineDetailsByEffectiveDate(
			Optional<String> carrierCode, Optional<String> clientId, Optional<String> effectiveDate) {
		carrierCodeToCarrierDesignatorValidation(OptionalUtil.getValue(carrierCode));
		return carrierInterlineDetailsMapper
				.mapToModel(carrierInterlineDetailsDao.findAll(carrierCode, clientId, effectiveDate));

	}

	@Override
	public boolean isValidPassengerSis(Optional<String> carrierCode, Optional<Boolean> passengerSis,
			Optional<String> effectiveDate) {
		List<CarrierInterlineDetailsEntity> carrierInterlineDetailsList = carrierInterlineDetailsDao
				.findAllValidPassengerSis(carrierCode, passengerSis, effectiveDate);
		return Objects.nonNull(carrierInterlineDetailsList) && carrierInterlineDetailsList.size() > 0;
	}

	@Override
	public CarrierInterlineDetailsModel getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(
			Optional<String> carrierCode, Optional<String> effectiveDate) {
		Optional<CarrierInterlineDetailsEntity> carrierInterlineDetails = carrierInterlineDetailsDao.find(carrierCode,
				effectiveDate);
		if (carrierInterlineDetails.isPresent()) {
			return carrierInterlineDetailsMapper.mapToModel(carrierInterlineDetails.get());
		}
		throw new BusinessException("Carrier Interline Details not found");
	}

	@Override
	public CarrierInterlineDetailsModel getCarrierInterlineByCarrierInterlineDtlId(Optional<String> carrierCode,
			Integer carrierInterlineDtlId) {
		// carrier code validation
		carrierCodeToCarrierDesignatorValidation(OptionalUtil.getValue(carrierCode));
		Optional<CarrierInterlineDetailsEntity> carrierInterlineDetailsEntity = carrierInterlineDetailsDao
				.findById(carrierInterlineDtlId);
		if (carrierInterlineDetailsEntity.isPresent()) {
			if (carrierInterlineDetailsEntity.get().getActivate()) {
				return carrierInterlineDetailsMapper.mapToModel(carrierInterlineDetailsEntity.get());
			}
			throw new BusinessException(CARRIERINTERLINEDETAILSIDINACTIVE);
		} else {
			throw new BusinessException(MIS_MATCH + carrierCode + CARRIER_INTERLINE_ID + carrierInterlineDtlId);
		}
	}

	@Override
	public CarrierInterlineDetailsModel createCarrierInterlineDetail(String carrierCode,
			CarrierInterlineDetailsModel carrierInterlineDetailsModel) {

		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getCarrierCode())) {
			if (!carrierCode.equalsIgnoreCase(OptionalUtil.getValue(carrierInterlineDetailsModel.getCarrierCode()))) {
				throw new BusinessException(CARRIER_CODE_MISMATCH);
			}
		} else {
			carrierInterlineDetailsModel.setCarrierCode(Optional.of(carrierCode));
		}

		// carrier code validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getCarrierCode())) {
			carrierCodeToCarrierDesignatorValidation(
					OptionalUtil.getValue(carrierInterlineDetailsModel.getCarrierCode()));
		}

		carrierInterlineDetailsModel.setActivate(Boolean.TRUE);
		carrierInterlineDetailsModel.setCreatedDate(LocalDateTime.now());

		// date validation
		boolean dateCheck = OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveToDate())
				.isAfter(OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveFromDate()));
		if (!dateCheck) {
			throw new BusinessException("Effective To Date "
					+ OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveToDate())
					+ " should be greater than Effective From Date "
					+ OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveFromDate()));
		}

		validateDate(OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveToDate()),
				OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveFromDate()));

		// Passenger sis
		if (carrierInterlineDetailsModel.getPassengerSis().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setPassengerSis(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getPassengerSis().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setPassengerSis(Optional.of(Boolean.FALSE));
		}

		// Misc sis
		if (carrierInterlineDetailsModel.getMiscSis().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setMiscSis(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getMiscSis().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setMiscSis(Optional.of(Boolean.FALSE));
		}

		// billing thru clearing house
		if (OptionalUtil.getValue(carrierInterlineDetailsModel.getPassengerSis()).equals(true)
				|| OptionalUtil.getValue(carrierInterlineDetailsModel.getMiscSis()).equals(true)) {
			if (!OptionalUtil.getValue(carrierInterlineDetailsModel.getBillingThruClearingHouse()).equals(true)) {
				throw new BusinessException(
						"IF 'PAX SIS' or 'MISC SIS' are active then ‘Billing Through Clearing House’ should be active");
			}
		}
		if (OptionalUtil.getValue(carrierInterlineDetailsModel.getPassengerSis()).equals(false)
				&& OptionalUtil.getValue(carrierInterlineDetailsModel.getMiscSis()).equals(false)) {
			if (!OptionalUtil.getValue(carrierInterlineDetailsModel.getBillingThruClearingHouse()).equals(false)) {
				throw new BusinessException(
						"IF 'PAX SIS' or 'MISC SIS' are active then ‘Billing Through Clearing House’ should be active");
			}
		}

		// validation for billing thru clearing house
		if (carrierInterlineDetailsModel.getPassengerSis().toString().equalsIgnoreCase("True")
				|| carrierInterlineDetailsModel.getMiscSis().toString().equalsIgnoreCase("True")) {
			if (!carrierInterlineDetailsModel.getBillingThruClearingHouse().toString().equalsIgnoreCase("True")) {
				throw new BusinessException("Billing Through Clearing House should be active");
			}
		}

		// ref data to is idec
		if (carrierInterlineDetailsModel.getReferenceDataToIsIdec().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setReferenceDataToIsIdec(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getReferenceDataToIsIdec().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setReferenceDataToIsIdec(Optional.of(Boolean.FALSE));
		}
		// mita for pax
		if (carrierInterlineDetailsModel.getMitaForPax().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setMitaForPax(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getMitaForPax().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setMitaForPax(Optional.of(Boolean.FALSE));
		}
		// digital signature
		if (carrierInterlineDetailsModel.getDigitalSignature().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setDigitalSignature(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getDigitalSignature().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setDigitalSignature(Optional.of(Boolean.FALSE));
		}
		// separate code share invoice
		if (carrierInterlineDetailsModel.getSeparateCodeShareInvoice().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setSeparateCodeShareInvoice(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getSeparateCodeShareInvoice().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setSeparateCodeShareInvoice(Optional.of(Boolean.FALSE));
		}
		// sas check required
		if (carrierInterlineDetailsModel.getSacCheckRequired().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setSacCheckRequired(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getSacCheckRequired().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setSacCheckRequired(Optional.of(Boolean.FALSE));
		}
		// sale check required
		if (carrierInterlineDetailsModel.getSaleCheckRequired().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setSaleCheckRequired(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getSaleCheckRequired().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setSaleCheckRequired(Optional.of(Boolean.FALSE));
		}
		// skip weekly billing
		if (carrierInterlineDetailsModel.getSkipWeeklyBilling().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setSkipWeeklyBilling(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getSkipWeeklyBilling().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setSkipWeeklyBilling(Optional.of(Boolean.FALSE));
		}
		// is_cpn_proc_dt_wkly_bill_lmt
		if (carrierInterlineDetailsModel.getIsCpnProcDtWklyBillLmt().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setIsCpnProcDtWklyBillLmt(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getIsCpnProcDtWklyBillLmt().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setIsCpnProcDtWklyBillLmt(Optional.of(Boolean.FALSE));
		}
		// customer code validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getCustomerCode())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getCustomerCode()))) {
			List<Customer> customer = customerController.getAllCustomer(carrierInterlineDetailsModel.getCustomerCode(),
					null, null, null, null, Optional.of(true));
			if (customer.isEmpty()) {
				throw new BusinessException("Invalid Customer code "
						+ OptionalUtil.getValue(carrierInterlineDetailsModel.getCustomerCode()).trim());
			}
		}
		// currency code validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getBillingCurrency())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getBillingCurrency()))) {
			currencyToCurrencyCodeValidation(OptionalUtil.getValue(carrierInterlineDetailsModel.getBillingCurrency()));
		}
		// IB tolerance check currency validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceCheckCurrency()) && StringUtils
				.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceCheckCurrency()))) {
			ibcurrencyToCurrencyCodeValidation(
					OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceCheckCurrency()));
		}

		validateIbToleranceGrossAmount(carrierInterlineDetailsModel);
		validateIbToleranceIscAmount(carrierInterlineDetailsModel);
		validateIbToleranceTaxAmount(carrierInterlineDetailsModel);
		validateIbToleranceTimeLimit(carrierInterlineDetailsModel);

		// EuRegistration country code validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getEuRegistrationCountryCode()) && StringUtils
				.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getEuRegistrationCountryCode()))) {
			countryToCountryCodeValidation(
					OptionalUtil.getValue(carrierInterlineDetailsModel.getEuRegistrationCountryCode()));
		}
		// client code validation
		if (OptionalUtil.getValue(carrierInterlineDetailsModel.getClientId()) != null) {
			clientIdToCarrierDesignatorValidation(OptionalUtil.getValue(carrierInterlineDetailsModel.getClientId()));
		}
		// zone validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getZone())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()))) {
			if (!(OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()).equals("A")
					|| OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()).equals("B")
					|| OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()).equals("C")
					|| OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()).equals("D"))) {
				throw new BusinessException("Zone valid values are only 'A'|'B'|'C'|'D'");
			}
		}

		if (!OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceGrossAmount()) && StringUtils
				.isEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceGrossAmount()))) {
			carrierInterlineDetailsModel.setIbToleranceGrossAmount(null);
		}

		if (!OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceIscAmount())
				&& StringUtils.isEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceIscAmount()))) {
			carrierInterlineDetailsModel.setIbToleranceIscAmount(null);
		}

		if (!OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceTaxAmount())
				&& StringUtils.isEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceTaxAmount()))) {
			carrierInterlineDetailsModel.setIbToleranceTaxAmount(null);
		}

		if (!OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceTimeLimit())
				&& StringUtils.isEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceTimeLimit()))) {
			carrierInterlineDetailsModel.setIbToleranceTimeLimit(null);
		}

		// unique key validation
		if (carrierInterlineDetailsDao.getOverLapRecordCount(
				OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveToDate()),
				OptionalUtil.getValue(carrierInterlineDetailsModel.getClientId()),
				OptionalUtil.getValue(carrierInterlineDetailsModel.getCarrierCode())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}

		if (carrierInterlineDetailsModel.getUatpApplicableInd() == null) {
			carrierInterlineDetailsModel.setUatpApplicableInd(Boolean.FALSE);
		}

		return carrierInterlineDetailsMapper.mapToModel(carrierInterlineDetailsRepository
				.save(carrierInterlineDetailsMapper.mapToEntity(carrierInterlineDetailsModel)));
	}

	@Override
	public CarrierInterlineDetailsModel updateCarrierInterlineDetail(String carrierCode, int carrierInterlineDtlId,
			CarrierInterlineDetailsModel carrierInterlineDetailsModel) {

		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getCarrierCode())) {
			if (!carrierCode.equalsIgnoreCase(OptionalUtil.getValue(carrierInterlineDetailsModel.getCarrierCode()))) {
				throw new BusinessException(CARRIER_CODE_MISMATCH);
			}
		} else {
			carrierInterlineDetailsModel.setCarrierCode(Optional.of(carrierCode));
		}

		Optional<CarrierInterlineDetailsEntity> carrierInterlineDetailsEntity = Optional
				.ofNullable(carrierInterlineDetailsRepository.findById(carrierInterlineDtlId))
				.orElseThrow(() -> new BusinessException(CARRIERINTERLINEDETAILSID));

		if (!carrierInterlineDetailsEntity.isPresent()) {
			throw new ResourceNotFoundException(CARRIERINTERLINEDETAILS, "code", CARRIERINTERLINEDETAILSID);
		}

		if (!carrierInterlineDetailsEntity.get().getActivate()) {
			throw new BusinessException(CARRIERINTERLINEDETAILSIDINACTIVE);
		}

		// carrier code validation/
		if (carrierInterlineDetailsEntity.get().getCarrierCode().equals(carrierCode)) {
			carrierCodeToCarrierDesignatorValidation(carrierCode);
		} else {
			throw new BusinessException(MIS_MATCH + carrierCode + CARRIER_INTERLINE_ID + carrierInterlineDtlId);
		}

		// date validation
		boolean dateCheck = OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveToDate())
				.isAfter(OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveFromDate()));
		if (!dateCheck) {
			throw new BusinessException("Effective To date "
					+ OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveToDate())
					+ " should be greater than Effective From date "
					+ OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveFromDate()));
		}

		// validate Date
		validateDate(OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveToDate()),
				OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveFromDate()));

		// passenger sis
		if (carrierInterlineDetailsModel.getPassengerSis().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setPassengerSis(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getPassengerSis().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setPassengerSis(Optional.of(Boolean.FALSE));
		}

		// Misc sis
		if (carrierInterlineDetailsModel.getMiscSis().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setMiscSis(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getMiscSis().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setMiscSis(Optional.of(Boolean.FALSE));
		}

		// billing thru clearing house
		if (OptionalUtil.getValue(carrierInterlineDetailsModel.getPassengerSis()).equals(true)
				|| OptionalUtil.getValue(carrierInterlineDetailsModel.getMiscSis()).equals(true)) {
			if (!OptionalUtil.getValue(carrierInterlineDetailsModel.getBillingThruClearingHouse()).equals(true)) {
				throw new BusinessException(
						"‘PAX SIS’ or ‘MISC SIS’ are true then ‘Billing Through Clearing House’ should be true");
			}
		}
		if (OptionalUtil.getValue(carrierInterlineDetailsModel.getPassengerSis()).equals(false)
				&& OptionalUtil.getValue(carrierInterlineDetailsModel.getMiscSis()).equals(false)) {
			if (!OptionalUtil.getValue(carrierInterlineDetailsModel.getBillingThruClearingHouse()).equals(false)) {
				throw new BusinessException(
						"‘PAX SIS’ or ‘MISC SIS’ are true then ‘Billing Through Clearing House’ should be true");
			}
		}

		// validation for billing thru clearing house
		if (carrierInterlineDetailsModel.getPassengerSis().toString().equalsIgnoreCase("True")
				|| carrierInterlineDetailsModel.getMiscSis().toString().equalsIgnoreCase("True")) {
			if (!carrierInterlineDetailsModel.getBillingThruClearingHouse().toString().equalsIgnoreCase("True")) {
				throw new BusinessException("Billing Through Clearing House should be active");
			}
		}

		// ref data to is idec
		if (carrierInterlineDetailsModel.getReferenceDataToIsIdec().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setReferenceDataToIsIdec(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getReferenceDataToIsIdec().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setReferenceDataToIsIdec(Optional.of(Boolean.FALSE));
		}

		// mita for pax
		if (carrierInterlineDetailsModel.getMitaForPax().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setMitaForPax(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getMitaForPax().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setMitaForPax(Optional.of(Boolean.FALSE));
		}

		// digital signature
		if (carrierInterlineDetailsModel.getDigitalSignature().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setDigitalSignature(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getDigitalSignature().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setDigitalSignature(Optional.of(Boolean.FALSE));
		}
		// separate code share invoice
		if (carrierInterlineDetailsModel.getSeparateCodeShareInvoice().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setSeparateCodeShareInvoice(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getSeparateCodeShareInvoice().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setSeparateCodeShareInvoice(Optional.of(Boolean.FALSE));
		}

		// sas check required
		if (carrierInterlineDetailsModel.getSacCheckRequired().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setSacCheckRequired(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getSacCheckRequired().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setSacCheckRequired(Optional.of(Boolean.FALSE));
		}

		// sale check required
		if (carrierInterlineDetailsModel.getSaleCheckRequired().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setSaleCheckRequired(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getSaleCheckRequired().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setSaleCheckRequired(Optional.of(Boolean.FALSE));
		}

		// skip weekly billing
		if (carrierInterlineDetailsModel.getSkipWeeklyBilling().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setSkipWeeklyBilling(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getSkipWeeklyBilling().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setSkipWeeklyBilling(Optional.of(Boolean.FALSE));
		}

		// is_cpn_proc_dt_wkly_bill_lmt
		if (carrierInterlineDetailsModel.getIsCpnProcDtWklyBillLmt().toString().equalsIgnoreCase("True")) {
			carrierInterlineDetailsModel.setIsCpnProcDtWklyBillLmt(Optional.of(Boolean.TRUE));
		} else if (carrierInterlineDetailsModel.getIsCpnProcDtWklyBillLmt().toString().equalsIgnoreCase("False")) {
			carrierInterlineDetailsModel.setIsCpnProcDtWklyBillLmt(Optional.of(Boolean.FALSE));
		}

		// customer code validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getCustomerCode())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getCustomerCode()))) {
			List<Customer> customer = customerController.getAllCustomer(carrierInterlineDetailsModel.getCustomerCode(),
					null, null, null, null, Optional.of(true));
			if (customer.isEmpty()) {
				throw new BusinessException("Invalid Customer code "
						+ OptionalUtil.getValue(carrierInterlineDetailsModel.getCustomerCode()));
			}
		}
		// currency code validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getBillingCurrency())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getBillingCurrency()))) {
			currencyToCurrencyCodeValidation(OptionalUtil.getValue(carrierInterlineDetailsModel.getBillingCurrency()));
		}

		// IB tolerance check currency validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceCheckCurrency()) && StringUtils
				.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceCheckCurrency()))) {
			ibcurrencyToCurrencyCodeValidation(
					OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceCheckCurrency()));
		}
		validateIbToleranceGrossAmount(carrierInterlineDetailsModel);
		validateIbToleranceIscAmount(carrierInterlineDetailsModel);
		validateIbToleranceTaxAmount(carrierInterlineDetailsModel);
		validateIbToleranceTimeLimit(carrierInterlineDetailsModel);

		// EuRegistration country code validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getEuRegistrationCountryCode()) && StringUtils
				.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getEuRegistrationCountryCode()))) {
			countryToCountryCodeValidation(
					OptionalUtil.getValue(carrierInterlineDetailsModel.getEuRegistrationCountryCode()));
		}

		// client code validation
		if (carrierInterlineDetailsModel.getClientId() != null) {
			clientIdToCarrierDesignatorValidation(OptionalUtil.getValue(carrierInterlineDetailsModel.getClientId()));
		}
		// zone validation
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getZone())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()))) {
			if (!(OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()).equals("A")
					|| OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()).equals("B")
					|| OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()).equals("C")
					|| OptionalUtil.getValue(carrierInterlineDetailsModel.getZone()).equals("D"))) {
				throw new BusinessException("Zone valid values are only 'A'|'B'|'C'|'D'");
			}
		}

		if (!OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceGrossAmount()) && StringUtils
				.isEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceGrossAmount()))) {
			carrierInterlineDetailsModel.setIbToleranceGrossAmount(null);
		}

		if (!OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceIscAmount())
				&& StringUtils.isEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceIscAmount()))) {
			carrierInterlineDetailsModel.setIbToleranceIscAmount(null);
		}

		if (!OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceTaxAmount())
				&& StringUtils.isEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceTaxAmount()))) {
			carrierInterlineDetailsModel.setIbToleranceTaxAmount(null);
		}

		if (!OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceTimeLimit())
				&& StringUtils.isEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceTimeLimit()))) {
			carrierInterlineDetailsModel.setIbToleranceTimeLimit(null);
		}

		if (carrierInterlineDetailsDao.getOverLapRecordCountForUpdate(
				OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(carrierInterlineDetailsModel.getEffectiveToDate()),
				OptionalUtil.getValue(carrierInterlineDetailsModel.getClientId()),
				OptionalUtil.getValue(carrierInterlineDetailsModel.getCarrierCode()), carrierInterlineDtlId) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}

		carrierInterlineDetailsEntity.get().setLastUpdatedDate(LocalDateTime.now());
		return carrierInterlineDetailsMapper.mapToModel(carrierInterlineDetailsDao.update(carrierInterlineDetailsMapper
				.mapToEntity(carrierInterlineDetailsModel, carrierInterlineDetailsEntity.get())));
	}

	@Override
	public void activateCarrierInterlineDetail(String carrierCode, int carrierInterlineDtlId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		Optional<CarrierInterlineDetailsEntity> carrierInterlineDetailsEntity = Optional
				.ofNullable(carrierInterlineDetailsRepository.findById(carrierInterlineDtlId))
				.orElseThrow(() -> new BusinessException(CARRIERINTERLINEDETAILSID));

		if (!carrierInterlineDetailsEntity.isPresent()) {
			throw new ResourceNotFoundException(CARRIERINTERLINEDETAILS, "code", carrierInterlineDtlId);
		}

		if (carrierInterlineDetailsEntity.get().getActivate()) {
			throw new BusinessException(CARRIERINTERLINEDETAILSIDACTIVE);
		}
		if (!carrierInterlineDetailsEntity.get().getCarrierCode().equals(carrierCode)) {
			throw new BusinessException(MIS_MATCH + carrierCode + CARRIER_INTERLINE_ID + carrierInterlineDtlId);
		}
		carrierInterlineDetailsEntity.get().setActivate(Boolean.TRUE);
		carrierInterlineDetailsEntity.get().setLastUpdatedBy(lastUpdatedBy);
		carrierInterlineDetailsEntity.get().setLastUpdatedDate(LocalDateTime.now());
		carrierInterlineDetailsRepository.save(carrierInterlineDetailsEntity.get());
	}

	@Override
	public void deactivateCarrierInterlineDetail(String carrierCode, int carrierInterlineDtlId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}

		Optional<CarrierInterlineDetailsEntity> carrierInterlineDetailsEntity = Optional
				.ofNullable(carrierInterlineDetailsRepository.findById(carrierInterlineDtlId))
				.orElseThrow(() -> new BusinessException(CARRIERINTERLINEDETAILSID));

		if (!carrierInterlineDetailsEntity.isPresent()) {
			throw new ResourceNotFoundException(CARRIERINTERLINEDETAILS, "code", carrierInterlineDtlId);
		}

		if (!carrierInterlineDetailsEntity.get().getActivate()) {
			throw new BusinessException(CARRIERINTERLINEDETAILSIDINACTIVE);
		}
		if (!carrierInterlineDetailsEntity.get().getCarrierCode().equals(carrierCode)) {
			throw new BusinessException(MIS_MATCH + carrierCode + CARRIER_INTERLINE_ID + carrierInterlineDtlId);
		}
		carrierInterlineDetailsEntity.get().setActivate(Boolean.FALSE);
		carrierInterlineDetailsEntity.get().setLastUpdatedBy(lastUpdatedBy);
		carrierInterlineDetailsEntity.get().setLastUpdatedDate(LocalDateTime.now());
		carrierInterlineDetailsRepository.save(carrierInterlineDetailsEntity.get());

	}

	private void carrierCodeToCarrierDesignatorValidation(String carrierCode) {

		if (globalMasterFeignClient.getAllCarrier(carrierCode, null, null, null, true).isEmpty()) {
			throw new BusinessException(INVALID_CARRIER_CODE + carrierCode);
		}

	}

	private void currencyToCurrencyCodeValidation(String currencyCode) {
		if (!globalMasterFeignClient.validateCurrencyCode(currencyCode)) {
			throw new BusinessException(INVALID_CURRENCY_CODE + currencyCode);
		}
	}

	private void ibcurrencyToCurrencyCodeValidation(String currencyCode) {
		if (!globalMasterFeignClient.validateCurrencyCode(currencyCode)) {
			throw new BusinessException(INVALID_IB_CURRENCY_CODE + currencyCode);
		}
	}

	private void countryToCountryCodeValidation(String countryCode) {
		Country countryCodeValue = globalMasterFeignClient.getCountryByCountryCode(countryCode);

		if (countryCodeValue.getCountryCode().isEmpty()) {
			throw new BusinessException(INVALID_COUNTRY_CODE + countryCode);
		}
	}

	private void clientIdToCarrierDesignatorValidation(String clientId) {
		if (globalMasterFeignClient.getAllCarrier(carrierCode1, clientId, carrierName1, carrierName2, true).isEmpty()) {
			throw new BusinessException(INVALID_CLIENTID + clientId);
		}
	}

	private void validateDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To Date[" + effectiveToDate
					+ "] should be greater than Effective From Date[" + effectiveFromDate + "]");
		}
	}

	protected void validateIbToleranceGrossAmount(CarrierInterlineDetailsModel carrierInterlineDetailsModel) {
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceGrossAmount()) && StringUtils
				.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceGrossAmount()))) {
			String ibToleranceGrossAmount = OptionalUtil
					.getValue(carrierInterlineDetailsModel.getIbToleranceGrossAmount());
			operationCheck = Pattern.compile(IBTOLERANCE_PATTERN).matcher(ibToleranceGrossAmount).find();
			if (!operationCheck) {
				throw new BusinessException("IB Tolerance Gross Amount should be of 16,3 format");
			}
		}
	}

	protected void validateIbToleranceIscAmount(CarrierInterlineDetailsModel carrierInterlineDetailsModel) {
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceIscAmount()) && StringUtils
				.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceIscAmount()))) {
			String ibToleranceIscAmount = OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceIscAmount());
			operationCheck = Pattern.compile(IBTOLERANCE_PATTERN).matcher(ibToleranceIscAmount).find();
			if (!operationCheck) {
				throw new BusinessException("IB Tolerance Isc Amount should be of 16,3 format");
			}
		}
	}

	protected void validateIbToleranceTaxAmount(CarrierInterlineDetailsModel carrierInterlineDetailsModel) {
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceTaxAmount()) && StringUtils
				.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceTaxAmount()))) {
			String ibToleranceTaxAmount = OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceTaxAmount());
			operationCheck = Pattern.compile(IBTOLERANCE_PATTERN).matcher(ibToleranceTaxAmount).find();
			if (!operationCheck) {
				throw new BusinessException("IB Tolerance Tax Amount should be of 16,3 format");
			}
		}
	}

	protected void validateIbToleranceTimeLimit(CarrierInterlineDetailsModel carrierInterlineDetailsModel) {
		if (OptionalUtil.isPresent(carrierInterlineDetailsModel.getIbToleranceTimeLimit()) && StringUtils
				.isNotEmpty(OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceTimeLimit()))) {
			String ibToleranceTimeLimit = OptionalUtil.getValue(carrierInterlineDetailsModel.getIbToleranceTimeLimit());
			operationCheck = Pattern.compile("^[0-9]+$").matcher(ibToleranceTimeLimit).find();
			if (!operationCheck) {
				throw new BusinessException("IB Tolerance Time Limit should be numeric value");
			}
		}
	}

	@Override
	public List<CarrierInterlineDetailsModel> getCarrierInterlineDetailsByZoneAndEffectiveDate(
			Optional<String> clientId, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> zone) {

		List<CarrierInterlineDetailsModel> carrierInterlineDetailsModels = carrierInterlineDetailsMapper
				.mapToModel(carrierInterlineDetailsDao.getCarrierInterlineDetailsByZoneAndEffectiveDate(clientId,
						effectiveFromDate, effectiveToDate, zone));

		carrierInterlineDetailsModels.stream().forEach(interline -> {

			try {
				Carrier carrierModel = globalMasterFeignClient
						.getActiveCarrierByCarrierCode(OptionalUtil.getValue(interline.getCarrierCode()));
				interline.setCarrierName(OptionalUtil.getValue(carrierModel.getCarrierName1()));
			} catch (Exception be) {
				interline.setCarrierName("");
			}

		});

		return carrierInterlineDetailsModels;
	}

	@Override
	public SettlementMethod getSettlementMethod(Optional<String> billingCarrierCode, Optional<String> billedCarriedCode,
			Optional<String> currentBillingDate) {

		CarrierInterlineDetailsModel billingCarrier = getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(
				billingCarrierCode, currentBillingDate);
		CarrierInterlineDetailsModel billedCarrier = getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(
				billedCarriedCode, currentBillingDate);
		String billingDate = null;
		if (currentBillingDate.isPresent()) {
			billingDate = currentBillingDate.get();
		}
		CarrierDetail billingCarrierDetail = globalMasterFeignClient
				.getCarrierTypeByCarrierCode(billingCarrierCode.get(), billingDate);
		CarrierDetail billedCarrierDetail = globalMasterFeignClient.getCarrierTypeByCarrierCode(billedCarriedCode.get(),
				billingDate);

		Boolean billingCarrierMiscSis = Boolean.FALSE;
		Boolean billingCarrierClearingHouse = Boolean.FALSE;
		if (billingCarrier != null) {
			if (billingCarrier.getMiscSis().isPresent())
				billingCarrierMiscSis = billingCarrier.getMiscSis().get();

			if (billingCarrier.getBillingThruClearingHouse().isPresent())
				billingCarrierClearingHouse = billingCarrier.getBillingThruClearingHouse().get();
		}

		Boolean billedCarrierMiscSis = Boolean.FALSE;
		Boolean billedCarrierClearingHouse = Boolean.FALSE;
		if (billedCarrier != null) {
			if (billedCarrier.getMiscSis().isPresent())
				billedCarrierMiscSis = billedCarrier.getMiscSis().get();

			if (billedCarrier.getBillingThruClearingHouse().isPresent())
				billedCarrierClearingHouse = billedCarrier.getBillingThruClearingHouse().get();
		}

		String billingCarrierType = null;
		String billedCarrierType = null;
		if (billingCarrierDetail != null) {
			if (billingCarrierDetail.getCarrierType().isPresent())
				billingCarrierType = billingCarrierDetail.getCarrierType().get().trim();
		}

		if (billedCarrierDetail != null) {
			if (billedCarrierDetail.getCarrierType().isPresent())
				billedCarrierType = billedCarrierDetail.getCarrierType().get().trim();
		}

		if (billingCarrier == null && billedCarrier == null && billingCarrierDetail == null
				&& billedCarrierDetail == null) {
			return SettlementMethod.D;
		} else {
			return deriveSettlementMethod(billingCarrierType, billedCarrierType, billingCarrierMiscSis,
					billedCarrierMiscSis, billingCarrierClearingHouse, billedCarrierClearingHouse);
		}
	}

	private SettlementMethod deriveSettlementMethod(String billingCarrierType, String billedCarrierType,
			Boolean billingCarrierMiscSis, Boolean billedCarrierMiscSis, Boolean billingCarrierClearingHouse,
			Boolean billedCarrierClearingHouse) {

		// BLANK (Non-Carrier) NA NA NA NA NA Direct
		if (StringUtils.isEmpty(billingCarrierType)) {
			return SettlementMethod.D;
		}

		// ICH/Both Y Y BLANK Direct
		if ((ICH.equals(billingCarrierType) || BOTH.equals(billingCarrierType)) && billingCarrierMiscSis
				&& billingCarrierClearingHouse && StringUtils.isEmpty(billedCarrierType)) {
			return SettlementMethod.D;
		}

		// ICH/Both Y Y ICH/ACH/BOTH N Y Bilateral
		if ((ICH.equals(billingCarrierType) || BOTH.equals(billingCarrierType)) && billingCarrierMiscSis
				&& billingCarrierClearingHouse
				&& (ICH.equals(billedCarrierType) || ACH.equals(billedCarrierType) || BOTH.equals(billedCarrierType))
				&& !billedCarrierMiscSis && billedCarrierClearingHouse) {
			return SettlementMethod.B;
		}

		// ICH/Both Y Y ICH/ACH/BOTH Y Y ICH
		if ((ICH.equals(billingCarrierType) || BOTH.equals(billingCarrierType)) && billingCarrierMiscSis
				&& billingCarrierClearingHouse
				&& (ICH.equals(billedCarrierType) || ACH.equals(billedCarrierType) || BOTH.equals(billedCarrierType))
				&& billedCarrierMiscSis && billedCarrierClearingHouse) {
			return SettlementMethod.I;
		}

		// ICH/Both N Y BLANK
		if ((ICH.equals(billingCarrierType) || BOTH.equals(billingCarrierType)) && !billingCarrierMiscSis
				&& billingCarrierClearingHouse && StringUtils.isEmpty(billedCarrierType)) {
			return SettlementMethod.D;
		}

		// ICH/Both Y Y ICH/ACH/BOTH N Y Bilateral
		if ((ICH.equals(billingCarrierType) || BOTH.equals(billingCarrierType)) && billingCarrierMiscSis
				&& billingCarrierClearingHouse
				&& (ICH.equals(billedCarrierType) || ACH.equals(billedCarrierType) || BOTH.equals(billedCarrierType))
				&& !billedCarrierMiscSis && billedCarrierClearingHouse) {
			return SettlementMethod.B;
		}

		// ICH/Both N Y ICH/ACH/BOTH Y Y Bilateral
		if ((ICH.equals(billingCarrierType) || BOTH.equals(billingCarrierType)) && !billingCarrierMiscSis
				&& billingCarrierClearingHouse
				&& (ICH.equals(billedCarrierType) || ACH.equals(billedCarrierType) || BOTH.equals(billedCarrierType))
				&& billedCarrierMiscSis && billedCarrierClearingHouse) {
			return SettlementMethod.B;
		}

		// ACH Y Y BLANK Direct
		if (ACH.equals(billingCarrierType) && billingCarrierMiscSis && billingCarrierClearingHouse
				&& StringUtils.isEmpty(billedCarrierType)) {
			return SettlementMethod.D;
		}
		// ACH Y Y ICH/ACH/BOTH N Y Bilateral
		if ((ACH.equals(billingCarrierType) && billingCarrierMiscSis && billingCarrierClearingHouse
				&& (ICH.equals(billedCarrierType) || ACH.equals(billedCarrierType) || BOTH.equals(billedCarrierType))
				&& !billedCarrierMiscSis && billedCarrierClearingHouse)) {
			return SettlementMethod.B;
		}

		// ACH Y Y ICH/ACH/BOTH Y Y ACH
		if ((ACH.equals(billingCarrierType) && billingCarrierMiscSis && billingCarrierClearingHouse
				&& (ICH.equals(billedCarrierType) || ACH.equals(billedCarrierType) || BOTH.equals(billedCarrierType))
				&& billedCarrierMiscSis && billedCarrierClearingHouse)) {
			return SettlementMethod.A;
		}
		// ACH N Y BLANK Direct
		if (ACH.equals(billingCarrierType) && !billingCarrierMiscSis && billingCarrierClearingHouse
				&& StringUtils.isEmpty(billedCarrierType)) {
			return SettlementMethod.D;
		}
		// ACH N Y ICH/ACH/BOTH N Y Bilateral
		if ((ACH.equals(billingCarrierType) && !billingCarrierMiscSis && billingCarrierClearingHouse
				&& (ICH.equals(billedCarrierType) || ACH.equals(billedCarrierType) || BOTH.equals(billedCarrierType))
				&& !billedCarrierMiscSis && billedCarrierClearingHouse)) {
			return SettlementMethod.B;
		}
		// ACH N Y ICH/ACH/BOTH Y Y Bilateral
		if ((ACH.equals(billingCarrierType) && !billingCarrierMiscSis && billingCarrierClearingHouse
				&& (ICH.equals(billedCarrierType) || ACH.equals(billedCarrierType) || BOTH.equals(billedCarrierType))
				&& billedCarrierMiscSis && billedCarrierClearingHouse)) {
			return SettlementMethod.B;
		}
		return SettlementMethod.D;

	}

}