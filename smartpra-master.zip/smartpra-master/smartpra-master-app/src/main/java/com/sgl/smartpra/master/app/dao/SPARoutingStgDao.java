package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.SPARoutingStgEntity;
@Repository
public interface SPARoutingStgDao {
	Optional<SPARoutingStgEntity> findById(Integer spaSectorId);
	List<SPARoutingStgEntity> findBySpaKeyMainIdClientId(Optional<Integer> spaKey, Optional<Integer> spaMainId,
			Optional<String> clientId);
}
