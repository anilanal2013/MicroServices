package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCodeEntity;

public class NonStandardChargeCodeEntitySpec {
	
	private static final String ISACTIVE = "isActive";
	private static final String CLIENTID = "clientId";      
	private static final String NON_STD_CHARGE_CODE = "nonStdChargeCode";
	private static final String STD_CHARGE_CODE = "stdChargeCode";
	private static final String NON_STD_CHARGE_CATEGORY = "nonStdCategoryCode";
	private static final String DISPLAYORDER = "nonStdChargeCode";
	
	private NonStandardChargeCodeEntitySpec() {}
	

	public static Specification<NonStandardChargeCodeEntity> isActive() {
		return (nonStandardChargeCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(nonStandardChargeCodeEntity.get(ISACTIVE), true);
	}

	public static Specification<NonStandardChargeCodeEntity> equalsClientId(String clientId) {
		return (nonStandardChargeCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(nonStandardChargeCodeEntity.get(CLIENTID), clientId);
	}

	public static Specification<NonStandardChargeCodeEntity> searchNonStandardChargeCode(String clientId, 
			Optional<String> nonStdChargeCategoryCode, Optional<String> nonStdChargeCode, 
			Optional<String> stdChargeCode, Optional<String> isActive) {
		return (nonStandardChargeCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
		
				predicates.add(criteriaBuilder.equal(nonStandardChargeCodeEntity.get(CLIENTID), clientId));
			
				if(nonStdChargeCategoryCode.isPresent()) {
					predicates.add(criteriaBuilder.equal(nonStandardChargeCodeEntity.get(NON_STD_CHARGE_CATEGORY), OptionalUtil.getValue(nonStdChargeCategoryCode)));
				}
				if(nonStdChargeCode.isPresent()) {
					predicates.add(criteriaBuilder.equal(nonStandardChargeCodeEntity.get(NON_STD_CHARGE_CODE), OptionalUtil.getValue(nonStdChargeCode)));
				}
				if(stdChargeCode.isPresent()) {
					predicates.add(criteriaBuilder.equal(nonStandardChargeCodeEntity.get(STD_CHARGE_CODE), OptionalUtil.getValue(stdChargeCode)));
				}
				if(isActive.isPresent()) {
					if("ALL".equalsIgnoreCase(isActive.get())) {
						predicates.add(criteriaBuilder.or(
								criteriaBuilder.equal(nonStandardChargeCodeEntity.get(ISACTIVE), "Y"),
								criteriaBuilder.equal(nonStandardChargeCodeEntity.get(ISACTIVE), "N")));
					} else {
						predicates.add(criteriaBuilder.equal(nonStandardChargeCodeEntity.get(ISACTIVE), OptionalUtil.getValue(isActive)));
					}
				}
				orderByAsc(nonStandardChargeCodeEntity, criteriaQuery, criteriaBuilder, DISPLAYORDER);
				
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static void orderByAsc(Root<NonStandardChargeCodeEntity> nonStdChargeCodeEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String displayOrder) {
		criteriaQuery.orderBy(criteriaBuilder.asc(nonStdChargeCodeEntity.get(displayOrder)));
	}
}