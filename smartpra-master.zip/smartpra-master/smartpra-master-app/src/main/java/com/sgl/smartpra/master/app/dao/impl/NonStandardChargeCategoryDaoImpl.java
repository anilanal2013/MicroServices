package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.NonStandardChargeCategoryDao;
import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCategoryEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.NonStandardChargeCategoryEntitySpec;
import com.sgl.smartpra.master.app.dao.repository.NonStandardChargeCategoryRepository;

@Repository
public class NonStandardChargeCategoryDaoImpl implements NonStandardChargeCategoryDao {

	@Autowired
	private NonStandardChargeCategoryRepository nonStdChargeCategoryRepository; 
	
	@Override
	public Optional<NonStandardChargeCategoryEntity> findById(Integer nonStdCategoryId) {
		return nonStdChargeCategoryRepository.findById(nonStdCategoryId);
	}

	@Override
	public NonStandardChargeCategoryEntity create(NonStandardChargeCategoryEntity nonStdChargeCategoryEntity) {
		return nonStdChargeCategoryRepository.save(nonStdChargeCategoryEntity);
	}

	@Override
	public NonStandardChargeCategoryEntity update(NonStandardChargeCategoryEntity nonStdChargeCategoryEntity) {
		return nonStdChargeCategoryRepository.save(nonStdChargeCategoryEntity);
	}

	@Override
	public List<NonStandardChargeCategoryEntity> searchNonStandardChargeCategory(String clientId,
			Optional<String> nonStdChargeCategoryCode, Optional<String> stdChargeCategoryCode,  Optional<String> isActive) {
		return nonStdChargeCategoryRepository.findAll(NonStandardChargeCategoryEntitySpec.searchNonStandardChargeCategory(clientId, 
				nonStdChargeCategoryCode, stdChargeCategoryCode, isActive));
	}

	@Override
	public int activateNonStandardChargeCategory(String clientId, String nonStdCategoryCode) {
		return nonStdChargeCategoryRepository.activateNonStandardChargeCategory(clientId, nonStdCategoryCode);
	}

	@Override
	public int deActivateNonStandardChargeCategory(String clientId, String nonStdCategoryCode) {
		return nonStdChargeCategoryRepository.deActivateNonStandardChargeCategory(clientId, nonStdCategoryCode);
	}

	@Override
	public String getMaxNonStdChargeCategoryCode(String clientId, String stdChargeCategoryCode, String initial) {
		return nonStdChargeCategoryRepository.getMaxNonStdChargeCategoryCode(clientId, initial);
	}

	@Override
	public String getNonStdChargeCategoryCode(String clientId, String stdCategoryCode, String nonStdCategoryName) {
		return nonStdChargeCategoryRepository.getNonStdChargeCategoryCode(clientId, nonStdCategoryName);
	}

	@Override
	public String getStdChargeCategoryCode(String clientId, String nonStdCategoryCode) {
		return nonStdChargeCategoryRepository.getStdChargeCategoryCode(clientId, nonStdCategoryCode);
	}

}
