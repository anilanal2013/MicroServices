package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_accounting_definition")
@Data
@DynamicInsert
@DynamicUpdate
@EqualsAndHashCode(callSuper = false)
public class AccountingDefinitionEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "account_definition_identifier")
	private int accountDefinitionIdentifier;

	@Column(name = "account_code_alpha")
	private String accountCodeAlpha;

	@Column(name = "accounting_attributes_1")
	private String accountingAttributes1;

	@Column(name = "accounting_attributes_10")
	private String accountingAttributes10;

	@Column(name = "accounting_attributes_11")
	private String accountingAttributes11;

	@Column(name = "accounting_attributes_12")
	private String accountingAttributes12;

	@Column(name = "accounting_attributes_13")
	private String accountingAttributes13;

	@Column(name = "accounting_attributes_14")
	private String accountingAttributes14;

	@Column(name = "accounting_attributes_15")
	private String accountingAttributes15;

	@Column(name = "accounting_attributes_16")
	private String accountingAttributes16;

	@Column(name = "accounting_attributes_17")
	private String accountingAttributes17;

	@Column(name = "accounting_attributes_18")
	private String accountingAttributes18;

	@Column(name = "accounting_attributes_19")
	private String accountingAttributes19;

	@Column(name = "accounting_attributes_2")
	private String accountingAttributes2;

	@Column(name = "accounting_attributes_20")
	private String accountingAttributes20;

	@Column(name = "accounting_attributes_3")
	private String accountingAttributes3;

	@Column(name = "accounting_attributes_4")
	private String accountingAttributes4;

	@Column(name = "accounting_attributes_5")
	private String accountingAttributes5;

	@Column(name = "accounting_attributes_6")
	private String accountingAttributes6;

	@Column(name = "accounting_attributes_7")
	private String accountingAttributes7;

	@Column(name = "accounting_attributes_8")
	private String accountingAttributes8;

	@Column(name = "accounting_attributes_9")
	private String accountingAttributes9;

	@Column(name = "accounting_attributes_master_1")
	private String accountingAttributesMaster1;

	@Column(name = "accounting_attributes_master_10")
	private String accountingAttributesMaster10;

	@Column(name = "accounting_attributes_master_11")
	private String accountingAttributesMaster11;

	@Column(name = "accounting_attributes_master_12")
	private String accountingAttributesMaster12;

	@Column(name = "accounting_attributes_master_13")
	private String accountingAttributesMaster13;

	@Column(name = "accounting_attributes_master_14")
	private String accountingAttributesMaster14;

	@Column(name = "accounting_attributes_master_15")
	private String accountingAttributesMaster15;

	@Column(name = "accounting_attributes_master_16")
	private String accountingAttributesMaster16;

	@Column(name = "accounting_attributes_master_17")
	private String accountingAttributesMaster17;

	@Column(name = "accounting_attributes_master_18")
	private String accountingAttributesMaster18;

	@Column(name = "accounting_attributes_master_19")
	private String accountingAttributesMaster19;

	@Column(name = "accounting_attributes_master_2")
	private String accountingAttributesMaster2;

	@Column(name = "accounting_attributes_master_20")
	private String accountingAttributesMaster20;

	@Column(name = "accounting_attributes_master_3")
	private String accountingAttributesMaster3;

	@Column(name = "accounting_attributes_master_4")
	private String accountingAttributesMaster4;

	@Column(name = "accounting_attributes_master_5")
	private String accountingAttributesMaster5;

	@Column(name = "accounting_attributes_master_6")
	private String accountingAttributesMaster6;

	@Column(name = "accounting_attributes_master_7")
	private String accountingAttributesMaster7;

	@Column(name = "accounting_attributes_master_8")
	private String accountingAttributesMaster8;

	@Column(name = "accounting_attributes_master_9")
	private String accountingAttributesMaster9;

	@Column(name = "attribute_validation_indicator_1")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator1;

	@Column(name = "attribute_validation_indicator_10")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator10;

	@Column(name = "attribute_validation_indicator_11")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator11;

	@Column(name = "attribute_validation_indicator_12")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator12;

	@Column(name = "attribute_validation_indicator_13")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator13;

	@Column(name = "attribute_validation_indicator_14")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator14;

	@Column(name = "attribute_validation_indicator_15")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator15;

	@Column(name = "attribute_validation_indicator_16")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator16;

	@Column(name = "attribute_validation_indicator_17")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator17;

	@Column(name = "attribute_validation_indicator_18")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator18;

	@Column(name = "attribute_validation_indicator_19")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator19;

	@Column(name = "attribute_validation_indicator_2")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator2;

	@Column(name = "attribute_validation_indicator_20")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator20;

	@Column(name = "attribute_validation_indicator_3")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator3;

	@Column(name = "attribute_validation_indicator_4")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator4;

	@Column(name = "attribute_validation_indicator_5")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator5;

	@Column(name = "attribute_validation_indicator_6")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator6;

	@Column(name = "attribute_validation_indicator_7")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator7;

	@Column(name = "attribute_validation_indicator_8")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator8;

	@Column(name = "attribute_validation_indicator_9")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean attributeValidationIndicator9;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "component_identifier")
	private String componentIdentifier;

	@Column(name = "conversion_date_use")
	private String conversionDateUse;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
