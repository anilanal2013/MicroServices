package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.InterlineServiceChargeEntity;
import com.sgl.smartpra.master.model.InterlineServiceCharge;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface InterlineServiceChargeMapper extends BaseMapper<InterlineServiceCharge, InterlineServiceChargeEntity> {

	InterlineServiceChargeEntity mapToEntity(InterlineServiceCharge interlineServiceCharge,
			@MappingTarget InterlineServiceChargeEntity chargeEntity);

	@Mapping(source = "iscId", target = "iscId", ignore = true)
	InterlineServiceChargeEntity mapToEntity(InterlineServiceCharge interlineServiceCharge);
  
}