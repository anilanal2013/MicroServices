package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.CustomerDao;
import com.sgl.smartpra.master.app.dao.entity.CustomerEntity;
import com.sgl.smartpra.master.app.mapper.CustomerMapper;
import com.sgl.smartpra.master.app.service.AgencyMasterService;
import com.sgl.smartpra.master.app.service.CreditCardService;
import com.sgl.smartpra.master.app.service.CustomerService;
import com.sgl.smartpra.master.app.service.FOPService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.CreditCard;
import com.sgl.smartpra.master.model.Customer;
import com.sgl.smartpra.master.model.ListOfValues;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerMapper customerMapper;

	@Autowired
	private CustomerDao customerDao;

	@Autowired
	private CreditCardService creditCardService;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private ListOfValuesService listOfValuesService;

	@Autowired
	@Qualifier("FOPService")
	private FOPService fopService;

	@Autowired
	private AgencyMasterService agencyMasterService;

	public static final String LAST_UPDATEDBY_MSG = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	public static final String LASTUPDATED_BY_MENDATORY_MSG = "Please provide Last Updated By";
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	public static final String CUSTOMER_ACTIVE = "Customer is already in active state";
	public static final String CUSTOMER_ALREADY_INACTIVE = "Customer is already in deactivated state";
	public static final String CUSTOMER_IS_NOT_ACTIVE = "Customer is not active with  ";
	private static final String TABLE_NAME = LOVEnum.TABLENAME.getLOVEnum();
	private static final String LOV_FINANCIAL_DOCUMENT_TYPE = LOVEnum.FINANCIALDOCTYPE.getLOVEnum();
	public static final String LOV_BILLING_FREQUENCY = LOVEnum.BILLINFREQUENCY.getLOVEnum();
	public static final String LANGUAGE = LOVEnum.LANGUAGE.getLOVEnum();
	public static final String LOV_CUSTOMER_TYPE = LOVEnum.CUSTOMERTYPE.getLOVEnum();
	public static final String CUSTOMER_ID_EXISTS = "Customer Id already exists";
	public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
			Pattern.CASE_INSENSITIVE);
	private static final String NOT_VALID = "] is Not Valid";

	@Override
	public List<Customer> getListOfCustomer(Customer customer, Optional<String> exceptionCall) {
		return customerMapper.mapToModel(customerDao.search(customer, exceptionCall));
	}

	@Override
	public Customer getCustomerByCustomerMasId(Integer customerMasId) {
		return customerMapper.mapToModel(customerDao.findById(customerMasId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(customerMasId))));
	}

	@Override
	public Customer createCustomer(Customer customer) {
		businessConstraintForCreate(customer);
		customer.setActivate(Boolean.TRUE);
		customer.setCreatedDate(LocalDateTime.now());
		return customerMapper.mapToModel(customerDao.create(customerMapper.mapToEntity(customer)));
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		CustomerEntity customerEntity = customerDao.findById(customer.getCustomerMasId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(customer.getCustomerMasId())));
		businessConstraintForUpdate(customer, customerEntity);
		customer.setLastUpdatedDate(LocalDateTime.now());
		return customerMapper.mapToModel(customerDao.update(customerMapper.mapToEntity(customer, customerEntity)));
	}

	@Override
	public void deactivateCustomer(Integer customerMasId, String lastUpdatedBy) {
		CustomerEntity customerEntity = customerDao.findOne(customerMasId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(customerMasId)));
		if (!customerEntity.getActivate())
			throw new BusinessException(CUSTOMER_ALREADY_INACTIVE);
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.trim().length() > 15)
				throw new BusinessException(LAST_UPDATEDBY_MSG);
		} else {
			throw new BusinessException(LASTUPDATED_BY_MENDATORY_MSG);
		}
		customerEntity.setActivate(Boolean.FALSE);
		customerEntity.setLastUpdatedBy(lastUpdatedBy);
		customerDao.update(customerEntity);
	}

	@Override
	public void activateCustomer(Integer customerMasId, String lastUpdatedBy) {
		CustomerEntity customerEntity = customerDao.findOne(customerMasId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(customerMasId)));
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.trim().length() > 15)
				throw new BusinessException(LAST_UPDATEDBY_MSG);
		} else {
			throw new BusinessException(LASTUPDATED_BY_MENDATORY_MSG);
		}
		if (customerEntity.getActivate())
			throw new BusinessException(CUSTOMER_ACTIVE);

		customerEntity.setActivate(Boolean.TRUE);
		customerEntity.setLastUpdatedBy(lastUpdatedBy);
		customerDao.update(customerEntity);
	}

	private void businessConstraintForCreate(Customer customer) {

		clientIdToCarrierDesignatorValidation(customer);
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(customer.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(customer.getEffectiveToDate()));
		cityCodeToAirport(customer);
		validateFopCodeForCreate(customer);
		validateSubFopCode(customer);
		validateAgencyCodeForCreate(customer);
		currencyCodeToCurrency(customer);
		validationForEmailAddress(customer);
		validateFinancialDocTypeForCreate(customer);
		validateBillingFrequencyForCreate(customer);
		validateCustomerTypeForCreate(customer);
		checkEmpty(customer);
		checkOverlapForCreate(customer);
		commonValidation(customer);
		validateSettleDueDate(customer);
		validateLanguage(customer);
	}

	private void validateSubFopCode(Customer customer) {
		if (OptionalUtil.isPresent(customer.getSubFopCode())) {
			CreditCard creditCard = new CreditCard();
			creditCard.setCcCompanyCode(customer.getSubFopCode());
			if (creditCardService.getAllCreditCard(creditCard, null).isEmpty()) {
				throw new BusinessException("Invalid Sub Fop Code " + OptionalUtil.getValue(customer.getSubFopCode()));
			}
		}
	}

	private void validateSettleDueDate(Customer customer) {
		if (OptionalUtil.isPresent(customer.getSettlementDueDate())) {
			int dueDate = OptionalUtil.getValue(customer.getSettlementDueDate());
			if (dueDate < 0 || dueDate > 99) {
				throw new BusinessException("Invalid Settle Due Date " + dueDate);
			}
		}
	}

	private void businessConstraintForUpdate(Customer customer, CustomerEntity customerEntity) {
		clientIdToCarrierDesignatorValidation(customer);
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(customer.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(customer.getEffectiveToDate()));
		cityCodeToAirport(customer);
		validateFopCodeForUpdate(customer, customerEntity);
		validateSubFopCode(customer);
		validateAgencyCodeForUpdate(customer, customerEntity);
		currencyCodeToCurrency(customer);
		validationForEmailAddress(customer);
		validateFinancialDocTypeForUpdate(customer, customerEntity);
		validateBillingFrequencyForUpdate(customer, customerEntity);
		validateCustomerTypeForUpdate(customer, customerEntity);
		checkEmpty(customer, customerEntity);
		checkOverlapForUpdate(customer, customerEntity);
		commonValidation(customer);
		validateSettleDueDate(customer);
		validateLanguage(customer, customerEntity);
	}

	private void clientIdToCarrierDesignatorValidation(Customer customer) {
		if (OptionalUtil.isPresent(customer.getClientId())) {
			String clientId = OptionalUtil.getValue(customer.getClientId());
			if (globalMasterFeignClient.getAllCarrier(null, clientId, null, null, true).isEmpty()) {
				throw new BusinessException("Invalid Client Id " + clientId);
			}
		}
	}

	private void cityCodeToAirport(Customer customer) {
		if (OptionalUtil.isPresent(customer.getCityCode())) {
			String cityCode = OptionalUtil.getValue(customer.getCityCode());
			if (globalMasterFeignClient.getAllAirport(null, null, cityCode, null, null).isEmpty()) {
				throw new BusinessException("Invalid City Code " + cityCode);
			}
		}
	}

	private void currencyCodeToCurrency(Customer customer) {
		if (OptionalUtil.isPresent(customer.getCurrencyOfInvoice())) {
			String currencyOfInvoice = OptionalUtil.getValue(customer.getCurrencyOfInvoice());
			if (globalMasterFeignClient.getAllcurrencies(currencyOfInvoice, null, true).isEmpty()) {
				throw new BusinessException("Invalid Currency Code " + currencyOfInvoice);
			}
		}
	}

	private void validationForEmailAddress(Customer customer) {
		if (OptionalUtil.isPresent(customer.getEmail())) {
			String email = OptionalUtil.getValue(customer.getEmail());
			if (OptionalUtil.getValue(customer.getEmail()).trim().length() > 0) {
				if (!(VALID_EMAIL_ADDRESS_REGEX.matcher(email).find())) {
					throw new BusinessException("Invalid Email " + email);
				}
			}
		}
	}

	private void validateFinancialDocType(String clientId, String financialDocType) {
		if (financialDocType != null && !financialDocType.isEmpty()) {
			if (financialDocType.trim().length() > 0) {
				ListOfValues listOfValuesModel = new ListOfValues();
				listOfValuesModel.setClientId(Optional.of(clientId));
				listOfValuesModel.setTableName(Optional.of(TABLE_NAME));
				listOfValuesModel.setColumnName(Optional.of(LOV_FINANCIAL_DOCUMENT_TYPE));
				listOfValuesModel.setIsActive(true);
				listOfValuesModel.setFieldValue(Optional.of(financialDocType));
				if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
					throw new BusinessException("Invalid Financial Document Type " + financialDocType);
				}
			}
		}
	}

	private void validateBillingFrequency(String clientId, String billingFrequency) {
		if (billingFrequency != null && !billingFrequency.isEmpty()) {
			if (billingFrequency.trim().length() > 0) {
				ListOfValues listOfValuesModel = new ListOfValues();
				listOfValuesModel.setClientId(Optional.of(clientId));
				listOfValuesModel.setTableName(Optional.of(TABLE_NAME));
				listOfValuesModel.setColumnName(Optional.of(LOV_BILLING_FREQUENCY));
				listOfValuesModel.setIsActive(true);
				listOfValuesModel.setFieldValue(Optional.of(billingFrequency));
				if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
					throw new BusinessException("Billing Frequency[" + billingFrequency + NOT_VALID);
				}
			}
		}
	}

	private void validateCustomerType(String clientId, String customerType) {
		if (customerType != null && !customerType.isEmpty()) {
			if (customerType.trim().length() > 0) {
				ListOfValues listOfValuesModel = new ListOfValues();
				listOfValuesModel.setClientId(Optional.of(clientId));
				listOfValuesModel.setTableName(Optional.of(TABLE_NAME));
				listOfValuesModel.setColumnName(Optional.of(LOV_CUSTOMER_TYPE));
				listOfValuesModel.setIsActive(true);
				listOfValuesModel.setFieldValue(Optional.of(customerType));
				if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
					throw new BusinessException("Customer Type[" + customerType + NOT_VALID);
				}
			}
		}
	}

	private void validateFinancialDocTypeForCreate(Customer customer) {
		if (OptionalUtil.isPresent(customer.getClientId()) && OptionalUtil.isPresent(customer.getFinancialDocType())) {
			validateFinancialDocType(OptionalUtil.getValue(customer.getClientId()),
					OptionalUtil.getValue(customer.getFinancialDocType()));
		}
	}

	private void validateBillingFrequencyForCreate(Customer customer) {
		if (OptionalUtil.isPresent(customer.getClientId()) && OptionalUtil.isPresent(customer.getBillingFrequency())) {
			validateBillingFrequency(OptionalUtil.getValue(customer.getClientId()),
					OptionalUtil.getValue(customer.getBillingFrequency()));
		}
	}

	private void validateCustomerTypeForCreate(Customer customer) {
		if (OptionalUtil.isPresent(customer.getClientId()) && OptionalUtil.isPresent(customer.getCustomerType())) {
			validateCustomerType(OptionalUtil.getValue(customer.getClientId()),
					OptionalUtil.getValue(customer.getCustomerType()));
		}
	}

	private void validateFinancialDocTypeForUpdate(Customer customer, CustomerEntity customerEntity) {
		if (OptionalUtil.isPresent(customer.getClientId()) || OptionalUtil.isPresent(customer.getFinancialDocType())) {
			validateFinancialDocType(getClientId(customer, customerEntity),
					getFinancialDocType(customer, customerEntity));
		}
	}

	private void validateBillingFrequencyForUpdate(Customer customer, CustomerEntity customerEntity) {
		if (OptionalUtil.isPresent(customer.getClientId()) || OptionalUtil.isPresent(customer.getBillingFrequency())) {
			validateBillingFrequency(getClientId(customer, customerEntity),
					getBillingFrequency(customer, customerEntity));
		}
	}

	private void validateCustomerTypeForUpdate(Customer customer, CustomerEntity customerEntity) {
		if (OptionalUtil.isPresent(customer.getClientId()) || OptionalUtil.isPresent(customer.getCustomerType())) {
			validateCustomerType(getClientId(customer, customerEntity), getCustomerType(customer, customerEntity));
		}
	}

	private String getClientId(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getClientId()) ? OptionalUtil.getValue(customer.getClientId())
				: customerEntity.getClientId();
	}

	private String getCustomerType(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getCustomerType()) ? OptionalUtil.getValue(customer.getCustomerType())
				: customerEntity.getCustomerType();
	}

	private String getBillingFrequency(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getBillingFrequency())
				? OptionalUtil.getValue(customer.getBillingFrequency())
				: customerEntity.getBillingFrequency();
	}

	private String getFinancialDocType(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getFinancialDocType())
				? OptionalUtil.getValue(customer.getFinancialDocType())
				: customerEntity.getFinancialDocType();
	}

	private String getFopCode(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getFopCode()) ? OptionalUtil.getValue(customer.getFopCode())
				: customerEntity.getFopCode();
	}

	private String getSubFopCode(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getSubFopCode()) ? OptionalUtil.getValue(customer.getSubFopCode())
				: customerEntity.getSubFopCode();
	}

	private String getLpoNumber(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getLpoNumber()) ? OptionalUtil.getValue(customer.getLpoNumber())
				: customerEntity.getLpoNumber();
	}

	private String getDebtorCode(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getDebtorCode()) ? OptionalUtil.getValue(customer.getDebtorCode())
				: customerEntity.getDebtorCode();
	}

	private String getCustomerCode(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getCustomerCode()) ? OptionalUtil.getValue(customer.getCustomerCode())
				: customerEntity.getCustomerCode();
	}

	private void commonValidation(Customer customer) {
		if (OptionalUtil.isPresent(customer.getCurrencyOfInvoice())) {
			String currencyOfInvoice = OptionalUtil.getValue(customer.getCurrencyOfInvoice());
			if (!Pattern.compile("^[A-Za-z]*").matcher(currencyOfInvoice).find()) {
				throw new BusinessException("Currency Of Invoice should be alplabate only");
			}
		}
		if (OptionalUtil.isPresent(customer.getLanguage())) {
			String language = OptionalUtil.getValue(customer.getLanguage());
			if (!Pattern.compile("^[A-Za-z]*").matcher(language).find()) {
				throw new BusinessException("Language should be alplabate only");
			}
		}
		if (OptionalUtil.isPresent(customer.getGovtApplicable())) {
			String govtApplicable = OptionalUtil.getValue(customer.getGovtApplicable());
			if (OptionalUtil.getValue(customer.getGovtApplicable()).trim().length() > 0) {
				if (!Pattern.compile("(^Y|N)").matcher(govtApplicable).find()) {
					throw new BusinessException("Govt Applicable should be Y or N only");
				}
			}
		}
		if (OptionalUtil.isPresent(customer.getTaxCode())) {
			String taxCode = OptionalUtil.getValue(customer.getTaxCode());
			if (!Pattern.compile("[A-Za-z]*").matcher(taxCode).find()) {
				throw new BusinessException("Tax Code should be alplabate only");
			}
		}
		if (OptionalUtil.isPresent(customer.getInvoiceByEmail())) {
			String invoiceByEmail = OptionalUtil.getValue(customer.getInvoiceByEmail());
			if (OptionalUtil.getValue(customer.getInvoiceByEmail()).trim().length() > 0) {
				if (!Pattern.compile("(^Y|N)").matcher(invoiceByEmail).find()) {
					throw new BusinessException("Invoice By Email should be Y or N only");
				}
			}
		}
	}

	public void checkEmpty(Customer customer) {
		if (!OptionalUtil.isPresent(customer.getCustomerName())) {
			customer.setCustomerName(Optional.of(""));
		}
		if (!OptionalUtil.isPresent(customer.getFopCode())) {
			customer.setFopCode(Optional.ofNullable(""));
		}
		if (!OptionalUtil.isPresent(customer.getSubFopCode())) {
			customer.setSubFopCode(Optional.of(""));
		}
		if (!OptionalUtil.isPresent(customer.getLpoNumber())) {
			customer.setLpoNumber(Optional.of(""));
		}
		if (!OptionalUtil.isPresent(customer.getDebtorCode())) {
			customer.setDebtorCode(Optional.of(""));
		}
		if (!OptionalUtil.isPresent(customer.getAgencyCode())) {
			customer.setAgencyCode(Optional.of(""));
		}
	}

	private void checkEmpty(Customer customer, CustomerEntity customerEntity) {
		if (!OptionalUtil.isPresent(customer.getCustomerName())
				&& StringUtils.isEmpty(customerEntity.getCustomerName())) {
			customer.setCustomerName(Optional.of(""));
		}
		if (!OptionalUtil.isPresent(customer.getFopCode()) && StringUtils.isEmpty(customerEntity.getFopCode())) {
			customer.setFopCode(Optional.ofNullable(""));
		}
		if (!OptionalUtil.isPresent(customer.getSubFopCode()) && StringUtils.isEmpty(customerEntity.getSubFopCode())) {
			customer.setSubFopCode(Optional.of(""));
		}
		if (!OptionalUtil.isPresent(customer.getLpoNumber()) && StringUtils.isEmpty(customerEntity.getLpoNumber())) {
			customer.setLpoNumber(Optional.of(""));
		}
		if (!OptionalUtil.isPresent(customer.getDebtorCode()) && StringUtils.isEmpty(customerEntity.getDebtorCode())) {
			customer.setDebtorCode(Optional.of(""));
		}
		if (!OptionalUtil.isPresent(customer.getAgencyCode()) && StringUtils.isEmpty(customerEntity.getAgencyCode())) {
			customer.setAgencyCode(Optional.of(""));
		}
	}

	private void checkOverlapForCreate(Customer customer) {
		if (customer.getCustomerType().isPresent() && customer.getFopCode().isPresent()
				&& customer.getSubFopCode().isPresent() && customer.getLpoNumber().isPresent()
				&& customer.getDebtorCode().isPresent() && customer.getCustomerCode().isPresent()
				&& customer.getAgencyCode().isPresent() && customer.getEffectiveFromDate().isPresent()
				&& customer.getEffectiveToDate().isPresent()) {
			if (customerDao.getOverlapRecordCountForCreate(OptionalUtil.getValue(customer.getCustomerType()),
					OptionalUtil.getValue(customer.getFopCode()), OptionalUtil.getValue(customer.getSubFopCode()),
					OptionalUtil.getValue(customer.getLpoNumber()), OptionalUtil.getValue(customer.getDebtorCode()),
					OptionalUtil.getValue(customer.getCustomerCode()), OptionalUtil.getValue(customer.getAgencyCode()),
					OptionalUtil.getLocalDateValue(customer.getEffectiveFromDate()),
					OptionalUtil.getLocalDateValue(customer.getEffectiveToDate())) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private void checkOverlapForUpdate(Customer customer, CustomerEntity customerEntity) {
		String customerType = getCustomerType(customer, customerEntity);
		String customerCode = getCustomerCode(customer, customerEntity);
		String agencyCode = getAgencyCode(customer, customerEntity);
		String lpoNumber = getLpoNumber(customer, customerEntity);
		String fopCode = getFopCode(customer, customerEntity);
		String subFopCode = getSubFopCode(customer, customerEntity);
		String debtorCode = getDebtorCode(customer, customerEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(customer, customerEntity);
		LocalDate effectiveToDate = getEffectiveToDate(customer, customerEntity);
		if (!customerType.equalsIgnoreCase(customerEntity.getCustomerType())
				|| !(agencyCode != null && agencyCode.equalsIgnoreCase(customerEntity.getAgencyCode()))
				|| !(customerCode != null && customerCode.equalsIgnoreCase(customerEntity.getCustomerCode()))
				|| !(lpoNumber != null && lpoNumber.equalsIgnoreCase(customerEntity.getLpoNumber()))
				|| !(fopCode != null && fopCode.equalsIgnoreCase(customerEntity.getFopCode()))
				|| !(subFopCode != null && subFopCode.equalsIgnoreCase(customerEntity.getSubFopCode()))
				|| !effectiveFromDate.equals(customerEntity.getEffectiveFromDate())
				|| !effectiveToDate.equals(customerEntity.getEffectiveToDate())
				|| !(debtorCode != null && debtorCode.equalsIgnoreCase(customerEntity.getDebtorCode()))) {
			if (customerDao.getOverlapRecordCountForUpdate(agencyCode, customerType, subFopCode, subFopCode, lpoNumber,
					debtorCode, customerCode, customerEntity.getCustomerMasId(), effectiveFromDate,
					effectiveToDate) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private String getAgencyCode(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getAgencyCode()) ? OptionalUtil.getValue(customer.getAgencyCode())
				: customerEntity.getAgencyCode();
	}

	private LocalDate getEffectiveToDate(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(customer.getEffectiveFromDate())
				: customerEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveFromDate(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(customer.getEffectiveToDate())
				: customerEntity.getEffectiveToDate();
	}

	private void validateFopCodeForCreate(Customer customer) {
		if (OptionalUtil.isPresent(customer.getFopCode())) {
			if (OptionalUtil.getValue(customer.getFopCode()).trim().length() > 0) {
				if (fopService.getListOfFOP(customer.getFopCode(), Optional.ofNullable(null), Optional.of(true))
						.size() == 0) {
					throw new BusinessException("Please provide valid Fop Code");
				}
			}
		}
	}

	private void validateFopCodeForUpdate(Customer customer, CustomerEntity customerEntity) {
		if (getFopCode(customer, customerEntity) != null && getFopCode(customer, customerEntity).trim().length() > 0) {
			if (fopService.getListOfFOP(Optional.of(getFopCode(customer, customerEntity)), Optional.ofNullable(null),
					Optional.of(true)).size() == 0) {
				throw new BusinessException("Please provide valid Fop Code");
			}
		}
	}

	private void validateAgencyCodeForCreate(Customer customer) {
		if (OptionalUtil.isPresent(customer.getAgencyCode())) {
			if (OptionalUtil.getValue(customer.getAgencyCode()).trim().length() > 0) {
				if (agencyMasterService
						.getListOfAgency(customer.getAgencyCode(), Optional.ofNullable(null), Optional.ofNullable(null),
								Optional.ofNullable(null), Optional.ofNullable(null), Optional.of(true))
						.size() == 0) {
					throw new BusinessException("Please provide valid Agency Code");
				}
			}
		}
	}

	private void validateAgencyCodeForUpdate(Customer customer, CustomerEntity customerEntity) {
		if (getAgencyCode(customer, customerEntity) != null
				&& getAgencyCode(customer, customerEntity).trim().length() > 0) {
			if (agencyMasterService.getListOfAgency(Optional.of(getAgencyCode(customer, customerEntity)),
					Optional.ofNullable(null), Optional.ofNullable(null), Optional.ofNullable(null),
					Optional.ofNullable(null), Optional.of(true)).size() == 0) {
				throw new BusinessException("Please provide valid Agency Code");
			}
		}
	}

	private void validateLanguage(Customer customer) {
		if (OptionalUtil.isPresent(customer.getClientId()) && OptionalUtil.isPresent(customer.getLanguage())) {
			validateLunguage(OptionalUtil.getValue(customer.getClientId()),
					OptionalUtil.getValue(customer.getLanguage()));
		}
	}

	private void validateLanguage(Customer customer, CustomerEntity customerEntity) {
		if (OptionalUtil.isPresent(customer.getClientId()) || OptionalUtil.isPresent(customer.getLanguage())) {
			validateLunguage(getClientId(customer, customerEntity), getLanguage(customer, customerEntity));
		}
	}

	private String getLanguage(Customer customer, CustomerEntity customerEntity) {
		return OptionalUtil.isPresent(customer.getLanguage()) ? OptionalUtil.getValue(customer.getLanguage())
				: customerEntity.getLanguage();
	}

	private void validateLunguage(String clientId, String language) {
		if (!StringUtils.isEmpty(language)) {
			ListOfValues listOfValuesModel = new ListOfValues();
			listOfValuesModel.setClientId(Optional.of(clientId));
			listOfValuesModel.setTableName(Optional.of(TABLE_NAME));
			listOfValuesModel.setColumnName(Optional.of(LANGUAGE));
			listOfValuesModel.setIsActive(true);
			listOfValuesModel.setFieldValue(Optional.of(language));
			if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
				throw new BusinessException("Language[" + language + NOT_VALID);
			}
		}
	}

	protected void validateEffectiveToDate(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}
}