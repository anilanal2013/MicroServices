package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.master.app.dao.entity.SPAHeaderStgEntity;

public class SPAHeaderStgEntitySpecification {
	SPAHeaderStgEntitySpecification() {

	}

	public static Specification<SPAHeaderStgEntity> search(String cxrCode, Integer spaCodeSeqNumber, Integer spaKey,
			String spaId, String effectiveIssueDate, String effectiveUpliftDate) {
		return (spaHeaderStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (cxrCode != null) {
				predicates.add(criteriaBuilder.equal(spaHeaderStgEntity.get("cxrCode"), cxrCode));
			}
			if (spaCodeSeqNumber != null) {
				predicates.add(criteriaBuilder.equal(spaHeaderStgEntity.get("spaCodeSeqNumber"), spaCodeSeqNumber));
			}
			if (spaKey != null) {
				predicates.add(criteriaBuilder.equal(spaHeaderStgEntity.get("spaKey"), spaKey));
			}
			if (spaId != null) {
				predicates.add(criteriaBuilder.equal(spaHeaderStgEntity.get("spaId"), spaId));
			}
			if (effectiveIssueDate != null) {
				predicates.add(criteriaBuilder.between(criteriaBuilder.literal(effectiveIssueDate),
						spaHeaderStgEntity.get("effectiveIssueFromDate"),
						spaHeaderStgEntity.get("effectiveIssueToDate")));
			}
			if (effectiveUpliftDate != null) {
				predicates.add(criteriaBuilder.between(criteriaBuilder.literal(effectiveUpliftDate),
						spaHeaderStgEntity.get("effectiveUpliftFromDate"),
						spaHeaderStgEntity.get("effectiveUpliftToDate")));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
	
	public static Specification<SPAHeaderStgEntity> searchForProcessingCoupon(String clientId, String cxrCode, String effectiveIssueDate, String effectiveOriginalDate, String effectiveUpliftDate) {
		return (spaHeaderStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (clientId != null) {
				predicates.add(criteriaBuilder.equal(spaHeaderStgEntity.get("clientId"), clientId));
			}
			if (cxrCode != null) {
				predicates.add(criteriaBuilder.equal(spaHeaderStgEntity.get("cxrCode"), cxrCode));
			}
			if (effectiveIssueDate != null) {
				predicates.add(criteriaBuilder.between(criteriaBuilder.literal(LocalDate.parse(effectiveIssueDate)),
						spaHeaderStgEntity.get("effectiveIssueFromDate"),
						spaHeaderStgEntity.get("effectiveIssueToDate")));
			}
			if (effectiveOriginalDate != null) {
				predicates.add(criteriaBuilder.between(criteriaBuilder.literal(LocalDate.parse(effectiveOriginalDate)),
						spaHeaderStgEntity.get("effectiveOrigIssueFromDate"),
						spaHeaderStgEntity.get("effectiveOrigIssueToDate")));
			}
			if (effectiveUpliftDate != null) {
				predicates.add(criteriaBuilder.between(criteriaBuilder.literal(LocalDate.parse(effectiveUpliftDate)),
						spaHeaderStgEntity.get("effectiveUpliftFromDate"),
						spaHeaderStgEntity.get("effectiveUpliftToDate")));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
}
