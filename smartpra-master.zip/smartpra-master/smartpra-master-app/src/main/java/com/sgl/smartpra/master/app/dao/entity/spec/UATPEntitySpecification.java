package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.UATPEntity;

public class UATPEntitySpecification {

	private static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";

	private static final String EFFECTIVE_TO_DATE = "effectiveToDate";

	public static Specification<UATPEntity> search(Optional<String> clientId, Optional<String> uatpRecType,
			Optional<String> issueCxr, Optional<String> operatingCxr, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate) {
		return (uatpEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.like(uatpEntity.get("clientId"), OptionalUtil.getValue(clientId) + "%"));
			}
			if (OptionalUtil.isPresent(uatpRecType)) {
				predicates.add(
						criteriaBuilder.like(uatpEntity.get("uatpRecType"), OptionalUtil.getValue(uatpRecType) + "%"));
			}
			if (OptionalUtil.isPresent(issueCxr)) {
				predicates.add(criteriaBuilder.like(uatpEntity.get("issueCxr"), OptionalUtil.getValue(issueCxr) + "%"));
			}
			if (OptionalUtil.isPresent(operatingCxr)) {
				predicates.add(criteriaBuilder.like(uatpEntity.get("operatingCxr"),
						OptionalUtil.getValue(operatingCxr) + "%"));
			}

			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								uatpEntity.get(EFFECTIVE_FROM_DATE), uatpEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								uatpEntity.get(EFFECTIVE_FROM_DATE), uatpEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(uatpEntity.get(EFFECTIVE_FROM_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate)),
						criteriaBuilder.between(uatpEntity.get(EFFECTIVE_TO_DATE),
								OptionalUtil.getLocalDateValue(effectiveFromDate),
								OptionalUtil.getLocalDateValue(effectiveToDate))));

			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							uatpEntity.get(EFFECTIVE_FROM_DATE), uatpEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							uatpEntity.get(EFFECTIVE_FROM_DATE), uatpEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			orderByAsc(uatpEntity, criteriaQuery, criteriaBuilder, "uatpRecType", "issueCxr", "operatingCxr",
					EFFECTIVE_FROM_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static void orderByAsc(Root<UATPEntity> uatpEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String uatpRecType, String issueCxr, String operatingCxr,
			String effectiveFromDate) {
		criteriaQuery.orderBy(criteriaBuilder.desc(uatpEntity.get(uatpRecType)),
				criteriaBuilder.asc(uatpEntity.get(issueCxr)), criteriaBuilder.asc(uatpEntity.get(operatingCxr)),
				criteriaBuilder.desc(uatpEntity.get(effectiveFromDate)));
	}

	public static Specification<UATPEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (uatpEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), uatpEntity.get(EFFECTIVE_FROM_DATE),
				uatpEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<UATPEntity> greaterThanOrEqualTo(LocalDate effectiveFromDate) {
		return (uatpEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(uatpEntity.get(EFFECTIVE_FROM_DATE), effectiveFromDate);
	}

	public static Specification<UATPEntity> lessThanOrEqualTo(LocalDate effectiveToDate) {
		return (uatpEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(uatpEntity.get(EFFECTIVE_TO_DATE), effectiveToDate);
	}

	public static Specification<UATPEntity> equalsClientId(String clientId) {
		return (uatpEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(uatpEntity.get("clientId"),
				clientId);
	}

	public static Specification<UATPEntity> equalsIssueCxr(String issueCxr) {
		return (uatpEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(uatpEntity.get("issueCxr"),
				issueCxr);
	}

	public static Specification<UATPEntity> equalsOperatingCxr(String operatingCxr) {
		return (uatpEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(uatpEntity.get("operatingCxr"),
				operatingCxr);
	}

	public static Specification<UATPEntity> notEqualsUatpId(Integer uatpId) {
		return (uatpEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(uatpEntity.get("uatpId"),
				uatpId);
	}
}
