package com.sgl.smartpra.master.app.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.MasAccountEntity;

@Repository
public interface AccountMasterDao {

	List<MasAccountEntity> findAll();

	List<MasAccountEntity> findByAccountAlphaCode(String byAccountAlphaCode);

}
