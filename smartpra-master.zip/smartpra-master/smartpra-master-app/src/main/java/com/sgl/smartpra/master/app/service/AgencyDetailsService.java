package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.AgencyDetailsModel;

public interface AgencyDetailsService {

	public List<AgencyDetailsModel> getAgencyDetailsByEffectiveDate(Optional<String> agencyCode,
			Optional<String> clientId, Optional<String> transactionType, Optional<String> reportingFrequency,
			Optional<String> transactionCurrency, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate);

	public AgencyDetailsModel getAgencyDetailsByAgencyDetailsId(Integer agencyId, int agencyDetailId);

	public AgencyDetailsModel createAgencyDetails(Integer agencyId, AgencyDetailsModel agencyDetailsModel);

	public AgencyDetailsModel updateAgencyDetails(Integer agencyId ,Integer agencyDetailId, AgencyDetailsModel agencyDetailsModel);

	public void deactivateAgencyDetail(Integer agencyId,int agencyDetailId, String lastUpdatedBy);

	public void activateAgencyDetail(Integer agencyId,int agencyDetailId, String lastUpdatedBy);

	public List<AgencyDetailsModel> getAgencyDetailsByAgencyCode(Optional<String> clientId, Optional<String> agencyCode,
			Optional<String> effectiveDate);
	
	public List<AgencyDetailsModel> getAgencyDetailsByEffectiveDate(Integer agencyId, Optional<String> agencyCode,
			Optional<String> clientId, Optional<String> transactionType, Optional<String> reportingFrequency,
			Optional<String> transactionCurrency, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate, Optional<String> exceptionCall);

}
