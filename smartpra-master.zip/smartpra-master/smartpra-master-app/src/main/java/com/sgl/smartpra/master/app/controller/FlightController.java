package com.sgl.smartpra.master.app.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.exception.ServiceException;
import com.sgl.smartpra.master.app.service.FlightService;
import com.sgl.smartpra.master.model.Flight;

@RestController
public class FlightController {
	@Autowired
	FlightService flightService;

	@GetMapping("/flight")
	public Flight getFlightByEffectiveDate(
			@RequestParam(value = "effectiveDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date effectiveDate,
			@RequestParam(value = "flightFrom", required = true) String flightFrom,
			@RequestParam(value = "flightTo", required = true) String flightTo,
			@RequestParam(value = "from", required = true) String from,
			@RequestParam(value = "to", required = true) String to) {
		return flightService.getFlightByEffectiveDate(effectiveDate, flightFrom, flightTo, from, to);
	}
	
	@GetMapping("/flightByFlightNumber")
	public Flight getFlightByFlightNumber(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "effectiveDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") String effectiveDate,
			@RequestParam(value = "flightNumber", required = true) String flightNumber,
			@RequestParam(value = "from", required = true) String from,
			@RequestParam(value = "to", required = true) String to) {
		return flightService.getFlightByFlightNumber(clientId, effectiveDate, flightNumber, from, to);
	}

	@GetMapping("/flight/{flightId}")
	public Flight getFlightByFlightId(@PathVariable(value = "flightId") Integer flightId) {
		return flightService.getFlightByFlightId(flightId);
	}

	@PostMapping("/flight")
	public Flight createFlight(@Validated(Create.class) @RequestBody Flight flight) {
		return flightService.createFlight(flight);
	}

	@PutMapping("/flight/{flightId}")
	public Flight updateFlight(@PathVariable(value = "flightId") Integer flightId,
			@Validated(Update.class) @RequestBody Flight flight) {
		Flight flight2 = null;

		try {
			flight2 = flightService.updateFlight(flightId, flight);
		} catch (DataIntegrityViolationException e) {
			throw new ServiceException(
					"FromDate,ToDate,FlightFrom,FlightTo,From,To and ClientId should be one is unique.");
		}
		return flight2;
	}

	@PutMapping("/flight/{flightId}/deactivate")
	public void deactivateCarrierAlliance(@Valid @PathVariable(value = "flightId") Integer flightId,
			@RequestParam(value = "lastUpdatedBy", required = false) String lastUpdatedBy) {
		flightService.deactivateFlight(flightId, lastUpdatedBy);
	}

	@PutMapping("/flight/{flightId}/activate")
	public void activateCarrierAlliance(@Valid @PathVariable(value = "flightId") Integer flightId,
			@RequestParam(value = "lastUpdatedBy", required = false) String lastUpdatedBy) {
		flightService.activateFlight(flightId, lastUpdatedBy);
	}

	@GetMapping("/flight-details")
	public List<Flight> getFlightByFlightDetails(
			@RequestParam(value = "flightAttribute1", required = false) String flightAttribute1,
			@RequestParam(value = "flightAttribute2", required = false) String flightAttribute2,
			@RequestParam(value = "flightAttribute3", required = false) String flightAttribute3,
			@RequestParam(value = "flightAttribute4", required = false) String flightAttribute4,
			@RequestParam(value = "flightAttribute5", required = false) String flightAttribute5) {
		return flightService.getFlightByFlightDetails(flightAttribute1, flightAttribute2, flightAttribute3,
				flightAttribute4, flightAttribute5);
	}
}
