package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.AccountingTransactionEntity;

@Repository
public interface AccountingTransactionDao {

	public AccountingTransactionEntity create(AccountingTransactionEntity accountingTransactionEntity);

	public AccountingTransactionEntity update(AccountingTransactionEntity accountingTransactionEntity);

	public Optional<AccountingTransactionEntity> findByAccountingId(Integer accountingTransactionId);

	public List<AccountingTransactionEntity> getAccountingTransactionListByFkId(Integer scenarioNumber,
			Optional<Integer> accountDefinitionIdentifier, Optional<String> accountAlphaCode, Boolean isActive);

	public long getOverlapRecordCount(String clientId, Integer scenarioNumber, Integer transactionSerialNo);

	public long getOverlapRecordCount(String clientId, Integer scenarioNumber, Integer transactionSerialNo,
			Integer accountingTransactionId);

	public List<AccountingTransactionEntity> findByScenarioNumber(Optional<Integer> scenarioNumber);
}
