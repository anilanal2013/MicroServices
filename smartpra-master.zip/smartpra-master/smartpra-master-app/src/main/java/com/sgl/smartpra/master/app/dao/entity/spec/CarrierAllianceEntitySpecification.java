package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.CarrierAllianceEntity;

public final class CarrierAllianceEntitySpecification {

	private CarrierAllianceEntitySpecification() {
	}

	public static Specification<CarrierAllianceEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), carrierAllianceEntity.get("effectiveFromDate"),
				carrierAllianceEntity.get("effectiveToDate"));
	}
	
	public static Specification<CarrierAllianceEntity> betweenEffectiveFrom(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				carrierAllianceEntity.get("effectiveFromDate"), criteriaBuilder.literal(effectiveFromDate),
				criteriaBuilder.literal(effectiveToDate));
	}

	public static Specification<CarrierAllianceEntity> equalsAllianceName(String allianceName) {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierAllianceEntity.get("allianceName"), allianceName);
	}

	public static Specification<CarrierAllianceEntity> equalsClientId(String clientId) {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierAllianceEntity.get("clientId"), clientId);
	}

	public static Specification<CarrierAllianceEntity> equalsCarrierCode(String carrierCode) {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierAllianceEntity.get("carrierCode"), carrierCode);
	}

	public static Specification<CarrierAllianceEntity> isActive() {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierAllianceEntity.get("activate"), true);
	}

	public static Specification<CarrierAllianceEntity> notEqualsCarrierAllianceDtlId(Integer carrierAllianceDtlId) {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(carrierAllianceEntity.get("carrierAllianceDtlId"), carrierAllianceDtlId);
	}

	public static void orderByCarrierCodeByAsc(Root<CarrierAllianceEntity> carrierAllianceEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String carrierCode) {
		criteriaQuery.orderBy(criteriaBuilder.asc(carrierAllianceEntity.get(carrierCode)));
	}

	public static Specification<CarrierAllianceEntity> search(Optional<String> carrierCode, Optional<String> clientId,
			Optional<String> allianceName, Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(carrierCode)) {
				predicates.add(criteriaBuilder.like(carrierAllianceEntity.get("carrierCode"),
						OptionalUtil.getValue(carrierCode) + "%"));
			}
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.like(carrierAllianceEntity.get("clientId"),
						OptionalUtil.getValue(clientId) + "%"));
			}

			if (OptionalUtil.isPresent(allianceName)) {
				predicates.add(criteriaBuilder.like(carrierAllianceEntity.get("allianceName"),
						OptionalUtil.getValue(allianceName) + "%"));
			}

			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
						carrierAllianceEntity.get("effectiveFromDate"), carrierAllianceEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								carrierAllianceEntity.get("effectiveFromDate"),
								carrierAllianceEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							carrierAllianceEntity.get("effectiveFromDate"),
							carrierAllianceEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							carrierAllianceEntity.get("effectiveFromDate"),
							carrierAllianceEntity.get("effectiveToDate")));
				}
			}

			predicates.add(criteriaBuilder.equal(carrierAllianceEntity.get("activate"), true));

			orderByCarrierCodeByAsc(carrierAllianceEntity, criteriaQuery, criteriaBuilder, "carrierCode");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
