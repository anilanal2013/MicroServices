package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.AircraftEntity;
import com.sgl.smartpra.master.model.Aircraft;

@Repository
public interface AircraftDao {

	public Optional<AircraftEntity> findById(Integer aircraftId);

	public AircraftEntity create(AircraftEntity aircraftEntity);

	public AircraftEntity update(AircraftEntity mapToEntity);

	public List<AircraftEntity> findAll(Aircraft aircraft, Optional<String> exceptionCall);

	List<AircraftEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	// -- This is for Create- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String aircraftRegistration);

	// -- This is for Update- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String aircraftRegistration, Integer aircraftId);

	public List<AircraftEntity> getAllAircraftDetails(Integer firstClassCapacity, Integer businessClassCapacity,
			Integer premiumEconomyClassCapacity, Integer economyClassCapacity);

}
