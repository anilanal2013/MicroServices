package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.HandlingFee;

public interface HandlingFeeService {

	List<HandlingFee> getAllHandlingFee(Optional<String> issueCxr, Optional<String> operatingCxr,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	HandlingFee getHandlingFeeByHandlingFeeId(Integer handlingFeeId);

	HandlingFee createHandlingFee(HandlingFee handlingFee);

	HandlingFee updateHandlingFee(Integer handlingFeeId, HandlingFee handlingFee);  

}
