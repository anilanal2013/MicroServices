package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.FFYIdentificationEntity;
import com.sgl.smartpra.master.model.FFYIdentification;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FFYIdentificationMapper extends BaseMapper<FFYIdentification, FFYIdentificationEntity> {

	FFYIdentificationEntity mapToEntity(FFYIdentification ffyIdentification,
			@MappingTarget FFYIdentificationEntity ffyIdentificationEntity);

	@Mapping(source = "ffyIdentifyId", target = "ffyIdentifyId", ignore = true)
	FFYIdentificationEntity mapToEntity(FFYIdentification ffyIdentification);
}
