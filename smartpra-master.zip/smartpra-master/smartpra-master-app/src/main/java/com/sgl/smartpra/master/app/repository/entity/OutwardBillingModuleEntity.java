package com.sgl.smartpra.master.app.repository.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

@Entity
@Table(name = "mas_outward_billing_module")
public class OutwardBillingModuleEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "billing_module_id")
	private Integer billingModuleId;
	@Column(name = "client_id")
	private String clientId;
	@Column(name = "billing_month")
	private String billingMonth;
	@Column(name = "billing_period")
	private Integer billingPeriod;
	@Column(name = "module_name")
	private String moduleName;
	@Column(name = "close_indicator")
	private String closeIndicator;
	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "created_date")
	private Timestamp createdDate;
	@Column(name = "last_updated_by")
	private String lastUpdatedBy;
	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name = "skip_ind")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean skipInd;

	public Boolean getSkipInd() {
		return skipInd;
	}

	public void setSkipInd(Boolean skipInd) {
		this.skipInd = skipInd;
	}

	public Integer getBillingModuleId() {
		return billingModuleId;
	}

	public void setBillingModuleId(Integer billingModuleId) {
		this.billingModuleId = billingModuleId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getBillingMonth() {
		return billingMonth;
	}

	public void setBillingMonth(String billingMonth) {
		this.billingMonth = billingMonth;
	}

	public Integer getBillingPeriod() {
		return billingPeriod;
	}

	public void setBillingPeriod(Integer billingPeriod) {
		this.billingPeriod = billingPeriod;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getCloseIndicator() {
		return closeIndicator;
	}

	public void setCloseIndicator(String closeIndicator) {
		this.closeIndicator = closeIndicator;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
