package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.FareBasisGroupcodeEntity;

public class FareBasisGroupCodeEntitySpecification {
	
	private FareBasisGroupCodeEntitySpecification() {
		
	}
	
	private static final String ATPCOFARETYPE = "atpcoFareType"; 
	private static final String BTITINDICATOR = "btItIndicator"; 
	private static final String CABIN = "cabin"; 
	private static final String DAYOFWEEK = "dayOfWeek";
	private static final String DISCOUNTCODE = "discountCode";
	private static final String FAREOWNERCXR = "fareOwnerCXR";
	private static final String FARETEXT = "fareText";
	private static final String FBDESCRIPTION = "fbDescription";
	private static final String FBGROUPCODE = "fbGroupCode";
	private static final String IATAFARETYPE = "iataFareType";
	private static final String ISPATTERN = "isPattern";
	private static final String ISSUECXR = "issueCXR";
	private static final String JOURNEYTYPE = "journeyType";
	private static final String NORMALSPECIAL = "normalSpecial";
	private static final String NONREVENUEFLAG = "nonRevenueFlag";
	private static final String PASSENGERNAME = "passengerName";
	private static final String PAXTYPE = "paxType";
	private static final String SEASONALCODE = "seasonalCode";
	private static final String TICKETEDFAREBASIS = "ticketedFareBasis";
	private static final String TICKETEDTD = "ticketedTD";
	private static final String UNPUBLISHFLAG = "unpublishFlag";
	private static final String ZEDIDENTIFIER = "zedIdentifier";
	
	public static Specification<FareBasisGroupcodeEntity> equalsClientId(String clientId) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get("clientId"), clientId);
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalsSeqLineNumber(Integer seqLineNumber) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get("seqLineNumber"), seqLineNumber);
	}
	
	public static Specification<FareBasisGroupcodeEntity> isActive() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get("isActive"), true);
	}
	
	public static void orderByAsc(Root<FareBasisGroupcodeEntity> fareBasisGroupcodeEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder) {
		criteriaQuery.orderBy(criteriaBuilder.asc(fareBasisGroupcodeEntity.get(FBGROUPCODE)));
	}
	
	public static Specification<FareBasisGroupcodeEntity> getActiveFBGroupCode() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

				predicates.add(criteriaBuilder.equal(fareBasisGroupcodeEntity.get("isActive"), true));
			
			orderByAsc(fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	/* atpcoFareType */
	public static Specification<FareBasisGroupcodeEntity> isATPCOFareTypeNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(ATPCOFARETYPE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isATPCOFareTypeNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(ATPCOFARETYPE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalATPCOFareType(String atpcoFareType) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(ATPCOFARETYPE),atpcoFareType);
	}
	
	/* btItIndicator */
	public static Specification<FareBasisGroupcodeEntity> isBTITIndicatorNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(BTITINDICATOR));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isBTITIndicatorNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(BTITINDICATOR));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalBTITIndicator(String btItIndicator) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(BTITINDICATOR),btItIndicator);
	}
	
	/* cabin */
	public static Specification<FareBasisGroupcodeEntity> isCabinNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(CABIN));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isCabinNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(CABIN));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalCabin(String cabin) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(CABIN),cabin);
	}
	
	/* dayOfWeek */
	public static Specification<FareBasisGroupcodeEntity> isDOWNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(DAYOFWEEK));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isDOWNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(DAYOFWEEK));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalDOW(String dayOfWeek) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(DAYOFWEEK),dayOfWeek);
	}
	
	/* discountCode */
	public static Specification<FareBasisGroupcodeEntity> isDiscountCodeNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(DISCOUNTCODE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isDiscountCodeNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(DISCOUNTCODE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalDiscountCode(String discountCode) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(DISCOUNTCODE),discountCode);
	}
	
	/* fareOwnerCXR */
	public static Specification<FareBasisGroupcodeEntity> isFareOwnerCXRNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(FAREOWNERCXR));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isFareOwnerCXRNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(FAREOWNERCXR));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalFareOwnerCXR(String fareOwnerCXR) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(FAREOWNERCXR),fareOwnerCXR);
	}
	
	/* fareText */
	public static Specification<FareBasisGroupcodeEntity> isFareTextNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(FARETEXT));
	}  
	
	public static Specification<FareBasisGroupcodeEntity> isFareTextNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(FARETEXT));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalFareText(String fareText) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(FARETEXT),fareText);
	}
	
	/* fbDescription */
	public static Specification<FareBasisGroupcodeEntity> isFBDescriptionNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(FBDESCRIPTION));
	}  
	
	public static Specification<FareBasisGroupcodeEntity> isFBDescriptionNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(FBDESCRIPTION));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalFBDescription(String fbDescription) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(FBDESCRIPTION),fbDescription);
	}
	
	/* fbGroupCode */
	public static Specification<FareBasisGroupcodeEntity> isFBGroupCodeNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(FBGROUPCODE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isFBGroupCodeNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(FBGROUPCODE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalsFBGroupCode(String fbGroupCode) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(FBGROUPCODE), fbGroupCode);
	}
	
	/* iataFareType */  
	public static Specification<FareBasisGroupcodeEntity> isIATAFareTypeNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(IATAFARETYPE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isIATAFareTypeNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(IATAFARETYPE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalIATAFareType(String iataFareType) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(IATAFARETYPE),iataFareType);
	}
	
	/*isPattern*/
	public static Specification<FareBasisGroupcodeEntity> isIsPatternNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(ISPATTERN));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isIsPatternNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(ISPATTERN));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalIsPattern(Boolean isPattern) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(ISPATTERN),isPattern);
	}
	
	/*issueCXR*/
	public static Specification<FareBasisGroupcodeEntity> isIssueCXRNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(ISSUECXR));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isIssueCXRNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(ISSUECXR));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalIssueCXR(String issueCXR) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(ISSUECXR),issueCXR);
	}
	
	/* journeyType */
	public static Specification<FareBasisGroupcodeEntity> isJourneyTypeNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(JOURNEYTYPE));
	}

	public static Specification<FareBasisGroupcodeEntity> isJourneyTypeNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(JOURNEYTYPE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalJourneyType(String journeyType) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(JOURNEYTYPE),journeyType);
	}
	
	/*normalSpecial*/
	public static Specification<FareBasisGroupcodeEntity> isNormalSpecialNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(NORMALSPECIAL));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isNormalSpecialNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(NORMALSPECIAL));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalNormalSpecial(String normalSpecial) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(NORMALSPECIAL),normalSpecial);
	}
	
	/* nonRevenueFlag */
	public static Specification<FareBasisGroupcodeEntity> isNonRevenueFlagNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(NONREVENUEFLAG));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isNonRevenueFlagNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(NONREVENUEFLAG));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalNonRevenueFlag(Boolean nonRevenueFlag) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(NONREVENUEFLAG),nonRevenueFlag);
	}
	
	/*passengerName*/
	public static Specification<FareBasisGroupcodeEntity> isPassengerNameNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(PASSENGERNAME));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isPassengerNameNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(PASSENGERNAME));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalPassengerName(String passengerName) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(PASSENGERNAME),passengerName);
	}
	
	/*paxType*/
	public static Specification<FareBasisGroupcodeEntity> isPaxTypeNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(PAXTYPE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isPaxTypeNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(PAXTYPE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalPaxType(String paxType) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(PAXTYPE),paxType);
	}
	
	/* seasonalCode */
	public static Specification<FareBasisGroupcodeEntity> isSeasonalCodeNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(SEASONALCODE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isSeasonalCodeNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(SEASONALCODE));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalSeasonalCode(String seasonalCode) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(SEASONALCODE),seasonalCode);
	}
	
	/*ticketedFareBasis*/
	public static Specification<FareBasisGroupcodeEntity> isTicketedFareBasisNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(TICKETEDFAREBASIS));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isTicketedFareBasisNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(TICKETEDFAREBASIS));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalTicketedFareBasis(String ticketedFareBasis) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(TICKETEDFAREBASIS),ticketedFareBasis);
	}
	
	/*ticketedTD*/
	public static Specification<FareBasisGroupcodeEntity> isTicketedTDNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(TICKETEDTD));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isTicketedTDNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(TICKETEDTD));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalTicketedTD(String ticketedTD) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(TICKETEDTD),ticketedTD);
	}
	
	/* unpublishFlag */
	public static Specification<FareBasisGroupcodeEntity> isUnPublishFlagNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(UNPUBLISHFLAG));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isUnPublishFlagNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(UNPUBLISHFLAG));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalUnPublishFlag(Boolean unpublishFlag) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(UNPUBLISHFLAG),unpublishFlag);
	}
	
	/* zedIdentifier */
	public static Specification<FareBasisGroupcodeEntity> isZedIdentifierNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fareBasisGroupcodeEntity.get(ZEDIDENTIFIER));
	}
	
	public static Specification<FareBasisGroupcodeEntity> isZedIdentifierNotNull() {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNotNull(fareBasisGroupcodeEntity.get(ZEDIDENTIFIER));
	}
	
	public static Specification<FareBasisGroupcodeEntity> equalZedIdentifier(String zedIdentifier) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisGroupcodeEntity.get(ZEDIDENTIFIER),zedIdentifier);
	}
	
	public static Specification<FareBasisGroupcodeEntity> search(Optional<String> fbGroupCode, Optional<String> fbDescription,
			Optional<Boolean> isActive) {
		return (fareBasisGroupcodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(fbGroupCode)) {
				predicates.add(criteriaBuilder
						.like(fareBasisGroupcodeEntity.get(FBGROUPCODE), OptionalUtil.getValue(fbGroupCode)+"%"));
				
			}
			if (OptionalUtil.isPresent(fbDescription)) {
				predicates.add(criteriaBuilder
						.like(fareBasisGroupcodeEntity.get(FBDESCRIPTION),OptionalUtil.getValue(fbDescription)+"%"));
			}
			
			if (OptionalUtil.isPresent(isActive) ) {
				predicates.add(
						criteriaBuilder.equal(fareBasisGroupcodeEntity.get("isActive"),  OptionalUtil.getValue(isActive)));
			}
			if (!OptionalUtil.isPresent(isActive)) {
				predicates.add(criteriaBuilder.equal(fareBasisGroupcodeEntity.get("isActive"), true));
			}			
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
}
