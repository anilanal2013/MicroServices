package com.sgl.smartpra.master.app.repository.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_interface_reference")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class InterfaceReferenceEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "interface_ref_id", nullable = false, length = 3)
	private int interfaceRefId;

	@Column(name = "client_id", nullable = false, length = 2)
	@NotEmpty
	private String clientId;

	@Column(name = "data_source", nullable = false, length = 3)
	@NotEmpty
	private String dataSource;

	@Column(name = "station_code", nullable = false, length = 3)
	private String stationCode;

	@Column(name = "commission_includes", length = 1)
	private String commissionIncludes;

	@Column(name = "commission_percentage")
	private double commissionPercentage;

	@Column(name = "decimal_precision", length = 1)
	private String decimalPrecision;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "net_gross_flag", length = 1)
	private String netGrossFlag;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
