package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.RouteCodeDao;
import com.sgl.smartpra.master.app.dao.entity.RouteCodeEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.RouteCodeEntitySpec;
import com.sgl.smartpra.master.app.dao.repository.RouteCodeRepository;
import com.sgl.smartpra.master.model.RouteCode;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RouteCodeDaoImpl implements RouteCodeDao {

	@Autowired
	private RouteCodeRepository routeCodeRepository;

	@Override
	public List<RouteCodeEntity> getAllRouteCode(RouteCode routeCodeModel) {
		return routeCodeRepository.findAll(RouteCodeEntitySpec.search(routeCodeModel.getClientId(),
				routeCodeModel.getRouting(), routeCodeModel.getRouteCode(), routeCodeModel.getEffectiveFromDate(),
				routeCodeModel.getEffectiveToDate()));
	}

	@Override
	@Cacheable(value = "routeCode", key = "#routeCodeId")
	public Optional<RouteCodeEntity> findById(Integer routeCodeId) {
		log.info("Cacheable Route Code Entity's ID= {}" + routeCodeId);
		return routeCodeRepository.findById(routeCodeId);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "routeCode", key = "#routeCodeEntity.routeCodeId") })
	public RouteCodeEntity createRouteCode(RouteCodeEntity routeCodeEntity) {
		return routeCodeRepository.save(routeCodeEntity);
	}

	@Override
	@CachePut(value = "routeCode", key = "#routeCodeEntity.routeCodeId")
	public RouteCodeEntity updateRouteCode(RouteCodeEntity routeCodeEntity) {
		return routeCodeRepository.save(routeCodeEntity);
	}

	@Override
	public long getOverLapForCreate(String clientId, String routeCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return routeCodeRepository.count(Specification
				.where(RouteCodeEntitySpec.equalsClientId(clientId).and(RouteCodeEntitySpec.equalsFOPCode(routeCode))
						.and((RouteCodeEntitySpec.betweenEffectiveFromAndEffectiveToDate((effectiveFromDate))
								.or(RouteCodeEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
										.or(RouteCodeEntitySpec.greaterThanOrEqualTo(effectiveFromDate)
												.and(RouteCodeEntitySpec.lessThanOrEqualTo(effectiveToDate))))));
	}

	@Override
	public long getOverLapForUpdate(String clientId, String routeCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, Integer routeCodeId) {
		return routeCodeRepository.count(Specification
				.where(RouteCodeEntitySpec.equalsClientId(clientId).and(RouteCodeEntitySpec.equalsFOPCode(routeCode))
						.and((RouteCodeEntitySpec.betweenEffectiveFromAndEffectiveToDate((effectiveFromDate))
								.or(RouteCodeEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
										.or(RouteCodeEntitySpec.greaterThanOrEqualTo(effectiveFromDate)
												.and(RouteCodeEntitySpec.lessThanOrEqualTo(effectiveToDate))))
						.and(RouteCodeEntitySpec.notEqualsRouteCodeId(routeCodeId))));
	}

	@Override
	public Page<RouteCodeEntity> getAllRouteCode(RouteCodeEntity mapToEntity, Pageable pageable) {
		return routeCodeRepository.findAll(RouteCodeEntitySpec.search(mapToEntity), pageable);
	}

	@Override
	public long getTotalCount(RouteCodeEntity mapToEntity) {
		return routeCodeRepository.count(RouteCodeEntitySpec.search(mapToEntity));
	}
}
