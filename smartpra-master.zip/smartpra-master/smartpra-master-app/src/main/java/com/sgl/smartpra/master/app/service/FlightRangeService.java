package com.sgl.smartpra.master.app.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.FlightRange;

public interface FlightRangeService {

	public FlightRange createFlightRange(FlightRange flightRange);

	public List<FlightRange> getAllFlightRange(Optional<String> flightRangeId, Optional<String> isMarketingOperating,
			Optional<String> cxrCode, Optional<String> flightNumber, Optional<Boolean> activate);

	public List<FlightRange> getFlightRangeBySearch(String flightRangeId, String isMarketingOperating, String cxrCode,
			String flightNumber, LocalDate saleDate, LocalDate travelDate);

	public FlightRange getFlightRangeByFlightRangeAutoId(Integer flightRangeAutoId);

	public FlightRange updateFlightRange(Integer flightRangeAutoId, FlightRange flightRange);

	public void deactivateFlightRange(FlightRange flightRange);

	public void activateFlightRange(FlightRange flightRange);

	public List<FlightRange> valiadateIssueDate(Integer flightRangeAutoId, String ticketedIssueDate,String clientId, String flag);

}
