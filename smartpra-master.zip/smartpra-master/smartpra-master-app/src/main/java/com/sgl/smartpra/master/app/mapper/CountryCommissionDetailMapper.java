package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.CountryCommissionDetailEntity;
import com.sgl.smartpra.master.model.CountryCommissionDetail;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CountryCommissionDetailMapper extends BaseMapper<CountryCommissionDetail, CountryCommissionDetailEntity>{
	
	CountryCommissionDetailEntity mapToEntity(CountryCommissionDetail countryCommissionDetail, @MappingTarget CountryCommissionDetailEntity countryCommissionDetailEntity);

	@Mapping(source = "countryCommissionDetailId", target = "countryCommissionDetailId", ignore = true)
	CountryCommissionDetailEntity mapToEntity(CountryCommissionDetail countryCommissionDetail);
	
}
