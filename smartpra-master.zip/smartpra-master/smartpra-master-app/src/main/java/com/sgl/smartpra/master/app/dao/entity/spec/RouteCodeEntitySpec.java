package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.RouteCodeEntity;

public class RouteCodeEntitySpec {

	private static void orderByDesc(Root<RouteCodeEntity> routeCodeEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String createdDate) {
		criteriaQuery.orderBy(criteriaBuilder.desc(routeCodeEntity.get(createdDate)));
	}

	public static Specification<RouteCodeEntity> search(Optional<String> clientId, Optional<String> routing,
			Optional<String> routeCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return (routeCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(routeCodeEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(routing)) {
				predicates.add(
						criteriaBuilder.like(routeCodeEntity.get("routing"), OptionalUtil.getValue(routing) + "%"));
			}
			if (OptionalUtil.isPresent(routeCode)) {
				predicates.add(
						criteriaBuilder.like(routeCodeEntity.get("routeCode"), OptionalUtil.getValue(routeCode) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								routeCodeEntity.get("effectiveFromDate"), routeCodeEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								routeCodeEntity.get("effectiveFromDate"), routeCodeEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							routeCodeEntity.get("effectiveFromDate"), routeCodeEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							routeCodeEntity.get("effectiveFromDate"), routeCodeEntity.get("effectiveToDate")));
				}
			}
			orderByDesc(routeCodeEntity, criteriaQuery, criteriaBuilder, "createdDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<RouteCodeEntity> equalsFOPCode(String routeCode) {
		return (routeCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(routeCodeEntity.get("routeCode"), routeCode);
	}

	public static Specification<RouteCodeEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (routeCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), routeCodeEntity.get("effectiveFromDate"),
				routeCodeEntity.get("effectiveToDate"));

	}

	public static Specification<RouteCodeEntity> equalsClientId(String clientId) {
		return (routeCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(routeCodeEntity.get("clientId"), clientId);
	}

	public static Specification<RouteCodeEntity> notEqualsRouteCodeId(Integer routeCodeId) {
		return (routeCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(routeCodeEntity.get("routeCodeId"), routeCodeId);
	}

	public static Specification<RouteCodeEntity> search(RouteCodeEntity mapToEntity) {
		return (routeCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (isEmptyOrNull(mapToEntity.getRouting())) {
				predicates.add(criteriaBuilder.like(routeCodeEntity.get("routing"), mapToEntity.getRouting() + "%"));
			}
			if (isEmptyOrNull(mapToEntity.getRouteCode())) {
				predicates
						.add(criteriaBuilder.like(routeCodeEntity.get("routeCode"), mapToEntity.getRouteCode() + "%"));
			}
			if (mapToEntity.getEffectiveFromDate() != null && mapToEntity.getEffectiveToDate() != null) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveFromDate()),
								routeCodeEntity.get("effectiveFromDate"), routeCodeEntity.get("effectiveToDate")),
						criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveToDate()),
								routeCodeEntity.get("effectiveFromDate"), routeCodeEntity.get("effectiveToDate"))));
			} else {
				if (mapToEntity.getEffectiveFromDate() != null) {
					predicates.add(criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveFromDate()),
							routeCodeEntity.get("effectiveFromDate"), routeCodeEntity.get("effectiveToDate")));
				}
				if (mapToEntity.getEffectiveToDate() != null) {
					predicates.add(criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveToDate()),
							routeCodeEntity.get("effectiveFromDate"), routeCodeEntity.get("effectiveToDate")));
				}
			}
			orderByDesc(routeCodeEntity, criteriaQuery, criteriaBuilder, "createdDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private static boolean isEmptyOrNull(String value) {
		return value != null && !value.isEmpty();
	}

	public static Specification<RouteCodeEntity> greaterThanOrEqualTo(LocalDate effectiveFromDate) {
		return (routeCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(routeCodeEntity.get("effectiveFromDate"), effectiveFromDate);
	}

	public static Specification<RouteCodeEntity> lessThanOrEqualTo(LocalDate effectiveToDate) {
		return (routeCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(routeCodeEntity.get("effectiveToDate"), effectiveToDate);
	}
}
