package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.AircraftDao;
import com.sgl.smartpra.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.master.app.mapper.AircraftMapper;
import com.sgl.smartpra.master.app.repository.entity.AircraftEntity;
import com.sgl.smartpra.master.app.service.AircraftService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.Aircraft;
import com.sgl.smartpra.master.model.ListOfValues;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class AircraftServiceImpl implements AircraftService {

	@Autowired
	private AircraftMapper aircraftMapper;

	@Autowired
	private AircraftDao aircraftDao;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private ListOfValuesService listOfValuesService;

	public static final String AIRCRAFTACTIVE = "Aircraft is already in active state";
	public static final String AIRCRAFTALREADYINACTIVE = "Aircraft is already in deactivated state";
	public static final String AIRCRAFT = "Aircraft";
	public static final String LASTUPDATEDBYMSG = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	public static final String LASTUPDATEDBYMENDATORYMSG = "Please provide Last Updated By";
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	private static final String LOVAIRCRAFTCATEGORY = LOVEnum.AIRCRAFT_CATEGORY.getLOVEnum();
	private static final String LOVWAKECATEGORY = LOVEnum.WAKE_CATEGORY.getLOVEnum();
	public static final String AIRCRAFTCATEGORYNOTINLOV = "Aircraft Category should be of values F,B,C in lov table";
	public static final String WAKECATEGORYNOTINLOV = "Wake Category should be of values H,L,M,S in lov table";
	public static final String CARRIER_CODE = null;
	public static final String CARRIER_NAME1 = null;
	public static final String CARRIER_NAME2 = null;
	Boolean dateCheck1 = null;
	Boolean dateCheck = null;
	private static final String DATE_CHECK = "Retire date should be greater than Hire date";
	private static final String AIRCRAFT_INVALID = "AircraftId is an invalid input";
	protected static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	private static final String EFFECTIVE_TO_DATE = "Effective To date[";

	@Override
	public List<Aircraft> getListOfAircraft(Aircraft aircraft, Optional<String> exceptionCall) {
		return aircraftMapper.mapToModel(aircraftDao.findAll(aircraft, exceptionCall));
	}

	@Override
	public Aircraft getAircraftByAircraftId(Integer aircraftId) {
		Optional<AircraftEntity> aircraftEntity = aircraftDao.findById(aircraftId);
		if (!aircraftEntity.isPresent()) {
			throw new ResourceNotFoundException(AIRCRAFT, "id", aircraftId);
		}
		return aircraftMapper.mapToModel(aircraftEntity.get());
	}

	@Override
	public Aircraft createAircraft(Aircraft aircraft) {
		validateBusinessConstrains(aircraft);
		aircraft.setActivate(Boolean.TRUE);
		try {
			return aircraftMapper.mapToModel(aircraftDao.create(aircraftMapper.mapToEntity(aircraft)));
		} catch (DataIntegrityViolationException e) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}
	}

	@Override
	public Aircraft updateAircraft(Integer aircraftId, Aircraft aircraft) {
		log.info("{}", aircraft);
		AircraftEntity aircraftEntity = aircraftDao.findById(aircraftId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(aircraftId)));
		if (!aircraftEntity.getActivate())
			throw new BusinessException(AIRCRAFTALREADYINACTIVE);
		validateBusinessConstraintsForUpdate(aircraft, aircraftEntity);
		// client code validation
		aircraft.setActivate(Boolean.TRUE);
		return aircraftMapper.mapToModel(aircraftDao.update(aircraftMapper.mapToEntity(aircraft, aircraftEntity)));
	}

	@Override
	public void deactivateAircraft(Integer aircraftId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		Optional<AircraftEntity> aircraftEntity = aircraftDao.findById(aircraftId);
		if (!aircraftEntity.isPresent())
			throw new ResourceNotFoundException(AIRCRAFT, "id", aircraftId);
		if (!aircraftEntity.get().getActivate())
			throw new BusinessException(AIRCRAFTALREADYINACTIVE);
		aircraftEntity.get().setActivate(Boolean.FALSE);
		aircraftEntity.get().setLastUpdatedBy(lastUpdatedBy);
		aircraftEntity.get().setLastUpdatedDate(LocalDateTime.now());
		aircraftDao.update(aircraftEntity.get());
	}

	@Override
	public void activateAircraft(Integer aircraftId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		Optional<AircraftEntity> aircraftEntity = aircraftDao.findById(aircraftId);

		if (!aircraftEntity.isPresent())
			throw new ResourceNotFoundException(AIRCRAFT, "id", aircraftId);

		if (aircraftEntity.get().getActivate())
			throw new BusinessException(AIRCRAFTACTIVE);

		aircraftEntity.get().setActivate(Boolean.TRUE);
		aircraftEntity.get().setLastUpdatedBy(lastUpdatedBy);
		aircraftEntity.get().setLastUpdatedDate(LocalDateTime.now());
		aircraftDao.update(aircraftEntity.get());

	}

	@Override
	public List<Aircraft> getAllAircraftDetails(Integer firstClassCapacity, Integer businessClassCapacity,
			Integer premiumEconomyClassCapacity, Integer economyClassCapacity) {
		return aircraftMapper.mapToModel(aircraftDao.getAllAircraftDetails(firstClassCapacity, businessClassCapacity,
				premiumEconomyClassCapacity, economyClassCapacity));
	}

	private void validateBusinessConstrains(Aircraft aircraft) {
		if (OptionalUtil.isPresent(aircraft.getEffectiveFromDate())
				&& OptionalUtil.isPresent(aircraft.getEffectiveToDate())) {
			validateEffectiveToDate(OptionalUtil.getLocalDateValue(aircraft.getEffectiveFromDate()),
					OptionalUtil.getLocalDateValue(aircraft.getEffectiveToDate()));
		}
		if (OptionalUtil.isPresent(aircraft.getRetireDate()) && OptionalUtil.isPresent(aircraft.getHireDate())) {
			validateToRetireDate(OptionalUtil.getLocalDateValue(aircraft.getRetireDate()),
					OptionalUtil.getLocalDateValue(aircraft.getHireDate()));
		}
		if (OptionalUtil.isPresent(aircraft.getRetireDate()) && OptionalUtil.isPresent(aircraft.getEffectiveToDate())) {
			validateToDateAndRetireDate(OptionalUtil.getLocalDateValue(aircraft.getRetireDate()),
					OptionalUtil.getLocalDateValue(aircraft.getEffectiveToDate()));
		}
		if (OptionalUtil.isPresent(aircraft.getWakeCategory())
				&& StringUtils.isNotBlank(OptionalUtil.getValue(aircraft.getWakeCategory()))) {
			validateWakeCategory(OptionalUtil.getValue(aircraft.getWakeCategory()),
					OptionalUtil.getValue(aircraft.getClientId()));
		}
		if (OptionalUtil.isPresent(aircraft.getAircraftCategory())
				&& StringUtils.isNotBlank(OptionalUtil.getValue(aircraft.getAircraftCategory()))) {
			validateAircraftCategory(OptionalUtil.getValue(aircraft.getAircraftCategory()),
					OptionalUtil.getValue(aircraft.getClientId()));
		}
		clientIdToCarrierDesignatorValidation(OptionalUtil.getValue(aircraft.getClientId()));

		validateOverLap(aircraft);
		if (aircraft.getAircraftId() != null) {
			throw new BusinessException(AIRCRAFT_INVALID);
		}
		if (aircraft.getBusinessClassCapacity() != null && aircraft.getFirstClassCapacity() != null
				&& aircraft.getPremiumEconomyClassCapacity() != null && aircraft.getEconomyClassCapacity() != null) {
			validateCabinCapacity(aircraft);
		}
	}

	private void clientIdToCarrierDesignatorValidation(String clientId) {
		if (globalMasterFeignClient.getAllCarrier(CARRIER_CODE, clientId, CARRIER_NAME1, CARRIER_NAME2, true)
				.isEmpty()) {
			throw new BusinessException("Invalid Client Id " + clientId);
		}
	}

	protected void validateEffectiveToDate(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException(EFFECTIVE_TO_DATE + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException(EFFECTIVE_TO_DATE + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}

	private void validateRetireDate(Aircraft aircraft, AircraftEntity aircraftEntity) {
		if (OptionalUtil.isPresent(aircraft.getRetireDate()) || OptionalUtil.isPresent(aircraft.getHireDate())) {
			validateToRetireDate(getRetireDate(aircraft, aircraftEntity), getHireDate(aircraft, aircraftEntity));
		}
	}

	private void validateToRetireDate(LocalDate retireDate, LocalDate hireDate) {
		if (retireDate != null && hireDate != null) {
			dateCheck1 = retireDate.isAfter(hireDate);
			if (!dateCheck1) {
				throw new BusinessException(DATE_CHECK);
			}
		}
	}

	private void validateToDateAndRetireDate(Aircraft aircraft, AircraftEntity aircraftEntity) {
		if (OptionalUtil.isPresent(aircraft.getRetireDate()) && OptionalUtil.isPresent(aircraft.getEffectiveToDate())) {
			validateToDateAndRetireDate(getRetireDate(aircraft, aircraftEntity),
					getEffectiveToDate(aircraft, aircraftEntity));
		}
	}

	private void validateToDateAndRetireDate(LocalDate retireDate, LocalDate toDate) {
		if (toDate.isAfter(retireDate) && !toDate.isEqual(retireDate)) {
			throw new BusinessException(EFFECTIVE_TO_DATE + toDate
					+ "]  should be less than or equal to the Retire date[" + retireDate + "]");
		}

	}

	private LocalDate getEffectiveFromDate(Aircraft aircraft, AircraftEntity aircraftEnity) {
		return OptionalUtil.isPresent(aircraft.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(aircraft.getEffectiveFromDate())
				: aircraftEnity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(Aircraft aircraft, AircraftEntity aircraftEnity) {
		return OptionalUtil.isPresent(aircraft.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(aircraft.getEffectiveToDate())
				: aircraftEnity.getEffectiveToDate();
	}

	private LocalDate getHireDate(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getHireDate()) ? OptionalUtil.getLocalDateValue(aircraft.getHireDate())
				: aircraftEntity.getHireDate();
	}

	private LocalDate getRetireDate(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getRetireDate())
				? OptionalUtil.getLocalDateValue(aircraft.getRetireDate())
				: aircraftEntity.getRetireDate();
	}

	private void validateWakeCategory(String wakeCategory, String clientId) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(LOVWAKECATEGORY));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(wakeCategory));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Wake Category[" + wakeCategory + "] is Not Valid");
		}
	}

	private void validateAircraftCategory(String aircraftCategory, String clientId2) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId2));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(LOVAIRCRAFTCATEGORY));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(aircraftCategory));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Aircraft Category[" + aircraftCategory + "] is Not Valid");
		}
	}

	// Validate OverLap in Create Service
	private void validateOverLap(Aircraft aircraft) {
		if (aircraftDao.getOverLapRecordCount(OptionalUtil.getLocalDateValue(aircraft.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(aircraft.getEffectiveToDate()),
				OptionalUtil.getValue(aircraft.getClientId()),
				OptionalUtil.getValue(aircraft.getAircraftRegistration())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}
	}

	private void validateOverLapForUpdate(Aircraft aircraft, AircraftEntity aircraftEntity) {
		String clientId = getClientId(aircraft, aircraftEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(aircraft, aircraftEntity);
		LocalDate effectiveToDate = getEffectiveToDate(aircraft, aircraftEntity);
		String aircraftRegistration = getAircraftRegistration(aircraft, aircraftEntity);
		if (!clientId.equalsIgnoreCase(aircraftEntity.getClientId())
				|| !effectiveFromDate.equals(aircraftEntity.getEffectiveFromDate())
				|| !effectiveToDate.equals(aircraftEntity.getEffectiveToDate())
				|| !aircraftRegistration.equalsIgnoreCase(aircraftEntity.getAircraftRegistration())) {
			if (aircraftDao.getOverLapRecordCount(effectiveFromDate, effectiveToDate, clientId, aircraftRegistration,
					aircraftEntity.getAircraftId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private void validateCabinCapacity(Aircraft aircraft) {
		if (!(Integer.parseInt(OptionalUtil.getValue(aircraft.getBusinessClassCapacity())) > 0
				|| Integer.parseInt(OptionalUtil.getValue(aircraft.getFirstClassCapacity())) > 0
				|| Integer.parseInt(OptionalUtil.getValue(aircraft.getEconomyClassCapacity())) > 0
				|| Integer.parseInt(OptionalUtil.getValue(aircraft.getPremiumEconomyClassCapacity())) > 0)) {
			throw new BusinessException("One of the capacity has to be non zero");
		}
	}

	private void validateCabiCapacityForUpdate(Aircraft aircraft, AircraftEntity aircraftEntity) {
		Integer bussiness = getBusinessClassCapacity(aircraft, aircraftEntity);
		Integer first = getFirstClassCapacity(aircraft, aircraftEntity);
		Integer economy = getEconomyClassCapacity(aircraft, aircraftEntity);
		Integer premium = getPremiumEconomyClassCapacity(aircraft, aircraftEntity);
		if (!(bussiness > 0 || first > 0 || economy > 0 || premium > 0)) {
			throw new BusinessException("One of the capacity has to be non zero");
		}
	}

	private Integer getPremiumEconomyClassCapacity(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getBusinessClassCapacity())
				? Integer.parseInt(OptionalUtil.getValue(aircraft.getBusinessClassCapacity()))
				: aircraftEntity.getBusinessClassCapacity();
	}

	private Integer getEconomyClassCapacity(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getEconomyClassCapacity())
				? Integer.parseInt(OptionalUtil.getValue(aircraft.getEconomyClassCapacity()))
				: aircraftEntity.getEconomyClassCapacity();
	}

	private Integer getFirstClassCapacity(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getFirstClassCapacity())
				? Integer.parseInt(OptionalUtil.getValue(aircraft.getFirstClassCapacity()))
				: aircraftEntity.getFirstClassCapacity();
	}

	private Integer getBusinessClassCapacity(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getPremiumEconomyClassCapacity())
				? Integer.parseInt(OptionalUtil.getValue(aircraft.getPremiumEconomyClassCapacity()))
				: aircraftEntity.getPremiumEconomyClassCapacity();
	}

	private void validateBusinessConstraintsForUpdate(Aircraft aircraft, AircraftEntity aircraftEntity) {
		validateWakeCategory(aircraft, aircraftEntity);
		validateAircraftCategory(aircraft, aircraftEntity);
		validateEffectiveToDate(aircraft, aircraftEntity);
		validateRetireDate(aircraft, aircraftEntity);
		validateToDateAndRetireDate(aircraft, aircraftEntity);
		if (OptionalUtil.isPresent(aircraft.getClientId())) {
			clientIdToCarrierDesignatorValidation(OptionalUtil.getValue(aircraft.getClientId()));
		}
		if (aircraft.getAircraftId() != null) {
			throw new BusinessException(AIRCRAFT_INVALID);
		}
		validateOverLapForUpdate(aircraft, aircraftEntity);
		if (OptionalUtil.isPresent(aircraft.getBusinessClassCapacity())
				|| OptionalUtil.isPresent(aircraft.getFirstClassCapacity())
				|| OptionalUtil.isPresent(aircraft.getPremiumEconomyClassCapacity())
				|| OptionalUtil.isPresent(aircraft.getEconomyClassCapacity())) {
			validateCabiCapacityForUpdate(aircraft, aircraftEntity);
		}
	}

	private void validateAircraftCategory(Aircraft aircraft, AircraftEntity aircraftEntity) {
		if (OptionalUtil.isPresent(aircraft.getAircraftCategory())
				&& StringUtils.isNotBlank(OptionalUtil.getValue(aircraft.getAircraftCategory())))
			validateAircraftCategory(getAircraftCategory(aircraft, aircraftEntity),
					getClientId(aircraft, aircraftEntity));
	}

	private String getAircraftCategory(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getAircraftCategory())
				? OptionalUtil.getValue(aircraft.getAircraftCategory())
				: aircraftEntity.getAircraftCategory();
	}

	private void validateWakeCategory(Aircraft aircraft, AircraftEntity aircraftEntity) {
		if (OptionalUtil.isPresent(aircraft.getWakeCategory())
				&& StringUtils.isNotBlank(OptionalUtil.getValue(aircraft.getWakeCategory())))
			validateWakeCategory(getWakeCategory(aircraft, aircraftEntity), getClientId(aircraft, aircraftEntity));
	}

	private String getWakeCategory(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getWakeCategory()) ? OptionalUtil.getValue(aircraft.getWakeCategory())
				: aircraftEntity.getWakeCategory();
	}

	private String getClientId(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getClientId()) ? OptionalUtil.getValue(aircraft.getClientId())
				: aircraftEntity.getClientId();
	}

	private String getAircraftRegistration(Aircraft aircraft, AircraftEntity aircraftEntity) {
		return OptionalUtil.isPresent(aircraft.getAircraftRegistration())
				? OptionalUtil.getValue(aircraft.getAircraftRegistration())
				: aircraftEntity.getAircraftRegistration();
	}

	private void validateEffectiveToDate(Aircraft aircraft, AircraftEntity aircraftEnity) {
		if (OptionalUtil.isPresent(aircraft.getEffectiveFromDate())
				|| OptionalUtil.isPresent(aircraft.getEffectiveToDate())) {
			validateEffectiveToDate(getEffectiveFromDate(aircraft, aircraftEnity),
					getEffectiveToDate(aircraft, aircraftEnity));
		}
	}
}