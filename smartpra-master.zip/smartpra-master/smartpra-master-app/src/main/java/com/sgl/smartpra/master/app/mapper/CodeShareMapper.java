package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.CodeShareEntity;
import com.sgl.smartpra.master.model.CodeShare;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CodeShareMapper extends BaseMapper<CodeShare, CodeShareEntity>{
	
	CodeShareEntity mapToEntity(CodeShare codeShare, @MappingTarget CodeShareEntity codeShareEntity);

	@Mapping(source = "codeShareId", target = "codeShareId", ignore = true)
	CodeShareEntity mapToEntity(CodeShare codeShare);
}
