package com.sgl.smartpra.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_prorate_discount")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class ProrateDiscountEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "prorate_discount_id", nullable = false)
	private Integer prorateDiscountId;

	@Column(name = "discount_code", nullable = false, length = 2)
	private String discountCode;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;

	@Column(name = "discount_type", nullable = false, length = 1)
	private String discountType;

	@Column(name = "discount_percent_normal_fare", nullable = false)
	private BigDecimal discountPercentNormalFare;

	@Column(name = "discount_percent_special_fare", nullable = false)
	private BigDecimal discountPercentSpecialFare;

	@Column(name = "fb_group_code", length = 5)
	private String fbGroupCode;

	@Column(name = "cxr", length = 3)
	private String cxr;

	@Column(name = "area_fbw_indicator", length = 1)
	private String areaFBWIndicator;

	@Column(name = "from_area", length = 4)
	private String fromArea;

	@Column(name = "to_area", length = 4)
	private String toArea;

	@Column(name = "is_active", nullable = false, length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;

	@Column(name = "client_id", nullable = false, length = 2)
	private String clientId;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

	public String getCxr() {
		if (cxr != null) {
			String trim = cxr.trim();
			return trim;
		}
		return cxr;
	}

	public void setCxr(String cxr) {
		if (cxr != null) {
			this.cxr = cxr.trim();
		}
		this.cxr = cxr;
	}

}