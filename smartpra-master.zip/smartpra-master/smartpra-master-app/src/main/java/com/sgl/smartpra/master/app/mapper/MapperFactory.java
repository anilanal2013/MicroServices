package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.factory.Mappers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperFactory {

	@Bean
	public RegionCountryMapper getRegionCountryMapper() {
		return Mappers.getMapper(RegionCountryMapper.class);
	}

	@Bean
	public FlightMapper getFlightMapper() {
		return Mappers.getMapper(FlightMapper.class);
	}

	@Bean
	public OutwardBillingPeriodsMapper getOutwardBillingPeriodsMapper() {
		return Mappers.getMapper(OutwardBillingPeriodsMapper.class);
	}

	@Bean
	public FinancialMonthMapper getFinancialMonthMapper() {
		return Mappers.getMapper(FinancialMonthMapper.class);
	}

	@Bean
	public OutwardBillingModuleMapper getOutwardBillingModuleMapper() {
		return Mappers.getMapper(OutwardBillingModuleMapper.class);
	}

}