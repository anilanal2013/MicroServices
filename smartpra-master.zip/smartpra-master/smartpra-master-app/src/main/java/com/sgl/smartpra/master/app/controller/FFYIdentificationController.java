package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.master.app.service.FFYIdentificationService;
import com.sgl.smartpra.master.model.FFYIdentification;

@RestController
public class FFYIdentificationController {

	@Autowired
	private FFYIdentificationService ffyIdentificationService;

	@GetMapping("/ffyIdentification")
	public List<FFYIdentification> getAllFFYIdentification(
			@RequestParam(value = "issueCxrCode", required = false) Optional<String> issueCxrCode,
			@RequestParam(value = "marketingCxrCode", required = false) Optional<String> marketingCxrCode,
			@RequestParam(value = "operatingCxrCode", required = false) Optional<String> operatingCxrCode,
			@RequestParam(value = "saleFromDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> saleFromDate,
			@RequestParam(value = "saleToDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> saleToDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return ffyIdentificationService.getAllFFYIdentification(issueCxrCode, marketingCxrCode, operatingCxrCode,
				saleFromDate, saleToDate, activate);
	}

	@GetMapping("/ffyIdentification/{ffyIdentifyId}")
	public FFYIdentification getFFYIdentificationByFFYIdentifyId(
			@PathVariable(value = "ffyIdentifyId") Integer ffyIdentifyId) {
		return ffyIdentificationService.findFFYIdentificationByffyIdentifyId(ffyIdentifyId);
	}

	@PostMapping("/ffyIdentification")
	public FFYIdentification createFFYIdentification(
			@Validated(Create.class) @RequestBody FFYIdentification ffyIdentification) {
		FFYIdentification createFFYIdentification = null;

		try {
			createFFYIdentification = ffyIdentificationService.createFFYIdentification(ffyIdentification);
		} catch (DataIntegrityViolationException e) {
			throw new BusinessException("Record already extists");
		}
		return createFFYIdentification;
	}

	@PutMapping("/ffyIdentification/{ffyIdentifyId}")
	public FFYIdentification updateFFYIndication(@PathVariable(value = "ffyIdentifyId") Integer ffyIdentifyId,
			@Validated(Update.class) @RequestBody FFYIdentification ffyIdentification) {
		FFYIdentification updateFFYIdentification = null;
		try {
			updateFFYIdentification = ffyIdentificationService.updateFFYIdentification(ffyIdentifyId,
					ffyIdentification);
		} catch (DataIntegrityViolationException e) {
			throw new BusinessException("Record already extists");
		}
		return updateFFYIdentification;
	}

	@PutMapping("/ffyIdentification/{ffyIdentifyId}/deactivate")
	public void deactivateFFYIdentification(@Valid @PathVariable(value = "ffyIdentifyId") Integer ffyIdentifyId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		ffyIdentificationService.deactivateFFYIdentification(ffyIdentifyId, lastUpdatedBy);
	}

	@PutMapping("/ffyIdentification/{ffyIdentifyId}/activate")
	public void activateFFYIdentification(@Valid @PathVariable(value = "ffyIdentifyId") Integer ffyIdentifyId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		ffyIdentificationService.activateFFYIdentification(ffyIdentifyId, lastUpdatedBy);
	}

}
