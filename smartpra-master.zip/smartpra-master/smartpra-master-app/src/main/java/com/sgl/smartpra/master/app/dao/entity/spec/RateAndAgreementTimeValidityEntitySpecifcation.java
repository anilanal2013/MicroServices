package com.sgl.smartpra.master.app.dao.entity.spec;


import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.master.app.dao.entity.RateAndAgreementTimeValidityEntity;

import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;


public final class RateAndAgreementTimeValidityEntitySpecifcation {


    public static Specification<RateAndAgreementTimeValidityEntity> search(Integer rateAgreementId) {
    return (entity, criteriaQuery,criteriaBuilder) ->{
        List<Predicate> predicates = new ArrayList<>();
   
       
            predicates.add(criteriaBuilder.equal(entity.get("rateAgreementId"),rateAgreementId));
        

        return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
    };
    }
}
