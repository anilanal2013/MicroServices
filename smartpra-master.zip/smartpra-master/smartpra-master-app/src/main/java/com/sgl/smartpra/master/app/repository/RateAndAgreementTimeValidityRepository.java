package com.sgl.smartpra.master.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sgl.smartpra.master.app.dao.entity.RateAndAgreementTimeValidityEntity;

public interface RateAndAgreementTimeValidityRepository extends JpaRepository<RateAndAgreementTimeValidityEntity,Integer>, JpaSpecificationExecutor<RateAndAgreementTimeValidityEntity> {
}
