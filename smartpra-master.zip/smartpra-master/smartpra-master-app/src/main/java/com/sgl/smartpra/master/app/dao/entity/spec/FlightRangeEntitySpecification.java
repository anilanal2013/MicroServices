package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.FlightRangeEntity;
import com.sgl.smartpra.master.app.repository.entity.POSEntity;

public class FlightRangeEntitySpecification {

	FlightRangeEntitySpecification() {
	}

	public static Specification<FlightRangeEntity> isActive() {
		return (flightRangeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(flightRangeEntity.get("activate"), true);
	}

	public static Specification<FlightRangeEntity> betweenSalesFromAndSalesToDate(LocalDate salesEffectiveDate) {
		return (flightRangeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(salesEffectiveDate), flightRangeEntity.get("saleFromDate"),
				flightRangeEntity.get("saleToDate"));
	}

	public static Specification<FlightRangeEntity> betweenTravelFromAndTravelToDate(LocalDate salesEffectiveDate) {
		return (flightRangeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(salesEffectiveDate), flightRangeEntity.get("travelFromDate"),
				flightRangeEntity.get("travelToDate"));
	}

	public static Specification<FlightRangeEntity> equalsFlightRangeAutoId(Integer flightRangeAutoId) {
		return (flightRangeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(flightRangeEntity.get("flightRangeAutoId"), flightRangeAutoId);
	}

	public static Specification<FlightRangeEntity> searchFlightRange(Optional<String> flightRangeId,
			Optional<String> isMarketingOperating, Optional<String> cxrCode, Optional<String> flightNumber,
			Optional<Boolean> activate) {
		return (flightRangeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(flightRangeId)) {
				predicates.add(criteriaBuilder.like(flightRangeEntity.get("flightRangeId"),
						OptionalUtil.getValue(flightRangeId) + "%"));
			}
			if (OptionalUtil.isPresent(isMarketingOperating)) {
				predicates.add(criteriaBuilder.like(flightRangeEntity.get("isMarketingOperating"),
						OptionalUtil.getValue(isMarketingOperating) + "%"));
			}
			if (OptionalUtil.isPresent(cxrCode)) {
				predicates.add(
						criteriaBuilder.like(flightRangeEntity.get("cxrCode"), OptionalUtil.getValue(cxrCode) + "%"));
			}
			if (OptionalUtil.isPresent(flightNumber)) {
				predicates.add(criteriaBuilder.like(flightRangeEntity.get("fromFlightNumber"),
						OptionalUtil.getValue(flightNumber) + "%"));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates
						.add(criteriaBuilder.equal(flightRangeEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(flightRangeEntity.get("activate"), true));
			}
			orderByAsc(flightRangeEntity, criteriaQuery, criteriaBuilder, "flightRangeId");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FlightRangeEntity> equalsCliendId(String clientId) {
		return (flightRangeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(flightRangeEntity.get("clientId"), clientId);
	}

	private static void orderByAsc(Root<FlightRangeEntity> flightRangeEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String flightRangeId) {
		criteriaQuery.orderBy(criteriaBuilder.asc(flightRangeEntity.get(flightRangeId)));
	}
}
