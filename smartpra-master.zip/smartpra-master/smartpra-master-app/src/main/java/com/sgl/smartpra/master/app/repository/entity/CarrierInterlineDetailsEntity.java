package com.sgl.smartpra.master.app.repository.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(schema = "SmartPRAMaster", name = "mas_carrier_interline")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class CarrierInterlineDetailsEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "carrier_interline_dtl_id")
	private int carrierInterlineDtlId;

	@Column(name = "carrier_code", length = 2, nullable = false)
	@NotEmpty
	private String carrierCode;

	@Column(name = "effective_from_date", nullable = false)
	@NotNull
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	@NotNull
	private LocalDate effectiveToDate;

	@Column(name = "customer_code", length = 10)
	private String customerCode;

	@Column(name = "billing_currency", length = 3, nullable = false)
	private String billingCurrency;

	@Column(name = "zone", length = 1)
	private String zone;

	@Column(name = "passenger_sis", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean passengerSis;

	@Column(name = "misc_sis", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean miscSis;

	@Column(name = "billing_thru_clearing_house", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean billingThruClearingHouse;

	@Column(name = "ib_tolerance_check_currency", length = 3)
	private String ibToleranceCheckCurrency;

	@Column(name = "ib_tolerance_gross_amount")
	private BigDecimal ibToleranceGrossAmount;

	@Column(name = "ib_tolerance_isc_amount")
	private BigDecimal ibToleranceIscAmount;

	@Column(name = "ib_tolerance_tax_amount")
	private BigDecimal ibToleranceTaxAmount;

	@Column(name = "ib_tolerance_time_limit")
	private Integer ibToleranceTimeLimit;

	@Column(name = "reference_data_to_is_idec", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean referenceDataToIsIdec;

	@Column(name = "eu_registration_country_code", length = 3)
	private String euRegistrationCountryCode;

	@Column(name = "vat_registration_number", length = 25)
	private String vatRegistrationNumber;

	@Column(name = "vat_exception_number", length = 25)
	private String vatExceptionNumber;

	@Column(name = "mita_for_pax", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean mitaForPax;

	@Column(name = "digital_signature", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean digitalSignature;

	@Column(name = "separate_code_share_invoice", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean separateCodeShareInvoice;

	@Column(name = "sac_check_required", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean sacCheckRequired;

	@Column(name = "sale_check_required", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean saleCheckRequired;

	@Column(name = "skip_weekly_billing", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean skipWeeklyBilling;

	@Column(name = "is_cpn_proc_dt_wkly_bill_lmt", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean isCpnProcDtWklyBillLmt;

	@Column(name = "endorsement_check_required", length = 1, nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean endorsementCheckRequired;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@Column(name = "uatp_applicable_ind")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean uatpApplicableInd;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
