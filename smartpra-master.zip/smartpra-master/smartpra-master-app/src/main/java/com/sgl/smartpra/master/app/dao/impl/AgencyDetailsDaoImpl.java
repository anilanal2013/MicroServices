package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.AgencyDetailsDao;
import com.sgl.smartpra.master.app.dao.entity.AgencyDetailsEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.AgencyDetailsEntitySpecificaton;
import com.sgl.smartpra.master.app.repository.AgencyDetailsRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AgencyDetailsDaoImpl<T> extends CommonSearchDao<T> implements AgencyDetailsDao {

	@Autowired
	private AgencyDetailsRepository agencyDetailsRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "agencyDetails", key = "#agencyDetailsEntity.agencyDetailsId")})
	public AgencyDetailsEntity create(AgencyDetailsEntity agencyDetailsEntity) {
		return agencyDetailsRepository.save(agencyDetailsEntity);
	}

	@Override
	@Cacheable(value = "agencyDetails", key = "#id")
	public Optional<AgencyDetailsEntity> findById(Integer id) {
		log.info("Cacheable AgencyDetails Entity's ID= {}", id);
		return agencyDetailsRepository.findById(id);
	}

	@Override
	@CachePut(value = "agencyDetails", key = "#agencyDetailsEntity.agencyDetailsId")
	public AgencyDetailsEntity update(AgencyDetailsEntity agencyDetailsEntity) {
		return agencyDetailsRepository.save(agencyDetailsEntity);
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String agencyCode, Optional<String> transactionType, Optional<String> transactionCurrency,
			Optional<String> reportingFrequency) {
		return agencyDetailsRepository.count(Specification
				.where(AgencyDetailsEntitySpecificaton.equalsClientId(clientId))
				.and(AgencyDetailsEntitySpecificaton.equalsAgencyCode(agencyCode))
				.and(AgencyDetailsEntitySpecificaton
						.equalsReportingFrequency(OptionalUtil.getValue(reportingFrequency)))
				.and(AgencyDetailsEntitySpecificaton.equalsTransactionType(OptionalUtil.getValue(transactionType)))
				.and(AgencyDetailsEntitySpecificaton
						.equalsTransactionCurrency(OptionalUtil.getValue(transactionCurrency)))
				.and(AgencyDetailsEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(AgencyDetailsEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String transactionCurrency, String transactionType, String agencyCode, String reportingFrequency,
			Integer agencyDetailsId) {
		return agencyDetailsRepository.count(AgencyDetailsEntitySpecificaton.equalsClientId(clientId)
				.and(AgencyDetailsEntitySpecificaton.equalsReportingType(transactionCurrency))
				.and(AgencyDetailsEntitySpecificaton.equalsTransactionType(transactionType))
				.and(AgencyDetailsEntitySpecificaton.equalsAgencyCode(agencyCode))
				.and(AgencyDetailsEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(AgencyDetailsEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(AgencyDetailsEntitySpecificaton.notEqualsAgencyDetailsId(agencyDetailsId)));
	}

	@Override
	public List<AgencyDetailsEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return agencyDetailsRepository
				.findAll((AgencyDetailsEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(AgencyDetailsEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(AgencyDetailsEntitySpecificaton.isActive())));
	}

	@Override
	public List<AgencyDetailsEntity> findAll(Optional<String> agencyCode, Optional<String> clientId,
			Optional<String> transactionType, Optional<String> reportingFrequency, Optional<String> transactionCurrency,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate) {
		return agencyDetailsRepository
				.findAll(AgencyDetailsEntitySpecificaton.search(agencyCode, clientId, transactionType,
						reportingFrequency, transactionCurrency, effectiveFromDate, effectiveToDate, activate));
	}

	@Override
	public List<AgencyDetailsEntity> searchAgencyDetailsByAgencyCode(Optional<String> clientId,
			Optional<String> agencyCode, Optional<String> effectiveDate) {
		return agencyDetailsRepository.findAll(
				AgencyDetailsEntitySpecificaton.searchAgencyDetailsByAgencyCode(clientId, agencyCode, effectiveDate));
	}

	@Override
	public List<AgencyDetailsEntity> findByAgencyId(Integer agencyId, Optional<String> agencyCode,
			Optional<String> clientId, Optional<String> transactionType, Optional<String> reportingFrequency,
			Optional<String> transactionCurrency, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate,Optional<String> exceptionCall) {
		return agencyDetailsRepository
		.findAll(AgencyDetailsEntitySpecificaton.findByAgencyId(agencyId,agencyCode, clientId, transactionType,
				reportingFrequency, transactionCurrency, effectiveFromDate, effectiveToDate, activate, exceptionCall));
	}

}
