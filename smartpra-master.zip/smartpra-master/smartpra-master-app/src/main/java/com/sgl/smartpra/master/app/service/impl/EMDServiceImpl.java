package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.EMDDao;
import com.sgl.smartpra.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.master.app.mapper.EMDMapper;
import com.sgl.smartpra.master.app.repository.entity.EMDEntity;
import com.sgl.smartpra.master.app.service.EMDService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.EMDModel;
import com.sgl.smartpra.master.model.ListOfValues;

@Service
@Transactional
public class EMDServiceImpl implements EMDService {

	@Autowired
	private EMDMapper emdMapper;

	@Autowired
	private EMDDao emdDao;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private ListOfValuesService listOfValueService;

	public static final String LASTUPDATEDBYMSG = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	public static final String LASTUPDATEDBYMENDATORYMSG = "Please provide Last Updated By";
	public static final String EMD = "EMD";
	public static final String EMDACTIVE = "EMD is already in active state";
	public static final String EMDALREADYINACTIVE = "EMD is already in deactivated state";
	public static final String EMDISNOTACTIVE = "EMD is not active with  ";
	private static final String TABLE_NAME = LOVEnum.TABLENAME.getLOVEnum();
	private static final String SALES_SOURCE = LOVEnum.SALES_SOURCE.getLOVEnum();
	private static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	String serviceType = "";

	@Override
	public List<EMDModel> getListOfEMD(EMDModel emdModel, Optional<String> exceptionCall) {
		return emdMapper.mapToModel(emdDao.findAll(emdModel,exceptionCall));
	}

	@Override
	public EMDModel getEMDByEmdId(Integer emdId) {
		return emdMapper.mapToModel(
				emdDao.findById(emdId).orElseThrow(() -> new RecordNotFoundException(String.valueOf(emdId))));
	}

	@Override
	public EMDModel createEMD(EMDModel emdModel) {
		if (!OptionalUtil.isPresent(emdModel.getServiceType())) {
			emdModel.setServiceType(Optional.of(serviceType));
		}
		businessConstraintValidationForCreate(emdModel);
		emdModel.setActivate(Boolean.TRUE);
		emdModel.setCreatedDate(LocalDateTime.now());
		return emdMapper.mapToModel(emdDao.create(emdMapper.mapToEntity(emdModel)));
	}

	@Override
	public EMDModel updateEMD(Integer emdId, EMDModel emdModel) {
		String salesSource = null;
		EMDEntity emdEntity = emdDao.findById(emdId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(emdId)));
		// update only if the record is active
		if (!emdEntity.getActivate()) {
			throw new BusinessException(EMDISNOTACTIVE + " id " + emdId);
		}
		salesSource = getSalesSource(emdModel, emdEntity);
		if (salesSource != null) {
			emdModel.setSalesSource(Optional.of(salesSource));
		}
		businessConstraintValidationForUpdate(emdModel, emdEntity);
		return emdMapper.mapToModel(emdDao.update(emdMapper.mapToEntity(emdModel, emdEntity)));
	}

	@Override
	public void deactivateEMD(Integer emdId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		Optional<EMDEntity> emdEntity = emdDao.findById(emdId);
		if (!emdEntity.isPresent())
			throw new ResourceNotFoundException(EMD, "id", emdId);
		if (!emdEntity.get().getActivate())
			throw new BusinessException(EMDALREADYINACTIVE);
		emdEntity.get().setActivate(Boolean.FALSE);
		emdEntity.get().setLastUpdatedBy(lastUpdatedBy);
		emdEntity.get().setLastUpdatedDate(LocalDateTime.now());
		emdDao.update(emdEntity.get());

	}

	@Override
	public void activateEMD(Integer emdId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		Optional<EMDEntity> emdEntity = emdDao.findById(emdId);
		if (!emdEntity.isPresent())
			throw new ResourceNotFoundException(EMD, "id", emdId);
		if (emdEntity.get().getActivate())
			throw new BusinessException(EMDACTIVE);
		emdEntity.get().setActivate(Boolean.TRUE);
		emdEntity.get().setLastUpdatedBy(lastUpdatedBy);
		emdEntity.get().setLastUpdatedDate(LocalDateTime.now());
		emdDao.update(emdEntity.get());
	}

	private void businessConstraintValidationForCreate(EMDModel emdModel) {
		boolean dateCheck = OptionalUtil.getLocalDateValue(emdModel.getEffectiveToDate())
				.isAfter(OptionalUtil.getLocalDateValue(emdModel.getEffectiveFromDate()));
		if (!dateCheck) {
			throw new BusinessException(
					"Effective To date[" + OptionalUtil.getLocalDateValue(emdModel.getEffectiveToDate())
							+ "] should be greater than Effective From date["
							+ OptionalUtil.getLocalDateValue(emdModel.getEffectiveFromDate()) + "]");
		}
		validateOverLap(emdModel);
		if (OptionalUtil.isPresent(emdModel.getSalesSource())) {
			if (OptionalUtil.getValue(emdModel.getSalesSource()).trim().length() > 0)
				validateSalesSource(OptionalUtil.getValue(emdModel.getClientId()),
						OptionalUtil.getValue(emdModel.getSalesSource()));
		}
		if (OptionalUtil.isPresent(emdModel.getEmdConsumedIssuanceFeecode())) {
			validateEMDConsumedIssuanceFeecode(OptionalUtil.getValue(emdModel.getEmdConsumedIssuanceFeecode()));
		}

		if (!OptionalUtil.isPresent(emdModel.getEmdOutdate())) {
			emdModel.setEmdOutdate(Optional.ofNullable("N"));
		}

		if (!OptionalUtil.isPresent((emdModel.getVatApplicable()))) {
			emdModel.setVatApplicable(Optional.ofNullable("N"));
		}

		if (!OptionalUtil.isPresent((emdModel.getEmdInterlinable()))) {
			emdModel.setEmdInterlinable(Optional.ofNullable("N"));
		}

		if (!OptionalUtil.isPresent((emdModel.getEmdRefund()))) {
			emdModel.setEmdRefund(Optional.ofNullable("N"));
		}
		if (!OptionalUtil.isPresent((emdModel.getEmdExchange()))) {
			emdModel.setEmdExchange(Optional.ofNullable("N"));
		}
		validateCarrierDesignatorCode(emdModel);
	}

	private void businessConstraintValidationForUpdate(EMDModel emdModel, EMDEntity emdEntity) {
		LocalDate effectiveToDate = getEffectiveToDate(emdModel, emdEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(emdModel, emdEntity);
		boolean dateCheck = effectiveToDate.isAfter(effectiveFromDate);
		if (!dateCheck) {
			throw new BusinessException("Effective To date " + effectiveToDate
					+ "should be greater than Effective From date " + effectiveFromDate);
		}
		if (getEmdOutdate(emdModel, emdEntity) == null || getEmdOutdate(emdModel, emdEntity).trim().length() == 0) {
			emdModel.setEmdOutdate(Optional.ofNullable("N"));
		}
		if (getVatApplicable(emdModel, emdEntity) == null
				|| getVatApplicable(emdModel, emdEntity).trim().length() == 0) {
			emdModel.setVatApplicable(Optional.ofNullable("N"));
		}
		if (getEmdInterlinable(emdModel, emdEntity) == null
				|| getEmdInterlinable(emdModel, emdEntity).trim().length() == 0) {
			emdModel.setEmdInterlinable(Optional.ofNullable("N"));
		}
		if (getEmdRefund(emdModel, emdEntity) == null || getEmdRefund(emdModel, emdEntity).trim().length() == 0) {
			emdModel.setEmdRefund(Optional.ofNullable("N"));
		}
		if (getEmdExchange(emdModel, emdEntity) == null || getEmdExchange(emdModel, emdEntity).trim().length() == 0) {
			emdModel.setEmdExchange(Optional.ofNullable("N"));
		}
		validateCarrierDesignatorCode(emdModel);

		if (OptionalUtil.isPresent(emdModel.getSalesSource()) && emdEntity.getSalesSource() != null) {
			validateSalesSourceForUpdate(emdModel, emdEntity);
		}

		if (OptionalUtil.isPresent(emdModel.getEmdConsumedIssuanceFeecode())) {
			validateEMDConsumedIssuanceFeecode(getEMDConsumedIssuanceFeecode(emdModel, emdEntity));
		}
		if (OptionalUtil.isPresent(emdModel.getEffectiveFromDate())
				&& OptionalUtil.isPresent(emdModel.getEffectiveToDate())) {
			validateEffectiveDateForUpdate(emdModel, emdEntity);
		}
	}

	private void validateCarrierDesignatorCode(EMDModel emdModel) {
		if (OptionalUtil.isPresent(emdModel.getClientId())) {
			String carrierDesignatorCode = OptionalUtil.getValue(emdModel.getClientId());
			if (!globalMasterFeignClient.isValidCarrierDesignatorCode(carrierDesignatorCode)) {
				throw new BusinessException("Invalid Client Id " + carrierDesignatorCode);
			}
		}
	}

	private void validateSalesSource(String clientId, String salesSource) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLE_NAME));
		listOfValuesModel.setColumnName(Optional.of(SALES_SOURCE));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(salesSource));
		if (!listOfValueService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Sales Source[" + salesSource + "] is Not Valid");
		}
	}

	private void validateSalesSourceForUpdate(EMDModel emdModel, EMDEntity emdEntity) {
		if (OptionalUtil.isPresent(emdModel.getClientId()) || OptionalUtil.isPresent(emdModel.getSalesSource())) {
			if (OptionalUtil.getValue(emdModel.getSalesSource()).trim().length() > 0)
				validateSalesSource(getClientId(emdModel, emdEntity), getSalesSource(emdModel, emdEntity));
		}
	}

	private String getClientId(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getClientId()) ? OptionalUtil.getValue(emdModel.getClientId())
				: emdEntity.getClientId();
	}

	private String getSalesSource(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getSalesSource())
				&& OptionalUtil.getValue(emdModel.getSalesSource()).trim().length() > 0
						? OptionalUtil.getValue(emdModel.getSalesSource())
						: emdEntity.getSalesSource();
	}

	private LocalDate getEffectiveFromDate(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(emdModel.getEffectiveFromDate())
				: emdEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(emdModel.getEffectiveToDate())
				: emdEntity.getEffectiveToDate();
	}

	private String getReasonForIssuanceCode(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getReasonForIssuanceCode())
				? OptionalUtil.getValue(emdModel.getReasonForIssuanceCode())
				: emdEntity.getReasonForIssuanceCode();
	}

	private String getReasonForIssuanceSubCode(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getReasonForIssuanceSubCode())
				? OptionalUtil.getValue(emdModel.getReasonForIssuanceSubCode())
				: emdEntity.getReasonForIssuanceSubCode();
	}

	private String getEmdOutdate(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getEmdOutdate()) ? OptionalUtil.getValue(emdModel.getEmdOutdate())
				: emdEntity.getEmdOutdate();
	}

	private String getVatApplicable(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getVatApplicable()) ? OptionalUtil.getValue(emdModel.getVatApplicable())
				: emdEntity.getVatApplicable();
	}

	private String getEmdInterlinable(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getEmdInterlinable())
				? OptionalUtil.getValue(emdModel.getEmdInterlinable())
				: emdEntity.getEmdInterlinable();
	}

	private String getEmdRefund(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getEmdRefund()) ? OptionalUtil.getValue(emdModel.getEmdRefund())
				: emdEntity.getEmdRefund();
	}

	private String getEmdExchange(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getEmdExchange()) ? OptionalUtil.getValue(emdModel.getEmdExchange())
				: emdEntity.getEmdExchange();
	}

	private String getEMDConsumedIssuanceFeecode(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getEmdConsumedIssuanceFeecode())
				? OptionalUtil.getValue(emdModel.getEmdConsumedIssuanceFeecode())
				: emdEntity.getEmdConsumedIssuanceFeecode();
	}

	private String getServiceType(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getServiceType()) ? OptionalUtil.getValue(emdModel.getServiceType())
				: emdEntity.getServiceType();
	}

	private String getEmdType(EMDModel emdModel, EMDEntity emdEntity) {
		return OptionalUtil.isPresent(emdModel.getEmdType()) ? OptionalUtil.getValue(emdModel.getEmdType())
				: emdEntity.getEmdType();
	}

	private void validateEMDConsumedIssuanceFeecode(String emd) {
		Boolean checkemd = Pattern.compile("[A-Za-z]*").matcher(emd).find();
		if (!checkemd) {
			throw new BusinessException("Emd Consumed Issuance FeeCode should be alphabets only");
		}
	}

	private void validateOverLap(EMDModel emdModel) {
		if (emdDao.getOverLapRecordCount(OptionalUtil.getLocalDateValue(emdModel.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(emdModel.getEffectiveToDate()), emdModel.getClientId(),
				emdModel.getReasonForIssuanceCode(), emdModel.getReasonForIssuanceSubCode(), emdModel.getEmdType(),
				emdModel.getServiceType()) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}
	}

	private void validateEffectiveDateForUpdate(EMDModel emdModel, EMDEntity emdEntity) {
		String clientId = getClientId(emdModel, emdEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(emdModel, emdEntity);
		LocalDate effectiveToDate = getEffectiveToDate(emdModel, emdEntity);
		String reasonForIssuanceCode = getReasonForIssuanceCode(emdModel, emdEntity);
		String reasonForIssuanceSubCode = getReasonForIssuanceSubCode(emdModel, emdEntity);
		String emdType = getEmdType(emdModel, emdEntity);
		serviceType = getServiceType(emdModel, emdEntity);
		if (!clientId.equalsIgnoreCase(emdEntity.getClientId())
				|| !effectiveFromDate.equals(emdEntity.getEffectiveFromDate())
				|| !effectiveToDate.equals(emdEntity.getEffectiveToDate())
				|| !reasonForIssuanceCode.equalsIgnoreCase(emdEntity.getReasonForIssuanceCode())
				|| !reasonForIssuanceSubCode.equalsIgnoreCase(emdEntity.getReasonForIssuanceSubCode())
				|| !emdType.equalsIgnoreCase(emdEntity.getEmdType())) {
			if (emdDao.getOverLapRecordCount(effectiveFromDate, effectiveToDate, clientId, reasonForIssuanceCode,
					reasonForIssuanceSubCode, emdType, serviceType, emdEntity.getEmdId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}
}
