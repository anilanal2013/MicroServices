package com.sgl.smartpra.master.app.dao.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.CodeShareEntity;


@Repository
public interface CodeShareRepository extends JpaRepository<CodeShareEntity, Integer>, JpaSpecificationExecutor<CodeShareEntity> {

	@Query(value = "select c from CodeShareEntity c where ((:effectiveDate between c.travelFromDate and c.travelToDate) "
			+ "and c.clientId=:clientId and c.marketingCXR=:marketingCXR  and c.marketedRBDList like %:marketedRBDList% ) and c.isActive=true")
	List<CodeShareEntity> getCodeShareByEffectiveDate(@Param("clientId") String clientId,@Param("marketingCXR")String marketingCXR,
			@Param("marketedRBDList")String marketedRBDList,@Param("effectiveDate") LocalDate effectiveDate);
	
	@Query(value = "select c from CodeShareEntity c where (:travelEffectiveDate between c.travelFromDate and c.travelToDate) AND c.marketingCXR=:marketingCXR "
			+ "AND (:saleEffectiveDate between c.saleFromDate and c.saleToDate) AND  c.clientId=:clientId "
			+ "AND ( CONVERT(numeric,:flightNumber) between c.fromBookedFlightNumber and c.toBookedFlightNumber) AND c.isActive=true ")
	public CodeShareEntity getCodeShareByMarketingCXR(@Param("marketingCXR")String marketingCXR,@Param("travelEffectiveDate")LocalDate travelEffectiveDate,
			@Param("saleEffectiveDate")LocalDate saleEffectiveDate,@Param("clientId")String clientId,@Param("flightNumber")String flightNumber);
	
	
	@Query(value = "select count(*) from CodeShareEntity d where"
			+ " ((?1 between d.saleFromDate and d.saleToDate) or "
			+ "(?2 between d.saleFromDate and d.saleToDate)) and d.isActive = true")
	int saleVerifyIfOverlapExits(LocalDate saleFromDate, LocalDate saleToDate);

	@Query(value = "select count(*) from CodeShareEntity d where"
			+ " ((?1 between d.travelFromDate and d.travelToDate) or "
			+ "(?2 between d.travelFromDate and d.travelToDate)) and d.isActive = true")
	int travelVerifyIfOverlapExits(LocalDate travelFromDate, LocalDate travelToDate);

	
	@Query(value ="select count(*) from CodeShareEntity cs where cs.marketingCXR = ?1 and cs.fromBookedFlightNumber =CONVERT(numeric,?2) and "
			+ "cs.toBookedFlightNumber = CONVERT(numeric,?3) and  ((?4 between cs.saleFromDate and cs.saleToDate) or (?5 between cs.saleFromDate and cs.saleToDate)) and  "
			+ "((?6 between cs.travelFromDate and cs.travelToDate) or (?7 between cs.travelFromDate and cs.travelToDate))  and cs.clientId=?8 and cs.isActive=true ")
	public int  overlappingCXRWithFlightNumber(String marketingCXR, String fromBookedFlightNumber,String toBookedFlightNumber,LocalDate saleFromDate,LocalDate saleToDate,
			LocalDate travelFromDate,LocalDate travelToDate,String clientId);

	
	@Query(value = "select c from CodeShareEntity c where isActive=true")
	List<CodeShareEntity> getCodeShareIsActive();

	
	@Query(value = "select d from CodeShareEntity d where"
			+ " d.isActive=true and (?1 between d.travelFromDate and d.travelToDate)")
	List<CodeShareEntity> getCodeShareDetailsByEffectiveDate(LocalDate effectiveDate);

	
	@Query(value = "select c from CodeShareEntity c where (:effectiveDateObject between c.travelFromDate and c.travelToDate) AND c.marketingCXR=:marketingCXR AND "
			+ "(:saleDateObject between c.saleFromDate and c.saleToDate) AND  c.clientId=:clientId "
			+ "AND (CONVERT(numeric,:flightNumber) between c.fromBookedFlightNumber and c.toBookedFlightNumber) AND isActive=true")
	List<CodeShareEntity> getCodeSharePopulateData(@Param("marketingCXR")String marketingCXR,@Param("effectiveDateObject") LocalDate effectiveDateObject,
			@Param("saleDateObject") LocalDate saleDateObject,	@Param("clientId")String clientId,@Param("flightNumber") String flightNumber);

	
	@Query(value = "select c from CodeShareEntity c where (:effectiveDateObject between c.travelFromDate and c.travelToDate) AND c.marketingCXR=:marketingCXR AND "
			+ "c.clientId=:clientId AND (CONVERT(numeric,:flightNumber) between c.fromBookedFlightNumber and c.toBookedFlightNumber) AND isActive=true")
	List<CodeShareEntity> getCodeSharePopulateDataWithoutSaleDate(@Param("marketingCXR")String marketingCXR, @Param("effectiveDateObject")LocalDate effectiveDateObject,
			@Param("clientId")String clientId,@Param("flightNumber")  String flightNumber);

	
	@Query(value = "select c from CodeShareEntity c where (:saleDateObject between c.saleFromDate and c.saleToDate) AND c.marketingCXR=:marketingCXR AND "
			+ "c.clientId=:clientId AND ( CONVERT(numeric,:flightNumber) between c.fromBookedFlightNumber and c.toBookedFlightNumber) AND isActive=true")
	List<CodeShareEntity> getCodeSharePopulateDataWithoutIssueDate(@Param("marketingCXR")String marketingCXR, @Param("saleDateObject") LocalDate saleDateObject,
			@Param("clientId")String clientId, @Param("flightNumber") String flightNumber);

	
	@Query(value = "select c from CodeShareEntity c where (:travelEffectiveDate between c.travelFromDate and c.travelToDate) AND c.marketingCXR=:marketingCXR "
			+ "AND (:saleEffectiveDate between c.saleFromDate and c.saleToDate) "
			+ "AND  c.clientId=:clientId AND (CONVERT(numeric,:flightNumber) between c.fromBookedFlightNumber and c.toBookedFlightNumber) "
			+ "AND c.marketedRBDList=:marketedRBDList AND c.isActive=true ")
	public CodeShareEntity getCodeShareBymarketingCXRForBsp(@Param("marketingCXR")String marketingCXR,@Param("travelEffectiveDate") LocalDate travelEffectiveDate,
			@Param("saleEffectiveDate")LocalDate saleEffectiveDate, @Param("clientId")String clientId, @Param("flightNumber")String flightNumber, 
			@Param("marketedRBDList")String marketedRBDList); 

	@Query(value = "select c from CodeShareEntity c where c.clientId=:clientId AND (CONVERT(numeric,:operatingflightNumber) between c.fromOperatingFlightNumber and c.toOperatingFlightNumber)"
			+ " AND (:travelDate between c.travelFromDate and c.travelToDate) AND c.operatingCXR=:operatingCXR "
			+ "AND (CONVERT(numeric,:marketingflightNumber) between c.fromBookedFlightNumber and c.toBookedFlightNumber) AND (:saleDate between c.saleFromDate and c.saleToDate)"
			+ " AND c.marketingCXR=:marketingCXR  AND c.isActive=true")
	public CodeShareEntity getCodeShareForValidation(@Param("clientId")String clientId, @Param("operatingflightNumber")String operatingflightNumber,
			@Param("travelDate") LocalDate travelDate, 	@Param("operatingCXR")String operatingCXR,  @Param("marketingflightNumber")String marketingflightNumber,
			@Param("saleDate") LocalDate saleDate, 	@Param("marketingCXR")String marketingCXR); 
	
	
	//reference for the populate data query
	
	//         select * from [SmartPRA_DEV].[SmartPRAMaster].[mas_code_share] where [client_id]='IC' and 
	//		   [marketing_cxr]='EW' and ('2023-01-28' between [sale_from_date] and [sale_to_date]) and  
	//		   ('2024-01-30' between [travel_from_date] and [travel_to_date]) and (10858 between [from_booked_flight_number] and [to_booked_flight_number]) 
	
}