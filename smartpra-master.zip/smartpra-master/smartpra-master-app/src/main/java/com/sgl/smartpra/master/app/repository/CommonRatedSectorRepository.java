package com.sgl.smartpra.master.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sgl.smartpra.master.app.repository.entity.CommonRatedSectorEntity;

public interface CommonRatedSectorRepository
		extends JpaRepository<CommonRatedSectorEntity, Integer>, JpaSpecificationExecutor<CommonRatedSectorEntity> {

//	@Query("Select cmn CommonRatedSectorEntity where  cmn.clientId=:clientId and  cmn.fromAirport=:fromAirport and cmn.commonRatedFromAirport=:commonRatedFromAirport and cmn.commonRatedToAirport=:commonRatedToAirport")
//	List<CommonRatedSectorEntity> getCommonRatedSectors(@Param("clientId") String clientId,
//			@Param("fromAirport") String fromAirport, @Param("toAirport") String toAirport,
//			@Param("commonRatedFromAirport") String commonRatedFromAirport,
//			@Param("commonRatedToAirport") String commonRatedToAirport);

}
