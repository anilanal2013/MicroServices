package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.EMDDao;
import com.sgl.smartpra.master.app.dao.entity.spec.EMDEntitySpecification;
import com.sgl.smartpra.master.app.repository.EMDRepository;
import com.sgl.smartpra.master.app.repository.entity.EMDEntity;
import com.sgl.smartpra.master.model.EMDModel;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class EMDDaoImpl implements EMDDao {

	@Autowired
	private EMDRepository emdRepository;

	@Override
	@Cacheable(value = "emd", key = "#id")
	public Optional<EMDEntity> findById(Integer id) {
		log.info("Cacheable EMD Entity's ID= {}", id);
		return emdRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "emd", key = "#emdEntity.emdId")})
	public EMDEntity create(EMDEntity emdEntity) {
		return emdRepository.save(emdEntity);
	}

	@Override
	@CachePut(value = "emd", key = "#emdEntity.emdId")
	public EMDEntity update(EMDEntity emdEntity) {
		return emdRepository.save(emdEntity);
	}

	@Override
	public List<EMDEntity> findAll(EMDModel emdModel, Optional<String> exceptionCall) {
		return emdRepository.findAll(EMDEntitySpecification.search(emdModel, exceptionCall));
	}

	@Override
	public List<EMDEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return emdRepository.findAll((EMDEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(EMDEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.and(EMDEntitySpecification.isActive())));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, Optional<String> clientId,
			Optional<String> reasonForIssuanceCode, Optional<String> reasonForIssuanceSubCode, Optional<String> emdType,
			Optional<String> serviceType) {
		return emdRepository.count(Specification
				.where(EMDEntitySpecification.equalsClientId(OptionalUtil.getValue(clientId)))
				.and(EMDEntitySpecification.equalsReasonForIssuanceCode(OptionalUtil.getValue(reasonForIssuanceCode)))
				.and(EMDEntitySpecification
						.equalsReasonForIssuanceSubCode(OptionalUtil.getValue(reasonForIssuanceSubCode)))
				.and(EMDEntitySpecification.equalsEmdType(OptionalUtil.getValue(emdType)))
				.and(EMDEntitySpecification.equalsServiceType(OptionalUtil.getValue(serviceType)))
				.and(EMDEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(EMDEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String reasonForIssuanceCode, String reasonForIssuanceSubCode, String emdType, String serviceType,
			Integer emdId) {
		return emdRepository.count(EMDEntitySpecification.equalsClientId(clientId)
				.and(EMDEntitySpecification.equalsReasonForIssuanceCode(reasonForIssuanceCode))
				.and(EMDEntitySpecification.equalsReasonForIssuanceSubCode(reasonForIssuanceSubCode))
				.and(EMDEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(EMDEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(EMDEntitySpecification.notEqualsAgencyDetailsId(emdId)));
	}
}
