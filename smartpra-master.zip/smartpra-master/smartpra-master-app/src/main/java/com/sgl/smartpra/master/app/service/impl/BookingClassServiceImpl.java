package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.BookingClassDao;
import com.sgl.smartpra.master.app.dao.entity.BookingClassEntity;
import com.sgl.smartpra.master.app.dao.repository.BookingClassRepository;
import com.sgl.smartpra.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.master.app.mapper.BookingClassMapper;
import com.sgl.smartpra.master.app.service.BookingClassService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.BookingClassModel;
import com.sgl.smartpra.master.model.ListOfValues;

@Service
@Transactional
public class BookingClassServiceImpl implements BookingClassService {

	@Autowired
	private BookingClassRepository bookingClassRepository;

	@Autowired
	private BookingClassMapper bookingClassMapper;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private BookingClassDao bookingClassDao;

	@Autowired
	private ListOfValuesService listOfValueService;

	public static final String BOOKINGCLASSIDACTIVE = "Booking Class is already in active state";
	public static final String BOOKINGCLASSIDINACTIVE = "Booking Class is already in deactivated state";
	public static final String BOOKINGCLASS = "Booking Class";
	public static final String BOOKINGCLASSID = "Booking Class id not found";
	public static final String LASTUPDATEDBYMSG = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	public static final String LASTUPDATEDBYMENDATORYMSG = "Please provide Last Updated By";
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	private static final String CAN_NOT_BLANK = " cannot be blank";
	private String invalidMarketingCarrierCode = "Invalid Marketing Carrier Code ";
	private String invalidOperatingCarrierCode = "Invalid Operating Carrier Code ";
	private String invalidClientCode = "Invalid Client Code ";
	private String invalidFromAirportCode = "Invalid From Airport Code ";
	private String invalidToAirportCode = "Invalid To Airport Code ";
	String carrierCode = null;
	String carrierName1 = null;
	String carrierName2 = null;
	private static final String TABLE_NAME = LOVEnum.TABLENAME.getLOVEnum();
	private static final String LOV_CABIN = LOVEnum.CABIN.getLOVEnum();

	@Override
	public List<BookingClassModel> getListOfBookingClassByUtilizationEffectiveDate(BookingClassModel bookingClassModel,
			Optional<String> exceptionCall) {
		return bookingClassMapper.mapToModel(bookingClassDao.search(bookingClassModel, exceptionCall));

	}

	@Override
	public BookingClassModel getBookingClassByBookingClassId(Integer bookingClassId) {
		return bookingClassMapper.mapToModel(bookingClassDao.findById(bookingClassId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(bookingClassId))));
	}

	@Override
	public BookingClassModel createBookingClassMaster(BookingClassModel bookingClassModel) {
		validateBusinessConstraintsForCreate(bookingClassModel);
		validateSaleAndUtilEffectiveFrom(bookingClassModel);
		bookingClassModel.setActivate(Boolean.TRUE);
		bookingClassModel.setCreatedDate(LocalDateTime.now());
		return bookingClassMapper.mapToModel(bookingClassDao.create(bookingClassMapper.mapToEntity(bookingClassModel)));
	}

	@Override
	public BookingClassModel updateBookingClassMaster(int bookingClassId, BookingClassModel bookingClassModel) {
		BookingClassEntity bookingClassEntity = bookingClassRepository.findById(bookingClassId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(bookingClassId)));

		if (!bookingClassEntity.getActivate()) {
			throw new BusinessException(BOOKINGCLASSIDACTIVE);
		}
		validateBusinessConstraintsForUpdate(bookingClassModel, bookingClassEntity);
		validateSaleAndUtilEffectiveFrom(bookingClassModel);
		bookingClassModel.setLastUpdatedDate(LocalDateTime.now());
		return bookingClassMapper.mapToModel(
				bookingClassDao.update(bookingClassMapper.mapToEntity(bookingClassModel, bookingClassEntity)));
	}

	@Override
	public void deactivateBookingClassMaster(int bookingClassId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}

		Optional<BookingClassEntity> bookingClassEntity = Optional
				.ofNullable(bookingClassRepository.findById(bookingClassId))
				.orElseThrow(() -> new BusinessException(BOOKINGCLASSID));

		if (!bookingClassEntity.isPresent())
			throw new ResourceNotFoundException(BOOKINGCLASS, "code", bookingClassId);
		if (!bookingClassEntity.get().getActivate())
			throw new BusinessException(BOOKINGCLASSIDINACTIVE);
		bookingClassEntity.get().setActivate(Boolean.FALSE);
		bookingClassEntity.get().setLastUpdatedBy(lastUpdatedBy);
		bookingClassEntity.get().setLastUpdatedDate(LocalDateTime.now());
		bookingClassDao.update(bookingClassEntity.get());
	}

	@Override
	public void activateBookingClassMaster(int bookingClassId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}

		Optional<BookingClassEntity> bookingClassEntity = Optional
				.ofNullable(bookingClassRepository.findById(bookingClassId))
				.orElseThrow(() -> new BusinessException(BOOKINGCLASSID));

		if (!bookingClassEntity.isPresent())
			throw new ResourceNotFoundException(BOOKINGCLASS, "code", bookingClassId);

		if (bookingClassEntity.get().getActivate())
			throw new BusinessException(BOOKINGCLASSIDACTIVE);

		bookingClassEntity.get().setActivate(Boolean.TRUE);
		bookingClassEntity.get().setLastUpdatedBy(lastUpdatedBy);
		bookingClassEntity.get().setLastUpdatedDate(LocalDateTime.now());
		bookingClassDao.update(bookingClassEntity.get());
	}

	private void validateBusinessConstraintsForCreate(BookingClassModel bookingClassModel) {
		validateUtilizationDateForCreate(bookingClassModel);
		checkEmptyField(bookingClassModel);
		checkOverlapForCreate(bookingClassModel);
		commonValidationForCreate(bookingClassModel);
		validateCabin(OptionalUtil.getValue(bookingClassModel.getClientId()),
				OptionalUtil.getValue(bookingClassModel.getCabin()));
		// validation for marketing carrier with carrier master
		marketingCarrierToCarrierDesignatorValidation(bookingClassModel);
		// validation for client code with carrier master
		clientCodeToCarrierDesignatorValidation(bookingClassModel);
		// validation for from airport code with airport master
		fromAirportToAirportForCreate(bookingClassModel);
		// validation for to airport code with airport master
		toAirportToAirportForCreate(bookingClassModel);
		operatingCarrierToCarrierDesignatorValidation(bookingClassModel);

	}

	private void validateBusinessConstraintsForUpdate(BookingClassModel bookingClassModel,
			BookingClassEntity bookingClassEntity) {

		validateUtilizationDateForUpdate(bookingClassModel, bookingClassEntity);
		validateCabinForUpdate(bookingClassModel, bookingClassEntity);
		checkOverlapForUpdate(bookingClassModel, bookingClassEntity);
		// validation for marketing carrier with carrier master
		marketingCarrierToCarrierDesignatorValidation(bookingClassModel);
		// validation for client code with carrier master
		clientCodeToCarrierDesignatorValidation(bookingClassModel);
		commonValidationForUpdate(bookingClassModel, bookingClassEntity);
		// validation for from airport code with airport master
		fromAirportToAirportForUpdate(bookingClassModel, bookingClassEntity);
		operatingCarrierToCarrierDesignatorValidation(bookingClassModel);
		// validation for to airport code with airport master
		toAirportToAirportForUpdate(bookingClassModel, bookingClassEntity);
	}

	private void commonValidationForCreate(BookingClassModel bookingClassModel) {
		if (OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveFromDate())) {
			if (!OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveToDate())) {
				throw new BusinessException("This field Sales Effective To date "
						+ OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveToDate()) + CAN_NOT_BLANK);
			}
		}

		if (OptionalUtil.isPresent(bookingClassModel.getFromAirport())) {
			if (!OptionalUtil.isPresent(bookingClassModel.getToAirport())) {
				throw new BusinessException(
						"This field To Airport " + bookingClassModel.getToAirport() + CAN_NOT_BLANK);
			}
		}

		if (OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveToDate())
				&& OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveFromDate())) {
			boolean salesDateCheck = OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveToDate())
					.isAfter(OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveFromDate()));
			if (!salesDateCheck) {
				throw new BusinessException(
						"Sales To date " + OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveToDate())
								+ " should be greater than Sales From date "
								+ OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveFromDate()));
			}
		}

	}

	private void commonValidationForUpdate(BookingClassModel bookingClassModel, BookingClassEntity bookingClassEntity) {
		if (getSalesEffectiveFromDate(bookingClassModel, bookingClassEntity) != null) {
			if (getSalesEffectiveToDate(bookingClassModel, bookingClassEntity) == null) {
				throw new BusinessException("This field Sales Effective To date "
						+ getSalesEffectiveToDate(bookingClassModel, bookingClassEntity) + CAN_NOT_BLANK);
			}
		}

		if (getFromAirport(bookingClassModel, bookingClassEntity) != null) {
			if (getToAirport(bookingClassModel, bookingClassEntity) == null) {
				throw new BusinessException(
						"This field To Airport " + getToAirport(bookingClassModel, bookingClassEntity) + CAN_NOT_BLANK);
			}
		}
	}

	private void fromAirportToAirportForCreate(BookingClassModel bookingClassModel) {
		if (OptionalUtil.isPresent(bookingClassModel.getFromAirport())) {
			if (OptionalUtil.getValue(bookingClassModel.getFromAirport()).trim().length() > 0) {
				if (!globalMasterFeignClient
						.isValidAirportCodeOrCityCode(OptionalUtil.getValue(bookingClassModel.getFromAirport()))) {
					throw new BusinessException(
							invalidFromAirportCode + OptionalUtil.getValue(bookingClassModel.getFromAirport()));
				}
			}
		}
	}

	private void fromAirportToAirportForUpdate(BookingClassModel bookingClassModel,
			BookingClassEntity bookingClassEntity) {
		if (getFromAirport(bookingClassModel, bookingClassEntity) != null
				&& getFromAirport(bookingClassModel, bookingClassEntity).trim().length() > 0) {
			if (!globalMasterFeignClient
					.isValidAirportCodeOrCityCode(getFromAirport(bookingClassModel, bookingClassEntity))) {
				throw new BusinessException(
						invalidFromAirportCode + getFromAirport(bookingClassModel, bookingClassEntity));
			}
		}
	}

	private void toAirportToAirportForUpdate(BookingClassModel bookingClassModel,
			BookingClassEntity bookingClassEntity) {
		if (getToAirport(bookingClassModel, bookingClassEntity) != null
				&& getToAirport(bookingClassModel, bookingClassEntity).trim().length() > 0) {
			if (!globalMasterFeignClient
					.isValidAirportCodeOrCityCode(getToAirport(bookingClassModel, bookingClassEntity))) {
				throw new BusinessException(invalidToAirportCode + getToAirport(bookingClassModel, bookingClassEntity));
			}
		}
	}

	private void toAirportToAirportForCreate(BookingClassModel bookingClassModel) {

		if (OptionalUtil.isPresent(bookingClassModel.getToAirport())) {
			if (OptionalUtil.getValue(bookingClassModel.getFromAirport()).trim().length() > 0) {
				if (!globalMasterFeignClient
						.isValidAirportCodeOrCityCode(OptionalUtil.getValue(bookingClassModel.getToAirport()))) {
					throw new BusinessException(
							invalidToAirportCode + OptionalUtil.getValue(bookingClassModel.getToAirport()));
				}
			}
		}
	}

	private void marketingCarrierToCarrierDesignatorValidation(BookingClassModel bookingClassModel) {
		if (OptionalUtil.isPresent(bookingClassModel.getMarketingCarrier())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(bookingClassModel.getMarketingCarrier()))) {
			if (globalMasterFeignClient.getAllCarrier(null,
					OptionalUtil.getValue(bookingClassModel.getMarketingCarrier()), null, null, true).isEmpty()) {
				throw new BusinessException(
						invalidMarketingCarrierCode + OptionalUtil.getValue(bookingClassModel.getMarketingCarrier()));
			}
		}
	}

	private void operatingCarrierToCarrierDesignatorValidation(BookingClassModel bookingClassModel) {
		if (OptionalUtil.isPresent(bookingClassModel.getOperatingCarrier())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(bookingClassModel.getOperatingCarrier()))) {
			if (globalMasterFeignClient.getAllCarrier(null,
					OptionalUtil.getValue(bookingClassModel.getOperatingCarrier()), null, null, true).isEmpty()) {
				throw new BusinessException(
						invalidOperatingCarrierCode + OptionalUtil.getValue(bookingClassModel.getOperatingCarrier()));
			}
		}
	}

	private void clientCodeToCarrierDesignatorValidation(BookingClassModel bookingClassModel) {
		if (OptionalUtil.isPresent(bookingClassModel.getClientId())) {
			if (globalMasterFeignClient.getAllCarrier(null, bookingClassModel.getClientId().get(), null, null, true)
					.isEmpty()) {
				throw new BusinessException(invalidClientCode + OptionalUtil.getValue(bookingClassModel.getClientId()));
			}
		}
	}

	private void validateUtilizationDateForCreate(BookingClassModel bookingClassModel) {
		boolean utilizationDateCheck = OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveToDate())
				.isAfter(OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate()));
		if (!utilizationDateCheck) {
			throw new BusinessException("Util Effective To date "
					+ OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveToDate())
					+ " should be greater than Util Effective From date "
					+ OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate()));
		}
	}

	private void validateUtilizationDateForUpdate(BookingClassModel bookingClassModel,
			BookingClassEntity bookingClassEntity) {
		boolean utilizationDateCheck = getUtilEffectiveToDate(bookingClassModel, bookingClassEntity)
				.isAfter(getUtilEffectiveFromDate(bookingClassModel, bookingClassEntity));
		if (!utilizationDateCheck) {
			throw new BusinessException("Util Effective To date "
					+ OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveToDate())
					+ " should be greater than Util Effective From date "
					+ OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate()));
		}
	}

	private void checkOverlapForCreate(BookingClassModel bookingClassModel) {
		LocalDate salesEffectiveFromDate;
		LocalDate salesEffectiveToDate;
		if (!OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveFromDate())) {
			salesEffectiveFromDate = null;
		} else {
			salesEffectiveFromDate = OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveFromDate());
		}
		if (!OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveToDate())) {
			salesEffectiveToDate = null;
		} else {
			salesEffectiveToDate = OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveToDate());
		}
		if (bookingClassDao.getOverlapRecordCount(OptionalUtil.getValue(bookingClassModel.getRbd()),
				OptionalUtil.getValue(bookingClassModel.getMarketingCarrier()),
				OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveToDate()), salesEffectiveFromDate,
				salesEffectiveToDate) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}
	}

	private void checkOverlapForUpdate(BookingClassModel bookingClassModel, BookingClassEntity bookingClassEntity) {
		LocalDate salesEffectiveFromDate = getSalesEffectiveFromDate(bookingClassModel, bookingClassEntity);
		LocalDate salesEffectiveToDate = getSalesEffectiveToDate(bookingClassModel, bookingClassEntity);
		LocalDate utilEffectiveFromDate = getUtilEffectiveFromDate(bookingClassModel, bookingClassEntity);
		LocalDate utilEffectiveToDate = getUtilEffectiveToDate(bookingClassModel, bookingClassEntity);
		String rbd = getRbd(bookingClassModel, bookingClassEntity);
		String marktingCarrier = getMarketingCarrier(bookingClassModel, bookingClassEntity);
		if (!marktingCarrier.equalsIgnoreCase(bookingClassEntity.getMarketingCarrier())
				|| !rbd.equalsIgnoreCase(bookingClassEntity.getRbd())) {
			if (bookingClassDao.getOverlapRecordCount(rbd, marktingCarrier, utilEffectiveFromDate, utilEffectiveToDate,
					salesEffectiveFromDate, salesEffectiveToDate, bookingClassEntity.getBookingClassId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private void validateCabin(String clientId, String cabin) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLE_NAME));
		listOfValuesModel.setColumnName(Optional.of(LOV_CABIN));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(cabin));
		if (!listOfValueService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Invalid Cabin " + cabin);
		}
	}

	private void validateSaleAndUtilEffectiveFrom(BookingClassModel bookingClassModel) {
		if (!OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveFromDate())
				.isBefore(OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate()))
				&& !OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveFromDate())
						.isEqual(OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate()))) {
			throw new BusinessException("Utilization Effective date "
					+ OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate())
					+ " should be greater than or equal to Sales Effective date "
					+ OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveFromDate()));
		}
	}

	private void validateCabinForUpdate(BookingClassModel bookingClassModel, BookingClassEntity bookingClassEntity) {
		if (OptionalUtil.isPresent(bookingClassModel.getClientId())
				|| OptionalUtil.isPresent(bookingClassModel.getCabin())) {
			validateCabin(getClientId(bookingClassModel, bookingClassEntity),
					getCabin(bookingClassModel, bookingClassEntity));
		}
	}

	private String getCabin(BookingClassModel bookingClassModel, BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getCabin())
				? OptionalUtil.getValue(bookingClassModel.getCabin())
				: bookingClassEntity.getCabin();
	}

	private String getClientId(BookingClassModel bookingClassModel, BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getClientId())
				? OptionalUtil.getValue(bookingClassModel.getClientId())
				: bookingClassEntity.getClientId();
	}

	private LocalDate getUtilEffectiveFromDate(BookingClassModel bookingClassModel,
			BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getUtilEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveFromDate())
				: bookingClassEntity.getUtilEffectiveFromDate();
	}

	private LocalDate getUtilEffectiveToDate(BookingClassModel bookingClassModel,
			BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getUtilEffectiveToDate())
				? OptionalUtil.getLocalDateValue(bookingClassModel.getUtilEffectiveToDate())
				: bookingClassEntity.getUtilEffectiveToDate();
	}

	private String getMarketingCarrier(BookingClassModel bookingClassModel, BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getMarketingCarrier())
				? OptionalUtil.getValue(bookingClassModel.getMarketingCarrier())
				: bookingClassEntity.getMarketingCarrier();
	}

	private LocalDate getSalesEffectiveFromDate(BookingClassModel bookingClassModel,
			BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveFromDate())
				: bookingClassEntity.getSalesEffectiveFromDate();
	}

	private LocalDate getSalesEffectiveToDate(BookingClassModel bookingClassModel,
			BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getSalesEffectiveToDate())
				? OptionalUtil.getLocalDateValue(bookingClassModel.getSalesEffectiveToDate())
				: bookingClassEntity.getSalesEffectiveToDate();
	}

	private String getFromAirport(BookingClassModel bookingClassModel, BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getFromAirport())
				? OptionalUtil.getValue(bookingClassModel.getFromAirport())
				: bookingClassEntity.getFromAirport();
	}

	private String getToAirport(BookingClassModel bookingClassModel, BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getToAirport())
				? OptionalUtil.getValue(bookingClassModel.getToAirport())
				: bookingClassEntity.getToAirport();
	}

	private String getRbd(BookingClassModel bookingClassModel, BookingClassEntity bookingClassEntity) {
		return OptionalUtil.isPresent(bookingClassModel.getRbd()) ? OptionalUtil.getValue(bookingClassModel.getRbd())
				: bookingClassEntity.getRbd();
	}

	private void checkEmptyField(BookingClassModel bookingClassModel) {
		if (bookingClassModel.getMarketingCarrier() == null) {
			bookingClassModel.setMarketingCarrier(Optional.ofNullable(""));
		}
	}

	@Override
	public BookingClassModel getBookingClassByRBD(Optional<String> clientId, Optional<String> rbd,
			Optional<String> marketingCarrier, Optional<String> utilizationDate, Optional<String> salesDate) {
		return bookingClassMapper.mapToModel(
				bookingClassDao.getBookingClassByRBD(clientId, rbd, marketingCarrier, utilizationDate, salesDate)
						.orElseThrow(() -> new BusinessException("Record Not Found")));
	}

	@Override
	public Map<String, Set<String>> getListOfRDBFromCabin(String clientId, String salesDate, String utilizationDate) {

		LocalDate utilDate = LocalDate.parse(utilizationDate);
		LocalDate saleDate = LocalDate.parse(salesDate);

		List<BookingClassModel> bookingClassData = bookingClassMapper
				.mapToModel(bookingClassDao.getCabinWithRBDS(clientId, saleDate, utilDate));

		return bookingClassData.stream().collect(Collectors.groupingBy(b -> OptionalUtil.getValue(b.getCabin()),
				Collectors.mapping(b -> OptionalUtil.getValue(b.getRbd()), Collectors.toSet())));
	}

	@Override
	public List<String> getRbdByCabin(String cabin) {
		return bookingClassDao.getRbdByCabin(cabin);
	}

	@Override
	public List<BookingClassModel> getListOfBookingClassByUtilizationEffectiveDate(
			Optional<String> utilizationEffectiveFromDate, Optional<String> utilizationEffectiveToDate,
			Optional<String> rbd, Optional<String> salesEffectiveFromDate, Optional<String> salesEffectiveToDate,
			Optional<String> cabin, Optional<String> marketingCarrier, Optional<String> fromAirport,
			Optional<String> toAirport) {
		BookingClassModel bookingClassModel = new BookingClassModel();
		bookingClassModel.setUtilEffectiveFromDate(utilizationEffectiveFromDate);
		bookingClassModel.setUtilEffectiveToDate(utilizationEffectiveToDate);
		bookingClassModel.setRbd(rbd);
		bookingClassModel.setSalesEffectiveFromDate(salesEffectiveFromDate);
		bookingClassModel.setSalesEffectiveToDate(salesEffectiveToDate);
		bookingClassModel.setCabin(cabin);
		bookingClassModel.setMarketingCarrier(marketingCarrier);
		bookingClassModel.setFromAirport(fromAirport);
		bookingClassModel.setToAirport(toAirport);

		return bookingClassMapper.mapToModel(bookingClassDao.search(bookingClassModel, Optional.of("")));
	}
}
