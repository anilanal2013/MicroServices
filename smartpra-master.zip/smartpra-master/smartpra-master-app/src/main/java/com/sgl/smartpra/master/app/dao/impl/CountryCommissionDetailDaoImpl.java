package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.master.app.dao.CountryCommissionDetailDao;
import com.sgl.smartpra.master.app.dao.repository.CountryCommissionDetailRepository;
import com.sgl.smartpra.master.model.CountryCommissionDetail;
import com.sgl.smartpra.master.app.dao.entity.CountryCommissionDetailEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.CountryCommissionDetailSpecification;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CountryCommissionDetailDaoImpl extends CommonSearchDao<CountryCommissionDetail> implements CountryCommissionDetailDao{
	
	@Autowired
	private CountryCommissionDetailRepository countryCommissionDetailRepository;
	
	
	@Override	
	@Cacheable(value = "countryCommissionDetail", key = "#id")
	public Optional<CountryCommissionDetailEntity> findById(Integer id) {
		log.info("Cacheable CountryCommissionDetail Entity's ID = {}", id);
		return countryCommissionDetailRepository.findById(id);		 
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "countryCommissionDetail", key = "#countryCommissionDetail.countryCommissionDetailId")})
	public CountryCommissionDetailEntity create(CountryCommissionDetailEntity countryCommissionDetail) {
		return countryCommissionDetailRepository.save(countryCommissionDetail);
	}

	@Override
	@CachePut(value = "countryCommissionDetail", key = "#countryCommissionDetail.countryCommissionDetailId")
	public CountryCommissionDetailEntity update(CountryCommissionDetailEntity countryCommissionDetail) {
		return countryCommissionDetailRepository.save(countryCommissionDetail);
	}	

	@Override
	public List<CountryCommissionDetailEntity> searchCountryCommissionDetail(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> countryCode, Optional<String> cabinClass) {		
		return countryCommissionDetailRepository.findAll(CountryCommissionDetailSpecification.searchCountryCommission(effectiveFromDate, effectiveToDate, countryCode, cabinClass));
	}
	
	@Override
	public Long getOverLapCount(LocalDate effectiveFromDate,
			LocalDate effectiveToDate, String countryCode, String cabinClass, String clientId, String netGrossFlag) {
		return countryCommissionDetailRepository.count(Specification.where(CountryCommissionDetailSpecification.equalsCabinClass(cabinClass))
				.and(CountryCommissionDetailSpecification.equalCountryCode(countryCode))
				.and(CountryCommissionDetailSpecification.equalsClientId(clientId))
				.and(CountryCommissionDetailSpecification.equalsNetGrossFlag(netGrossFlag))
				.and( (CountryCommissionDetailSpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
					.or(CountryCommissionDetailSpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
					.or(CountryCommissionDetailSpecification.greaterOrLessThanEffectiveFromAndEffectiveToDate(effectiveFromDate, effectiveToDate))
				));
	}

	@Override
	public List<CountryCommissionDetailEntity> searchCountryCommissionDetailByCountryCode(String issueDate,
			String countryCode) {
		return countryCommissionDetailRepository.findAll(CountryCommissionDetailSpecification
				.searchCountryCommissionDetailByCountryCode(issueDate, countryCode));
	}

	@Override
	public List<CountryCommissionDetailEntity> verifyIfSameRecordExits(LocalDate effectiveFromDate,
			LocalDate effectiveToDate, String countryCode, String cabinClass,String clientId, String netGrossFlag) {
		return countryCommissionDetailRepository.findAll(Specification.where(CountryCommissionDetailSpecification.equalsCabinClass(cabinClass))
				.and(CountryCommissionDetailSpecification.equalCountryCode(countryCode))
				.and(CountryCommissionDetailSpecification.equalsClientId(clientId))
				.and(CountryCommissionDetailSpecification.equalsNetGrossFlag(netGrossFlag))
				.and( (CountryCommissionDetailSpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
					.or(CountryCommissionDetailSpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
					
				));

	}

}
