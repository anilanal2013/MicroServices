package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.StockEntity;

public class StockEntitySpecification {
	private StockEntitySpecification() {
	}

	public static void orderByAsc(Root<StockEntity> stockEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(stockEntity.get(orderByString)));
	}

	public static Specification<StockEntity> search(Optional<String> documentSeriesFrom,
			Optional<String> documentSeriesTo, Optional<String> documentType, Optional<String> clientId, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<Boolean> activate) {
		return (stockEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(documentSeriesFrom) && OptionalUtil.isPresent(documentSeriesTo)) {
				
				if(OptionalUtil.getValue(documentSeriesFrom).length() == 10 && OptionalUtil.getValue(documentSeriesTo).length() == 10) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getValue(documentSeriesFrom)),
								stockEntity.get("documentSeriesFrom"), stockEntity.get("documentSeriesTo")),
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getValue(documentSeriesTo)),
								stockEntity.get("documentSeriesFrom"), stockEntity.get("documentSeriesTo"))));
				}else {
					predicates.add(criteriaBuilder.like(stockEntity.get("documentSeriesFrom"),
							OptionalUtil.getValue(documentSeriesFrom) + "%"));
					predicates.add(criteriaBuilder.like(stockEntity.get("documentSeriesTo"),
							OptionalUtil.getValue(documentSeriesTo) + "%"));
				}
				
			} else {
				if (OptionalUtil.isPresent(documentSeriesFrom) && OptionalUtil.getValue(documentSeriesFrom).length() == 10) {
					predicates.add(
							criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getValue(documentSeriesFrom)),
									stockEntity.get("documentSeriesFrom"), stockEntity.get("documentSeriesTo")));
				}else if(OptionalUtil.isPresent(documentSeriesFrom)  && OptionalUtil.getValue(documentSeriesFrom).length() != 10){
					predicates.add(criteriaBuilder.like(stockEntity.get("documentSeriesFrom"),
							OptionalUtil.getValue(documentSeriesFrom) + "%"));	
				}
				
				if (OptionalUtil.isPresent(documentSeriesTo) && OptionalUtil.getValue(documentSeriesTo).length() == 10) {
					predicates.add(
							criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getValue(documentSeriesTo)),
									stockEntity.get("documentSeriesFrom"), stockEntity.get("documentSeriesTo")));
				}else if (OptionalUtil.isPresent(documentSeriesTo) && OptionalUtil.getValue(documentSeriesTo).length() != 10){
					predicates.add(criteriaBuilder.like(stockEntity.get("documentSeriesTo"),
							OptionalUtil.getValue(documentSeriesTo) + "%"));
				}
				
			}
			if (OptionalUtil.isPresent(documentType)) {
				predicates.add(criteriaBuilder.like(stockEntity.get("documentType"),
						OptionalUtil.getValue(documentType) + "%"));
			}
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(stockEntity.get("clientId"),
						OptionalUtil.getValue(clientId) ));
			}			
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								stockEntity.get("effectiveFromDate"), stockEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								stockEntity.get("effectiveFromDate"), stockEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							stockEntity.get("effectiveFromDate"), stockEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							stockEntity.get("effectiveFromDate"), stockEntity.get("effectiveToDate")));
				}
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(stockEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(stockEntity.get("activate"), Boolean.TRUE));
			}
			orderByAsc(stockEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<StockEntity> betweenDocumentFromAndDocumentTo(String documentSeries) {
		return (stockEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(documentSeries), stockEntity.get("documentSeriesFrom"),
				stockEntity.get("documentSeriesTo"));
	}

	public static Specification<StockEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (stockEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), stockEntity.get("effectiveFromDate"),
				stockEntity.get("effectiveToDate"));
	}
	
	public static Specification<StockEntity> betweenEffectiveFrom(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return (stockEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				stockEntity.get("effectiveFromDate"), criteriaBuilder.literal(effectiveFromDate),
				criteriaBuilder.literal(effectiveToDate));

	}

	public static Specification<StockEntity> isActive() {
		return (stockEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(stockEntity.get("activate"),
				true);
	}

	public static Specification<StockEntity> equalsClientId(String clientId) {
		return (stockEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(stockEntity.get("clientId"),
				clientId);
	}
	
	public static Specification<StockEntity> equalsStockId(Integer stockId) {
		return (stockEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(stockEntity.get("stockId"),
				stockId);
	}

	public static Specification<StockEntity> equalsDocumentType(String documentType) {
		return (stockEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(stockEntity.get("documentType"),
				documentType);
	}

	public static Specification<StockEntity> notEqualsStockId(Integer stockId) {
		return (stockEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(stockEntity.get("stockId"),
				stockId);
	}
}
