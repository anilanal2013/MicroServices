package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.EstimationAverageDao;
import com.sgl.smartpra.master.app.dao.entity.EstimationAverageEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.EstimationAverageSpecification;
import com.sgl.smartpra.master.app.repository.EstimationAverageRepository;
import com.sgl.smartpra.master.model.EstimationAverage;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class EstimationAverageDaoImpl implements EstimationAverageDao {
	@Autowired
	private EstimationAverageRepository estimationAverageRepository;

	public List<EstimationAverageEntity> search(EstimationAverage estimationAverage, Optional<String> exceptionCall) {
		return estimationAverageRepository
				.findAll(EstimationAverageSpecification.search(estimationAverage, exceptionCall));
	}

	@Override
	public Optional<EstimationAverageEntity> getEstimationAverage(Optional<String> flightNumber,
			Optional<String> fromAirport, Optional<String> toAirport, Optional<String> rbd, Optional<String> cabin,
			Optional<String> passengerType, Optional<String> selfOc, LocalDate flightDate) {
		return estimationAverageRepository.findOne(EstimationAverageSpecification.search(flightNumber, fromAirport,
				toAirport, rbd, cabin, passengerType, selfOc, flightDate));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "estimationAverage", key = "#estimationAverageEntity.estimationAverageId") })
	public EstimationAverageEntity createEstimationAverage(EstimationAverageEntity estimationAverageEntity) {
		return estimationAverageRepository.save(estimationAverageEntity);
	}

	@Override
	@CachePut(value = "estimationAverage", key = "#estimationAverageEntity.estimationAverageId")
	public EstimationAverageEntity updateEstimationAverage(EstimationAverageEntity estimationAverageEntity) {
		return estimationAverageRepository.save(estimationAverageEntity);
	}

	@Override
	@Cacheable(value = "estimationAverage", key = "#id")
	public Optional<EstimationAverageEntity> findById(Integer id) {
		log.info("Cacheable Estimation Average Entity's ID= {}", id);
		return estimationAverageRepository.findById(id);
	}

	@Override
	public long getOverLapRecordCount(Optional<String> clientId, Optional<String> flightNumber,
			Optional<String> fromAirport, Optional<String> toAirport, Optional<String> flightDate, Optional<String> rbd,
			Optional<String> cabin, Optional<String> passengerType, Optional<String> selfOc) {
		return estimationAverageRepository.count(Specification.where(EstimationAverageSpecification
				.equalsClientId(OptionalUtil.getValue(clientId))
				.and(EstimationAverageSpecification.equalsFlightNumber(OptionalUtil.getValue(flightNumber)))
				.and(EstimationAverageSpecification.equalsFromAirport(OptionalUtil.getValue(fromAirport)))
				.and(EstimationAverageSpecification.equalsToAirport(OptionalUtil.getValue(toAirport)))
				.and(EstimationAverageSpecification.equalsFlightDate(OptionalUtil.getLocalDateValue(flightDate)))
				.and(EstimationAverageSpecification.equalsRbd(OptionalUtil.getValue(rbd)))
				.and(EstimationAverageSpecification.equalsCabin(OptionalUtil.getValue(cabin)))
				.and(EstimationAverageSpecification.equalsPassengerType(OptionalUtil.getValue(passengerType)))
				.and(EstimationAverageSpecification.equalsSelfOc(OptionalUtil.getValue(selfOc)))));
	}

	@Override
	public long getOverLapRecordCount(String clientId, String flightNumber, String fromAirport, String toAirport,
			LocalDate flightDate, String rbd, String cabin, String passengerType, String selfOc,
			Integer estimationAverageId) {
		return estimationAverageRepository.count(Specification.where(EstimationAverageSpecification
				.equalsClientId(clientId).and(EstimationAverageSpecification.equalsFlightNumber(flightNumber))
				.and(EstimationAverageSpecification.equalsFromAirport(fromAirport))
				.and(EstimationAverageSpecification.equalsToAirport((toAirport))
						.and(EstimationAverageSpecification.equalsFlightDate(flightDate))
						.and(EstimationAverageSpecification.equalsRbd(rbd))
						.and(EstimationAverageSpecification.equalsCabin(cabin))
						.and(EstimationAverageSpecification.equalsPassengerType(passengerType))
						.and(EstimationAverageSpecification.equalsSelfOc(selfOc))
						.and(EstimationAverageSpecification.notEqualsEstimationAverageId(estimationAverageId)))));
	}

	@Override
	public Page<EstimationAverageEntity> getAllEstimationAverages(EstimationAverageEntity estimationAverageEntity,
			Pageable pageable, Optional<String> exceptionCall) {
		return estimationAverageRepository
				.findAll(EstimationAverageSpecification.getAllEstimationAverages(estimationAverageEntity.getClientId(),
						estimationAverageEntity.getFlightNumber(), estimationAverageEntity.getFromAirport(),
						estimationAverageEntity.getToAirport(), estimationAverageEntity.getRbd(),
						estimationAverageEntity.getCabin(), estimationAverageEntity.getPassengerType(),
						estimationAverageEntity.getSelfOc(), estimationAverageEntity.getFlightDate(),
						estimationAverageEntity.getActivate(), exceptionCall), pageable);

	}

	@Override
	public Long getCount(EstimationAverageEntity estimationAverageEntity) {
		return estimationAverageRepository.count(EstimationAverageSpecification.getAllEstimationAverages("",
				estimationAverageEntity.getFlightNumber(), estimationAverageEntity.getFromAirport(),
				estimationAverageEntity.getToAirport(), estimationAverageEntity.getRbd(),
				estimationAverageEntity.getCabin(), estimationAverageEntity.getPassengerType(),
				estimationAverageEntity.getSelfOc(), estimationAverageEntity.getFlightDate(),
				estimationAverageEntity.getActivate(), Optional.of("")));
	}

}