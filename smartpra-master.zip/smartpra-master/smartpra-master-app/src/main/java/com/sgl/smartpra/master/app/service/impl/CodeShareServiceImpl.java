package com.sgl.smartpra.master.app.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTimeComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.CodeShareDao;
import com.sgl.smartpra.master.app.dao.entity.CodeShareEntity;
import com.sgl.smartpra.master.app.dao.repository.CodeShareRepository;
import com.sgl.smartpra.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.master.app.mapper.CodeShareMapper;
import com.sgl.smartpra.master.app.service.ClientUserAreaService;
import com.sgl.smartpra.master.app.service.CodeShareService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.app.service.ProrateDiscountService;
import com.sgl.smartpra.master.app.service.SystemParameterService;
import com.sgl.smartpra.master.model.CodeShare;
import com.sgl.smartpra.master.model.Geo;
import com.sgl.smartpra.master.model.SystemParameter;

@Service
@Transactional
public class CodeShareServiceImpl implements CodeShareService {

	@Autowired
	CodeShareMapper codeSharemapper;
	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;
	@Autowired
	private CodeShareRepository codeShareRepository;

	@Autowired
	private ProrateDiscountService prorateDiscountService;

	@Autowired
	private ListOfValuesService lovService;

	@Autowired
	private SystemParameterService systemParameterService;

	@Autowired
	ClientUserAreaService clientUserAreaService;

	@Autowired
	private CodeShareDao codeShareDao;

	private static final String LASTUPDATEDBYMENDATORYMSG = "Please provide Last Updated By";
	private static final String LASTUPDATEDBYMSG = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	private static final String CODESHARE = "Code Share";
	private static final String CODESHAREALREADYINACTIVE = "Code Share is already in deactivated state";
	private static final String CODESHAREALREADYACTIVE = "Code Share is already in activated state";
	private static final String TRAVELWODVALIDATIONMSG = "Values allowed for Travel DOW is N,Y";
	private static final String AREAFBWINDICATOR = "Only valid values for Area FBW Indicator field is 'F'|'B'|W ";
	private static final String AREAFBINDICATOR = "If FBW Area Indicator is W, then only From Area is mandatory";
	private static final String INVALIDFROMAREA = "Invalid From Area ";
	private static final String INVALIDTOAREA = "Invalid To Area ";
	private static final String CODESHAREIDEACTIVESTATE = "Code Share Id is in deactivate state";
	private static final String CLIENT = "client";
	private static final String RANGEBOOKEDFLIGHTNUMBER = "To Booked Flight Number should be greater than From Booked Flight Number";
	private static final String PATTERN = "^[a-zA-Z]*$";
	private static final String FLIGHTNUMBERPATTERN =  "-?\\d+";
	private static final String INCORRECT_FIELD =  "Invalid Flight Number : ";
	private static final String GLOBAL = "global";
	private static final String RANGEOPERATINGFLIGHTNUMBER = "To Operating Flight Number should be greater than From Operating Flight Number";
	private static final String LINKCXRISNOTNULLTHENMARKETINGCXRMENDATORY = "If LinkCXR is captured, then marketing CXR needs to be partition CXR / default CXR";
	private static final String FLIGHTRANGEDIFFERENCE = "Flight range difference should be same for booked and Operating flights";
	@Override
	public List<CodeShare> getAllCodeShare(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> effectiveTravelFromDate, Optional<String> effectiveTravelToDate,
			Optional<String> effectiveSaleFromDate,Optional<String> effectiveSaleToDate, Optional<Boolean> isActive) {
		return codeSharemapper.mapToModel(codeShareDao.findAll(clientId, marketingCXR,
				effectiveTravelFromDate, effectiveTravelToDate, effectiveSaleFromDate, effectiveSaleToDate, isActive));
	}

	@Override
	public List<CodeShare> getCodeShareByEffectiveDate(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> marketedRBDList, Optional<String> effectiveDate) {
		return codeSharemapper.mapToModel(codeShareDao.search(clientId, marketingCXR, marketedRBDList, effectiveDate));
	}

	@Override
	public CodeShare getCodeShareBymarketingCXR(String marketingCXR, Date travelEffectiveDate, Date saleEffectiveDate,
			String clientId, String flightNumber) {
		CodeShare codeShare = null;
		codeShare = codeSharemapper.mapToModel(codeShareRepository.getCodeShareByMarketingCXR(marketingCXR,
				convertLocalDate(travelEffectiveDate), convertLocalDate(saleEffectiveDate), clientId, flightNumber));
		if (codeShare != null && !codeShare.getIsActive()) {
			throw new BusinessException("record is not active with parameter marketingCXR :" + marketingCXR
					+ ",travelEffectiveDate :" + travelEffectiveDate + ",saleEffectiveDate :" + saleEffectiveDate
					+ ",clientId :" + clientId + ",flightNumber :" + flightNumber + " ");
		} else {
			return codeShare;
		}
	}

	@Override
	public CodeShare createCodeShare(CodeShare codeShare) {
		validateSaleDateFormat(codeShare);
		validateAllDate(codeShare);
		codeshareOverlappingForCreate(codeShare);
		commonValidation(codeShare);
		additionalCodeShareValidation(codeShare);

		String areaFromInclude = null;
		String areaFromExclude = null;
		String areaToInclude = null;
		String areaToExclude = null;
		String[] fromAreaArray = null;
		String userFromArea = null;
		String userToArea = null;
		if (OptionalUtil.isPresent(codeShare.getFromArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea()))) {
			fromAreaArray = validateArea(OptionalUtil.getValue(codeShare.getFromArea()), codeShare.getFromAreaInclude(),
					codeShare.getFromAreaExclude(), codeShare.getUserFromAreaName(), CLIENT, "From Area");
			areaFromInclude = fromAreaArray[0];
			areaFromExclude = fromAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}
		String[] toAreaArray = null;
		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea()))) {
			toAreaArray = validateArea(OptionalUtil.getValue(codeShare.getToArea()), codeShare.getToAreaInclude(),
					codeShare.getToAreaExclude(), codeShare.getUserToAreaName(), CLIENT, "To Area");
			areaToInclude = toAreaArray[0];
			areaToExclude = toAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}
		boolean fromAreaStandardAreaFlag = false;
		boolean toAreaStandardAreaFlag = false;
		if (OptionalUtil.isPresent(codeShare.getFromArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea())))
			fromAreaStandardAreaFlag = OptionalUtil.getValue(codeShare.getFromArea()).startsWith("4");

		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea())))
			toAreaStandardAreaFlag = OptionalUtil.getValue(codeShare.getToArea()).startsWith("4");

		// validation to_billing
		if (OptionalUtil.isPresent(codeShare.getFromArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea()))) {
			userFromArea = OptionalUtil.getValue(codeShare.getFromArea()).substring(1,
					OptionalUtil.getValue(codeShare.getFromArea()).length());
		}
		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea()))) {
			userToArea = OptionalUtil.getValue(codeShare.getToArea()).substring(1,
					OptionalUtil.getValue(codeShare.getToArea()).length());
		}
		codeShare.setCreatedDate(LocalDateTime.now());
		codeShare.setIsActive(Boolean.TRUE);
		codeShare.setOperatingCXR(codeShare.getOperatingCXR());
		CodeShare codeShareImpl = codeSharemapper
				.mapToModel(codeShareRepository.save(codeSharemapper.mapToEntity(codeShare)));
		Boolean updateFlag = false;
		String areaKey1 = "C";
		String areaKey2 = OptionalUtil.getValue(codeShare.getMarketingCXR());
		String areaKey3 = codeShareImpl.getCodeShareId().toString();
		String areaKey4 = OptionalUtil.getValue(codeShare.getClientId());
		Map<String, String> map = new HashMap<>();
		map.put("areaKey1", areaKey1);
		map.put("areaKey2", areaKey2);
		map.put("areaKey3", areaKey3);
		map.put("areaKey4", areaKey4);
		map.put("userFromAreaName", codeShare.getUserFromAreaName());
		map.put("areaFromInclude", areaFromInclude);
		map.put("areaFromExclude", areaFromExclude);
		map.put("createdBy", OptionalUtil.getValue(codeShare.getCreatedBy()));
		map.put("userFromArea", userFromArea);
		map.put("updateFlag", updateFlag.toString());

		if (OptionalUtil.isPresent(codeShare.getFromArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea())) && fromAreaStandardAreaFlag) {
			clientUserAreaService.clientSpecificUserAreaInsertOrUpdate(map);
		}

		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea())) && toAreaStandardAreaFlag) {
			map.put("userFromAreaName", null);
			map.put("areaToInclude", areaToInclude);
			map.put("areaToExclude", areaToExclude);
			map.put("userToAreaName", codeShare.getUserToAreaName());
			map.put("userToArea", userToArea);
		}
		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea())) && toAreaStandardAreaFlag) {
			clientUserAreaService.clientSpecificUserAreaInsertOrUpdate(map);
		}
		return codeShareImpl;
	}

	@Override
	public CodeShare updateCodeShare(Integer codeShareId, CodeShare codeShare) {
		String clientId = OptionalUtil.getValue(codeShare.getClientId());
		try {
			Integer.parseInt(codeShareId.toString());
		} catch (NumberFormatException nfe) {
			throw new BusinessException("Only numeric values allowed for codeShare Id");
		}
		Optional<CodeShareEntity> codeShareEntity = codeShareDao.findById(codeShareId);
		if (!codeShareEntity.isPresent())
			throw new ResourceNotFoundException(CODESHARE, "id", codeShareId);

		if (!codeShareEntity.get().getIsActive())
			throw new BusinessException(CODESHAREIDEACTIVESTATE);
		validateSaleDateFormat(codeShare);
		validateAllDate(codeShare);
		codeshareOverlappingForUpdate(codeShare);
		commonValidation(codeShare);
		additionalCodeShareValidation(codeShare);
		String userFromArea = null;
		String userToArea = null;
		String areaFromInclude = null;
		String areaFromExclude = null;
		String areaToInclude = null;
		String areaToExclude = null;

		if (OptionalUtil.isPresent(codeShare.getFromArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea()))) {
			String[] fromAreaArray = prorateDiscountService.validateArea(OptionalUtil.getValue(codeShare.getFromArea()),
					codeShare.getFromAreaInclude(), codeShare.getFromAreaExclude(), codeShare.getUserFromAreaName(),
					CLIENT);
			areaFromInclude = fromAreaArray[0];
			areaFromExclude = fromAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea()))) {
			String[] toAreaArray = prorateDiscountService.validateArea(OptionalUtil.getValue(codeShare.getToArea()),
					codeShare.getToAreaInclude(), codeShare.getToAreaExclude(), codeShare.getUserToAreaName(), CLIENT);
			areaToInclude = toAreaArray[0];
			areaToExclude = toAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		boolean fromAreaStandardAreaFlag = false;
		boolean toAreaStandardAreaFlag = false;
		if (OptionalUtil.isPresent(codeShare.getFromArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea())))
			fromAreaStandardAreaFlag = OptionalUtil.getValue(codeShare.getFromArea()).startsWith("4");

		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea())))
			toAreaStandardAreaFlag = OptionalUtil.getValue(codeShare.getToArea()).startsWith("4");
		// this code just change from here
		CodeShareEntity codeShareEntityUpdated = codeShareEntity.get();
		codeShareEntityUpdated.setAreaFBWIndicator(OptionalUtil.getValue(codeShare.getAreaFBWIndicator()));
		codeShareEntityUpdated.setBillingTo(OptionalUtil.getValue(codeShare.getBillingTo()));
		codeShareEntityUpdated.setClientId(OptionalUtil.getValue(codeShare.getClientId()));
		if (OptionalUtil.isPresent(codeShare.getFromArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea()))) {
			userFromArea = OptionalUtil.getValue(codeShare.getFromArea()).substring(1,
					OptionalUtil.getValue(codeShare.getFromArea()).length());
			codeShareEntityUpdated.setFromArea(OptionalUtil.getValue(codeShare.getFromArea()));
		}
		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea()))) {
			userToArea = OptionalUtil.getValue(codeShare.getToArea()).substring(1,
					OptionalUtil.getValue(codeShare.getToArea()).length());
			codeShareEntityUpdated.setToArea(OptionalUtil.getValue(codeShare.getToArea()));
		}
		
		codeShareEntityUpdated.setFromBookedFlightNumber(OptionalUtil.getValue(codeShare.getFromBookedFlightNumber()));
		codeShareEntityUpdated
				.setFromOperatingFlightNumber(OptionalUtil.getValue(codeShare.getFromOperatingFlightNumber()));
		codeShareEntityUpdated.setLastUpdatedBy(OptionalUtil.getValue(codeShare.getLastUpdatedBy()));
		codeShareEntityUpdated.setLinkCXR(OptionalUtil.getValue(codeShare.getLinkCXR()));
		codeShareEntityUpdated.setMarketedRBDList(OptionalUtil.getValue(codeShare.getMarketedRBDList()));
		codeShareEntityUpdated.setMarketingCXR(OptionalUtil.getValue(codeShare.getMarketingCXR()));
		codeShareEntityUpdated.setOperatedRBDList(OptionalUtil.getValue(codeShare.getOperatedRBDList()));
		codeShareEntityUpdated.setOperatingCXR(OptionalUtil.getValue(codeShare.getOperatingCXR()));
		codeShareEntityUpdated.setSaleFromDate(LocalDate.parse(OptionalUtil.getValue(codeShare.getSaleFromDate())));
		codeShareEntityUpdated.setSaleToDate(LocalDate.parse(OptionalUtil.getValue(codeShare.getSaleToDate())));
		codeShareEntityUpdated.setTravelDOW(OptionalUtil.getValue(codeShare.getTravelDOW()));
		codeShareEntityUpdated.setTravelFromDate(LocalDate.parse(OptionalUtil.getValue(codeShare.getTravelFromDate())));
		codeShareEntityUpdated.setTravelToDate(LocalDate.parse(OptionalUtil.getValue(codeShare.getTravelToDate())));
		codeShareEntityUpdated.setLastUpdatedDate(LocalDateTime.now());
		codeShareEntityUpdated.setIsActive(Boolean.TRUE);
		CodeShare codeShareImpl = codeSharemapper.mapToModel(codeShareRepository.save(codeShareEntityUpdated));
		Boolean updateFlag = true;
		String areaKey1 = "C";
		String areaKey2 = OptionalUtil.getValue(codeShare.getMarketingCXR());
		String areaKey3 = codeShareImpl.getCodeShareId().toString();
		String areaKey4 = clientId;
		Map<String, String> map = new HashMap<>();
		map.put("areaKey1", areaKey1);
		map.put("areaKey2", areaKey2);
		map.put("areaKey3", areaKey3);
		map.put("areaKey4", areaKey4);
		map.put("userFromAreaName", codeShare.getUserFromAreaName());
		map.put("areaFromInclude", areaFromInclude);
		map.put("areaFromExclude", areaFromExclude);
		map.put("createdBy", OptionalUtil.getValue(codeShare.getLastUpdatedBy()));
		map.put("userFromArea", userFromArea);
		map.put("updateFlag", updateFlag.toString());
		map.put("lastUpdatedBy", OptionalUtil.getValue(codeShare.getLastUpdatedBy()));
		if (OptionalUtil.isPresent(codeShare.getFromArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea())) && fromAreaStandardAreaFlag) {
			clientUserAreaService.clientSpecificUserAreaInsertOrUpdate(map);
		}
		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea())) && toAreaStandardAreaFlag) {
			map.put("areaToInclude", areaToInclude);
			map.put("areaToExclude", areaToExclude);
			map.put("userToAreaName", codeShare.getUserToAreaName());
			map.put("userToArea", userToArea);
		}
		if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea())) && toAreaStandardAreaFlag) {
			clientUserAreaService.clientSpecificUserAreaInsertOrUpdate(map);
		}
		return codeShareImpl;
	}
	
	private void validateSaleDateFormat(CodeShare codeShare) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			if(OptionalUtil.isPresent(codeShare.getSaleFromDate())) {
				sdf.parse(OptionalUtil.getValue(codeShare.getSaleFromDate()));
			 }
			if(OptionalUtil.isPresent(codeShare.getSaleToDate())) {
				 sdf.parse(OptionalUtil.getValue(codeShare.getSaleToDate())); 
			 }
		} catch (ParseException e) {
			throw new BusinessException("Required Date Pattern is yyyy-MM-dd for Sale From and To date");
		}
	}
	
	/*private void codeshareOverlappingForCreate(CodeShare codeShare) {
			long k = codeShareDao.overlappingCXRWithFlightNumber(OptionalUtil.getValue(codeShare.getMarketingCXR()),
					OptionalUtil.isPresent(codeShare.getFromBookedFlightNumber()) && OptionalUtil.getValue(codeShare.getFromBookedFlightNumber()) != null ? OptionalUtil.getValue(codeShare.getFromBookedFlightNumber()) : null,
					OptionalUtil.isPresent(codeShare.getToBookedFlightNumber()) && OptionalUtil.getValue(codeShare.getToBookedFlightNumber()) != null ? OptionalUtil.getValue(codeShare.getToBookedFlightNumber()) : null,
					OptionalUtil.getValue(codeShare.getSaleFromDate()) != null && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getSaleFromDate()))  ? LocalDate.parse(OptionalUtil.getValue(codeShare.getSaleFromDate())) : null,
					OptionalUtil.getValue(codeShare.getSaleToDate()) != null && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getSaleToDate()))  ? LocalDate.parse(OptionalUtil.getValue(codeShare.getSaleToDate())) : null,
					LocalDate.parse(OptionalUtil.getValue(codeShare.getTravelFromDate())),
					LocalDate.parse(OptionalUtil.getValue(codeShare.getTravelToDate())),
					OptionalUtil.getValue(codeShare.getClientId()));
			if (k > 0) {
				throw new BusinessException("Record Already Exists");
			}
	}*/
	
	private void codeshareOverlappingForCreate(CodeShare codeShare) {
		long k = codeShareDao.overlappingCXRWithFlightNumber(codeShare.getMarketingCXR(),
                codeShare.getFromBookedFlightNumber(),
			    codeShare.getToBookedFlightNumber(),
				codeShare.getSaleFromDate(),
				codeShare.getSaleToDate(),
				codeShare.getTravelFromDate(),
				codeShare.getTravelToDate(),
				Optional.ofNullable(codeShare.getCodeShareId()),
				codeShare.getClientId());
		if (k > 0) {
			throw new BusinessException("Record Already Exists");
		}
}
	
	private void codeshareOverlappingForUpdate(CodeShare codeShare) {
		long k = codeShareDao.overlappingCXRWithFlightNumber(codeShare.getMarketingCXR(),
                codeShare.getFromBookedFlightNumber(),
			    codeShare.getToBookedFlightNumber(),
				codeShare.getSaleFromDate(),
				codeShare.getSaleToDate(),
				codeShare.getTravelFromDate(),
				codeShare.getTravelToDate(),
				Optional.ofNullable(codeShare.getCodeShareId()),
				codeShare.getClientId());
		if (k > 0) {
			throw new BusinessException("Record Already Exists");
		}
}

	private void additionalCodeShareValidation(CodeShare codeShare) {

		String clientId = OptionalUtil.getValue(codeShare.getClientId());
		
		List<String> elementTypeList = lovService.getListOfValues(Optional.of(clientId),Optional.of(LOVEnum.TABLENAME.getLOVEnum()), 
				Optional.of(LOVEnum.BILLING.getLOVEnum()));
		boolean flag = false;
		for (String elementTypestr : elementTypeList) {
			if (elementTypestr.equals(OptionalUtil.getValue(codeShare.getBillingTo()))) {
				flag = true;
			}
		}
		if (!flag) {
			throw new BusinessException("Invalid Billing To " + OptionalUtil.getValue(codeShare.getBillingTo()));
		}

		// validate If Link CXR is captured, then marketing CXR needs to be partition
		// CXR / default CXR.
		SystemParameter systemParameter = null;

		if (OptionalUtil.isPresent(codeShare.getLinkCXR()) && OptionalUtil.getValue(codeShare.getLinkCXR()) != null && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getLinkCXR()).trim())) {
			systemParameter = systemParameterService.findSystemParameterByParameterNameAndClientId(
					"DEFAULT_CARRIER_ALPHA_CODE", OptionalUtil.getValue(codeShare.getClientId()));
			
				if (OptionalUtil.isPresent(codeShare.getMarketingCXR()) && systemParameter != null && !systemParameter.getParameterRangeFrom().get()
						.equalsIgnoreCase(OptionalUtil.getValue(codeShare.getMarketingCXR()))) {
					throw new BusinessException(LINKCXRISNOTNULLTHENMARKETINGCXRMENDATORY);
				} 
		}

		// validate the operationCXR code
		if (OptionalUtil.isPresent(codeShare.getOperatingCXR()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getOperatingCXR()).trim()) && (!globalMasterFeignClient
				.isValidCarrierDesignatorCodeList(OptionalUtil.getValue(codeShare.getOperatingCXR()).trim()))) {
			throw new BusinessException("Invalid Operating CXR " + OptionalUtil.getValue(codeShare.getOperatingCXR()));
		}

		// validate the operationCXR code
		if (OptionalUtil.isPresent(codeShare.getLinkCXR()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getLinkCXR()).trim()) && (!globalMasterFeignClient
				.isValidCarrierDesignatorCodeList(OptionalUtil.getValue(codeShare.getLinkCXR()).trim()))) {
			throw new BusinessException("Invalid Link CXR " + OptionalUtil.getValue(codeShare.getLinkCXR()));
		}

		if (OptionalUtil.isPresent(codeShare.getMarketedRBDList()) && !OptionalUtil.isPresent(codeShare.getOperatedRBDList())) {
			throw new BusinessException("Operated RBD list is mandatory when Marketed RBD list is specified");
		}

		// validation for operatedRBDList
		if (OptionalUtil.isPresent(codeShare.getOperatedRBDList()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getOperatedRBDList()).trim())) {
			String[] operatedRBDList = OptionalUtil.getValue(codeShare.getOperatedRBDList()).split("/");
			for (int i = 0; operatedRBDList.length > i; i++) {
				if (!globalMasterFeignClient.getFBTDElementByElementCodeBasedOnPrimeCode(operatedRBDList[i], "5")) {
					throw new BusinessException(
							"Operated RBD List " +operatedRBDList[i]+ " is not present in FBTD Element Master");
				}
			}
		}

		// operating cxr and link cxr one it should be there
		if ((!OptionalUtil.isPresent(codeShare.getOperatingCXR()) && !OptionalUtil.isPresent(codeShare.getLinkCXR())) ||
			(StringUtils.isEmpty(OptionalUtil.getValue(codeShare.getOperatingCXR())) && StringUtils.isEmpty(OptionalUtil.getValue(codeShare.getLinkCXR())))) {
			throw new BusinessException("Either Operating Carrier or Link Carrier is mandatory");
		}

		// validation for marketedRBDList
		if (OptionalUtil.isPresent(codeShare.getMarketedRBDList()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getMarketedRBDList()).trim())) {
			String[] marketedRBDList = OptionalUtil.getValue(codeShare.getMarketedRBDList()).split("/");
			for (int i = 0; marketedRBDList.length > i; i++) {
				if (!globalMasterFeignClient.getFBTDElementByElementCodeBasedOnPrimeCode(marketedRBDList[i], "5")) {
					throw new BusinessException(
							"Marketed RBD List " +marketedRBDList[i]+ " is not present in FBTD Element Master");
				}
			}
		}

	}

	private void commonValidation(CodeShare codeShare) {
		
		Pattern fromBooked = Pattern.compile(FLIGHTNUMBERPATTERN);
		Pattern toBooked = Pattern.compile(FLIGHTNUMBERPATTERN);
		Pattern fromOperation = Pattern.compile(FLIGHTNUMBERPATTERN);
		Pattern toOperating = Pattern.compile(FLIGHTNUMBERPATTERN);
		if (StringUtils.isNotBlank(OptionalUtil.getValue(codeShare.getFromBookedFlightNumber())) 
				&& !fromBooked.matcher(OptionalUtil.getValue(codeShare.getFromBookedFlightNumber())).matches()) {
			throw new BusinessException(INCORRECT_FIELD + OptionalUtil.getValue(codeShare.getFromBookedFlightNumber()));
		}
		if (StringUtils.isNotBlank(OptionalUtil.getValue(codeShare.getToBookedFlightNumber())) 
				&& !toBooked.matcher(OptionalUtil.getValue(codeShare.getToBookedFlightNumber())).matches()) {
			throw new BusinessException(INCORRECT_FIELD + OptionalUtil.getValue(codeShare.getToBookedFlightNumber()));
		}
		if (StringUtils.isNotBlank(OptionalUtil.getValue(codeShare.getFromOperatingFlightNumber())) 
				&& !fromOperation.matcher(OptionalUtil.getValue(codeShare.getFromOperatingFlightNumber())).matches()) {
			throw new BusinessException(INCORRECT_FIELD + OptionalUtil.getValue(codeShare.getFromOperatingFlightNumber()));
		}
		if (StringUtils.isNotBlank(OptionalUtil.getValue(codeShare.getToOperatingFlightNumber())) 
				&& !toOperating.matcher(OptionalUtil.getValue(codeShare.getToOperatingFlightNumber())).matches()) {
			throw new BusinessException(INCORRECT_FIELD + OptionalUtil.getValue(codeShare.getToOperatingFlightNumber()));
		}

		// if areaFBW is blank then FromArea and ToArea should be blank
		if (!OptionalUtil.isPresent(codeShare.getAreaFBWIndicator()) || OptionalUtil.getValue(codeShare.getAreaFBWIndicator()) == null || StringUtils.isEmpty(OptionalUtil.getValue(codeShare.getAreaFBWIndicator()))) {
			if (OptionalUtil.isPresent(codeShare.getFromArea()) || OptionalUtil.isPresent(codeShare.getToArea()) ||
				StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea())) ||  StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea()))) {
				throw new BusinessException(
						"If FBW indicator is blank, then Area from and Area to also needs to be blank");
			}
		}

		// areaFBW Indicator
		if (OptionalUtil.isPresent(codeShare.getAreaFBWIndicator())
				&& (OptionalUtil.getValue(codeShare.getAreaFBWIndicator()).trim().equals("F")
						|| OptionalUtil.getValue(codeShare.getAreaFBWIndicator()).trim().equals("B"))) {

			if (!OptionalUtil.isPresent(codeShare.getToArea()) || OptionalUtil.getValue(codeShare.getToArea()) == null || StringUtils.isEmpty(OptionalUtil.getValue(codeShare.getToArea()).trim()) 
				|| !OptionalUtil.isPresent(codeShare.getFromArea()) || OptionalUtil.getValue(codeShare.getFromArea()) == null || StringUtils.isEmpty(OptionalUtil.getValue(codeShare.getFromArea()).trim())) {
				throw new BusinessException("For Area FBW Indicator F & B, To Area and From Area are mandatory");
			}
		}

		// validation for BookedFlightNumber
		if (OptionalUtil.isPresent(codeShare.getToBookedFlightNumber()) && !OptionalUtil.isPresent(codeShare.getFromBookedFlightNumber())) {
			throw new BusinessException("Please provide From Booked Flight Number");
		}
		if (OptionalUtil.isPresent(codeShare.getFromBookedFlightNumber()) && !OptionalUtil.isPresent(codeShare.getToBookedFlightNumber())) {
			throw new BusinessException("Please provide To Booked Flight Number");
		}

		// validation for fromBookedFlightNumber & toBookedFlightNumber
		if (OptionalUtil.isPresent(codeShare.getFromBookedFlightNumber()) && OptionalUtil.isPresent(codeShare.getToBookedFlightNumber())) {
			if (!(Integer.parseInt(OptionalUtil.getValue(codeShare.getFromBookedFlightNumber())) < 
					Integer.parseInt(OptionalUtil.getValue(codeShare.getToBookedFlightNumber())))) {
				throw new BusinessException(RANGEBOOKEDFLIGHTNUMBER);
			}
		}
		
		// validation for OperatingFlightNumber
		if (OptionalUtil.isPresent(codeShare.getFromOperatingFlightNumber()) && !OptionalUtil.isPresent(codeShare.getToOperatingFlightNumber())) {
				throw new BusinessException("Please provide To Operating Flight number");
		}

		if (OptionalUtil.isPresent(codeShare.getToOperatingFlightNumber()) && !OptionalUtil.isPresent(codeShare.getFromOperatingFlightNumber())) {
				throw new BusinessException("Please provide From Operating Flight number");
		}

		// validation for fromOperatingFlightNumber & toOperatingFlightNumber
		if (OptionalUtil.isPresent(codeShare.getFromOperatingFlightNumber()) && OptionalUtil.isPresent(codeShare.getToOperatingFlightNumber())) {
			if (!(Integer.parseInt(OptionalUtil.getValue(codeShare.getFromOperatingFlightNumber())) < 
					Integer.parseInt(OptionalUtil.getValue(codeShare.getToOperatingFlightNumber())))) {
				throw new BusinessException(RANGEOPERATINGFLIGHTNUMBER);
			}
		}
		
		if (OptionalUtil.isPresent(codeShare.getFromBookedFlightNumber()) && OptionalUtil.isPresent(codeShare.getToBookedFlightNumber()) &&
			!OptionalUtil.isPresent(codeShare.getFromOperatingFlightNumber()) && !OptionalUtil.isPresent(codeShare.getToOperatingFlightNumber())) {
			throw new BusinessException("Operating Flight Number is mandatory when Marketed Flight Number is specified");
	    }
		
		if (!OptionalUtil.isPresent(codeShare.getFromBookedFlightNumber()) && !OptionalUtil.isPresent(codeShare.getToBookedFlightNumber()) &&
			OptionalUtil.isPresent(codeShare.getFromOperatingFlightNumber()) && OptionalUtil.isPresent(codeShare.getToOperatingFlightNumber())) {
				throw new BusinessException("Marketed Flight Number is mandatory when Operating Flight Number is specified");
		 }
		
		if (OptionalUtil.isPresent(codeShare.getFromBookedFlightNumber()) && OptionalUtil.isPresent(codeShare.getToBookedFlightNumber())
			&& OptionalUtil.isPresent(codeShare.getFromOperatingFlightNumber()) && OptionalUtil.isPresent(codeShare.getToOperatingFlightNumber())) {
			int bookedFlightDifference = Integer.parseInt(OptionalUtil.getValue(codeShare.getToBookedFlightNumber())) - 
					Integer.parseInt(OptionalUtil.getValue(codeShare.getFromBookedFlightNumber()));
			int operatingFlightDifference = Integer.parseInt(OptionalUtil.getValue(codeShare.getToOperatingFlightNumber())) - 
					Integer.parseInt(OptionalUtil.getValue(codeShare.getFromOperatingFlightNumber()));
			if (bookedFlightDifference != operatingFlightDifference) {
				throw new BusinessException(FLIGHTRANGEDIFFERENCE);
			}
		}

		// validation overlapping for carrier with fromBookedFlightNumber and
		// toBookedFlightNumber
		/*
		 * if (OptionalUtil.isPresent(codeShare.getFromBookedFlightNumber()) &&
		 * OptionalUtil.isPresent(codeShare.getToBookedFlightNumber())) { long k =
		 * codeShareDao.overlappingCXRWithFlightNumber(OptionalUtil.getValue(codeShare.
		 * getMarketingCXR()),
		 * OptionalUtil.getValue(codeShare.getFromBookedFlightNumber()),
		 * OptionalUtil.getValue(codeShare.getToBookedFlightNumber()),
		 * LocalDate.parse(OptionalUtil.getValue(codeShare.getSaleFromDate())),
		 * LocalDate.parse(OptionalUtil.getValue(codeShare.getSaleToDate())),
		 * LocalDate.parse(OptionalUtil.getValue(codeShare.getTravelFromDate())),
		 * LocalDate.parse(OptionalUtil.getValue(codeShare.getTravelToDate())),
		 * OptionalUtil.getValue(codeShare.getClientId())); if (k > 0) {
		 * 
		 * throw new BusinessException( "Flight number " +
		 * OptionalUtil.getValue(codeShare.getFromBookedFlightNumber()) +
		 * " and Sales Date " +
		 * OptionalUtil.getLocalDateValue(codeShare.getSaleFromDate()) +
		 * " and Travel Dates " +
		 * OptionalUtil.getLocalDateValue(codeShare.getTravelFromDate()) +
		 * " are overlapping with current marketing carrier " +
		 * OptionalUtil.getValue(codeShare.getMarketingCXR()) +
		 * OptionalUtil.getValue(codeShare.getMarketingCXR())); } }
		 */
		// overlapping changes

		// validate the carrier code
		if (!OptionalUtil.isPresent(codeShare.getLinkCXR())) {
			if (OptionalUtil.isPresent(codeShare.getMarketingCXR()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getMarketingCXR()).trim()) && (!globalMasterFeignClient
					.isValidCarrierDesignatorCodeList(OptionalUtil.getValue(codeShare.getMarketingCXR()).trim()))) {
				throw new BusinessException(
						"Invalid Marketing CXR " + OptionalUtil.getValue(codeShare.getMarketingCXR()));
			}
		}
		if (OptionalUtil.isPresent(codeShare.getClientId()) && (!globalMasterFeignClient
				.isValidCarrierDesignatorCodeList(OptionalUtil.getValue(codeShare.getClientId())))) {
			throw new BusinessException("Invalid client ID " + OptionalUtil.getValue(codeShare.getClientId()));
		}

		// validate MarketingCXR and OperatingCXR should not be same
		if (OptionalUtil.isPresent(codeShare.getMarketingCXR()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getMarketingCXR()).trim()) && 
			OptionalUtil.isPresent(codeShare.getOperatingCXR()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getOperatingCXR()).trim())
			&& codeShare.getMarketingCXR().equals(codeShare.getOperatingCXR())) {
			throw new BusinessException("Marketing and Operating Carrier cannot be same");
		}

		if (!OptionalUtil.isPresent(codeShare.getMarketedRBDList()) && OptionalUtil.isPresent(codeShare.getOperatedRBDList()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getOperatedRBDList()).trim())) {
			throw new BusinessException("Marketed RBD list is mandatory when Operated RBD list is specified");
		}

		// validation for Marketed RBD list and Operated RBD list must be same length
		if (OptionalUtil.isPresent(codeShare.getMarketedRBDList()) && OptionalUtil.isPresent(codeShare.getOperatedRBDList())
			&& StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getMarketedRBDList()).trim()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getOperatedRBDList()).trim())) {

			String[] marketedRBDList = OptionalUtil.getValue(codeShare.getMarketedRBDList()).split("/");
			String[] operatedRBDList = OptionalUtil.getValue(codeShare.getOperatedRBDList()).split("/");

			if (marketedRBDList.length != operatedRBDList.length) {
				throw new BusinessException(
						"Number of Marketed RBD specified, should match with number of Operated RBD");
			}
		}

		// should not allowed duplicate in Marketing RBD list
		marketedRBDList(codeShare);

		// 1st validation for travel DOW
		if (OptionalUtil.isPresent(codeShare.getTravelDOW()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getTravelDOW()).trim())) {
			String tdow = OptionalUtil.getValue(codeShare.getTravelDOW());
			// 2nd validation for travel DOW
			if (tdow.length() != 7) {
				throw new BusinessException(
						"Travel DOW length should be 7 characters only");
			}

			for (int i = 0; i < tdow.length() - 1; i++) {
				if (!((tdow.charAt(i) == 'Y') || (tdow.charAt(i) == 'N'))) {
					throw new BusinessException(TRAVELWODVALIDATIONMSG);
				}
			}
		}

		// AREAFBWINDICATOR validation
		if (OptionalUtil.isPresent(codeShare.getAreaFBWIndicator()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getAreaFBWIndicator()).trim())) {
			if (!(OptionalUtil.getValue(codeShare.getAreaFBWIndicator()).trim().equalsIgnoreCase("F")
					|| OptionalUtil.getValue(codeShare.getAreaFBWIndicator()).trim().equalsIgnoreCase("B")
					|| OptionalUtil.getValue(codeShare.getAreaFBWIndicator()).trim().equalsIgnoreCase("W"))) {
				throw new BusinessException(AREAFBWINDICATOR);
			}
			if (OptionalUtil.getValue(codeShare.getAreaFBWIndicator()).trim().equalsIgnoreCase("W")) {
				if (!OptionalUtil.isPresent(codeShare.getFromArea()) || StringUtils.isEmpty(OptionalUtil.getValue(codeShare.getFromArea()).trim())) {
					throw new BusinessException(AREAFBINDICATOR);
				}
				if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea()).trim())) {
					throw new BusinessException(AREAFBINDICATOR);
				}
			}

		}

		// AREAFBWINDICATOR validation againt LOV table
		if (OptionalUtil.isPresent(codeShare.getAreaFBWIndicator()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getAreaFBWIndicator()).trim())) {
			String clientId1 = OptionalUtil.getValue(codeShare.getClientId());
			
			List<String> elementTypelist1 = lovService.getListOfValues(Optional.of(clientId1), Optional.of(LOVEnum.TABLENAME.getLOVEnum()), 
					Optional.of(LOVEnum.FBW.getLOVEnum()));
			boolean flag1 = false;
			for (String elementTypestr1 : elementTypelist1) {
				if (elementTypestr1.equals(OptionalUtil.getValue(codeShare.getAreaFBWIndicator()))) {
					flag1 = true;
				}
			}
			if (!flag1) {
				throw new BusinessException(
						"Invalid Area FBW Indicator " + OptionalUtil.getValue(codeShare.getAreaFBWIndicator()));
			}
		}

		// validation for fromArea and ToArea
		if (OptionalUtil.isPresent(codeShare.getFromArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getFromArea()))) {
			String[] fromAreaArray = OptionalUtil.getValue(codeShare.getFromArea()).split("");
			if (!(fromAreaArray[0].startsWith("1") || fromAreaArray[0].startsWith("2")
					|| fromAreaArray[0].startsWith("3") || fromAreaArray[0].startsWith("4")
					|| fromAreaArray[0].startsWith("5"))) {
				throw new BusinessException(INVALIDFROMAREA + fromAreaArray[0]);
			}
			if (OptionalUtil.isPresent(codeShare.getToArea()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getToArea()))) {
				String[] toAreaArray = OptionalUtil.getValue(codeShare.getToArea()).split("");
				if (!(toAreaArray[0].startsWith("1") || toAreaArray[0].startsWith("2") || toAreaArray[0].startsWith("3")
						|| toAreaArray[0].startsWith("4") || toAreaArray[0].startsWith("5"))) {
					throw new BusinessException(INVALIDTOAREA + toAreaArray[0]);
				}
			}
		}
	}

	@Override
	public void deactivateCodeShare(Integer codeShareId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		Optional<CodeShareEntity> codeShareEntity = codeShareDao.findById(codeShareId);

		if (!codeShareEntity.isPresent())
			throw new ResourceNotFoundException(CODESHARE, "code", codeShareId);

		if (!codeShareEntity.get().getIsActive())
			throw new BusinessException(CODESHAREALREADYINACTIVE);
		codeShareEntity.get().setIsActive(Boolean.FALSE);
		codeShareEntity.get().setLastUpdatedBy(lastUpdatedBy);
		codeShareEntity.get().setLastUpdatedDate(LocalDateTime.now());
		codeShareDao.update(codeShareEntity.get());

	}

	@Override
	public void activateCodeShare(Integer codeShareId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		Optional<CodeShareEntity> codeShareEntity = codeShareDao.findById(codeShareId);

		if (!codeShareEntity.isPresent())
			throw new ResourceNotFoundException(CODESHARE, "code", codeShareId);
		if (codeShareEntity.get().getIsActive())
			throw new BusinessException(CODESHAREALREADYACTIVE);
		codeShareEntity.get().setIsActive(Boolean.TRUE);
		codeShareEntity.get().setLastUpdatedBy(lastUpdatedBy);
		codeShareEntity.get().setLastUpdatedDate(LocalDateTime.now());
		codeShareDao.update(codeShareEntity.get());

	}

	public void validateAllDate(CodeShare codeShare) {
		
		boolean travelDateCheck = LocalDate.parse(OptionalUtil.getValue(codeShare.getTravelToDate()))
				.isAfter(LocalDate.parse(OptionalUtil.getValue(codeShare.getTravelFromDate())));

		if (!travelDateCheck) {
			throw new BusinessException("Travel To Date " + OptionalUtil.getLocalDateValue(codeShare.getTravelToDate())
					+ " should be greater than Travel From date "
					+ OptionalUtil.getLocalDateValue(codeShare.getTravelFromDate()));
		}
		validateTravelDate(codeShare);
		
		if (OptionalUtil.isPresent(codeShare.getSaleFromDate()) && OptionalUtil.isPresent(codeShare.getSaleToDate()) &&
			OptionalUtil.getValue(codeShare.getSaleFromDate()) != null && OptionalUtil.getValue(codeShare.getSaleToDate()) != null &&
			!StringUtils.isEmpty(OptionalUtil.getValue(codeShare.getSaleFromDate())) && !StringUtils.isEmpty(OptionalUtil.getValue(codeShare.getSaleToDate()))) {
			boolean saleDateCheck = LocalDate.parse(OptionalUtil.getValue(codeShare.getSaleToDate()))
					.isAfter(LocalDate.parse(OptionalUtil.getValue(codeShare.getSaleFromDate())));

			if (!saleDateCheck) {
				throw new BusinessException("Sale To Date " + OptionalUtil.getLocalDateValue(codeShare.getSaleToDate())
						+ " should be greater than Sale From date "
						+ OptionalUtil.getLocalDateValue(codeShare.getSaleFromDate()));
			}
			validateSaleDate(codeShare);
			validateTravelDateGreaterThanEqual(codeShare);
		}
	}

	private void validateTravelDateGreaterThanEqual(CodeShare codeShare) {

		DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();

		int valid = dateTimeComparator.compare(OptionalUtil.getValue(codeShare.getTravelFromDate()), OptionalUtil.getValue(codeShare.getSaleFromDate()));

		if (valid < 0) {
			throw new BusinessException("Travel Effective from "+OptionalUtil.getLocalDateValue(codeShare.getTravelFromDate())+" should be greater than Sale effective From "+OptionalUtil.getLocalDateValue(codeShare.getSaleFromDate()));
		} 

	}
	
	public void validateSaleDate(CodeShare codeShare) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		String currentDateStr = sdf.format(new Date());
		if (OptionalUtil.isPresent(codeShare.getSaleFromDate())  && OptionalUtil.isPresent(codeShare.getSaleToDate())) {
			//String saleToDateStr = sdf.format(codeShare.getSaleToDate());
			String saleToDateStr = OptionalUtil.getValue(codeShare.getSaleToDate());
			Date currentDate = null;
			Date saleToDate = null;
			try {
				currentDate = sdf.parse(currentDateStr);
				saleToDate = sdf.parse(saleToDateStr);
			} catch (ParseException e) {

				e.printStackTrace();
			}

			DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();

			int valid = dateTimeComparator.compare(saleToDate, currentDate);

			if (valid < 0) {
				throw new BusinessException("Sale To date " + OptionalUtil.getLocalDateValue(codeShare.getSaleToDate())
						+ " should be greater than or equal to the Current date " + currentDate);
			}
		}
	}

	public void validateTravelDate(CodeShare codeShare) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		String currentDateStr = sdf.format(new Date());

		//String travelToDateStr = sdf.format(codeShare.getTravelToDate());
		String travelToDateStr = OptionalUtil.getValue(codeShare.getTravelToDate());

		Date currentDate = null;
		Date travelToDate = null;
		try {
			currentDate = sdf.parse(currentDateStr);
			travelToDate = sdf.parse(travelToDateStr);
		} catch (ParseException e) {

			e.printStackTrace();
		}

		DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();

		int valid = dateTimeComparator.compare(travelToDate, currentDate);

		if (valid < 0) {
			throw new BusinessException("Travel To date " + OptionalUtil.getLocalDateValue(codeShare.getTravelToDate())
					+ " should be greater than or equal to the Current date " + currentDate);
		}

	}

	public void marketedRBDList(CodeShare codeShare) {
		if (OptionalUtil.isPresent(codeShare.getMarketedRBDList()) && StringUtils.isNotEmpty(OptionalUtil.getValue(codeShare.getMarketedRBDList()))) {
			String marketedList = OptionalUtil.getValue(codeShare.getMarketedRBDList());
			String[] str1 = marketedList.split("/");
			List<String> list = Arrays.asList(marketedList.split("/"));
			for (int i = 0; i < str1.length; i++) {
				if (list.stream().distinct().collect(Collectors.toList()).size() < list.size()) {
					throw new BusinessException("Marketed RBD List cannot be repeated");
				}
			}
		}
	}

	List<String> typeValueList = new ArrayList<>();

	private StringBuilder userGeoList(List<Geo> l, StringBuilder geoString, boolean flag) {

		for (Geo geo : l) {

			if (geo.getGeoTypeId() == null)
				throw new BusinessException("GeoTypeId should be 1,2,3 or 5 ");
			if (geo.getGeoTypeId() == 1 || geo.getGeoTypeId() == 2 || geo.getGeoTypeId() == 3
					|| geo.getGeoTypeId() == 5) {

				if (geo.getGeoTypeId() == 1
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"Value Length: For Geo Type Value Element length should be 3 characters only - Airport");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(
								"This field Geo Type Value " + geo.getGeoTypeValue() + " cannot be blank");
					}
					if (!globalMasterFeignClient.isValidAirportCodeOrCityCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Invalid Airport Code " + geo.getGeoTypeValue());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 2
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 2) {
							typeValueList.clear();
							throw new BusinessException(
									"Value Length: For Geo Type Value Element length should be 2 characters only - Country");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(
								"This field Geo Type Value " + geo.getGeoTypeValue() + " cannot be blank");
					}
					try {
						globalMasterFeignClient.getCountryByCountryCode(geo.getGeoTypeValue().toUpperCase());
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException("Invalid Country Code " + geo.getGeoTypeValue());
					} catch (BusinessException se) {
						typeValueList.clear();
						throw new BusinessException("Invalid Country Code " + geo.getGeoTypeValue());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 3
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (flag) {
						typeValueList.clear();
						throw new BusinessException("Geo Type Id 3 is not applicable for excludeGeoList");
					}
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"Value Length: For Geo Type Value Element length should be 3 characters only - Standard Area");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(
								"This field Geo Type Value " + geo.getGeoTypeValue() + " cannot be blank");
					}
					try {
					if(!globalMasterFeignClient.getActiveStandardAreaByStandardAreaCode(geo.getGeoTypeValue().toUpperCase())){
						typeValueList.clear();
						throw new BusinessException("Invalid Standard Area Code " + geo.getGeoTypeValue());
					  }
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException("Invalid Standard Area Code " + geo.getGeoTypeValue());
					} catch (BusinessException se) {
						typeValueList.clear();
						throw new BusinessException("Invalid Standard Area Code " + geo.getGeoTypeValue());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 5
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 4) {
							typeValueList.clear();
							throw new BusinessException(
									"Value Length: For Geo Type Value Element length should be 4 Characters only - State");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(
								"This field Geo Type Value " + geo.getGeoTypeValue() + " cannot be blank");
					}
					if (!globalMasterFeignClient.isValidStateCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Invalid State Code " + geo.getGeoTypeValue());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					typeValueList.clear();
					throw new BusinessException("Include Area List and Exclude Area List cannot be same");
				}

			} else {
				typeValueList.clear();
				throw new BusinessException("Invalid Geo type id " + geo.getGeoTypeId());
			}

		} // enf of for loop
		if (geoString.length() > 1000) {
			typeValueList.clear();
			throw new BusinessException(
					"Area Include List or Area Exclude List length must be less than 1000 charecters");
		}
		if (geoString.length() != 0) {
			geoString.delete(geoString.length() - 1, geoString.length());
		}
		return geoString;

	}

	public String[] validateArea(String geoArea, List<Geo> areaIncludeList, List<Geo> areaExcludeList,
			String userAreaName, String area , String areaName) {

		String[] array = new String[2];
		String areaInclude = "";
		String areaExclude = "";
		if (geoArea.startsWith("1") || geoArea.startsWith("2") || geoArea.startsWith("3") || geoArea.startsWith("5")) {
			if (areaIncludeList != null || areaExcludeList != null || userAreaName != null || StringUtils.isNotEmpty(userAreaName)) {
				throw new BusinessException("For " + geoArea
						+ "IncludeArea, ExcludeArea and userAreaName not required for non User Defined Area");
			}
		}

		if (geoArea != null) {
			if (geoArea.startsWith("1")) {
				if (!Pattern.compile(PATTERN).matcher(geoArea.substring(1, geoArea.length())).find()) {
					throw new BusinessException("Only alphabets allowed for Airport Code");
				} else {
					if (!globalMasterFeignClient.isValidAirportCodeOrCityCode(geoArea.substring(1, geoArea.length()))) {
						throw new BusinessException("Invalid Airport Code " + geoArea.substring(1, geoArea.length()));
					}
				}
			} else if (geoArea.startsWith("2")) {
				if (!Pattern.compile(PATTERN).matcher(geoArea.substring(1, geoArea.length())).find()) {
					throw new BusinessException("Only alphabets allowed for Country Code");
				} else {
					if (!globalMasterFeignClient.validateCountryCode(geoArea.substring(1, geoArea.length()))) {
						throw new BusinessException("Invalid Counrty Code " + geoArea.substring(1, geoArea.length()));
					}
				}
			} else if (geoArea.startsWith("3")) {
				if (!globalMasterFeignClient
						.getActiveStandardAreaByStandardAreaCode(geoArea.substring(1, geoArea.length()))) {
					throw new BusinessException("Invalid Standard Area Code " + geoArea.substring(1, geoArea.length()));
				}
			} else if (geoArea.startsWith("4") && area.equals(GLOBAL)) {
				boolean flag = false;
				List<Geo> geoFromAreaInclude = areaIncludeList;
				if (areaIncludeList != null && !areaIncludeList.isEmpty()) {

					if (userAreaName == null) {
						throw new BusinessException("User Area Name " + userAreaName + " cannot be blank");
					}

					StringBuilder geoString = new StringBuilder();
					StringBuilder strareaIncludeList = userGeoList(geoFromAreaInclude, geoString, flag);
					areaInclude = strareaIncludeList.toString();
					if (areaExcludeList != null) {
						List<Geo> geoFromAreaExclude = areaExcludeList;
						StringBuilder geoString1 = new StringBuilder();
						flag = true;
						StringBuilder strAreaExcludeList = userGeoList(geoFromAreaExclude, geoString1, flag);

						areaExclude = strAreaExcludeList.toString();
					}
					array[0] = areaInclude;
					array[1] = areaExclude;

				} else {
					throw new BusinessException(areaName+ "include " + areaIncludeList + " cannot be blank");
				}
			} else if (geoArea.startsWith("4") && area.equals(CLIENT)) {
				boolean flag = false;
				List<Geo> geoFromAreaInclude = areaIncludeList;
				if (areaIncludeList != null && !areaIncludeList.isEmpty()) {

					if (userAreaName == null) {
						throw new BusinessException("User Area Name " + userAreaName + " cannot be blank");
					}

					StringBuilder geoString = new StringBuilder();
					StringBuilder strareaIncludeList = userGeoList(geoFromAreaInclude, geoString, flag);
					areaInclude = strareaIncludeList.toString();
					if (areaExcludeList != null) {
						List<Geo> geoFromAreaExclude = areaExcludeList;
						StringBuilder geoString1 = new StringBuilder();
						flag = true;
						StringBuilder strAreaExcludeList = userGeoList(geoFromAreaExclude, geoString1, flag);

						areaExclude = strAreaExcludeList.toString();
					}
					array[0] = areaInclude;
					array[1] = areaExclude;

				} else {
					throw new BusinessException(areaName+ " include " + areaIncludeList + " cannot be blank");
				}
			} else if (geoArea.startsWith("5")) {
				if (!Pattern.compile(PATTERN).matcher(geoArea.substring(1, geoArea.length())).find()) {
					throw new BusinessException("Only alphabets allowed for State Code");
				} else {
					if (!globalMasterFeignClient.isValidStateCode(geoArea.substring(1, geoArea.length()))) {
						throw new BusinessException("Invalid State Code " + geoArea.substring(1, geoArea.length()));
					}
				}
			}
		}
		return array;
	}

	public LocalDate convertLocalDate(Date date) {
		if (date != null) {
			return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		} else {
			return null;
		}
	}

	@Override
	public List<CodeShare> getCodeSharePopulateData(String marketingCXR, Date effectiveDateObject, Date saleDateObject,
			String clientId, String flightNumber) {
		List<CodeShare> listCodeShare = null;
		//Integer flightNumber = Integer.parseInt(strFlightNumber);
		if (marketingCXR != null && effectiveDateObject != null && saleDateObject != null && clientId != null
				&& flightNumber != null) {
			listCodeShare = codeSharemapper.mapToModel(codeShareRepository.getCodeSharePopulateData(marketingCXR,
					convertLocalDate(effectiveDateObject), convertLocalDate(saleDateObject), clientId, flightNumber));
		} else if (marketingCXR != null && effectiveDateObject != null && clientId != null && flightNumber != null) {
			listCodeShare = codeSharemapper.mapToModel(codeShareRepository.getCodeSharePopulateDataWithoutSaleDate(
					marketingCXR, convertLocalDate(effectiveDateObject), clientId, flightNumber));
		} else if (marketingCXR != null && saleDateObject != null && clientId != null && flightNumber != null) {
			listCodeShare = codeSharemapper.mapToModel(codeShareRepository.getCodeSharePopulateDataWithoutIssueDate(
					marketingCXR, convertLocalDate(saleDateObject), clientId, flightNumber));
		}
		return listCodeShare;
	}

	@Override
	public CodeShare getCodeShareByClientAndMarketingCXRAndMarketedRBDAndEffectiveDateSales(String clientIdStr,
			String marketingCXRStr, String marketedRBDListStr, String effectiveDateStr,
			String flightNumberStr) {
		Optional<String> clientId = Optional.of(clientIdStr);
		Optional<String> marketingCXR = Optional.of(marketingCXRStr);
		Optional<String> marketedRBDList = Optional.of(marketedRBDListStr);
		Optional<String> effectiveDate = Optional.of(effectiveDateStr);
		Optional<String> flightNumber = Optional.of(flightNumberStr);
		return codeSharemapper.mapToModel(codeShareDao.getCodeShareBymarketingCXRForBSP(clientId, marketingCXR, marketedRBDList, effectiveDate,flightNumber)
				.orElseThrow(() -> new BusinessException("Record Not Found")));
	}

	@Override
	public CodeShare getCodeShareForValidation(String clientId, String operatingflightNumber, Date travelDate,
			String operatingCXR, String marketingflightNumber, Date saleDate, String marketingCXR) {
		CodeShare codeShare = null;
		codeShare = codeSharemapper.mapToModel(codeShareRepository.getCodeShareForValidation(clientId,
				operatingflightNumber, SmartPRACommonUtil.convertToLocalDate(travelDate), operatingCXR, 
				marketingflightNumber, SmartPRACommonUtil.convertToLocalDate(saleDate), marketingCXR));
		if (codeShare != null && !codeShare.getIsActive()) {
			throw new BusinessException("record is not active with parameter clientId : " + clientId
					+ ", operatingflightNumber : " + operatingflightNumber + ", travelDate : " + travelDate
					+ ", operatingCXR : " + operatingCXR + ", marketingflightNumber : " + marketingflightNumber
					+ ", saleDate : " + saleDate + ", marketingCXR : " + marketingCXR);
		} else {
			return codeShare;
		}
	}

	@Override
	public CodeShare getCodeShareByCodeShareId(Integer codeShareId) {
		return codeSharemapper.mapToModel(
				codeShareDao.findByCodeShareId(codeShareId).orElseThrow(() -> new RecordNotFoundException(String.valueOf(codeShareId))));
	}
}
