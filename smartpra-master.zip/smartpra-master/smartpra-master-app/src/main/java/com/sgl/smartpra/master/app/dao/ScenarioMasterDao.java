package com.sgl.smartpra.master.app.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.MasScenarioEntity;

@Repository
public interface ScenarioMasterDao {

	List<MasScenarioEntity> findAll();

	List<MasScenarioEntity> findByScenarioMaster(MasScenarioEntity scenarioMaster);

}
