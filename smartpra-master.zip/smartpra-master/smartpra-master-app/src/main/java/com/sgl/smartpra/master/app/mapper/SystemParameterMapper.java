package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.SystemParameterEntity;
import com.sgl.smartpra.master.model.SystemParameter;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SystemParameterMapper extends BaseMapper<SystemParameter, SystemParameterEntity>{

	SystemParameterEntity mapToEntity(SystemParameter systemParameter, @MappingTarget SystemParameterEntity systemParameterEntity);
	SystemParameterEntity mapToEntity(SystemParameter systemParameter);
}