package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.FlightControl;

public interface FlightControlService {
	public List<FlightControl> getListOfFlightControl(String clientId, String flightControlId, Boolean isActive,
			Optional<String> exceptionCall);
	
	List<FlightControl> getFlightControls(String clientId);

	public FlightControl getFlightControlByFlightControlAutoId(Integer flightControlAutoId);

	public FlightControl createFlightControl(FlightControl flightControl);

	public FlightControl updateFlightControl(Integer flightControlAutoId, FlightControl flightControl);

	public void deactivateFlightControl(Integer flightControlAutoId, String lastUpdatedBy);

	public void activateFlightControl(Integer flightControlAutoId, String lastUpdatedBy);
}
