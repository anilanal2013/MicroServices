package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.master.app.dao.StockAllocationDao;
import com.sgl.smartpra.master.app.dao.entity.StockAllocationEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.StockAllocationEntitySpec;
import com.sgl.smartpra.master.app.dao.repository.StockAllocationRepository;

@Component
@Transactional(rollbackFor = DataAccessException.class)
public class StockAllocationDaoImpl implements StockAllocationDao {

	@Autowired
	private StockAllocationRepository stockAllocationRepository;

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@Cacheable(value = "stockAllocation", key = "#stockAllocationId")
	public Optional<StockAllocationEntity> findByStockAllocationId(Integer stockAllocationId) {
		return stockAllocationRepository.findById(stockAllocationId);
	}

	@Override
	public List<StockAllocationEntity> search(Integer stockId, Optional<String> documentSeriesFrom,
			Optional<String> documentSeriesTo, Optional<String> documentType, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate) {
		return stockAllocationRepository.findAll(StockAllocationEntitySpec.searchAll(stockId, documentSeriesFrom,
				documentSeriesTo, documentType, effectiveFromDate, effectiveToDate));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "stockAllocation", key = "#stockAllocation.stockAllocationId") })
	public StockAllocationEntity create(StockAllocationEntity stockAllocation) {
		return stockAllocationRepository.save(stockAllocation);
	}

	@Override
	@CachePut(value = "stockAllocation", key = "#stockAllocationEntity.stockAllocationId")
	public StockAllocationEntity update(StockAllocationEntity stockAllocationEntity) {
		return stockAllocationRepository.save(stockAllocationEntity);
	}

	@Override
	public long getOverLapRecordCount(Optional<String> clientId, Integer stockId, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate) {
		return stockAllocationRepository.count(Specification
				.where(StockAllocationEntitySpec.equalsClientId(OptionalUtil.getValue(clientId)))
				.and(StockAllocationEntitySpec.equalsStockId(stockId))

				.and(StockAllocationEntitySpec
						.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate))
						.or(StockAllocationEntitySpec.betweenEffectiveFromAndEffectiveToDate(
								OptionalUtil.getLocalDateValue(effectiveToDate)))));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			Integer stockId, Integer stockAllocationId) {
		return stockAllocationRepository.count(Specification.where(StockAllocationEntitySpec.equalsClientId(clientId))
				.and(StockAllocationEntitySpec.equalsStockId(stockId))

				.and(StockAllocationEntitySpec.notEqualsStockAllocationId(stockAllocationId)
						.and(StockAllocationEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate).or(
								StockAllocationEntitySpec.betweenEffectiveFromAndEffectiveToDate((effectiveToDate))))));
	}

	@Override
	@Transactional(rollbackFor = BusinessException.class)
	public void createAgentStaockDetails(StockAllocationEntity entity, String document) {
		String q = "Update StcokDetails s set s.lastUpdatedDate=:lastUpdatedDate,s.agentCode=:agentCode where s.stockId=:stockId and s.documentNumber=:documentNumber";
		Query query = entityManager.createQuery(q);
		query.setParameter("agentCode", entity.getAgencyCode());
		query.setParameter("lastUpdatedDate", LocalDateTime.now());
		query.setParameter("stockId", entity.getStockId());
		query.setParameter("documentNumber", document);
		query.executeUpdate();
	}

	@Override
	@Transactional(rollbackFor = BusinessException.class)
	public void updateAgencyCodeDetails(StockAllocationEntity entity, String document) {
		String q = "Update StcokDetails s set s.lastUpdatedDate=:lastUpdatedDate,s.agentCode=:agentCode "
				+ "where s.stockId=:stockId and s.documentNumber=:documentNumber and isUtilized = 'N' "
				+ " and (blockListReason is NULL or blockListReason = 'NULL' or blockListReason = '') ";
		Query query = entityManager.createQuery(q);
		query.setParameter("agentCode", null);
		query.setParameter("lastUpdatedDate", LocalDateTime.now());
		query.setParameter("stockId", entity.getStockId());
		query.setParameter("documentNumber", document);
		query.executeUpdate();
	}

	@Override
	@Transactional(rollbackFor = BusinessException.class)
	public void updateStock(Integer stockId) {
		String q = "Update StockEntity s set s.isAllocated=:isAllocated,s.lastUpdatedDate=:lastUpdatedDate where s.stockId=:stockId";
		Query query = entityManager.createQuery(q);
		query.setParameter("isAllocated", true);
		query.setParameter("stockId", stockId);
		query.setParameter("lastUpdatedDate", LocalDateTime.now());
		query.executeUpdate();
	}

	@Override
	public String getLastDocumentToSeries(String clientId, Integer stockId) {
		return stockAllocationRepository.getMaxDocumentToSeries(clientId, stockId);
	}

	@Override
	public StockAllocationEntity getDocSeriesByDate(Optional<String> clientId, Integer stockId, Optional<String> documentFromSeries,
			Optional<String> documentToSeries) {
		return stockAllocationRepository.findOne(Specification
				.where(StockAllocationEntitySpec.equalsClientId(OptionalUtil.getValue(clientId)))
				.and(StockAllocationEntitySpec.equalsStockId(stockId))
				.and(StockAllocationEntitySpec.effectiveToDateGreaterThan())
				.and((StockAllocationEntitySpec.betweenDocumentSeries(OptionalUtil.getValue(documentFromSeries)))
				.or(StockAllocationEntitySpec.betweenDocumentSeries(OptionalUtil.getValue(documentToSeries)))))
				.orElse(new StockAllocationEntity());
	}

}
