package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.exception.ServiceException;
import com.sgl.smartpra.master.app.service.ProrateDiscountService;
import com.sgl.smartpra.master.model.ProrateDiscount;

@RestController
public class ProrateDiscountController {

	@Autowired
	private ProrateDiscountService prorateDiscountService;

	public static final String DATACONSTARINTVIOALATION = "Record already exists";

	@GetMapping("/prorate-discounts")
	public List<ProrateDiscount> getProrateDiscount(

			@RequestParam(value = "discountCode", required = false) String discountCode,
			@RequestParam(value = "discountType", required = false) String discountType,
			@RequestParam(value = "fbGroupCode", required = false) Optional<String> fbGroupCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "cxr", required = false) Optional<String> cxr) {

		return prorateDiscountService.getProrateDiscount(discountCode, discountType, fbGroupCode, effectiveFromDate,
				effectiveToDate, cxr);
	}

	@GetMapping("/prorate-discounts/{prorateDiscountCode}/{effectiveDate}")
	public List<ProrateDiscount> getProrateDiscountByProrateDiscountCodeAndEffectiveDate(
			@PathVariable(value = "prorateDiscountCode") String prorateDiscountCode,
			@PathVariable(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return prorateDiscountService.getProrateDiscountByProrateDiscountCodeAndEffectiveDate(prorateDiscountCode,
				effectiveDate);
	}

	@PostMapping("/prorate-discounts")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProrateDiscount createProrateDiscount(
			@Validated(Create.class) @RequestBody ProrateDiscount prorateDiscount) {

		ProrateDiscount prorateDiscountData = null;
		try {
			prorateDiscountData = prorateDiscountService.createProrateDiscount(prorateDiscount);
		} catch (DataIntegrityViolationException e) {
			throw new ServiceException(DATACONSTARINTVIOALATION);
		}
		return prorateDiscountData;
	}

	@PutMapping("/prorate-discounts/{prorateDiscountId}")
	public ProrateDiscount updateProrateDiscount(@PathVariable(value = "prorateDiscountId") Integer prorateDiscountId,
			@Validated(Update.class) @RequestBody ProrateDiscount prorateDiscount) {

		ProrateDiscount prorateDiscountData = null;
		try {
			prorateDiscountData = prorateDiscountService.updateProrateDiscount(prorateDiscountId, prorateDiscount);
		} catch (DataIntegrityViolationException e) {
			throw new ServiceException(DATACONSTARINTVIOALATION);
		}
		return prorateDiscountData;
	}

	@PutMapping("/prorate-discounts/{prorateDiscountId}/deactivate")
	public void deactivateProrateDiscount(@Valid @PathVariable(value = "prorateDiscountId") Integer prorateDiscountId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		ProrateDiscount prorateDiscount = new ProrateDiscount();
		prorateDiscount.setProrateDiscountId(prorateDiscountId);
		prorateDiscount.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		prorateDiscountService.deactivateProrateDiscount(prorateDiscount);
	}

	@PutMapping("/prorate-discounts/{prorateDiscountId}/activate")
	public void activateProrateDiscount(@Valid @PathVariable(value = "prorateDiscountId") Integer prorateDiscountId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		ProrateDiscount prorateDiscount = new ProrateDiscount();
		prorateDiscount.setProrateDiscountId(prorateDiscountId);
		prorateDiscount.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		prorateDiscountService.activateProrateDiscount(prorateDiscount);
	}

	// called from proration module for testing discount code type mandatory or not
	@GetMapping("/prorate-discounts/discount-type/{prorateDiscountCode}/{effectiveDate}/{discountType}/{clientId}")
	public List<ProrateDiscount> getProrateDiscountByProrateDiscountIdAndEffectiveDateAndType(
			@PathVariable(value = "prorateDiscountCode") String prorateDiscountCode,
			@PathVariable(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate,
			@PathVariable(value = "discountType") String discountType,
			@PathVariable(value = "clientId") String clientId) {
		return prorateDiscountService.getProrateDiscountByProrateDiscountIdAndEffectiveDate(prorateDiscountCode,
				effectiveDate, discountType, clientId);
	}

	@GetMapping("/prorate-discounts/{prorateDiscountId}")
	public ProrateDiscount getProrateDiscountByProrateDiscountId(
			@PathVariable(value = "prorateDiscountId") Integer prorateDiscountId) {
		return prorateDiscountService.getProrateDiscountByProrateDiscountId(prorateDiscountId);
	}
}
