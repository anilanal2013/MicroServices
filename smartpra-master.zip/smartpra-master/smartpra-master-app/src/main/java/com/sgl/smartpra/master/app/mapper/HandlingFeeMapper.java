package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.HandlingFeeEntity;
import com.sgl.smartpra.master.model.HandlingFee;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface HandlingFeeMapper extends BaseMapper<HandlingFee, HandlingFeeEntity> {

	HandlingFeeEntity mapToEntity(HandlingFee handlingFee, @MappingTarget HandlingFeeEntity handlingFeeEntity);

	@Mapping(target = "handlingFeeId", source = "handlingFeeId")
	HandlingFeeEntity mapToEntity(HandlingFee handlingFee);

}
