package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.FOPMappingDao;
import com.sgl.smartpra.master.app.dao.entity.FOPMappingEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.FOPMappingEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.FOPMappingRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FOPMappingDaoImpl implements FOPMappingDao {

	@Autowired
	private FOPMappingRepository fopMappingRepository;

	@Override
	@Cacheable(value = "fopMapping", key = "#id")
	public Optional<FOPMappingEntity> findById(Integer id) {
		log.info("Cacheable FOP Mapping Entity's ID= {}", id);
		return fopMappingRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fopMapping", key = "#fopMappingEntity.fopMapId") })
	public FOPMappingEntity create(FOPMappingEntity fopMappingEntity) {
		return fopMappingRepository.save(fopMappingEntity);
	}

	@Override
	@CachePut(value = "fopMapping", key = "#fopMappingEntity.fopMapId")
	public FOPMappingEntity update(FOPMappingEntity fopMappingEntity) {
		return fopMappingRepository.save(fopMappingEntity);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fopMapping", key = "#id") })
	public void delete(Integer id) {
		fopMappingRepository.deleteById(id);
	}

	@Override
	public long getOverlapRecoedCount(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String source, String stationCode, String fopCode) {
		return fopMappingRepository.count(Specification.where(FOPMappingEntitySpecification.equalsClientId(clientId)
				.and(FOPMappingEntitySpecification.equalsFOPCode(fopCode))
				.and(FOPMappingEntitySpecification.equalsSource(source))
				.and(FOPMappingEntitySpecification.equalsStationCode(stationCode))
				.and(FOPMappingEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(FOPMappingEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))));
	}

	@Override
	public long getOverlapRecoedCount(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String source, String stationCode, String fopCode, Integer fopMapId) {
		return fopMappingRepository.count(Specification.where(FOPMappingEntitySpecification.equalsClientId(clientId)
				.and(FOPMappingEntitySpecification.equalsFOPCode(fopCode))
				.and(FOPMappingEntitySpecification.equalsSource(source))
				.and(FOPMappingEntitySpecification.equalsStationCode(stationCode))
				.and(FOPMappingEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(FOPMappingEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(FOPMappingEntitySpecification.notEqualsfopId(fopMapId))));
	}

	@Override
	public List<FOPMappingEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return fopMappingRepository
				.findAll((FOPMappingEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(FOPMappingEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(FOPMappingEntitySpecification.isActive())));
	}

	@Override
	public List<FOPMappingEntity> searchFOPMapping(Optional<String> stationCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> source, Optional<String> fopCode) {
		return fopMappingRepository.findAll(
				FOPMappingEntitySpecification.search(stationCode, effectiveFromDate, effectiveToDate, source, fopCode));
	}

}
