package com.sgl.smartpra.master.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.FormCodeEntity;

@Repository
public interface FormCodeRepository
		extends JpaRepository<FormCodeEntity, Integer>, JpaSpecificationExecutor<FormCodeEntity> {

	@Query(value = "select documentType  from FormCodeEntity d where d.formCodeId=?1 and d.activate =TRUE")
	String getDocumentType(int formCodeId);

}