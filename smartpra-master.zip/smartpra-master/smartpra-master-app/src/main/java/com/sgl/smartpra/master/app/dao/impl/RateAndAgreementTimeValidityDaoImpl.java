package com.sgl.smartpra.master.app.dao.impl;


import com.sgl.smartpra.master.app.dao.RateAndAgreementTimeValidityDao;

import com.sgl.smartpra.master.app.dao.entity.RateAndAgreementTimeValidityEntity;

import com.sgl.smartpra.master.app.dao.entity.spec.RateAndAgreementTimeValidityEntitySpecifcation;

import com.sgl.smartpra.master.app.repository.RateAndAgreementTimeValidityRepository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;


@Component
@Slf4j
public class RateAndAgreementTimeValidityDaoImpl implements RateAndAgreementTimeValidityDao {

    @Autowired
    private RateAndAgreementTimeValidityRepository rateAndAgreementTimeValidityRepository;

    @Override
    @Caching(evict= {@CacheEvict(value="rateAndAgreementTimeValidityEntity",key = "#rateAndAgreementTimeValidityEntity.rateAgreementTimeValID")})
    public RateAndAgreementTimeValidityEntity create(RateAndAgreementTimeValidityEntity rateAndAgreementTimeValidityEntity) {
        return rateAndAgreementTimeValidityRepository.save(rateAndAgreementTimeValidityEntity);
    }

    @Override
    @CachePut(value = "rateAndAgreementTimeValidityEntity", key = "#rateAndAgreementTimeValidityEntity.rateAgreementTimeValID")
    @CacheEvict(value = "rateAndAgreementEntitySearch", allEntries = true)
    public RateAndAgreementTimeValidityEntity update(RateAndAgreementTimeValidityEntity rateAndAgreementTimeValidityEntity) {
        return rateAndAgreementTimeValidityRepository.save(rateAndAgreementTimeValidityEntity);
    }

    @Override
    public Optional<RateAndAgreementTimeValidityEntity> findById(Integer id) {
        return rateAndAgreementTimeValidityRepository.findById(id);
    }

    @Override
    public List<RateAndAgreementTimeValidityEntity> fetchAll(Integer rateAgreementID) {
        return rateAndAgreementTimeValidityRepository.findAll(RateAndAgreementTimeValidityEntitySpecifcation.search(rateAgreementID));
    }

    @Override
    @CacheEvict(value = "rateAndAgreementTimeValidityEntity" , key = "#rateAgreementTimeValID")
    public Boolean delete(Integer rateAgreementTimeValID) {
        Boolean flag = Boolean.FALSE;
        try {
        	rateAndAgreementTimeValidityRepository.deleteById(rateAgreementTimeValID);
            flag = Boolean.TRUE;
        } catch(Exception e){
        	flag = Boolean.FALSE;
            log.error("Exc : ",e);
        }
        return flag;
    }
}
