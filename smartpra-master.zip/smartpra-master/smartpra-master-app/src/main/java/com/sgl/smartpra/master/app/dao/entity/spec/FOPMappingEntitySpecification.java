package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.FOPMappingEntity;

public class FOPMappingEntitySpecification {
	public static Specification<FOPMappingEntity> equalsClientId(String clientId) {
		return (fopMappingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fopMappingEntity.get("clientId"), clientId);
	}

	public static Specification<FOPMappingEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (fopMappingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), fopMappingEntity.get("effectiveFromDate"),
				fopMappingEntity.get("effectiveToDate"));
	}

	public static Specification<FOPMappingEntity> equalsFOPCode(String fopCode) {
		return (fopMappingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fopMappingEntity.get("fopCode"), fopCode);
	}

	public static Specification<FOPMappingEntity> equalsSource(String source) {
		return (fopMappingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fopMappingEntity.get("source"), source);
	}

	public static Specification<FOPMappingEntity> equalsStationCode(String stationCode) {
		return (fopMappingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fopMappingEntity.get("stationCode"), stationCode);
	}

	public static Specification<FOPMappingEntity> isActive() {
		return (fopMappingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fopMappingEntity.get("activate"), true);
	}

	public static Specification<FOPMappingEntity> notEqualsfopId(Integer fopMapId) {
		return (fopMappingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(fopMappingEntity.get("fopMapId"), fopMapId);
	}

	public static void orderByAsc(Root<FOPMappingEntity> fopMappingEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(fopMappingEntity.get(orderByString)));
	}

	public static Specification<FOPMappingEntity> search(Optional<String> stationCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> source,
			Optional<String> fopCode) {
		return (fopMappingEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(stationCode)) {
				predicates.add(criteriaBuilder.like(fopMappingEntity.get("stationCode"),
						OptionalUtil.getValue(stationCode) + "%"));
			}
			if (OptionalUtil.isPresent(source)) {
				predicates.add(criteriaBuilder.equal(fopMappingEntity.get("source"), OptionalUtil.getValue(source)));
			}
			if (OptionalUtil.isPresent(fopCode)) {
				predicates.add(criteriaBuilder.equal(fopMappingEntity.get("fopCode"), OptionalUtil.getValue(fopCode)));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								fopMappingEntity.get("effectiveFromDate"), fopMappingEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								fopMappingEntity.get("effectiveFromDate"), fopMappingEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							fopMappingEntity.get("effectiveFromDate"), fopMappingEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							fopMappingEntity.get("effectiveFromDate"), fopMappingEntity.get("effectiveToDate")));
				}
			}
			orderByAsc(fopMappingEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

}
