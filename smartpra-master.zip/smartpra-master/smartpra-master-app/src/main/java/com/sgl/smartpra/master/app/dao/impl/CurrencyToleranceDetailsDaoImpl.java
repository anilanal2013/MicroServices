package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.CurrencyToleranceDetailsDao;
import com.sgl.smartpra.master.app.dao.entity.CurrencyToleranceDetailsEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.CurrencyToleranceDetailsEntitySpec;
import com.sgl.smartpra.master.app.dao.repository.CurrencyToleranceDetailsRepository;

@Component
public class CurrencyToleranceDetailsDaoImpl implements CurrencyToleranceDetailsDao {

	@Autowired
	private CurrencyToleranceDetailsRepository currencyToleranceRepository;

	@Override
	@Caching(evict = {
			@CacheEvict(value = "currencyToleranceDetails", key = "#currencyToleranceDetailsEntity.currencyToleranceDtlId") })
	public CurrencyToleranceDetailsEntity createCurrencyTolerance(
			CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity) {
		return currencyToleranceRepository.save(currencyToleranceDetailsEntity);
	}

	@Override
	public Optional<CurrencyToleranceDetailsEntity> findById(Integer currencyToleranceDtlId) {
		return currencyToleranceRepository.findById(currencyToleranceDtlId);
	}

	@Override
	@CachePut(value = "currencyToleranceDetails", key = "#currencyToleranceDetailsEntity.currencyToleranceDtlId")
	public CurrencyToleranceDetailsEntity updateCurrencyTolerance(
			CurrencyToleranceDetailsEntity currencyToleranceDetailsEntity) {
		return currencyToleranceRepository.save(currencyToleranceDetailsEntity);
	}

	@Override
	public List<CurrencyToleranceDetailsEntity> getListOfCurrencyTolerance(String currencyCode, String clientId, 
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return currencyToleranceRepository
				.findAll(CurrencyToleranceDetailsEntitySpec.search(currencyCode, clientId, effectiveFromDate, effectiveToDate));
	}
	
	@Override
	public CurrencyToleranceDetailsEntity getCurrencyToleranceByDate(String currencyCode, String clientId,
			Optional<String> effectiveFromDate) {
		return currencyToleranceRepository.findOne(CurrencyToleranceDetailsEntitySpec.equalsClientId(clientId)
				.and(CurrencyToleranceDetailsEntitySpec.equalsCurrencyCode(currencyCode))
				.and((CurrencyToleranceDetailsEntitySpec.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate)))
						.or(CurrencyToleranceDetailsEntitySpec.greaterThanOrEqualTo(OptionalUtil.getLocalDateValue(effectiveFromDate))
								.and(CurrencyToleranceDetailsEntitySpec.lessThanOrEqualTo(OptionalUtil.getLocalDateValue(effectiveFromDate))))))
				.orElse(new CurrencyToleranceDetailsEntity());
	}

	@Override
	public long findOverLapRecord(Optional<String> clientId, Optional<String> currencyCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return currencyToleranceRepository.count(Specification.where(CurrencyToleranceDetailsEntitySpec
				.equalsClientId(OptionalUtil.getValue(clientId))
				.and(CurrencyToleranceDetailsEntitySpec.equalsCurrencyCode(OptionalUtil.getValue(currencyCode)))
				.and((CurrencyToleranceDetailsEntitySpec
						.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate))
						.or(CurrencyToleranceDetailsEntitySpec.betweenEffectiveFromAndEffectiveToDate(
								OptionalUtil.getLocalDateValue(effectiveToDate))))
										.or(CurrencyToleranceDetailsEntitySpec
												.greaterThanOrEqualTo(OptionalUtil.getLocalDateValue(effectiveFromDate))
												.and(CurrencyToleranceDetailsEntitySpec.lessThanOrEqualTo(
														OptionalUtil.getLocalDateValue(effectiveToDate)))))));

	}

	@Override
	public long findOverLapRecord(String clientId, String currencyCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, Integer currencyToleranceDtlId) {
		return currencyToleranceRepository.count(Specification.where(CurrencyToleranceDetailsEntitySpec
				.equalsClientId(clientId).and(CurrencyToleranceDetailsEntitySpec.equalsCurrencyCode(currencyCode))
				.and((CurrencyToleranceDetailsEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(CurrencyToleranceDetailsEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
								.or(CurrencyToleranceDetailsEntitySpec.greaterThanOrEqualTo(effectiveFromDate)
										.and(CurrencyToleranceDetailsEntitySpec.lessThanOrEqualTo((effectiveToDate))))
								.and(CurrencyToleranceDetailsEntitySpec
										.notEqualsCurrencyToleranceId(currencyToleranceDtlId)))));
	}
}
