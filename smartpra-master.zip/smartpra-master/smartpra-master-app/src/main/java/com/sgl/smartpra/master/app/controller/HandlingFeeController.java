package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.HandlingFeeService;
import com.sgl.smartpra.master.model.HandlingFee;

@RestController
public class HandlingFeeController {

	@Autowired
	private HandlingFeeService handlingFeeService;

	@GetMapping("/handling-fee")
	public List<HandlingFee> getAllHandlingFee(
			@RequestParam(value = "issueCxr", required = false) Optional<String> issueCxr,
			@RequestParam(value = "operatingCxr", required = false) Optional<String> operatingCxr,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {
		return handlingFeeService.getAllHandlingFee(issueCxr, operatingCxr, effectiveFromDate, effectiveToDate);
	}

	@GetMapping("/handling-fee/{handlingFeeId}")
	public HandlingFee getHandlingFeeByHandlingFeeId(@PathVariable("handlingFeeId") Integer handlingFeeId) {
		return handlingFeeService.getHandlingFeeByHandlingFeeId(handlingFeeId);
	}

	@PostMapping("/handling-fee")
	public HandlingFee createHandlingFee(@Validated(Create.class) @RequestBody HandlingFee handlingFee) {
		return handlingFeeService.createHandlingFee(handlingFee);
	}

	@PutMapping("/handling-fee/{handlingFeeId}")
	public HandlingFee updateHandlingFee(@PathVariable("handlingFeeId") Integer handlingFeeId,
			@Validated(Update.class) @RequestBody HandlingFee handlingFee) {
		return handlingFeeService.updateHandlingFee(handlingFeeId, handlingFee);
	}

}
