package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.OneWorldCarrierAlliance;

public interface CarrierAllianceService {

	public List<CarrierAlliance> search(Optional<String> carrierCode, Optional<String> clientId,
			Optional<String> allianceName, Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	public CarrierAlliance createCarrierAlliance(CarrierAlliance carrierAlliance);

	public OneWorldCarrierAlliance createCarrierAlliance(OneWorldCarrierAlliance oneWorldCarrierAlliance);

	public CarrierAlliance updateCarrierAlliance(CarrierAlliance carrierAlliance);

	public OneWorldCarrierAlliance updateCarrierAlliance(OneWorldCarrierAlliance oneWorldCarrierAlliance);

	public CarrierAlliance getCarrierAllianceByCarrierAllianceDtlId(Integer carrierAllianceDtlId);

	public List<CarrierAlliance> search(String carrierCode, Optional<String> effectiveDate);

	public List<CarrierAlliance> search(String allianceName, Optional<String> effectiveDate, String clientId);

	public List<CarrierAlliance> findAll(String clientId);

	public void deactivateCarrierAlliance(CarrierAlliance carrierAlliance);

	public void activateCarrierAlliance(CarrierAlliance carrierAlliance);

	public CarrierAlliance getAllianceByCarrierCodeAndEffectiveDate(String clientId,
			 String carrierCode, Optional<String> effectiveDate);

}
