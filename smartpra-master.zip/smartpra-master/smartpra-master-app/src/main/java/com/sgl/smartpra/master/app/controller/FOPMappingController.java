package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.FOPMappingService;
import com.sgl.smartpra.master.model.FOPMapping;

@RestController
@RequestMapping("/fop-mapping")
public class FOPMappingController {
	@Autowired
	FOPMappingService fopMappingService;

	@PostMapping
	@ResponseStatus(value = HttpStatus.CREATED)
	public FOPMapping createFOPMapping(@Validated(Create.class) @RequestBody FOPMapping fopMapping) {
		return fopMappingService.createFOPMapping(fopMapping);
	}

	@PutMapping("/{fopMapId}")
	@ResponseStatus(value = HttpStatus.OK)
	public FOPMapping updateFOPMapping(@PathVariable(value = "fopMapId") Integer fopMapId,
			@Validated(Update.class) @RequestBody FOPMapping fopMapping) {
		fopMapping.setFopMapId(fopMapId);
		return fopMappingService.updateFOPMapping(fopMapping);
	}

	@GetMapping("/search")
	public List<FOPMapping> search(@RequestParam(name = "stationCode", required = false) Optional<String> stationCode,
			@RequestParam(name = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(name = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(name = "source", required = false) Optional<String> source,
			@RequestParam(name = "fopCode", required = false) Optional<String> fopCode) {
		return fopMappingService.search(stationCode, effectiveFromDate, effectiveToDate, source, fopCode);
	}

	@GetMapping("/{fopMapId}")
	public FOPMapping getFOPMappingByFOPMapId(@PathVariable(value = "fopMapId") Integer fopMapId) {
		return fopMappingService.getFOPMappingByFOPMapId(fopMapId);
	}

	@PutMapping("{fopMapId}/deactivate")
	public void deactivateFOPMapping(@Valid @PathVariable(value = "fopMapId") Integer fopMapId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		FOPMapping fopMapping = new FOPMapping();
		fopMapping.setFopMapId(fopMapId);
		fopMapping.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		fopMappingService.deactivateFOPMapping(fopMapping);
	}

	@PutMapping("{fopMapId}/activate")
	public void activateFOPMapping(@Valid @PathVariable(value = "fopMapId") Integer fopMapId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		FOPMapping fopMapping = new FOPMapping();
		fopMapping.setFopMapId(fopMapId);
		fopMapping.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		fopMappingService.activateFOPMapping(fopMapping);
	}
}
