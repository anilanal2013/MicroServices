package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.InterfaceReferenceEntity;

@Repository
public interface InterfaceReferenceDao {

	public InterfaceReferenceEntity create(InterfaceReferenceEntity interfaceReferenceEntity);

	public InterfaceReferenceEntity update(InterfaceReferenceEntity interfaceReferenceEntity);

	public List<InterfaceReferenceEntity> search(Optional<String> clientId, Optional<String> dataSource, Optional<String> stationCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate, Optional<String> exceptionCall);
 
	public Optional<InterfaceReferenceEntity> findById(Integer interfaceRefId);

	public long getOverLapRecordCountCreate(String clientId, String dataSource, String stationCode,
			LocalDate effectiveFromDate, LocalDate effectiveToDate);

	public long getOverLapRecordCountUpdate(String clientId, String dataSource, String stationCode,
			LocalDate effectiveFromDate, LocalDate effectiveToDate, Integer interfaceRefId);

	public Optional<InterfaceReferenceEntity> getInterfaceReferenceByDataSourceAndStationCodeWithEffectiveDate(
			Optional<String> clientId, Optional<String> dataSource, Optional<String> stationCode,
			Optional<String> effectiveDate);

	public long getCount(InterfaceReferenceEntity interfaceReferenceEntity);

	public Page<InterfaceReferenceEntity> searchData(InterfaceReferenceEntity mapToEntity, Pageable pageable);
}
