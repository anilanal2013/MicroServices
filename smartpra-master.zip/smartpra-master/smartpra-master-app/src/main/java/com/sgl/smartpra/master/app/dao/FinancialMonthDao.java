package com.sgl.smartpra.master.app.dao;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;

@Repository
public class FinancialMonthDao<T> extends CommonSearchDao<T> {

}
