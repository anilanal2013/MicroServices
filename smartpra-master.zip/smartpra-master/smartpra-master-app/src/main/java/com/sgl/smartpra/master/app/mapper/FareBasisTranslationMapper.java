package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.FareBasisTranslationEntity;
import com.sgl.smartpra.master.model.FareBasisTranslation;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FareBasisTranslationMapper extends BaseMapper<FareBasisTranslation, FareBasisTranslationEntity> {
	
	FareBasisTranslationEntity mapToEntity(FareBasisTranslation fareBasisTranslation, @MappingTarget FareBasisTranslationEntity fareBasisTranslationEntity);

	@Mapping(source = "fbtId", target = "fbtId", ignore = true)
	FareBasisTranslationEntity mapToEntity(FareBasisTranslation fareBasisTranslation);
}
