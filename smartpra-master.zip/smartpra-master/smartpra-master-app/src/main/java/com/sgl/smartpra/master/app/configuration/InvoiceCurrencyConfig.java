package com.sgl.smartpra.master.app.configuration;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.NoArgsConstructor;
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "smart-pra")
@Component
@Data
public class InvoiceCurrencyConfig {

	private List<InvoiceCurrency> invoiceCurrencies = new ArrayList<InvoiceCurrency>();
	@Data
	@NoArgsConstructor
	public static class InvoiceCurrency {
		String billedZone;
		String billingZone;
		String currency;
	}

}
