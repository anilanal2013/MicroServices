package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.FlightControlService;
import com.sgl.smartpra.master.model.FlightControl;

@RestController
public class FlightControlController {
	@Autowired
	FlightControlService flightControlService;

	@GetMapping("/flight-control")
	public List<FlightControl> getAllFlightControl(
			@RequestParam(value = "flightControlId", required = false) String flightControlId,
			@RequestParam(value = "activate", required = false) Boolean activate) {
		FlightControl flightControl = new FlightControl();
		flightControl.setFlightControlId(Optional.of(flightControlId));
		flightControl.setActivate(activate);

		return flightControlService.getListOfFlightControl("", flightControlId, activate, Optional.of(""));
	}

	@GetMapping("/flight-control/search/clientid/{clientId}")
	public List<FlightControl> getAllFlightControl(@PathVariable(value = "clientId") String clientId,
			@RequestParam(value = "flightControlId", required = false) String flightControlId,
			@RequestParam(value = "activate", required = false) Boolean activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {

		return flightControlService.getListOfFlightControl(clientId, flightControlId, activate, exceptionCall);
	}

	@GetMapping("/flight-control/{flightControlAutoId}")
	public FlightControl getFlightControlByFlightControlId(
			@PathVariable(value = "flightControlAutoId") Integer flightControlAutoId) {
		return flightControlService.getFlightControlByFlightControlAutoId(flightControlAutoId);
	}

	@PostMapping("/flight-control")
	public FlightControl createFlightControl(@Validated(Create.class) @RequestBody FlightControl flightControl) {

		return flightControlService.createFlightControl(flightControl);
	}

	@PutMapping("/flight-control/{flightControlAutoId}")
	public FlightControl updateFlightControl(@PathVariable(value = "flightControlAutoId") Integer flightControlAutoId,
			@Validated(Update.class) @RequestBody FlightControl flightControl) {
		return flightControlService.updateFlightControl(flightControlAutoId, flightControl);
	}

	@PutMapping("/flight-control/{flightControlAutoId}/deactivate")
	public void deactivateFlightControl(@Valid @PathVariable(value = "flightControlAutoId") Integer flightControlAutoId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		flightControlService.deactivateFlightControl(flightControlAutoId, lastUpdatedBy);
	}

	@PutMapping("/flight-control/{flightControlAutoId}/activate")
	public void activateFlightControl(@Valid @PathVariable(value = "flightControlAutoId") Integer flightControlAutoId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		flightControlService.activateFlightControl(flightControlAutoId, lastUpdatedBy);
	}

}
