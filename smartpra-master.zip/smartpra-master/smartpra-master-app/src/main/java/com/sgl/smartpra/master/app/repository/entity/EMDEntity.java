package com.sgl.smartpra.master.app.repository.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_electronic_misc_document database table.
 * 
 */
@Entity
@Table(name = "mas_emd")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class EMDEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "emd_id")
	private Integer emdId;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "consumption_type")
	private String consumptionType;

	@Column(name = "cost_centre")
	private String costCentre;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Column(name = "emd_consumed_issuance_feecode")
	private String emdConsumedIssuanceFeecode;

	@Column(name = "emd_exchange")
	private String emdExchange;

	@Column(name = "emd_interlinable")
	private String emdInterlinable;

	@Column(name = "emd_outdate")
	private String emdOutdate;

	@Column(name = "emd_refund")
	private String emdRefund;

	@Column(name = "emd_type")
	private String emdType;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "profit_centre")
	private String profitCentre;

	@Column(name = "prorate_emd")
	private String prorateEmd;

	@Column(name = "reason_for_issuance_code")
	private String reasonForIssuanceCode;

	@Column(name = "reason_for_issuance_sub_code")
	private String reasonForIssuanceSubCode;

	@Column(name = "sales_source")
	private String salesSource;

	@Column(name = "vat_applicable")
	private String vatApplicable;

	@Column(name = "wait_link_passenger_doc")
	private String waitLinkPassengerDoc;

	@Column(name = "service_type")
	private String serviceType;

	@Column(name = "description")
	private String description;

	@Column(name = "mco_tax")
	private String mcoTax;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}