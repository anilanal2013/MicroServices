package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.SPARoutingStgEntity;

public class SPARoutingStgEntitySpecification {
	SPARoutingStgEntitySpecification() {
	}
	public static Specification<SPARoutingStgEntity> findBySpaKeyMainIdClientId(Optional<Integer> spaKey,
			Optional<Integer> spaMainId, Optional<String> clientId) {
		return (spaRoutingStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(spaKey)) {
				predicates.add(criteriaBuilder.equal(spaRoutingStgEntity.get("spaKey"), OptionalUtil.getValue(spaKey)));
			}
			if (OptionalUtil.isPresent(spaMainId)) {
				predicates.add(
						criteriaBuilder.equal(spaRoutingStgEntity.get("spaMainId"), OptionalUtil.getValue(spaMainId)));
			}
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.equal(spaRoutingStgEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
