package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_source_code")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class SourceCodeEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "source_code_id")
	private Integer sourceCodeId;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@Column(name = "attribute_3")
	private String attribute3;

	@Column(name = "attribute_4")
	private String attribute4;

	@Column(name = "attribute_5")
	private String attribute5;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "cost_centre")
	private String costCentre;

	@Column(name = "outward_source_code")
	private String outwardSourceCode;

	@Column(name = "profit_centre")
	private String profitCentre;

	@Column(name = "source_category")
	private String sourceCategory;

	@Column(name = "source_code")
	private String sourceCode;

	@Column(name = "source_description")
	private String sourceDescription;

	@Column(name = "source_type")
	private String sourceType;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
