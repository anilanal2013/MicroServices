package com.sgl.smartpra.master.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.master.app.dao.entity.ClientUserAreaEntity;

@Repository
public interface ClientUserAreaRepository
		extends JpaRepository<ClientUserAreaEntity, Integer>, JpaSpecificationExecutor<ClientUserAreaEntity> {

	List<ClientUserAreaEntity> findByUserAreaCode(String userAreaCode);

	@Transactional
	@Modifying
	@Query("delete from ClientUserAreaEntity g where g.areaKey1= ?1 AND g.areaKey2= ?2 AND g.areaKey3= ?3")
	void deleteClientUserArea(String areaKey1, String areaKey2, String areaKey3);
}
