package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.AgencyDetailsDao;
import com.sgl.smartpra.master.app.dao.entity.AgencyDetailsEntity;
import com.sgl.smartpra.master.app.dao.entity.AgencyMasterEntity;
import com.sgl.smartpra.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.master.app.mapper.AgencyDetailsMapper;
import com.sgl.smartpra.master.app.service.AgencyDetailsService;
import com.sgl.smartpra.master.app.service.AgencyMasterService;
import com.sgl.smartpra.master.app.service.ListOfValuesService;
import com.sgl.smartpra.master.model.AgencyDetailsModel;
import com.sgl.smartpra.master.model.ListOfValues;

@Service
@Transactional
public class AgencyDetailsServiceImpl implements AgencyDetailsService {

	@Autowired
	private AgencyDetailsMapper agencyDetailsMapper;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private AgencyMasterService agencyMastersService;

	@Autowired
	private AgencyDetailsDao agencyDetailsDao;

	@Autowired
	private ListOfValuesService listOfValuesService;

	public static final String AGENCY_DETAILS_ID_ACTIVE = "Agency Details is already in active state";
	public static final String AGENCY_DETAILS_ID_INACTIVE = "Agency Details is deactivated state";
	public static final String AGENCY_DETAIL_ID_INACTIVE = "Agency Details is already in deactivated state";
	public static final String AGENCYDETAILS = "Agency Details";
	public static final String AGENCYDETAILSID = "Agency Details id not found";
	public static final String LASTUPDATEDBYMSG = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	public static final String LASTUPDATEDBYMENDATORYMSG = "Please provide Last Updated By";
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	String carrierCode = null;
	String carrierName1 = null;
	String carrierName2 = null;
	private static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	private static final String LOVTRANSACTIONTYPE = LOVEnum.TRANSACTION_TYPE.getLOVEnum();
	private static final String LOVREPORTINGFREQUENCY = LOVEnum.REPORTING_FREQUENCY.getLOVEnum();
	private static final String LOVREPORTINGTYPE = LOVEnum.REPORTING_TYPE.getLOVEnum();
	private static final String LOVAPPLICABLEDOCTYPES = LOVEnum.DOCTYPE.getLOVEnum();
	private static final String PERCENTAGE_VALIDATE = "^\\d{0,3}(\\.\\d{0,3})?$";
	private static final String AGENCYID_VALIDATE = "Record not found with Agency Id ";
	private static final String VALID = "] is Not Valid";

	@Override
	public List<AgencyDetailsModel> getAgencyDetailsByEffectiveDate(Optional<String> agencyCode,
			Optional<String> clientId, Optional<String> transactionType, Optional<String> reportingFrequency,
			Optional<String> transactionCurrency, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate) {
		return agencyDetailsMapper.mapToModel(agencyDetailsDao.findAll(agencyCode, clientId, transactionType,
				reportingFrequency, transactionCurrency, effectiveFromDate, effectiveToDate, activate));
	}

	@Override
	public List<AgencyDetailsModel> getAgencyDetailsByEffectiveDate(Integer agencyId, Optional<String> agencyCode,
			Optional<String> clientId, Optional<String> transactionType, Optional<String> reportingFrequency,
			Optional<String> transactionCurrency, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate, Optional<String> exceptionCall) {
		try {
			agencyMastersService.getAgencyByAgencyId(agencyId);
		} catch (Exception e) {
			throw new BusinessException(AGENCYID_VALIDATE + agencyId);
		}
		return agencyDetailsMapper.mapToModel(
				agencyDetailsDao.findByAgencyId(agencyId, agencyCode, clientId, transactionType, reportingFrequency,
						transactionCurrency, effectiveFromDate, effectiveToDate, activate, exceptionCall));
	}

	@Override
	public AgencyDetailsModel getAgencyDetailsByAgencyDetailsId(Integer agencyId, int agencyDetailId) {
		try {
			agencyMastersService.getAgencyByAgencyId(agencyId);
		} catch (Exception e) {
			throw new BusinessException(AGENCYID_VALIDATE + agencyId);
		}

		Optional<AgencyDetailsEntity> agencyDetailsEntity = agencyDetailsDao.findById(agencyDetailId);
		if (!agencyDetailsEntity.isPresent()) {
			throw new ResourceNotFoundException(AGENCYDETAILS, "code", agencyDetailId);
		}
		return agencyDetailsMapper.mapToModel(agencyDetailsEntity.get());
	}

	@Override
	public AgencyDetailsModel createAgencyDetails(Integer agencyId, AgencyDetailsModel agencyDetailsModel) {
		try {
			agencyMastersService.getAgencyByAgencyId(agencyId);
		} catch (Exception e) {
			throw new BusinessException(AGENCYID_VALIDATE + agencyId);
		}
		if (OptionalUtil.isPresent(agencyDetailsModel.getCommissionPercentage())
				&& !OptionalUtil.getValue(agencyDetailsModel.getCommissionPercentage()).isEmpty()) {
			validateCommissionPercentage(agencyDetailsModel.getCommissionPercentage());
		} else {
			agencyDetailsModel.setCommissionPercentage(null);
		}
		if (OptionalUtil.isPresent(agencyDetailsModel.getNetGrossFlag())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(agencyDetailsModel.getNetGrossFlag()))) {
			Boolean checkControlId = Pattern.compile("^G|N")
					.matcher(OptionalUtil.getValue(agencyDetailsModel.getNetGrossFlag())).find();
			if (!checkControlId) {
				throw new BusinessException("Net Gross Flag should be start with G|N");
			}
		}
		if (OptionalUtil.isPresent(agencyDetailsModel.getCommissionFlag())) {
			Boolean checkControlId = Pattern.compile("^Y|N")
					.matcher(OptionalUtil.getValue(agencyDetailsModel.getCommissionFlag())).find();
			if (!checkControlId) {
				throw new BusinessException("Commission Flag should be start with Y|N");
			}
		}
		validateBusinessConstraintsForCreate(agencyDetailsModel);

		agencyDetailsModel.setActivate(Boolean.TRUE);
		agencyDetailsModel.setCreatedDate(LocalDateTime.now());
		agencyDetailsModel.setAgencyId(agencyId);
		return agencyDetailsMapper
				.mapToModel(agencyDetailsDao.create(agencyDetailsMapper.mapToEntity(agencyDetailsModel)));
	}

	@Override
	public AgencyDetailsModel updateAgencyDetails(Integer agencyId, Integer agencyDetailId,
			AgencyDetailsModel agencyDetailsModel) {
		try {
			agencyMastersService.getAgencyByAgencyId(agencyId);
		} catch (Exception e) {
			throw new BusinessException(AGENCYID_VALIDATE + agencyId);
		}
		AgencyDetailsEntity agencyDetailsEntity = agencyDetailsDao.findById(agencyDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(agencyDetailId)));
		if (!agencyDetailsEntity.getActivate())
			throw new BusinessException(AGENCY_DETAILS_ID_INACTIVE);
		if (OptionalUtil.isPresent(agencyDetailsModel.getNetGrossFlag())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(agencyDetailsModel.getNetGrossFlag()))) {
			Boolean netGrossFlag = Pattern.compile("^G|N")
					.matcher(getNetGrossFlag(agencyDetailsModel, agencyDetailsEntity)).find();
			if (!netGrossFlag) {
				throw new BusinessException("Net Gross Flag should be start with G|N");
			}
		}
		if (OptionalUtil.isPresent(agencyDetailsModel.getCommissionPercentage())
				&& !OptionalUtil.getValue(agencyDetailsModel.getCommissionPercentage()).isEmpty()) {
			validateCommissionPercentage(agencyDetailsModel.getCommissionPercentage());
		} else {
			agencyDetailsModel.setCommissionPercentage(null);
		}
		if (OptionalUtil.isPresent(agencyDetailsModel.getCommissionFlag())) {
			Boolean checkControlId = Pattern.compile("^Y|N")
					.matcher(getCommissionFlag(agencyDetailsModel, agencyDetailsEntity)).find();
			if (!checkControlId) {
				throw new BusinessException("Commission Flag should be start with Y|N");
			}
		}
		validateBusinessConstraintsForUpdate(agencyDetailsModel, agencyDetailsEntity);
		if (OptionalUtil.isPresent(agencyDetailsModel.getEffectiveFromDate())
				&& OptionalUtil.isPresent(agencyDetailsModel.getEffectiveToDate())) {
			validateOverLapForUpdate(agencyDetailsModel, agencyDetailsEntity);
		}
		clientIdToCarrierDesignatorValidation(getClientId(agencyDetailsModel, agencyDetailsEntity));
		if (OptionalUtil.isPresent(agencyDetailsModel.getTransactionCurrency())) {
			currencyToCurrencyCodeValidation(OptionalUtil.getValue(agencyDetailsModel.getTransactionCurrency()));
		}
		agencyCodeToAgencyMaster(getAgencyCode(agencyDetailsModel, agencyDetailsEntity));
		agencyDetailsModel.setActivate(Boolean.TRUE);
		agencyDetailsModel.setLastUpdatedDate(LocalDateTime.now());
		agencyDetailsModel.setAgencyDetailsId(agencyDetailsEntity.getAgencyDetailsId());
		agencyDetailsModel.setAgencyId(agencyId);
		return agencyDetailsMapper.mapToModel(
				agencyDetailsDao.update(agencyDetailsMapper.mapToEntity(agencyDetailsModel, agencyDetailsEntity)));
	}

	@Override
	public void deactivateAgencyDetail(Integer agencyId, int agencyDetailId, String lastUpdatedBy) {
		try {
			agencyMastersService.getAgencyByAgencyId(agencyId);
		} catch (Exception e) {
			throw new BusinessException(AGENCYID_VALIDATE + agencyId);
		}
		AgencyDetailsEntity agencyDetailsEntity = agencyDetailsDao.findById(agencyDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(agencyDetailId)));
		if (agencyDetailsEntity.getLastUpdatedBy().isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (agencyDetailsEntity.getLastUpdatedBy().length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}
		if (!agencyDetailsEntity.getActivate()) {
			throw new BusinessException(AGENCY_DETAIL_ID_INACTIVE);
		}
		agencyDetailsEntity.setActivate(Boolean.FALSE);
		agencyDetailsEntity.setLastUpdatedBy(lastUpdatedBy);
		agencyDetailsEntity.setLastUpdatedDate(LocalDateTime.now());
		agencyDetailsDao.update(agencyDetailsEntity);
	}

	@Override
	public void activateAgencyDetail(Integer agencyId, int agencyDetailId, String lastUpdatedBy) {
		try {
			agencyMastersService.getAgencyByAgencyId(agencyId);
		} catch (Exception e) {
			throw new BusinessException(AGENCYID_VALIDATE + agencyId);
		}
		AgencyDetailsEntity agencyDetailsEntity = agencyDetailsDao.findById(agencyDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(agencyDetailId)));
		if (agencyDetailsEntity.getLastUpdatedBy().isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (agencyDetailsEntity.getLastUpdatedBy().length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}
		if (agencyDetailsEntity.getActivate()) {
			throw new BusinessException(AGENCY_DETAILS_ID_ACTIVE);
		}
		agencyDetailsEntity.setActivate(Boolean.TRUE);
		agencyDetailsEntity.setLastUpdatedBy(lastUpdatedBy);
		agencyDetailsEntity.setLastUpdatedDate(LocalDateTime.now());
		agencyDetailsDao.update(agencyDetailsEntity);
	}

	private void validateBusinessConstraintsForCreate(AgencyDetailsModel agencyDetailsModel) {
		validateOverLap(agencyDetailsModel);
		if (OptionalUtil.isPresent(agencyDetailsModel.getTransactionType())) {
			validateTransactionType(OptionalUtil.getValue(agencyDetailsModel.getClientId()),
					OptionalUtil.getValue(agencyDetailsModel.getTransactionType()));
		}
		if (OptionalUtil.isPresent(agencyDetailsModel.getReportingFrequency())) {
			validateFrequencyList(OptionalUtil.getValue(agencyDetailsModel.getClientId()),
					OptionalUtil.getValue(agencyDetailsModel.getReportingFrequency()));
		}
		if (OptionalUtil.isPresent(agencyDetailsModel.getReportingType())
				&& !StringUtils.isEmpty(OptionalUtil.getValue(agencyDetailsModel.getReportingType()))) {
			validateReportingType(OptionalUtil.getValue(agencyDetailsModel.getClientId()),
					OptionalUtil.getValue(agencyDetailsModel.getReportingType()));
		}
		if (OptionalUtil.isPresent(agencyDetailsModel.getApplDocTypes())) {
			validateApplicationDocumentType(OptionalUtil.getValue(agencyDetailsModel.getClientId()),
					OptionalUtil.getValue(agencyDetailsModel.getApplDocTypes()));
		}
		clientIdToCarrierDesignatorValidation(OptionalUtil.getValue(agencyDetailsModel.getClientId()));
		if (OptionalUtil.isPresent(agencyDetailsModel.getTransactionCurrency())) {
			currencyToCurrencyCodeValidation(OptionalUtil.getValue(agencyDetailsModel.getTransactionCurrency()));
		}
		if (OptionalUtil.isPresent(agencyDetailsModel.getAgencyCode())) {
			validateAgencyCode(OptionalUtil.getValue(agencyDetailsModel.getAgencyCode()));
		}

	}

	@Override
	public List<AgencyDetailsModel> getAgencyDetailsByAgencyCode(Optional<String> clientId, Optional<String> agencyCode,
			Optional<String> effectiveDate) {
		return agencyDetailsMapper
				.mapToModel(agencyDetailsDao.searchAgencyDetailsByAgencyCode(clientId, agencyCode, effectiveDate));
	}

	private void agencyCodeToAgencyMaster(String agencyCode) {
		validateAgencyCode(agencyCode);
	}

	private void clientIdToCarrierDesignatorValidation(String clientId) {
		if (globalMasterFeignClient.getAllCarrier(carrierCode, clientId, carrierName1, carrierName2, true).isEmpty()) {
			throw new BusinessException("Invalid Client Id " + clientId);
		}
	}

	private void currencyToCurrencyCodeValidation(String currencyCode) {
		if (!globalMasterFeignClient.validateCurrencyCode(currencyCode)) {
			throw new BusinessException("Invalid Currency Code " + currencyCode);
		}
	}

	private void validateAgencyCode(String agencyCode) {
		List<AgencyMasterEntity> validAgencyCode = agencyMastersService.isValidAgencyCode(agencyCode);
		if (validAgencyCode.isEmpty()) {
			throw new BusinessException("Invalid Agency Code " + agencyCode);
		}
	}

	private void validateTransactionType(String clientId, String transactionType) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(LOVTRANSACTIONTYPE));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(transactionType));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Transaction Type[" + transactionType + VALID);
		}
	}

	private void validateFrequencyList(String clientId, String frequencyList) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(LOVREPORTINGFREQUENCY));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(frequencyList));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Reporting Frequency[" + frequencyList + VALID);
		}
	}

	private void validateReportingType(String clientId, String reportingType) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(LOVREPORTINGTYPE));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(reportingType));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Reporting Type[" + reportingType + VALID);
		}
	}

	private void validateApplicationDocumentType(String clientId, String applDocTypes) {
		ListOfValues listOfValuesModel = new ListOfValues();
		listOfValuesModel.setClientId(Optional.of(clientId));
		listOfValuesModel.setTableName(Optional.of(TABLENAME));
		listOfValuesModel.setColumnName(Optional.of(LOVAPPLICABLEDOCTYPES));
		listOfValuesModel.setIsActive(true);
		listOfValuesModel.setFieldValue(Optional.of(applDocTypes));
		if (!listOfValuesService.isRecordExist(listOfValuesModel)) {
			throw new BusinessException("Appl Doc Types[" + applDocTypes + VALID);
		}
	}

	private void validateBusinessConstraintsForUpdate(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		validateTransactionType(agencyDetailsModel, agencyDetailsEntity);
		validateFrequencyList(agencyDetailsModel, agencyDetailsEntity);
		if (OptionalUtil.isPresent(agencyDetailsModel.getReportingType())
				&& !StringUtils.isEmpty(OptionalUtil.getValue(agencyDetailsModel.getReportingType()))) {
			validateReportingType(agencyDetailsModel, agencyDetailsEntity);
		}
		validateApplicationDocumentType(agencyDetailsModel, agencyDetailsEntity);

	}

	private LocalDate getEffectiveToDate(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(agencyDetailsModel.getEffectiveToDate())
				: agencyDetailsEntity.getEffectiveToDate();
	}

	private LocalDate getEffectiveFromDate(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(agencyDetailsModel.getEffectiveFromDate())
				: agencyDetailsEntity.getEffectiveFromDate();
	}

	private void validateApplicationDocumentType(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		if (OptionalUtil.isPresent(agencyDetailsModel.getClientId())
				|| OptionalUtil.isPresent(agencyDetailsModel.getApplDocTypes()))
			validateApplicationDocumentType(getClientId(agencyDetailsModel, agencyDetailsEntity),
					getApplDocTypes(agencyDetailsModel, agencyDetailsEntity));
	}

	private void validateReportingType(AgencyDetailsModel agencyDetailsModel, AgencyDetailsEntity agencyDetailsEntity) {
		validateReportingType(getClientId(agencyDetailsModel, agencyDetailsEntity),
				getReportingType(agencyDetailsModel, agencyDetailsEntity));
	}

	private void validateFrequencyList(AgencyDetailsModel agencyDetailsModel, AgencyDetailsEntity agencyDetailsEntity) {
		if (OptionalUtil.isPresent(agencyDetailsModel.getClientId())
				|| OptionalUtil.isPresent(agencyDetailsModel.getReportingFrequency()))
			validateFrequencyList(getClientId(agencyDetailsModel, agencyDetailsEntity),
					getReportingFrequency(agencyDetailsModel, agencyDetailsEntity));

	}

	private void validateTransactionType(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		if (OptionalUtil.isPresent(agencyDetailsModel.getClientId())
				|| OptionalUtil.isPresent(agencyDetailsModel.getTransactionType()))
			validateTransactionType(getClientId(agencyDetailsModel, agencyDetailsEntity),
					getTransactionType(agencyDetailsModel, agencyDetailsEntity));
	}

	private String getClientId(AgencyDetailsModel agencyDetailsModel, AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getClientId())
				? OptionalUtil.getValue(agencyDetailsModel.getClientId())
				: agencyDetailsEntity.getClientId();
	}

	private CharSequence getNetGrossFlag(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getNetGrossFlag())
				? OptionalUtil.getValue(agencyDetailsModel.getNetGrossFlag())
				: agencyDetailsEntity.getNetGrossFlag();
	}

	private CharSequence getCommissionFlag(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getCommissionFlag())
				? OptionalUtil.getValue(agencyDetailsModel.getCommissionFlag())
				: agencyDetailsEntity.getCommissionFlag();
	}

	private String getTransactionCurrency(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getTransactionCurrency())
				? OptionalUtil.getValue(agencyDetailsModel.getTransactionCurrency())
				: agencyDetailsEntity.getTransactionCurrency();
	}

	private String getAgencyCode(AgencyDetailsModel agencyDetailsModel, AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getAgencyCode())
				? OptionalUtil.getValue(agencyDetailsModel.getAgencyCode())
				: agencyDetailsEntity.getAgencyCode();
	}

	private String getApplDocTypes(AgencyDetailsModel agencyDetailsModel, AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getApplDocTypes())
				? OptionalUtil.getValue(agencyDetailsModel.getApplDocTypes())
				: agencyDetailsEntity.getApplDocTypes();
	}

	private String getReportingType(AgencyDetailsModel agencyDetailsModel, AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getReportingType())
				? OptionalUtil.getValue(agencyDetailsModel.getReportingType())
				: agencyDetailsEntity.getReportingType();
	}

	private String getReportingFrequency(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getReportingFrequency())
				? OptionalUtil.getValue(agencyDetailsModel.getReportingFrequency())
				: agencyDetailsEntity.getReportingFrequency();
	}

	private String getTransactionType(AgencyDetailsModel agencyDetailsModel, AgencyDetailsEntity agencyDetailsEntity) {
		return OptionalUtil.isPresent(agencyDetailsModel.getTransactionType())
				? OptionalUtil.getValue(agencyDetailsModel.getTransactionType())
				: agencyDetailsEntity.getTransactionType();
	}

	private void validateOverLap(AgencyDetailsModel agencyDetailsModel) {
		if (agencyDetailsDao.getOverLapRecordCount(
				OptionalUtil.getLocalDateValue(agencyDetailsModel.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(agencyDetailsModel.getEffectiveToDate()),
				OptionalUtil.getValue(agencyDetailsModel.getClientId()),
				OptionalUtil.getValue(agencyDetailsModel.getAgencyCode()), agencyDetailsModel.getTransactionType(),
				agencyDetailsModel.getTransactionCurrency(), agencyDetailsModel.getReportingFrequency()) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}
	}

	private void validateOverLapForUpdate(AgencyDetailsModel agencyDetailsModel,
			AgencyDetailsEntity agencyDetailsEntity) {
		String clientId = getClientId(agencyDetailsModel, agencyDetailsEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(agencyDetailsModel, agencyDetailsEntity);
		LocalDate effectiveToDate = getEffectiveToDate(agencyDetailsModel, agencyDetailsEntity);
		String agencyCode = getAgencyCode(agencyDetailsModel, agencyDetailsEntity);
		String transactionCurrency = getTransactionCurrency(agencyDetailsModel, agencyDetailsEntity);
		String transactionType = getTransactionType(agencyDetailsModel, agencyDetailsEntity);
		String reportingFrequency = getReportingFrequency(agencyDetailsModel, agencyDetailsEntity);
		if (!clientId.equalsIgnoreCase(agencyDetailsEntity.getClientId())
				|| !effectiveFromDate.equals(agencyDetailsEntity.getEffectiveFromDate())
				|| !effectiveToDate.equals(agencyDetailsEntity.getEffectiveToDate())
				|| !agencyCode.equalsIgnoreCase(agencyDetailsEntity.getAgencyCode())
				|| !transactionType.equalsIgnoreCase(agencyDetailsEntity.getTransactionType())
				|| !(validateType(agencyDetailsEntity.getReportingType()))) {
			long count = agencyDetailsDao.getOverLapRecordCount(effectiveFromDate, effectiveToDate, clientId,
					transactionCurrency, transactionType, agencyCode, reportingFrequency,
					agencyDetailsEntity.getAgencyDetailsId());
			if (count != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private void validateCommissionPercentage(Optional<String> commissionPercentage) {
		double commissionPer = Double.parseDouble(OptionalUtil.getValue(commissionPercentage));
		if (commissionPer >= 0 && commissionPer <= 100) {
			final Pattern pattern = Pattern.compile(PERCENTAGE_VALIDATE);
			String valueOf = String.valueOf(commissionPer);
			Matcher matcher = pattern.matcher(valueOf);
			boolean matches = matcher.matches();
			if (!matches) {
				throw new BusinessException("Invalid Commission Percentage");
			}
		} else {
			throw new BusinessException("Commission Percentage should be 0 to 100% only");
		}
	}

	private boolean validateType(String reportingType) {
		if (reportingType != null) {
			if (reportingType.equalsIgnoreCase(reportingType)) {
				return true;
			} else {
				return false;
			}
		}
		return true;
	}

}
