package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.StcokDetails;

@Repository
public interface StockDetailDao {

	List<StcokDetails> getBlockListedStockDetails(long documentNumber,Integer stockId);

	List<StcokDetails> getStockDetailByEffective(long documentNumber,Integer stockId, String clientId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate);
	
	String getMaxDocumentNumber(Integer stockId, String clientId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate);
	
	void deleteUnusedStock(Integer stockId, String clientId, String documentNumber, LocalDate effectiveFromDate,
			LocalDate effectiveToDate);
}
