package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.master.app.dao.AccountMasterDao;
import com.sgl.smartpra.master.app.dao.entity.MasAccountEntity;
import com.sgl.smartpra.master.app.dao.entity.MasScenarioEntity;
import com.sgl.smartpra.master.app.repository.AccountMasterRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AccountMasterDaoImpl<T> extends CommonSearchDao<T> implements AccountMasterDao {
	@Autowired
	private AccountMasterRepository accountMasterRepositiry;
	@Override
	public List<MasAccountEntity> findAll() {
		log.info("finding all MasAccountEntitys");
		return accountMasterRepositiry.findAll();
	}
	@Override
	public List<MasAccountEntity> findByAccountAlphaCode(String byAccountAlphaCode) {
		log.info("finding all MasAccountEntitys for by AccountAlphaCode{}",byAccountAlphaCode);
		return accountMasterRepositiry.findAllByAccountAlphaCode(byAccountAlphaCode);
	}
	

}
