package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.UATPDao;
import com.sgl.smartpra.master.app.dao.entity.UATPEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.UATPEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.UATPRepository;

@Component
public class UATPDaoImpl implements UATPDao {

	@Autowired
	private UATPRepository uatpRepository;

	@Override
	public List<UATPEntity> getListOfUATP(Optional<String> clientId, Optional<String> uatpRecType,
			Optional<String> issueCxr, Optional<String> operatingCxr, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate) {
		return uatpRepository.findAll(UATPEntitySpecification.search(clientId, uatpRecType, issueCxr, operatingCxr,
				effectiveFromDate, effectiveToDate));
	}

	@Override
	@Cacheable(value = "uatpModel", key = "#id")
	public Optional<UATPEntity> findById(Integer id) {
		return uatpRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "uatpModel", key = "#uatpEntity.uatpId") })
	public UATPEntity createUATP(UATPEntity uatpEntity) {
		return uatpRepository.save(uatpEntity);
	}

	@Override
	@CachePut(value = "uatpModel", key = "#uatpEntity.uatpId")
	public UATPEntity updateUATP(UATPEntity uatpEntity) {
		return uatpRepository.save(uatpEntity);
	}

	@Override
	public long getOverLapForCreate(Optional<String> clientId, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> issueCxr, Optional<String> operatingCxr) {
		return uatpRepository.count(Specification
				.where(UATPEntitySpecification.equalsClientId(OptionalUtil.getValue(clientId)))
				.and(UATPEntitySpecification.equalsIssueCxr(OptionalUtil.getValue(issueCxr)))
				.and(UATPEntitySpecification.equalsOperatingCxr(OptionalUtil.getValue(operatingCxr)))
				.and((UATPEntitySpecification
						.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate))
						.or(UATPEntitySpecification.betweenEffectiveFromAndEffectiveToDate(
								OptionalUtil.getLocalDateValue(effectiveToDate))))
										.or(UATPEntitySpecification
												.greaterThanOrEqualTo(OptionalUtil.getLocalDateValue(effectiveFromDate))
												.and(UATPEntitySpecification.lessThanOrEqualTo(
														OptionalUtil.getLocalDateValue(effectiveToDate))))));
	}

	@Override
	public long getOverLapForUpdate(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String issueCxr, String operatingCxr, Integer uatpId) {
		return uatpRepository.count(Specification.where(UATPEntitySpecification.equalsClientId(clientId))
				.and(UATPEntitySpecification.equalsIssueCxr(issueCxr))
				.and(UATPEntitySpecification.equalsOperatingCxr(operatingCxr))
				.and((UATPEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(UATPEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
								.or(UATPEntitySpecification.greaterThanOrEqualTo(effectiveFromDate)
										.and(UATPEntitySpecification.lessThanOrEqualTo(effectiveToDate))))
				.and(UATPEntitySpecification.notEqualsUatpId(uatpId)));
	}

}
