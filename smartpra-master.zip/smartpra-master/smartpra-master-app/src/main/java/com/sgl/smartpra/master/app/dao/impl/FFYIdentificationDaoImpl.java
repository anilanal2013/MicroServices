package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.FFYIdentificationDao;
import com.sgl.smartpra.master.app.dao.entity.FFYIdentificationEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.AgencyMasterEntitySpec;
import com.sgl.smartpra.master.app.dao.entity.spec.FFYIdentificationEntitySpecification;
import com.sgl.smartpra.master.app.dao.entity.spec.FOPEntitySpecification;
import com.sgl.smartpra.master.app.dao.entity.spec.POSEntitySpecification;
import com.sgl.smartpra.master.app.repository.FFYIdentificationRepository;

@Component
public class FFYIdentificationDaoImpl implements FFYIdentificationDao {

	@Autowired
	private FFYIdentificationRepository ffyIdentificationRepository;

	@Override
	public List<FFYIdentificationEntity> search(Optional<String> issueCxrCode, Optional<String> marketingCxrCode,
			Optional<String> operatingCxrCode, Optional<String> saleFromDate, Optional<String> saleToDate,
			Optional<Boolean> activate) {
		return ffyIdentificationRepository.findAll(FFYIdentificationEntitySpecification.search(issueCxrCode,
				marketingCxrCode, operatingCxrCode, saleFromDate, saleToDate, activate));
	}

	@Override
	public Optional<FFYIdentificationEntity> findById(Integer ffyIdentifyId) {
		return ffyIdentificationRepository.findById(ffyIdentifyId);
	}

	@Override
	public FFYIdentificationEntity update(FFYIdentificationEntity ffyIdentificationEntity) {
		return ffyIdentificationRepository.save(ffyIdentificationEntity);
	}

	@Override
	public FFYIdentificationEntity create(FFYIdentificationEntity ffyIdentificationEntity) {
		return ffyIdentificationRepository.save(ffyIdentificationEntity);
	}

	@Override
	public long saleVerifyIfOverlapExits(LocalDate saleFromDate, LocalDate saleToDate) {
		return ffyIdentificationRepository.count(Specification
				.where(FFYIdentificationEntitySpecification.betweenSaleFromAndSaleToDate(saleFromDate)
						.or(FFYIdentificationEntitySpecification.betweenSaleFromAndSaleToDate(saleToDate))
						.or(FFYIdentificationEntitySpecification.greaterThanOrEqualTo(saleFromDate)
								.and(FFYIdentificationEntitySpecification.lessThanOrEqualTo(saleToDate))))
				.and(FFYIdentificationEntitySpecification.isActive()));
	}

	@Override
	public long upLiftVerifyIfOverlapExits(LocalDate upliftFromDate, LocalDate upliftToDate) {
		return ffyIdentificationRepository
				.count(Specification
						.where(FFYIdentificationEntitySpecification.betweenUpliftFromAndUpliftoDate(upliftFromDate)
								.or(FFYIdentificationEntitySpecification.betweenUpliftFromAndUpliftoDate(upliftToDate))
								.or(FFYIdentificationEntitySpecification.greaterThanOrEqualToUpliftFrom(upliftFromDate)
										.and(FFYIdentificationEntitySpecification
												.lessThanOrEqualToUpliftTo(upliftToDate))))
						.and(FFYIdentificationEntitySpecification.isActive()));
	}

	@Override
	public long verifyIfSameSaleRecordExits(LocalDate saleFromDate, LocalDate saleToDate, Integer ffyIdentifyId) {
		return ffyIdentificationRepository.count(Specification
				.where(FFYIdentificationEntitySpecification.betweenSaleFromAndSaleToDate(saleFromDate)
						.or(FFYIdentificationEntitySpecification.betweenSaleFromAndSaleToDate(saleToDate))
						.or(FFYIdentificationEntitySpecification.greaterThanOrEqualTo(saleFromDate)
								.and(FFYIdentificationEntitySpecification.lessThanOrEqualTo(saleToDate))))
				.and(FFYIdentificationEntitySpecification.isActive())
				.and(FFYIdentificationEntitySpecification.notEqualsFfyIdentifyId(ffyIdentifyId)));
	}

	@Override
	public long verifyIfSameUpliftRecordExits(LocalDate upliftFromDate, LocalDate upliftToDate, Integer ffyIdentifyId) {
		return ffyIdentificationRepository
				.count(Specification
						.where(FFYIdentificationEntitySpecification.betweenUpliftFromAndUpliftoDate(upliftFromDate)
								.or(FFYIdentificationEntitySpecification.betweenUpliftFromAndUpliftoDate(upliftToDate))
								.or(FFYIdentificationEntitySpecification.greaterThanOrEqualToUpliftFrom(upliftFromDate)
										.and(FFYIdentificationEntitySpecification
												.lessThanOrEqualToUpliftTo(upliftToDate))))
						.and(FFYIdentificationEntitySpecification.isActive())
						.and(FFYIdentificationEntitySpecification.notEqualsFfyIdentifyId(ffyIdentifyId)));
	}

}
