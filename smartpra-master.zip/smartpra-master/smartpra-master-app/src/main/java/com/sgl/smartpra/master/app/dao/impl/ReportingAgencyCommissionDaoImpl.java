package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.master.app.dao.ReportingAgencyCommissionDao;
import com.sgl.smartpra.master.app.dao.entity.ReportingAgencyCommissionEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.ReportingAgencyCommissionEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.ReportingAgencyCommissionRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ReportingAgencyCommissionDaoImpl<T> extends CommonSearchDao<T> implements ReportingAgencyCommissionDao {

	@Autowired
	private ReportingAgencyCommissionRepository reportingAgencyCommissionRepository;

	@Override
	@Cacheable(value = "reportingAgencyCommId", key = "#id")
	public Optional<ReportingAgencyCommissionEntity> findById(Integer id) {
		log.info("Cacheable ReportingAgencyCommission Entity's ID= {}", id);
		return reportingAgencyCommissionRepository.findById(id);
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "reportingAgencyCommission", key = "#reportingAgencyCommissionEntity.reportingAgencyCommId") })
	public ReportingAgencyCommissionEntity create(ReportingAgencyCommissionEntity reportingAgencyCommissionEntity) {
		return reportingAgencyCommissionRepository.save(reportingAgencyCommissionEntity);
	}

	@Override
	@CachePut(value = "reportingAgencyCommission", key = "#reportingAgencyCommissionEntity.reportingAgencyCommId")
	public ReportingAgencyCommissionEntity update(ReportingAgencyCommissionEntity reportingAgencyCommissionEntity) {
		return reportingAgencyCommissionRepository.save(reportingAgencyCommissionEntity);
	}

	@Override
	public void delete(Integer id) {
		reportingAgencyCommissionRepository.deleteById(id);

	}

	@Override
	public List<ReportingAgencyCommissionEntity> searchReportingAgencyCommission(Optional<String> agencyCode,
			Optional<String> reportingAgency, Optional<Boolean> activate) {
		return reportingAgencyCommissionRepository
				.findAll(ReportingAgencyCommissionEntitySpecification.search(agencyCode, reportingAgency, activate));
	}

	@Override
	public long getOverlapRecordCount(String clientId, String reportingAgency, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, String agencyCode, String orcCurrency) {
		return reportingAgencyCommissionRepository
				.count(Specification.where(ReportingAgencyCommissionEntitySpecification.equalsClientId(clientId)
						.and(ReportingAgencyCommissionEntitySpecification.equalsReportingAgency(reportingAgency))
						.and((ReportingAgencyCommissionEntitySpecification
								.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate))
										.or(ReportingAgencyCommissionEntitySpecification
												.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
						.and(ReportingAgencyCommissionEntitySpecification.equalsAgencyCode(agencyCode))
						.and(ReportingAgencyCommissionEntitySpecification.equalsORCCurrency(orcCurrency))));
	}

	@Override
	public long getOverlapRecordCount(String clientId, String reportingAgency, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, String agencyCode, String orcCurrency, Integer reportingAgencyCommId) {
		return reportingAgencyCommissionRepository
				.count(Specification.where(ReportingAgencyCommissionEntitySpecification.equalsClientId(clientId)
						.and(ReportingAgencyCommissionEntitySpecification.equalsReportingAgency(reportingAgency))
						.and((ReportingAgencyCommissionEntitySpecification
								.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate))
										.or(ReportingAgencyCommissionEntitySpecification
												.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
						.and(ReportingAgencyCommissionEntitySpecification.equalsAgencyCode(agencyCode))
						.and(ReportingAgencyCommissionEntitySpecification.equalsORCCurrency(orcCurrency))
						.and(ReportingAgencyCommissionEntitySpecification
								.notEqualsReportingAgencyCommId(reportingAgencyCommId))));
	}

	@Override
	public Optional<ReportingAgencyCommissionEntity> findOne(Integer reportingAgencyCommId) {
		return reportingAgencyCommissionRepository.findById(reportingAgencyCommId);
	}

	@Override
	public List<ReportingAgencyCommissionEntity> searchReportingAgencyCommissionByAgencyId(Integer agencyId,
			Optional<String> agencyCode, Optional<String> reportingAgency, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> orcCurrency, Optional<Boolean> activate) {
		return reportingAgencyCommissionRepository.findAll(
				ReportingAgencyCommissionEntitySpecification.searchReportingAgencyCommissionByAgencyId(agencyId,
						agencyCode, reportingAgency, effectiveFromDate, effectiveToDate, orcCurrency, activate));
	}

}
