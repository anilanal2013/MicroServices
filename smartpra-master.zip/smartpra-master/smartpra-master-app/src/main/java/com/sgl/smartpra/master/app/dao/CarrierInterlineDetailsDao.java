package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.CarrierInterlineDetailsEntity;

@Repository
public interface CarrierInterlineDetailsDao {

	public CarrierInterlineDetailsEntity create(CarrierInterlineDetailsEntity carrierInterlineDetailsEntity);

	public CarrierInterlineDetailsEntity update(CarrierInterlineDetailsEntity carrierInterlineDetailsEntity);

	public List<CarrierInterlineDetailsEntity> search(Optional<String> carrierCode, Optional<String> effectiveDate);

	public Optional<CarrierInterlineDetailsEntity> findById(Integer carrierInterlineDtlId);

	public List<CarrierInterlineDetailsEntity> getCarrierCodeByCarrierCode(Optional<String> carrierCode);

	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String carrierCode);

	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String carrierCode, Integer carrierInterlineDtlId);

	public List<CarrierInterlineDetailsEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate,
			LocalDate effectiveToDate);

	public List<CarrierInterlineDetailsEntity> findAll(Optional<String> carrierCode,  Optional<String> clientId, Optional<String> effectiveDate);
	public Optional<CarrierInterlineDetailsEntity> find(Optional<String> carrierCode, Optional<String> effectiveDate);

	public List<CarrierInterlineDetailsEntity> findAllValidPassengerSis(
			Optional<String> carrierCode, Optional<Boolean> passengerSis,
			Optional<String> effectiveDate);

	public List<CarrierInterlineDetailsEntity> getCarrierInterlineDetailsByZoneAndEffectiveDate(Optional<String> clientId,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> zone);

}
