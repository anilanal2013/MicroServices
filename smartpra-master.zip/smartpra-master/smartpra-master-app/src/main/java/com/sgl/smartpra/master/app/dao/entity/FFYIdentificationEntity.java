package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_ffy_identification")
@Data
@DynamicInsert
@DynamicUpdate
@EqualsAndHashCode(callSuper = false)
public class FFYIdentificationEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ffy_identify_id")
	private Integer ffyIdentifyId;

	@Column(name = "priority")
	private Integer priority;

	@Column(name = "ffy_id")
	private String ffyId;

	@Column(name = "sale_from_date")
	private LocalDate saleFromDate;

	@Column(name = "sale_to_date")
	private LocalDate saleToDate;

	@Column(name = "uplift_from_date")
	private LocalDate upliftFromDate;

	@Column(name = "uplift_to_date")
	private LocalDate upliftToDate;

	@Column(name = "issue_cxr_code")
	private String issueCxrCode;

	@Column(name = "marketing_cxr_code")
	private String marketingCxrCode;

	@Column(name = "operating_cxr_code")
	private String operatingCxrCode;

	@Column(name = "include_fare_type")
	private String includeFareType;

	@Column(name = "exclude_fare_type")
	private String excludeFareType;

	@Column(name = "marketed_rbd_list")
	private String marketedRbdList;

	@Column(name = "operated_rbd_list")
	private String operatedRbdList;

	@Column(name = "area_fbw_indicator")
	private String areaFbwIndicator;

	@Column(name = "from_area")
	private String fromArea;

	@Column(name = "to_area")
	private String toArea;

	@Column(name = "fare_ticket")
	private String fareTicket;

	@Column(name = "source_code_gross_isc")
	private String sourceCodeGrossIsc;

	@Column(name = "source_code_tax")
	private String sourceCodeTax;

	@Column(name = "invoice_indicator")
	private String invoiceIndicator;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "client_id")
	private String clientId;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

	public String getIssueCxrCode() {

		if (issueCxrCode != null) {
			String trim = issueCxrCode.trim();
			return trim;
		}
		return issueCxrCode;
	}

	public void setIssueCxrCode(String issueCxrCode) {
		if (issueCxrCode != null) {
			this.issueCxrCode = issueCxrCode.trim();
		}
		this.issueCxrCode = issueCxrCode;
	}

	public String getMarketingCxrCode() {
		if (marketingCxrCode != null) {
			String trim = marketingCxrCode.trim();
			return trim;
		}
		return marketingCxrCode;
	}

	public void setMarketingCxrCode(String marketingCxrCode) {
		if (marketingCxrCode != null) {
			this.marketingCxrCode = marketingCxrCode.trim();
		}
		this.marketingCxrCode = marketingCxrCode;
	}

	public String getOperatingCxrCode() {
		if (operatingCxrCode != null) {
			String trim = operatingCxrCode.trim();
			return trim;
		}
		return operatingCxrCode;
	}

	public void setOperatingCxrCode(String operatingCxrCode) {
		if (operatingCxrCode != null) {
			this.operatingCxrCode = operatingCxrCode.trim();
		}
		this.operatingCxrCode = operatingCxrCode;
	}

	public String getIncludeFareType() {
		if (includeFareType != null) {
			String trim = includeFareType.trim();
			return trim;
		}
		return includeFareType;
	}

	public void setIncludeFareType(String includeFareType) {
		if (includeFareType != null) {
			this.includeFareType = includeFareType.trim();
		}
		this.includeFareType = includeFareType;
	}

	public String getExcludeFareType() {
		if (excludeFareType != null) {
			String trim = excludeFareType.trim();
			return trim;
		}
		return excludeFareType;
	}

	public void setExcludeFareType(String excludeFareType) {
		this.excludeFareType = excludeFareType;
	}

}
