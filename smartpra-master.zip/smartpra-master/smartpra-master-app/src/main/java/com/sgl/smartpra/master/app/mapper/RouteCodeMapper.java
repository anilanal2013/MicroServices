package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.RouteCodeEntity;
import com.sgl.smartpra.master.model.RouteCode;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface RouteCodeMapper extends BaseMapper<RouteCode, RouteCodeEntity> {

	RouteCodeEntity mapToEntity(RouteCode routeCode, @MappingTarget RouteCodeEntity routeCodeEntity);

	@Mapping(source = "routeCodeId", target = "routeCodeId", ignore = true)
	RouteCodeEntity mapToEntity(RouteCode routeCode);

}
