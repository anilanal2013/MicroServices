package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.JobDao;
import com.sgl.smartpra.master.app.dao.entity.JobEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.JobEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.JobRepository;
import com.sgl.smartpra.master.model.Job;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JobDaoImpl implements JobDao {
	@Autowired
	private JobRepository jobRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "job", key = "#jobEntity.jobId") })
	public JobEntity create(JobEntity jobEntity) {
		return jobRepository.save(jobEntity);
	}

	@Override
	@CachePut(value = "job", key = "#jobEntity.jobId")
	public JobEntity update(JobEntity jobEntity) {
		return jobRepository.save(jobEntity);
	}

	@Override
	@Cacheable(value = "job", key = "#jobId")
	public Optional<JobEntity> findById(Integer jobId) {
		log.info("Cacheable JobEntity's ID= {}", jobId);
		return jobRepository.findById(jobId);
	}

	@Override
	public List<JobEntity> search(Job job) {
		return jobRepository.findAll(
				JobEntitySpecification.search(job));
	}
	
	@Override
	public List<JobEntity> getAllJobByEffectiveDate(Optional<String> effectiveFromDate) {
		return jobRepository.findAll(
				JobEntitySpecification.searchByEffectiveDate(effectiveFromDate));
	}

	@Override
	public long getOverLapForCreate(String jobName, String clientId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return jobRepository.count(Specification.where(JobEntitySpecification.equalsJobName(jobName))
				.and(JobEntitySpecification.equalsClientId(clientId))
				.and((JobEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(JobEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.or((JobEntitySpecification.greaterThanOrEqualToEffectiveFromDate(effectiveFromDate)
						.and(JobEntitySpecification.lessThanOrEqualToEffectiveToDate(effectiveToDate)))))
						);
	}

	@Override
	public long getOverLapForUpdate(String jobName, String clientId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, Integer jobId) {
		return jobRepository.count(Specification.where(JobEntitySpecification.equalsJobName(jobName))
				.and(JobEntitySpecification.equalsClientId(clientId))
				.and(JobEntitySpecification.notEqualsJobId(jobId))
				.and((JobEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(JobEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.or((JobEntitySpecification.greaterThanOrEqualToEffectiveFromDate(effectiveFromDate)
				.and(JobEntitySpecification.lessThanOrEqualToEffectiveToDate(effectiveToDate)))))
	);

	}
}