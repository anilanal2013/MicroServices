package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.AccountingDefinitionEntity;

@Repository
public interface AccountingDefinitionDao {

	Optional<AccountingDefinitionEntity> findById(Integer accountDefinitionIdentifier);

	List<AccountingDefinitionEntity> search(Optional<String> componentIdentifier, Optional<String> conversionDateUse);
	
	List<AccountingDefinitionEntity> searchWithIsActiveParam(Optional<String> componentIdentifier, Optional<String> conversionDateUse,
			Optional<Boolean> activate);

	AccountingDefinitionEntity create(AccountingDefinitionEntity mapToEntity);

	AccountingDefinitionEntity update(AccountingDefinitionEntity mapToEntity);

	long verifyAttributeMaster(String accountingAttributesMaster, String accountingAttributes);

	long getOverLapRecordCount(String accountCodeAlpha, String componentIdentifier, String clientId,
			String conversionDateUse);

	long getOverLapRecordCount(String accountCodeAlpha, String componentIdentifier, String clientId,
			String conversionDateUse, Integer accountDefinitionIdentifier);

	AccountingDefinitionEntity getListOfAccountingDefByAccountAphaCodeAndAccountDef(Integer accountDefinitionIdentifier,
			String accountCodeAlpha);
	public List<String> getAccountAttrMasterTabs();
	
	public List<String> getAccountAttrColumns();
	
	public List<Integer> getAccountDefinitionIdentifierFromAccountDefinitionMaster();

	public List<String> getAccountAlphaCodeFromAccountDefinitionMaster();
}
