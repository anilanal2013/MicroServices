package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.ProrationHighLowQcEntity;
import com.sgl.smartpra.master.model.ProrationHighLowQc;

@Repository
public interface ProrationHighLowQcDao {

	public Optional<ProrationHighLowQcEntity> getProrationHighLowIdById(Integer highLowQcId);

	public List<ProrationHighLowQcEntity> getAllProrationHighLowQc(Optional<String> clientId,ProrationHighLowQc hl);

	public ProrationHighLowQcEntity createProrationHighLowQc(ProrationHighLowQcEntity prorationHighLowQcEntity);

	public long getOverlapRecordCountForCreate(String clientId, String highLowId, String qcField,
			LocalDate effectiveFromDate, LocalDate effectiveToDate);

	public Optional<ProrationHighLowQcEntity> findById(Integer prorationHighLowQcId);

	public ProrationHighLowQcEntity updateProrationHighLowQc(ProrationHighLowQcEntity prorationHighLowQcEntity);

	public long getOverlapRecordCountForCreate(String clientId, String highLowId, String qcField,
			LocalDate effectiveFromDate, LocalDate effectiveToDate, Integer lowHighQcId);

	public long getCount(ProrationHighLowQcEntity mapToEntity);

	public Page<ProrationHighLowQcEntity> getData(ProrationHighLowQcEntity mapToEntity, Pageable pageable);

	public List<ProrationHighLowQcEntity> searchHighLow(Optional<String> date);

}
