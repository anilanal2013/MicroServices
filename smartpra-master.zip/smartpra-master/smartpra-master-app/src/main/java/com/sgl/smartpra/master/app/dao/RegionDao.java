package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.app.dao.entity.RegionEntity;
import com.sgl.smartpra.master.model.Region;

public interface RegionDao {

	public Optional<RegionEntity> findById(Integer regionId);

	public RegionEntity create(RegionEntity regionEntity);

	public RegionEntity update(RegionEntity regionEntity);

	public List<RegionEntity> getAllRegion(Region region, Optional<String> exceptionCall);

	public long getOverLapRecordCount(Optional<String> regionCode, Optional<String> clientId);

	public List<RegionEntity> getAllRegion(Optional<String> regionCode, Optional<String> regionName,
			Optional<String> continentName, Optional<Boolean> isActive);

	public long getOverLapRecordCount(String regionCode, String clientId, Integer id);

	List<RegionEntity> findAllRegionList();

	List<RegionEntity> findAllRegionListForUpdate(Integer regionId, Boolean isActive);

}
