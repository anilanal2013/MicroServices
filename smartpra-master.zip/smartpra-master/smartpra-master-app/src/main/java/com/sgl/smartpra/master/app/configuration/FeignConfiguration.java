package com.sgl.smartpra.master.app.configuration;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.model.FlightDataDetails;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.CarrierDetail;
import com.sgl.smartpra.global.master.model.ChargeCategory;
import com.sgl.smartpra.global.master.model.ChargeCode;
import com.sgl.smartpra.global.master.model.Country;
import com.sgl.smartpra.global.master.model.Currency;
import com.sgl.smartpra.global.master.model.StandardArea;
import com.sgl.smartpra.integration.model.CurrencyRateIn;
import com.sgl.smartpra.integration.model.CurrencyRateOut;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-global-master-app")
	public interface GlobalMasterFeignClient {

		@GetMapping("/countries/{countryCode}")
		public Country getCountryByCountryCode(@PathVariable(value = "countryCode") String countryCode);

		@GetMapping("/carriers")
		public List<Carrier> getAllCarrier(
				@RequestParam(value = "carrierCode", required = false) @Valid String carrierCode,
				@RequestParam(value = "carrierDesignatorCode", required = false) String carrierDesignatorCode,
				@RequestParam(value = "carrierName1", required = false) String carrierName1,
				@RequestParam(value = "carrierName2", required = false) String carrierName2,
				@RequestParam(value = "isActive", required = false) Boolean isActive);

		@GetMapping("/carriers/carrierDesignatorCode/validate/{carrierDesignatorCode}")
		public boolean isValidCarrierDesignatorCode(
				@PathVariable("carrierDesignatorCode") String carrierDesignatorCode);

		@GetMapping("/carriers/carrierDesignatorCodeList/validate/{carrierDesignatorCode}")
		public boolean isValidCarrierDesignatorCodeList(
				@PathVariable("carrierDesignatorCode") String carrierDesignatorCode);

		@GetMapping("/carriers/getCarrierDesignatorCode/{carrierDesignatorCode}")
		public Integer countCarrrierByCarrierDesignatorCode(
				@PathVariable(value = "carrierDesignatorCode", required = true) List<String> carrierDesignatorCode);

		@GetMapping("/carriers/{carrierCode}")
		public Carrier getCarrierByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode);

		@GetMapping("/airports/{airportCode}/validate")
		public boolean isValidAirportCodeOrCityCode(@PathVariable(value = "airportCode") String airportCode);

		@GetMapping("/airports/{cityCode}/isValidCityCode")
		public boolean isValidCityCode(@PathVariable(value = "cityCode") String cityCode);

		@GetMapping("/airports/{airportCode}/isValidAirportCode")
		public boolean isValidAirportCode(@PathVariable(value = "airportCode") String airportCode);

		@GetMapping("/standard-areas/{standardAreaCode}")
		public StandardArea getStandardAreaByStandardAreaCode(
				@PathVariable(value = "standardAreaCode") String standardAreaCode);

		@GetMapping("/standard-areas/area-validate/{standardAreaCode}")
		public Boolean getActiveStandardAreaByStandardAreaCode(
				@PathVariable(value = "standardAreaCode") String standardAreaCode);

		@GetMapping("/standard-areas/validate/{standardAreaCode}")
		public boolean validateStandardArea(@PathVariable(value = "standardAreaCode") String standardAreaCode);

		@GetMapping("/airports/{stateCode}/isValid")
		public boolean isValidStateCode(@PathVariable(value = "stateCode") String stateCode);

		@GetMapping("/carriers/{carrierCode}/validate")
		public boolean validateCarrierCode(@Valid @PathVariable(value = "carrierCode") String carrierCode);

		@GetMapping("/currencies/{currencyCode}/validate")
		public boolean validateCurrencyCode(@PathVariable(value = "currencyCode") String currencyCode);

		@PostMapping("/carriers/validate")
		public List<String> validateCarrrierCodeList(List<String> carrierCodeList);

		@PostMapping("/currencies/validate")
		public List<String> validateCurrencyCodeList(List<String> currencyCodeList);

		@GetMapping("/countries/validate/{countryCode}")
		public boolean validateCountryCode(@PathVariable(value = "countryCode") String countryCode);

		@PostMapping("/countries/validate")
		public List<String> getValidateCountryCodeList(List<String> countryCodeList);

		@GetMapping("/fbtd-elementsvalue/{elementCode}")
		public boolean getFBTDElementByElementCode(@PathVariable(value = "elementCode") String elementCode);

		@PostMapping("/user-area/insert")
		public void clientSpecificUserAreaInsertOrUpdate(Map<String, String> map);

		@GetMapping("/user-area/validate/{areaCode}")
		public boolean isAreaCode(@PathVariable(value = "areaCode") String areaCode);

		@GetMapping("/fbtd-elementsvalue/{elementCode}/{elementType}")
		public boolean getFBTDElementByElementCodeBasedOnPrimeCode(
				@PathVariable(value = "elementCode") String elementCode,
				@PathVariable(value = "elementType") String elementType);

		@GetMapping("/fbtd-element-cabin/{cabin}")
		public Boolean validateCabin(@PathVariable(value = "cabin") String cabin);

		@GetMapping("/fbtd-element-iataFareType/{iataFareType}")
		public boolean validateIATAFareType(@PathVariable(value = "iataFareType") String iataFareType);

		@GetMapping("/fbtd-element-seasonal/{seasonalCode}")
		public boolean validateSeasonalCode(@PathVariable(value = "seasonalCode") String seasonalCode);

		@GetMapping("/fbtd-element-dayOfWeek/{dayOfWeek}")
		public boolean validateDayOfWeek(@PathVariable(value = "dayOfWeek") String dayOfWeek);

		@GetMapping("/fbtd-element-discountCode/{discountCode}")
		public boolean validateDiscountCode(@PathVariable(value = "discountCode") String discountCode);

		@GetMapping("/fbtd-element-journeyType/{journeyType}")
		public boolean validateJourneyType(@PathVariable(value = "journeyType") String journeyType);

		@GetMapping("/fbtd-element-zedidentifier/{zedIdentifier}")
		public boolean validateZedIdentifier(@PathVariable(value = "zedIdentifier") String zedIdentifier);

		@GetMapping("/currencies")
		public List<Currency> getAllcurrencies(
				@RequestParam(value = "currencyCode", required = false) String currencyCode,
				@RequestParam(value = "currencyName", required = false) String currencyName,
				@RequestParam(value = "isActive", required = false) Boolean isActive);

		@GetMapping("/airports")
		public List<Airport> getAllAirport(@RequestParam(value = "airportCode", required = false) String airportCode,
				@RequestParam(value = "airportName", required = false) String airportName,
				@RequestParam(value = "cityCode", required = false) String cityCode,
				@RequestParam(value = "cityName", required = false) String cityName,
				@RequestParam(value = "countryCode", required = false) String countryCode);

		@GetMapping("/system-parameters/clientId/{clientId}/parameterName/{parameterName}")
		public String getSystemParameterRangeByparameterNameAndClientId(
				@PathVariable(value = "parameterName") String parameterName,
				@PathVariable(value = "clientId") String clientId);

		@GetMapping("/carriers/active-carrierCode")
		public Carrier getActiveCarrierByCarrierCode(
				@RequestParam(value = "carrierCode", required = true) String carrierCode);

		@GetMapping("/carriers/details/carrierType/{carrierCode}/{effectiveDate}")
		public CarrierDetail getCarrierTypeByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode,
				@PathVariable(value = "effectiveDate") String effectiveDate);

		@GetMapping("charge-categories/{chargeCategoryCode}")
		public ChargeCategory getChargeCategoryByChargeCategoryCode(
				@PathVariable(value = "chargeCategoryCode") String chargeCategoryCode);

		@GetMapping("/charge-categories/{chargeCategoryCode}/charge-codes/{chargeCode}")
		public ChargeCode getChargeCodeByChargeCode(
				@PathVariable(value = "chargeCategoryCode") String chargeCategoryCode,
				@PathVariable(value = "chargeCode") String chargeCode);
		
		@GetMapping("/charge-categories/account-scenario")
		public List<String> getChargeCatCodeFromChargeCatMaster();

		@GetMapping("/charge-codes/account-scenario")
		public List<String> getChargeCodeFromChargeCodeMaster();


	}

	@FeignClient(value = "smartpra-yqyr-global-app")
	public interface YQYRGlobalMasterFeignClient {

		@GetMapping("/fare-type-atpco/{atpcoFareType}")
		public boolean validateAtpcoFareType(@PathVariable(value = "atpcoFareType") String atpcoFareType);

		@GetMapping("/fare-type-paxType/{paxType}")
		public boolean validatePAXtype(@PathVariable(value = "paxType") String paxType);

	}

	@FeignClient(value = "smartpra-batch-global-app")
	public interface BatchGlobalMasterFeignClient {

		@PutMapping("/master-audit")
		public void updateMasterAudit(@RequestParam(value = "newObj") Object newObj,
				@RequestParam(value = "oldObj") Object oldObj, @RequestParam(value = "tableName") String tableName,
				@RequestParam(value = "serviceName") String serviceName);

	}

	@FeignClient(value = "smartpra-flown-app")
	public interface FlownMasterFeignClient {

		@GetMapping("/flight-data-details")
		public List<FlightDataDetails> getAllFlightDataDetails(
				@RequestParam(value = "flightNumber", required = false) String flightNumber,
				@RequestParam(value = "fromAirport", required = false) String fromAirport,
				@RequestParam(value = "toAirport", required = false) String toAirport,
				@RequestParam(value = "flightStatus", required = false) String flightStatus);
	}
	
		@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface ExchangeRateFeignClient {
		@PostMapping("/integ/erd")
		public CurrencyRateOut getExchangeRate(@Validated @RequestBody CurrencyRateIn currencyRateIn);
		
		@PostMapping("/api/init-exceptionmessage")
		public void initExceptionTrasaction(@RequestBody ExceptionTransactionModel exceptionTransactionModel);
	}
}
