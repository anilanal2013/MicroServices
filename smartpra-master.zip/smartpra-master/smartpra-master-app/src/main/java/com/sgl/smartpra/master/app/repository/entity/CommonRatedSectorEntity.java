package com.sgl.smartpra.master.app.repository.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_common_rated_sector")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class CommonRatedSectorEntity extends BaseEntity {

    @Id
    @Column(name = "common_rated_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer commonRatedID;

    @Column(name = "client_id", nullable = true, length = 3)
    private String clientId;

    @Column(name = "from_airport", nullable = true, length = 3)
    private String fromAirport;

    @Column(name = "to_airport", nullable = true, length = 3)
    private String toAirport;

    @Column(name = "common_rated_from_airport", nullable = true, length = 3)
    private String commonRatedFromAirport;

    @Column(name = "common_rated_to_airport", nullable = true, length = 3)
    private String commonRatedToAirport;

    @Column(name = "effective_from_date", nullable = false)
   // @Temporal(TemporalType.DATE)
    private LocalDate effectiveFromDate;

    @Column(name = "effective_to_date", nullable = false)
    //@Temporal(TemporalType.DATE)
    private LocalDate effectiveToDate;

    @Column(name = "remarks", nullable = false)
    private String remarks;

    @PrePersist
    public void setCreatedDate() {
        setCreatedDate(LocalDateTime.now());
    }

    @PreUpdate
    public void setLastUpdatedDate() {
        setLastUpdatedDate(LocalDateTime.now());
    }
}
