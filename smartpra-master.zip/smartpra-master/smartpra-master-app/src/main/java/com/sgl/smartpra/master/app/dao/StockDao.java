package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.StockEntity;

@Repository
public interface StockDao {

	public List<StockEntity> search(Optional<String> documentSeriesFrom, Optional<String> documentSeriesTo,
			Optional<String> documentType, Optional<String> clientId, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate);

	public Optional<StockEntity> findById(Integer stockId);
	
	public List<StockEntity> findByListStockId(Integer stockId);

	public StockEntity create(StockEntity stockEntity);

	public StockEntity update(StockEntity mapToEntity);

	// -- This is for Create- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String documentSeriesFrom,
			String documentSeriesTo, String clientId, String documentType);

	public List<StockEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	// -- This is for Update- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String documentSeriesFrom,
			String documentSeriesTo, String clientId, String documentType, Integer stockId);

	public List<StockEntity> verifyIfOverlapForDocumentSeriesExists(LocalDate effectiveFromDate,
			LocalDate effectiveToDate, Optional<String> documentSeriesFrom, Optional<String> documentSeriesTo);
}
