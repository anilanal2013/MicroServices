package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sgl.smartpra.master.app.dao.entity.HandlingFeeEntity;

@Service
public interface HandlingFeeDao {

	List<HandlingFeeEntity> getAllHandlingFee(Optional<String> issueCxr, Optional<String> operatingCxr,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	Optional<HandlingFeeEntity> findById(Integer handlingFeeId);

	HandlingFeeEntity createHandlingFee(HandlingFeeEntity handlingFeeEntity);

	HandlingFeeEntity updateHandlingFee(HandlingFeeEntity handlingFeeEntity);

	long getOverLapForCreate(Optional<String> clientId, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> salesSource, Optional<String> issueCxr,
			Optional<String> operatingCxr, Optional<String> couponFromArea, Optional<String> couponToArea);

	long getOverLapForUpdate(String clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String salesSource, String issueCxr, String operatingCxr, String couponFromArea, String couponToArea,
			Integer handlingFeeId);

}
