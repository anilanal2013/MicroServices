package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.ReasonCodeService;
import com.sgl.smartpra.master.model.ReasonCode;

@RestController
public class ReasonCodeController {

	@Autowired
	private ReasonCodeService reasonCodeService;

	@GetMapping("/reason-codes/clientId/{clientId}")
	public List<ReasonCode> getAllReasonCode(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "reasonType", required = false) Optional<String> reasonType,
			@RequestParam(value = "reasonCategory", required = false) Optional<String> reasonCategory,
			@RequestParam(value = "isCpnBreakdownMandatory", required = false) Optional<String> isCpnBreakdownMandatory,
			@RequestParam(value = "isActive", required = false) Optional<Boolean> isActive) {
		return reasonCodeService.getListOfReasonCode(clientId, reasonType, reasonCategory, isCpnBreakdownMandatory, isActive);
	}

	@GetMapping("/reason-codes/{reasonCodeId}")
	public ReasonCode getReasonCodeByReasonCodeId(@PathVariable(value = "reasonCodeId") Integer reasonCodeId) {
		return reasonCodeService.getReasonCodeByReasonCodeId(reasonCodeId);
	}

	@PostMapping("/reason-codes")
	public ReasonCode createReasonCode(@Validated(Create.class) @RequestBody ReasonCode reasonCode) {
		return reasonCodeService.createReasonCode(reasonCode);
	}

	@PutMapping("reason-codes/{reasonCodeId}")
	public ReasonCode updateReasonCode(@PathVariable(value = "reasonCodeId") Integer reasonCodeId,
			@Validated(Update.class) @RequestBody ReasonCode reasonCode) {
		return reasonCodeService.updateReasonCode(reasonCodeId, reasonCode);
	}

	@PutMapping("reason-codes/{reasonCodeId}/activate")
	public void activateReasonCode(@Valid @PathVariable(value = "reasonCodeId") Integer reasonCodeId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		reasonCodeService.activateReasonCode(reasonCodeId, lastUpdatedBy);
	}

	@PutMapping("reason-codes/{reasonCodeId}/deactivate")
	public void deactivateReasonCode(@Valid @PathVariable(value = "reasonCodeId") Integer reasonCodeId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		reasonCodeService.deactivateReasonCode(reasonCodeId, lastUpdatedBy);
	}

	@GetMapping("/reason-codes/reason-code/{reasonCode}")
	public ReasonCode getReasonCodeByReasonCode(@PathVariable(value = "reasonCode") String reasonCode) {
		return reasonCodeService.getReasonCodeByReasonCode(reasonCode);
	}
}
