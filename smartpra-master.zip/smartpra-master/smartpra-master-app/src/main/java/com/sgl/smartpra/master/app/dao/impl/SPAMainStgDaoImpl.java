package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.SPAMainStgDao;
import com.sgl.smartpra.master.app.dao.entity.SPAMainStgEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.SPAMainStgEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.SPAMainStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SPAMainStgDaoImpl implements SPAMainStgDao {

	@Autowired
	private SPAMainStgRepository spaMainStgRepository;

	@Override
	@Cacheable(value = "spaMainStg", key = "#spaMainId")
	public Optional<SPAMainStgEntity> findById(Integer spaMainId) {
		log.info("Cacheable SPA Main Entity's ID= {}", spaMainId);
		return spaMainStgRepository.findById(spaMainId);
	}

	@Override
	@Cacheable(value = "spaMainStg", key = "#spaKey")
	public List<SPAMainStgEntity> findBySpaKey(Optional<Integer> spaKey) {
		log.info("Cacheable SPA Main Entity's SPA Key= {}", spaKey);
		return spaMainStgRepository.findAll(SPAMainStgEntitySpecification.findBySpaKey(spaKey));
	}
	
	@Override
	@Cacheable(value = "spaAllMainStg", key = "#spaMainId")
	public List<SPAMainStgEntity> findAllMainDataBySpaMainId(Optional<Integer> spaMainId) {
		log.info("Cacheable SPA Main Entity's SPA MainId = {}", spaMainId);
		return spaMainStgRepository.findAllMainDataBySpaMainId(spaMainId);	
	}

	@Override
	public List<SPAMainStgEntity> findBySpaKeyAndClientId(Optional<Integer> spaKey, Optional<String> clientId) {
		return spaMainStgRepository.findAll(SPAMainStgEntitySpecification.search(spaKey,clientId));
	}
}
