package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_job")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class JobEntity extends BaseEntity {
	
	@Id
	@Column(name = "job_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer jobId;  
	
	@Column(name = "client_id", nullable = false)
	private String clientId;
	
	@Column(name = "job_name", nullable = false)
	private String jobName;
	
	@Column(name = "job_type", nullable = false)
	private String jobType;
	
	@Column(name = "module_name", nullable = false)
	private String moduleName; 
	
	@Column(name = "category", nullable = false)
	private String category;
	
	@Column(name = "frequency", nullable = false)
	private String frequency;
	
	@Column(name = "delay", nullable = true)
	private Integer delay;  
	
	@Column(name = "sequence", nullable = true)
	private Integer sequence; 
	
	@Column(name = "parameter_1", nullable = false)
	private String parameter1;
	
	@Column(name = "parameter_2", nullable = false)
	private String parameter2;
	
	@Column(name = "parameter_3", nullable = false)
	private String parameter3; 
	
	@Column(name = "parameter_4", nullable = false)
	private String parameter4; 
	
	@Column(name = "skip_indicator", nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean skipIndicator;
	
	@Column(name = "time_limit_indicator", nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean timeLimitIndicator; 
	
	@Column(name = "rolling_display_indicator", nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean rollingDisplayIndicator;  
	
	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;
	
	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;
}
