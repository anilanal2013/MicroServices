package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.CarrierAllianceDao;
import com.sgl.smartpra.master.app.dao.entity.CarrierAllianceEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.CarrierAllianceEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.CarrierAllianceRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CarrierAllianceDaoImpl implements CarrierAllianceDao {

	@Autowired
	private CarrierAllianceRepository carrierAllianceRepository;

	@Override
	@Cacheable(value = "carrierAlliance", key = "#id")
	public Optional<CarrierAllianceEntity> findById(Integer id) {
		log.info("Cacheable CarrierAlliance Entity's ID = {}", id);
		return carrierAllianceRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "carrierAlliance", key = "#carrierAllianceEntity.carrierAllianceDtlId"),	@CacheEvict(value = "carrierAllianceSearch", allEntries = true) , 
			@CacheEvict(value = "clientId", allEntries = true),	@CacheEvict(value = "carrierCode", allEntries = true),
			@CacheEvict(value = "effectiveDate", allEntries = true)})
	public CarrierAllianceEntity create(CarrierAllianceEntity carrierAllianceEntity) {
		return carrierAllianceRepository.save(carrierAllianceEntity);
	}

	@Override
	@CachePut(value = "carrierAlliance", key = "#carrierAllianceEntity.carrierAllianceDtlId")
	@Caching(evict = { @CacheEvict(value = "carrierAllianceSearch", allEntries = true) , 
			@CacheEvict(value = "clientId", allEntries = true),	@CacheEvict(value = "carrierCode", allEntries = true),
			@CacheEvict(value = "effectiveDate", allEntries = true)})
	public CarrierAllianceEntity update(CarrierAllianceEntity carrierAllianceEntity) {
		return carrierAllianceRepository.save(carrierAllianceEntity);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "carrierAlliance", key = "#id"),	@CacheEvict(value = "carrierAllianceSearch", allEntries = true) , 
			@CacheEvict(value = "clientId", allEntries = true),	@CacheEvict(value = "carrierCode", allEntries = true),
			@CacheEvict(value = "effectiveDate", allEntries = true)})
	public void delete(Integer id) {
		carrierAllianceRepository.deleteById(id);
	}

	@Override
	public List<CarrierAllianceEntity> findAll(String clientId) {
		return carrierAllianceRepository
				.findAll(Specification.where(CarrierAllianceEntitySpecification.equalsClientId(clientId)));
	}

	@Override
	@Cacheable(value = "carrierAllianceSearch", key = "#carrierCode")
	public List<CarrierAllianceEntity> search(String carrierCode) {
		return carrierAllianceRepository
				.findAll(Specification.where(CarrierAllianceEntitySpecification.equalsCarrierCode(carrierCode))
						.and(CarrierAllianceEntitySpecification.isActive()));
	}

	@Override
	public List<CarrierAllianceEntity> search(String carrierCode, LocalDate effectiveDate) {
		return carrierAllianceRepository
				.findAll(Specification.where(CarrierAllianceEntitySpecification.equalsCarrierCode(carrierCode))
						.and(CarrierAllianceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveDate))
						.and(CarrierAllianceEntitySpecification.isActive()));
	}

	@Override
	public List<CarrierAllianceEntity> search(String allianceName, String clientId) {
		return carrierAllianceRepository
				.findAll(Specification.where(CarrierAllianceEntitySpecification.equalsAllianceName(allianceName))
						.and(CarrierAllianceEntitySpecification.equalsClientId(clientId))
						.and(CarrierAllianceEntitySpecification.isActive()));
	}

	@Override
	public List<CarrierAllianceEntity> search(String allianceName, String clientId, LocalDate effectiveDate) {
		return carrierAllianceRepository
				.findAll(Specification.where(CarrierAllianceEntitySpecification.equalsAllianceName(allianceName))
						.and(CarrierAllianceEntitySpecification.equalsClientId(clientId))
						.and(CarrierAllianceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveDate))
						.and(CarrierAllianceEntitySpecification.isActive()));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String allianceName,
			String carrierCode, String clientId) {
		return carrierAllianceRepository.count(Specification
				.where(CarrierAllianceEntitySpecification.equalsAllianceName(allianceName))
				.and(CarrierAllianceEntitySpecification.equalsCarrierCode(carrierCode))
				.and(CarrierAllianceEntitySpecification.equalsClientId(clientId))
				.and(CarrierAllianceEntitySpecification.isActive())
				.and(CarrierAllianceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
					.or(CarrierAllianceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
					.or(CarrierAllianceEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate))));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String allianceName,
			String carrierCode, String clientId, Integer carrierAllianceDtlId) {
		return carrierAllianceRepository.count(Specification
				.where(CarrierAllianceEntitySpecification.equalsAllianceName(allianceName))
				.and(CarrierAllianceEntitySpecification.equalsCarrierCode(carrierCode))
				.and(CarrierAllianceEntitySpecification.equalsClientId(clientId))
				.and(CarrierAllianceEntitySpecification.isActive())
				.and(CarrierAllianceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(CarrierAllianceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.or(CarrierAllianceEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate)))
				.and(CarrierAllianceEntitySpecification.notEqualsCarrierAllianceDtlId(carrierAllianceDtlId)));
	}

	@Override
	public List<CarrierAllianceEntity> search(Optional<String> carrierCode, Optional<String> clientId,
			Optional<String> allianceName, Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return carrierAllianceRepository
				.findAll(CarrierAllianceEntitySpecification.search(carrierCode, clientId,allianceName, effectiveFromDate, effectiveToDate));
	}

	@Override
	@Cacheable(cacheNames={"clientId","carrierCode","effectiveDate"})
	public Optional<CarrierAllianceEntity> getAllianceByCarrierCodeAndEffectiveDate(String clientId, String carrierCode,
			Optional<String> effectiveDate) {
		return carrierAllianceRepository.findOne(CarrierAllianceEntitySpecification.equalsClientId(clientId)
				.and(CarrierAllianceEntitySpecification.equalsCarrierCode(carrierCode))
				.and(CarrierAllianceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveDate)))
				.and(CarrierAllianceEntitySpecification.isActive()));
	}

}
