package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.FareBasisTranslationDao;
import com.sgl.smartpra.master.app.dao.entity.FareBasisTranslationEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.FareBasisTranslationEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.FareBasisTranslationRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FareBasisTranslationDaoImpl<T> extends CommonSearchDao<T> implements FareBasisTranslationDao {

	@Autowired
	FareBasisTranslationRepository fareBasisTranslationRepository;

	// Create
	@Override
	@Caching(evict = { @CacheEvict(value = "fareBasisTranslation", key = "#fareBasisTranslationEntity.fbtId") })
	public FareBasisTranslationEntity create(FareBasisTranslationEntity fareBasisTranslationEntity) {
		return fareBasisTranslationRepository.save(fareBasisTranslationEntity);
	}

	// Update
	@Override
	@CachePut(value = "fareBasisTranslation", key = "#fareBasisTranslationEntityUpdated.fbtId")
	public FareBasisTranslationEntity update(FareBasisTranslationEntity fareBasisTranslationEntityUpdated) {
		return fareBasisTranslationRepository.save(fareBasisTranslationEntityUpdated);
	}

	// FindBy Id....
	@Override
	@Cacheable(value = "fareBasisTranslation", key = "#fbtId")
	public Optional<FareBasisTranslationEntity> findById(Integer fbtId) {
		return fareBasisTranslationRepository.findById(fbtId);
	}

	@Override
	public List<FareBasisTranslationEntity> getFareBasisTranslationResult(Optional<String> marketingFareBasis,
			Optional<String> marketingTD, Optional<String> fareOwnerCXR, Optional<String> effectiveDate) {
		return fareBasisTranslationRepository.findAll(FareBasisTranslationEntitySpecification.search(marketingFareBasis,
				marketingTD, fareOwnerCXR, effectiveDate));
	}

	@Override
	public int verifyIfOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return (int) fareBasisTranslationRepository.count(Specification.where(FareBasisTranslationEntitySpecification
				.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(FareBasisTranslationEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.and(FareBasisTranslationEntitySpecification.isActive())));
	}

	@Override
	public List<FareBasisTranslationEntity> getFareBasisTranslationList(Optional<String> marketingFareBasis,
			Optional<String> marketingTD,Optional<String> clientId, Optional<String> effectiveDate) {
		return fareBasisTranslationRepository.findAll(FareBasisTranslationEntitySpecification
				.searchOnDateBasis(marketingFareBasis, marketingTD,clientId, effectiveDate)
				.and(FareBasisTranslationEntitySpecification.isActive()));
	}

	@Override
	public List<FareBasisTranslationEntity> getFBTByIsPattern() {
		return fareBasisTranslationRepository
				.findAll(Specification.where(FareBasisTranslationEntitySpecification.getFBTByIsPattern())
						.and(FareBasisTranslationEntitySpecification.isActive()));
	}

	@Override
	public int getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String marketingFareBasis, String marketingTD, String fareOwnerCXR, String areaFBWIndicator,
			String fromArea, String toArea, Integer fbtId) {

		return (int) fareBasisTranslationRepository.count(FareBasisTranslationEntitySpecification.equalsToFBTId(fbtId)
				.and(FareBasisTranslationEntitySpecification.equalsToClientId(clientId))
				.and(FareBasisTranslationEntitySpecification.equalsMarketingFareBasis(marketingFareBasis))
				.and(FareBasisTranslationEntitySpecification.equalsMarketingTD(marketingTD))
				.and(FareBasisTranslationEntitySpecification.equalsFareOwnerCXR(fareOwnerCXR))
				.and(FareBasisTranslationEntitySpecification.equalsToAreaFBWIndicator(areaFBWIndicator))
				.and(FareBasisTranslationEntitySpecification.equalsToFromAtea(fromArea))
				.and(FareBasisTranslationEntitySpecification.equalsToArea(toArea))
				.and(FareBasisTranslationEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(FareBasisTranslationEntitySpecification
								.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(FareBasisTranslationEntitySpecification.isActive()));
	}

	@Override
	public int getOverLapRecordCountCreate(String clientId, String marketingFareBasis, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, String marketingTD, String fareOwnerCXR, String areaFBWIndicator,
			String fromArea, String toArea) {
		return (int) fareBasisTranslationRepository.count(Specification
				.where(FareBasisTranslationEntitySpecification.equalsToClientId(clientId))
				.and(FareBasisTranslationEntitySpecification.equalsMarketingFareBasis(marketingFareBasis))
				.and(FareBasisTranslationEntitySpecification.equalsMarketingTD(marketingTD))
				.and(FareBasisTranslationEntitySpecification.equalsFareOwnerCXR(fareOwnerCXR))
				.and(FareBasisTranslationEntitySpecification.equalsToAreaFBWIndicator(areaFBWIndicator))
				.and(FareBasisTranslationEntitySpecification.equalsToFromAtea(fromArea))
				.and(FareBasisTranslationEntitySpecification.equalsToArea(toArea))
				.and(FareBasisTranslationEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(FareBasisTranslationEntitySpecification
								.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(FareBasisTranslationEntitySpecification.isActive()));
	}

}
