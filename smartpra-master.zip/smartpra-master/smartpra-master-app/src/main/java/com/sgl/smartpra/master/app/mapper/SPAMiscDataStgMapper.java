package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.SPAMiscDataStgEntity;
import com.sgl.smartpra.master.model.SPAMiscDataStg;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SPAMiscDataStgMapper extends BaseMapper<SPAMiscDataStg, SPAMiscDataStgEntity>{
	SPAMiscDataStgEntity mapToEntity(SPAMiscDataStg spaMiscDataStg, @MappingTarget SPAMiscDataStgEntity spaMiscDataStgEntity);
	@Mapping(source = "spaMiscDataId", target = "spaMiscDataId", ignore = true)
	SPAMiscDataStgEntity mapToEntity(SPAMiscDataStg spaMiscDataStg);
}
