package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.ReportingAgencyCommissionService;
import com.sgl.smartpra.master.model.ReportingAgencyCommission;

@RestController
public class ReportingAgencyCommissionController {

	@Autowired
	private ReportingAgencyCommissionService reportingAgencyCommissionService;

	@GetMapping("agency-reporting-commission")
	public List<ReportingAgencyCommission> getAllReportingAgencyCommission(
			@RequestParam(value = "agencyCode", required = false) Optional<String> agencyCode,
			@RequestParam(value = "reportingAgency", required = false) Optional<String> reportingAgency,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return reportingAgencyCommissionService.getListOfReportingAgencyCommission(agencyCode, reportingAgency,
				activate);
	}

	@GetMapping("/agency/{agencyId}/agency-reporting-commission")
	public List<ReportingAgencyCommission> getAllReportingAgencyCommission(
			@PathVariable(value = "agencyId") Integer agencyId,
			@RequestParam(value = "agencyCode", required = false) Optional<String> agencyCode,
			@RequestParam(value = "reportingAgency", required = false) Optional<String> reportingAgency,
			@RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "orcCurrency", required = false) Optional<String> orcCurrency,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return reportingAgencyCommissionService.getListOfReportingAgencyCommission(agencyId, agencyCode,
				reportingAgency, effectiveFromDate, effectiveToDate, orcCurrency, activate);
	}

	@GetMapping("/agency/{agencyId}/agency-reporting-commission/{reportingAgencyCommId}")
	public ReportingAgencyCommission getReportingAgencyCommissionByReportingAgencyCommId(
			@PathVariable(value = "agencyId") Integer agencyId,
			@PathVariable(value = "reportingAgencyCommId") Integer reportingAgencyCommId) {
		return reportingAgencyCommissionService.getReportAgencyCommReportAgencyCommId(agencyId, reportingAgencyCommId);

	}

	@PostMapping("/agency/{agencyId}/agency-reporting-commission")
	public ReportingAgencyCommission createReportingAgencyCommission(@PathVariable(value = "agencyId") Integer agencyId,
			@Validated(Create.class) @RequestBody ReportingAgencyCommission reportingAgencyCommission) {
		return reportingAgencyCommissionService.createReportingAgencyCommission(agencyId, reportingAgencyCommission);

	}

	@PutMapping("/agency/{agencyId}/agency-reporting-commission/{reportingAgencyCommId}")
	public ReportingAgencyCommission updateReportingAgencyCommission(@PathVariable(value = "agencyId") Integer agencyId,
			@PathVariable(value = "reportingAgencyCommId") Integer reportingAgencyCommId,
			@Validated(Update.class) @RequestBody ReportingAgencyCommission reportingAgencyCommission) {
		reportingAgencyCommission.setReportingAgencyCommId(reportingAgencyCommId);
		return reportingAgencyCommissionService.updateReportingAgencyCommission(agencyId, reportingAgencyCommission);

	}

	@PutMapping("/agency/{agencyId}/agency-reporting-commission/{reportingAgencyCommId}/deactivate")
	public void deactivateReportingAgencyCommission(@PathVariable(value = "agencyId") Integer agencyId,
			@Valid @PathVariable(value = "reportingAgencyCommId") Integer reportingAgencyCommId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		reportingAgencyCommissionService.deactivateReportingAgencyCommission(agencyId, reportingAgencyCommId,
				lastUpdatedBy);
	}

	@PutMapping("/agency/{agencyId}/agency-reporting-commission/{reportingAgencyCommId}/activate")
	public void activateReportingAgencyCommission(@PathVariable(value = "agencyId") Integer agencyId,
			@Valid @PathVariable(value = "reportingAgencyCommId") Integer reportingAgencyCommId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		reportingAgencyCommissionService.activateReportingAgencyCommission(agencyId, reportingAgencyCommId,
				lastUpdatedBy);

	}

}
