/**
 * 
 */
package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.NonStandardChargeCodeDao;
import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCodeEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.NonStandardChargeCodeEntitySpec;
import com.sgl.smartpra.master.app.dao.repository.NonStandardChargeCodeRepository;

/**
 * @author kanprasa
 *
 */
@Repository
public class NonStandardChargeCodeDaoImpl implements NonStandardChargeCodeDao {
	
	@Autowired
	private NonStandardChargeCodeRepository nonStdchargeCodeRepository;

	@Override
	public Optional<NonStandardChargeCodeEntity> findById(Integer nonStdChargeCodeId) {
		return nonStdchargeCodeRepository.findById(nonStdChargeCodeId);
	}

	@Override
	public NonStandardChargeCodeEntity create(NonStandardChargeCodeEntity nonStdChargeCodeEntity) {
		return nonStdchargeCodeRepository.save(nonStdChargeCodeEntity);
	}

	@Override
	public NonStandardChargeCodeEntity update(NonStandardChargeCodeEntity nonStdChargeCodeEntity) {
		return nonStdchargeCodeRepository.save(nonStdChargeCodeEntity);
	}

	@Override
	public List<NonStandardChargeCodeEntity> searchNonStdChargeCode(String clientId,
			Optional<String> nonStdCategoryCode, Optional<String> nonStdChargeCode,
			Optional<String> stdChargeCode, Optional<String> isActive) {
		return nonStdchargeCodeRepository.findAll(NonStandardChargeCodeEntitySpec.searchNonStandardChargeCode(clientId
				, nonStdCategoryCode, nonStdChargeCode, stdChargeCode, isActive));
	}

	@Override
	public int activateNonStdChargeCode(String clientId, String nonStdChargeCode) {
		return nonStdchargeCodeRepository.activateNonStdChargeCode(clientId, nonStdChargeCode);
	}

	@Override
	public int deActivateNonStdChargeCode(String clientId, String nonStdChargeCode) {
		return nonStdchargeCodeRepository.deActivateNonStdChargeCode(clientId, nonStdChargeCode);
	}

	@Override
	public String getMaxNonStdChargeCode(String clientId, String stdChargeCode, String initial) {
		return nonStdchargeCodeRepository.getMaxNonStdChargeCode(clientId, initial);
	}
	@Override
	public String getNonStdChargeCode(String clientId, String stdChargeCode, String nonStdChargeCodeName, String nonStdCategoryCode) {
		return nonStdchargeCodeRepository.getNonStdChargeCode(clientId, nonStdChargeCodeName);
	}

}
