package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.FormCodeDao;
import com.sgl.smartpra.master.app.dao.entity.spec.FormCodeEntitySpec;
import com.sgl.smartpra.master.app.repository.FormCodeRepository;
import com.sgl.smartpra.master.app.repository.entity.FormCodeEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FormCodeDaoImpl implements FormCodeDao {

	@Autowired
	private FormCodeRepository formCodeRepository;
	
	@Override
	public List<FormCodeEntity> findAllFormCode(Optional<String> clientId, Optional<String> formCode, Optional<String> documentType,
			Optional<String> numberOfCoupon, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate,Optional<String> exceptionCall) {
		return formCodeRepository.findAll(FormCodeEntitySpec.search(clientId,formCode, documentType, numberOfCoupon,
				effectiveFromDate, effectiveToDate, activate,exceptionCall));
	}
	
	@Override
	public List<FormCodeEntity> findFormCode(Optional<String> formCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate) {
		return formCodeRepository.findAll(FormCodeEntitySpec.formCodeSearch(formCode,
				effectiveFromDate, effectiveToDate, activate));
	}
	
	@Override
	@Cacheable(value = "formCode", key = "#id")
	public Optional<FormCodeEntity> findById(Integer id) {
		log.info("Cacheable FormCode Entity's ID= {}", id);
		return formCodeRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "formCode", key = "#formCodeEntity.formCodeId"),
			@CacheEvict(value = "formCode", allEntries = true),@CacheEvict(value = "effectiveDate", allEntries = true)})
	public FormCodeEntity create(FormCodeEntity formCodeEntity) {
		return formCodeRepository.save(formCodeEntity);
	}

	@Override
	@CachePut(value = "formCode", key = "#formCodeEntity.formCodeId")
	@Caching(evict = { @CacheEvict(value = "formCode", allEntries = true),@CacheEvict(value = "effectiveDate", allEntries = true)})
	public FormCodeEntity update(FormCodeEntity formCodeEntity) {
		return formCodeRepository.save(formCodeEntity);
	}

	@Override
	public long getOverLapRecordCount(Optional<String> clientId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			Optional<String> formCode, Optional<String> documentType) {
		return formCodeRepository
				.count(Specification.where(FormCodeEntitySpec.equalsClientId(OptionalUtil.getValue(clientId)))
						.and(FormCodeEntitySpec.equalsFormCode(OptionalUtil.getValue(formCode)))
						.and(FormCodeEntitySpec.equalsDocumentType(OptionalUtil.getValue(documentType)))
						.and(FormCodeEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
								.or(FormCodeEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))));
	}

	@Override
	public long getOverLapRecordCount(String clientId, String documentType, String formCode1,
			LocalDate effectiveFromDate, LocalDate effectiveToDate, Integer formCodeId) {
		return formCodeRepository.count(Specification.where(FormCodeEntitySpec.equalsClientId(clientId))
				.and(FormCodeEntitySpec.equalsFormCode(formCode1))
				.and(FormCodeEntitySpec.equalsDocumentType(documentType))
				.and(FormCodeEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(FormCodeEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(FormCodeEntitySpec.notEqualsFormCodeId(formCodeId))));
	}

	@Override
	public Page<FormCodeEntity> findAll(FormCodeEntity mapToEntity, Optional<String> exceptionCall, Pageable pageable) {
		return formCodeRepository.findAll(FormCodeEntitySpec.findAll(mapToEntity,exceptionCall), pageable);

	}

	@Override
	public Long getCount(FormCodeEntity mapToEntity, Optional<String> exceptionCall) {
		return formCodeRepository.count(FormCodeEntitySpec.findAll(mapToEntity,exceptionCall));
	}
	
	@Override
	@Cacheable(cacheNames={"formCode", "effectiveDate"})
	public Optional<FormCodeEntity> getFormCodeByfromCodeAndEffectiveDate(Optional<String> clientId, Optional<String> formCode,
			Optional<String> effectiveDate) {
		log.info("Cacheable FormCode = {}", formCode," effectiveDate = ",effectiveDate);
		return formCodeRepository.findOne(Specification.where(
		FormCodeEntitySpec.equalsFormCode(OptionalUtil.getValue(formCode))
		.and(FormCodeEntitySpec.equalsClientId(OptionalUtil.getValue(clientId)))
		.and(FormCodeEntitySpec.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveDate))
		.and(FormCodeEntitySpec.isActive()))));
	}

}
