package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.SPAMiscDataStgEntity;

public class SPAMiscDataStgEntitySpecification {
	SPAMiscDataStgEntitySpecification(){
	}
	
	public static Specification<SPAMiscDataStgEntity> findBySpaKeyMainIdClientIdRecordType(Optional<Integer> spaKey,
			Optional<Integer> spaMainId, Optional<String> clientId) {
		return (spaMiscDataStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(spaKey)) {
				predicates.add(criteriaBuilder.equal(spaMiscDataStgEntity.get("spaKey"), OptionalUtil.getValue(spaKey)));
			}
			if (OptionalUtil.isPresent(spaMainId)) {
				predicates.add(
						criteriaBuilder.equal(spaMiscDataStgEntity.get("spaMainId"), OptionalUtil.getValue(spaMainId)));
			}
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.equal(spaMiscDataStgEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static  Specification<SPAMiscDataStgEntity> findBySpaKeyMainIdClientIdAndSpaKey(Optional<String> clientId, Optional<Integer> spaKey, Optional<Integer> recordType) {
		return (spaMiscDataStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(spaKey)) {
				predicates.add(criteriaBuilder.equal(spaMiscDataStgEntity.get("spaKey"), OptionalUtil.getValue(spaKey)));
			}
			
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.equal(spaMiscDataStgEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(recordType)) {
				predicates.add(
						criteriaBuilder.equal(spaMiscDataStgEntity.get("recordType"), OptionalUtil.getValue(recordType)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
