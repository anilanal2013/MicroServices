package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.CountryCommissionDetailEntity;

public class CountryCommissionDetailSpecification {

	private CountryCommissionDetailSpecification() {
	}

	public static Specification<CountryCommissionDetailEntity> equalCountryCode(String countryCode) {
		return (countryCommissionDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(countryCommissionDetailEntity.get("countryCode"), countryCode);
	}

	public static Specification<CountryCommissionDetailEntity> equalsCabinClass(String cabinClass) {
		return (countryCommissionDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(countryCommissionDetailEntity.get("cabinClass"), cabinClass);
	}
	
	public static Specification<CountryCommissionDetailEntity> equalsClientId(String clientId) {
		return (countryCommissionDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(countryCommissionDetailEntity.get("clientId"), clientId);
	}
	
	public static Specification<CountryCommissionDetailEntity> equalsNetGrossFlag(String netGrossFlag) {
		return (countryCommissionDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(countryCommissionDetailEntity.get("netGrossFlag"), netGrossFlag);
	}

	public static Specification<CountryCommissionDetailEntity> greaterOrLessThanEffectiveFromAndEffectiveToDate(
			LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return (countryCommissionDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			predicates.add(criteriaBuilder.greaterThanOrEqualTo(countryCommissionDetailEntity.get("effectiveFromDate"),
					effectiveFromDate));
			predicates.add(criteriaBuilder.lessThanOrEqualTo(countryCommissionDetailEntity.get("effectiveToDate"),
					effectiveToDate));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<CountryCommissionDetailEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (countryCommissionDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), countryCommissionDetailEntity.get("effectiveFromDate"),
				countryCommissionDetailEntity.get("effectiveToDate"));
	}

	public static void orderByAsc(Root<CountryCommissionDetailEntity> countryCommissionDetailEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(countryCommissionDetailEntity.get(orderByString)));
	}

	public static Specification<CountryCommissionDetailEntity> searchCountryCommission(
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> countryCode,
			Optional<String> cabinClass) {
		return (countryCommissionDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(effectiveFromDate)) {
				predicates.add(
						criteriaBuilder.greaterThanOrEqualTo(countryCommissionDetailEntity.get("effectiveFromDate"),
								OptionalUtil.getLocalDateValue(effectiveFromDate)));
			}
			if (OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(countryCommissionDetailEntity.get("effectiveToDate"),
						OptionalUtil.getLocalDateValue(effectiveToDate)));
			}
			if (OptionalUtil.isPresent(countryCode)) {
				predicates.add(criteriaBuilder.like(countryCommissionDetailEntity.get("countryCode"),
						OptionalUtil.getValue(countryCode) + "%"));
			}
			if (OptionalUtil.isPresent(cabinClass)) {
				predicates.add(criteriaBuilder.like(countryCommissionDetailEntity.get("cabinClass"),
						OptionalUtil.getValue(cabinClass) + "%"));
			}
			predicates.add(criteriaBuilder.isTrue(countryCommissionDetailEntity.get("activate")));
			orderByAsc(countryCommissionDetailEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<CountryCommissionDetailEntity> searchCountryCommissionDetailByCountryCode(
			String issueDate, String countryCode) {
		return (countryCommissionDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate localIssueDate = LocalDate.parse(issueDate, formatter);
			predicates.add(
					criteriaBuilder.like(countryCommissionDetailEntity.get("countryCode"), "%" + countryCode + "%"));
			predicates.add(criteriaBuilder.between(criteriaBuilder.literal(localIssueDate),
					countryCommissionDetailEntity.get("effectiveFromDate"),
					countryCommissionDetailEntity.get("effectiveToDate")));
			predicates.add(criteriaBuilder.isTrue(countryCommissionDetailEntity.get("activate")));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));

		};
	}

}
