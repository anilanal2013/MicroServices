package com.sgl.smartpra.master.app.service.impl;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.master.model.CarrierAllianceBaseModel;
import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.OneWorldCarrierAlliance;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CarrierAllianceCreateService extends CarrierAllianceServiceImpl {

	public CarrierAlliance createCarrierAlliance(CarrierAlliance carrierAlliance) {
		log.info("{}", carrierAlliance);
		validateBusinessConstraints(carrierAlliance);
		carrierAlliance.setActivate(Optional.of(true));
		return carrierAllianceMapper
				.mapToModel(carrierAllianceDao.create(carrierAllianceMapper.mapToEntity(carrierAlliance)));
	}

	public OneWorldCarrierAlliance createCarrierAlliance(OneWorldCarrierAlliance oneWorldCarrierAlliance) {
		log.info("{}", oneWorldCarrierAlliance);
		validateBusinessConstraints(oneWorldCarrierAlliance);
		oneWorldCarrierAlliance.setActivate(Optional.of(true));
		return carrierAllianceMapper.mapToOneWorldCarrierAllianceModel(
				carrierAllianceDao.create(carrierAllianceMapper.mapToEntity(oneWorldCarrierAlliance)));
	}

	private void validateBusinessConstraints(CarrierAllianceBaseModel carrierAllianceBaseDTO) {
		validateEffectiveToDate(carrierAllianceBaseDTO);
		super.validateCarrierDesignatorCode(carrierAllianceBaseDTO);
		super.validateCarrierCode(carrierAllianceBaseDTO);
		validateAllianceName(carrierAllianceBaseDTO);
		validateOverlap(carrierAllianceBaseDTO);
	}

	private void validateAllianceName(CarrierAllianceBaseModel carrierAllianceBaseDTO) {
		super.validateAllianceName(OptionalUtil.getValue(carrierAllianceBaseDTO.getClientId()),
				OptionalUtil.getValue(carrierAllianceBaseDTO.getAllianceName()));
	}

	private void validateEffectiveToDate(CarrierAllianceBaseModel carrierAllianceBaseDTO) {
		super.validateEffectiveToDate(OptionalUtil.getLocalDateValue(carrierAllianceBaseDTO.getEffectiveToDate()),
				OptionalUtil.getLocalDateValue(carrierAllianceBaseDTO.getEffectiveFromDate()));
	}

	private void validateOverlap(CarrierAllianceBaseModel carrierAllianceBaseDTO) {
		if (carrierAllianceDao.getOverLapRecordCount(
				OptionalUtil.getLocalDateValue(carrierAllianceBaseDTO.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(carrierAllianceBaseDTO.getEffectiveToDate()),
				OptionalUtil.getValue(carrierAllianceBaseDTO.getAllianceName()),
				OptionalUtil.getValue(carrierAllianceBaseDTO.getCarrierCode()),
				OptionalUtil.getValue(carrierAllianceBaseDTO.getClientId())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

}
