package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SearchCriteria;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.ClientUserAreaDao;
import com.sgl.smartpra.master.app.dao.entity.ClientUserAreaEntity;
import com.sgl.smartpra.master.app.dao.impl.ClientUserAreaDaoImpl;
import com.sgl.smartpra.master.app.dao.repository.ClientUserAreaRepository;
import com.sgl.smartpra.master.app.exception.ServiceException;
import com.sgl.smartpra.master.app.mapper.ClientUserAreaMapper;
import com.sgl.smartpra.master.app.service.ClientUserAreaService;
import com.sgl.smartpra.master.model.ClientUserArea;
import com.sgl.smartpra.master.model.Geo;
import com.sgl.smartpra.proration.model.farebasis.UserAreaDefine;

@Service
@Transactional
public class ClientUserAreaServiceImpl implements ClientUserAreaService {

	@Autowired
	ClientUserAreaMapper clientUserAreaMapper;

	@Autowired
	private ClientUserAreaRepository clientUserAreaRepository;

	@Autowired
	private ClientUserAreaDao clientUserAreaDao;

	@Autowired
	private ClientUserAreaDaoImpl clientUserAreaDaoImpl;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	private static final String DOESNOTEXIST = " Does not exist";
	private static final String ISNOTACTIVE = " Is not active";
	private static final String INVALIDCARRIERCODEAREA2 = "Invalid carrier code area_key2  : ";
	private static final String INVALIDCARRIERCODEAREA4 = "Invalid carrier code area_key4  : ";
	private static final String USERAREAALREADYEXIST = "UserAreacode already exist";
	private static final String INVALIDAREAKEYFOR_I = "Invalid  area_key combination value pair for area_Key1 : I";
	private static final String MANDATORYGEOTYPEVALUE = "Please provide Geo Type Value";
	String carrierCode = null;
	String carrierName1 = null;
	String carrierName2 = null;
	String carrierDesignatorCode = null;
	private static final String INACTIVE_USERAREA = "Given FOP record is not active";
	private static final String OVERLAP_COMBINATION_EXIST = "Record already exists";

	@Override
	public List<ClientUserArea> getClientListOfUserArea(Optional<String> userAreaCode, Optional<String> userAreaName,
			Optional<Boolean> activate) {
		return clientUserAreaMapper.mapToModel(clientUserAreaDao.search(userAreaCode, userAreaName, activate));
	}

	@Override
	public ClientUserArea getClientUserAreaByUserAreaCode(Integer globalUserAreaId) {
		ClientUserAreaEntity clientUserAreaEntity = clientUserAreaDao.findById(globalUserAreaId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(globalUserAreaId)));
		// return only if the record is active
		if (!clientUserAreaEntity.getActivate()) {
			throw new ServiceException("User is not active");
		}
		return clientUserAreaMapper.mapToModel(clientUserAreaEntity);
	}

	@Override
	public ClientUserArea createClientUserArea(ClientUserArea userArea) {
		boolean flag = false;
		List<ClientUserAreaEntity> clientUserAreaEntity = clientUserAreaRepository
				.findByUserAreaCode(OptionalUtil.getValue(userArea.getUserAreaCode()));
		if (!clientUserAreaEntity.isEmpty()) {
			throw new ServiceException(USERAREAALREADYEXIST);
		}
		flag = true;
		areaKeyValidation(userArea);
		if (userArea.getIncludeGeoList() != null) {
			List<Geo> geoList = userArea.getIncludeGeoList();
			StringBuilder geoString = new StringBuilder();
			StringBuilder m1 = userGeoList(geoList, geoString, flag);
			String str = m1.toString();
			userArea.setAreaIncludeList(Optional.of(str));
		}
		if (userArea.getExcludeGeoList() != null) {
			List<Geo> geoList1 = userArea.getExcludeGeoList();
			StringBuilder geoString1 = new StringBuilder();
			StringBuilder ex = userGeoList(geoList1, geoString1, flag);
			String str1 = ex.toString();
			userArea.setAreaExcludeList(Optional.of(str1));
		}
		typeValueList = new ArrayList<>();
		typeValueList.clear();
		userArea.setActivate(Boolean.TRUE);
		typeValueList.clear();
		return clientUserAreaMapper.mapToModel(clientUserAreaDao.create(clientUserAreaMapper.mapToEntity(userArea)));

	}

	@Override
	public ClientUserArea updateClientUserArea(Integer globalUserAreaId, ClientUserArea userArea) {
		boolean flag = false;
		typeValueList.clear();
		ClientUserAreaEntity clientUserAreaEntity = clientUserAreaDao.findById(globalUserAreaId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(globalUserAreaId)));
		flag = true;
		if (userArea.getIncludeGeoList() != null) {
			List<Geo> geoList = userArea.getIncludeGeoList();
			StringBuilder geoString = new StringBuilder();
			StringBuilder m1 = userGeoList(geoList, geoString, flag);
			String str = m1.toString();
			userArea.setAreaIncludeList(Optional.of(str));
		}
		if (userArea.getExcludeGeoList() != null) {
			List<Geo> geoList1 = userArea.getExcludeGeoList();
			StringBuilder geoString1 = new StringBuilder();
			StringBuilder ex = userGeoList(geoList1, geoString1, flag);
			String str1 = ex.toString();
			userArea.setAreaExcludeList(Optional.of(str1));
		}
		// update only if the record is active
		if (!clientUserAreaEntity.getActivate()) {
			throw new ServiceException("user is not active");
		}
		typeValueList = new ArrayList<>();
		typeValueList.clear();

		return clientUserAreaMapper
				.mapToModel(clientUserAreaDao.update(clientUserAreaMapper.mapToEntity(userArea, clientUserAreaEntity)));
	}

	@Override
	public void deactivateClientUserArea(Integer globalUserAreaId, String lastUpdatedBy) {
		ClientUserAreaEntity clientUserAreaEntity = clientUserAreaDao.findById(globalUserAreaId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(globalUserAreaId)));
		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}
		if (!clientUserAreaEntity.getActivate()) {
			throw new BusinessException(INACTIVE_USERAREA);
		}
		clientUserAreaEntity.setActivate(Boolean.FALSE);
		clientUserAreaEntity.setLastUpdatedBy(lastUpdatedBy);
		clientUserAreaDao.update(clientUserAreaEntity);

	}

	@Override
	public void activateClientUserArea(Integer globalUserAreaId, String lastUpdatedBy) {
		ClientUserAreaEntity clientUserAreaEntity = clientUserAreaDao.findById(globalUserAreaId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(globalUserAreaId)));
		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}
		if (clientUserAreaEntity.getActivate()) {
			throw new BusinessException(INACTIVE_USERAREA);
		}
		clientUserAreaEntity.setActivate(Boolean.TRUE);
		clientUserAreaEntity.setLastUpdatedBy(lastUpdatedBy);
		clientUserAreaDao.update(clientUserAreaEntity);

	}

	private void areaKeyValidation(ClientUserArea userArea) {

		String areaKey1 = OptionalUtil.getValue(userArea.getAreaKey1());
		String areaKey2 = OptionalUtil.getValue(userArea.getAreaKey2());
		String areaKey4 = OptionalUtil.getValue(userArea.getAreaKey4());

		if (areaKey1.equalsIgnoreCase("D")) {
			if ((areaKey2.equalsIgnoreCase("CH") || areaKey2.equalsIgnoreCase("IN")
					|| areaKey2.equalsIgnoreCase("ID"))) {
				carrierDesignatorCode = (areaKey4);
				if (!carrierDesignatorCode.equalsIgnoreCase("GLB")) {
					codeArea4CarrierValidation(carrierDesignatorCode);
				}
			} else {
				throw new ServiceException("Invalid  area_key combination value pair for area_Key1 : D");
			}
		} else if (areaKey1.equalsIgnoreCase("C") || areaKey1.equalsIgnoreCase("S")) {
			carrierDesignatorCode = areaKey2;
			codeArea2CarrierValidation(carrierDesignatorCode);
			carrierDesignatorCode = areaKey4;
			codeArea4CarrierValidation(carrierDesignatorCode);
		} else if (areaKey1.equalsIgnoreCase("F")) {
			if (areaKey2.equalsIgnoreCase("FB")) {
				carrierDesignatorCode = areaKey4;
				codeArea4CarrierValidation(carrierDesignatorCode);
			} else {
				throw new ServiceException("Invalid  area_key combination value pair for area_Key1 : F");
			}
		} else if (areaKey1.equalsIgnoreCase("M")) {
			if (areaKey2.equalsIgnoreCase("SCM")) {
				carrierDesignatorCode = areaKey4;
				codeArea4CarrierValidation(carrierDesignatorCode);
			} else {
				throw new ServiceException("Invalid  area_key combination value pair for area_Key1 : M");
			}
		} else if (areaKey1.equalsIgnoreCase("Q")) {
			if (areaKey2.equalsIgnoreCase("SUR")) {
				carrierDesignatorCode = areaKey4;
				codeArea4CarrierValidation(carrierDesignatorCode);
			} else {
				throw new ServiceException("Invalid  area_key combination value pair for area_Key1 : Q");
			}
		} else if (areaKey1.equalsIgnoreCase("Y")) {
			if (areaKey2.equalsIgnoreCase("YLD")) {
				carrierDesignatorCode = areaKey4;
				codeArea4CarrierValidation(carrierDesignatorCode);
			} else {
				throw new ServiceException("Invalid  area_key combination value pair for area_Key1 : Y");
			}
		} else if (areaKey1.equalsIgnoreCase("T")) {
			if (areaKey2.equalsIgnoreCase("YQ") || areaKey2.equalsIgnoreCase("YR")) {
				carrierDesignatorCode = areaKey4;
				codeArea4CarrierValidation(carrierDesignatorCode);
			} else {
				throw new ServiceException(
						"Invalid  area_key combination value pair for area_Key1 : T, area_key2 must be 'YQ' or 'YR'");
			}
		} else if (areaKey1.equalsIgnoreCase("I")) {
			if (areaKey2.equalsIgnoreCase("ISC")) {
				carrierDesignatorCode = areaKey4;
				if (!carrierDesignatorCode.equalsIgnoreCase("GLB")) {
					codeArea4CarrierValidation(carrierDesignatorCode);
				}
			} else {
				throw new ServiceException(INVALIDAREAKEYFOR_I);
			}
		} else {
			throw new ServiceException("Invalid  area_key1 value : " + userArea.getAreaKey1()
					+ " Valid area_key1 must have any of 'C','F','M','S','Q','T','Y','D','I'");
		}
	}

	private void codeArea2CarrierValidation(String carrierDesignatorCode) {
		if (globalMasterFeignClient.getAllCarrier(carrierCode, carrierDesignatorCode, carrierName1, carrierName2, true)
				.isEmpty()) {
			throw new ServiceException(INVALIDCARRIERCODEAREA2 + carrierDesignatorCode + DOESNOTEXIST);
		}
	}

	private void codeArea4CarrierValidation(String carrierDesignatorCode) {
		if (globalMasterFeignClient.getAllCarrier(carrierCode, carrierDesignatorCode, carrierName1, carrierName2, true)
				.isEmpty()) {
			throw new ServiceException(INVALIDCARRIERCODEAREA4 + carrierDesignatorCode + DOESNOTEXIST);
		}
	}

	List<String> typeValueList = new ArrayList<>();

	private StringBuilder userGeoList(List<Geo> l, StringBuilder geoString, boolean flag) {
		for (Geo geo : l) {
			if (geo.getGeoTypeId() == null)
				throw new ServiceException("GeoTypeId should be 1,2,3 or 5 ");
			if (geo.getGeoTypeId() == 1 || geo.getGeoTypeId() == 2 || geo.getGeoTypeId() == 3
					|| geo.getGeoTypeId() == 5) {
				if (geo.getGeoTypeId() == 1
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new ServiceException(
									"GeoTypeValue should be maximum of 3 characters for  Airport/City Code");
						}
					} else {
						typeValueList.clear();
						throw new ServiceException(MANDATORYGEOTYPEVALUE);
					}
					if (!globalMasterFeignClient.isValidAirportCodeOrCityCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. Airport/City Code : "
								+ geo.getGeoTypeValue().toUpperCase() + " Does not exist or not active");
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 2
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 2) {
							typeValueList.clear();
							throw new ServiceException(
									"GeoTypeValue should be maximum of 2 characters for countryCode");
						}
					} else {
						typeValueList.clear();
						throw new ServiceException(MANDATORYGEOTYPEVALUE);
					}
					try {
						globalMasterFeignClient.getCountryByCountryCode(geo.getGeoTypeValue().toUpperCase());
					} catch (Exception ec) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. country Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");
				} else if (geo.getGeoTypeId() == 3
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (flag) {
						typeValueList.clear();
						throw new ServiceException("Geo Type Id 3 is not applicable for excludeGeoList");
					}
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new ServiceException(
									"GeoTypeValue should be maximum of 3 characters for standardAreaCode");
						}
					} else {
						typeValueList.clear();
						throw new ServiceException(MANDATORYGEOTYPEVALUE);
					}
					try {
						if(!globalMasterFeignClient.getActiveStandardAreaByStandardAreaCode(geo.getGeoTypeValue().toUpperCase())) {
							typeValueList.clear();
							throw new ServiceException("Invalid Geo Type Value : "
									+ geo.getGeoTypeValue().toUpperCase());
						}
					} catch (Exception ec) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. standardArea Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");
				} else if (geo.getGeoTypeId() == 5
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 4) {
							typeValueList.clear();
							throw new ServiceException("GeoTypeValue should be maximum of 4 characters for stateCode");
						}
					} else {
						typeValueList.clear();
						throw new ServiceException(MANDATORYGEOTYPEVALUE);
					}
					if (!globalMasterFeignClient.isValidStateCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. State Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST + " or " + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");
				} else if (typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					typeValueList.clear();
					throw new ServiceException("Duplicate Geotype Value: " + geo.getGeoTypeValue().toUpperCase());
				}
			} else {
				typeValueList.clear();
				throw new ServiceException(
						"invalid Geo type id :" + geo.getGeoTypeId() + " Only 1,2,3,5 are the valid Geo type id ");
			}
		}
		if (geoString.length() > 1000) {
			typeValueList.clear();
			throw new ServiceException(
					"area_include_list or area_exclude_list length must be less than 1000 charecters");
		}
		if (geoString.length() != 0) {
			geoString.delete(geoString.length() - 1, geoString.length());
		}
		return geoString;
	}

	@Override
	public void clientSpecificUserAreaInsertOrUpdate(Map<String, String> map) {
		String userAreaCode = "";
		String areaKey1 = "";
		String areaKey2 = "";
		String areaKey3 = "";
		String areaKey4 = "";
		String areaFromInclude = "";
		String areaToInclude = null;
		Boolean flag = false;
		String clientId = "";
		ClientUserArea clientUserArea = new ClientUserArea();

		for (Map.Entry<String, String> m : map.entrySet()) {
			Optional<String> value = Optional.ofNullable(m.getValue());
			if (m.getKey().equals("userToArea") && m.getValue() != null) {
				clientUserArea.setUserAreaCode(value);
				userAreaCode = m.getValue();
			} else if (m.getKey().equals("userFromArea") && m.getValue() != null) {
				clientUserArea.setUserAreaCode(value);
				userAreaCode = m.getValue();
			} else if (m.getKey().equals("areaKey1")) {
				clientUserArea.setAreaKey1(value);
				areaKey1 = m.getValue();
			} else if (m.getKey().equals("areaKey2")) {
				clientUserArea.setAreaKey2(value);
				areaKey2 = m.getValue();
			} else if (m.getKey().equals("areaKey3")) {
				clientUserArea.setAreaKey3(value);
				areaKey3 = m.getValue();
			} else if (m.getKey().equals("areaKey4")) {
				clientUserArea.setAreaKey4(value);
				areaKey4 = m.getValue();
			} else if (m.getKey().equals("areaFromInclude")) {
				clientUserArea.setAreaIncludeList(value);
				areaFromInclude = m.getValue();
			} else if (m.getKey().equals("areaFromExclude")) {
				clientUserArea.setAreaExcludeList(value);
			} else if (m.getKey().equals("createdBy")) {
				clientUserArea.setCreatedBy(value);
			} else if (m.getKey().equals("areaToInclude")) {
				clientUserArea.setAreaIncludeList(value);
				areaToInclude = m.getValue();
			} else if (m.getKey().equals("areaToExclude")) {
				clientUserArea.setAreaExcludeList(value);
			} else if (m.getKey().equals("updateFlag")) {
				String flagSet = m.getValue();
				flag = Boolean.valueOf(flagSet);
			} else if (m.getKey().equals("userFromAreaName")) {
				if (m.getValue() != null)
					clientUserArea.setUserAreaName(value);
			} else if (m.getKey().equals("userToAreaName")) {
				if (m.getValue() != null)
					clientUserArea.setUserAreaName(value);
			}
		}
		Optional<ClientUserAreaEntity> clientUserAreaEntity = null;
		if (!flag) {
			if (OptionalUtil.getValue(clientUserArea.getAreaIncludeList()) == null) {
				clientUserAreaEntity = validateOverLap(userAreaCode, areaKey1, areaKey2, areaKey3, areaKey4);
			} else {
				clientUserAreaEntity = validateOverLap(userAreaCode, areaKey1, areaKey2, areaKey3, areaKey4);
			}
			if (OptionalUtil.getValue(clientUserAreaEntity) != null) {
				throw new ServiceException("fromArea and toArea should not be same");
			}
			clientUserArea.setActivate(Boolean.TRUE);
			clientUserArea.setCreatedDate(LocalDateTime.now());

			clientUserAreaMapper
					.mapToModel(clientUserAreaRepository.save(clientUserAreaMapper.mapToEntity(clientUserArea)));
		} else {
			Optional<ClientUserAreaEntity> clientUserAreaEntityUpdated = null;

			/*
			 * if (OptionalUtil.getValue(clientUserArea.getAreaIncludeList()) == null) {
			 * clientUserAreaEntityUpdated = validateOverLap(userAreaCode, areaKey1,
			 * areaKey2, areaKey3, areaKey4); } else { clientUserAreaEntityUpdated =
			 * validateOverLap(userAreaCode, areaKey1, areaKey2, areaKey3, areaKey4); }
			 */
			
			ClientUserAreaEntity clientUsrAreaEntity = new ClientUserAreaEntity();
			clientUsrAreaEntity.setUserAreaCode(OptionalUtil.getValue(clientUserArea.getUserAreaCode()));
			clientUsrAreaEntity.setAreaKey1(OptionalUtil.getValue(clientUserArea.getAreaKey1()));
			clientUsrAreaEntity.setAreaKey2(OptionalUtil.getValue(clientUserArea.getAreaKey2()));
			clientUsrAreaEntity.setAreaKey3(OptionalUtil.getValue(clientUserArea.getAreaKey3()));
			clientUsrAreaEntity.setAreaKey4(OptionalUtil.getValue(clientUserArea.getAreaKey4()));
			List<ClientUserArea> clientArea = getClientListOfUserAreaForCaptureArea(Optional.of(userAreaCode), Optional.of(areaKey1), Optional.of(areaKey2), Optional.of(areaKey3), Optional.of(areaKey4),Optional.of(true));
			if(!clientArea.isEmpty()) {	
			clientUsrAreaEntity.setUserAreaId(clientArea.get(0).getUserAreaId());
			clientUsrAreaEntity.setCreatedBy(OptionalUtil.getValue(clientArea.get(0).getCreatedBy()));
			clientUsrAreaEntity.setCreatedDate(LocalDateTime.now());
			}else {
			throw new ServiceException("User Area Record is not found for id " + areaKey3);	
			}
			
			for (Map.Entry<String, String> m : map.entrySet()) {
				if (m.getKey().equals("areaFromInclude")) {
					clientUsrAreaEntity.setAreaIncludeList(m.getValue());
				} else if (m.getKey().equals("areaFromExclude")) {
					clientUsrAreaEntity.setAreaExcludeList(m.getValue());
				} else if (m.getKey().equals("areaToInclude")) {
					clientUsrAreaEntity.setAreaIncludeList(m.getValue());
				} else if (m.getKey().equals("areaToExclude")) {
					clientUsrAreaEntity.setAreaExcludeList(m.getValue());
				} else if (m.getKey().equals("createdBy")) {
					clientUsrAreaEntity.setCreatedBy(m.getValue());
				} else if (m.getKey().equals("lastUpdatedBy")) {
					clientUsrAreaEntity.setLastUpdatedBy(m.getValue());
				} else if (m.getKey().equals("userFromAreaName")) {
					if (m.getValue() != null)
						clientUsrAreaEntity.setUserAreaName(m.getValue());
				} else if (m.getKey().equals("userToAreaName")) {
					if (m.getValue() != null)
						clientUsrAreaEntity.setUserAreaName(m.getValue());
				}

			}
			clientUsrAreaEntity.setLastUpdatedDate(LocalDateTime.now());
			clientUsrAreaEntity.setActivate(Boolean.TRUE);
			clientUserAreaRepository.save(clientUsrAreaEntity);

		}

	}

	@Override
	public boolean isValidateAreaCode(String areaCode) {
		List<ClientUserAreaEntity> clientAreaEntity = clientUserAreaRepository.findByUserAreaCode(areaCode);
		if (!clientAreaEntity.isEmpty()) {
			return true;
		}
		return false;
	}

	@Override
	public UserAreaDefine getClientUserArea(UserAreaDefine userAreaDefine) {
		List<SearchCriteria> params = new ArrayList<>();

		if (userAreaDefine.getUserAreaCode() == null || userAreaDefine.getAreaKey1() == null
				|| userAreaDefine.getAreaKey2() == null || userAreaDefine.getAreaKey3() == null
				|| userAreaDefine.getAreaKey4() == null) {
			return userAreaDefine;
		}

		List<ClientUserArea> clientUserAreaList = clientUserAreaMapper.mapToModel(clientUserAreaDao.getClientUserArea(
				userAreaDefine.getUserAreaCode(), userAreaDefine.getAreaKey1(), userAreaDefine.getAreaKey2(),
				userAreaDefine.getAreaKey3(), userAreaDefine.getAreaKey4(), Boolean.TRUE));

		if (!clientUserAreaList.isEmpty()) {
			if (OptionalUtil.isPresent(clientUserAreaList.get(0).getAreaExcludeList())) {
				userAreaDefine
						.setAreaExcludeList(OptionalUtil.getValue(clientUserAreaList.get(0).getAreaExcludeList()));
			}
			if (OptionalUtil.isPresent(clientUserAreaList.get(0).getAreaIncludeList())) {
				userAreaDefine
						.setAreaIncludeList(OptionalUtil.getValue(clientUserAreaList.get(0).getAreaIncludeList()));
			}
			return userAreaDefine;
		}

		return userAreaDefine;
	}

	private Optional<ClientUserAreaEntity> validateOverLap(String userAreaCode, String areaKey1, String areaKey2,
			String areaKey3, String areaKey4) {

		if (OptionalUtil.getValue(clientUserAreaDao.getOverLapRecordCount(userAreaCode, areaKey1, areaKey2, areaKey3,
				areaKey4)) != null) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}
		return clientUserAreaDao.getOverLapRecordCount(userAreaCode, areaKey1, areaKey2, areaKey3, areaKey4);
	}

	@Override
	public void deleteClientUserArea(String areaKey1, String areaKey2, String areaKey3) {
		clientUserAreaRepository.deleteClientUserArea(areaKey1, areaKey2, areaKey3);
	}

	@Override
	public List<ClientUserArea> getClientListOfUserAreaForCaptureArea(Optional<String> userAreaCode,
			Optional<String> areaKey1, Optional<String> areaKey2, Optional<String> areaKey3, Optional<String> areaKey4,
			Optional<Boolean> activate) {
		return clientUserAreaMapper.mapToModel(clientUserAreaDao.getClientUserArea(OptionalUtil.getValue(userAreaCode), OptionalUtil.getValue(areaKey1), OptionalUtil.getValue(areaKey2), 
				OptionalUtil.getValue(areaKey3) ,OptionalUtil.getValue(areaKey4), OptionalUtil.getValue(activate)));
	}
}
