package com.sgl.smartpra.master.app.repository.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * The persistent class for the mas_flight database table.
 * 
 */
@Entity
@Table(name = "mas_flight")
//@NamedQuery(name = "FlightEntity.findAll", query = "SELECT f FROM FlightEntity f")
public class FlightEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "flight_id")
	Integer flightId;

	@Column(name = "client_id")
	String clientId;

	@Column(name = "flight_from")
	String flightFrom;

	@Column(name = "flight_to")
	String flightTo;

	@Column(name = "from_date")
	Date fromDate;

	@Column(name = "to_date")
	Date toDate;

	@Column(name = "[from]")
	String from;

	@Column(name = "[to]")
	String to;

	@Column(name = "operation_days")
	Integer operationDays;

	@Column(name = "route_code")
	String routeCode;

	@Column(name = "route_description")
	String routeDescription;

	@Column(name = "super_route_code")
	String superRouteCode;

	@Column(name = "group_code")
	String groupCode;

	@Column(name = "line_of_business")
	String lineOfBusiness;

	@Column(name = "service_type")
	String serviceType;

	@Column(name = "flight_type")
	String flightType;

	@Column(name = "flight_indicator")
	String flightIndicator;

	@Column(name = "no_of_legs")
	Integer noOfLegs;

	@Column(name = "order_of_flight")
	Integer orderOfFlight;

	@Column(name = "from_leg_no")
	Integer fromLegNo;

	@Column(name = "to_leg_no")
	Integer toLegNo;

	@Column(name = "flight_attribute_1")
	String flightAttribute1;

	@Column(name = "flight_attribute_2")
	String flightAttribute2;

	@Column(name = "flight_attribute_3")
	String flightAttribute3;

	@Column(name = "flight_attribute_4")
	String flightAttribute4;

	@Column(name = "flight_attribute_5")
	String flightAttribute5;

	@Column(name = "is_active")
	Boolean isActive;

	@Column(name = "created_date")
	private Timestamp createdDate;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	public Integer getFlightId() {
		return flightId;
	}

	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getFlightFrom() {
		return flightFrom;
	}

	public void setFlightFrom(String flightFrom) {
		this.flightFrom = flightFrom;
	}

	public String getFlightTo() {
		return flightTo;
	}

	public void setFlightTo(String flightTo) {
		this.flightTo = flightTo;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public Integer getOperationDays() {
		return operationDays;
	}

	public void setOperationDays(Integer operationDays) {
		this.operationDays = operationDays;
	}

	public String getRouteCode() {
		return routeCode;
	}

	public void setRouteCode(String routeCode) {
		this.routeCode = routeCode;
	}

	public String getRouteDescription() {
		return routeDescription;
	}

	public void setRouteDescription(String routeDescription) {
		this.routeDescription = routeDescription;
	}

	public String getSuperRouteCode() {
		return superRouteCode;
	}

	public void setSuperRouteCode(String superRouteCode) {
		this.superRouteCode = superRouteCode;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getFlightType() {
		return flightType;
	}

	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}

	public String getFlightIndicator() {
		return flightIndicator;
	}

	public void setFlightIndicator(String flightIndicator) {
		this.flightIndicator = flightIndicator;
	}

	public Integer getNoOfLegs() {
		return noOfLegs;
	}

	public void setNoOfLegs(Integer noOfLegs) {
		this.noOfLegs = noOfLegs;
	}

	public Integer getOrderOfFlight() {
		return orderOfFlight;
	}

	public void setOrderOfFlight(Integer orderOfFlight) {
		this.orderOfFlight = orderOfFlight;
	}

	public Integer getFromLegNo() {
		return fromLegNo;
	}

	public void setFromLegNo(Integer fromLegNo) {
		this.fromLegNo = fromLegNo;
	}

	public Integer getToLegNo() {
		return toLegNo;
	}

	public void setToLegNo(Integer toLegNo) {
		this.toLegNo = toLegNo;
	}

	public String getFlightAttribute1() {
		return flightAttribute1;
	}

	public void setFlightAttribute1(String flightAttribute1) {
		this.flightAttribute1 = flightAttribute1;
	}

	public String getFlightAttribute2() {
		return flightAttribute2;
	}

	public void setFlightAttribute2(String flightAttribute2) {
		this.flightAttribute2 = flightAttribute2;
	}

	public String getFlightAttribute3() {
		return flightAttribute3;
	}

	public void setFlightAttribute3(String flightAttribute3) {
		this.flightAttribute3 = flightAttribute3;
	}

	public String getFlightAttribute4() {
		return flightAttribute4;
	}

	public void setFlightAttribute4(String flightAttribute4) {
		this.flightAttribute4 = flightAttribute4;
	}

	public String getFlightAttribute5() {
		return flightAttribute5;
	}

	public void setFlightAttribute5(String flightAttribute5) {
		this.flightAttribute5 = flightAttribute5;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

}