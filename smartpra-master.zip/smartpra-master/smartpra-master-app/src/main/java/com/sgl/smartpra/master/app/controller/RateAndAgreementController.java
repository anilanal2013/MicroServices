package com.sgl.smartpra.master.app.controller;


import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.integration.model.CurrencyRateIn;
import com.sgl.smartpra.integration.model.CurrencyRateOut;
import com.sgl.smartpra.master.app.service.RateAndAgreementService;
import com.sgl.smartpra.master.model.RateAndAgreementModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@RestController
public class RateAndAgreementController {

    @Autowired
    private RateAndAgreementService rateAndAgreementService;

	
    @PostMapping("/rate-agreement")
    @ResponseStatus(HttpStatus.CREATED)
    public RateAndAgreementModel create(@Validated(Create.class) @RequestBody RateAndAgreementModel rateAndAgreementModel){
        return rateAndAgreementService.create(rateAndAgreementModel);
    }

    @GetMapping("/rate-agreement")
    public List<RateAndAgreementModel> fetchRateAndAgreement(
            @RequestParam(name="supplierCode" , required = true) Optional<String> supplierCode,
            @RequestParam(name= "baseLocation" , required = true) Optional<String> baseLocation,
            @RequestParam(name = "chargeCategory", required = true) Optional<String> chargeCategory,
            @RequestParam(name = "chargeCode" , required = false) Optional<String> chargeCode,
            @RequestParam(name = "effectivePeriod" , required = false) Optional<String> effectivePeriodFrom,
            @RequestParam(name = "effectivePeriod" , required = false) Optional<String> effectivePeriodTo,
            @RequestParam(name = "airport" , required = false) Optional<String> airport
    ){
        return rateAndAgreementService.fetchAll(supplierCode,baseLocation,chargeCategory,chargeCode,effectivePeriodFrom,effectivePeriodTo,airport);
    }

    @PutMapping("/rate-agreement/{id}")
    public RateAndAgreementModel updateRateAndAgreement(
            @PathVariable(name = "id") Integer id, @Validated(Update.class) @RequestBody RateAndAgreementModel  rateAndAgreementModel
    ){
        return rateAndAgreementService.saveExist(rateAndAgreementModel);
    }

    
    @DeleteMapping("/rate-agreement/{id}")
    public Boolean deleteRateAndAgreement( @PathVariable(name = "id") Integer id){
        return rateAndAgreementService.delete(id);
    }

    @PostMapping("/rate-agreement-exchange-rate")
	public CurrencyRateOut getExchangeRate(@Validated @RequestBody CurrencyRateIn currencyRateIn) {
    	return rateAndAgreementService.getExchangeRate(currencyRateIn);
    }
	

}
