package com.sgl.smartpra.master.app.dao.entity;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.Length;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_accounting_recon database table.
 * 
 */
@Entity
@Table(name = "mas_accounting_recon")
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicUpdate
@DynamicInsert
public class MasAccountingReconEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "accounting_entry_recon_id")
	private Integer accountingEntryReconId;
	@Column(name = "account_alpha_code",length=3)
	private String accountAlphaCode;
	@Column(name = "account_type")
	private String accountType;
	@Column(name = "client_id",length=2)
	private String clientId;
	@Column(name = "conversion_date")
	private LocalDate conversionDate;
	@Column(name = "debit_credit_indicator",length=1)
	private String debitCreditIndicator;
	@Column(name = "doc_type",length=3)
	private String docType;
	@Column(name = "effective_from_date")
	private Date effectiveFromDate;
	@Column(name = "effective_to_date")
	private Date effectiveToDate;
	@Column(name = "module_id")
	private Integer moduleId;
	@Column(name = "pre_implementation_indicator",length=1)
	private String preImplementationIndicator;
	@Column(name = "rejection_memo_type",length=2)
	private String rejectionMemoType;
	@Column(name = "self_oal_indicator",length=1)
	private String selfOalIndicator;
	@Column(name = "transaction_type",length=5)
	private String transactionType;
	@Column(name = "value_component",length=2)
	private String valueComponent;
	@Column(name = "value_component_table",length=100)

	private String valueComponentTable;
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}