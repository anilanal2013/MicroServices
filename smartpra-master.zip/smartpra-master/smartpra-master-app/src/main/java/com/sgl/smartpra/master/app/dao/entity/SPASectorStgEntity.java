package com.sgl.smartpra.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "mas_spa_sector_stg")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class SPASectorStgEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "spa_sector_id", nullable = false)
	private Integer spaSectorId;

	@Column(name = "spa_key", unique = true, nullable = false)
	private Integer spaKey;

	@Column(name = "spa_main_id", nullable = false)
	private Integer spaMainId;

	@Column(name = "client_id", nullable = false, length = 2)
	private String clientId;

	@Column(name = "sector_rec_seq_number", unique = true, nullable = false)
	private Integer sectorRecSeqNumber;

	@Column(name = "sector_from", nullable = false, length = 4)
	private String sectorFrom;

	@Column(name = "sector_to", nullable = false, length = 4)
	private String sectorTo;

	@Column(name = "sector_via", length = 4)
	private String sectorVia;

	@Column(name = "vv_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean vvFlag;

	@Column(name = "issue_cxr", length = 3)
	private String issueCxr;

	@Column(name = "uplift_cxr", length = 3)
	private String upliftCxr;

	@Column(name = "marketing_cxr", length = 3)
	private String marketingCxr;

	@Column(name = "validity_period_type", length = 1)
	private String validityPeriodType;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Column(name = "mileage_type", length = 1)
	private String mileageType;

	@Column(name = "mileage_from")
	private Integer mileageFrom;

	@Column(name = "mileage_to")
	private Integer mileageTo;

	@Column(name = "flight_range_groupid", length = 8)
	private String flightRangeGroupid;

	@Column(name = "season_type", length = 1)
	private String seasonType;

	@Column(name = "season_groupid", length = 3)
	private String seasonGroupId;

	@Column(name = "season_from", length = 5)
	private String seasonFrom;

	@Column(name = "season_to", length = 5)
	private String seasonTo;

	@Column(name = "week_type", length = 1)
	private String weekType;

	@Column(name = "fb_group_code", length = 5)
	private String fbGroupCode;

	@Column(name = "ticketed_fb_groupid", length = 3)
	private String ticketedFbGroupid;

	@Column(name = "td_groupid", length = 3)
	private String tdGroupId;

	@Column(name = "tour_code_groupid", length = 3)
	private String tourCodeGroupId;

	@Column(name = "journey_type", length = 1)
	private String journeyType;

	@Column(name = "rbd_type", length = 1)
	private String rbdType;

	@Column(name = "rbd_list", length = 25)
	private String rbdList;

	@Column(name = "apply_surcharge_classdiff", length = 1)
	private String applySurchargeClassdiff;

	@Column(name = "prorate_relief", length = 1)
	private String prorateRelief;

	@Column(name = "rev_share_flag", length = 2)
	private String revShareFlag;

	@Column(name = "rev_share_percent", precision = 5, scale = 2)
	private BigDecimal revSharePercent;

	@Column(name = "srp_based_on", length = 1)
	private String srpBasedOn;

	@Column(name = "wm_adjustment", length = 1)
	private Integer wmAdjustment;

	@Column(name = "share_fare_basis", length = 15)
	private String shareFareBasis;

	@Column(name = "fare_date_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean fareDateFlag;

	@Column(name = "third_cxr_share", length = 1)
	private String thirdCxrShare;

	@Column(name = "rev_share_class", length = 1)
	private String revShareClass;

	@Column(name = "rev_share_currency", length = 3)
	private String revShareCurrency;

	@Column(name = "rev_share_amount", precision = 18, scale = 3)
	private BigDecimal revShareAmount;

	@Column(name = "rev_share_exception", length = 1)
	private String revShareException;

	@Column(name = "addon_currency", length = 3)
	private String addonCurrency;

	@Column(name = "addon_amount", precision = 18, scale = 3)
	private BigDecimal addonAmount;

	@Column(name = "isc_appl_on", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean iscApplOn;

	@Column(name = "isc_currency", length = 3)
	private String iscCurrency;

	@Column(name = "isc_amount", precision = 18, scale = 3)
	private BigDecimal iscAmount;

	@Column(name = "isc_percent", precision = 5, scale = 3)
	private BigDecimal iscPercent;

	@Column(name = "uatp_percent", precision = 5, scale = 3)
	private BigDecimal uatpPercent;

	@Column(name = "compare_flag", nullable = false, length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean compareFlag;

	@Column(name = "from_rec_serial")
	private Integer fromRecSerial;

	@Column(name = "to_rec_serial")
	private Integer toRecSerial;

	@Column(name = "question_id", length = 3)
	private String questionId;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

	// bi-directional many-to-one association to SPAMainStgEntity
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "spa_main_id", insertable = false, updatable = false)
	@JsonIgnore
	private SPAMainStgEntity masSpaMain;
}
