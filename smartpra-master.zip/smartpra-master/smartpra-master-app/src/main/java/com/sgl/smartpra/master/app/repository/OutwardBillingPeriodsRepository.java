package com.sgl.smartpra.master.app.repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.OutwardBillingPeriodsEntity;

@Repository
public interface OutwardBillingPeriodsRepository extends JpaRepository<OutwardBillingPeriodsEntity, Integer>,
		JpaSpecificationExecutor<OutwardBillingPeriodsEntity> {

	OutwardBillingPeriodsEntity findByBillingPeriod(Integer billingPeriod);

	OutwardBillingPeriodsEntity findByBillingPeriodAndBillingMonth(Integer billingPeriod, String billingMonth);

	List<OutwardBillingPeriodsEntity> findByBillingMonthAndBillingPeriod(String billingMonth, Integer billingPeriod);

	List<OutwardBillingPeriodsEntity> findByBillingMonthAndBillingPeriodAndClientId(String billingMonth,
			Integer billingPeriod, String clientId);

	@Query(value = "select a from OutwardBillingPeriodsEntity a  where ((?1 between a.startDate  AND a.endDate) or (a.startDate >=?1 and a.endDate <=?1 ))")
	List<OutwardBillingPeriodsEntity> getOutwardBillingPeriodsUsingDate(LocalDate date);

	@Query(value = "select top 1 * from SmartPRAMaster.mas_outward_billing_period  WHERE closing_indicator='Y' ORDER BY end_date DESC", nativeQuery = true)
	OutwardBillingPeriodsEntity getLatestClosedOutwardBillingPeriods();

	@Query(value = "select top 1 * from SmartPRAMaster.mas_outward_billing_period WHERE closing_indicator='N' ORDER BY end_date ASC", nativeQuery = true)
	OutwardBillingPeriodsEntity getCurrentOpenOutwardBillingPeriods();

	@Query(value = "select top 1 * from SmartPRAMaster.mas_outward_billing_period WHERE closing_indicator='N' and client_Id = :clientId ORDER BY end_date ASC", nativeQuery = true)
	OutwardBillingPeriodsEntity getCurrentOpenOutwardBillingPeriodsByClientId(@Param("clientId") String clientId);

}
