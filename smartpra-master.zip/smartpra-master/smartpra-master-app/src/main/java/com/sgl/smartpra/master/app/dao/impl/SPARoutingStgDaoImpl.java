package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.SPARoutingStgDao;
import com.sgl.smartpra.master.app.dao.entity.SPARoutingStgEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.SPARoutingStgEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.SPARoutingStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SPARoutingStgDaoImpl implements SPARoutingStgDao {
	@Autowired
	private SPARoutingStgRepository spaRoutingStgRepository;

	@Override
	@Cacheable(value = "spaRoutingStg", key = "#spaRoutingId")
	public Optional<SPARoutingStgEntity> findById(Integer spaRoutingId) {
		log.info("Cacheable SPA Routing Entity's ID= {}", spaRoutingId);
		return spaRoutingStgRepository.findById(spaRoutingId);
	}

	@Override
	public List<SPARoutingStgEntity> findBySpaKeyMainIdClientId(Optional<Integer> spaKey, Optional<Integer> spaMainId,
			Optional<String> clientId) {
		return spaRoutingStgRepository
				.findAll(SPARoutingStgEntitySpecification.findBySpaKeyMainIdClientId(spaKey, spaMainId, clientId));
	}

}
