package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_fare_basis_translation")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class FareBasisTranslationEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fbt_id")
	private Integer fbtId;

	@Column(name = "marketing_fare_basis", length = 15)
	private String marketingFareBasis;

	@Column(name = "marketing_td", length = 10)
	private String marketingTD;

	@Column(name = "fare_owner_cxr", length = 2, nullable = false)
	private String fareOwnerCXR;

	@Column(name = "effective_from_date", nullable = false)
	@NotNull
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	@NotNull
	private LocalDate effectiveToDate;

	@Column(name = "area_fbw_indicator", length = 1)
	private String areaFBWIndicator;

	@Column(name = "from_area", length = 4)
	private String fromArea;

	@Column(name = "to_area", length = 4)
	private String toArea;

	@Column(name = "via_area", length = 4)
	private String viaArea;

	@Column(name = "cabin", length = 1)
	private String cabin;

	@Column(name = "normal_special", length = 1)
	private String normalSpecial;

	@Column(name = "iata_fare_type", length = 2)
	private String iataFareType;

	@Column(name = "atpco_fare_type", length = 3)
	private String atpcoFareType;

	@Column(name = "seasonal_code", length = 1)
	private String seasonalCode;

	@Column(name = "day_of_week", length = 1)
	private String dayOfWeek;

	@Column(name = "pax_type", length = 3)
	private String paxType;

	@Column(name = "discount_code", length = 2)
	private String discountCode;

	@Column(name = "journey_type", length = 2)
	private String journeyType;

	@Column(name = "zed_identifier", length = 2)
	private String zedIdentifier;

	@Column(name = "bt_it_indicator", length = 1)
	private String btItIndicator;

	@Column(name = "unpublish_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean unpublishFlag;

	@Column(name = "non_revenue_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean nonRevenueFlag;

	@Column(name = "is_pattern", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isPattern;

	@Column(name = "client_id", nullable = true, length = 2)
	private String clientId;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
