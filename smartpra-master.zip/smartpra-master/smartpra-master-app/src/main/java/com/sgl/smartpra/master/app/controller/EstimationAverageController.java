package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.EstimationAverageService;
import com.sgl.smartpra.master.model.EstimationAverage;
import com.sgl.smartpra.master.model.EstimationAverageResponse;
import com.sgl.smartpra.master.model.RBD;

@RestController
public class EstimationAverageController {

	@Autowired
	private EstimationAverageService estimationAverageService;

	@GetMapping("/estimation-average/search")
	public List<EstimationAverage> getListOfEstimationAverages(
			@RequestParam(value = "flightNumber", required = false) Optional<String> flightNumber,
			@RequestParam(value = "fromAirport", required = false) Optional<String> fromAirport,
			@RequestParam(value = "toAirport", required = false) Optional<String> toAirport,
			@RequestParam(value = "rbd", required = false) Optional<String> rbd,
			@RequestParam(value = "cabin", required = false) Optional<String> cabin,
			@RequestParam(value = "passengerType", required = false) Optional<String> passengerType,
			@RequestParam(value = "selfOc", required = false) Optional<String> selfOc,
			@RequestParam(value = "flightDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> flightDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		EstimationAverage estimationAverage = new EstimationAverage();
		// estimationAverage.setClientId(clientId);
		estimationAverage.setFlightNumber(flightNumber);
		estimationAverage.setFromAirport(fromAirport);
		estimationAverage.setToAirport(toAirport);
		estimationAverage.setRbd(rbd);
		estimationAverage.setCabin(cabin);
		estimationAverage.setPassengerType(passengerType);
		estimationAverage.setSelfOc(selfOc);
		if (OptionalUtil.isPresent(flightDate)) {
			estimationAverage.setFlightDate(flightDate);
		}
		estimationAverage.setActivate(OptionalUtil.getValue(activate));
		return estimationAverageService.getAllEstimationAverages(estimationAverage, Optional.of(""));
	}

	@GetMapping("/estimation-average/search/clientId/{clientId}")
	public List<EstimationAverage> getListOfEstimationAverages(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "flightNumber", required = false) Optional<String> flightNumber,
			@RequestParam(value = "fromAirport", required = false) Optional<String> fromAirport,
			@RequestParam(value = "toAirport", required = false) Optional<String> toAirport,
			@RequestParam(value = "rbd", required = false) Optional<String> rbd,
			@RequestParam(value = "cabin", required = false) Optional<String> cabin,
			@RequestParam(value = "passengerType", required = false) Optional<String> passengerType,
			@RequestParam(value = "selfOc", required = false) Optional<String> selfOc,
			@RequestParam(value = "flightDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> flightDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {

		EstimationAverage estimationAverage = new EstimationAverage();
		estimationAverage.setClientId(clientId);
		estimationAverage.setFlightNumber(flightNumber);
		estimationAverage.setFromAirport(fromAirport);
		estimationAverage.setToAirport(toAirport);
		estimationAverage.setRbd(rbd);
		estimationAverage.setCabin(cabin);
		estimationAverage.setPassengerType(passengerType);
		estimationAverage.setSelfOc(selfOc);
		if (OptionalUtil.isPresent(flightDate)) {
			estimationAverage.setFlightDate(flightDate);
		}
		estimationAverage.setActivate(OptionalUtil.getValue(activate));
		return estimationAverageService.getAllEstimationAverages(estimationAverage, exceptionCall);
	}

	@GetMapping("/estimation-average/list/clientId/{clientId}")
	public EstimationAverageResponse getListOfEstimationAverages(Pageable pageable,
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "flightNumber", required = false) Optional<String> flightNumber,
			@RequestParam(value = "fromAirport", required = false) Optional<String> fromAirport,
			@RequestParam(value = "toAirport", required = false) Optional<String> toAirport,
			@RequestParam(value = "rbd", required = false) Optional<String> rbd,
			@RequestParam(value = "cabin", required = false) Optional<String> cabin,
			@RequestParam(value = "passengerType", required = false) Optional<String> passengerType,
			@RequestParam(value = "selfOc", required = false) Optional<String> selfOc,
			@RequestParam(value = "flightDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> flightDate,
			@RequestParam(value = "activate", required = false) Boolean activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {

		EstimationAverage estimationAverage = new EstimationAverage();
		estimationAverage.setClientId(clientId);
		estimationAverage.setFlightNumber(flightNumber);
		estimationAverage.setFromAirport(fromAirport);
		estimationAverage.setToAirport(toAirport);
		estimationAverage.setRbd(rbd);
		estimationAverage.setCabin(cabin);
		estimationAverage.setPassengerType(passengerType);
		estimationAverage.setSelfOc(selfOc);
		if (OptionalUtil.isPresent(flightDate)) {
			estimationAverage.setFlightDate(flightDate);
		}
		estimationAverage.setActivate(activate);

		return estimationAverageService.getAllEstimationAverages(pageable, estimationAverage, exceptionCall);
	}


	@GetMapping("/estimation-average")
	public EstimationAverage getEstimationAverage(
			@RequestParam(value = "flightNumber", required = false) Optional<String> flightNumber,
			@RequestParam(value = "fromAirport", required = false) Optional<String> fromAirport,
			@RequestParam(value = "toAirport", required = false) Optional<String> toAirport,
			@RequestParam(value = "rbd", required = false) Optional<String> rbd,
			@RequestParam(value = "cabin", required = false) Optional<String> cabin,
			@RequestParam(value = "passengerType", required = false) Optional<String> passengerType,
			@RequestParam(value = "selfOc", required = false) Optional<String> selfOc,
			@RequestParam(value = "flightDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> flightDate) {

		return estimationAverageService.findEstimationAverage(flightNumber, fromAirport, toAirport, rbd, cabin,
				passengerType, selfOc, flightDate);
	}

	@PostMapping("/estimation-average")
	public EstimationAverage createEstimationAverage(
			@Validated(Create.class) @RequestBody EstimationAverage estimationAverage) {

		return estimationAverageService.createEstimationAverage(estimationAverage);

	}

	@PutMapping("/estimation-average/{estimationAverageId}")
	public EstimationAverage updateEstimationAverage(@PathVariable("estimationAverageId") Integer estimationAverageId,
			@Validated(Update.class) @RequestBody EstimationAverage estimationAverage) {

		return estimationAverageService.updateEstimationAverage(estimationAverageId, estimationAverage);
	}

	@GetMapping("/estimation-average/{estimationAverageId}")
	public EstimationAverage findByEstimationAverageId(
			@PathVariable("estimationAverageId") Integer estimationAverageId) {

		return estimationAverageService.findByEstimationAverageId(estimationAverageId);

	}

	@PutMapping("/estimation-average/{estimationAverageId}/deactivate")
	public void deactivateAircraft(@Valid @PathVariable(value = "estimationAverageId") Integer estimationAverageId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		estimationAverageService.deactivateEstimationAverage(estimationAverageId, lastUpdatedBy);
	}

	@PutMapping("/estimation-average/{estimationAverageId}/activate")
	public void activateAircraft(@Valid @PathVariable(value = "estimationAverageId") Integer estimationAverageId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		estimationAverageService.activateEstimationAverage(estimationAverageId, lastUpdatedBy);
	}

	@GetMapping("/estimation-average/cabin/{cabin}")
	public List<RBD> getRbdByCabin(@PathVariable("cabin") String cabin) {
		return estimationAverageService.getRbdByCabin(cabin);

	}
}