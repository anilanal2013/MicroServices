package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.ListOfValuesEntity;

@Repository
public interface ListOfValuesDao {
	
	public Optional<ListOfValuesEntity> findById(Integer lovId);

	public ListOfValuesEntity create(ListOfValuesEntity listOfValuesEntity);

	public ListOfValuesEntity update(ListOfValuesEntity listOfValuesEntity);
	
	ListOfValuesEntity fetchListOfValues(Optional<String> clientId, Optional<String> tableName, Optional<String> columnName
			, Optional<String> fieldValue);
	
	
	List<ListOfValuesEntity> fetchListOfValuesList(Optional<String> clientId, Optional<String> tableName, Optional<String> columnName);
	
	List<String> fetchListOfValue(String clientId, String tableName, String columnName);
}
