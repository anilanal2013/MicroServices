package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.ProrateDiscountEntity;
import com.sgl.smartpra.master.model.ProrateDiscount;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProrateDiscountMapper extends BaseMapper<ProrateDiscount, ProrateDiscountEntity> {

	ProrateDiscountEntity mapToEntity(ProrateDiscount prorateDiscount,
			@MappingTarget ProrateDiscountEntity prorateDiscountEntity);
    
	@Mapping(source = "prorateDiscountId", target = "prorateDiscountId", ignore = true)
	ProrateDiscountEntity mapToEntity(ProrateDiscount prorateDiscount);

}
