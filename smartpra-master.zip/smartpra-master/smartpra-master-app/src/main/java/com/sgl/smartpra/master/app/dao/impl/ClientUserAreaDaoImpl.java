package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.ClientUserAreaDao;
import com.sgl.smartpra.master.app.dao.entity.ClientUserAreaEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.ClientUserAreaDaoEntitySpec;
import com.sgl.smartpra.master.app.dao.repository.ClientUserAreaRepository;

@Component
public class ClientUserAreaDaoImpl implements ClientUserAreaDao {

	@Autowired
	private ClientUserAreaRepository repository;

	@Override
	public List<ClientUserAreaEntity> search(Optional<String> userAreaCode, Optional<String> userAreaName,
			Optional<Boolean> activate) {
		return repository.findAll(ClientUserAreaDaoEntitySpec.search(userAreaCode, userAreaName, activate));
	}

	@Override
	@Cacheable(value = "clientUserArea", key = "#userAreaId")
	public Optional<ClientUserAreaEntity> findById(Integer userAreaId) {
		return repository.findById(userAreaId);
	}

	@Override
	@CachePut(value = "clientUserArea", key = "#clientUserAreaEntity.userAreaId")
	public ClientUserAreaEntity update(ClientUserAreaEntity clientUserAreaEntity) {
		return repository.save(clientUserAreaEntity);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "clientUserArea", key = "#clientUserAreaEntity.userAreaId") })
	public ClientUserAreaEntity create(ClientUserAreaEntity clientUserAreaEntity) {
		return repository.save(clientUserAreaEntity);
	}

	@Override
	public Optional<ClientUserAreaEntity> getOverLapRecordCount(String userAreaCode, String areaKey1, String areaKey2,
			String areaKey3, String areaKey4) {
		return repository.findOne(Specification.where(ClientUserAreaDaoEntitySpec.equalsUserAreaCode(userAreaCode)
				.and(ClientUserAreaDaoEntitySpec.equalsAreaKey1(areaKey1))
				.and(ClientUserAreaDaoEntitySpec.equalsAreaKey2(areaKey2))
				.and(ClientUserAreaDaoEntitySpec.equalsAreaKey3(areaKey3))
				.and(ClientUserAreaDaoEntitySpec.equalsAreaKey4(areaKey4))));
	}

	@Override
	public List<ClientUserAreaEntity> getClientUserArea(String userAreaCode, String areaKey1, String areaKey2,
			String areaKey3, String areaKey4, Boolean activate) {
		return repository.findAll(ClientUserAreaDaoEntitySpec.getClientUserArea(userAreaCode, areaKey1, areaKey2,
				areaKey3, areaKey4, activate));
	}

	

}
