package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.ReportingSystemIdentifierEntity;
import com.sgl.smartpra.master.model.ReportingSystemIdentifier;

public class ReportingSystemIdentifierEntitySpecification {

	public static final String RPSICODE = "rpsiCode";
	public static final String CLIENTID = "clientId";
	public static final String ACTIVE = "isActive";
	public static final String SYSTEMPROVIDER = "systemProvider";

	private ReportingSystemIdentifierEntitySpecification() {
	}

	public static Specification<ReportingSystemIdentifierEntity> equalsRPSICode(String rpsiCode) {
		return (reportingSystemIdentifierEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(reportingSystemIdentifierEntity.get(RPSICODE), rpsiCode);
	}

	public static Specification<ReportingSystemIdentifierEntity> equalsClientId(String clientId) {
		return (reportingSystemIdentifierEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(reportingSystemIdentifierEntity.get(CLIENTID), clientId);
	}

	public static Specification<ReportingSystemIdentifierEntity> isActive() {
		return (reportingSystemIdentifierEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(reportingSystemIdentifierEntity.get(ACTIVE), true);
	}

	public static void orderByAsc(Root<ReportingSystemIdentifierEntity> reportingSystemIdentifierEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(reportingSystemIdentifierEntity.get(orderByString)));
	}

	public static Specification<ReportingSystemIdentifierEntity> getAllReportingSystemIdentifier(
			ReportingSystemIdentifier reportingSystemIdentifier, Optional<String> exceptionCall) {
		return (reportingSystemIdentifierEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(reportingSystemIdentifier.getClientId())) {
				predicates.add(criteriaBuilder.equal(reportingSystemIdentifierEntity.get("clientId"),
						OptionalUtil.getValue(reportingSystemIdentifier.getClientId())));
			}

			if (OptionalUtil.isPresent(reportingSystemIdentifier.getRpsiCode())) {
				predicates.add(criteriaBuilder.like(reportingSystemIdentifierEntity.get(RPSICODE),
						OptionalUtil.getValue(reportingSystemIdentifier.getRpsiCode()) + "%"));
			}
			if (OptionalUtil.isPresent(reportingSystemIdentifier.getSystemProvider())) {
				predicates.add(criteriaBuilder.like(reportingSystemIdentifierEntity.get(SYSTEMPROVIDER),
						OptionalUtil.getValue(reportingSystemIdentifier.getSystemProvider()) + "%"));
			}

			if (!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (reportingSystemIdentifier.getIsActive() != null) {
					predicates.add(criteriaBuilder.equal(reportingSystemIdentifierEntity.get("isActive"),
							reportingSystemIdentifier.getIsActive()));
				}
				if (reportingSystemIdentifier.getIsActive() == null) {
					predicates.add(criteriaBuilder.equal(reportingSystemIdentifierEntity.get("isActive"), true));
				}
			}
			orderByAsc(reportingSystemIdentifierEntity, criteriaQuery, criteriaBuilder, RPSICODE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
