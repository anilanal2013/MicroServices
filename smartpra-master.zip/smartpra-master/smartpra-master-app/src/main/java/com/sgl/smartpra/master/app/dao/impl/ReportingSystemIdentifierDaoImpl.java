package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.ReportingSystemIdentifierDao;
import com.sgl.smartpra.master.app.dao.entity.ReportingSystemIdentifierEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.ReportingSystemIdentifierEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.ReportingSystemIdentifierRepository;
import com.sgl.smartpra.master.model.ReportingSystemIdentifier;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ReportingSystemIdentifierDaoImpl extends CommonSearchDao<ReportingSystemIdentifier>
		implements ReportingSystemIdentifierDao {

	@Autowired
	private ReportingSystemIdentifierRepository reportingSystemIdentifierRepository;

	@Override
	@Cacheable(value = "reportingSystemIdentifier", key = "#id")
	public Optional<ReportingSystemIdentifierEntity> findById(Integer id) {
		log.info("Cacheable ReportingSystemIdentifier Entity's ID = {}", id);
		return reportingSystemIdentifierRepository.findById(id);
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "reportingSystemIdentifier", key = "#reportingSystemIdentifierEntity.rpsiAutoId"),
			@CacheEvict(value = "rpsiCode", allEntries = true), @CacheEvict(value = "clientId", allEntries = true) })
	public ReportingSystemIdentifierEntity create(ReportingSystemIdentifierEntity reportingSystemIdentifierEntity) {
		return reportingSystemIdentifierRepository.save(reportingSystemIdentifierEntity);
	}

	@Override
	@CachePut(value = "reportingSystemIdentifier", key = "#reportingSystemIdentifierEntity.rpsiAutoId")
	@Caching(evict = { @CacheEvict(value = "rpsiCode", allEntries = true),
			@CacheEvict(value = "clientId", allEntries = true) })
	public ReportingSystemIdentifierEntity update(ReportingSystemIdentifierEntity reportingSystemIdentifierEntity) {
		return reportingSystemIdentifierRepository.save(reportingSystemIdentifierEntity);
	}

	@Override
	@Cacheable(cacheNames = { "rpsiCode", "clientId" })
	public Optional<ReportingSystemIdentifierEntity> getRpsiCodeByClientIdAndRpsiCode(Optional<String> rpsiCode,
			Optional<String> clientId) {
		return reportingSystemIdentifierRepository.findOne(Specification
				.where(ReportingSystemIdentifierEntitySpecification.equalsRPSICode(OptionalUtil.getValue(rpsiCode))
						.and(ReportingSystemIdentifierEntitySpecification
								.equalsClientId(OptionalUtil.getValue(clientId))
								.and(ReportingSystemIdentifierEntitySpecification.isActive()))));

	}

	@Override
	public List<ReportingSystemIdentifierEntity> getAllReportingSystemIdentifier(
			ReportingSystemIdentifier reportingSystemIdentifier, Optional<String> exceptionCall) {
		return reportingSystemIdentifierRepository
				.findAll(Specification.where(ReportingSystemIdentifierEntitySpecification
						.getAllReportingSystemIdentifier(reportingSystemIdentifier, exceptionCall)));
	}

}
