package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.FOPEntity;
import com.sgl.smartpra.master.model.FOP;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FOPMapper extends BaseMapper<FOP, FOPEntity> {

	FOPEntity mapToEntity(FOP fop, @MappingTarget FOPEntity fopEntity);

	@Mapping(source = "fopId", target = "fopId", ignore = true)
	FOPEntity mapToEntity(FOP fop);

}
