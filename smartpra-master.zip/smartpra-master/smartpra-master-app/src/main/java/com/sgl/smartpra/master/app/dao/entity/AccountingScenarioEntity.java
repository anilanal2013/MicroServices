package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_scenario")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class AccountingScenarioEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "scenario_number", nullable = false)
	private Integer scenarioNumber;

	@Column(name = "client_id", nullable = false, length = 2)
	private String clientId;

	@Column(name = "module", nullable = false, length = 2)
	private String module;

	@Column(name = "transaction_type", nullable = false, length = 5)
	private String transactionType;

	@Column(name = "self_oal_indicator", length = 1)
	private String selfOalIndicator;

	@Column(name = "sales_exist_indicator", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean salesExistIndicator;

	@Column(name = "doc_type", length = 3)
	private String docType;

	@Column(name = "charge_cat_code", length = 3)
	private String chargeCatCode;

	@Column(name = "charge_code", length = 6)
	private String chargeCode;

	@Column(name = "pre_implementation_indicator", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean preImplementationIndicator;

	@Column(name = "misc_document_util_type", length = 15)
	private String miscDocumentUtilType;

	@Column(name = "misc_document_issued_for", length = 15)
	private String miscDocumentIssuedFor;

	@Column(name = "invoice_type", length = 2)
	private String invoiceType;

	@Column(name = "source_code", length = 2)
	private String sourceCode;

	@Column(name = "delivering_carrier_indicator", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean deliveringCarrierIndicator;

	@Column(name = "receiving_carrier_indicator", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean receivingCarrierIndicator;

	@Column(name = "prime_reissue_indicator", length = 1)
	private String primeReissueIndicator;

	@Column(name = "fop_type", length = 2)
	private String fopType;

	@Column(name = "rejection_memo_type", length = 2)
	private String rejectionMemoType;

	@Column(name = "ancillary_service", length = 1)
	private String ancillaryService;

	@Column(name = "bsp_agent_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean bspAgentFlag;

	@Column(name = "is_active", nullable = false, length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
