package com.sgl.smartpra.master.app.repository.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_form_code database table.
 * 
 */
@Entity
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
@Data
@Table(name = "mas_form_code")
@NamedQuery(name = "FormCodeEntity.findAll", query = "SELECT m FROM FormCodeEntity m")
public class FormCodeEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "form_code_id")
	private int formCodeId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "document_type")
	private String documentType;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Column(name = "form_code")
	private String formCode;

	@Column(name = "form_decription")
	private String formDecription;

	@Column(name = "incld_airline_code_checkdigit")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean incldAirlineCodeCheckdigit;

	@Column(name = "include_coupon_checkdigit")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean includeCouponCheckdigit;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "is_stock_maintained")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isStockMaintained;

	@Column(name = "number_of_coupon")
	private String numberOfCoupon;

	private String remarks;
}