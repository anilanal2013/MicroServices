package com.sgl.smartpra.master.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.sgl.smartpra.master.app.dao.entity.FlightControlEntity;

public interface FlightControlRepository
		extends JpaRepository<FlightControlEntity, Integer>, JpaSpecificationExecutor<FlightControlEntity> {
	List<FlightControlEntity> findByFlightControlIdAndClientId(String flightControlId,String clientId);

	@Query(value = "select CAST(SUBSTRING(flightControlId, 3, 6) AS int) AS id from FlightControlEntity ORDER BY id desc")
	List<Integer> getControlIdNumber();
}
