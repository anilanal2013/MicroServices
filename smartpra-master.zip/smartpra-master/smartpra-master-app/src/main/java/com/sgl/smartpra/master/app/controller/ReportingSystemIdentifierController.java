package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.ReportingSystemIdentifierService;
import com.sgl.smartpra.master.model.ReportingSystemIdentifier;

@RestController
public class ReportingSystemIdentifierController {

	@Autowired
	
	private ReportingSystemIdentifierService reportingSystemIdentifierService;

	@GetMapping("/rpsi")
	public List<ReportingSystemIdentifier> getAllRpsi(
			@RequestParam(value = "rpsiCode", required = false) Optional<String> rpsiCode,
			@RequestParam(value = "systemProvider", required = false) Optional<String> systemProvider,
			@RequestParam(value = "isActive", required = false) Boolean isActive) {

		ReportingSystemIdentifier reportingSystemIdentifier = new ReportingSystemIdentifier();
		// reportingSystemIdentifier.setClientId(clientId);
		reportingSystemIdentifier.setRpsiCode(rpsiCode);
		reportingSystemIdentifier.setSystemProvider(systemProvider);
		reportingSystemIdentifier.setIsActive(isActive);

		return reportingSystemIdentifierService.getAllReportingSystemIdentifier(reportingSystemIdentifier,
				Optional.of(""));
	}

	@GetMapping("/rpsi/search/clientId/{clientId}")
	public List<ReportingSystemIdentifier> getAllRpsi(@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "rpsiCode", required = false) Optional<String> rpsiCode,
			@RequestParam(value = "systemProvider", required = false) Optional<String> systemProvider,
			@RequestParam(value = "isActive", required = false) Boolean isActive,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {

		ReportingSystemIdentifier reportingSystemIdentifier = new ReportingSystemIdentifier();
		reportingSystemIdentifier.setClientId(clientId);
		reportingSystemIdentifier.setRpsiCode(rpsiCode);
		reportingSystemIdentifier.setSystemProvider(systemProvider);
		reportingSystemIdentifier.setIsActive(isActive);

		return reportingSystemIdentifierService.getAllReportingSystemIdentifier(reportingSystemIdentifier,
				exceptionCall);
	}

	@GetMapping("/rpsi/{rpsiAutoId}")
	public ReportingSystemIdentifier getReportingSystemIdentifierByRPSIAutoId(
			@PathVariable(value = "rpsiAutoId") Integer rpsiAutoId) {
		return reportingSystemIdentifierService.getReportingSystemIdentifierByRPSIAutoId(rpsiAutoId);
	}
	
	@GetMapping("/rpsi/rpsi-clientId-search")
	public ReportingSystemIdentifier getRpsiCodeByClientIdAndRpsiCode(
			@RequestParam(value = "rpsiCode", required = true) Optional<String> rpsiCode,
			@RequestParam(value = "clientId", required = true) Optional<String> clientId) {
		return reportingSystemIdentifierService.getRpsiCodeByClientIdAndRpsiCode(rpsiCode,clientId);
	}

	@PostMapping("/rpsi")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ReportingSystemIdentifier createReportingSystemIdentifier(
			@Validated(Create.class) @RequestBody ReportingSystemIdentifier reportingSystemIdentifier) {
		return reportingSystemIdentifierService.createReportingSystemIdentifier(reportingSystemIdentifier);
	}

	@PutMapping("/rpsi/{rpsiAutoId}")
	@ResponseStatus(value = HttpStatus.OK)
	public ReportingSystemIdentifier updateReportingSystemIdentifier(
			@PathVariable(value = "rpsiAutoId") Integer rpsiAutoId,
			@Validated(Update.class) @RequestBody ReportingSystemIdentifier reportingSystemIdentifier) {
		reportingSystemIdentifier.setRpsiAutoId(rpsiAutoId);
		return reportingSystemIdentifierService.updateReportingSystemIdentifier(reportingSystemIdentifier);
	}

	@PutMapping("/rpsi/{rpsiAutoId}/deactivate")
	public void deactivateReportingSystemIdentifier(@Valid @PathVariable(value = "rpsiAutoId") Integer rpsiAutoId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		reportingSystemIdentifierService.deactivateReportingSystemIdentifier(rpsiAutoId, lastUpdatedBy);
	}

	@PutMapping("/rpsi/{rpsiAutoId}/activate")
	public void activateReportingSystemIdentifier(@Valid @PathVariable(value = "rpsiAutoId") Integer rpsiAutoId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		reportingSystemIdentifierService.activateReportingSystemIdentifier(rpsiAutoId, lastUpdatedBy);
	}
}
