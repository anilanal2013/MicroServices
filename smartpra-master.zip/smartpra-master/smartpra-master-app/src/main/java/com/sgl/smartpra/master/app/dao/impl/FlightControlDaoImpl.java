package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.FlightControlDao;
import com.sgl.smartpra.master.app.dao.entity.FlightControlEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.FlightControlEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.FlightControlRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FlightControlDaoImpl implements FlightControlDao {

	@Autowired
	FlightControlRepository flightControlRepository;

	@Override
	@Cacheable(value = "flightControl", key = "#flightControlAutoId")
	public Optional<FlightControlEntity> findById(Integer flightControlAutoId) {
		log.info("Cacheable FlightControl Entity's ID= {}", flightControlAutoId);
		return flightControlRepository.findById(flightControlAutoId);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "flightControl", key = "#flightControlEntity.flightControlAutoId") })
	public FlightControlEntity create(FlightControlEntity flightControlEntity) {
		return flightControlRepository.save(flightControlEntity);
	}

	@Override
	@CachePut(value = "flightControl", key = "#flightControlEntity.flightControlAutoId")
	public FlightControlEntity update(FlightControlEntity flightControlEntity) {
		return flightControlRepository.save(flightControlEntity);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "flightControl", key = "#id") })
	public void delete(Integer id) {
		flightControlRepository.deleteById(id);

	}

	@Override
	public List<FlightControlEntity> search(String clientId, String flightControlId, Boolean activate,Optional<String> exceptionCall) {
		return flightControlRepository.findAll(FlightControlEntitySpecification.search(Optional.ofNullable(clientId),
				Optional.ofNullable(flightControlId), Optional.ofNullable(activate),exceptionCall));
	}

	@Override
	public List<FlightControlEntity> search(String clientId) {
		return flightControlRepository
				.findAll(Specification.where(FlightControlEntitySpecification.equalsClientId(clientId))
						.and(FlightControlEntitySpecification.activate()));
	}

	@Override
	public long getOverlapCount(String clientId, String flightControlId) {
		return flightControlRepository.count(FlightControlEntitySpecification.equalsClientId(clientId)
				.and(FlightControlEntitySpecification.equalsFlightControlId(flightControlId)));
	}

	@Override
	public long getOverlapCount(String clientId, String flightControlId, Integer flightControlAutoId) {
		return flightControlRepository.count(FlightControlEntitySpecification.equalsClientId(clientId)
				.and(FlightControlEntitySpecification.equalsFlightControlId(flightControlId))
				.and(FlightControlEntitySpecification.notEqualsfopId(flightControlAutoId)));
	}

	@Override
	public long validateControlFormulae(String flightControlId) {
		return flightControlRepository.count((FlightControlEntitySpecification.equalsFlightControlId(flightControlId)));
	}
}
