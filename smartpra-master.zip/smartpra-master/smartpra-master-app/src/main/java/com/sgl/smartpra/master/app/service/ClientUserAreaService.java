package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.sgl.smartpra.master.model.ClientUserArea;
import com.sgl.smartpra.proration.model.farebasis.UserAreaDefine;

public interface ClientUserAreaService {

	public List<ClientUserArea> getClientListOfUserArea(Optional<String> userAreaCode, Optional<String> userAreaName,Optional<Boolean> activate);

	public UserAreaDefine getClientUserArea(UserAreaDefine userAreaDefine);

	public ClientUserArea getClientUserAreaByUserAreaCode(Integer userAreaId);

	public ClientUserArea createClientUserArea(ClientUserArea clientUserArea);

	public ClientUserArea updateClientUserArea(Integer userAreaId, ClientUserArea clientUserArea);

	public void deactivateClientUserArea(Integer userAreaId, String lastUpdatedBy);

	public void activateClientUserArea(Integer userAreaId, String lastUpdatedBy);

	public void clientSpecificUserAreaInsertOrUpdate(Map<String, String> map);

	public boolean isValidateAreaCode(String areaCode);

	public void deleteClientUserArea(String areaKey1, String areaKey2, String areaKey3);

	public List<ClientUserArea> getClientListOfUserAreaForCaptureArea(Optional<String> userAreaCode,
			Optional<String> areaKey1, Optional<String> areaKey2, Optional<String> areaKey3, Optional<String> areaKey4,
			Optional<Boolean> activate);

}