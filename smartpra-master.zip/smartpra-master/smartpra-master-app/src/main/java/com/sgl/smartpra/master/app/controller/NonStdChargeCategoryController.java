package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.NonStandardChargeCategoryService;
import com.sgl.smartpra.master.model.NonStandardChargeCategory;

@RestController
@RequestMapping("nonstd-charge-categories")
public class NonStdChargeCategoryController {

	@Autowired
	private NonStandardChargeCategoryService nonStdChargeCategoryService;
	
	@GetMapping("/id/{nonStdCategoryId}")
	public NonStandardChargeCategory findNonStdChargeCategoryId(@PathVariable(value = "nonStdCategoryId", required = true) Integer nonStdCategoryId) {
		return nonStdChargeCategoryService.findById(nonStdCategoryId);
	}

	@PostMapping("/create")
	public NonStandardChargeCategory createNonStandardChargeCategory(@Validated(Create.class) @RequestBody NonStandardChargeCategory nonStdChargeCategory) {
		return nonStdChargeCategoryService.create(nonStdChargeCategory);
	}

	@PutMapping("/update")
	public NonStandardChargeCategory updateNonStandardChargeCategory(@Validated(Update.class) @RequestBody NonStandardChargeCategory nonStdChargeCategory) {
		return nonStdChargeCategoryService.update(nonStdChargeCategory);
	}

	@GetMapping("/search")
	public List<NonStandardChargeCategory> searchNonStandardChargeCategory(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "nonStdCategoryCode", required = false) Optional<String> nonStdCategoryCode, 
			@RequestParam(value = "stdCategoryCode", required = false) Optional<String> stdCategoryCode, 
			@RequestParam(value = "isActive", required = false) Optional<String> isActive) {
		return nonStdChargeCategoryService.searchNonStandardChargeCategory(clientId, nonStdCategoryCode, stdCategoryCode, isActive);
	}

	@PutMapping("/activate")
	public String activateNonStandardChargeCategory(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "nonStdCategoryCode", required = true) String nonStdCategoryCode) {
		return nonStdChargeCategoryService.activateNonStandardChargeCategory(clientId, nonStdCategoryCode);
	}

	@PutMapping("/de-activate")
	public String deActivateNonStandardChargeCategory(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "nonStdCategoryCode", required = true) String nonStdCategoryCode) {
		return nonStdChargeCategoryService.deActivateNonStandardChargeCategory(clientId, nonStdCategoryCode);
	}
}
