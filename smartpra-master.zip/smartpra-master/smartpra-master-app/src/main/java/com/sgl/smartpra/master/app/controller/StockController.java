package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.model.KeyValue;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.StockService;
import com.sgl.smartpra.master.model.Stock;

@RestController
public class StockController {

	@Autowired
	private StockService stockService;

	@GetMapping("/stock")
	public List<Stock> getAllStock(
			@RequestParam(value = "documentSeriesFrom", required = false) Optional<String> documentSeriesFrom,
			@RequestParam(value = "documentSeriesTo", required = false) Optional<String> documentSeriesTo,
			@RequestParam(value = "documentType", required = false) Optional<String> documentType,
			@RequestParam(value = "clientId", required = false) Optional<String> clientId,
			@RequestParam(value = "effectiveFromDate", required = false) Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return stockService.getAllStock(documentSeriesFrom, documentSeriesTo, documentType, clientId ,effectiveFromDate,
				effectiveToDate, activate);
	}

	@GetMapping("/stock/{stockId}")
	public Stock getStockByStockId(@PathVariable(value = "stockId") Integer stockId) {
		return stockService.getStockByStockId(stockId);
	}

	@PostMapping("/stock")
	public Stock createStock(@Validated(Create.class) @RequestBody Stock stock) {
		return stockService.createStock(stock);
	}

	@PutMapping("/stock/{stockId}")
	public Stock updateStock(@PathVariable(value = "stockId") Integer stockId,
			@Validated(Update.class) @RequestBody Stock stock) {
		return stockService.updateStock(stockId, stock);
	}

	@PutMapping("/stock/{stockId}/deactivate")
	public void deactivateStock(@Valid @PathVariable(value = "stockId") Integer stockId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		stockService.deactivateStock(stockId, lastUpdatedBy);
	}

	@PutMapping("/stock/{stockId}/activate")
	public void activateStock(@Valid @PathVariable(value = "stockId") Integer stockId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		stockService.activateStock(stockId, lastUpdatedBy);
	}

	@GetMapping("/stock/documentType")
	public KeyValue getDocumentType(
			@RequestParam(value = "formCodeId" , required = true) String formCodeId,
			@RequestParam(value = "effectiveFromDate", required = true) String effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = true) String effectiveToDate) {
		return stockService.getDocumentType(formCodeId, effectiveFromDate, effectiveToDate);
	}
}