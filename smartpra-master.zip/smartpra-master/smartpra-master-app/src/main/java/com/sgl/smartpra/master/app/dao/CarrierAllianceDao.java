package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.app.dao.entity.CarrierAllianceEntity;

public interface CarrierAllianceDao {

	// ------------- CRUD------------
	public Optional<CarrierAllianceEntity> findById(Integer id);

	public CarrierAllianceEntity create(CarrierAllianceEntity carrierAllianceEntity);

	public CarrierAllianceEntity update(CarrierAllianceEntity carrierAllianceEntity);

	public void delete(Integer id);

	public List<CarrierAllianceEntity> findAll(String clientId);

	// --------------Search-----------
	public List<CarrierAllianceEntity> search(String carrierCode);

	public List<CarrierAllianceEntity> search(String carrierCode, LocalDate effectiveDate);

	public List<CarrierAllianceEntity> search(String allianceName, String clientId);

	public List<CarrierAllianceEntity> search(String allianceName, String clientId, LocalDate effectiveDate);

	public List<CarrierAllianceEntity> search(Optional<String> carrierCode, Optional<String> clientId,
			Optional<String> allianceName, Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	// -- This is for Create- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String allianceName,
			String carrierCode, String clientId);

	// -- This is for Update- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String allianceName,
			String carrierCode, String clientId, Integer carrierAllianceDtlId);

	public Optional<CarrierAllianceEntity> getAllianceByCarrierCodeAndEffectiveDate(String clientId, String carrierCode,
			Optional<String> effectiveDate);

}
