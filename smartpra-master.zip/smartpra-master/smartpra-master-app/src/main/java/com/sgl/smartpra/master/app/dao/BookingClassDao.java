package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.BookingClassEntity;
import com.sgl.smartpra.master.model.BookingClassModel;

@Repository
public interface BookingClassDao {
	public Optional<BookingClassEntity> findById(Integer id);

	public BookingClassEntity create(BookingClassEntity bookingClassEntity);

	public BookingClassEntity update(BookingClassEntity bookingClassEntity);

	public void delete(Integer id);

	public long getOverlapRecordCount(String rbd, String marketingCarrier, LocalDate utilEffectiveFromDate,
			LocalDate utilEffectiveToDate, LocalDate salesEffectiveFromDate, LocalDate salesEffectiveToDate);

	public long getOverlapRecordCount(String rbd, String marketingCarrier, LocalDate utilEffectiveFromDate,
			LocalDate utilEffectiveToDate, LocalDate salesEffectiveFromDate, LocalDate salesEffectiveToDate,
			Integer bookingClassId);

	public List<BookingClassEntity> search(BookingClassModel bookingClassModel, Optional<String> exceptionCall);

	public Optional<BookingClassEntity> getBookingClassByRBD(Optional<String> clientId, Optional<String> rbd,
			Optional<String> marketingCarrier, Optional<String> utilizationDate, Optional<String> salesDate);

	public List<BookingClassEntity> getCabinWithRBDS(String clientId, LocalDate salesDate, LocalDate utilizationDate);

	public List<String> getRbdByCabin(String cabin);

}
