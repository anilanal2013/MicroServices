package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.AccountModel;

public interface AccountService {

	AccountModel createAccount(AccountModel accountModel);

	AccountModel updateAccount(Integer accountAlphaCodeId, AccountModel accountModel);

	AccountModel findByAccount(Integer accountAlphaCodeId);

	List<AccountModel> getAllAccount(AccountModel accountModel);

	Boolean findByAccountAlphaCode(Optional<String> accountAlphaCode);

	List<AccountModel> getListOfAccountBYAccountAphaCode(List<String> accountAlphaCode);

}
