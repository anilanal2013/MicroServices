package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.SPARoutingStgEntity;
import com.sgl.smartpra.master.model.SPARoutingStg;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SPARoutingStgMapper extends BaseMapper<SPARoutingStg, SPARoutingStgEntity>{
	SPARoutingStgEntity mapToEntity(SPARoutingStg spaRoutingStg, @MappingTarget SPARoutingStgEntity spaRoutingStgEntity);
	@Mapping(source = "spaRoutingId", target = "spaRoutingId", ignore = true)
	SPARoutingStgEntity mapToEntity(SPARoutingStg spaRoutingStg);
}
