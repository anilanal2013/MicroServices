package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Entity
@Table(name = "mas_fare_basis_groupcode")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class FareBasisGroupcodeEntity extends BaseEntity {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fb_group_id")
	private Integer fbGroupId;
	
	@Column(name = "fb_group_code", nullable = false)
	@NotEmpty
	private String fbGroupCode;

	@Column(name = "seq_line_number", nullable = false)
	private Integer seqLineNumber;

	@Column(name = "fb_description", nullable = false)
	@NotEmpty
	private String fbDescription;
	
	@Column(name = "ticketed_fare_basis", nullable = true)
	private String ticketedFareBasis;
	
	@Column(name = "ticketed_td", nullable = true)
	private String ticketedTD;
	
	@Column(name = "fare_owner_cxr", nullable = true)
	private String fareOwnerCXR;
	
	@Column(name = "issue_cxr", nullable = true)
	private String issueCXR;
	
	@Column(name = "cabin", nullable = true)
	private String cabin;
	
	@Column(name = "normal_special", nullable = true)
	private String normalSpecial;
	
	@Column(name = "iata_fare_type", nullable = true)
	private String iataFareType;
	
	@Column(name = "atpco_fare_type", nullable = true)
	private String atpcoFareType;
	
	@Column(name = "seasonal_code", nullable = true)
	private String seasonalCode;
	
	@Column(name = "day_of_week", nullable = true)
	private String dayOfWeek;
	
	@Column(name = "pax_type", nullable = true)
	private String paxType;
	
	@Column(name = "discount_code", nullable = true)
	private String discountCode;
	
	@Column(name = "journey_type", nullable = true)
	private String journeyType;
	
	@Column(name = "zed_identifier", nullable = true)
	private String zedIdentifier;
	
	@Column(name = "bt_it_indicator", nullable = true)
	private String btItIndicator;
	
	@Column(name = "fare_text", nullable = true)
	private String fareText;
	
	@Column(name = "passenger_name", nullable = true)
	private String passengerName;
	
	@Column(name = "unpublish_flag", nullable = true)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean unpublishFlag;
	
	@Column(name = "non_revenue_flag", nullable = true)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean nonRevenueFlag;
	
	@Column(name = "is_pattern", nullable = true)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isPattern;
	
	@Column(name = "client_id", nullable = false)
	private String clientId;
	
	@Column(name = "is_active", nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}
	
	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

	
	
}

