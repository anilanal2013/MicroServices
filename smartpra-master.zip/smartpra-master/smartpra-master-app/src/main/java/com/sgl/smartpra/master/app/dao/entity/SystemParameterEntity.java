package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "mas_system_config")
@DynamicUpdate
@DynamicInsert
public class SystemParameterEntity extends BaseEntity{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "parameter_def_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer parameterId;
	
	@Column(name = "client_id", nullable = false)
	private String clientId;
	
	@Column(name = "group_name", nullable = false, length=25)
	private String groupName;
	
	@Column(name = "module_name", nullable = false, length=25)
	private String moduleName;
	
	@Column(name = "parameter_name", nullable = false, length=50)
	private String parameterName;
	
	@Column(name = "parameter_data_type", nullable = false, length=15)
	private String parameterDataType;

	@Column(name = "parameter_format", nullable = false, length=15)
	private String parameterFormat;
	
	@Column(name = "parameter_key", length=255)
	private String parameterKey;
	
	@Column(name = "reference_entity_name", length=50)
	private String referenceEntityName;
	
	@Column(name = "parameter_range_from", length=1000)
	private String parameterRangeFrom;
	
	@Column(name = "parameter_range_to", length=1000)
	private String parameterRangeTo;
	
	@Column(name = "airline_exception", length=100)
	private String airlineException;
	
	@Column(name = "parameter_description", length=100)
	private String parameterDescription;
	
	@Column(name = "is_readonly",nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isReadonly;
	
	@Column(name = "additional_description", length=100)
	private String additionalDescription;
	
	@Column(name = "reason_description", length=100)
	private String reasonDescription;
	
	@Column(name = "effective_from_date", length=100)
	protected LocalDate effectiveFromDate;
	
	@Column(name = "effective_to_date", length=100)
	protected LocalDate effectiveToDate;
	
	@Column(name = "is_visible", nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isVisible;
	
	@Column(name = "remarks",length=1000)
	private String remarks;
	
	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	protected Boolean isActive;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
