package com.sgl.smartpra.master.app.service.impl;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration;
import com.sgl.smartpra.master.app.dao.CommonRatedDao;
import com.sgl.smartpra.master.app.mapper.CommonRatedSectorMapper;
import com.sgl.smartpra.master.app.repository.entity.CommonRatedSectorEntity;
import com.sgl.smartpra.master.app.service.CommonRatedSectorService;
import com.sgl.smartpra.master.model.CommonRatedSector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class CommonRatedSectorServiceImpl implements CommonRatedSectorService {

	@Autowired
	private CommonRatedSectorMapper commonRatedSectorMapper;

	@Autowired
	private CommonRatedDao commonRatedDao;

	@Autowired
	private FeignConfiguration.GlobalMasterFeignClient globalMasterFeignClient;

	private static final String FROM_AIRPORT = "From Airport ";
	private static final String TO_AIRPORT = "To Airport ";
	private static final String COMMON_RATED_FROM_AIRPORT = "Common Rated From Airport ";
	private static final String COMMON_RATED_TO_AIRPORT = "Common Rated To Airport ";
	private static final String SHOULD_NOT_SAME = " should not be same";
	private static final String AND = " and ";

	@Override
	public List<CommonRatedSector> getAllCommonRatedSector(Optional<String> clientId, Optional<String> fromAirport,
			Optional<String> toAirport, Optional<String> commonRatedFromAirport,
			Optional<String> commonRatedToAirport) {
		return commonRatedSectorMapper.mapToModel(
				commonRatedDao.search(clientId, fromAirport, toAirport, commonRatedFromAirport, commonRatedToAirport));

	}

	@Override
	public List<CommonRatedSector> getAllCommonRatedSectors(Optional<String> fromAirport, Optional<String> toAirport,
			Optional<String> commonRatedFromAirport, Optional<String> commonRatedToAirport,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return commonRatedSectorMapper.mapToModel(commonRatedDao.getAllCommonRatedSectors(fromAirport, toAirport,
				commonRatedFromAirport, commonRatedToAirport, effectiveFromDate, effectiveToDate));
	}

	@Override
	public CommonRatedSector findCommonRatedSectorByCommonRatedSectorId(Integer commonRatedID) {
		return commonRatedSectorMapper
				.mapToModel(commonRatedDao.findCommonRatedSectorByCommonRatedSectorId(commonRatedID)
						.orElseThrow(() -> new RecordNotFoundException(String.valueOf(commonRatedID))));
	}

	@Override
	public CommonRatedSector createCommonRateSectors(CommonRatedSector commonRatedSector) {

		validateBusinessConstraintsForCreate(commonRatedSector);

		return commonRatedSectorMapper.mapToModel(
				commonRatedDao.createCommonRateSectors(commonRatedSectorMapper.mapToEntity(commonRatedSector)));
	}

	@Override
	public CommonRatedSector updateCommonRateSectors(Integer commonRatedID, CommonRatedSector commonRatedSector) {
		CommonRatedSectorEntity commonRatedSectorEntity = commonRatedDao.findById(commonRatedID)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(commonRatedID)));

		validateBusinessConstraintsForUpdate(commonRatedSector, commonRatedSectorEntity);

		return commonRatedSectorMapper.mapToModel(commonRatedDao.updateCommonRateSectors(
				commonRatedSectorMapper.mapToEntity(commonRatedSector, commonRatedSectorEntity)));

	}

	private void validateBusinessConstraintsForCreate(CommonRatedSector commonRatedSector) {
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(commonRatedSector.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(commonRatedSector.getEffectiveToDate()));
		validateCarrierDesignatorCode(commonRatedSector);
		validateAirportCode(commonRatedSector.getFromAirport(), FROM_AIRPORT);
		validateAirportCode(commonRatedSector.getToAirport(), TO_AIRPORT);
		validateAirportCode(commonRatedSector.getCommonRatedFromAirport(), COMMON_RATED_FROM_AIRPORT);
		validateAirportCode(commonRatedSector.getCommonRatedToAirport(), COMMON_RATED_TO_AIRPORT);
		validateFromAndToAirport(OptionalUtil.getValue(commonRatedSector.getFromAirport()),
				OptionalUtil.getValue(commonRatedSector.getToAirport()));
		validateCommonRatedFromAndToAirport(OptionalUtil.getValue(commonRatedSector.getCommonRatedFromAirport()),
				OptionalUtil.getValue(commonRatedSector.getCommonRatedToAirport()));

		validateToAirportAndCommonRatedFromRated(OptionalUtil.getValue(commonRatedSector.getCommonRatedFromAirport()),
				OptionalUtil.getValue(commonRatedSector.getToAirport()));

		validateFromAirportAndCommonRatedToRated(OptionalUtil.getValue(commonRatedSector.getCommonRatedToAirport()),
				OptionalUtil.getValue(commonRatedSector.getFromAirport()));
		validateFromAndToAirportAndCommonRatedAirport(commonRatedSector);
		validateOverLapForCreate(commonRatedSector);
	}

	private void validateBusinessConstraintsForUpdate(CommonRatedSector commonRatedSector,
			CommonRatedSectorEntity commonRatedSectorEntity) {

		validateEffectiveToDate(commonRatedSector, commonRatedSectorEntity);
		validateCarrierDesignatorCode(commonRatedSector);
		validateAirportCode(commonRatedSector.getFromAirport(), FROM_AIRPORT);
		validateAirportCode(commonRatedSector.getToAirport(), TO_AIRPORT);
		validateAirportCode(commonRatedSector.getCommonRatedFromAirport(), COMMON_RATED_FROM_AIRPORT);
		validateAirportCode(commonRatedSector.getCommonRatedToAirport(), COMMON_RATED_TO_AIRPORT);
		validateFromAndToAirport(getFromAirport(commonRatedSector, commonRatedSectorEntity),
				getToAirport(commonRatedSector, commonRatedSectorEntity));
		validateCommonRatedFromAndToAirport(getCommonRatedFromAirport(commonRatedSector, commonRatedSectorEntity),
				getCommonRatedToAirport(commonRatedSector, commonRatedSectorEntity));

		validateToAirportAndCommonRatedFromRated(getCommonRatedFromAirport(commonRatedSector, commonRatedSectorEntity),
				getToAirport(commonRatedSector, commonRatedSectorEntity));

		validateFromAirportAndCommonRatedToRated(getCommonRatedToAirport(commonRatedSector, commonRatedSectorEntity),
				getFromAirport(commonRatedSector, commonRatedSectorEntity));
		validateFromAndToAirportAndCommonRatedForUpdate(commonRatedSector, commonRatedSectorEntity);
		validateOverLapForUpdate(commonRatedSector, commonRatedSectorEntity);
	}

	private void validateEffectiveToDate(CommonRatedSector commonRatedSector,
			CommonRatedSectorEntity commonRatedSectorEntity) {
		if (OptionalUtil.isPresent(commonRatedSector.getEffectiveFromDate())
				|| OptionalUtil.isPresent(commonRatedSector.getEffectiveToDate())) {
			validateEffectiveToDate(getEffectiveFromDate(commonRatedSector, commonRatedSectorEntity),
					getEffectiveToDate(commonRatedSector, commonRatedSectorEntity));
		}
	}

	private LocalDate getEffectiveToDate(CommonRatedSector commonRatedSector,
			CommonRatedSectorEntity commonRatedSectorEntity) {
		return OptionalUtil.isPresent(commonRatedSector.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(commonRatedSector.getEffectiveToDate())
				: commonRatedSectorEntity.getEffectiveToDate();
	}

	private LocalDate getEffectiveFromDate(CommonRatedSector commonRatedSector,
			CommonRatedSectorEntity commonRatedSectorEntity) {
		return OptionalUtil.isPresent(commonRatedSector.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(commonRatedSector.getEffectiveFromDate())
				: commonRatedSectorEntity.getEffectiveFromDate();
	}

	private String getCommonRatedToAirport(CommonRatedSector commonRatedSector,
			CommonRatedSectorEntity commonRatedSectorEntity) {
		return OptionalUtil.isPresent(commonRatedSector.getCommonRatedToAirport())
				? OptionalUtil.getValue(commonRatedSector.getCommonRatedToAirport())
				: commonRatedSectorEntity.getCommonRatedToAirport();
	}

	private String getCommonRatedFromAirport(CommonRatedSector commonRatedSector,
			CommonRatedSectorEntity commonRatedSectorEntity) {
		return OptionalUtil.isPresent(commonRatedSector.getCommonRatedFromAirport())
				? OptionalUtil.getValue(commonRatedSector.getCommonRatedFromAirport())
				: commonRatedSectorEntity.getCommonRatedFromAirport();
	}

	private String getToAirport(CommonRatedSector commonRatedSector, CommonRatedSectorEntity commonRatedSectorEntity) {
		return OptionalUtil.isPresent(commonRatedSector.getToAirport())
				? OptionalUtil.getValue(commonRatedSector.getToAirport())
				: commonRatedSectorEntity.getToAirport();
	}

	private String getFromAirport(CommonRatedSector commonRatedSector,
			CommonRatedSectorEntity commonRatedSectorEntity) {
		return OptionalUtil.isPresent(commonRatedSector.getFromAirport())
				? OptionalUtil.getValue(commonRatedSector.getFromAirport())
				: commonRatedSectorEntity.getFromAirport();
	}

	private String getClientId(CommonRatedSector commonRatedSector, CommonRatedSectorEntity commonRatedSectorEntity) {
		return OptionalUtil.isPresent(commonRatedSector.getClientId())
				? OptionalUtil.getValue(commonRatedSector.getClientId())
				: commonRatedSectorEntity.getClientId();
	}

	private void validateAirportCode(Optional<String> airportCode, String value) {
		if (OptionalUtil.isPresent(airportCode)) {
			if (!globalMasterFeignClient.isValidAirportCodeOrCityCode(OptionalUtil.getValue(airportCode))) {
				throw new BusinessException("Invalid " + value + OptionalUtil.getValue(airportCode));
			}
		}
	}

	private void validateCarrierDesignatorCode(CommonRatedSector commonRatedSector) {
		if (OptionalUtil.isPresent(commonRatedSector.getClientId())) {
			String carrierDesignatorCode = OptionalUtil.getValue(commonRatedSector.getClientId());
			if (!globalMasterFeignClient.isValidCarrierDesignatorCode(carrierDesignatorCode)) {
				throw new BusinessException("Invalid Client Id " + carrierDesignatorCode);
			}
		}
	}

	protected void validateEffectiveToDate(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}

	private void validateOverLapForCreate(CommonRatedSector commonRatedSector) {
		if (commonRatedDao.validateOverLapForCreate(commonRatedSector.getClientId(), commonRatedSector.getFromAirport(),
				commonRatedSector.getToAirport(), commonRatedSector.getCommonRatedFromAirport(),
				commonRatedSector.getCommonRatedToAirport(), commonRatedSector.getEffectiveFromDate(),
				commonRatedSector.getEffectiveToDate()) != 0) {
			throw new BusinessException("Record already exists");
		}
	}

	private void validateOverLapForUpdate(CommonRatedSector commonRatedSector,
			CommonRatedSectorEntity commonRatedSectorEntity) {

		String clientId = getClientId(commonRatedSector, commonRatedSectorEntity);
		String fromAirport = getFromAirport(commonRatedSector, commonRatedSectorEntity);
		String toAirport = getToAirport(commonRatedSector, commonRatedSectorEntity);
		String commonRatedFromAirport = getCommonRatedFromAirport(commonRatedSector, commonRatedSectorEntity);
		String commonRatedToAirport = getCommonRatedToAirport(commonRatedSector, commonRatedSectorEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(commonRatedSector, commonRatedSectorEntity);
		LocalDate effectiveToDate = getEffectiveToDate(commonRatedSector, commonRatedSectorEntity);

		if (commonRatedDao.validateOverLapForUpdate(clientId, fromAirport, toAirport, commonRatedFromAirport,
				commonRatedToAirport, effectiveFromDate, effectiveToDate,
				commonRatedSectorEntity.getCommonRatedID()) != 0) {
			throw new BusinessException("Record already exists");

		}
	}

	private void validateFromAndToAirport(String fromAirport, String toAirport) {
		if (fromAirport.equalsIgnoreCase(toAirport)) {
			throw new BusinessException(FROM_AIRPORT + fromAirport + AND + TO_AIRPORT + toAirport + SHOULD_NOT_SAME);
		}
	}

	private void validateCommonRatedFromAndToAirport(String commonRatedFromAirport, String commonRatedToAirport) {
		if (commonRatedFromAirport.equalsIgnoreCase(commonRatedToAirport)) {
			throw new BusinessException(COMMON_RATED_FROM_AIRPORT + commonRatedFromAirport + AND
					+ COMMON_RATED_TO_AIRPORT + commonRatedToAirport + SHOULD_NOT_SAME);
		}
	}

	private void validateFromAirportAndCommonRatedToRated(String commonRatedToAirport, String fromAirport) {
		if (commonRatedToAirport.equalsIgnoreCase(fromAirport)) {

			throw new BusinessException(COMMON_RATED_TO_AIRPORT + commonRatedToAirport + AND + " From Airport "
					+ fromAirport + SHOULD_NOT_SAME);

		}
	}

	private void validateToAirportAndCommonRatedFromRated(String commonRatedFromAirport, String toAirport) {
		if (commonRatedFromAirport.equalsIgnoreCase(toAirport)) {
			throw new BusinessException(COMMON_RATED_FROM_AIRPORT + commonRatedFromAirport + AND + " To Airport "
					+ toAirport + SHOULD_NOT_SAME);
		}
	}

	private void validateFromAndToAirportAndCommonRatedAirport(CommonRatedSector commonRatedSector) {
		String fromAirport = OptionalUtil.getValue(commonRatedSector.getFromAirport());
		String toAirport = OptionalUtil.getValue(commonRatedSector.getToAirport());
		String commonRatedFromAirport = OptionalUtil.getValue(commonRatedSector.getCommonRatedFromAirport());
		String commonRatedToAirport = OptionalUtil.getValue(commonRatedSector.getCommonRatedToAirport());

		if (fromAirport.equalsIgnoreCase(commonRatedFromAirport) && toAirport.equalsIgnoreCase(commonRatedToAirport)) {
			throw new BusinessException(
					"From Airport + To Airport and Common Rated From Airport + Common Rated To Airport"
							+ SHOULD_NOT_SAME);
		}
	}

	private void validateFromAndToAirportAndCommonRatedForUpdate(CommonRatedSector commonRatedSector,
			CommonRatedSectorEntity commonRatedSectorEntity) {
		String fromAirport = getFromAirport(commonRatedSector, commonRatedSectorEntity);
		String toAirport = getToAirport(commonRatedSector, commonRatedSectorEntity);
		String commonRatedFromAirport = getCommonRatedFromAirport(commonRatedSector, commonRatedSectorEntity);
		String commonRatedToAirport = getCommonRatedToAirport(commonRatedSector, commonRatedSectorEntity);

		if (fromAirport.equalsIgnoreCase(commonRatedFromAirport) && toAirport.equalsIgnoreCase(commonRatedToAirport)) {
			throw new BusinessException(
					"From Airport + To Airport and Common Rated From Airport + Common Rated To Airport"
							+ SHOULD_NOT_SAME);
		}
	}
}
