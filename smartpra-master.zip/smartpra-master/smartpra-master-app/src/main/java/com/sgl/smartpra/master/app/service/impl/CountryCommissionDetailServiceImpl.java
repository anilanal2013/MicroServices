package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.CountryCommissionDetailDao;
import com.sgl.smartpra.master.app.dao.entity.CountryCommissionDetailEntity;
import com.sgl.smartpra.master.app.mapper.CountryCommissionDetailMapper;
import com.sgl.smartpra.master.app.service.CountryCommissionDetailService;
import com.sgl.smartpra.master.model.CountryCommissionDetail;
import com.sgl.smartpra.master.model.SystemParameter;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class CountryCommissionDetailServiceImpl implements CountryCommissionDetailService {	
	

	private static final String ACTIVE_COUNTRYCOMMISSIONDETAIL = "Country Commission Detail is already active";
	private static final String DEACTIVE_COUNTRYCOMMISSIONDETAIL = "Country Commission Detail is already inactive";
	private static final String COUNTRYCOMMISSIONDETAILIDINACTIVE = "Country Commission Detail is not active state";
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String CABINCLASS_LOV_COLUMN_VALUE = LOVEnum.CABIN.getLOVEnum();
	public static final String NET_GROSS_FLAG_LOV_COLUMN_VALUE = LOVEnum.NETGROSSFLAG.getLOVEnum();
	protected static final String OVERLAP_COMBINATION_EXIST = "Record already exists";	
	public static final String DEFAULT_CABIN_CLASS = "N";
	public static final String SYSTEM_PARTAMETER_NAME = "DEFAULT_COMMISSION_PERCENTAGE";

	@Autowired
	private CountryCommissionDetailDao countryCommissionDetailDao;

	@Autowired
	private CountryCommissionDetailMapper countryCommissionDetailMapper;
	
	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;
	
	@Autowired
	private ListOfValuesServiceImpl listOfValuesServiceImpl;
	
	@Autowired
	private SystemParameterServiceImpl systemParameterServiceImpl;

	@Override
	public CountryCommissionDetail create(CountryCommissionDetail countryCommissionDetail) {
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(countryCommissionDetail.getEffectiveToDate()), OptionalUtil.getLocalDateValue(countryCommissionDetail.getEffectiveFromDate()));
 		if(!OptionalUtil.isPresent(countryCommissionDetail.getCabinClass()))
 			countryCommissionDetail.setCabinClass(Optional.of(DEFAULT_CABIN_CLASS));
		
		validateOverlap(countryCommissionDetail);
		validateBusinessContraints(countryCommissionDetail);		
		countryCommissionDetail.setActivate(Boolean.TRUE);
		countryCommissionDetail.setCreatedDate(LocalDateTime.now());
		return countryCommissionDetailMapper.mapToModel(countryCommissionDetailDao.create(countryCommissionDetailMapper.mapToEntity(countryCommissionDetail)));
	}

	@Override
	public CountryCommissionDetail update(CountryCommissionDetail countryCommissionDetail) {
		CountryCommissionDetailEntity countryCommissionDetailEntity = 
				countryCommissionDetailDao.findById(countryCommissionDetail.getCountryCommissionDetailId()).
				orElseThrow(() -> new RecordNotFoundException(String.valueOf(countryCommissionDetail.getCountryCommissionDetailId())));
				
		if(!countryCommissionDetailEntity.getActivate()) {
			throw new BusinessException(COUNTRYCOMMISSIONDETAILIDINACTIVE);
		}
		
		validateDatesForUpdate(countryCommissionDetail,countryCommissionDetailEntity);
		validateOverlap(countryCommissionDetail, countryCommissionDetailEntity);
		validateBusinessContraints(countryCommissionDetail);		
		countryCommissionDetail.setLastUpdatedDate(LocalDateTime.now());
		
		return countryCommissionDetailMapper.mapToModel(countryCommissionDetailDao.
				update(countryCommissionDetailMapper.mapToEntity(countryCommissionDetail,countryCommissionDetailEntity)));
		
	}	

	@Override
	public List<CountryCommissionDetail> findAll(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> countryCode, Optional<String> cabinClass) {
		return countryCommissionDetailMapper.mapToModel(countryCommissionDetailDao.
				searchCountryCommissionDetail(effectiveFromDate, effectiveToDate, countryCode, cabinClass));		
	}

	@Override
	public void activate(Integer countryCommissionDetailId) {
		CountryCommissionDetailEntity countryCommissionDetailEntity = countryCommissionDetailDao.findById(countryCommissionDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(countryCommissionDetailId)));
		
		if (countryCommissionDetailEntity.getActivate()) {
			throw new BusinessException(ACTIVE_COUNTRYCOMMISSIONDETAIL);
		}

		countryCommissionDetailEntity.setActivate(Boolean.TRUE);
		countryCommissionDetailDao.update(countryCommissionDetailEntity);
		
	}

	@Override
	public void deactivate(Integer countryCommissionDetailId) {
		
		CountryCommissionDetailEntity countryCommissionDetailEntity = countryCommissionDetailDao.findById(countryCommissionDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(countryCommissionDetailId)));
		
		if (!countryCommissionDetailEntity.getActivate()) {
			throw new BusinessException(DEACTIVE_COUNTRYCOMMISSIONDETAIL);
		}

		countryCommissionDetailEntity.setActivate(Boolean.FALSE);
		countryCommissionDetailDao.update(countryCommissionDetailEntity);
	}	

	@Override
	public CountryCommissionDetail getCountryCommissionDetailById(Integer countryCommissionDetailId) {
		return countryCommissionDetailMapper.mapToModel(countryCommissionDetailDao.findById(countryCommissionDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(countryCommissionDetailId))));
	}
	
	private void validateBusinessContraints(CountryCommissionDetail countryCommissionDetail) {		
		validateCountryCode(countryCommissionDetail);	
		validateCabinClass(countryCommissionDetail);
		validateCommissionPercentageAndNetGrossFlag(countryCommissionDetail);
		validateNetGrossFlag(countryCommissionDetail);
	}

	private void validateNetGrossFlag(CountryCommissionDetail countryCommissionDetail) {
		if (OptionalUtil.isPresent(countryCommissionDetail.getNetGrossFlag())) {
			List<String> listOfValues = listOfValuesServiceImpl.getListOfValues(
					countryCommissionDetail.getClientId(),
					Optional.of(TABLENAME), Optional.of(NET_GROSS_FLAG_LOV_COLUMN_VALUE));
			String netGrossFlag = OptionalUtil.getValue(countryCommissionDetail.getNetGrossFlag());
			if (!(listOfValues.contains(OptionalUtil.getValue(countryCommissionDetail.getNetGrossFlag())))) {
				throw new BusinessException("Net Gross Flag[" + netGrossFlag + "] is Not Valid");
			}
		}
	}

	private void validateCommissionPercentageAndNetGrossFlag(CountryCommissionDetail countryCommissionDetail) {
		if (OptionalUtil.isPresent(countryCommissionDetail.getCabinClass())) {
			if (OptionalUtil.getValue(countryCommissionDetail.getCabinClass()).equals(DEFAULT_CABIN_CLASS)) {
				if (OptionalUtil.isPresent(countryCommissionDetail.getCommissionPercentage())) {
					throw new BusinessException("Commission percentage cannot be defined for Default Cabin Class");
				}
 				
 				String commissionPercentage = null;
 				SystemParameter systemParameter = systemParameterServiceImpl.findSystemParameterByParameterNameAndClientId(
 						SYSTEM_PARTAMETER_NAME,OptionalUtil.getValue(countryCommissionDetail.getClientId()));
				
 				if (StringUtils.isNotBlank(OptionalUtil.getValue(systemParameter.getParameterRangeFrom()))) {
 					commissionPercentage = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
 				}
 						
				if(!StringUtils.isEmpty(commissionPercentage)) {
					countryCommissionDetail.setCommissionPercentage(Optional.of(commissionPercentage));
					}
				else {
					throw new BusinessException("Default Commission not configured for provided client Id");
				}
				
			} else {
				if (!OptionalUtil.isPresent(countryCommissionDetail.getCommissionPercentage())) {
					throw new BusinessException("Commission Percentage is required");
				}
			}
		}
	}

	private void validateCountryCode(CountryCommissionDetail countryCommissionDetail) {
		if (OptionalUtil.isPresent(countryCommissionDetail.getCountryCode())) {
			String countryCode = OptionalUtil.getValue(countryCommissionDetail.getCountryCode());
			if (!globalMasterFeignClient.validateCountryCode(countryCode)) {
				throw new BusinessException("Country Code [" + countryCode + "] is not valid");
			}
		}

	}

	private void validateCabinClass(CountryCommissionDetail countryCommissionDetail) {
		if (OptionalUtil.isPresent(countryCommissionDetail.getCabinClass())) {
			List<String> listOfValues = listOfValuesServiceImpl.getListOfValues(countryCommissionDetail.getClientId(),
					Optional.of(TABLENAME), Optional.of(CABINCLASS_LOV_COLUMN_VALUE));
			String cabinClass = OptionalUtil.getValue(countryCommissionDetail.getCabinClass());
			if (!listOfValues.contains(OptionalUtil.getValue(countryCommissionDetail.getCabinClass())) && !OptionalUtil.getValue(countryCommissionDetail.getCabinClass()).equals(DEFAULT_CABIN_CLASS)) {
				throw new BusinessException("Cabin class[" + cabinClass + "] is Not Valid");
			}
		}		
	}
	
	protected void validateEffectiveToDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {

		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To Date[" + effectiveToDate
					+ "] should be greater than Effective From Date[" + effectiveFromDate + "]");
		}
	}	
	
	private void validateDatesForUpdate(CountryCommissionDetail countryCommissionDetail, CountryCommissionDetailEntity countryCommissionDetailEntity) {
		validateEffectiveToDate(getEffectiveToDate(countryCommissionDetail, countryCommissionDetailEntity), getEffectiveFromDate(countryCommissionDetail, countryCommissionDetailEntity));
	}
	
	private void validateOverlap(CountryCommissionDetail countryCommissionDetail) {
		if (countryCommissionDetailDao.getOverLapCount(
				OptionalUtil.getLocalDateValue(countryCommissionDetail.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(countryCommissionDetail.getEffectiveToDate()),
				OptionalUtil.getValue(countryCommissionDetail.getCountryCode()),
				OptionalUtil.getValue(countryCommissionDetail.getCabinClass()),
				OptionalUtil.getValue(countryCommissionDetail.getClientId()),
				OptionalUtil.getValue(countryCommissionDetail.getNetGrossFlag())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}
	
	private void validateOverlap(CountryCommissionDetail countryCommissionDetail, CountryCommissionDetailEntity countryCommissionDetailEntity) {

		// During Update input for "effectiveFromDate" can be null if the element is not
		// sent in json. if that is the case take the value from the db(entity) to
		// validate overlap
		LocalDate effectiveFromDate = getEffectiveFromDate(countryCommissionDetail, countryCommissionDetailEntity);

		// During Update input for "effectiveToDate" can be null if the element is not
		// sent in json. if that is the case take the value from the db(entity) to
		// validate overlap
		LocalDate effectiveToDate = getEffectiveToDate(countryCommissionDetail, countryCommissionDetailEntity);

		// During Update input for "clientId" can be null if the element is not sent in
		// json. if that is the case take the value from the db(entity) to validate
		// overlap
		String cabinClass = getCabinClass(countryCommissionDetail, countryCommissionDetailEntity);
		
		String countryCode = getCountryCode(countryCommissionDetail, countryCommissionDetailEntity);
		String clientId = getClientId(countryCommissionDetail, countryCommissionDetailEntity);
		String netGrossFlag = getNetGrossFlag(countryCommissionDetail, countryCommissionDetailEntity);

		List<CountryCommissionDetailEntity> sameRecord = countryCommissionDetailDao.verifyIfSameRecordExits
				(effectiveFromDate, effectiveToDate, countryCode, cabinClass,clientId,netGrossFlag);

		if (!sameRecord.isEmpty() && sameRecord.size() == 1 && sameRecord.get(0).getCountryCommissionDetailId().equals(countryCommissionDetail.getCountryCommissionDetailId())) {

			validateBusinessContraints(countryCommissionDetail);

		} else {

			long count = countryCommissionDetailDao.getOverLapCount(effectiveFromDate, effectiveToDate, countryCode, cabinClass,clientId,netGrossFlag);

			if (count > 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}

		}
	}
	
	private LocalDate getEffectiveFromDate(CountryCommissionDetail countryCommissionDetail, CountryCommissionDetailEntity countryCommissionDetailEntity) {
		return OptionalUtil.isPresent(countryCommissionDetail.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(countryCommissionDetail.getEffectiveFromDate())
				: countryCommissionDetailEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(CountryCommissionDetail countryCommissionDetail, CountryCommissionDetailEntity countryCommissionDetailEntity) {
		return OptionalUtil.isPresent(countryCommissionDetail.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(countryCommissionDetail.getEffectiveToDate())
				: countryCommissionDetailEntity.getEffectiveToDate();
	}
	
	private String getCabinClass(CountryCommissionDetail countryCommissionDetail, CountryCommissionDetailEntity countryCommissionDetailEntity) {
		return OptionalUtil.isPresent(countryCommissionDetail.getCabinClass()) ? OptionalUtil.getValue(countryCommissionDetail.getCabinClass())
				: countryCommissionDetailEntity.getCabinClass();
	}
	
	private String getCountryCode(CountryCommissionDetail countryCommissionDetail, CountryCommissionDetailEntity countryCommissionDetailEntity) {
		return OptionalUtil.isPresent(countryCommissionDetail.getCountryCode()) ? OptionalUtil.getValue(countryCommissionDetail.getCountryCode())
				: countryCommissionDetailEntity.getCountryCode();
	}
	
	private String getClientId(CountryCommissionDetail countryCommissionDetail, CountryCommissionDetailEntity countryCommissionDetailEntity) {
		return OptionalUtil.isPresent(countryCommissionDetail.getClientId()) ? OptionalUtil.getValue(countryCommissionDetail.getClientId())
				: countryCommissionDetailEntity.getClientId();
	}
	
	private String getNetGrossFlag(CountryCommissionDetail countryCommissionDetail, CountryCommissionDetailEntity countryCommissionDetailEntity) {
		return OptionalUtil.isPresent(countryCommissionDetail.getNetGrossFlag()) ? OptionalUtil.getValue(countryCommissionDetail.getNetGrossFlag())
				: countryCommissionDetailEntity.getNetGrossFlag();
	}

	@Override
	public List<CountryCommissionDetail> getCountryCommissionDetailByCountryCode(String issueDate,
			String countryCode) {
		return countryCommissionDetailMapper.mapToModel(
				countryCommissionDetailDao.searchCountryCommissionDetailByCountryCode(issueDate, countryCode));
	}
}
