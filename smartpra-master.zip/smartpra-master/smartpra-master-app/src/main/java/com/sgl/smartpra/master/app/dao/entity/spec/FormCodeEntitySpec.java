package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.repository.entity.FormCodeEntity;

public class FormCodeEntitySpec {

	public static void orderByAsc(Root<FormCodeEntity> formCodeEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(formCodeEntity.get(orderByString)));
	}

	public static Specification<FormCodeEntity> search(Optional<String> clientId, Optional<String> formCode, Optional<String> documentType,
			Optional<String> numberOfCoupon, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate,Optional<String> exceptionCall) {
		return (formCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(formCodeEntity.get("clientId"),
						OptionalUtil.getValue(clientId) ));
			}
			
			if (OptionalUtil.isPresent(formCode)) {
				predicates.add(
						criteriaBuilder.like(formCodeEntity.get("formCode"), OptionalUtil.getValue(formCode) + "%"));
			}
			if (OptionalUtil.isPresent(documentType)) {
				predicates.add(criteriaBuilder.like(formCodeEntity.get("documentType"),
						OptionalUtil.getValue(documentType) + "%"));
			}
			if (OptionalUtil.isPresent(numberOfCoupon)) {
				predicates.add(criteriaBuilder.like(formCodeEntity.get("numberOfCoupon"),
						OptionalUtil.getValue(numberOfCoupon) + "%"));
			}

			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)
					&& OptionalUtil.getValue(effectiveFromDate) != null
					&& OptionalUtil.getValue(effectiveToDate) != null
					&& !OptionalUtil.getValue(effectiveFromDate).isEmpty()
					&& !OptionalUtil.getValue(effectiveToDate).isEmpty()) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.getValue(effectiveFromDate) != null
						&& !OptionalUtil.getValue(effectiveFromDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate) && OptionalUtil.getValue(effectiveToDate) != null
						&& !OptionalUtil.getValue(effectiveToDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate")));
				}
			}
			if(!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (OptionalUtil.isPresent(activate)) {
					predicates.add(criteriaBuilder.equal(formCodeEntity.get("activate"), OptionalUtil.getValue(activate)));
				}
				if (!OptionalUtil.isPresent(activate)) {
					predicates.add(criteriaBuilder.equal(formCodeEntity.get("activate"), true));
				}
			}
			orderByAsc(formCodeEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<FormCodeEntity> formCodeSearch(Optional<String> formCode, 
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate) {
		return (formCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(formCode)) {
				predicates.add(
						criteriaBuilder.like(formCodeEntity.get("formCode"), OptionalUtil.getValue(formCode)));
			}
			
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)
					&& OptionalUtil.getValue(effectiveFromDate) != null
					&& OptionalUtil.getValue(effectiveToDate) != null
					&& !OptionalUtil.getValue(effectiveFromDate).isEmpty()
					&& !OptionalUtil.getValue(effectiveToDate).isEmpty()) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.getValue(effectiveFromDate) != null
						&& !OptionalUtil.getValue(effectiveFromDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate) && OptionalUtil.getValue(effectiveToDate) != null
						&& !OptionalUtil.getValue(effectiveToDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate")));
				}
			}

			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(formCodeEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(formCodeEntity.get("activate"), true));
			}
			orderByAsc(formCodeEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FormCodeEntity> equalsClientId(String clientId) {
		return (formCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(formCodeEntity.get("clientId"),
				clientId);
	}

	public static Specification<FormCodeEntity> equalsFormCode(String formCode) {
		return (formCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(formCodeEntity.get("formCode"),
				formCode);
	}

	public static Specification<FormCodeEntity> equalsDocumentType(String documentType) {
		return (formCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(formCodeEntity.get("documentType"), documentType);
	}

	public static Specification<FormCodeEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (formCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), formCodeEntity.get("effectiveFromDate"),
				formCodeEntity.get("effectiveToDate"));
	}

	public static Specification<FormCodeEntity> notEqualsFormCodeId(Integer formCodeId) {
		return (formCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(formCodeEntity.get("formCodeId"), formCodeId);
	}

	public static Specification<FormCodeEntity> findAll(FormCodeEntity mapToEntity,Optional<String> exceptionCall) {
		return (formCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (isEmptyOrNull(mapToEntity.getFormCode())) {
				predicates.add(criteriaBuilder.like(formCodeEntity.get("formCode"), mapToEntity.getFormCode() + "%"));
			}
			if (isEmptyOrNull(mapToEntity.getDocumentType())) {
				predicates.add(
						criteriaBuilder.like(formCodeEntity.get("documentType"), mapToEntity.getDocumentType() + "%"));
			}
			if (isEmptyOrNull(mapToEntity.getNumberOfCoupon())) {
				predicates.add(criteriaBuilder.like(formCodeEntity.get("numberOfCoupon"),
						mapToEntity.getNumberOfCoupon() + "%"));
			}

			if (mapToEntity.getEffectiveFromDate() != null && mapToEntity.getEffectiveToDate() != null) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveFromDate()),
								formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate")),
						criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveToDate()),
								formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate"))));
			} else {
				if (mapToEntity.getEffectiveFromDate() != null) {
					predicates.add(criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveFromDate()),
							formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate")));
				}
				if (mapToEntity.getEffectiveToDate() != null) {
					predicates.add(criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveToDate()),
							formCodeEntity.get("effectiveFromDate"), formCodeEntity.get("effectiveToDate")));
				}
			}
			if(!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (mapToEntity.getActivate() != null) {
					predicates.add(criteriaBuilder.equal(formCodeEntity.get("activate"), mapToEntity.getActivate()));
				}
				if (mapToEntity.getActivate() == null) {
					predicates.add(criteriaBuilder.equal(formCodeEntity.get("activate"), true));
				}
			}
			orderByAsc(formCodeEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private static boolean isEmptyOrNull(String value) {
		return value != null && !value.isEmpty();
	}
	
	public static Specification<FormCodeEntity> isActive() {
		return (formCodeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(formCodeEntity.get("activate"), true);
	}
}
