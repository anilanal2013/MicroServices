package com.sgl.smartpra.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.master.app.dao.AccountingDefinitionDao;
import com.sgl.smartpra.master.app.dao.entity.AccountingDefinitionEntity;
import com.sgl.smartpra.master.app.mapper.AccountingDefinitionMapper;
import com.sgl.smartpra.master.app.service.AccountService;
import com.sgl.smartpra.master.app.service.AccountingDefinitionService;
import com.sgl.smartpra.master.model.AccountDefIdentifierResponse;
import com.sgl.smartpra.master.model.AccountDefIdentifierWrapper;
import com.sgl.smartpra.master.model.AccountingDefinition;

@Service
@Transactional
public class AccountingDefinitionServiceImpl implements AccountingDefinitionService {

	@Autowired
	private AccountingDefinitionMapper accountingDefinitionMapper;

	@Autowired
	private AccountingDefinitionDao accountingDefinitionDao;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private AccountService accountService;

	List<AccountDefIdentifierWrapper> errorDataList = new ArrayList<>();

	AccountDefIdentifierResponse accountDefIdentifierResponse = null;

	public static final String ACCOUNT_ALREADY_INACTIVE = "Given Account Definition record is already deactive state";
	private static final String ACCOUNT_ALREADY_ACTIVE = "Given Account Definition record is already active state";

	private List<String> attributesList = null;
 
	@Override
	public List<AccountingDefinition> getAllAccountingDefinition(Optional<String> componentIdentifier,
			Optional<String> conversionDateUse) {
		
		return accountingDefinitionMapper
				.mapToModel(accountingDefinitionDao.search(componentIdentifier, conversionDateUse));
	}
	
	@Override
	public List<AccountingDefinition> getAllAccountingDefinitionWithIsActiveParam(Optional<String> componentIdentifier,
			Optional<String> conversionDateUse, Optional<Boolean> activate) {

		return accountingDefinitionMapper
				.mapToModel(accountingDefinitionDao.searchWithIsActiveParam(componentIdentifier, conversionDateUse, activate));
	}

	@Override
	public AccountingDefinition getAccountingDefinitionByIdentifier(Integer accountDefinitionIdentifier) {

		return accountingDefinitionMapper.mapToModel(accountingDefinitionDao.findById(accountDefinitionIdentifier)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountDefinitionIdentifier))));
	}

	@Override
	public AccountingDefinition createAccountingDefinition(AccountingDefinition accountingDefinition) {

		validateOverLapForCreate(accountingDefinition);

		validateCarrierDesignatorCode(accountingDefinition);

		validateAccountCodeAlpha(accountingDefinition);

		validateAttributesForCreate(accountingDefinition);

		accountingDefinition.setActivate(Boolean.TRUE);
		return accountingDefinitionMapper.mapToModel(
				accountingDefinitionDao.create(accountingDefinitionMapper.mapToEntity(accountingDefinition)));
	}

	@Override
	public AccountingDefinition updateAccountingDefinition(Integer accountDefinitionIdentifier,
			AccountingDefinition accountingDefinition) {

		AccountingDefinitionEntity accountingDefinitionEntity = accountingDefinitionDao
				.findById(accountDefinitionIdentifier)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountDefinitionIdentifier)));

		validateOverLapForUpdate(accountingDefinition, accountingDefinitionEntity);

		validateCarrierDesignatorCode(accountingDefinition);

		validateAccountCodeAlpha(accountingDefinition);

		validateAttributesForUpdate(accountingDefinition, accountingDefinitionEntity);

		accountingDefinition.setActivate(Boolean.TRUE);
		return accountingDefinitionMapper.mapToModel(accountingDefinitionDao
				.update(accountingDefinitionMapper.mapToEntity(accountingDefinition, accountingDefinitionEntity)));
	}

	@Override
	public void deactivateAccountingDefinition(@Valid Integer accountDefinitionIdentifier, String lastUpdatedBy) {

		AccountingDefinitionEntity accountingDefinitionEntity = accountingDefinitionDao
				.findById(accountDefinitionIdentifier)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountDefinitionIdentifier)));

		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (!accountingDefinitionEntity.getActivate()) {
			throw new BusinessException(ACCOUNT_ALREADY_INACTIVE);
		}

		accountingDefinitionEntity.setActivate(Boolean.FALSE);
		accountingDefinitionEntity.setLastUpdatedBy(lastUpdatedBy);
		accountingDefinitionEntity.setLastUpdatedDate(LocalDateTime.now());
		accountingDefinitionDao.update(accountingDefinitionEntity);

	}

	@Override
	public void activateAccountingDefinition(@Valid Integer accountDefinitionIdentifier, String lastUpdatedBy) {
		AccountingDefinitionEntity accountingDefinitionEntity = accountingDefinitionDao
				.findById(accountDefinitionIdentifier)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(accountDefinitionIdentifier)));

		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (accountingDefinitionEntity.getActivate()) {
			throw new BusinessException(ACCOUNT_ALREADY_ACTIVE);
		}

		accountingDefinitionEntity.setActivate(Boolean.TRUE);
		accountingDefinitionEntity.setLastUpdatedBy(lastUpdatedBy);
		accountingDefinitionEntity.setLastUpdatedDate(LocalDateTime.now());
		accountingDefinitionDao.update(accountingDefinitionEntity);
	}

	protected void validateCarrierDesignatorCode(AccountingDefinition accountingDefinition) {
		if (OptionalUtil.isPresent(accountingDefinition.getClientId())) {
			String carrierDesignatorCode = OptionalUtil.getValue(accountingDefinition.getClientId());
			if (!globalMasterFeignClient.isValidCarrierDesignatorCode(carrierDesignatorCode)) {
				throw new BusinessException("Invalid Client Id " + carrierDesignatorCode);
			}
		}
	}

	private void validateAccountCodeAlpha(AccountingDefinition accountingDefinition) {

		if (OptionalUtil.isPresent(accountingDefinition.getAccountCodeAlpha())) {
			if (!accountService.findByAccountAlphaCode(accountingDefinition.getAccountCodeAlpha())) {
				throw new BusinessException("Invalid Account Alpha Code "
						+ OptionalUtil.getValue(accountingDefinition.getAccountCodeAlpha()));
			}
		}
	}

	private void validateAttributesForCreate(AccountingDefinition accountingDefinition) {
		attributesList = new ArrayList<>();
		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster1(),
				accountingDefinition.getAccountingAttributes1());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster2(),
				accountingDefinition.getAccountingAttributes2());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster3(),
				accountingDefinition.getAccountingAttributes3());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster4(),
				accountingDefinition.getAccountingAttributes4());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster5(),
				accountingDefinition.getAccountingAttributes5());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster6(),
				accountingDefinition.getAccountingAttributes6());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster7(),
				accountingDefinition.getAccountingAttributes7());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster8(),
				accountingDefinition.getAccountingAttributes8());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster9(),
				accountingDefinition.getAccountingAttributes9());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster10(),
				accountingDefinition.getAccountingAttributes10());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster11(),
				accountingDefinition.getAccountingAttributes11());

		validateAttributeMaster(accountingDefinition.getAccountingAttributesMaster12(),
				(accountingDefinition.getAccountingAttributes12()));

		validateAttributeMaster((accountingDefinition.getAccountingAttributesMaster13()),
				(accountingDefinition.getAccountingAttributes13()));

		validateAttributeMaster((accountingDefinition.getAccountingAttributesMaster14()),
				(accountingDefinition.getAccountingAttributes14()));

		validateAttributeMaster((accountingDefinition.getAccountingAttributesMaster15()),
				(accountingDefinition.getAccountingAttributes15()));

		validateAttributeMaster((accountingDefinition.getAccountingAttributesMaster16()),
				(accountingDefinition.getAccountingAttributes16()));

		validateAttributeMaster((accountingDefinition.getAccountingAttributesMaster17()),
				(accountingDefinition.getAccountingAttributes17()));

		validateAttributeMaster((accountingDefinition.getAccountingAttributesMaster18()),
				(accountingDefinition.getAccountingAttributes18()));

		validateAttributeMaster((accountingDefinition.getAccountingAttributesMaster19()),
				(accountingDefinition.getAccountingAttributes19()));

		validateAttributeMaster((accountingDefinition.getAccountingAttributesMaster20()),
				(accountingDefinition.getAccountingAttributes20()));

	}

	private void validateAttributesForUpdate(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		attributesList = new ArrayList<>();

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster1(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes1(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster2(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes2(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster3(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes3(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster4(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes4(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster5(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes5(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster6(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes6(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster7(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes7(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster8(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes8(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster9(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes9(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster10(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes10(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster11(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes11(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster12(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes12(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster13(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes13(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster14(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes14(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster15(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes15(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster16(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes16(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster17(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes17(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster18(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes18(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster19(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes19(accountingDefinition, accountingDefinitionEntity));

		validateAttributeMasterForUpdate(
				getAccountingAttributesMaster20(accountingDefinition, accountingDefinitionEntity),
				getAccountingAttributes20(accountingDefinition, accountingDefinitionEntity));

	}

	private String getAccountingAttributes1(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes1())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes1())
				: accountingDefinitionEntity.getAccountingAttributes1();
	}

	private String getAccountingAttributesMaster1(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster1())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster1())
				: accountingDefinitionEntity.getAccountingAttributesMaster1();
	}

	private String getAccountingAttributes2(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes2())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes2())
				: accountingDefinitionEntity.getAccountingAttributes2();
	}

	private String getAccountingAttributesMaster2(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster2())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster2())
				: accountingDefinitionEntity.getAccountingAttributesMaster2();
	}

	private String getAccountingAttributes3(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes3())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes3())
				: accountingDefinitionEntity.getAccountingAttributes3();
	}

	private String getAccountingAttributesMaster3(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster3())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster3())
				: accountingDefinitionEntity.getAccountingAttributesMaster3();
	}

	private String getAccountingAttributes4(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes4())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes4())
				: accountingDefinitionEntity.getAccountingAttributes4();
	}

	private String getAccountingAttributesMaster4(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster4())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster4())
				: accountingDefinitionEntity.getAccountingAttributesMaster4();
	}

	private String getAccountingAttributes5(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes5())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes5())
				: accountingDefinitionEntity.getAccountingAttributes5();
	}

	private String getAccountingAttributesMaster5(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster5())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster5())
				: accountingDefinitionEntity.getAccountingAttributesMaster5();
	}

	private String getAccountingAttributes6(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes6())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes6())
				: accountingDefinitionEntity.getAccountingAttributes6();
	}

	private String getAccountingAttributesMaster6(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster6())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster6())
				: accountingDefinitionEntity.getAccountingAttributesMaster6();
	}

	private String getAccountingAttributes7(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes7())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes7())
				: accountingDefinitionEntity.getAccountingAttributes7();
	}

	private String getAccountingAttributesMaster7(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster7())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster7())
				: accountingDefinitionEntity.getAccountingAttributesMaster7();
	}

	private String getAccountingAttributes8(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes8())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes8())
				: accountingDefinitionEntity.getAccountingAttributes8();
	}

	private String getAccountingAttributesMaster8(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster8())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster8())
				: accountingDefinitionEntity.getAccountingAttributesMaster8();
	}

	private String getAccountingAttributes9(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes9())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes9())
				: accountingDefinitionEntity.getAccountingAttributes9();
	}

	private String getAccountingAttributesMaster9(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster9())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster9())
				: accountingDefinitionEntity.getAccountingAttributesMaster9();
	}

	private String getAccountingAttributes10(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes10())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes10())
				: accountingDefinitionEntity.getAccountingAttributes10();
	}

	private String getAccountingAttributesMaster10(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster10())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster10())
				: accountingDefinitionEntity.getAccountingAttributesMaster10();
	}

	private String getAccountingAttributes11(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes11())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes11())
				: accountingDefinitionEntity.getAccountingAttributes11();
	}

	private String getAccountingAttributesMaster11(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster11())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster11())
				: accountingDefinitionEntity.getAccountingAttributesMaster11();
	}

	private String getAccountingAttributes12(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes12())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes12())
				: accountingDefinitionEntity.getAccountingAttributes12();
	}

	private String getAccountingAttributesMaster12(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster12())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster12())
				: accountingDefinitionEntity.getAccountingAttributesMaster12();
	}

	private String getAccountingAttributes13(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes13())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes13())
				: accountingDefinitionEntity.getAccountingAttributes13();
	}

	private String getAccountingAttributesMaster13(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster13())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster13())
				: accountingDefinitionEntity.getAccountingAttributesMaster13();
	}

	private String getAccountingAttributes14(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes14())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes14())
				: accountingDefinitionEntity.getAccountingAttributes14();
	}

	private String getAccountingAttributesMaster14(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster14())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster14())
				: accountingDefinitionEntity.getAccountingAttributesMaster14();
	}

	private String getAccountingAttributes15(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes15())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes15())
				: accountingDefinitionEntity.getAccountingAttributes15();
	}

	private String getAccountingAttributesMaster15(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster15())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster15())
				: accountingDefinitionEntity.getAccountingAttributesMaster15();
	}

	private String getAccountingAttributes16(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes16())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes16())
				: accountingDefinitionEntity.getAccountingAttributes16();
	}

	private String getAccountingAttributesMaster16(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster16())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster16())
				: accountingDefinitionEntity.getAccountingAttributesMaster16();
	}

	private String getAccountingAttributes17(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes17())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes17())
				: accountingDefinitionEntity.getAccountingAttributes17();
	}

	private String getAccountingAttributesMaster17(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster17())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster17())
				: accountingDefinitionEntity.getAccountingAttributesMaster17();
	}

	private String getAccountingAttributes18(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes18())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes18())
				: accountingDefinitionEntity.getAccountingAttributes18();
	}

	private String getAccountingAttributesMaster18(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster18())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster18())
				: accountingDefinitionEntity.getAccountingAttributesMaster18();
	}

	private String getAccountingAttributes19(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes19())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes19())
				: accountingDefinitionEntity.getAccountingAttributes19();
	}

	private String getAccountingAttributesMaster19(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster19())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster19())
				: accountingDefinitionEntity.getAccountingAttributesMaster19();
	}

	private String getAccountingAttributes20(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributes20())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributes20())
				: accountingDefinitionEntity.getAccountingAttributes20();
	}

	private String getAccountingAttributesMaster20(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		return OptionalUtil.isPresent(accountingDefinition.getAccountingAttributesMaster20())
				? OptionalUtil.getValue(accountingDefinition.getAccountingAttributesMaster20())
				: accountingDefinitionEntity.getAccountingAttributesMaster20();
	}

	private void validateAttributeMaster(Optional<String> accountingAttributesMaster,
			Optional<String> accountingAttributes) {

		if (OptionalUtil.isPresent(accountingAttributesMaster) && OptionalUtil.isPresent(accountingAttributes)) {
			if (attributesList.stream().anyMatch(attributes -> attributes.contentEquals(
					OptionalUtil.getValue(accountingAttributesMaster) + OptionalUtil.getValue(accountingAttributes)))) {
				throw new BusinessException("Duplicate accountingAttributesMaster " + (accountingAttributesMaster)
						+ " and accountingAttributes " + (accountingAttributes));
			}
			attributesList.add(
					OptionalUtil.getValue(accountingAttributesMaster) + OptionalUtil.getValue(accountingAttributes));
		}
	}

	private void validateAttributeMasterForUpdate(String accountingAttributesMaster, String accountingAttributes) {

		if (accountingAttributesMaster != null && accountingAttributes != null) {
			if (attributesList.stream().anyMatch(
					attributes -> attributes.contentEquals((accountingAttributesMaster) + (accountingAttributes)))) {
				throw new BusinessException("Duplicate accountingAttributesMaster " + (accountingAttributesMaster)
						+ " and accountingAttributes " + (accountingAttributes));
			}
			attributesList.add((accountingAttributesMaster) + (accountingAttributes));
		}
	}

	private void validateOverLapForCreate(AccountingDefinition accountingDefinition) {
		if (accountingDefinitionDao.getOverLapRecordCount(
				OptionalUtil.getValue(accountingDefinition.getAccountCodeAlpha()),
				OptionalUtil.getValue(accountingDefinition.getComponentIdentifier()),
				OptionalUtil.getValue(accountingDefinition.getClientId()),
				OptionalUtil.getValue(accountingDefinition.getConversionDateUse())) != 0) {
			throw new BusinessException("Record already exists");
		}
	}

	private void validateOverLapForUpdate(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {

		if (accountingDefinitionDao.getOverLapRecordCount(
				getAccountCodeAlpha(accountingDefinition, accountingDefinitionEntity),
				getComponentIdentifier(accountingDefinition, accountingDefinitionEntity),
				getClientId(accountingDefinition, accountingDefinitionEntity),
				getConversionDateUse(accountingDefinition, accountingDefinitionEntity),
				accountingDefinitionEntity.getAccountDefinitionIdentifier()) != 0) {
			throw new BusinessException("Record already exists");
		}
	}

	private String getConversionDateUse(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getConversionDateUse())
				? OptionalUtil.getValue(accountingDefinition.getConversionDateUse())
				: accountingDefinitionEntity.getConversionDateUse();
	}

	private String getClientId(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getClientId())
				? OptionalUtil.getValue(accountingDefinition.getClientId())
				: accountingDefinitionEntity.getClientId();
	}

	private String getComponentIdentifier(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getComponentIdentifier())
				? OptionalUtil.getValue(accountingDefinition.getComponentIdentifier())
				: accountingDefinitionEntity.getComponentIdentifier();
	}

	private String getAccountCodeAlpha(AccountingDefinition accountingDefinition,
			AccountingDefinitionEntity accountingDefinitionEntity) {
		return OptionalUtil.isPresent(accountingDefinition.getAccountCodeAlpha())
				? OptionalUtil.getValue(accountingDefinition.getAccountCodeAlpha())
				: accountingDefinitionEntity.getAccountCodeAlpha();
	}

	@Override
	public AccountDefIdentifierResponse getListOfAccountingDefByAccountAphaCodeAndAccountDef(
			AccountingDefinition accountDefinition) {

		accountDefinition.getTranAccDefMappingList().stream().distinct().forEach(accountDefIdentifierWrapper -> {
			accountDefIdentifierResponse = new AccountDefIdentifierResponse();
			AccountingDefinitionEntity dataEntity = accountingDefinitionDao
					.getListOfAccountingDefByAccountAphaCodeAndAccountDef(
							accountDefIdentifierWrapper.getAccountDefinitionIdentifier(),
							accountDefIdentifierWrapper.getAccountCodeAlpha());
			if (dataEntity == null) {
				errorDataList.add(
						new AccountDefIdentifierWrapper(accountDefIdentifierWrapper.getAccountDefinitionIdentifier(),
								accountDefIdentifierWrapper.getAccountCodeAlpha()));
				accountDefIdentifierResponse.setErrorData(errorDataList);
			}
		});
		return accountDefIdentifierResponse;
	}
	
	   @Override
	   public List<String> getAccountAttrMasterTabs() {
		
		return accountingDefinitionDao.getAccountAttrMasterTabs();
	   }
	   
	   @Override
	   public List<String> getAccountAttrColumns() {
		 
		return accountingDefinitionDao.getAccountAttrColumns();
	  }
	
}
