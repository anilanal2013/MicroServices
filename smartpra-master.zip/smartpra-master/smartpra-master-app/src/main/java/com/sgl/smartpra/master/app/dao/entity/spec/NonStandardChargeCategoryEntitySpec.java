package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCategoryEntity;

public class NonStandardChargeCategoryEntitySpec {
	
	private static final String ISACTIVE = "isActive";
	private static final String CLIENTID = "clientId";      
	private static final String NON_STD_CHARGE_CATEGORY = "nonStdCategoryCode";
	private static final String STD_CHARGE_CATEGORY = "stdCategoryCode";
	private static final String DISPLAYORDER = "nonStdCategoryCode";
	
	private NonStandardChargeCategoryEntitySpec() {}
	

	public static Specification<NonStandardChargeCategoryEntity> isActive() {
		return (nonStandardChargeCategoryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(nonStandardChargeCategoryEntity.get(ISACTIVE), true);
	}

	public static Specification<NonStandardChargeCategoryEntity> equalsClientId(String clientId) {
		return (nonStandardChargeCategoryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(nonStandardChargeCategoryEntity.get(CLIENTID), clientId);
	}

	public static Specification<NonStandardChargeCategoryEntity> searchNonStandardChargeCategory(String clientId, 
			Optional<String> nonStdChargeCategoryCode, Optional<String> stdChargeCategoryCode,  Optional<String> isActive) {
		return (nonStandardChargeCategoryEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
		
				predicates.add(criteriaBuilder.equal(nonStandardChargeCategoryEntity.get(CLIENTID), clientId));
			
				if(nonStdChargeCategoryCode.isPresent()) {
					predicates.add(criteriaBuilder.equal(nonStandardChargeCategoryEntity.get(NON_STD_CHARGE_CATEGORY), OptionalUtil.getValue(nonStdChargeCategoryCode)));
				}
				if(stdChargeCategoryCode.isPresent()) {
					predicates.add(criteriaBuilder.equal(nonStandardChargeCategoryEntity.get(STD_CHARGE_CATEGORY), OptionalUtil.getValue(stdChargeCategoryCode)));
				}
				if(isActive.isPresent()) {
					if("ALL".equalsIgnoreCase(isActive.get())) {
						predicates.add(criteriaBuilder.or(
								criteriaBuilder.equal(nonStandardChargeCategoryEntity.get(ISACTIVE), "Y"),
								criteriaBuilder.equal(nonStandardChargeCategoryEntity.get(ISACTIVE), "N")));
					} else {
						predicates.add(criteriaBuilder.equal(nonStandardChargeCategoryEntity.get(ISACTIVE), OptionalUtil.getValue(isActive)));
					}
				}
				orderByAsc(nonStandardChargeCategoryEntity, criteriaQuery, criteriaBuilder, DISPLAYORDER);
				
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static void orderByAsc(Root<NonStandardChargeCategoryEntity> nonStdChargeCategoryEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String displayOrder) {
		criteriaQuery.orderBy(criteriaBuilder.asc(nonStdChargeCategoryEntity.get(displayOrder)));
	}
}
