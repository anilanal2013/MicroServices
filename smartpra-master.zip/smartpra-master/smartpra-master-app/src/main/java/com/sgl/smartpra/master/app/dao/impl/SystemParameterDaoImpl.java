package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.SystemParameterDao;
import com.sgl.smartpra.master.app.dao.entity.SystemParameterEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.SystemParameterEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.SystemParameterRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SystemParameterDaoImpl implements SystemParameterDao {

	@Autowired
	private SystemParameterRepository systemParameterRepository;
	
	@Override
	@Cacheable(value = "systemParameter", key = "#id")
	public Optional<SystemParameterEntity> findById(Integer id) {
		log.info("Cacheable SystemParameter Entity's ID = {}", id);
		return systemParameterRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "systemParameter", key = "#systemParameterEntity.parameterId"),
			@CacheEvict(value = "parameterName", allEntries = true),@CacheEvict(value = "clientId", allEntries = true)})
	public SystemParameterEntity create(SystemParameterEntity systemParameterEntity) {
		return systemParameterRepository.save(systemParameterEntity);
	}

	@Override
	@CachePut(value = "systemParameter", key = "#systemParameterEntity.parameterId")
	@Caching(evict = { @CacheEvict(value = "parameterName", allEntries = true),@CacheEvict(value = "clientId", allEntries = true)})
	public SystemParameterEntity update(SystemParameterEntity systemParameterEntity) {
		return systemParameterRepository.save(systemParameterEntity);
	}

	@Override
	public List<SystemParameterEntity> findAll(Optional<String> clientId, Optional<String> groupName, Optional<String> moduleName,
			Optional<String> parameterName, Optional<String> parameterFormat, String parameterId, Optional<Boolean> isVisible, Optional<Boolean> isActive) {
		return systemParameterRepository.findAll(SystemParameterEntitySpecification.searchAll(clientId,groupName,moduleName,parameterName,parameterFormat,parameterId,isVisible,isActive));
	}

	@Override
	public Optional<SystemParameterEntity> findOne(Optional<String> clientId, Optional<String> groupName,
			Optional<String> moduleName, Optional<String> parameterName, Optional<String> parameterFormat,
			String parameterId) {
		return systemParameterRepository.findOne(SystemParameterEntitySpecification.search(clientId,groupName,moduleName,parameterName,parameterFormat,parameterId));
	}
	
	@Override
	public List<SystemParameterEntity> findDistinctModuleNameGroupNameByModuleName(String clientId) {
		return systemParameterRepository.findAll(Specification.where(SystemParameterEntitySpecification.equalsClientId(clientId)
				.and(SystemParameterEntitySpecification.isActive())));
	}

	@Override
	@Cacheable(cacheNames={"parameterName"})
	public List<SystemParameterEntity> findByParameterNameAndEffectiveToDateGreaterThanEqual(String parameterName) {
		return systemParameterRepository.findAll(Specification.where(SystemParameterEntitySpecification.equalsParameterName(parameterName)
				.and(SystemParameterEntitySpecification.equalsEffectiveToDateGreaterThanEqual())
				.and(SystemParameterEntitySpecification.isActive())));
	}

	@Override
	@Cacheable(cacheNames={"parameterName","clientId"})
	public SystemParameterEntity findByParameterNameAndClientIdAndEffectiveToDateGreaterThanEqual(String parameterName,
			String clientId) {
		return systemParameterRepository.findOne(
				Specification.where(SystemParameterEntitySpecification.equalsParameterName(parameterName)
				.and(SystemParameterEntitySpecification.equalsClientId(clientId))
				.and(SystemParameterEntitySpecification.equalsEffectiveToDateGreaterThanEqual())
				.and(SystemParameterEntitySpecification.isActive()))).orElse(new SystemParameterEntity());
		
	}

	@Override
	@Cacheable(cacheNames={"parameterName","clientId"})
	public List<SystemParameterEntity> findParameterListByAndParameterNameAndClientAndEffectiveToDateGreaterThanEqual(
			String clientId, String parameterName) {
		return systemParameterRepository.findAll(Specification.where(SystemParameterEntitySpecification.equalsParameterName(parameterName)
				.and(SystemParameterEntitySpecification.equalsClientId(clientId))
				.and(SystemParameterEntitySpecification.equalsEffectiveToDateGreaterThanEqual())
				.and(SystemParameterEntitySpecification.isActive())));
	}
	
	@Override
	@Cacheable(cacheNames={"parameterName","clientId"})
	public List<SystemParameterEntity> findParameterNameListAndClientIdAndEffectiveToDateGreaterThanEqual(String clientId,
			List<String> parameterName) {
		return systemParameterRepository.findAll(Specification.where(SystemParameterEntitySpecification.equalsListParameterName(parameterName)
				.and(SystemParameterEntitySpecification.equalsClientId(clientId))
				.and(SystemParameterEntitySpecification.equalsEffectiveToDateGreaterThanEqual())
				.and(SystemParameterEntitySpecification.isActive())));
	}
	
}
