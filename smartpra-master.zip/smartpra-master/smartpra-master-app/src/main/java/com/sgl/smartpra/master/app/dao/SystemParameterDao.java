package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.SystemParameterEntity;

@Repository
public interface SystemParameterDao{

	public Optional<SystemParameterEntity> findById(Integer id);
	
	public SystemParameterEntity create(SystemParameterEntity systemParameterEntity);
	
	public SystemParameterEntity update(SystemParameterEntity systemParameterEntity);
	
	public List<SystemParameterEntity> findAll(Optional<String> clientId, Optional<String> groupName, Optional<String> moduleName, Optional<String> parameterName, Optional<String> parameterFormat,
			String parameterId, Optional<Boolean> isVisible, Optional<Boolean> isActive);
	
	public Optional<SystemParameterEntity> findOne(Optional<String> clientId, Optional<String> groupName, Optional<String> moduleName, Optional<String> parameterName, Optional<String> parameterFormat,
			String parameterId);
	
	public List<SystemParameterEntity> findDistinctModuleNameGroupNameByModuleName(String clientId);
	
	public List<SystemParameterEntity> findByParameterNameAndEffectiveToDateGreaterThanEqual(String parameterName);
	
	public SystemParameterEntity findByParameterNameAndClientIdAndEffectiveToDateGreaterThanEqual(String parameterName,String clientId);

	public List<SystemParameterEntity> findParameterListByAndParameterNameAndClientAndEffectiveToDateGreaterThanEqual(
			String clientId, String parameterName);
	
	public List<SystemParameterEntity> findParameterNameListAndClientIdAndEffectiveToDateGreaterThanEqual(String clientId, List<String> parameterName);
}
