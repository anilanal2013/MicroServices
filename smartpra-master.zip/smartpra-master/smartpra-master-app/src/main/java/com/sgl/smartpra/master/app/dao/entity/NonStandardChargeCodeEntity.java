package com.sgl.smartpra.master.app.dao.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_non_standard_charge_code")
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicUpdate
@DynamicInsert
public class NonStandardChargeCodeEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "non_std_charge_code_id")
	private Integer nonStdChargeCodeId;
	
	@Column(name = "client_id")
	private String clientId;

	@Column(name = "non_std_charge_code_name")
	private String nonStdChargeCodeName;

	@Column(name = "non_std_charge_code")
	private String nonStdChargeCode;
	
	@Column(name = "non_std_category_code")
	private String nonStdCategoryCode;

	@Column(name = "std_charge_code")
	private String stdChargeCode;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "cost_center_code")
	private String costCenterCode;

	@Column(name = "is_active")
	private String isActive;
}
