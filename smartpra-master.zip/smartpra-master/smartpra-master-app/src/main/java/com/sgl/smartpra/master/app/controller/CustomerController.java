package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.CustomerService;
import com.sgl.smartpra.master.model.Customer;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@GetMapping("/customers")
	public List<Customer> getAllCustomer(
			@RequestParam(value = "customerId", required = false) Optional<String> customerCode,
			@RequestParam(value = "customerType", required = false) Optional<String> customerType,
			@RequestParam(value = "customerName", required = false) Optional<String> customerName,
			@RequestParam(value = "billingFrequency", required = false) Optional<String> billingFrequency,
			@RequestParam(value = "financialDocType", required = false) Optional<String> financialDocType,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {

		Customer customer = new Customer();
		// customer.setClientId(clientId);
		customer.setCustomerCode(customerCode);
		customer.setCustomerType(customerType);
		customer.setCustomerName(customerName);
		customer.setBillingFrequency(billingFrequency);
		customer.setFinancialDocType(financialDocType);
		customer.setActivate(OptionalUtil.getValue(activate));

		return customerService.getListOfCustomer(customer, Optional.of(""));
	}

	@GetMapping("/customers/search/clientid/{clientId}")
	public List<Customer> getAllCustomer(@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "customerId", required = false) Optional<String> customerCode,
			@RequestParam(value = "customerType", required = false) Optional<String> customerType,
			@RequestParam(value = "customerName", required = false) Optional<String> customerName,
			@RequestParam(value = "billingFrequency", required = false) Optional<String> billingFrequency,
			@RequestParam(value = "financialDocType", required = false) Optional<String> financialDocType,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {

		Customer customer = new Customer();
		customer.setClientId(clientId);
		customer.setCustomerCode(customerCode);
		customer.setCustomerType(customerType);
		customer.setCustomerName(customerName);
		customer.setBillingFrequency(billingFrequency);
		customer.setFinancialDocType(financialDocType);
		customer.setActivate(OptionalUtil.getValue(activate));

		return customerService.getListOfCustomer(customer, exceptionCall);
	}

	@GetMapping("customers/{customerMasId}")
	public Customer getCustomerByCustomerId(@PathVariable(value = "customerMasId") Integer customerMasId) {
		return customerService.getCustomerByCustomerMasId(customerMasId);

	}

	@PostMapping("/customers")
	@ResponseStatus(value = HttpStatus.CREATED)
	public Customer createCustomer(@Validated(Create.class) @RequestBody Customer customer) {
		return customerService.createCustomer(customer);

	}

	@PutMapping("customer/{customerMasId}")
	@ResponseStatus(value = HttpStatus.OK)
	public Customer updateCustomer(@PathVariable(value = "customerMasId") Integer customerMasId,
			@Validated(Update.class) @RequestBody Customer customer) {
		customer.setCustomerMasId(customerMasId);
		return customerService.updateCustomer(customer);

	}

	@PutMapping("customer/{customerMasId}/deactivate")
	public void deactivateCustomer(@Valid @PathVariable(value = "customerMasId") Integer customerMasId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		customerService.deactivateCustomer(customerMasId, lastUpdatedBy);
	}

	@PutMapping("customer/{customerMasId}/activate")
	public void activateCustomer(@Valid @PathVariable(value = "customerMasId") Integer customerMasId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		customerService.activateCustomer(customerMasId, lastUpdatedBy);

	}

}
