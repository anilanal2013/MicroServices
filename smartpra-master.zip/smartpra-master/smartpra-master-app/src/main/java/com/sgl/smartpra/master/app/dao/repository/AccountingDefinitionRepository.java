package com.sgl.smartpra.master.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import com.sgl.smartpra.master.app.dao.entity.AccountingDefinitionEntity;

@Repository
public interface AccountingDefinitionRepository extends JpaRepository<AccountingDefinitionEntity, Integer>,
		JpaSpecificationExecutor<AccountingDefinitionEntity> {

	AccountingDefinitionEntity findByAccountDefinitionIdentifierAndAccountCodeAlpha(int accountDefinitionIdentifier,
			String accountCodeAlpha);

	@Query(value = "SELECT isc.TABLE_NAME FROM INFORMATION_SCHEMA.COLUMNS isc", nativeQuery = true)
	public List<String> getAccountAttrMasterTabs();

	@Query(value = "SELECT isc.COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS isc", nativeQuery = true)
	public List<String> getAccountAttrColumns();

	@Query(value = "select distinct(accountDefinitionIdentifier) from AccountingDefinitionEntity ")
	List<Integer> getAccountDefinitionIdentifierFromAccountDefinitionMaster();

	@Query(value = "select distinct(accountCodeAlpha) from AccountingDefinitionEntity ")
	List<String> getAccountAlphaCodeFromAccountDefinitionMaster();

}
