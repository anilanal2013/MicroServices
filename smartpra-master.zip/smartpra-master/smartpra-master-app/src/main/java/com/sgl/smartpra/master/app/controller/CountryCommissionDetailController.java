package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.CountryCommissionDetailService;
import com.sgl.smartpra.master.model.CountryCommissionDetail;

@RestController
public class CountryCommissionDetailController {
	
	@Autowired
	private CountryCommissionDetailService countryCommissionDetailService;
	
	@PostMapping("/country-commission-detail")
	public CountryCommissionDetail createCountryCommissionDetail(@Validated(value = Create.class)
			@RequestBody CountryCommissionDetail countryCommissionDetail) {
				return countryCommissionDetailService.create(countryCommissionDetail);		
	}
	
	@PutMapping("/country-commission-detail/{countryCommissionDetailId}")
	public CountryCommissionDetail updateCountryCommissionDetail(@PathVariable(value = "countryCommissionDetailId") Integer countryCommissionDetailId, @Validated(value = Update.class)
			@RequestBody CountryCommissionDetail countryCommissionDetail) {
		countryCommissionDetail.setCountryCommissionDetailId(countryCommissionDetailId);
		return countryCommissionDetailService.update(countryCommissionDetail);
	}
	
	@GetMapping("/country-commission-detail/{countryCommissionDetailId}")
	public CountryCommissionDetail getCountryCommissionDetailById(@PathVariable(value = "countryCommissionDetailId") 
			Integer countryCommissionDetailId) {
		return countryCommissionDetailService.getCountryCommissionDetailById(countryCommissionDetailId);
	}
	
	@GetMapping("/country-commission-detail")
	public List<CountryCommissionDetail> getCountryCommissionDetail(@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "MM-DD-YYYY")
	Optional<String> effectiveFromDate, @RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "MM-DD-YYYY")
	Optional<String> effectiveToDate, @RequestParam(value = "countryCode", required = false)
	Optional<String> countryCode, @RequestParam(value = "cabinClass", required = false) Optional<String> cabinClass) {
		return countryCommissionDetailService.findAll(effectiveFromDate, effectiveToDate, countryCode, cabinClass);
	}
	
	@PutMapping("/country-commission-detail/{countryCommissionDetailId}/activate")
	public void activateCountryCommissionDetail(@PathVariable(value = "countryCommissionDetailId") Integer countryCommissionDetailId) {
		countryCommissionDetailService.activate(countryCommissionDetailId);
	}
	
	@PutMapping("/country-commission-detail/{countryCommissionDetailId}/deactivate")
	public void deactivateCountryCommissionDetail(@PathVariable(value = "countryCommissionDetailId") Integer countryCommissionDetailId) {
		countryCommissionDetailService.deactivate(countryCommissionDetailId);
	}
	
	@GetMapping("/country-commission-detail/{issueDate}/{countryCode}")
	public List<CountryCommissionDetail> getCountryCommissionDetailByCountryCode(
			@PathVariable(value = "issueDate") @DateFormat(pattern = "yyyy-MM-dd") String issueDate,
			@PathVariable(value = "countryCode") String countryCode) {
		return countryCommissionDetailService.getCountryCommissionDetailByCountryCode(issueDate, countryCode);
	}
	
}
