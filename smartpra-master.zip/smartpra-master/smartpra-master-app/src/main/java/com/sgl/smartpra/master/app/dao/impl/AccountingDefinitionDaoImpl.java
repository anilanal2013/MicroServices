package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.AccountingDefinitionDao;
import com.sgl.smartpra.master.app.dao.entity.AccountingDefinitionEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.AccountingDefinitionEntitySpecification;
import com.sgl.smartpra.master.app.dao.entity.spec.AccountingTransactionEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.AccountingDefinitionRepository;

@Component
public class AccountingDefinitionDaoImpl implements AccountingDefinitionDao {

	@Autowired
	private AccountingDefinitionRepository accountDefinitionRepository;

	@Override
	@Cacheable(value = "accountingDefinition", key = "#id")
	public Optional<AccountingDefinitionEntity> findById(Integer id) {
		return accountDefinitionRepository.findById(id);
	}

	@Override
	public List<AccountingDefinitionEntity> search(Optional<String> componentIdentifier,
			Optional<String> conversionDateUse) {

		return accountDefinitionRepository
				.findAll(AccountingDefinitionEntitySpecification.search(componentIdentifier, conversionDateUse)
						.and(AccountingDefinitionEntitySpecification.activate()));
	}

	@Override
	public List<AccountingDefinitionEntity> searchWithIsActiveParam(Optional<String> componentIdentifier,
			Optional<String> conversionDateUse, Optional<Boolean> activate) {
		return accountDefinitionRepository.findAll(AccountingDefinitionEntitySpecification
				.searchWithIsActiveParam(componentIdentifier, conversionDateUse, activate));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "accountingDefinition", key = "#mapToEntity.accountDefinitionIdentifier") })
	public AccountingDefinitionEntity create(AccountingDefinitionEntity mapToEntity) {
		return accountDefinitionRepository.save(mapToEntity);
	}

	@Override
	@CachePut(value = "accountingDefinition", key = "#mapToEntity.accountDefinitionIdentifier")
	public AccountingDefinitionEntity update(AccountingDefinitionEntity mapToEntity) {
		return accountDefinitionRepository.save(mapToEntity);
	}

	@Override
	public long verifyAttributeMaster(String accountingAttributesMaster, String accountingAttributes) {
		return accountDefinitionRepository.count(
				AccountingDefinitionEntitySpecification.equalsAccountingAttributesMaster(accountingAttributesMaster));
	}

	@Override
	public long getOverLapRecordCount(String accountCodeAlpha, String componentIdentifier, String clientId,
			String conversionDateUse) {
		return accountDefinitionRepository
				.count(Specification.where(AccountingDefinitionEntitySpecification.equalsClientId(clientId))
						.and(AccountingDefinitionEntitySpecification.equalsAccountCodeAlpha(accountCodeAlpha))
						.and(AccountingDefinitionEntitySpecification.equalsComponentIdentifier(componentIdentifier).and(
								AccountingDefinitionEntitySpecification.equalsConversionDateUse(conversionDateUse))));
	}

	@Override
	public long getOverLapRecordCount(String accountCodeAlpha, String componentIdentifier, String clientId,
			String conversionDateUse, Integer accountDefinitionIdentifier) {
		return accountDefinitionRepository
				.count(Specification.where(AccountingDefinitionEntitySpecification.equalsClientId(clientId))
						.and(AccountingDefinitionEntitySpecification.equalsAccountCodeAlpha(accountCodeAlpha))
						.and(AccountingDefinitionEntitySpecification.equalsComponentIdentifier(componentIdentifier))
						.and(AccountingDefinitionEntitySpecification.equalsConversionDateUse(conversionDateUse))
						.and(AccountingDefinitionEntitySpecification
								.notEqualsAccountDefinitionIdentifier(accountDefinitionIdentifier)));
	}

	@Override
	public AccountingDefinitionEntity getListOfAccountingDefByAccountAphaCodeAndAccountDef(
			Integer accountDefinitionIdentifier, String accountCodeAlpha) {
		return accountDefinitionRepository
				.findByAccountDefinitionIdentifierAndAccountCodeAlpha(accountDefinitionIdentifier, accountCodeAlpha);
	}
	
	@Override
	public List<String> getAccountAttrMasterTabs() {
		
		return accountDefinitionRepository.getAccountAttrMasterTabs();
	}
	@Override
	public List<String> getAccountAttrColumns() {
		
		return accountDefinitionRepository.getAccountAttrColumns();
	}
	@Override
	public List<Integer> getAccountDefinitionIdentifierFromAccountDefinitionMaster() {
		// TODO Auto-generated method stub
		return accountDefinitionRepository.getAccountDefinitionIdentifierFromAccountDefinitionMaster();
	}

	@Override
	public List<String> getAccountAlphaCodeFromAccountDefinitionMaster() {

		return accountDefinitionRepository.getAccountAlphaCodeFromAccountDefinitionMaster();
	}
}
