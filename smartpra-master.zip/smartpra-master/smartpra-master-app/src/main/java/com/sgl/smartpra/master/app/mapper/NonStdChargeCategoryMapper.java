package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCategoryEntity;
import com.sgl.smartpra.master.model.NonStandardChargeCategory;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface NonStdChargeCategoryMapper extends BaseMapper<NonStandardChargeCategory, NonStandardChargeCategoryEntity>{

	NonStandardChargeCategoryEntity mapToEntity(NonStandardChargeCategory nonStdChargeCategory,  @MappingTarget NonStandardChargeCategoryEntity nonStdChargeCategoryEntity);
	
	NonStandardChargeCategoryEntity mapToEntity(NonStandardChargeCategory nonStdChargeCategory);
	
}
