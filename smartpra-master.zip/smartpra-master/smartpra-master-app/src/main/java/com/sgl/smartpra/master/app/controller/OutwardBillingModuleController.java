package com.sgl.smartpra.master.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.repository.entity.OutwardBillingModuleEntity;
import com.sgl.smartpra.master.app.service.OutwardBillingModuleService;
import com.sgl.smartpra.master.model.OutwardBillingModule;

@RestController
public class OutwardBillingModuleController {

	@Autowired
	OutwardBillingModuleService outwardBillingModuleService;

	@PostMapping("/billing-module")
	public OutwardBillingModule createOutwardBillingModule(
			@Validated(Create.class) @RequestBody OutwardBillingModule outwardBillingModule) {
		return outwardBillingModuleService.createOutwardBillingModule(outwardBillingModule);
	}

	@PutMapping("/billing-module/{billingModuleId}")
	public OutwardBillingModule updateOutwardBillingModule(
			@PathVariable(value = "billingModuleId") Integer billingModuleId,
			@Validated(Update.class) @RequestBody OutwardBillingModule outwardBillingModule) {

		return outwardBillingModuleService.updateOutwardBillingModule(billingModuleId, outwardBillingModule);
	}

	@GetMapping("/billing-module/billing-month-period-module-name/{billingMonth}/{billingPeriod}/{moduleName}")
	public List<OutwardBillingModuleEntity> getOutwardBillingModuleUsingBillingMonthAndBillingPeriodAndModuleName(
			@PathVariable(value = "billingMonth", required = true) String billingMonth,
			@PathVariable(value = "billingPeriod", required = true) Integer billingPeriod,
			@PathVariable(value = "moduleName", required = true) String moduleName) {
		return outwardBillingModuleService.getOutwardBillingModuleUsingBillingMonthAndBillingPeriodAndModuleName(
				billingMonth, billingPeriod, moduleName);
	}

	@GetMapping("/billing-module/billing-month")
	public List<OutwardBillingModuleEntity> getOutwardBillingModuleUsingBillingMonth(
			@RequestParam(value = "billingMonth", required = true) String billingMonth,
			@RequestParam(value = "billingPeriod", required = false) Integer billingPeriod,
			@RequestParam(value = "moduleName", required = false) String moduleName) {
		return outwardBillingModuleService.getOutwardBillingModuleUsingBillingMonth(billingMonth, billingPeriod,
				moduleName);
	}

	@GetMapping("/billing-module/latest-closed/{moduleName}")
	public OutwardBillingModuleEntity getLatestClosedOutwardBillingModule(
			@PathVariable(value = "moduleName", required = true) String moduleName) {
		return outwardBillingModuleService.getLatestClosedOutwardBillingModule(moduleName);
	}

	@GetMapping("/billing-module/current-open/{moduleName}")
	public OutwardBillingModuleEntity getCurrentOpenOutwardBillingModule(
			@PathVariable(value = "moduleName", required = true) String moduleName) {
		return outwardBillingModuleService.getCurrentOpenOutwardBillingModule(moduleName);
	}
}
