package com.sgl.smartpra.master.app.mapper;

import java.util.List;

import com.sgl.smartpra.master.model.CommonRatedSector;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.repository.entity.CommonRatedSectorEntity;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CommonRatedSectorMapper extends BaseMapper<CommonRatedSector, CommonRatedSectorEntity> {

    CommonRatedSectorEntity mapToEntity(CommonRatedSector commonRatedSector,
                                        @MappingTarget CommonRatedSectorEntity commonRatedSectorEntity);

    @Mapping(source = "commonRatedID", target = "commonRatedID", ignore = true)
    CommonRatedSectorEntity mapToEntity(CommonRatedSector commonRatedSector);

    List<CommonRatedSector> mapToCommonRatedSectorsModellList(
            List<CommonRatedSectorEntity> commonRatedSectorEntityList);

}
