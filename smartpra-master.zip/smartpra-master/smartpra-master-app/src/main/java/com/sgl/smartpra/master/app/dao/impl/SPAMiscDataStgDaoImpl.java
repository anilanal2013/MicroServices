package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.SPAMiscDataStgDao;
import com.sgl.smartpra.master.app.dao.entity.SPAMiscDataStgEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.SPAMiscDataStgEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.SPAMiscDataStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SPAMiscDataStgDaoImpl implements SPAMiscDataStgDao {

	@Autowired
	private SPAMiscDataStgRepository spaMiscDataStgRepository;

	@Override
	@Cacheable(value = "spaMiscDataStg", key = "#spaMiscDataId")
	public Optional<SPAMiscDataStgEntity> findById(Integer spaMiscDataId) {
		log.info("Cacheable SPA Misc Data Entity's ID= {}", spaMiscDataId);
		return spaMiscDataStgRepository.findById(spaMiscDataId);
	}

	@Override
	public List<SPAMiscDataStgEntity> findBySpaKeyMainIdClientIdRecordType(Optional<Integer> spaKey,
			Optional<Integer> spaMainId, Optional<String> clientId) {

		return spaMiscDataStgRepository
				.findAll(SPAMiscDataStgEntitySpecification.findBySpaKeyMainIdClientIdRecordType(spaKey, spaMainId, clientId));
	}
	
	@Override
	public List<SPAMiscDataStgEntity> getSPAMiscDataBySpaKeyProcessing(Optional<String> clientId, Optional<Integer> spaKey,Optional<Integer> recordType) {

		return spaMiscDataStgRepository
				.findAll(SPAMiscDataStgEntitySpecification.findBySpaKeyMainIdClientIdAndSpaKey(clientId, spaKey,recordType));
	}


}
