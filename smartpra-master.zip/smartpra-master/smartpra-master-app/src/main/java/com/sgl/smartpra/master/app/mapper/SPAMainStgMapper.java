package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.SPAMainStgEntity;
import com.sgl.smartpra.master.model.SPAMainStg;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SPAMainStgMapper extends BaseMapper<SPAMainStg, SPAMainStgEntity> {
	SPAMainStgEntity mapToEntity(SPAMainStg spaMainStg, @MappingTarget SPAMainStgEntity spaMainStgEntity);
	@Mapping(source = "spaMainId", target = "spaMainId", ignore = true)
	SPAMainStgEntity mapToEntity(SPAMainStg spaMainStg);
}
