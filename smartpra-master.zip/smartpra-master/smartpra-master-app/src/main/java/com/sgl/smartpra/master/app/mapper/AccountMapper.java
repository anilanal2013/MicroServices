package com.sgl.smartpra.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.AccountEntity;
import com.sgl.smartpra.master.model.AccountModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AccountMapper extends BaseMapper<AccountModel, AccountEntity> {

	AccountEntity mapToEntity(AccountModel accountModel, @MappingTarget AccountEntity accountEntity);

	@Mapping(source = "accountAlphaCodeId", target = "accountAlphaCodeId", ignore = true)
	AccountEntity mapToEntity(AccountModel accountModel);

}
