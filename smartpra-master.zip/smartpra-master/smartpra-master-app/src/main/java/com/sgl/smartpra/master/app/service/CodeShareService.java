package com.sgl.smartpra.master.app.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.CodeShare;

public interface CodeShareService {
	
	public List<CodeShare> getAllCodeShare(Optional<String> clientId, Optional<String> marketingCXR,
			Optional<String> effectiveTravelFromDate,Optional<String> effectiveTravelToDate,Optional<String> effectiveSaleFromDate,Optional<String> effectiveSaleToDate, Optional<Boolean> isActive);

	public List<CodeShare> getCodeShareByEffectiveDate(Optional<String> clientId,Optional<String> marketingCXR, Optional<String> marketedRBDList,
			Optional<String> effectiveDate);
	
	public CodeShare getCodeShareByCodeShareId(Integer codeShareId);

	public CodeShare getCodeShareBymarketingCXR(String marketingCXR,Date travelEffectiveDate,Date saleEffectiveDate,String clientId,String flightNumber);

	public CodeShare createCodeShare(CodeShare codeShare);

	public CodeShare updateCodeShare(Integer codeShareId, CodeShare codeShare);

	public void deactivateCodeShare(Integer codeShareId, String lastUpdatedBy);

	public void activateCodeShare(Integer codeShareId, String lastUpdatedBy);

	public List<CodeShare> getCodeSharePopulateData(String marketingCXR, Date effectiveDateObject, Date saleDateObject,
			String clientId, String flightNumber);

	public CodeShare getCodeShareForValidation(String clientId, String operatingflightNumber, Date travelDate, String operatingCXR, String marketingflightNumber, Date saleDate, String marketingCXR);
	
	public CodeShare getCodeShareByClientAndMarketingCXRAndMarketedRBDAndEffectiveDateSales(String clientId,
			String marketingCXR, String marketedRBDList, String effectiveDate,
			String flightNumber);

}
