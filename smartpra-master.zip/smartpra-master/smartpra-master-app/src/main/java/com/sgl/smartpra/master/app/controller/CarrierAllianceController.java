package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.CarrierAllianceService;
import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.OneWorldCarrierAlliance;

@RestController
public class CarrierAllianceController {

	@Autowired
	@Qualifier("CarrierAllianceService")
	private CarrierAllianceService carrierAllianceService;
	
	@GetMapping("/carrier-alliance/search")
	public List<CarrierAlliance> search(
			@RequestParam(value = "carrierCode", required = false)  Optional<String> carrierCode,
			@RequestParam(value = "clientId", required = false)  Optional<String> clientId,
			@RequestParam(value = "allianceName", required = false)  Optional<String> allianceName,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {
		return carrierAllianceService.search(carrierCode, clientId, allianceName, effectiveFromDate, effectiveToDate);
	}

	@PostMapping("/carrier-alliance")
	@ResponseStatus(value = HttpStatus.CREATED)
	public CarrierAlliance createCarrierAlliance(
			@Validated(value = Create.class) @RequestBody CarrierAlliance carrierAlliance) {
		return carrierAllianceService.createCarrierAlliance(carrierAlliance);
	}

	@PostMapping("/carrier-alliance/oneworld")
	@ResponseStatus(value = HttpStatus.CREATED)
	public OneWorldCarrierAlliance createCarrierAlliance(
			@Validated(value = Create.class) @RequestBody OneWorldCarrierAlliance oneWorldCarrierAlliance) {
		return carrierAllianceService.createCarrierAlliance(oneWorldCarrierAlliance);
	}

	@PutMapping("/carrier-alliance/{carrierAllianceDtlId}")
	@ResponseStatus(value = HttpStatus.OK)
	public CarrierAlliance updateCarrierAlliance(
			@PathVariable(value = "carrierAllianceDtlId") Integer carrierAllianceDtlId,
			@Validated(value = Update.class) @RequestBody CarrierAlliance carrierAlliance) {
		carrierAlliance.setCarrierAllianceDtlId(carrierAllianceDtlId);
		return carrierAllianceService.updateCarrierAlliance(carrierAlliance);
	}

	@PutMapping("/carrier-alliance/oneworld/{carrierAllianceDtlId}")
	@ResponseStatus(value = HttpStatus.OK)
	public OneWorldCarrierAlliance updateCarrierAlliance(
			@PathVariable(value = "carrierAllianceDtlId") Integer carrierAllianceDtlId,
			@Validated(value = Update.class) @RequestBody OneWorldCarrierAlliance oneWorldCarrierAlliance) {
		oneWorldCarrierAlliance.setCarrierAllianceDtlId(carrierAllianceDtlId);
		return carrierAllianceService.updateCarrierAlliance(oneWorldCarrierAlliance);
	}

	@GetMapping("/carrier-alliance/{carrierAllianceDtlId}")
	public CarrierAlliance getCarrierAllianceByCarrierAllianceDtlId(
			@PathVariable(value = "carrierAllianceDtlId") Integer carrierAllianceDtlId) {
		return carrierAllianceService.getCarrierAllianceByCarrierAllianceDtlId(carrierAllianceDtlId);
	}

	@GetMapping("/carrier-alliance/searchByCarrierCode")
	public List<CarrierAlliance> search(
			@RequestParam(value = "carrierCode", required = true) @NotEmpty String carrierCode,
			@RequestParam(value = "effectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return carrierAllianceService.search(carrierCode, effectiveDate);
	}

	@GetMapping("/carrier-alliance/searchByAllianceName")
	public List<CarrierAlliance> search(@RequestParam(value = "clientId", required = true) @NotEmpty String clientId,
			@RequestParam(value = "allianceName", required = true) @NotEmpty String allianceName,
			@RequestParam(value = "effectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return carrierAllianceService.search(allianceName, effectiveDate, clientId);
	}

	@GetMapping("/carrier-alliances/{clientId}")
	public List<CarrierAlliance> findAll(@PathVariable("clientId") @NotEmpty String clientId) {
		return carrierAllianceService.findAll(clientId);
	}
	
	@GetMapping("/carrier-alliances/flight-date-search")
	public CarrierAlliance getAllianceByCarrierCodeAndEffectiveDate(@RequestParam("clientId") String clientId,
			@RequestParam(value = "carrierCode", required = true) String carrierCode,
			@RequestParam(value = "effectiveDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return carrierAllianceService.getAllianceByCarrierCodeAndEffectiveDate(clientId,carrierCode,effectiveDate);
	}

	@PutMapping("/carrier-alliance/{carrierAllianceDtlId}/deactivate")
	public void deactivateCarrierAlliance(
			@Valid @PathVariable(value = "carrierAllianceDtlId") Integer carrierAllianceDtlId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		CarrierAlliance carrierAlliance = new CarrierAlliance();
		carrierAlliance.setCarrierAllianceDtlId(carrierAllianceDtlId);
		carrierAlliance.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		carrierAllianceService.deactivateCarrierAlliance(carrierAlliance);
	}

	@PutMapping("/carrier-alliance/{carrierAllianceDtlId}/activate")
	public void activateCarrierAlliance(
			@Valid @PathVariable(value = "carrierAllianceDtlId") Integer carrierAllianceDtlId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		CarrierAlliance carrierAlliance = new CarrierAlliance();
		carrierAlliance.setCarrierAllianceDtlId(carrierAllianceDtlId);
		carrierAlliance.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		carrierAllianceService.activateCarrierAlliance(carrierAlliance);
	}

}
