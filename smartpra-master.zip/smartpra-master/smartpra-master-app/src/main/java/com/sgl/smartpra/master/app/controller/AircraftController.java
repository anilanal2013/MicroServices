package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.exception.ServiceException;
import com.sgl.smartpra.master.app.service.AircraftService;
import com.sgl.smartpra.master.model.Aircraft;

@RestController
public class AircraftController {

	@Autowired
	private AircraftService aircraftService;

	public static final String DATACONSTARINTVIOALATION = "Record already exists";

	@GetMapping("/aircrafts")
	public List<Aircraft> getAllAircraft(
			@RequestParam(value = "aircraftRegistration", required = false) Optional<String> aircraftRegistration,
			@RequestParam(value = "aircraftType", required = false) Optional<String> aircraftType,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		Aircraft aircraft = new Aircraft();

		aircraft.setAircraftRegistration(aircraftRegistration);
		aircraft.setAircraftType(aircraftType);
		aircraft.setActivate(OptionalUtil.getValue(activate));
		return aircraftService.getListOfAircraft(aircraft, Optional.of(""));
	}

	// for exception call service
	@GetMapping("/aircrafts/search/clientid/{clientId}")
	public List<Aircraft> getAllAircraft(@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "aircraftRegistration", required = false) Optional<String> aircraftRegistration,
			@RequestParam(value = "aircraftType", required = false) Optional<String> aircraftType,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {
		Aircraft aircraft = new Aircraft();
		aircraft.setClientId(clientId);
		aircraft.setAircraftRegistration(aircraftRegistration);
		aircraft.setAircraftType(aircraftType);
		aircraft.setActivate(OptionalUtil.getValue(activate));
		return aircraftService.getListOfAircraft(aircraft, exceptionCall);
	}

	@GetMapping("aircrafts/{aircraftId}")
	public Aircraft getAircraftByAircraftId(@PathVariable(value = "aircraftId") Integer aircraftId) {
		return aircraftService.getAircraftByAircraftId(aircraftId);

	}

	@PostMapping("/aircrafts")
	public Aircraft createAircraft(@Validated(Create.class) @RequestBody Aircraft aircraft) {
		return aircraftService.createAircraft(aircraft);

	}

	@PutMapping("aircraft/{aircraftId}")
	public Aircraft updateAircraft(@PathVariable(value = "aircraftId") Integer aircraftId,
			@Validated(Update.class) @RequestBody Aircraft aircraft) {
		Aircraft aircraftData = null;
		try {
			aircraftData = aircraftService.updateAircraft(aircraftId, aircraft);
		} catch (DataIntegrityViolationException e) {
			throw new ServiceException(DATACONSTARINTVIOALATION);
		}
		return aircraftData;
	}

	@PutMapping("aircraft/{aircraftId}/deactivate")
	public void deactivateAircraft(@Valid @PathVariable(value = "aircraftId") Integer aircraftId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		aircraftService.deactivateAircraft(aircraftId, lastUpdatedBy);
	}

	@PutMapping("aircraft/{aircraftId}/activate")
	public void activateAircraft(@Valid @PathVariable(value = "aircraftId") Integer aircraftId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		aircraftService.activateAircraft(aircraftId, lastUpdatedBy);
	}

	@GetMapping("/aircraft-details")
	public List<Aircraft> getAllAircraftDetails(
			@RequestParam(value = "firstClassCapacity", required = false) Integer firstClassCapacity,
			@RequestParam(value = "businessClassCapacity", required = false) Integer businessClassCapacity,
			@RequestParam(value = "premiumEconomyClassCapacity", required = false) Integer premiumEconomyClassCapacity,
			@RequestParam(value = "economyClassCapacity", required = false) Integer economyClassCapacity) {
		return aircraftService.getAllAircraftDetails(firstClassCapacity, businessClassCapacity,
				premiumEconomyClassCapacity, economyClassCapacity);
	}
}
