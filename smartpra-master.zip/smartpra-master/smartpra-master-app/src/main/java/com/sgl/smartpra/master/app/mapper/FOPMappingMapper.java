package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.FOPMappingEntity;
import com.sgl.smartpra.master.model.FOPMapping;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FOPMappingMapper extends BaseMapper<FOPMapping, FOPMappingEntity> {

	FOPMappingEntity mapToEntity(FOPMapping fopMapping, @MappingTarget FOPMappingEntity fopMappingEntity);

	@Mapping(source = "fopMapId", target = "fopMapId", ignore = true)
	FOPMappingEntity mapToEntity(FOPMapping fopMapping);
}
