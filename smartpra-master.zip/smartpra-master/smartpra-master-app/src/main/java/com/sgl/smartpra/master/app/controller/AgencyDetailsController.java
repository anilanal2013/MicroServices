package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.exception.ServiceException;
import com.sgl.smartpra.master.app.service.AgencyDetailsService;
import com.sgl.smartpra.master.model.AgencyDetailsModel;

@RestController
public class AgencyDetailsController {

	@Autowired
	private AgencyDetailsService agencyDetailsService;

	public static final String DATACONSTARINTVIOALATION = "Record already exists";

	@GetMapping("/agency-detail")
	public List<AgencyDetailsModel> getAgencyDetailsByEffectiveDate(
			@RequestParam(value = "agencyCode", required = false) Optional<String> agencyCode,
			@RequestParam(value = "clientId", required = false) Optional<String> clientId,
			@RequestParam(value = "transactionType", required = false) Optional<String> transactionType,
			@RequestParam(value = "reportingFrequency", required = false) Optional<String> reportingFrequency,
			@RequestParam(value = "transactionCurrency", required = false) Optional<String> transactionCurrency,
			@RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return agencyDetailsService.getAgencyDetailsByEffectiveDate(agencyCode, clientId, transactionType,
				reportingFrequency, transactionCurrency, effectiveFromDate, effectiveToDate, activate);
	}

	@GetMapping("/agency/{agencyId}/agency-details/clientId/{clientId}")
	public List<AgencyDetailsModel> getAllAgencyDetails(@PathVariable(value = "agencyId") Integer agencyId,
			@RequestParam(value = "agencyCode", required = false) Optional<String> agencyCode,
			@PathVariable(value = "clientId", required = true) Optional<String> clientId,
			@RequestParam(value = "transactionType", required = false) Optional<String> transactionType,
			@RequestParam(value = "reportingFrequency", required = false) Optional<String> reportingFrequency,
			@RequestParam(value = "transactionCurrency", required = false) Optional<String> transactionCurrency,
			@RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {
		return agencyDetailsService.getAgencyDetailsByEffectiveDate(agencyId, agencyCode, clientId, transactionType,
				reportingFrequency, transactionCurrency, effectiveFromDate, effectiveToDate, activate, exceptionCall);
	}

	@GetMapping(value = "/agency/{agencyId}/agency-details/{agencyDetailId}")
	public AgencyDetailsModel getAgencyDetailsByAgencyDetailsId(@PathVariable(value = "agencyId") Integer agencyId,
			@PathVariable(value = "agencyDetailId") int agencyDetailId) {
		return agencyDetailsService.getAgencyDetailsByAgencyDetailsId(agencyId, agencyDetailId);
	}

	@GetMapping(value = "/agency-detailsbycode/{clientId}/{agencyCode}/{effectiveDate}")
	public List<AgencyDetailsModel> getAgencyDetailsByAgencyCode(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@PathVariable(value = "agencyCode") Optional<String> agencyCode,
			@PathVariable(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return agencyDetailsService.getAgencyDetailsByAgencyCode(clientId, agencyCode, effectiveDate);
	}

	@PostMapping("/agency/{agencyId}/agency-details")
	public AgencyDetailsModel createAgencyDetails(@PathVariable(value = "agencyId") Integer agencyId,
			@Validated(Create.class) @RequestBody AgencyDetailsModel agencyDetailsModel) {
		return agencyDetailsService.createAgencyDetails(agencyId, agencyDetailsModel);
	}

	@PutMapping("/agency/{agencyId}/agency-details/{agencyDetailId}")
	public AgencyDetailsModel updateAgencyDetails(@PathVariable(value = "agencyId") Integer agencyId,
			@PathVariable(value = "agencyDetailId") Integer agencyDetailId,
			@Validated(Update.class) @RequestBody AgencyDetailsModel agencyDetailsModel) {
		AgencyDetailsModel agencyDetailsModel1 = null;

		try {
			agencyDetailsModel1 = agencyDetailsService.updateAgencyDetails(agencyId, agencyDetailId,
					agencyDetailsModel);
		} catch (DataIntegrityViolationException e) {
			throw new ServiceException(DATACONSTARINTVIOALATION);
		}
		return agencyDetailsModel1;
	}

	@PutMapping("/agency/{agencyId}/agency-details/{agencyDetailId}/deactivate")
	public void deactivateAgencyDetails(@PathVariable(value = "agencyId") Integer agencyId,
			@Valid @PathVariable(value = "agencyDetailId") int agencyDetailId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		agencyDetailsService.deactivateAgencyDetail(agencyId, agencyDetailId, lastUpdatedBy);
	}

	@PutMapping("/agency/{agencyId}/agency-details/{agencyDetailId}/activate")
	public void activateAgencyDetails(@PathVariable(value = "agencyId") Integer agencyId,
			@Valid @PathVariable(value = "agencyDetailId") int agencyDetailId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		agencyDetailsService.activateAgencyDetail(agencyId, agencyDetailId, lastUpdatedBy);
	}

}
