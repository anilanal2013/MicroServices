package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.UATPService;
import com.sgl.smartpra.master.model.UATPModel;

@RestController
public class UATPController {

	@Autowired
	private UATPService uatpservice;

	@PostMapping("/uatp")
	@ResponseStatus(value = HttpStatus.CREATED)
	public UATPModel createUATP(@Validated(Create.class) @RequestBody UATPModel uatpModel) {
		return uatpservice.createUATP(uatpModel);
	}

	@PutMapping("/uatp/{uatpId}")
	@ResponseStatus(value = HttpStatus.OK)
	public UATPModel updateUATP(@PathVariable(value = "uatpId") Integer uatpId,
			@Validated(Update.class) @RequestBody UATPModel uatpModel) {
		return uatpservice.updateUATP(uatpId, uatpModel);
	}

	@GetMapping("/uatp/search/clientid/{clientId}")
	public List<UATPModel> getAllUATP(@PathVariable(name = "clientId") Optional<String> clientId,
			@RequestParam(name = "uatpRecType") Optional<String> uatpRecType,
			@RequestParam(name = "issueCxr") Optional<String> issueCxr,
			@RequestParam(name = "operatingCxr") Optional<String> operatingCxr,
			@RequestParam(name = "effectiveFromDate") @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(name = "effectiveToDate") @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {
		return uatpservice.getListOfUATP(clientId, uatpRecType, issueCxr, operatingCxr, effectiveFromDate,
				effectiveToDate);
	}

	@GetMapping("/uatp/{uatpId}")
	public UATPModel getUATPByUATPId(@PathVariable(value = "uatpId") Integer uatpId) {
		return uatpservice.getUATPByUATPId(uatpId);
	}
}
