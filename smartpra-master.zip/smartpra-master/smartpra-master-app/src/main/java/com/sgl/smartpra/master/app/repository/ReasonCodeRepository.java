package com.sgl.smartpra.master.app.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.repository.entity.ReasonCodeEntity;

@Repository
public interface ReasonCodeRepository
		extends JpaRepository<ReasonCodeEntity, Integer>, JpaSpecificationExecutor<ReasonCodeEntity> {

	Optional<ReasonCodeEntity> findByReasonCode(String reasonCode);
	
	List<ReasonCodeEntity> findByClientIdAndReasonCode(String clientId, String reasonCode);
	
//	@Query(value = "select reasonCodeId from ReasonCodeEntity d where d.reasonCode=?1 and d.clientId=?2 and d.isActive = 1")
//	List<Integer> sameReasonCode(String reasonCode ,String clientId);
}
