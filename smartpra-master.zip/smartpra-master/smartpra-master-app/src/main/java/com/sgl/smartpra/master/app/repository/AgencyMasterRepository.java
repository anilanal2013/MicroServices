package com.sgl.smartpra.master.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.AgencyMasterEntity;

@Repository
public interface AgencyMasterRepository
		extends JpaRepository<AgencyMasterEntity, Integer>, JpaSpecificationExecutor<AgencyMasterEntity> {

	List<AgencyMasterEntity> findByClientIdAndReportingAgencyAndAgencyCode(String clientId, String reportingAgency,
			String agencyCode);

}