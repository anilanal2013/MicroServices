package com.sgl.smartpra.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "mas_country_commission_detail")
@EqualsAndHashCode(callSuper=false)
@DynamicUpdate
@DynamicInsert
public class CountryCommissionDetailEntity extends BaseEntity{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "commission_dtl_id")
	private Integer countryCommissionDetailId; 
	
	@Column(name = "client_id")
	private String clientId;
	
	@Column(name = "country_code")
	private String countryCode;
	
	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;
	
	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;
	
	@Column(name = "cabin_class")
	private String cabinClass;
	
	@Column(name = "commission_percentage")
	private BigDecimal commissionPercentage;
	
	@Column(name = "net_gross_flag")
	private String netGrossFlag;
	
	@Column(name = "is_active")	
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;
}
