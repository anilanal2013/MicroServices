package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_user_area")
@Data
@DynamicInsert
@DynamicUpdate
@EqualsAndHashCode(callSuper = false)
public class ClientUserAreaEntity extends BaseEntity {

	@Id
	@Column(name = "mas_user_area_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer userAreaId;

	@Column(name = "user_area_code", nullable = false, length = 3)
	private String userAreaCode;

	@Column(name = "area_key1", nullable = false, length = 1)
	private String areaKey1;

	@Column(name = "area_key2", nullable = false, length = 5)
	private String areaKey2;

	@Column(name = "area_key3", nullable = false, length = 5)
	private String areaKey3;

	@Column(name = "area_key4", nullable = false, length = 5)
	private String areaKey4;

	@Column(name = "user_area_name", nullable = false, length = 30)
	private String userAreaName;

	@Column(name = "area_include_list", length = 1000)
	private String areaIncludeList;

	@Column(name = "area_exclude_list", length = 1000)
	private String areaExcludeList;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@Column(name = "client_id", nullable = true, length = 3)
	private String clientId;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}