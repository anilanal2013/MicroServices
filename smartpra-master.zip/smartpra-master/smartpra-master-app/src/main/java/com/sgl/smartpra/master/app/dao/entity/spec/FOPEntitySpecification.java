package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.FOPEntity;

public final class FOPEntitySpecification {

	public static Specification<FOPEntity> equalsClientId(String clientId) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(fopEntity.get("clientId"),
				clientId);
	}

	public static Specification<FOPEntity> equalsFOPCode(String fopCode) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(fopEntity.get("fopCode"), fopCode);
	}

	public static Specification<FOPEntity> equalsFOPIdentifier(String fopIdentifier) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(fopEntity.get("fopIdentifier"),
				fopIdentifier);
	}

	public static Specification<FOPEntity> equalsFOPDescription(String fopDescription) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(fopEntity.get("fopDescription"),
				fopDescription);
	}

	public static Specification<FOPEntity> equalsTransactionType(String transactionType) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(fopEntity.get("transactionType"),
				transactionType);
	}

	public static Specification<FOPEntity> equalsControlId(String controlId) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(fopEntity.get("controlId"),
				controlId);
	}

	public static Specification<FOPEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), fopEntity.get("effectiveFromDate"),
				fopEntity.get("effectiveToDate"));
	}

	public static Specification<FOPEntity> isActive() {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(fopEntity.get("activate"), true);
	}

	public static Specification<FOPEntity> notEqualsfopId(Integer fopId) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(fopEntity.get("fopId"), fopId);
	}

	public static Specification<FOPEntity> equalsNegativeFopFlag(String negativeFopFlag) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(fopEntity.get("negativeFopFlag"),
				negativeFopFlag);
	}

	public static void orderByAsc(Root<FOPEntity> fopEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(fopEntity.get(orderByString)));
	}

	public static Specification<FOPEntity> search(Optional<String> fopCode, Optional<String> fopIdentifier,
			Optional<Boolean> activate) {
		return (fopEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(fopCode)) {
				predicates.add(criteriaBuilder.like(fopEntity.get("fopCode"), OptionalUtil.getValue(fopCode) + "%"));
			}
			if (OptionalUtil.isPresent(fopIdentifier)) {
				predicates.add(criteriaBuilder.like(fopEntity.get("fopIdentifier"),
						OptionalUtil.getValue(fopIdentifier) + "%"));
			}

			if (OptionalUtil.getValue(activate) == null || OptionalUtil.getValue(activate)) {
				predicates.add(criteriaBuilder.isTrue(fopEntity.get("activate")));
			} else {
				predicates.add(criteriaBuilder.isFalse(fopEntity.get("activate")));
			}
			orderByAsc(fopEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FOPEntity> searchByTransactionType(String fopIdentifier,String transactionType){
		return (fopEntity, criteriaQuery, criteriaBuilder)->{
			List<Predicate> predicates = new ArrayList<>();
			    if(fopIdentifier!=null && !fopIdentifier.equals(""))
			    {
				predicates.add(criteriaBuilder.equal(fopEntity.get("fopIdentifier"),
						fopIdentifier));
			    }
				predicates.add(criteriaBuilder.equal(fopEntity.get("transactionType"),
						transactionType ));
				predicates.add(criteriaBuilder.isTrue(fopEntity.get("activate")));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FOPEntity> searchByFOPIdentifier(String fopIdentifier){
		return(fopEntity, criteriaQuery, criteriaBuilder)->{
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBuilder.equal(fopEntity.get("fopIdentifier"), fopIdentifier));
		predicates.add(criteriaBuilder.isTrue(fopEntity.get("activate")));
		return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
