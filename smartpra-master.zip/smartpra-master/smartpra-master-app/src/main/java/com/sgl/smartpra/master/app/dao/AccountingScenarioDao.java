package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.AccountingScenarioEntity;
import com.sgl.smartpra.master.model.AccountingScenario;

@Repository
public interface AccountingScenarioDao {
	public AccountingScenarioEntity create(AccountingScenarioEntity accountingScenarioEntity);

	public AccountingScenarioEntity update(AccountingScenarioEntity accountingScenarioEntity);

	public Optional<AccountingScenarioEntity> findById(Integer scenarioNumber);

	public List<AccountingScenarioEntity> getSearchAllAccountingScenario(String transactionType,
			String selfOalIndicator, Boolean salesExistIndicator, String docType, String chargeCatCode,
			String chargeCode);

	public List<AccountingScenarioEntity> getSearchAllAccountingScenarioWithIsActiveParam(String module,
			String transactionType, String selfOalIndicator, Boolean salesExistIndicator, String docType,
			String chargeCatCode, String chargeCode, Boolean isActive);

	public long getOverlapRecordCount(AccountingScenario accountingScenario);

	public long getOverlapRecordCount(AccountingScenario accountingScenario, Integer scenarioNumber);

}
