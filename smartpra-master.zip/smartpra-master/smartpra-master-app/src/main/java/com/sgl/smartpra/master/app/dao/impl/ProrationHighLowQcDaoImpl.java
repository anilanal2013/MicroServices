package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.ProrationHighLowQcDao;
import com.sgl.smartpra.master.app.dao.entity.ProrationHighLowQcEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.ISCEntitySpec;
import com.sgl.smartpra.master.app.dao.entity.spec.ProrationHighLowQcEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.ProrationHighLowQcRepository;
import com.sgl.smartpra.master.model.ProrationHighLowQc;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProrationHighLowQcDaoImpl implements ProrationHighLowQcDao {

	@Autowired
	private ProrationHighLowQcRepository prorationHighLowQcRepository;

	@Override
	@Cacheable(value = "prorationHighLowQc", key = "#id")
	public Optional<ProrationHighLowQcEntity> getProrationHighLowIdById(Integer id) {
		log.info("Cacheable ProrationHighLowQc Entity's ID= {}", id);
		return prorationHighLowQcRepository.findById(id);
	}

	@Override
	public List<ProrationHighLowQcEntity> getAllProrationHighLowQc(Optional<String> clientId,ProrationHighLowQc hl){
		return prorationHighLowQcRepository.findAll(ProrationHighLowQcEntitySpecification.search(clientId, hl)); 
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "prorationHighLowQc", key = "#prorationHighLowQcEntity.lowHighQcId") })
	public ProrationHighLowQcEntity createProrationHighLowQc(ProrationHighLowQcEntity prorationHighLowQcEntity) {
		return prorationHighLowQcRepository.save(prorationHighLowQcEntity);
	}

	@Override
	public long getOverlapRecordCountForCreate(String clientId, String highLowId, String qcField,
			LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return prorationHighLowQcRepository.count(Specification.where(ProrationHighLowQcEntitySpecification
				.equalsClientId(clientId).and(ProrationHighLowQcEntitySpecification.equalsHighLowId(highLowId))
				.and(ProrationHighLowQcEntitySpecification.equalsQCField(qcField))

				.and((ProrationHighLowQcEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProrationHighLowQcEntitySpecification
								.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))).or(
										ProrationHighLowQcEntitySpecification.greaterThanOrEqualTo(effectiveFromDate)
												.and(ProrationHighLowQcEntitySpecification
														.lessThanOrEqualTo(effectiveToDate))))));
	}

	@Override
	public Optional<ProrationHighLowQcEntity> findById(Integer prorationHighLowQcId) {
		return prorationHighLowQcRepository.findById(prorationHighLowQcId);
	}

	@Override
	@CachePut(value = "prorationHighLowQc", key = "#prorationHighLowQcEntity.lowHighQcId")
	public ProrationHighLowQcEntity updateProrationHighLowQc(ProrationHighLowQcEntity prorationHighLowQcEntity) {
		return prorationHighLowQcRepository.save(prorationHighLowQcEntity);

	}

	@Override
	public long getOverlapRecordCountForCreate(String clientId, String highLowId, String qcField,
			LocalDate effectiveFromDate, LocalDate effectiveToDate, Integer lowHighQcId) {
		return prorationHighLowQcRepository.count(Specification.where(ProrationHighLowQcEntitySpecification
				.equalsClientId(clientId).and(ProrationHighLowQcEntitySpecification.equalsHighLowId(highLowId))
				.and(ProrationHighLowQcEntitySpecification.equalsQCField(qcField))
				.and((ProrationHighLowQcEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProrationHighLowQcEntitySpecification
								.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))).or(
										ProrationHighLowQcEntitySpecification.greaterThanOrEqualTo(effectiveFromDate)
												.and(ProrationHighLowQcEntitySpecification
														.lessThanOrEqualTo(effectiveToDate))))
				.and(ProrationHighLowQcEntitySpecification.notEqualsLowHighQcIdId(lowHighQcId))));
	}

	@Override
	public long getCount(ProrationHighLowQcEntity mapToEntity) {
		return prorationHighLowQcRepository.count(ProrationHighLowQcEntitySpecification.getCount(mapToEntity));
	}

	@Override
	public Page<ProrationHighLowQcEntity> getData(ProrationHighLowQcEntity mapToEntity, Pageable pageable) {
		return prorationHighLowQcRepository.findAll(ProrationHighLowQcEntitySpecification.getCount(mapToEntity),
				pageable);
	}

	@Override
	public List<ProrationHighLowQcEntity> searchHighLow(Optional<String> date) {
		return prorationHighLowQcRepository.findAll(ProrationHighLowQcEntitySpecification.searchHighLow(date));
	}
}
