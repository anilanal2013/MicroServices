package com.sgl.smartpra.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.CreditCardEntity;

@Repository
public interface CreditCardRepository
		extends JpaRepository<CreditCardEntity, Integer>, JpaSpecificationExecutor<CreditCardEntity> {

}
