package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.repository.entity.FormCodeEntity;
import com.sgl.smartpra.master.model.FormCode;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FormCodeMapper extends BaseMapper<FormCode, FormCodeEntity>{
	
	FormCodeEntity mapToEntity(FormCode formCodeModel,
			@MappingTarget FormCodeEntity formCodeEntity);

	@Mapping(source = "formCodeId", target = "formCodeId", ignore = true)
	FormCodeEntity mapToEntity(FormCode formCodeModel);
	
	
	
	
}
