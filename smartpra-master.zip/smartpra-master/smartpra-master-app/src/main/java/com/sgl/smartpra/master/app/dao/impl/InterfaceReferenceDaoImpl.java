package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.InterfaceReferenceDao;
import com.sgl.smartpra.master.app.dao.entity.spec.InterfaceReferenceEntitySpecification;
import com.sgl.smartpra.master.app.repository.InterfaceReferenceRepository;
import com.sgl.smartpra.master.app.repository.entity.InterfaceReferenceEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class InterfaceReferenceDaoImpl implements InterfaceReferenceDao {

	@Autowired
	private InterfaceReferenceRepository interfaceReferenceRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "interfaceReference", key = "#interfaceReferenceEntity.interfaceRefId"),
			@CacheEvict(value = "clientId", allEntries = true), @CacheEvict(value = "dataSource", allEntries = true), 
			@CacheEvict(value = "stationCode", allEntries = true), @CacheEvict(value = "effectiveDate", allEntries = true) })
	public InterfaceReferenceEntity create(InterfaceReferenceEntity interfaceReferenceEntity) {
		return interfaceReferenceRepository.save(interfaceReferenceEntity);
	}

	@Override
	@CachePut(value = "interfaceReference", key = "#interfaceReferenceEntity.interfaceRefId")
	@Caching(evict = { @CacheEvict(value = "clientId", allEntries = true), @CacheEvict(value = "dataSource", allEntries = true),
			@CacheEvict(value = "stationCode", allEntries = true), @CacheEvict(value = "effectiveDate", allEntries = true) })
	public InterfaceReferenceEntity update(InterfaceReferenceEntity interfaceReferenceEntity) {
		return interfaceReferenceRepository.save(interfaceReferenceEntity);
	}

	@Override
	@Cacheable(value = "interfaceReference", key = "#interfaceRefId")
	public Optional<InterfaceReferenceEntity> findById(Integer interfaceRefId) {
		log.info("Cacheable intetface reference entity ID = {}", interfaceRefId);
		return interfaceReferenceRepository.findById(interfaceRefId);
	}

	@Override
	public List<InterfaceReferenceEntity> search(Optional<String> clientId, Optional<String> dataSource, Optional<String> stationCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate, Optional<String> exceptionCall) {
		return interfaceReferenceRepository.findAll(InterfaceReferenceEntitySpecification.search(clientId, dataSource,
				stationCode, effectiveFromDate, effectiveToDate, activate, exceptionCall));
	}

	@Override
	public long getOverLapRecordCountCreate(String clientId, String dataSource, String stationCode,
			LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return interfaceReferenceRepository.count(Specification
				.where(InterfaceReferenceEntitySpecification.equalsClientId(clientId))
				.and(InterfaceReferenceEntitySpecification.equalsDataSource(dataSource))
				.and(InterfaceReferenceEntitySpecification.equalsStationCode(stationCode))
				.and(InterfaceReferenceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate))
				.and(InterfaceReferenceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)));
	}

	@Override
	public long getOverLapRecordCountUpdate(String clientId, String dataSource, String stationCode,
			LocalDate effectiveFromDate, LocalDate effectiveToDate, Integer interfaceRefId) {
		return interfaceReferenceRepository.count(Specification
				.where(InterfaceReferenceEntitySpecification.equalsClientId(clientId))
				.and(InterfaceReferenceEntitySpecification.equalsDataSource(dataSource))
				.and(InterfaceReferenceEntitySpecification.equalsStationCode(stationCode))
				.and(InterfaceReferenceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate))
				.and(InterfaceReferenceEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.and(InterfaceReferenceEntitySpecification.notEqualsInterfaceRefId(interfaceRefId)));
	}

	@Override
	@Cacheable(cacheNames = { "clientId", "dataSource", "stationCode", "effectiveDate" })
	public Optional<InterfaceReferenceEntity> getInterfaceReferenceByDataSourceAndStationCodeWithEffectiveDate(
			Optional<String> clientId, Optional<String> dataSource, Optional<String> stationCode,
			Optional<String> effectiveDate) {
		log.info("Cacheable InterfaceReference Entity's clientId= {}", clientId);
		return interfaceReferenceRepository.findOne(Specification
				.where(InterfaceReferenceEntitySpecification.equalsClientId(OptionalUtil.getValue(clientId)))
				.and(InterfaceReferenceEntitySpecification.equalsDataSource(OptionalUtil.getValue(dataSource)))
				.and(InterfaceReferenceEntitySpecification.equalsStationCode(OptionalUtil.getValue(stationCode)))
				.and(InterfaceReferenceEntitySpecification
						.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveDate)))
				.and((InterfaceReferenceEntitySpecification
						.greaterThanorEqualEffectiveFromDate(OptionalUtil.getLocalDateValue(effectiveDate)))
								.or(InterfaceReferenceEntitySpecification
										.lessThanorEqualEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveDate))))
				.and(InterfaceReferenceEntitySpecification.equalsActivate()));
	}

	@Override
	public long getCount(InterfaceReferenceEntity interfaceReferenceEntity) {
		return interfaceReferenceRepository
				.count(InterfaceReferenceEntitySpecification.search(interfaceReferenceEntity));
	}

	@Override
	public Page<InterfaceReferenceEntity> searchData(InterfaceReferenceEntity interfaceReferenceEntity,
			Pageable pageable) {
		return interfaceReferenceRepository
				.findAll(InterfaceReferenceEntitySpecification.search(interfaceReferenceEntity), pageable);
	}
}
