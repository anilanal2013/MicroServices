package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.app.dao.entity.ReportingSystemIdentifierEntity;
import com.sgl.smartpra.master.model.ReportingSystemIdentifier;

public interface ReportingSystemIdentifierDao {

	public Optional<ReportingSystemIdentifierEntity> findById(Integer rpsiAutoId);
	
	public ReportingSystemIdentifierEntity create(ReportingSystemIdentifierEntity reportingSystemIdentifierEntity);
	
	public ReportingSystemIdentifierEntity update(ReportingSystemIdentifierEntity reportingSystemIdentifierEntity);

	public Optional<ReportingSystemIdentifierEntity> getRpsiCodeByClientIdAndRpsiCode(Optional<String> rpsiCode, Optional<String> clientId);

	//public List<ReportingSystemIdentifierEntity> getAllReportingSystemIdentifier(Optional<String> rpsiCode,
	//		Optional<String> systemProvider, Boolean isActive);
	public List<ReportingSystemIdentifierEntity> getAllReportingSystemIdentifier(
			ReportingSystemIdentifier reportingSystemIdentifier, Optional<String> exceptionCall); 
	
}
