package com.sgl.smartpra.master.app.dao.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.SystemParameterEntity;

@Repository
public interface SystemParameterRepository
		extends JpaRepository<SystemParameterEntity, Integer>, JpaSpecificationExecutor<SystemParameterEntity> {
	
	public SystemParameterEntity findByParameterIdAndIsActiveTrue(Integer parameterId);
	
	public Optional<SystemParameterEntity> findByParameterIdAndClientId(Integer parameterId, Integer clientId);
	
	public Optional<SystemParameterEntity> findByParameterId(Integer parameterId);
	
	public List<SystemParameterEntity> findByParameterNameAndEffectiveToDateGreaterThanEqual(String parameterName, LocalDate effectiveDate);	

	public SystemParameterEntity findByParameterNameAndClientIdAndEffectiveToDateGreaterThanEqual(String parameterName,String clientId,LocalDateTime effectiveDate);
	
	public SystemParameterEntity findSystemParameterRangeByParameterNameAndClientId(String parameterName,String clientId);

	public SystemParameterEntity findByParameterNameAndClientIdAndEffectiveToDateGreaterThanEqual(String parameterName,String clientId,LocalDate effectiveDate);
	
	@Query("SELECT e FROM SystemParameterEntity e WHERE e.clientId = :clientId and e.effectiveToDate >= :effectiveDate and e.parameterName IN (:names)")   
	public List<SystemParameterEntity> findByParameterNameAndClientIdAndEffectiveToDateGreaterThanEqual(
			@Param("clientId") String clientId, @Param("effectiveDate") LocalDate effectiveDate,@Param("names") List<String> names);

}
