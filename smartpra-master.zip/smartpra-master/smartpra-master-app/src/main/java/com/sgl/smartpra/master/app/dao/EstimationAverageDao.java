package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.master.app.dao.entity.EstimationAverageEntity;
import com.sgl.smartpra.master.model.EstimationAverage;

public interface EstimationAverageDao {

	public List<EstimationAverageEntity> search(EstimationAverage estimationAverage, Optional<String> exceptionCall);

	public Optional<EstimationAverageEntity> getEstimationAverage(Optional<String> flightNumber,
			Optional<String> fromAirport, Optional<String> toAirport, Optional<String> rbd, Optional<String> cabin,
			Optional<String> passengerType, Optional<String> selfOc, LocalDate flightDate);

	public EstimationAverageEntity createEstimationAverage(EstimationAverageEntity estimationAverageEntity);

	public EstimationAverageEntity updateEstimationAverage(EstimationAverageEntity estimationAverageEntity);

	public Optional<EstimationAverageEntity> findById(Integer estimationAverageId);

	public long getOverLapRecordCount(Optional<String> clientId, Optional<String> flightNumber,
			Optional<String> fromAirport, Optional<String> toAirport, Optional<String> flightDate, Optional<String> rbd,
			Optional<String> cabin, Optional<String> passengerType, Optional<String> selfOc);

	public long getOverLapRecordCount(String clientId, String flightNumber, String fromAirport, String toAirport,
			LocalDate flightDate, String rbd, String cabin, String passengerType, String selfOc,
			Integer estimationAverageId);

	public Page<EstimationAverageEntity> getAllEstimationAverages(EstimationAverageEntity mapToEntity,
			Pageable pageable, Optional<String> exceptionCall);

	public Long getCount(EstimationAverageEntity mapToEntity);
}