package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.AccountService;
import com.sgl.smartpra.master.model.AccountAlphaCode;
import com.sgl.smartpra.master.model.AccountModel;

@RestController
public class AccountController {

	@Autowired
	private AccountService accountService;

	@PostMapping("/account")
	public AccountModel createAccount(@Validated(Create.class) @RequestBody AccountModel accountModel) {

		return accountService.createAccount(accountModel);
	}

	@PutMapping("/account/{accountAlphaCodeId}")
	public AccountModel updateAccount(@PathVariable(value = "accountAlphaCodeId") Integer accountAlphaCodeId,
			@RequestBody @Validated(Update.class) AccountModel accountModel) {

		return accountService.updateAccount(accountAlphaCodeId, accountModel);
	}

	@GetMapping("/accountGetById/{accountAlphaCodeId}")
	public AccountModel findByAccount(@PathVariable(value = "accountAlphaCodeId") Integer accountAlphaCodeId) {
		return accountService.findByAccount(accountAlphaCodeId);
	}

	@GetMapping("/account")
	public List<AccountModel> getAllAccount(
			@RequestParam(value = "accountAlphaCode", required = false) Optional<String> accountAlphaCode,
			@RequestParam(value = "accountNumCode", required = false) Optional<String> accountNumCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "clientId", required = false) Optional<String> clientId,
			@RequestParam(value = "accountType", required = false) Optional<String> accountType) {

		AccountModel accountModel = new AccountModel();
		accountModel.setAccountAlphaCode(accountAlphaCode);
		accountModel.setAccountNumCode(accountNumCode);
		if (OptionalUtil.isPresent(effectiveFromDate)) {
			accountModel.setEffectiveFromDate(effectiveFromDate);
		}
		if (OptionalUtil.isPresent(effectiveToDate)) {
			accountModel.setEffectiveToDate(effectiveToDate);
		}
		accountModel.setAccountType(accountType);
		accountModel.setClientId(clientId);
		return accountService.getAllAccount(accountModel);

	}

	@GetMapping("/account/{accountAlphaCode}")
	public Boolean findByAccountAlphaCode(@PathVariable(value = "accountAlphaCode") Optional<String> accountAlphaCode) {
		return accountService.findByAccountAlphaCode(accountAlphaCode);
	}

	@PostMapping("/account/account-alpha-code")
	public List<AccountModel> getListOfAccountBYAccountAphaCode(@RequestBody AccountAlphaCode accountAlphaCode) {

		return accountService.getListOfAccountBYAccountAphaCode(accountAlphaCode.getAccountAlphaCode());

	}

}
