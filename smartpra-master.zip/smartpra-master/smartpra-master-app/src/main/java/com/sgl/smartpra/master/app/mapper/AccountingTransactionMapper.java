package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.AccountingTransactionEntity;
import com.sgl.smartpra.master.model.AccountingTransaction;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AccountingTransactionMapper extends BaseMapper<AccountingTransaction, AccountingTransactionEntity> {
	AccountingTransactionEntity mapToEntity(AccountingTransaction accountingTransaction,
			@MappingTarget AccountingTransactionEntity accountingTransactionEntity);

	@Mapping(source = "accountingTransactionId", target = "accountingTransactionId", ignore = true)
	AccountingTransactionEntity mapToEntity(AccountingTransaction accountingTransaction);
	
}
