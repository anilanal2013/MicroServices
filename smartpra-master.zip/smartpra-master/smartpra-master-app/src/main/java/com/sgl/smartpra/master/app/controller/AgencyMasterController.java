package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.exception.ServiceException;
import com.sgl.smartpra.master.app.service.AgencyMasterService;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.master.model.AgencyMasterResponse;

@RestController
public class AgencyMasterController {

	@Autowired
	private AgencyMasterService agencyMasterService;

	public static final String DATACONSTARINTVIOALATION = "Record already exists";
	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";
	Optional<String> hostCarrierDesigCode;

	@GetMapping("/agency-master")
	public List<AgencyMaster> getAllAgency(
			@RequestParam(value = "agencyCode", required = false) Optional<String> agencyCode,
			@RequestParam(value = "reportingAgency", required = false) Optional<String> reportingAgency,
			@RequestParam(value = "agencyType", required = false) Optional<String> agencyType,
			@RequestParam(value = "areaOfOperation", required = false) Optional<String> areaOfOperation,
			@RequestParam(value = "reportingAgencyType", required = false) Optional<String> reportingAgencyType,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {

		return agencyMasterService.getListOfAgency(agencyCode, reportingAgency, agencyType, areaOfOperation,
				reportingAgencyType, activate);
	}

	@GetMapping("/agency/search")
	public List<AgencyMaster> getSearchAllAgency(
			@RequestParam(value = "agencyCode", required = false) Optional<String> agencyCode,
			@RequestParam(value = "reportingAgency", required = false) Optional<String> reportingAgency,
			@RequestParam(value = "agencyType", required = false) Optional<String> agencyType,
			@RequestParam(value = "areaOfOperation", required = false) Optional<String> areaOfOperation,
			@RequestParam(value = "reportingAgencyType", required = false) Optional<String> reportingAgencyType,
			@RequestParam(value = "cityCode", required = false) Optional<String> cityCode,
			@RequestParam(value = "countryCode", required = false) Optional<String> countryCode,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "clientId", required = false) Optional<String> clientId) {
		return agencyMasterService.getSearchAllAgency(agencyCode, reportingAgency, agencyType, areaOfOperation,
				reportingAgencyType, cityCode, countryCode, activate,clientId);
	}

	@GetMapping("/agency/search/list/{clientId}")
	public AgencyMasterResponse getSearchAllAgency(Pageable pageable,
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "agencyCode", required = false) Optional<String> agencyCode,
			@RequestParam(value = "reportingAgency", required = false) Optional<String> reportingAgency,
			@RequestParam(value = "agencyType", required = false) Optional<String> agencyType,
			@RequestParam(value = "areaOfOperation", required = false) Optional<String> areaOfOperation,
			@RequestParam(value = "reportingAgencyType", required = false) Optional<String> reportingAgencyType,
			@RequestParam(value = "cityCode", required = false) Optional<String> cityCode,
			@RequestParam(value = "countryCode", required = false) Optional<String> countryCode,
			@RequestParam(value = "activate", required = false) Boolean activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {

		AgencyMaster agencyMaster = new AgencyMaster();
		agencyMaster.setClientId(clientId);
		agencyMaster.setAgencyCode(agencyCode);
		agencyMaster.setReportingAgency(reportingAgency);
		agencyMaster.setAgencyType(agencyType);
		agencyMaster.setAreaOfOperation(areaOfOperation);
		agencyMaster.setReportingAgencyType(reportingAgencyType);
		agencyMaster.setCityCode(cityCode);
		agencyMaster.setCountryCode(countryCode);
		agencyMaster.setActivate(activate);

		return agencyMasterService.getListOfAgency(agencyMaster,exceptionCall, pageable);

	}

	@GetMapping("/agency-master/{agencyId}")
	public AgencyMaster getAgencyByAgencyId(@PathVariable(value = "agencyId") Integer agencyId) {
		return agencyMasterService.getAgencyByAgencyId(agencyId);
	}

	@GetMapping("/agency-master/agency-code-clientId-search")
	public AgencyMaster getAgencyByAgencyCode(
			@RequestParam(value = "agencyCode", required=true) String agencyCode,
			@RequestParam(value = "clientId", required=true) String clientId) {
		return agencyMasterService.getAgencyByAgencyCode(agencyCode, clientId);
	}

	@PostMapping("/agency-master")
	@ResponseStatus(value = HttpStatus.CREATED)
	public AgencyMaster createAgencyMaster(@Validated(Create.class) @RequestBody AgencyMaster agencyMaster) {
		return agencyMasterService.createAgency(agencyMaster);
	}
 
	@PutMapping("/agency-master/{agencyId}")
	@ResponseStatus(value = HttpStatus.OK)
	public AgencyMaster updateAgencyMaster(@PathVariable(value = "agencyId") Integer agencyId,
			@Validated(Update.class) @RequestBody AgencyMaster agencyMaster) {
		AgencyMaster agency = null;
		try {
			agency = agencyMasterService.updateAgency(agencyId, agencyMaster);
		} catch (DataIntegrityViolationException e) {
			throw new ServiceException(DATACONSTARINTVIOALATION);
		}
		return agency;
	}

	@PutMapping("/agency-master/{agencyId}/deactivate")
	public void deactivateAgencyMaster(@Valid @PathVariable(value = "agencyId") Integer agencyId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		agencyMasterService.deactivateAgency(agencyId, lastUpdatedBy);
	}

	@PutMapping("/agency-master/{agencyId}/activate")
	public void activateAgencyMaster(@Valid @PathVariable(value = "agencyId") Integer agencyId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		agencyMasterService.activateAgency(agencyId, lastUpdatedBy);
	}
}