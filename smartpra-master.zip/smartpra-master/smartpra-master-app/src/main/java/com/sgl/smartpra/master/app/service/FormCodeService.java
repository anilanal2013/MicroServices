package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.master.model.FormCodeResponse;

public interface FormCodeService {
	public List<FormCode> getListOfFormCode(Optional<String> clientId, Optional<String> formCode, Optional<String> docType,
			Optional<String> noOfCoupons, Optional<String> effectiveFormDate, Optional<String> effectiveToDate,Optional<Boolean> activate,
			Optional<String> exceptionCall);
	
	public List<FormCode> getListOfFormCode(Optional<String> formCode, Optional<String> docType,
			Optional<String> noOfCoupons, Optional<String> effectiveFormDate, Optional<String> effectiveToDate,Optional<Boolean> activate);

	public FormCode getFormCodeByformCodeId(Integer formCodeId);
	
	public FormCode getFormCodeByfromCodeAndEffectiveDate(Optional<String> clientId, Optional<String> formCode,Optional<String> effectiveDate);

	public FormCode createFormCode(FormCode formCode);

	public FormCode updateFormCode(Integer formCodeId, FormCode formCode);

	public void deactivateFormCode(Integer formCodeId, String lastUpdatedBy);

	public void activateFormCode(Integer formCodeId, String lastUpdatedBy);

	public FormCodeResponse getListOfFormCode(FormCode formCodeModel, Optional<String> exceptionCall, Pageable pageable);

	List<FormCode> getFormCodeByDate(Optional<String> formCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<Boolean> activate); 
}
