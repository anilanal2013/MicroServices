package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.FFYIdentification;

public interface FFYIdentificationService {

	public FFYIdentification findFFYIdentificationByffyIdentifyId(Integer ffyIdentifyId);

	public FFYIdentification createFFYIdentification(FFYIdentification ffyIdentification);

	public FFYIdentification updateFFYIdentification(Integer ffyIdentifyId, FFYIdentification ffyIdentification);

	public void deactivateFFYIdentification(Integer ffyIdentifyId, String lastUpdatedBy);

	public void activateFFYIdentification(Integer ffyIdentifyId, String lastUpdatedBy);

	public List<FFYIdentification> getAllFFYIdentification(Optional<String> issueCxrCode,
			Optional<String> marketingCxrCode, Optional<String> operatingCxrCode, Optional<String> saleFromDate,
			Optional<String> saleToDate, Optional<Boolean> activate);

}
