package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "mas_transaction_accounts")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class AccountingTransactionEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "accounting_transaction_id", nullable = false)
	private Integer accountingTransactionId;

	@Column(name = "client_id", nullable = false, length = 2)
	private String clientId;

	@Column(name = "scenario_number", nullable = false)
	private Integer scenarioNumber;

	@Column(name = "transaction_serial_no", nullable = false)
	private Integer transactionSerialNo;

	@Column(name = "account_definition_identifier", nullable = false)
	private Integer accountDefinitionIdentifier;

	@Column(name = "account_alpha_code", nullable = false, length = 3)
	private String accountAlphaCode;

	@Column(name = "provisional_account_code", length = 3)
	private String provisionalAccountCode;

	@Column(name = "debit_credit_indicator", length = 2)
	private String debitCreditIndicator;

	@Column(name = "balance_flag", length = 1)
	private String balanceFlag;

	@Column(name = "is_active", nullable = false, length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
