package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.AircraftDao;
import com.sgl.smartpra.master.app.dao.entity.spec.AircraftEntitySpecificaton;
import com.sgl.smartpra.master.app.repository.AircraftRepository;
import com.sgl.smartpra.master.app.repository.entity.AircraftEntity;
import com.sgl.smartpra.master.model.Aircraft;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AircraftDaoImpl implements AircraftDao {

	@Autowired
	private AircraftRepository aircraftRepository;

	@Override
	@Cacheable(value = "aircraft", key = "#id")
	public Optional<AircraftEntity> findById(Integer id) {
		log.info("Cacheable aircraft Entity's ID= {}", id);
		return aircraftRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "aircraft", key = "#aircraftEntity.aircraftId") })
	public AircraftEntity create(AircraftEntity aircraftEntity) {
		return aircraftRepository.save(aircraftEntity);
	}

	@Override
	@CachePut(value = "aircraft", key = "#aircraftEntity.aircraftId")
	public AircraftEntity update(AircraftEntity aircraftEntity) {
		return aircraftRepository.save(aircraftEntity);
	}

	@Override
	public List<AircraftEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return aircraftRepository
				.findAll((AircraftEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(AircraftEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(AircraftEntitySpecificaton.isActive())));

	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String aircraftRegistration) {
		return aircraftRepository.count(Specification.where(AircraftEntitySpecificaton.equalsClientId(clientId))
				.and(AircraftEntitySpecificaton.equalsAircraftRegistration(aircraftRegistration))
				.and(AircraftEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(AircraftEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))));

	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String clientId,
			String aircraftRegistration, Integer aircraftId) {
		return aircraftRepository.count(AircraftEntitySpecificaton.equalsClientId(clientId)
				.and(AircraftEntitySpecificaton.equalsAircraftRegistration(aircraftRegistration))
				.and(AircraftEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(AircraftEntitySpecificaton.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(AircraftEntitySpecificaton.notEqualsAircraftId(aircraftId)));

	}

	@Override
	public List<AircraftEntity> findAll(Aircraft aircraft, Optional<String> exceptionCall) {
		return aircraftRepository.findAll(AircraftEntitySpecificaton.search(aircraft.getClientId(),
				aircraft.getAircraftRegistration(), aircraft.getAircraftType(), aircraft.getActivate(), exceptionCall));
	}


	@Override
	public List<AircraftEntity> getAllAircraftDetails(Integer firstClassCapacity, Integer businessClassCapacity,
			Integer premiumEconomyClassCapacity, Integer economyClassCapacity) {
		return aircraftRepository.findAll(AircraftEntitySpecificaton.getAllAircraftDetails(firstClassCapacity,
				businessClassCapacity, premiumEconomyClassCapacity, economyClassCapacity));
	}

}
