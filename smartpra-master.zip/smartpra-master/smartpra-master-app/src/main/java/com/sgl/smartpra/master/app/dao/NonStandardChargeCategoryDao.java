package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCategoryEntity;

public interface NonStandardChargeCategoryDao {

	public Optional<NonStandardChargeCategoryEntity> findById(Integer nonStdCategoryId);
	
	public NonStandardChargeCategoryEntity create(NonStandardChargeCategoryEntity nonStdChargeCategoryEntity);

	public NonStandardChargeCategoryEntity update(NonStandardChargeCategoryEntity nonStdChargeCategoryEntity);
	
	public List<NonStandardChargeCategoryEntity> searchNonStandardChargeCategory(String clientId, Optional<String> nonStdCategoryCode, 
			Optional<String> stdCategoryCode, Optional<String> isActive);

	public int activateNonStandardChargeCategory(String clientId, String nonStdCategoryCode);
	
	public int deActivateNonStandardChargeCategory(String clientId, String nonStdCategoryCode);
	
	public String getMaxNonStdChargeCategoryCode(String clientId, String stdChargeCategoryCode, String initial);
	
	public String getNonStdChargeCategoryCode(String clientId, String stdCategoryCode, String nonStdCategoryName);
	
	public String getStdChargeCategoryCode(String clientId, String nonStdCategoryCode);
}
