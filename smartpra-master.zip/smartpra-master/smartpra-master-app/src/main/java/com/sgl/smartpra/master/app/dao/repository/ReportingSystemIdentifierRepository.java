package com.sgl.smartpra.master.app.dao.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.ReportingSystemIdentifierEntity;

@Repository
public interface ReportingSystemIdentifierRepository extends JpaRepository<ReportingSystemIdentifierEntity, Integer>,
		JpaSpecificationExecutor<ReportingSystemIdentifierEntity> {

	public Optional<ReportingSystemIdentifierEntity> findByClientIdAndRpsiCode(String clientId, String rpsiCode);

	public Optional<ReportingSystemIdentifierEntity> findByClientIdAndRpsiCodeAndRpsiAutoIdNot(String clientId,
			String rpsiCode, Integer rpsiAutoid);
}
