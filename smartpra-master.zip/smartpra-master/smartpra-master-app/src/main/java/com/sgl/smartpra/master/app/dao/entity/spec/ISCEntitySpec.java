package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.InterlineServiceChargeEntity;

public class ISCEntitySpec {

	public static void orderByDesc(Root<InterlineServiceChargeEntity> iscEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString, String recordType, String priority) {
		criteriaQuery.orderBy(criteriaBuilder.desc(iscEntity.get(orderByString)),
				criteriaBuilder.desc(iscEntity.get(recordType)), criteriaBuilder.asc(iscEntity.get(priority)));
	}

	public static Specification<InterlineServiceChargeEntity> search(Optional<String> documentType,
			Optional<String> iscRecordType, Optional<String> issueCxr, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> billingCxr, Optional<Boolean> activate) {

		return (iscEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(documentType)) {
				predicates
						.add(criteriaBuilder.equal(iscEntity.get("documentType"), OptionalUtil.getValue(documentType)));
			}
			if (OptionalUtil.isPresent(iscRecordType)) {
				predicates.add(criteriaBuilder.like(iscEntity.get("iscRecordType"),
						OptionalUtil.getValue(iscRecordType) + "%"));
			}
			if (OptionalUtil.isPresent(billingCxr)) {
				predicates.add(
						criteriaBuilder.like(iscEntity.get("billingCxr"), OptionalUtil.getValue(billingCxr) + "%"));
			}
			if (OptionalUtil.isPresent(issueCxr)) {
				predicates.add(criteriaBuilder.like(iscEntity.get("issueCxr"), OptionalUtil.getValue(issueCxr) + "%"));
			}

			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								iscEntity.get("effectiveFromDate"), iscEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								iscEntity.get("effectiveFromDate"), iscEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							iscEntity.get("effectiveFromDate"), iscEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							iscEntity.get("effectiveFromDate"), iscEntity.get("effectiveToDate")));
				}
			}

			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(iscEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(iscEntity.get("activate"), true));
			}
			orderByDesc(iscEntity, criteriaQuery, criteriaBuilder, "documentType", "iscRecordType", "priority");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static void orderByAsc(Root<InterlineServiceChargeEntity> interlineServiceChargeEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String oredrByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(interlineServiceChargeEntity.get(oredrByString)));
	}
	
	//Added new parameter
	public static Specification<InterlineServiceChargeEntity> searchISC(Optional<String> documentType, Optional<String> iscRecordType,
			Optional<String> effectiveFromDate, Optional<String> settlementIndicator, Optional<String> clientId,Optional<String> issueCxr,Optional<String> billingCxr) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(documentType)) {
				predicates
						.add(criteriaBuilder.equal(iscEntity.get("documentType"), OptionalUtil.getValue(documentType)));
			}

			if (OptionalUtil.isPresent(iscRecordType)) {
				predicates
						.add(criteriaBuilder.equal(iscEntity.get("iscRecordType"), OptionalUtil.getValue(iscRecordType)));
			}
			if (OptionalUtil.isPresent(effectiveFromDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								iscEntity.get("effectiveFromDate"), iscEntity.get("effectiveToDate"))));
			} 

			if (OptionalUtil.isPresent(settlementIndicator)) {
				predicates.add(criteriaBuilder.equal(iscEntity.get("settlementIndicator"), OptionalUtil.getValue(settlementIndicator)));
			}
			
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(iscEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(issueCxr)) {
				predicates.add(iscEntity.get("issueCxr").in((Object[])issueCxr.get().split(","))); 
			}
			if (OptionalUtil.isPresent(billingCxr)) {
				predicates.add(iscEntity.get("billingCxr").in((Object[])billingCxr.get().split(","))); 
			}
			
			predicates.add(criteriaBuilder.equal(iscEntity.get("activate"), true));
			orderByAsc(iscEntity, criteriaQuery, criteriaBuilder, "priority");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	

	public static Specification<InterlineServiceChargeEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate localDate) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(localDate), iscEntity.get("effectiveFromDate"),
				iscEntity.get("effectiveToDate"));
	}

	public static Specification<InterlineServiceChargeEntity> isActive() {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("activate"), true);
	}

	public static Specification<InterlineServiceChargeEntity> equalsClientId(String clientId) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("clientId"),
				clientId);
	}

	public static Specification<InterlineServiceChargeEntity> equalsDocumentType(String documentType) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("documentType"),
				documentType);
	}

	public static Specification<InterlineServiceChargeEntity> euqalsSettlementIndicator(String settlementIndicator) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(iscEntity.get("settlementIndicator"), settlementIndicator);
	}

	public static Specification<InterlineServiceChargeEntity> equalsIscRecordType(String iscRecordType) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("iscRecordType"),
				iscRecordType);
	}

	public static Specification<InterlineServiceChargeEntity> equalsIssueCxr(String issueCxr) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("issueCxr"),
				issueCxr);
	}

	public static Specification<InterlineServiceChargeEntity> equalsBillingCxr(String billingCxr) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("billingCxr"),
				billingCxr);
	}

	public static Specification<InterlineServiceChargeEntity> equalsSalesSource(String salesSource) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("salesSource"),
				salesSource);
	}

	public static Specification<InterlineServiceChargeEntity> equalsPointOfSale(String pointOfSale) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("pointOfSale"),
				pointOfSale);
	}

	public static Specification<InterlineServiceChargeEntity> equalsTravelFromArea(String travelFromArea) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("travelFromArea"),
				travelFromArea);
	}

	public static Specification<InterlineServiceChargeEntity> equalsTravelToArea(String travelToArea) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("travelToArea"),
				travelToArea);
	}

	public static Specification<InterlineServiceChargeEntity> equalsCouponFromArea(String couponFromArea) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("couponFromArea"),
				couponFromArea);
	}

	public static Specification<InterlineServiceChargeEntity> equalsCouponToArea(String couponToArea) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("couponToArea"),
				couponToArea);
	}

	public static Specification<InterlineServiceChargeEntity> equalsFlightRangeId(String flightRangeId) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("flightRangeId"),
				flightRangeId);
	}

	public static Specification<InterlineServiceChargeEntity> equalsFBGroupCode(String fbGroupCode) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(iscEntity.get("fbGroupCode"),
				fbGroupCode);
	}

	public static Specification<InterlineServiceChargeEntity> notEqualsISCId(Integer iscId) {
		return (iscEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(iscEntity.get("iscId"), iscId);
	}

}