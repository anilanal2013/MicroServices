package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "mas_spa_misc_data_stg")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class SPAMiscDataStgEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "spa_misc_data_id", nullable = false)
	private Integer spaMiscDataId;

	@Column(name = "spa_key", unique = true, nullable = false)
	private Integer spaKey;

	@Column(name = "spa_main_id", nullable = false)
	private Integer spaMainId;

	@Column(name = "client_id", nullable = false, length = 3)
	private String clientId;

	@Column(name = "record_type", unique= true, nullable = false)
	private Integer recordType;

	@Column(name = "misc_seq_no",unique = true, nullable = false)
	private Integer miscSeqNo;

	@Column(name = "info_field_1", length = 3)
	private String infoField1;

	@Column(name = "info_field_2")
	private Integer infoField2;

	@Column(name = "info_field_3")
	private Integer infoField3;

	@Column(name = "info_field_4", length = 1)
	private String infoField4;

	@Column(name = "info_field_5", length = 1)
	private String infoField5;

	@Column(name = "info_field_6", length = 1)
	private String infoField6;

	@Column(name = "info_field_7", length = 5)
	private String infoField7;

	@Column(name = "info_field_8", length = 5)
	private String infoField8;

	@Column(name = "info_field_9", length = 5)
	private String infoField9;

	@Column(name = "info_field_10", length = 15)
	private String infoField10;

	@Column(name = "info_field_11")
	private LocalDate infoField11;

	@Column(name = "info_field_12")
	private LocalDate infoField12;

	@Column(name = "info_field_13")
	private LocalDate infoField13;

	@Column(name = "info_field_14")
	private LocalDate infoField14;

	@Column(name = "info_field_15", length = 150)
	private String infoField15;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}


	//bi-directional many-to-one association to SPAMainStgEntity
	@ManyToOne(fetch = FetchType.EAGER,optional = false)
	@JoinColumn(name="spa_main_id",insertable=false, updatable=false)
	@JsonIgnore private SPAMainStgEntity masSpaMain;

}
