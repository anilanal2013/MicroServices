package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.SPASectorStgDao;
import com.sgl.smartpra.master.app.dao.entity.SPASectorStgEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.SPASectorStgEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.SPASectorStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SPASectorStgDaoImpl implements SPASectorStgDao {

	@Autowired
	private SPASectorStgRepository spaSectorStgRepository;

	@Override
	@Cacheable(value = "spaSectorStg", key = "#spaSectorId")
	public Optional<SPASectorStgEntity> findById(Integer spaSectorId) {
		log.info("Cacheable SPA Sector Entity's ID= {}", spaSectorId);
		return spaSectorStgRepository.findById(spaSectorId);
	}

	@Override
	public List<SPASectorStgEntity> findBySpaKeyMainIdClientId(Optional<Integer> spaKey, Optional<Integer> spaMainId,
			Optional<String> clientId) {
		return spaSectorStgRepository
				.findAll(SPASectorStgEntitySpecification.findBySpaKeyMainIdClientId(spaKey, spaMainId, clientId));
	}

}
