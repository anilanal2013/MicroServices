package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.AccountingTransaction;

public interface AccountingTransactionService {
	public AccountingTransaction crerateAccountingTransaction(AccountingTransaction accountingTransaction);

	public AccountingTransaction updateAccountingTransaction(Optional<Integer> scenarioNumber,
			Optional<Integer> accountDefinitionIdentifier, Integer accountingTransactionId,
			AccountingTransaction accountingTransaction);

	public AccountingTransaction getAccountingTransactionByAccountingId(Integer accountingTransactionId);

	public List<AccountingTransaction> getAccountingTransactionListByFkId(Integer scenarioNumber,
			Optional<Integer> accountDefinitionIdentifier, Optional<String> accountAlphaCode, Boolean isActive);

	public void activateAccountingTransaction(AccountingTransaction accountingTransaction);

	public void deactivateAccountingTransaction(AccountingTransaction accountingTransaction);

	public List<AccountingTransaction> getAccountingTransactionByScenarioNumber(Optional<Integer> scenarioNumber);

}
