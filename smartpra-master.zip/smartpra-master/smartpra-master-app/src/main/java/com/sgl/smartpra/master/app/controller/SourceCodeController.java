package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.SourceCodeService;
import com.sgl.smartpra.master.model.SourceCode;

@RestController
public class SourceCodeController {

	@Autowired
	private SourceCodeService sourceCodeService;

	@GetMapping("/source-codes/clientId/{clientId}")
	public List<SourceCode> getAllSourceCode(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "sourceType", required = false) Optional<String> sourceType,
			@RequestParam(value = "sourceCategory", required = false) Optional<String> sourceCategory,
			@RequestParam(value = "isActive", required = false) Optional<Boolean> isActive) {
		return sourceCodeService.getListOfSourceCode(clientId, sourceType, sourceCategory, isActive);
	}

	@GetMapping("/source-codes/{sourceCodeId}")
	public SourceCode getSourceCodeBySourceCodeId(@PathVariable(value = "sourceCodeId") Integer sourceCodeId) {
		return sourceCodeService.getSourceCodeBySourceCodeId(sourceCodeId);
	}

	@GetMapping("/source-codes/sourcecode/{sourceCode}")
	public List<SourceCode> getAllSourceCode(@PathVariable(value = "sourceCode") String sourceCode) {
		return sourceCodeService.getAllSourceCode(sourceCode);
	}

	@GetMapping("/source-codes/outwardsourcecode/{sourceCode}/{clientId}")
	public List<String> getOutwardSourceCodeBySourceCode(@PathVariable(value = "sourceCode") String sourceCode,
			@PathVariable(value = "clientId") String clientId) {
		return sourceCodeService.getOutwardSourceCodeBySourceCode(sourceCode, clientId);
	}

	@PostMapping("/source-codes")
	public SourceCode createSourceCode(@Validated(Create.class) @RequestBody SourceCode sourceCode) {
		return sourceCodeService.createSourceCode(sourceCode);
	}

	@PutMapping("source-codes/{sourceCodeId}")
	public SourceCode updateSourceCode(@PathVariable(value = "sourceCodeId") Integer sourceCodeId,
			@Validated(Update.class) @RequestBody SourceCode sourceCode) {
		return sourceCodeService.updateSourceCode(sourceCodeId, sourceCode);
	}

	@PutMapping("source-codes/{sourceCodeId}/activate")
	public void activateSourceCode(@Valid @PathVariable(value = "sourceCodeId") Integer sourceCodeId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		sourceCodeService.activateSourceCode(sourceCodeId, lastUpdatedBy);
	}

	@PutMapping("source-codes/{sourceCodeId}/deactivate")
	public void deactivateSourceCode(@Valid @PathVariable(value = "sourceCodeId") Integer sourceCodeId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		sourceCodeService.deactivateSourceCode(sourceCodeId, lastUpdatedBy);
	}

	@GetMapping("/source-codes/{sourceCode}/{clientId}")
	public List<SourceCode> getSourceCodeBySourceCodeAndClientId(@PathVariable(value = "sourceCode") String sourceCode,
			@PathVariable(value = "clientId") String clientId) {
		return sourceCodeService.getSourceCodeBySourceCodeAndClientId(sourceCode, clientId);
	}
}
