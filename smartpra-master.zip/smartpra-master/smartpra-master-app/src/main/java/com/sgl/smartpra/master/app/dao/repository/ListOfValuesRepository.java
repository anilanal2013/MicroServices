package com.sgl.smartpra.master.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.ListOfValuesEntity;

@Repository
public interface ListOfValuesRepository
		extends JpaRepository<ListOfValuesEntity, Integer>, JpaSpecificationExecutor<ListOfValuesEntity> {

	@Query(value = "select fieldValue from ListOfValuesEntity where"
			+ " clientId = ?1 and tableName = ?2 and columnName = ?3 and isActive = 'Y' order by displayOrder")
	List<String> getListOfFieldValues(String clientId, String tableName, String columnName);

}
