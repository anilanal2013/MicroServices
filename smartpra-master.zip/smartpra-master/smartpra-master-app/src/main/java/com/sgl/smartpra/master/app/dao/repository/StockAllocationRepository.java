package com.sgl.smartpra.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.StockAllocationEntity;

@Repository
public interface StockAllocationRepository
		extends JpaRepository<StockAllocationEntity, Integer>, JpaSpecificationExecutor<StockAllocationEntity> {

	@Query("SELECT documentToSeries from StockAllocationEntity c where  c.clientId =:clientId and "
			+ "	c.stockId =:stockId and c.agencyCode =:agencyCode and "
			+ " c.documentToSeries = (SELECT MAX(documentToSeries)  from StockAllocationEntity d"
			+ "	where d.clientId =:clientId and d.stockId =:stockId and d.agencyCode =:agencyCode ) ")
	String getLastDocumentToSeries(@Param("clientId") String clientId, @Param("stockId") Integer stockId, @Param("agencyCode") String agencyCode );		 
	
	
	@Query("SELECT documentToSeries from StockAllocationEntity c where  c.clientId =:clientId and "
			+ "	c.stockId =:stockId and "
			+ " c.documentToSeries = (SELECT MAX(documentToSeries)  from StockAllocationEntity d"
			+ "	where d.clientId =:clientId and d.stockId =:stockId) ")
	String getMaxDocumentToSeries(@Param("clientId") String clientId, @Param("stockId") Integer stockId);		 
	
}
