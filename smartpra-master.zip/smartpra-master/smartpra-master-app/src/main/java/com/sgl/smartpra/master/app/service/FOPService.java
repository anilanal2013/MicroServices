package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.FOP;

public interface FOPService {

	public FOP createFOP(FOP fop);

	public FOP updateFOP(FOP fop);

	public List<FOP> getListOfFOP(Optional<String> fopCode, Optional<String> fopIdentifier, Optional<Boolean> activate);


	 List<FOP> getListOfFOPByTransactionType(String fopIdentifier, String transactionType);

	 List<FOP> getListOfFOPByFopIdentifier(String fopIdentifier);

	public FOP getFOPByfopId(Integer fopId);

	public void deactivateFOP(FOP fop);

	public void activateFOP(FOP fop);

}
