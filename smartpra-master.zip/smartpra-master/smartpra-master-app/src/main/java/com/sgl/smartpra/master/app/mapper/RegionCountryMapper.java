package com.sgl.smartpra.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.master.app.repository.entity.RegionCountryEntity;
import com.sgl.smartpra.master.model.RegionCountry;

@Mapper
public interface RegionCountryMapper {

	RegionCountry mapToRegionCountryModel(RegionCountryEntity regionCountryEntity);

	List<RegionCountry> mapToRegionCountryModelList(List<RegionCountryEntity> regionCountryEntityList);

	RegionCountryEntity mapToRegionCountryEntity(RegionCountry regionCountry);

	List<RegionCountryEntity> mapToRegionCountryEntityList(List<RegionCountry> regionCountryList);

}
