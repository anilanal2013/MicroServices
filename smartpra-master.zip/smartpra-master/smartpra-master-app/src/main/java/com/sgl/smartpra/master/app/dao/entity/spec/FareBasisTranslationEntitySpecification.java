package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.FareBasisTranslationEntity;

public final class FareBasisTranslationEntitySpecification {
	private FareBasisTranslationEntitySpecification() {
	}

	// Start With getFareBasisTranslationResult()
	public static Specification<FareBasisTranslationEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), fareBasisTranslationEntity.get("effectiveFromDate"),
				fareBasisTranslationEntity.get("effectiveToDate"));
	}

	public static Specification<FareBasisTranslationEntity> searchOnDateBasis(Optional<String> marketingFareBasis,
			Optional<String> marketingTD,Optional<String> clientId, Optional<String> effectiveDate) {

		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(marketingFareBasis)) {
				predicates.add(criteriaBuilder.equal(fareBasisTranslationEntity.get("marketingFareBasis"),
						OptionalUtil.getValue(marketingFareBasis)));
			}
			if (OptionalUtil.isPresent(marketingTD)) {
				predicates.add(criteriaBuilder.equal(fareBasisTranslationEntity.get("marketingTD"),
						OptionalUtil.getValue(marketingTD)));
			}
			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(fareBasisTranslationEntity.get("clientId"),
						OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								fareBasisTranslationEntity.get("effectiveFromDate"),
								fareBasisTranslationEntity.get("effectiveToDate")),
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								fareBasisTranslationEntity.get("effectiveFromDate"),
								fareBasisTranslationEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
							fareBasisTranslationEntity.get("effectiveFromDate"),
							fareBasisTranslationEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
							fareBasisTranslationEntity.get("effectiveFromDate"),
							fareBasisTranslationEntity.get("effectiveToDate")));
				}
			}
			predicates.add(criteriaBuilder.equal(fareBasisTranslationEntity.get("activate"), true));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FareBasisTranslationEntity> equalsToMarketingFareBasis(
			Optional<String> marketingFareBasis) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("marketingFareBasis"), OptionalUtil.getValue(marketingFareBasis));
	}

	public static Specification<FareBasisTranslationEntity> equalsToMarketingTD(Optional<String> marketingTD) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("marketingTD"), OptionalUtil.getValue(marketingTD));
	}

	public static Specification<FareBasisTranslationEntity> equalsToFareOwnerCXR(Optional<String> fareOwnerCXR) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("fareOwnerCXR"), OptionalUtil.getValue(fareOwnerCXR));
	}

	public static Specification<FareBasisTranslationEntity> isActive() {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("activate"), true);
	}

	public static Specification<FareBasisTranslationEntity> equalsToClientId(String clientId) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("clientId"), clientId);
	}

	public static Specification<FareBasisTranslationEntity> equalsMarketingFareBasis(String marketingFareBasis) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("marketingFareBasis"), marketingFareBasis);
	}

	public static Specification<FareBasisTranslationEntity> equalsMarketingTD(String marketingTD) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("marketingTD"), marketingTD);
	}

	public static Specification<FareBasisTranslationEntity> equalsFareOwnerCXR(String fareOwnerCXR) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("fareOwnerCXR"), fareOwnerCXR);
	}

	public static Specification<FareBasisTranslationEntity> equalsToAreaFBWIndicator(String areaFBWIndicator) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("areaFBWIndicator"), areaFBWIndicator);
	}

	public static Specification<FareBasisTranslationEntity> equalsToFromAtea(String fromArea) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("fromArea"), fromArea);
	}

	public static Specification<FareBasisTranslationEntity> equalsToArea(String toArea) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("toArea"), toArea);
	}

	public static Specification<FareBasisTranslationEntity> equalsToFBTId(Integer fbtId) {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("fbtId"), fbtId);
	}
	// Ends With getFareBasisTranslationResult()

	public static Specification<FareBasisTranslationEntity> getFBTByIsPattern() {
		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareBasisTranslationEntity.get("isPattern"), true);
	}

	public static Specification<FareBasisTranslationEntity> search(Optional<String> marketingFareBasis,
			Optional<String> marketingTD, Optional<String> fareOwnerCXR, Optional<String> effectiveDate) {

		return (fareBasisTranslationEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(marketingFareBasis)) {
				predicates.add(criteriaBuilder.equal(fareBasisTranslationEntity.get("marketingFareBasis"),
						OptionalUtil.getValue(marketingFareBasis)));
			}
			if (OptionalUtil.isPresent(marketingTD)) {
				predicates.add(criteriaBuilder.equal(fareBasisTranslationEntity.get("marketingTD"),
						OptionalUtil.getValue(marketingTD)));
			}
			if (OptionalUtil.isPresent(fareOwnerCXR)) {
				predicates.add(criteriaBuilder.equal(fareBasisTranslationEntity.get("fareOwnerCXR"),
						OptionalUtil.getValue(fareOwnerCXR)));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								fareBasisTranslationEntity.get("effectiveFromDate"),
								fareBasisTranslationEntity.get("effectiveToDate")),
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								fareBasisTranslationEntity.get("effectiveFromDate"),
								fareBasisTranslationEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
							fareBasisTranslationEntity.get("effectiveFromDate"),
							fareBasisTranslationEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
							fareBasisTranslationEntity.get("effectiveFromDate"),
							fareBasisTranslationEntity.get("effectiveToDate")));
				}
			}
			predicates.add(criteriaBuilder.equal(fareBasisTranslationEntity.get("activate"), true));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
