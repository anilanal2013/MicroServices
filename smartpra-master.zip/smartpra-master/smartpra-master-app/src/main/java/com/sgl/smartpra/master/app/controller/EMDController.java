package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.EMDService;
import com.sgl.smartpra.master.model.EMDModel;

@RestController
public class EMDController {

	@Autowired
	private EMDService emdService;

	@GetMapping("emds")
	public List<EMDModel> getAllEmd(
			@RequestParam(value = "reasonForIssuanceCode", required = false) Optional<String> reasonForIssuanceCode,
			@RequestParam(value = "reasonForIssuanceSubCode", required = false) Optional<String> reasonForIssuanceSubCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "salesSource", required = false) Optional<String> salesSource,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		
		EMDModel emdModel = new EMDModel();
		emdModel.setClientId(Optional.of("QR"));
		emdModel.setReasonForIssuanceCode(reasonForIssuanceCode);
		emdModel.setReasonForIssuanceSubCode(reasonForIssuanceSubCode);
		emdModel.setEffectiveFromDate(effectiveFromDate);
		emdModel.setEffectiveToDate(effectiveToDate);
		emdModel.setSalesSource(salesSource);
		emdModel.setActivate(OptionalUtil.getValue(activate));
		
		return emdService.getListOfEMD(emdModel,Optional.of(""));
	}
	
	@GetMapping("emds/search/clientid/{clientId}")
	public List<EMDModel> getAllEmd(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "reasonForIssuanceCode", required = false) Optional<String> reasonForIssuanceCode,
			@RequestParam(value = "reasonForIssuanceSubCode", required = false) Optional<String> reasonForIssuanceSubCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "salesSource", required = false) Optional<String> salesSource,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {
		EMDModel emdModel = new EMDModel();
		emdModel.setClientId(clientId);
		emdModel.setReasonForIssuanceCode(reasonForIssuanceCode);
		emdModel.setReasonForIssuanceSubCode(reasonForIssuanceSubCode);
		emdModel.setEffectiveFromDate(effectiveFromDate);
		emdModel.setEffectiveToDate(effectiveToDate);
		emdModel.setSalesSource(salesSource);
		emdModel.setActivate(OptionalUtil.getValue(activate));
		
		return emdService.getListOfEMD(emdModel,exceptionCall);
	}

	@GetMapping("emds/{emdId}")
	public EMDModel getEMDByEmdId(@PathVariable(value = "emdId") Integer emdId) {
		return emdService.getEMDByEmdId(emdId);

	}

	@PostMapping("emds")
	public EMDModel createEMD(@Validated(Create.class) @RequestBody EMDModel emdModel) {
		return emdService.createEMD(emdModel);

	}

	@PutMapping("emd/{emdId}")
	public EMDModel updateEMD(@PathVariable(value = "emdId") Integer emdId,
			@Validated(Update.class) @RequestBody EMDModel emdModel) {
		return emdService.updateEMD(emdId, emdModel);
	}

	@PutMapping("emd/{emdId}/deactivate")
	public void deactivateEMD(@Valid @PathVariable(value = "emdId") Integer emdId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		emdService.deactivateEMD(emdId, lastUpdatedBy);
	}

	@PutMapping("emd/{emdId}/activate")
	public void activateEMD(@Valid @PathVariable(value = "emdId") Integer emdId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		emdService.activateEMD(emdId, lastUpdatedBy);

	}
}
