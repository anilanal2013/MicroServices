package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.FlightControlEntity;

public final class FlightControlEntitySpecification {

	public static Specification<FlightControlEntity> equalsClientId(String clientId) {
		return (flightControlEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(flightControlEntity.get("clientId"), clientId);
	}

	public static Specification<FlightControlEntity> equalsFlightControlId(String flightControlId) {
		return (flightControlEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(flightControlEntity.get("flightControlId"), flightControlId);
	}

	public static Specification<FlightControlEntity> notEqualsfopId(Integer flightControlAutoId) {
		return (FlightControlEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(FlightControlEntity.get("flightControlAutoId"), flightControlAutoId);
	}

	public static Specification<FlightControlEntity> activate() {
		return (flightControlEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(flightControlEntity.get("activate"), true);
	}

	private static void orderByAsc(Root<FlightControlEntity> flightControlEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String flightControlId) {
		criteriaQuery.orderBy(criteriaBuilder.asc(flightControlEntity.get(flightControlId)));
	}

	public static Specification<FlightControlEntity> search(Optional<String> clientId, Optional<String> flightControlId,
			Optional<Boolean> activate, Optional<String> exceptionCall) {
		return (flightControlEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(
						criteriaBuilder.equal(flightControlEntity.get("clientId"), OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(flightControlId)) {
				predicates.add(criteriaBuilder.like(flightControlEntity.get("flightControlId"),
						OptionalUtil.getValue(flightControlId) + "%"));
			}
			if (!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (OptionalUtil.isPresent(activate)) {
					predicates.add(criteriaBuilder.equal(flightControlEntity.get("activate"),
							OptionalUtil.getValue(activate)));
				}
				if (!OptionalUtil.isPresent(activate)) {
					predicates.add(criteriaBuilder.equal(flightControlEntity.get("activate"), true));
				}
			}
			orderByAsc(flightControlEntity, criteriaQuery, criteriaBuilder, "flightControlId");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}