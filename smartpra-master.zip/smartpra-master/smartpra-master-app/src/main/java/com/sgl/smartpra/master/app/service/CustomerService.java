package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.Customer;

public interface CustomerService {

	public List<Customer> getListOfCustomer(Customer customer, Optional<String> exceptionCall);

	public Customer getCustomerByCustomerMasId(Integer customerMasId);

	public Customer createCustomer(Customer customer);

	public Customer updateCustomer(Customer customer);

	public void deactivateCustomer(Integer customerMasId, String lastUpdatedBy);

	public void activateCustomer(Integer customerMasId, String lastUpdatedBy);

}
