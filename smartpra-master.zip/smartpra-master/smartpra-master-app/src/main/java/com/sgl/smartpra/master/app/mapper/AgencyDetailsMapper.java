package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.AgencyDetailsEntity;
import com.sgl.smartpra.master.model.AgencyDetailsModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AgencyDetailsMapper extends BaseMapper<AgencyDetailsModel, AgencyDetailsEntity> {

	AgencyDetailsEntity mapToEntity(AgencyDetailsModel agencyDetailModel,
			@MappingTarget AgencyDetailsEntity agencyDetailEntity);

	@Mapping(source = "agencyDetailsId", target = "agencyDetailsId", ignore = true)
	AgencyDetailsEntity mapToEntity(AgencyDetailsModel agencyDetailModel);

}
