package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.RegionService;
import com.sgl.smartpra.master.model.Region;

@RestController
public class RegionController {

	@Autowired
	private RegionService regionService;;

	@GetMapping("/regions")
	public List<Region> getAllRegion(@RequestParam(value = "regionCode", required = false) Optional<String> regionCode,
			@RequestParam(value = "regionName", required = false) Optional<String> regionName,
			@RequestParam(value = "continentName", required = false) Optional<String> continentName,
			@RequestParam(value = "isActive", required = false) Optional<Boolean> isActive) {

		Region region = new Region();
		// region.setClientId(clientId);
		region.setRegionCode(regionCode);
		region.setRegionName(regionName);
		region.setContinentName(continentName);
		region.setIsActive(OptionalUtil.getValue(isActive));

		return regionService.getAllRegion(region, Optional.of(""));

	}

	@GetMapping("/regions/search/clientId/{clientId}")
	public List<Region> getAllRegion(@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "regionCode", required = false) Optional<String> regionCode,
			@RequestParam(value = "regionName", required = false) Optional<String> regionName,
			@RequestParam(value = "continentName", required = false) Optional<String> continentName,
			@RequestParam(value = "isActive", required = false) Optional<Boolean> isActive,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {

		Region region = new Region();
		region.setClientId(clientId);
		region.setRegionCode(regionCode);
		region.setRegionName(regionName);
		region.setContinentName(continentName);
		region.setIsActive(OptionalUtil.getValue(isActive));

		return regionService.getAllRegion(region, exceptionCall);

	}


	@GetMapping("/regions/{regionId}")
	public Region getRegionByRegionCode(@PathVariable(value = "regionId") Integer regionId) {
		return regionService.findRegionByRegionId(regionId);
	}

	@PostMapping("/regions")
	public Region createRegion(@Validated(Create.class) @RequestBody Region region) {
		return regionService.createRegion(region);
	}

	@PutMapping("/regions/{regionId}")
	public Region updateRegion(@PathVariable(value = "regionId") Integer regionId,
			@Validated(Update.class) @RequestBody Region region) {
		return regionService.updateRegion(regionId, region);
	}

	@PutMapping("/regions/{regionId}/deactivate")
	public void deactivateRegion(@Valid @PathVariable(value = "regionId") Integer regionId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		regionService.deactivateRegion(regionId, lastUpdatedBy);

	}

	@PutMapping("/regions/{regionId}/activate")
	public void activateRegion(@Valid @PathVariable(value = "regionId") Integer regionId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		regionService.activateRegion(regionId, lastUpdatedBy);

	}

}