package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.CreditCardService;
import com.sgl.smartpra.master.model.CreditCard;

@RestController
public class CreditCardController {

	@Autowired
	private CreditCardService creditCardService;

	@GetMapping(value = "/credit-card")
	public List<CreditCard> getAllCreditCard(@RequestParam(name = "ccCompanyCode") Optional<String> ccCompanyCode,
			@RequestParam(name = "ccCompanyName") Optional<String> ccCompanyName,
			@RequestParam(name = "locallyInvoiced") Optional<Boolean> locallyInvoiced,
			@RequestParam(name = "uatpFlag") Optional<Boolean> uatpFlag,
			@RequestParam(name = "uatpAirlineCode") Optional<String> uatpAirlineCode,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		CreditCard creditCard = new CreditCard();
		creditCard.setCcCompanyCode(ccCompanyCode);
		creditCard.setCcCompanyName(ccCompanyName);
		creditCard.setLocallyInvoiced(locallyInvoiced);
		creditCard.setUatpFlag(uatpFlag);
		creditCard.setUatpAirlineCode(uatpAirlineCode);
		creditCard.setActivate(activate);
		return creditCardService.getAllCreditCard(creditCard,Optional.of(""));
	}
	
	@GetMapping(value = "/credit-card/search/clientid/{clientId}")
	public List<CreditCard> getAllCreditCard(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(name = "ccCompanyCode") Optional<String> ccCompanyCode,
			@RequestParam(name = "ccCompanyName") Optional<String> ccCompanyName,
			@RequestParam(name = "locallyInvoiced") Optional<Boolean> locallyInvoiced,
			@RequestParam(name = "uatpFlag") Optional<Boolean> uatpFlag,
			@RequestParam(name = "uatpAirlineCode") Optional<String> uatpAirlineCode,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {
		CreditCard creditCard = new CreditCard();
		creditCard.setClientId(clientId);
		creditCard.setCcCompanyCode(ccCompanyCode);
		creditCard.setCcCompanyName(ccCompanyName);
		creditCard.setLocallyInvoiced(locallyInvoiced);
		creditCard.setUatpFlag(uatpFlag);
		creditCard.setUatpAirlineCode(uatpAirlineCode);
		creditCard.setActivate(activate);
		return creditCardService.getAllCreditCard(creditCard,exceptionCall);
	}

	@GetMapping(value = "/credit-card/{creditCardId}")
	public CreditCard getCreditCardById(@PathVariable(name = "creditCardId") Integer creditCardId) {

		return creditCardService.getCreditCardById(creditCardId);
	}

	@PostMapping(value = "/credit-card")
	@ResponseStatus(value = HttpStatus.CREATED)
	public CreditCard createCreditCard(@Validated(Create.class) @RequestBody CreditCard creditCard) {

		return creditCardService.createCreditCard(creditCard);
	}

	@PutMapping(value = "/credit-card/{creditCardId}")
	@ResponseStatus(value = HttpStatus.OK)
	public CreditCard updateCreditCard(@PathVariable(value = "creditCardId") Integer creditCardId,
			@Validated(Update.class) @RequestBody CreditCard creditCard) {

		return creditCardService.updateCreditCard(creditCardId, creditCard);
	}

	@PutMapping("credit-card/{creditCardId}/deactivate")
	public void deactivateCreditCard(@Valid @PathVariable(value = "creditCardId") Integer creditCardId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		creditCardService.deactivateCreditCard(creditCardId, lastUpdatedBy);
	}

	@PutMapping("credit-card/{creditCardId}/activate")
	public void activateCreditCard(@Valid @PathVariable(value = "creditCardId") Integer creditCardId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		creditCardService.activateCreditCard(creditCardId, lastUpdatedBy);
	}
}
