package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.AccountingScenarioEntity;
import com.sgl.smartpra.master.model.AccountingScenario;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AccountingScenarioMapper extends BaseMapper<AccountingScenario, AccountingScenarioEntity>{
	AccountingScenarioEntity mapToEntity(AccountingScenario accountingScenario, @MappingTarget AccountingScenarioEntity accountingScenarioEntity);
	
	@Mapping(source = "scenarioNumber", target = "scenarioNumber", ignore = true)
	AccountingScenarioEntity mapToEntity(AccountingScenario accountingScenario);
}
