package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.CarrierAllianceEntity;
import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.OneWorldCarrierAlliance;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CarrierAllianceMapper extends BaseMapper<CarrierAlliance, CarrierAllianceEntity> {

	CarrierAllianceEntity mapToEntity(CarrierAlliance carrierAlliance,
			@MappingTarget CarrierAllianceEntity carrierAllianceEntity);

	CarrierAllianceEntity mapToEntity(OneWorldCarrierAlliance oneWorldCarrierAlliance,
			@MappingTarget CarrierAllianceEntity carrierAllianceEntity);

	@Mapping(source = "carrierAllianceDtlId", target = "carrierAllianceDtlId", ignore = true)
	CarrierAllianceEntity mapToEntity(CarrierAlliance carrierAlliance);

	@Mapping(source = "carrierAllianceDtlId", target = "carrierAllianceDtlId", ignore = true)
	CarrierAllianceEntity mapToEntity(OneWorldCarrierAlliance oneWorldCarrierAlliance);

	OneWorldCarrierAlliance mapToOneWorldCarrierAllianceModel(CarrierAllianceEntity carrierAllianceEntity);

}
