package com.sgl.smartpra.master.app.controller;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.FinancialMonthService;
import com.sgl.smartpra.master.model.FinancialMonthModel;

@RestController
public class FinancialMonthController {

	@Autowired
	private FinancialMonthService financialMonthService;

	@GetMapping("/financial-month")
	public List<FinancialMonthModel> getListOfFinancialMonthCalendar(
			@RequestParam(value = "financialYear", required = true) String financialYear,
			@RequestParam(value = "financialMonth", required = false) String financialMonth) {
		return financialMonthService.getListOfFinancialMonthCalendar(financialYear, financialMonth);
	}

	@GetMapping("/financial-month/{financialYear}/{financialMonth}")
	public FinancialMonthModel getFinancialMonthCalendarByFinancialYearAndMonth(
			@PathVariable(value = "financialYear") String financialYear,
			@PathVariable(value = "financialMonth") String financialMonth) {
		return financialMonthService.getFinancialMonthCalendarByFinancialYearAndMonth(financialYear, financialMonth);
	}

	@GetMapping("/financial-month/current-open")
	public FinancialMonthModel getCurrentOpenFinancialMonthForFinancialCalendar(
			@RequestParam(value = "clientId", required = false) String clientId) {
		if(StringUtils.isNotBlank(clientId)) {
			return financialMonthService.getCurrentOpenFinancialMonthForFinancialCalendarByClientId(clientId);
		} else {
			return financialMonthService.getCurrentOpenFinancialMonthForFinancialCalendar();
		}
	}
	
	@GetMapping("/financial-month/latest-closed")
	public FinancialMonthModel getLatestClosedFinancialMonthForFinancialCalendar() {
		return financialMonthService.getLatestClosedFinancialMonthForFinancialCalendar();
	}
	
	@GetMapping("/financial-month/financial-year")
	public FinancialMonthModel getFinancialYearByFinancialMonth(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "financialMonth", required = true) String financialMonth) {
		return financialMonthService.getFinancialYearByFinancialMonth(clientId,financialMonth);
	}

	@PostMapping("/financial-month")
	public FinancialMonthModel createFinancialMonthCalendar(
			@Validated(Create.class) @RequestBody FinancialMonthModel financialMonthModel) {
		return financialMonthService.createFinancialMonthCalendar(financialMonthModel);
	}

	@PutMapping("/financial-month/{financialMonthId}")
	public FinancialMonthModel updateFinancialMonthCalendar(
			@PathVariable(value = "financialMonthId") int financialMonthId,
			@Validated(Update.class) @RequestBody FinancialMonthModel financialMonthModel) {
		return financialMonthService.updateFinancialMonthCalendar(financialMonthId, financialMonthModel);
	}

}
