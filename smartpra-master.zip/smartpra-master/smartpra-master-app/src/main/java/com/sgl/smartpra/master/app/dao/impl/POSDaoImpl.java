package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.master.app.dao.POSDao;
import com.sgl.smartpra.master.app.dao.entity.spec.POSEntitySpecification;
import com.sgl.smartpra.master.app.repository.POSRepository;
import com.sgl.smartpra.master.app.repository.entity.POSEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class POSDaoImpl<T> extends CommonSearchDao<T> implements POSDao {
	@Autowired
	private POSRepository posRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "pos", key = "#posEntity.posId") })
	public POSEntity create(POSEntity posEntity) {
		return posRepository.save(posEntity);
	}

	@Override
	@CachePut(value = "pos", key = "#posEntity.posId")
	public POSEntity update(POSEntity posEntity) {
		return posRepository.save(posEntity);
	}

	@Override
	@Cacheable(value = "pos", key = "#posId")
	public Optional<POSEntity> findByPosCode(Integer posId) {
		log.info("Cacheable POS Entity's ID= {}", posId);
		return posRepository.findById(posId);
	}

	@Override
	public List<POSEntity> search(Optional<String> clientId, Optional<String> posCode, Optional<String> posName, Optional<String> accountCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return posRepository.findAll(
				POSEntitySpecification.search(clientId,posCode, posName, accountCode, effectiveFromDate, effectiveToDate));
	}

	@Override
	public long getOverLapForCreate(String posCode, String clientId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return posRepository.count(Specification.where(POSEntitySpecification.equalsPosCode(posCode))
				.and(POSEntitySpecification.equalsClientId(clientId))
				.and((POSEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(POSEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
								.or(POSEntitySpecification.greaterThanOrEqualTo(effectiveFromDate))
								.and(POSEntitySpecification.lessThanOrEqualTo(effectiveToDate))));
	}

	@Override
	public long getOverLapForUpdate(String posCode, String clientId, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, Integer posId) {
		return posRepository.count(Specification.where(POSEntitySpecification.equalsPosCode(posCode))
				.and(POSEntitySpecification.equalsClientId(clientId)).and(POSEntitySpecification.notEqualsfopId(posId))
				.and((POSEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(POSEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
								.or(POSEntitySpecification.greaterThanOrEqualTo(effectiveFromDate))
								.and(POSEntitySpecification.lessThanOrEqualTo(effectiveToDate))));
	}
}