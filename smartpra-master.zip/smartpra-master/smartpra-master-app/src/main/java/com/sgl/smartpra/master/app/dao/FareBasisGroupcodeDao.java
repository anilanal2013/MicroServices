package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.FareBasisGroupcodeEntity;

@Repository
public interface FareBasisGroupcodeDao {

	public Optional<FareBasisGroupcodeEntity> findById(Integer id);

	public FareBasisGroupcodeEntity create(FareBasisGroupcodeEntity fareBasisGroupcodeEntity);

	public FareBasisGroupcodeEntity update(FareBasisGroupcodeEntity fopMappingEntity);

	public void delete(Integer id);

	public List<FareBasisGroupcodeEntity> searchFareBasisGroupcode(FareBasisGroupcodeEntity fareBasisGroupcodeEntity);

	List<FareBasisGroupcodeEntity> findByFbGroupCode(String fbgroupcode);

	List<FareBasisGroupcodeEntity> getAllFareBasisGroupcode();
	
	List<FareBasisGroupcodeEntity> checkUniqueRecord(String fbGroupCode, String clientId, Integer seqLineNumber);

	public int getExistingRecord(String fbGroupCode, String clientId);

	public int getExistingRecord(String fbGroupCode);

	public List<FareBasisGroupcodeEntity> getFBTByIsPattern();

	public List<FareBasisGroupcodeEntity> search(Optional<String> fbGroupCode, Optional<String> fbDescription,
			Optional<Boolean> isActive);

}