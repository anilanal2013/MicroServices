package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.JobService;
import com.sgl.smartpra.master.model.Job;

@RestController
public class JobController {

	@Autowired
	private JobService jobService;

	@PostMapping("/job")
	@ResponseStatus(value = HttpStatus.CREATED)
	public Job createJob(@Validated(Create.class) @RequestBody Job job) {

		return jobService.createJob(job);
	}

	@PutMapping("/job/{jobId}")
	@ResponseStatus(value = HttpStatus.OK)
	public Job updateJob(@PathVariable(value = "jobId") Integer jobId,
			@RequestBody @Validated(Update.class) Job job) {
		job.setJobId(jobId);
		return jobService.updateJob(jobId, job);
	}

	@GetMapping("/job/{jobId}")
	public Job findByJobId(@PathVariable(value = "jobId") Integer jobId) {
		return jobService.findByJobId(jobId);
	}

	@GetMapping("/job/search/clientId/{clientId}")
	public List<Job> getAllJob(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "jobName", required = false) Optional<String> jobName,
			@RequestParam(value = "jobType", required = false) Optional<String> jobType,
			@RequestParam(value = "category", required = false) Optional<String> category,
			@RequestParam(value = "moduleName", required = false) Optional<String> moduleName,
			@RequestParam(value = "frequency", required = false) Optional<String> frequency,
			@RequestParam(value = "skipIndicator", required = false) Optional<Boolean> skipIndicator,
			@RequestParam(value = "timeLimitIndicator", required = false) Optional<Boolean> timeLimitIndicator,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate
			) {
		   
		Job job = new Job();
		job.setJobName(jobName);
		job.setJobType(jobType);
		job.setCategory(category);
		job.setModuleName(moduleName);
		job.setFrequency(frequency);
		job.setSkipIndicator(skipIndicator);
		job.setTimeLimitIndicator(timeLimitIndicator);
		job.setClientId(clientId);
		if (OptionalUtil.isPresent(effectiveFromDate)) {
			job.setEffectiveFromDate(effectiveFromDate);
		}
		if (OptionalUtil.isPresent(effectiveToDate)) {
			job.setEffectiveToDate(effectiveToDate);
		}
		return jobService.getAllJob(job);

	}
	
	@GetMapping("/job/with-effective-date")
	public List<Job> getAllJobByEffectiveDate(
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate){
		return jobService.getAllJobByEffectiveDate(effectiveFromDate);
	}

}
