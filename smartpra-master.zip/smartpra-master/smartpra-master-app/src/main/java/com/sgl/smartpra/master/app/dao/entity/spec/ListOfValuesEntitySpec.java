package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.ListOfValuesEntity;

public class ListOfValuesEntitySpec {
	
	private static final String ISACTIVE = "isActive";
	private static final String CLIENTID = "clientId";      
	private static final String TABLENAME = "tableName";
	private static final String COLUMNNAME = "columnName";
	private static final String FIELDVALUE = "fieldValue";
	private static final String DISPLAYORDER = "displayOrder";
	
	private ListOfValuesEntitySpec() {
		
	}
	

	public static Specification<ListOfValuesEntity> isActive() {
		return (listOfValuesEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(listOfValuesEntity.get(ISACTIVE), true);
	}

	public static Specification<ListOfValuesEntity> equalsClientId(String clientId) {
		return (listOfValuesEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(listOfValuesEntity.get(CLIENTID), clientId);

	}


	public static Specification<ListOfValuesEntity> fetchListOfValues(Optional<String> clientId, Optional<String> tableName,
			Optional<String> columnName, Optional<String> fieldValue) {
		return (listOfValuesEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
		
				predicates.add(criteriaBuilder.equal(listOfValuesEntity.get(CLIENTID), 
								OptionalUtil.getValue(clientId)));
			
				predicates.add(criteriaBuilder.equal(listOfValuesEntity.get(TABLENAME),
						OptionalUtil.getValue(tableName) ));
				
				predicates.add(criteriaBuilder.equal(listOfValuesEntity.get(COLUMNNAME),
						OptionalUtil.getValue(columnName) ));
			
				predicates.add(criteriaBuilder.equal(listOfValuesEntity.get(FIELDVALUE),
						OptionalUtil.getValue(fieldValue) ));
			
				predicates.add(criteriaBuilder.equal(listOfValuesEntity.get(ISACTIVE), true));
				orderByAsc(listOfValuesEntity, criteriaQuery, criteriaBuilder, DISPLAYORDER);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ListOfValuesEntity> fetchListOfValuesList(Optional<String> clientId, Optional<String> tableName,
			Optional<String> columnName) {
		return (listOfValuesEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
		
				predicates.add(criteriaBuilder.equal(listOfValuesEntity.get(CLIENTID), 
								OptionalUtil.getValue(clientId)));
			
				predicates.add(criteriaBuilder.equal(listOfValuesEntity.get(TABLENAME),
						OptionalUtil.getValue(tableName) ));
				
				predicates.add(criteriaBuilder.equal(listOfValuesEntity.get(COLUMNNAME),
						OptionalUtil.getValue(columnName) ));
			
				predicates.add(criteriaBuilder.equal(listOfValuesEntity.get(ISACTIVE), true));
				orderByAsc(listOfValuesEntity, criteriaQuery, criteriaBuilder, DISPLAYORDER);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static void orderByAsc(Root<ListOfValuesEntity> listOfValuesEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String displayOrder) {
		criteriaQuery.orderBy(criteriaBuilder.asc(listOfValuesEntity.get(displayOrder)));
	}
}
