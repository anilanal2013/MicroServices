package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.EstimationAverageEntity;
import com.sgl.smartpra.master.model.EstimationAverage;

public class EstimationAverageSpecification {

	private static final String FLIGHT_NUMBER = "flightNumber";
	private static final String FROM_AIRPORT = "fromAirport";
	private static final String TO_AIRPORT = "toAirport";
	private static final String CABIN = "cabin";
	private static final String SELF_OC = "selfOc";
	private static final String PASSENGER_TYPE = "passengerType";
	private static final String FLIGHT_DATE = "flightDate";
	private static final String ACTIVATE = "activate";

	public static Specification<EstimationAverageEntity> search(Optional<String> flightNumber,
			Optional<String> fromAirport, Optional<String> toAirport, Optional<String> rbd, Optional<String> cabin,
			Optional<String> passengerType, Optional<String> selfOc, LocalDate flightDate) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(flightNumber)) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(FLIGHT_NUMBER),
						OptionalUtil.getValue(flightNumber) + "%"));
			}
			if (OptionalUtil.isPresent(fromAirport)) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(FROM_AIRPORT),
						OptionalUtil.getValue(fromAirport) + "%"));
			}
			if (OptionalUtil.isPresent(toAirport)) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(TO_AIRPORT),
						OptionalUtil.getValue(toAirport) + "%"));
			}
			if (OptionalUtil.isPresent(rbd)) {
				predicates.add(
						criteriaBuilder.like(estimationAverageEntity.get("rbd"), OptionalUtil.getValue(rbd) + "%"));
			}
			if (OptionalUtil.isPresent(cabin)) {
				predicates.add(
						criteriaBuilder.like(estimationAverageEntity.get(CABIN), OptionalUtil.getValue(cabin) + "%"));
			}
			if (OptionalUtil.isPresent(selfOc)) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(SELF_OC),
						OptionalUtil.getValue(selfOc) + "%"));
			}
			if (OptionalUtil.isPresent(passengerType)) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(PASSENGER_TYPE),
						OptionalUtil.getValue(passengerType) + "%"));
			}
			if (flightDate != null) {
				predicates.add(criteriaBuilder.equal(estimationAverageEntity.get(FLIGHT_DATE), flightDate));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<EstimationAverageEntity> search(EstimationAverage estimationAverage,
			Optional<String> exceptionCall) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(estimationAverage.getClientId())) {
				predicates.add(criteriaBuilder.equal(estimationAverageEntity.get("clientId"),
						OptionalUtil.getValue(estimationAverage.getClientId())));
			}

			if (OptionalUtil.isPresent(estimationAverage.getFlightNumber())) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(FLIGHT_NUMBER),
						OptionalUtil.getValue(estimationAverage.getFlightNumber()) + "%"));
			}
			if (OptionalUtil.isPresent(estimationAverage.getFromAirport())) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(FROM_AIRPORT),
						OptionalUtil.getValue(estimationAverage.getFromAirport()) + "%"));
			}
			if (OptionalUtil.isPresent(estimationAverage.getToAirport())) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(TO_AIRPORT),
						OptionalUtil.getValue(estimationAverage.getToAirport()) + "%"));
			}
			if (OptionalUtil.isPresent(estimationAverage.getRbd())) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get("rbd"),
						OptionalUtil.getValue(estimationAverage.getRbd()) + "%"));
			}
			if (OptionalUtil.isPresent(estimationAverage.getCabin())) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(CABIN),
						OptionalUtil.getValue(estimationAverage.getCabin()) + "%"));
			}
			if (OptionalUtil.isPresent(estimationAverage.getSelfOc())) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(SELF_OC),
						OptionalUtil.getValue(estimationAverage.getSelfOc()) + "%"));
			}
			if (OptionalUtil.isPresent(estimationAverage.getPassengerType())) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(PASSENGER_TYPE),
						OptionalUtil.getValue(estimationAverage.getPassengerType()) + "%"));
			}
			if (OptionalUtil.isPresent(estimationAverage.getFlightDate())) {
				predicates.add(criteriaBuilder.equal(estimationAverageEntity.get(FLIGHT_DATE),
						OptionalUtil.getLocalDateValue(estimationAverage.getFlightDate())));
			}

			if (!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (estimationAverage.getActivate() != null) {
					predicates.add(criteriaBuilder.equal(estimationAverageEntity.get(ACTIVATE),
							estimationAverage.getActivate()));
				}
				if (estimationAverage.getActivate() == null) {
					predicates.add(criteriaBuilder.equal(estimationAverageEntity.get(ACTIVATE), true));
				}
			}
			orderByAsc(estimationAverageEntity, criteriaQuery, criteriaBuilder, FLIGHT_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private static void orderByAsc(Root<EstimationAverageEntity> estimationAverageEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String flightDate) {
		criteriaQuery.orderBy(criteriaBuilder.desc(estimationAverageEntity.get(flightDate)));
	}

	public static Specification<EstimationAverageEntity> equalsClientId(String clientId) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get("clientId"), clientId);

	}

	public static Specification<EstimationAverageEntity> equalsFlightNumber(String flightNumber) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get(FLIGHT_NUMBER), flightNumber);
	}

	public static Specification<EstimationAverageEntity> equalsFromAirport(String fromAirport) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get(FROM_AIRPORT), fromAirport);
	}

	public static Specification<EstimationAverageEntity> equalsToAirport(String toAirport) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get(TO_AIRPORT), toAirport);
	}

	public static Specification<EstimationAverageEntity> equalsFlightDate(LocalDate flightDate) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get(FLIGHT_DATE), flightDate);
	}

	public static Specification<EstimationAverageEntity> equalsRbd(String rbd) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get("rbd"), rbd);
	}

	public static Specification<EstimationAverageEntity> equalsCabin(String cabin) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get(CABIN), cabin);
	}

	public static Specification<EstimationAverageEntity> equalsPassengerType(String passengerType) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get(PASSENGER_TYPE), passengerType);
	}

	public static Specification<EstimationAverageEntity> equalsSelfOc(String selfOc) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get(SELF_OC), selfOc);
	}

	public static Specification<EstimationAverageEntity> isActive() {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(estimationAverageEntity.get(ACTIVATE), true);
	}

	public static Specification<EstimationAverageEntity> notEqualsEstimationAverageId(Integer estimationAverageId) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(estimationAverageEntity.get("estimationAverageId"), estimationAverageId);
	}

	public static Specification<EstimationAverageEntity> getAllEstimationAverages(String clientId, String flightNumber,
			String fromAirport, String toAirport, String rbd, String cabin, String passengerType, String selfOc,
			LocalDate flightDate, Boolean activate, Optional<String> exceptionCall) {
		return (estimationAverageEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (clientId != null && StringUtils.isNotEmpty(clientId)) {
				predicates.add(criteriaBuilder.equal(estimationAverageEntity.get("clientId"), clientId));
			}

			if (flightNumber != null) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(FLIGHT_NUMBER), flightNumber + "%"));
			}
			if (fromAirport != null) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(FROM_AIRPORT), (fromAirport) + "%"));
			}
			if (toAirport != null) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(TO_AIRPORT), (toAirport) + "%"));
			}
			if (rbd != null) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get("rbd"), (rbd) + "%"));
			}
			if (cabin != null) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(CABIN), (cabin) + "%"));
			}
			if (selfOc != null) {
				predicates.add(criteriaBuilder.like(estimationAverageEntity.get(SELF_OC), (selfOc) + "%"));
			}
			if (passengerType != null) {
				predicates
						.add(criteriaBuilder.like(estimationAverageEntity.get(PASSENGER_TYPE), (passengerType) + "%"));
			}
			if (flightDate != null) {
				predicates.add(criteriaBuilder.equal(estimationAverageEntity.get(FLIGHT_DATE), (flightDate)));
			}
			if (!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (activate != null) {
					predicates.add(criteriaBuilder.equal(estimationAverageEntity.get(ACTIVATE), (activate)));
				}
				if (activate == null) {
					predicates.add(criteriaBuilder.equal(estimationAverageEntity.get(ACTIVATE), true));
				}
			}
			orderByAsc(estimationAverageEntity, criteriaQuery, criteriaBuilder, FLIGHT_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}