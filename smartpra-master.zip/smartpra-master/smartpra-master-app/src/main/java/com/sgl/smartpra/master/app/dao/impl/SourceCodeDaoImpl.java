package com.sgl.smartpra.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.SourceCodeDao;
import com.sgl.smartpra.master.app.dao.entity.SourceCodeEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.SourceCodeEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.SourceCodeRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SourceCodeDaoImpl implements SourceCodeDao {

	@Autowired
	private SourceCodeRepository sourceCodeRepository;

	// findById...
	@Override
	@Cacheable(value = "sourceCode", key = "#id")
	public Optional<SourceCodeEntity> findById(Integer id) {
		return sourceCodeRepository.findById(id);
	}

	// findAll...
	@Override
	public List<SourceCodeEntity> search(Optional<String> clientId, Optional<String> sourceType,
			Optional<String> sourceCategory, Optional<Boolean> activate) {

		return sourceCodeRepository
				.findAll(SourceCodeEntitySpecification.search(clientId, sourceType, sourceCategory, activate));
	}

	// Create...
	@Override
	@Caching(evict = { @CacheEvict(value = "sourceCode", key = "#sourceCodeEntity.sourceCodeId") })
	public SourceCodeEntity create(SourceCodeEntity sourceCodeEntity) {
		return sourceCodeRepository.save(sourceCodeEntity);
	}

	// Update..
	@Override
	@CachePut(value = "sourceCode", key = "#sourceCodeEntity.sourceCodeId")
	public SourceCodeEntity update(SourceCodeEntity sourceCodeEntity) {
		return sourceCodeRepository.save(sourceCodeEntity);
	}

	// activate / deactivate
	@Override
	public void save(SourceCodeEntity sourceCodeEntity) {
		sourceCodeRepository.save(sourceCodeEntity);
	}

	@Override
	public List<SourceCodeEntity> findByClientIdAndSourceCode(Optional<String> clientId, Optional<String> sourceCode) {
		return sourceCodeRepository
				.findAll(SourceCodeEntitySpecification.findByClientIdAndSourceCode(clientId, sourceCode));
	}

	@Override
	public List<SourceCodeEntity> getAllSourceCode(String sourceCode) {
		return sourceCodeRepository.findAll(SourceCodeEntitySpecification.findBySourceCode(sourceCode));
	}

	@Override
	public long getOverLapForUpdate(String sourceCode, String clientId, Integer sourceCodeId) {
		return sourceCodeRepository.count(Specification.where(SourceCodeEntitySpecification.equalsClientId(clientId))
				.and(SourceCodeEntitySpecification.equalsSourceCode(sourceCode))
				.and(SourceCodeEntitySpecification.notEqualsSourceCodeId(sourceCodeId)));
	}

	@Override
	public List<String> getSourceCodeFromSourceCodeMaster() {

		return sourceCodeRepository.getSourceCodeFromSourceCodeMaster();
	}
}
