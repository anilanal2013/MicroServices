package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.master.app.service.SPAMainStgService;
import com.sgl.smartpra.master.model.SPAMainStg;

@RestController
@RequestMapping("/spa/main/stg")
public class SPAMainStgController {
	
	@Autowired
	private SPAMainStgService spaMainStgService;
	
	@GetMapping("/{spaMainId}")
	public SPAMainStg getSPAMainBySpaMainId(@PathVariable(value = "spaMainId") Integer spaMainId) {
		return spaMainStgService.findById(spaMainId);
	}

	@GetMapping("spakey/{spaKey}")
	public List<SPAMainStg> getSPAMainBySpaKey(@PathVariable(value = "spaKey") Optional<Integer> spaKey) {
		return spaMainStgService.findBySpaKey(spaKey);
	}
	
	@GetMapping("/fetchAllMainData/{spaMainId}")
	public List<SPAMainStg> getAllSPAMainBySpaKey(@PathVariable(value = "spaMainId") Optional<Integer> spaMainId) {
		return spaMainStgService.findAllMainDataBySpaMainId(spaMainId);
	}
	
	@GetMapping("/spakey/{spaKey}/spaclientid/{clientId}")
	public List<SPAMainStg> getSPAMainBySpaKeyAndSpaClientId(
			@PathVariable(value = "spaKey") Optional<Integer> spaKey,
			@PathVariable(value = "clientId") Optional<String> clientId) {
		return spaMainStgService.findBySpaKeyAndClientId(spaKey,clientId);
	}


}
