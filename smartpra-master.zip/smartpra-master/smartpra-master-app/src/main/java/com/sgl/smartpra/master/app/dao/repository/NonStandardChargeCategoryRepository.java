package com.sgl.smartpra.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.NonStandardChargeCategoryEntity;

@Repository
public interface NonStandardChargeCategoryRepository
		extends JpaRepository<NonStandardChargeCategoryEntity, Integer>, JpaSpecificationExecutor<NonStandardChargeCategoryEntity> {

	@Modifying
	@Query("update NonStandardChargeCategoryEntity set isActive = 'Y' where clientId = :clientId and nonStdCategoryCode = :nonStdCategoryCode ")
	public int activateNonStandardChargeCategory(@Param("clientId") String clientId, @Param("nonStdCategoryCode") String nonStdCategoryCode);
	
	@Modifying
	@Query("update NonStandardChargeCategoryEntity set isActive = 'N' where clientId = :clientId and nonStdCategoryCode = :nonStdCategoryCode ")
	public int deActivateNonStandardChargeCategory(@Param("clientId") String clientId, @Param("nonStdCategoryCode") String nonStdCategoryCode);
	
	@Query(value = "select max(nonStdCategoryCode) from NonStandardChargeCategoryEntity where clientId = :clientId and nonStdCategoryCode like :initial% ") 
	public String getMaxNonStdChargeCategoryCode(@Param("clientId") String clientId,
			@Param("initial") String initial);
	
	@Query(value = "select nonStdCategoryCode from NonStandardChargeCategoryEntity where clientId = :clientId "
			+ " and nonStdCategoryName = :nonStdCategoryName ") 
	public String getNonStdChargeCategoryCode(@Param("clientId") String clientId, @Param("nonStdCategoryName") String nonStdCategoryName);
	
	
	
	@Query(value = "select stdCategoryCode from NonStandardChargeCategoryEntity where clientId = :clientId and nonStdCategoryCode = :nonStdCategoryCode ")
	public String getStdChargeCategoryCode(@Param("clientId") String clientId, @Param("nonStdCategoryCode") String nonStdCategoryCode);
}
