package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.FOPEntity;

@Repository
public interface FOPDao {
	public Optional<FOPEntity> findById(Integer id);

	public FOPEntity create(FOPEntity fopEntity);

	public FOPEntity update(FOPEntity fopEntity);

	public void delete(Integer id);

	public List<FOPEntity> findAll();

	public List<FOPEntity> search(Optional<String> fopCode,Optional<String> fopIdentifier, Optional<Boolean> activate);

	public List<FOPEntity> searchByTransactionType(String fopIdentifier,String transactionType);

	public List<FOPEntity> searchByFOPIdentifier(String fopIdentifier);
 
	// -- This is for Create-Overlap Count Validation
	public long getOverLapRecordCount(String clientId, String fopCode, String fopIdentifier, String negativeFopFlag,
			String transactionType, String controlId, LocalDate effectiveFromDate, LocalDate effectiveToDate);

	// -- This is for Update- Overlap Count Validation
	public long getOverLapRecordCount(String clientId, String fopCode, String fopIdentifier, String negativeFopFlag,
			String transactionType, String controlId, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			Integer fopId);
	public List<String> getFOPIdentifierFromFOPMaster();
}
