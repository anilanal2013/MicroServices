package com.sgl.smartpra.master.app.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.CodeShareService;
import com.sgl.smartpra.master.model.CodeShare;

@RestController
public class CodeShareController {

	@Autowired
	private CodeShareService codeShareService;

	@GetMapping("/code-shares")
	public List<CodeShare> getCodeShareByEffectiveDate(
			@RequestParam(value = "clientId",required=false) Optional<String> clientId,
			@RequestParam(value = "marketingCXR",required=false) Optional<String> marketingCXR,
			@RequestParam(value = "marketedRBDList",required=false) Optional<String> marketedRBDList,
			@RequestParam(value = "effectiveTravelDate",required=false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveTravelDate) {
		return codeShareService.getCodeShareByEffectiveDate(clientId,marketingCXR,marketedRBDList,effectiveTravelDate);
	}
	@GetMapping("/code-shares/{codeShareId}")
	public CodeShare getCodeShareByCodeShareId(@PathVariable(value = "codeShareId") Integer codeShareId) {
		return codeShareService.getCodeShareByCodeShareId(codeShareId);
	}
	
	@GetMapping("/code-shares/list")
	public List<CodeShare> getAllCodeShare(
			@RequestParam(value = "clientId",required=false) Optional<String> clientId,
			@RequestParam(value = "marketingCXR",required=false) Optional<String> marketingCXR,
			@RequestParam(value = "effectiveTravelFromDate",required=false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveTravelFromDate,
			@RequestParam(value = "effectiveTravelToDate",required=false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveTravelToDate,
			@RequestParam(value = "effectiveSaleFromDate",required=false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveSaleFromDate,
			@RequestParam(value = "effectiveSaleToDate",required=false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveSaleToDate,
			@RequestParam(value = "isActive",required=false) Optional<Boolean> isActive) {
		return codeShareService.getAllCodeShare(clientId,marketingCXR,effectiveTravelFromDate,effectiveTravelToDate,effectiveSaleFromDate,effectiveSaleToDate,isActive);
	}
	
	//
	@GetMapping("/code-shares/bsp") 
	public List<CodeShare> getCodeShareByEffectiveDateBSP(
			@RequestParam(value = "clientId", required = false) Optional<String> clientId,
			@RequestParam(value = "marketingCXR", required = false) Optional<String> marketingCXR,
			@RequestParam(value = "marketedRBDList", required = false) Optional<String> marketedRBDList,
			@RequestParam(value = "effectiveTravelDate", required = false) Optional<String> effectiveTravelDate) {

		return codeShareService.getCodeShareByEffectiveDate(clientId,marketingCXR,marketedRBDList,effectiveTravelDate);
	}

	
	@GetMapping("/code-shares/{marketingCXR}/{travelEffectiveDate}/{saleEffectiveDate}/{clientId}/{flightNumber}")
	public CodeShare getCodeShareBymarketingCXR(@PathVariable(value = "marketingCXR",required=true) String marketingCXR,
			@PathVariable(value = "travelEffectiveDate",required=true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date travelEffectiveDate,
			@PathVariable(value = "saleEffectiveDate",required=true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date saleEffectiveDate,
			@PathVariable(value = "clientId",required=true) String clientId,
			@PathVariable(value = "flightNumber",required=true) String flightNumber) {
		return codeShareService.getCodeShareBymarketingCXR(marketingCXR,travelEffectiveDate,saleEffectiveDate,clientId,flightNumber);
	}
	
	
	
	//for bsp only
	@GetMapping("/code-shares/code-share-saledate-search")
	public CodeShare getCodeShareByClientAndMarketingCXRAndMarketedRBDAndEffectiveDateSales(
			@RequestParam(value = "clientId",required=true) String clientId,
			@RequestParam(value = "marketingCXR",required=true) String marketingCXR,
			@RequestParam(value = "marketedRBDList",required=true) String marketedRBDList,
			@RequestParam(value = "effectiveDate",required=true) @DateFormat(pattern = "yyyy-MM-dd") String effectiveDate,
			@RequestParam(value = "flightNumber",required=true) String flightNumber) {
		return codeShareService.getCodeShareByClientAndMarketingCXRAndMarketedRBDAndEffectiveDateSales
				(clientId,marketingCXR,marketedRBDList,effectiveDate,flightNumber);
	}

	@GetMapping("/code-shares/{clientId}/{operatingflightNumber}/{travelDate}/{operatingCXR}/{marketingflightNumber}/{saleDate}/{marketingCXR}")
	public CodeShare getCodeShareForValidation(@PathVariable(value = "clientId",required=true) String clientId,
			@PathVariable(value = "operatingflightNumber",required=true) String operatingflightNumber,
			@PathVariable(value = "travelDate",required=true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date travelDate,
			@PathVariable(value = "operatingCXR",required=true) String operatingCXR,
			@PathVariable(value = "marketingflightNumber",required=true) String marketingflightNumber,
			@PathVariable(value = "saleDate",required=true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date saleDate,
			@PathVariable(value = "marketingCXR",required=true) String marketingCXR) {
		return codeShareService.getCodeShareForValidation(clientId, operatingflightNumber, travelDate, operatingCXR, marketingflightNumber, saleDate, marketingCXR);
	}	
	
	
	//calling from code share populate data
	@GetMapping("/code-shares/populatedata/{marketingCXR}/{travelEffectiveDate}/{saleEffectiveDate}/{clientId}/{flightNumber}")
	public List<CodeShare> getCodeSharePopulateData(@PathVariable(value = "marketingCXR",required=false) String marketingCXR,
			@PathVariable(value = "travelEffectiveDate",required=false) String travelEffectiveDate,
			@PathVariable(value = "saleEffectiveDate",required=false) String saleEffectiveDate,
			@PathVariable(value = "clientId",required=false) String clientId,
			@PathVariable(value = "flightNumber",required=false) String flightNumber) {
		Date effectiveDateObject = new Date();
		Date saleDateObject = new Date();
		try {
			effectiveDateObject = new SimpleDateFormat("yyyy-MM-dd").parse(travelEffectiveDate);
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			saleDateObject = new SimpleDateFormat("yyyy-MM-dd").parse(saleEffectiveDate);
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return codeShareService.getCodeSharePopulateData(marketingCXR,effectiveDateObject,saleDateObject,clientId,flightNumber);
	}
	
	//calling from code share populate data
		@GetMapping("/code-shares/populatedata/{marketingCXR}/{travelEffectiveDate}/{clientId}/{flightNumber}")
		public List<CodeShare> getCodeSharePopulateDataSingleCoupon(@PathVariable(value = "marketingCXR",required=false) String marketingCXR,
				@PathVariable(value = "travelEffectiveDate",required=false) String travelEffectiveDate,
				@PathVariable(value = "clientId",required=false) String clientId,
				@PathVariable(value = "flightNumber",required=false) String flightNumber) {
			Date effectiveDateObject = new Date();	
			try {
				effectiveDateObject = new SimpleDateFormat("yyyy-MM-dd").parse(travelEffectiveDate);
			} catch (java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return codeShareService.getCodeSharePopulateData(marketingCXR,effectiveDateObject,null,clientId,flightNumber);
		}

	
	
	@PostMapping("/code-shares")
	public CodeShare createCodeShare(@Validated(Create.class) @RequestBody CodeShare codeShare) {
		return codeShareService.createCodeShare(codeShare);
	}

	@PutMapping("/code-shares/{codeShareId}")
	public CodeShare updateCodeShare(@PathVariable(value = "codeShareId") Integer codeShareId,
			@Validated(Update.class) @RequestBody CodeShare codeShare) {
		return codeShareService.updateCodeShare(codeShareId, codeShare);
	}

	@PutMapping("/code-shares/{codeShareId}/deactivate")
	public void deactivateCodeShare(@Valid @PathVariable(value = "codeShareId") Integer  codeShareId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		codeShareService.deactivateCodeShare(codeShareId, lastUpdatedBy);
	}

	@PutMapping("/code-shares/{codeShareId}/activate")
	public void activateCodeShare(@Valid @PathVariable(value = "codeShareId") Integer codeShareId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		codeShareService.activateCodeShare(codeShareId, lastUpdatedBy);
	}
}
