package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.AccountingTransactionService;
import com.sgl.smartpra.master.model.AccountingTransaction;

@RestController
public class AccountingTransactionController {

	@Autowired
	private AccountingTransactionService accountingTransactionService;

	@PostMapping("/accounting-scenario/{scenarioNumber}/accounting-definition/{accountDefinitionIdentifier}/accounting-transaction")
	@ResponseStatus(value = HttpStatus.CREATED)
	public AccountingTransaction createAccountingTransaction(
			@Validated(Create.class) @RequestBody AccountingTransaction accountingTransaction,
			@PathVariable(value = "scenarioNumber") Optional<Integer> scenarioNumber,
			@PathVariable(value = "accountDefinitionIdentifier") Optional<Integer> accountDefinitionIdentifier) {
		accountingTransaction.setScenarioNumber(scenarioNumber);
		accountingTransaction.setAccountDefinitionIdentifier(accountDefinitionIdentifier);
		return accountingTransactionService.crerateAccountingTransaction(accountingTransaction);

	}

	@PutMapping("/accounting-scenario/{scenarioNumber}/accounting-definition/{accountDefinitionIdentifier}/accounting-transaction/{accountingTransactionId}")
	@ResponseStatus(value = HttpStatus.OK)
	public AccountingTransaction updateAccountingTransaction(
			@PathVariable(value = "scenarioNumber") Optional<Integer> scenarioNumber,
			@PathVariable(value = "accountDefinitionIdentifier") Optional<Integer> accountDefinitionIdentifier,
			@PathVariable(value = "accountingTransactionId") Integer accountingTransactionId,
			@Validated(Update.class) @RequestBody AccountingTransaction accountingTransaction) {
		return accountingTransactionService.updateAccountingTransaction(scenarioNumber, accountDefinitionIdentifier,
				accountingTransactionId, accountingTransaction);
	}

	@GetMapping("/accounting-transaction/{accountingTransactionId}")
	public AccountingTransaction getAccountingTransactionByAccountingId(
			@PathVariable(value = "accountingTransactionId") Integer accountingTransactionId) {
		return accountingTransactionService.getAccountingTransactionByAccountingId(accountingTransactionId);
	}

	@GetMapping("/accounting-transaction/accounting-scenario/{scenarioNumber}")
	public List<AccountingTransaction> getAccountingTransactionByScenarioNumber(
			@PathVariable(value = "scenarioNumber") Optional<Integer> scenarioNumber) {
		return accountingTransactionService.getAccountingTransactionByScenarioNumber(scenarioNumber);
	}

	@GetMapping("/accounting-scenario/accounting-transaction/search")
	public List<AccountingTransaction> getAccountingTransactionListByFkId(
			@RequestParam(value = "scenarioNumber", required = false) Integer scenarioNumber,
			@RequestParam(value = "accountDefinitionIdentifier", required = false) Optional<Integer> accountDefinitionIdentifier,
			@RequestParam(value = "accountAlphaCode", required = false) Optional<String> accountAlphaCode,
			@RequestParam(value = "isActive", required = false) Boolean isActive) {
		return accountingTransactionService.getAccountingTransactionListByFkId(scenarioNumber,
				accountDefinitionIdentifier, accountAlphaCode, isActive);
	}

	@PutMapping("/accounting-scenario/{scenarioNumber}/accounting-definition/{accountDefinitionIdentifier}/accounting-transaction/{accountingTransactionId}/activate")
	public void activateAccountingScenario(
			@Valid @PathVariable(value = "scenarioNumber") Optional<Integer> scenarioNumber,
			@PathVariable(value = "accountDefinitionIdentifier") Optional<Integer> accountDefinitionIdentifier,
			@PathVariable(value = "accountingTransactionId") Integer accountingTransactionId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		AccountingTransaction accountingTransaction = new AccountingTransaction();
		accountingTransaction.setScenarioNumber(scenarioNumber);
		accountingTransaction.setAccountDefinitionIdentifier(accountDefinitionIdentifier);
		accountingTransaction.setAccountingTransactionId(accountingTransactionId);
		accountingTransaction.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		accountingTransactionService.activateAccountingTransaction(accountingTransaction);

	}

	@PutMapping("/accounting-scenario/{scenarioNumber}/accounting-definition/{accountDefinitionIdentifier}/accounting-transaction/{accountingTransactionId}/deactivate")
	public void deactivateAccountingScenario(
			@Valid @PathVariable(value = "scenarioNumber") Optional<Integer> scenarioNumber,
			@PathVariable(value = "accountDefinitionIdentifier") Optional<Integer> accountDefinitionIdentifier,
			@PathVariable(value = "accountingTransactionId") Integer accountingTransactionId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		AccountingTransaction accountingTransaction = new AccountingTransaction();
		accountingTransaction.setScenarioNumber(scenarioNumber);
		accountingTransaction.setAccountDefinitionIdentifier(accountDefinitionIdentifier);
		accountingTransaction.setAccountingTransactionId(accountingTransactionId);
		accountingTransaction.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		accountingTransactionService.deactivateAccountingTransaction(accountingTransaction);
	}

}
