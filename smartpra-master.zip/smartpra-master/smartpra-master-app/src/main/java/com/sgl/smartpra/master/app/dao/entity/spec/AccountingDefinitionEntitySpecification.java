package com.sgl.smartpra.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.AccountingDefinitionEntity;
import com.sgl.smartpra.master.app.dao.entity.AccountingTransactionEntity;

public class AccountingDefinitionEntitySpecification {

	public static Specification<AccountingDefinitionEntity> equalsAccountingAttributesMaster(
			String accountingAttributesMaster) {
		return (accountingDefinitionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingDefinitionEntity.get("accountingAttributesMaster"), accountingAttributesMaster);
	}
	
	public static Specification<AccountingDefinitionEntity> search(Optional<String> componentIdentifier,
			Optional<String> conversionDateUse) {
		return (accountingDefinitionEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(componentIdentifier)) {
				predicates.add(criteriaBuilder.like(accountingDefinitionEntity.get("componentIdentifier"),
						OptionalUtil.getValue(componentIdentifier) + "%"));
			}
			if (OptionalUtil.isPresent(conversionDateUse)) {
				predicates.add(criteriaBuilder.like(accountingDefinitionEntity.get("conversionDateUse"),
						OptionalUtil.getValue(conversionDateUse) + "%"));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
 
	public static Specification<AccountingDefinitionEntity> activate() {
		return (accountingDefinitionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingDefinitionEntity.get("activate"), true);
	}
	
	public static Specification<AccountingDefinitionEntity> searchWithIsActiveParam(Optional<String> componentIdentifier,
			Optional<String> conversionDateUse, Optional<Boolean> activate) {
		return (accountingDefinitionEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(componentIdentifier)) {
				predicates.add(criteriaBuilder.like(accountingDefinitionEntity.get("componentIdentifier"),
						OptionalUtil.getValue(componentIdentifier) + "%"));
			}
			if (OptionalUtil.isPresent(conversionDateUse)) {
				predicates.add(criteriaBuilder.like(accountingDefinitionEntity.get("conversionDateUse"),
						OptionalUtil.getValue(conversionDateUse) + "%"));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(accountingDefinitionEntity.get("activate"),
						OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(accountingDefinitionEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<AccountingDefinitionEntity> equalsClientId(String clientId) {
		return (accountingDefinitionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingDefinitionEntity.get("clientId"), clientId);
	}

	public static Specification<AccountingDefinitionEntity> equalsAccountCodeAlpha(String accountCodeAlpha) {
		return (accountingDefinitionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingDefinitionEntity.get("accountCodeAlpha"), accountCodeAlpha);
	}

	public static Specification<AccountingDefinitionEntity> equalsComponentIdentifier(String componentIdentifier) {
		return (accountingDefinitionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingDefinitionEntity.get("componentIdentifier"), componentIdentifier);
	}

	public static Specification<AccountingDefinitionEntity> equalsConversionDateUse(String conversionDateUse) {
		return (accountingDefinitionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(accountingDefinitionEntity.get("conversionDateUse"), conversionDateUse);
	}

	public static Specification<AccountingDefinitionEntity> notEqualsAccountDefinitionIdentifier(
			Integer accountDefinitionIdentifier) {
		return (accountingDefinitionEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(accountingDefinitionEntity.get("accountDefinitionIdentifier"), accountDefinitionIdentifier);
	}

}
