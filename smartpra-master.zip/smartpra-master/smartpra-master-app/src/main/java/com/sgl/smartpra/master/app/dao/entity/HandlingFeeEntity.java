package com.sgl.smartpra.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "mas_handling_fee")
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class HandlingFeeEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "handling_fee_id")
	private Integer handlingFeeId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "coupon_from_area")
	private String couponFromArea;

	@Column(name = "coupon_to_area")
	private String couponToArea;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Column(name = "hf_amount")
	private BigDecimal hfAmount;

	@Column(name = "hf_currency_code")
	private String hfCurrencyCode;

	@Column(name = "hf_percentage")
	private BigDecimal hfPercentage;

	@Column(name = "hf_type")
	private String hfType;

	@Column(name = "issue_cxr")
	private String issueCxr;

	@Column(name = "max_hf_amount")
	private BigDecimal maxHfAmount;

	@Column(name = "min_hf_amount")
	private BigDecimal minHfAmount;

	@Column(name = "operating_cxr")
	private String operatingCxr;

	@Column(name = "sales_source")
	private String salesSource;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
