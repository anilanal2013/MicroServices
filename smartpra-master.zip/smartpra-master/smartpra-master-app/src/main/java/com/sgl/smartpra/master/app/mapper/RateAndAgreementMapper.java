package com.sgl.smartpra.master.app.mapper;


import com.sgl.smartpra.master.app.dao.entity.RateAndAgreementEntity;
import com.sgl.smartpra.master.app.mapper.BaseMapper;
import com.sgl.smartpra.master.model.RateAndAgreementModel;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface RateAndAgreementMapper extends BaseMapper<RateAndAgreementModel, RateAndAgreementEntity> {

	RateAndAgreementEntity mapToEntity(RateAndAgreementModel rateAndAgreementModel);
	
    RateAndAgreementEntity mapToEntity(RateAndAgreementModel rateAndAgreementModel, @MappingTarget RateAndAgreementEntity rateAndAgreementEntity);
}
