package com.sgl.smartpra.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(schema = "SmartPRAMaster", name = "mas_agency_details")
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicUpdate
@DynamicInsert
public class AgencyDetailsEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "agency_dtl_id")
	private int agencyDetailsId;

	@Column(name = "agency_id")
	private Integer agencyId;

	@Column(name = "client_id", nullable = false, length = 2)
	private String clientId;

	@Column(name = "agency_code", nullable = false, length = 8)
	private String agencyCode;

	@Column(name = "transaction_type", nullable = false, length = 1)
	private String transactionType;

	@Column(name = "reporting_frequency", nullable = false, length = 2)
	private String reportingFrequency;

	@Column(name = "transaction_currency", nullable = false, length = 3)
	private String transactionCurrency;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;

	@Column(name = "reporting_type", length = 2)
	private String reportingType;

	@Column(name = "appl_doc_types", nullable = false, length = 3)
	private String applDocTypes;

	@Column(name = "commission_flag", nullable = false, length = 1)
	private String commissionFlag;

	@Column(name = "net_gross_flag", nullable = false, length = 1)
	private String netGrossFlag;

	@Column(name = "commission_percentage")
	private BigDecimal commissionPercentage;

	@Column(name = "profit_centre", nullable = false, length = 50)
	private String profitCentre;

	@Column(name = "cost_centre", length = 50)
	private String costCentre;

	@Column(name = "customer_code", length = 50)
	private String customerCode;

	@Column(name = "attribute_1", length = 50)
	private String attribute1;

	@Column(name = "attribute_2", length = 50)
	private String attribute2;

	@Column(name = "attribute_3", length = 50)
	private String attribute3;

	@Column(name = "attribute_4", length = 50)
	private String attribute4;

	@Column(name = "attribute_5", length = 50)
	private String attribute5;

	@Column(name = "ota_indicator")
	private String otaindicator;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
