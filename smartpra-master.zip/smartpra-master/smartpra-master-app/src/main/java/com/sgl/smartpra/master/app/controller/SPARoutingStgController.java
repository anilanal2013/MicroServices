package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.master.app.service.SPARoutingStgService;
import com.sgl.smartpra.master.model.SPARoutingStg;

@RestController
@RequestMapping("/spa/routing/stg")
public class SPARoutingStgController {
	
	@Autowired
	private SPARoutingStgService spaRoutingStgService;
	
	@GetMapping("/{spaRoutingId}")
	public SPARoutingStg getSPASectorBySpaSectorId(@PathVariable(value = "spaRoutingId") Integer spaRoutingId) {
		return spaRoutingStgService.findById(spaRoutingId);
	}

	@GetMapping("/{spaKey}/{spaMainId}/{clientId}")
	public List<SPARoutingStg> getSPASectorBySpaKey(@PathVariable(value = "spaKey") Optional<Integer> spaKey,
			@PathVariable(value = "spaMainId") Optional<Integer> spaMainId,
			@PathVariable(value = "clientId") Optional<String> clientId) {
		return spaRoutingStgService.findBySpaKeyMainIdClientId(spaKey, spaMainId, clientId);
	}
}
