package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.sgl.smartpra.master.model.BookingClassModel;

public interface BookingClassService {

	public BookingClassModel getBookingClassByBookingClassId(Integer bookingClassId);

	public List<BookingClassModel> getListOfBookingClassByUtilizationEffectiveDate(BookingClassModel bookingClassModel,
			Optional<String> exceptionCall);

	public BookingClassModel createBookingClassMaster(BookingClassModel bookingClassModel);

	public BookingClassModel updateBookingClassMaster(int bookingClassId, BookingClassModel bookingClassModel);

	public void deactivateBookingClassMaster(int bookingClassId, String lastUpdatedBy);

	public void activateBookingClassMaster(int bookingClassId, String lastUpdatedBy);

	public BookingClassModel getBookingClassByRBD(Optional<String> clientId, Optional<String> rbd,
			Optional<String> marketingCarrier, Optional<String> utilizationDate, Optional<String> salesDate);

	public Map<String, Set<String>> getListOfRDBFromCabin(String clientId, String salesDate, String utilizationDate);

	public List<String> getRbdByCabin(String cabin);

	public List<BookingClassModel> getListOfBookingClassByUtilizationEffectiveDate(
			Optional<String> utilizationEffectiveFromDate, Optional<String> utilizationEffectiveToDate,
			Optional<String> rbd, Optional<String> salesEffectiveFromDate, Optional<String> salesEffectiveToDate,
			Optional<String> cabin, Optional<String> marketingCarrier, Optional<String> fromAirport,
			Optional<String> toAirport);
}
