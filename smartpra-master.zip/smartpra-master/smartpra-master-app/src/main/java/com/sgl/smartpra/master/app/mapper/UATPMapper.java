package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.UATPEntity;
import com.sgl.smartpra.master.model.UATPModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface UATPMapper extends BaseMapper<UATPModel, UATPEntity> {

	UATPEntity mapToEntity(UATPModel uatpModel, @MappingTarget UATPEntity uatpEntity);

	@Mapping(source = "uatpId", target = "uatpId", ignore = true)
	UATPEntity mapToEntity(UATPModel uatpModel);
}
