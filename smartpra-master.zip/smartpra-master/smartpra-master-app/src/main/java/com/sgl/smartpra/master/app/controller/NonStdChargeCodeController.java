package com.sgl.smartpra.master.app.controller;

/**
 * @author kanprasa
 *
 */

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.NonStandardChargeCodeService;
import com.sgl.smartpra.master.model.NonStandardChargeCode;
import com.sgl.smartpra.master.model.NonStdChargeCategoryCodeModel;

@RestController
@RequestMapping("nonstd-charge-code")
public class NonStdChargeCodeController {

	@Autowired
	private NonStandardChargeCodeService nonStdChargeCodeService;
	
	@GetMapping("/id/{nonStdChargeCodeId}")
	public NonStandardChargeCode findNonStdChargeCategoryId(@PathVariable(value = "nonStdChargeCodeId", required = true) Integer nonStdChargeCodeId) {
		return nonStdChargeCodeService.findById(nonStdChargeCodeId);
	}

	@PostMapping("/create")
	public NonStandardChargeCode createNonStandardChargeCode(@Validated(Create.class) @RequestBody NonStandardChargeCode nonStdChargeCode) {
		return nonStdChargeCodeService.create(nonStdChargeCode);
	}

	@PutMapping("/update")
	public NonStandardChargeCode updateNonStandardChargeCategory(@Validated(Update.class) @RequestBody NonStandardChargeCode nonStdChargeCode) {
		return nonStdChargeCodeService.update(nonStdChargeCode);
	}

	@GetMapping("/search")
	public List<NonStandardChargeCode> searchNonStandardChargeCategory(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "nonStdCategoryCode", required = false) Optional<String> nonStdCategoryCode, 
			@RequestParam(value = "nonStdChargeCode", required = false) Optional<String> nonStdChargeCode, 
			@RequestParam(value = "stdChargeCode", required = false) Optional<String> stdChargeCode, 
			@RequestParam(value = "isActive", required = false) Optional<String> isActive) {
		return nonStdChargeCodeService.searchNonStandardChargeCode(clientId, nonStdCategoryCode, 
				nonStdChargeCode, stdChargeCode, isActive);
	}
	
	@GetMapping("/search-all")
	public NonStdChargeCategoryCodeModel searchAllNonStandardChargeCategory(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "nonStdCategoryCode", required = false) Optional<String> nonStdCategoryCode, 
			@RequestParam(value = "stdCategoryCode", required = false) Optional<String> stdCategoryCode,
			@RequestParam(value = "nonStdChargeCode", required = false) Optional<String> nonStdChargeCode, 
			@RequestParam(value = "stdChargeCode", required = false) Optional<String> stdChargeCode, 
			@RequestParam(value = "isActive", required = false) Optional<String> isActive) {
		return nonStdChargeCodeService.searchAllNonStandardChargeCode(clientId, nonStdCategoryCode, 
				stdCategoryCode, nonStdChargeCode, stdChargeCode, isActive);
	}

	@PutMapping("/activate")
	public String activateNonStandardChargeCategory(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "nonStdChargeCode", required = true) String nonStdChargeCode) {
		return nonStdChargeCodeService.activateNonStandardChargeCode(clientId, nonStdChargeCode);
	}

	@PutMapping("/de-activate")
	public String deActivateNonStandardChargeCategory(
			@RequestParam(value = "clientId", required = true) String clientId,
			@RequestParam(value = "nonStdChargeCode", required = true) String nonStdChargeCode) {
		return nonStdChargeCodeService.deActivateNonStandardChargeCode(clientId, nonStdChargeCode);
	}
}