package com.sgl.smartpra.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.CurrencyToleranceDetailsEntity;

@Repository
public interface CurrencyToleranceDetailsDao {

	CurrencyToleranceDetailsEntity createCurrencyTolerance(CurrencyToleranceDetailsEntity mapToEntity);

	Optional<CurrencyToleranceDetailsEntity> findById(Integer currencyToleranceDtlId);

	CurrencyToleranceDetailsEntity updateCurrencyTolerance(CurrencyToleranceDetailsEntity mapToEntity);

	List<CurrencyToleranceDetailsEntity> getListOfCurrencyTolerance(String currencyCode,
			String clientId, Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	long findOverLapRecord(Optional<String> clientId, Optional<String> currencyCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate);

	long findOverLapRecord(String clientId, String currencyCode, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			Integer currencyToleranceDtlId);

	CurrencyToleranceDetailsEntity getCurrencyToleranceByDate(String currencyCode, String clientId,
			Optional<String> effectiveFromDate);

}