package com.sgl.smartpra.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.master.app.repository.entity.OutwardBillingModuleEntity;
import com.sgl.smartpra.master.model.OutwardBillingModule;

@Mapper
public interface OutwardBillingModuleMapper {
	OutwardBillingModule mapToOutwardBillingModuleModel(OutwardBillingModuleEntity outwardBillingModule);

	List<OutwardBillingModule> mapToOutwardBillingModuleModellList(
			List<OutwardBillingModuleEntity> outwardBillingModuleEntities);

	OutwardBillingModuleEntity mapToOutwardBillingModuleEntity(OutwardBillingModule outwardBillingModule);

	List<OutwardBillingModuleEntity> mapToOutwardBillingModuleEntityList(
			List<OutwardBillingModule> OutwardBillingModuleList);
}
