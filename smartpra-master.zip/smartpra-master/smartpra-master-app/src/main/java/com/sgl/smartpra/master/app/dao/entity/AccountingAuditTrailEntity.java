package com.sgl.smartpra.master.app.dao.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.Length;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * @author nacsanth
 *
 */
@Entity
@Table(name="accounting_audit_trail")
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicUpdate
@DynamicInsert
public class AccountingAuditTrailEntity extends BaseEntity  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="accounting_audit_trail_id")
	private Integer accountingAuditTrailId;
	@Column(name="account_alpha_code",unique=true)
	@Length(min=1,max=3)
	private char accountAlphaCode;
	@Column(name="account_definition_identifier")
	private int accountDefinitionIdentifier;
	@Column(name="account_description")
	private String accountDescription;
	@Column(name="account_num_code")
	@Length(min=1,max=50)
	private String accountNumCode;
	@Column(name="account_type")
	private char accountType;
	@Column(name="accounting_attribute_1")
	private String accountingAttribute1;
	@Column(name="accounting_attribute_10")
	private String accountingAttribute10;
	@Column(name="accounting_attribute_11")
	private String accountingAttribute11;
	@Column(name="accounting_attribute_12")
	private String accountingAttribute12;
	@Column(name="accounting_attribute_13")
	private String accountingAttribute13;
	@Column(name="accounting_attribute_14")
	private String accountingAttribute14;
	@Column(name="accounting_attribute_15")
	private String accountingAttribute15;
	@Column(name="accounting_attribute_16")
	private String accountingAttribute16;
	@Column(name="accounting_attribute_17")
	private String accountingAttribute17;
	@Column(name="accounting_attribute_18")
	private String accountingAttribute18;
	@Column(name="accounting_attribute_19")
	private String accountingAttribute19;
	@Column(name="accounting_attribute_2")
	private String accountingAttribute2;
	@Column(name="accounting_attribute_20")
	private String accountingAttribute20;
	@Column(name="accounting_attribute_3")
	private String accountingAttribute3;
	@Column(name="accounting_attribute_4")
	private String accountingAttribute4;
	@Column(name="accounting_attribute_5")
	private String accountingAttribute5;
	@Column(name="accounting_attribute_6")
	private String accountingAttribute6;
	@Column(name="accounting_attribute_7")
	private String accountingAttribute7;
	@Column(name="accounting_attribute_8")
	private String accountingAttribute8;
	@Column(name="accounting_attribute_9")
	private String accountingAttribute9;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="accounting_date")
	private Date accountingDate;
	@Column(name="base_currency")
	private char baseCurrency;
	@Column(name="batch_key1")
	private String batchKey1;
	@Column(name="batch_key2")
	private String batchKey2;
	@Column(name="batch_key3")
	private String batchKey3;
	@Column(name="batch_key4")
	private String batchKey4;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="batch_key5")
	private Date batchKey5;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="batch_key6")
	private Date batchKey6;
	@Column(name="client_id",unique=true)
	@Length(min=1,max=2)
	private char clientId;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="conv_date_reporting_currency")
	private Date convDateReportingCurrency;
	@Column(name="conv_rate_reporting_currency")
	private BigDecimal convRateReportingCurrency;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="conversion_date")
	private Date conversionDate;
	@Column(name="conversion_rate")
	private BigDecimal conversionRate;
	@Column(name="coupon_number",unique=true)
	private Integer couponNumber;
	@Column(name="cr_amt_in_reporting_currency")
	private BigDecimal crAmtInReportingCurrency;
	@Column(name="cr_amt_in_transaction_currency")
	private BigDecimal crAmtInTransactionCurrency;
	@Column(name="credit_amount_in_base_currency")
	private BigDecimal creditAmountInBaseCurrency;
	@Column(name="date_of_issue")
	@Temporal(TemporalType.DATE)
	private Date dateOfIssue;
	@Column(name="debit_amount_in_base_currency")
	private BigDecimal debitAmountInBaseCurrency;
	@Column(name="doc_type")
	@Length(max=3)
	private char docType;
	@Column(name="document_unique_id")
	@Length(max=33)
	private String documentUniqueId;
	@Column(name="dr_amt_in_reporting_currency")
	private BigDecimal drAmtInReportingCurrency;
	@Column(name="dr_amt_in_transaction_currency")
	private BigDecimal drAmtInTransactionCurrency;
	@Column(name="erp_response_number")
	private String erpResponseNumber;
	@Column(name="fin_year")
	@Length(min=1,max=5, message="Financial year is mandatory")
	private String finYear;
	@Column(name="gl_summarisation_no")
	private String glSummarisationNo;
	@Column(name="jv_number")
	@Length(min=1,max=10,message="JV number is mandatory")
	private String jvNumber;
	@Column(name="main_doc_number",unique=true)
	@Length(max=20)
	private String mainDocNumber;
	@Column(name="main_iss_airline",unique=true)
	@Length(max=3)
	private char mainIssAirline;
	@Column(name="memo_no")
	private String memoNo;
	@Column(name="lov_module_id",unique=true)
	@NotNull(message="Module Id is mandatory")
	private Integer moduleId;
	@Column(name="month_closed_date")
	@NotNull(message="Month close date is mandatory")
	@Temporal(TemporalType.TIMESTAMP)
	private Date monthClosedDate;
	@Column(name="narration")
	private String narration;
	@Column(name="order_id")
	@Length(max=20)
	private String orderId;
	@Length(max=13)
	private String pnr;
	@Column(name="ref_document_number",unique=true)
	@Length(max=20)
	private String refDocumentNumber;
	@Column(name="ref_issuing_carrier",unique=true)
	@Length(max=3)
	private char refIssuingCarrier;
	@Column(name="reporting_currency")
	@Length(max=3,message="Reporting currency is mandatory")
	private char reportingCurrency;
	@Length(min=1,message="Reversal_indicator is mandatory")
	@Column(name="reversal_indicator")
	private char reversalIndicator;
	@Column(name="scenario_number")
	private int scenarioNumber;
	@Column(name="trans_doc_number",unique=true)
	@Length(max=20)
	private String transDocNumber;
	@Column(name="trans_iss_airline",unique=true)
	@Length(max=3)
	private char transIssAirline;
	@Column(name="transaction_currency")
	@Length(min=1,max=3,message="transactionCurrency is mandatory")
	private char transactionCurrency;
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
	

}