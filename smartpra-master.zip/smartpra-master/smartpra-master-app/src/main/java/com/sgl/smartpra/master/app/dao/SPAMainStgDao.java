package com.sgl.smartpra.master.app.dao;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.SPAMainStgEntity;
@Repository
public interface SPAMainStgDao {
	Optional<SPAMainStgEntity> findById(Integer spaMainId);
	List<SPAMainStgEntity> findBySpaKey(Optional<Integer> spaKey);
	List<SPAMainStgEntity> findAllMainDataBySpaMainId(Optional<Integer> spaMainId);
	List<SPAMainStgEntity> findBySpaKeyAndClientId(Optional<Integer> spaKey, Optional<String> clientId);
}

