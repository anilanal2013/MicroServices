package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.CreditCardEntity;
import com.sgl.smartpra.master.model.CreditCard;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CreditCardMapper extends BaseMapper<CreditCard, CreditCardEntity> {

	CreditCardEntity mapToEntity(CreditCard creditCard, @MappingTarget CreditCardEntity creditCardEntity);

	@Mapping(source = "creditCardId", target = "creditCardId", ignore = true)
	CreditCardEntity mapToEntity(CreditCard creditCard);
}
