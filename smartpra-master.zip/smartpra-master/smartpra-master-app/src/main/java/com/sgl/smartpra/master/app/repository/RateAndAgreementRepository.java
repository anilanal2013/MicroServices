package com.sgl.smartpra.master.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sgl.smartpra.master.app.dao.entity.RateAndAgreementEntity;

public interface RateAndAgreementRepository extends JpaRepository<RateAndAgreementEntity,Integer>, JpaSpecificationExecutor<RateAndAgreementEntity> {
}
