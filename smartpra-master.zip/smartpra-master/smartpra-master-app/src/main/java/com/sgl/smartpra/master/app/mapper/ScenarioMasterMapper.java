package com.sgl.smartpra.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.MasScenarioEntity;
import com.sgl.smartpra.master.model.MasScenarioModel;
@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ScenarioMasterMapper extends BaseMapper<MasScenarioModel, MasScenarioEntity> {
	
	List<MasScenarioModel> mapToModel(List<MasScenarioEntity> masScenarioEntity);
	MasScenarioEntity mapToEntity(MasScenarioModel masScenarioModel, @MappingTarget MasScenarioEntity masScenarioEntity);
	
	@Mapping(source = "scenarioNumber", target = "scenarioNumber", ignore = true)
	MasScenarioEntity mapToEntity(MasScenarioModel masScenarioModel);
	
}

