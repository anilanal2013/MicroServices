package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.BookingClassDao;
import com.sgl.smartpra.master.app.dao.entity.BookingClassEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.BookingClassEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.BookingClassRepository;
import com.sgl.smartpra.master.model.BookingClassModel;

@Repository
public class BookingClassDaoImpl implements BookingClassDao {

	@Autowired
	private BookingClassRepository bookingClassRepository;

	@Override
	@Cacheable(value = "bookingClass", key = "#id")
	public Optional<BookingClassEntity> findById(Integer id) {
		return bookingClassRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "bookingClass", key = "#bookingClassEntity.bookingClassId"),
			@CacheEvict(value = "clientId", allEntries = true), @CacheEvict(value = "rbd", allEntries = true),
			@CacheEvict(value = "marketingCarrier", allEntries = true),
			@CacheEvict(value = "utilizationDate", allEntries = true),
			@CacheEvict(value = "salesDate", allEntries = true) })
	public BookingClassEntity create(BookingClassEntity bookingClassEntity) {
		return bookingClassRepository.save(bookingClassEntity);
	}

	@Override
	@CachePut(value = "bookingClass", key = "#bookingClassEntity.bookingClassId")
	@Caching(evict = { @CacheEvict(value = "clientId", allEntries = true),
			@CacheEvict(value = "rbd", allEntries = true), @CacheEvict(value = "marketingCarrier", allEntries = true),
			@CacheEvict(value = "utilizationDate", allEntries = true),
			@CacheEvict(value = "salesDate", allEntries = true) })
	public BookingClassEntity update(BookingClassEntity bookingClassEntity) {
		return bookingClassRepository.save(bookingClassEntity);
	}

	@Override
	public void delete(Integer id) {
		bookingClassRepository.deleteById(id);
	}

	@Override
	public long getOverlapRecordCount(String rbd, String marketingCarrier, LocalDate utilEffectiveFromDate,
			LocalDate utilEffectiveToDate, LocalDate salesEffectiveFromDate, LocalDate salesEffectiveToDate) {
		if (salesEffectiveFromDate != null && salesEffectiveToDate != null) {
			return bookingClassRepository.count(Specification.where(BookingClassEntitySpecification
					.equalsMarktingCarrier(marketingCarrier).and(BookingClassEntitySpecification.equalsRbd(rbd))

					.and(BookingClassEntitySpecification
							.betweenUtilEffectiveFromAndUtilEffectiveToDate(utilEffectiveFromDate)
							.or(BookingClassEntitySpecification
									.betweenUtilEffectiveFromAndUtilEffectiveToDate(utilEffectiveToDate)))
					.and(BookingClassEntitySpecification
							.betweenSalesEffectiveFromAndSalesEffectiveToDate(salesEffectiveFromDate)
							.or(BookingClassEntitySpecification
									.betweenSalesEffectiveFromAndSalesEffectiveToDate(salesEffectiveFromDate)))));
		}
		return bookingClassRepository.count(Specification.where(BookingClassEntitySpecification
				.equalsMarktingCarrier(marketingCarrier).and(BookingClassEntitySpecification.equalsRbd(rbd))
				.and(BookingClassEntitySpecification
						.betweenUtilEffectiveFromAndUtilEffectiveToDate(utilEffectiveFromDate)
						.or(BookingClassEntitySpecification
								.betweenUtilEffectiveFromAndUtilEffectiveToDate(utilEffectiveToDate)))));
	}

	@Override
	public long getOverlapRecordCount(String rbd, String marketingCarrier, LocalDate utilEffectiveFromDate,
			LocalDate utilEffectiveToDate, LocalDate salesEffectiveFromDate, LocalDate salesEffectiveToDate,
			Integer bookingClassId) {
		return bookingClassRepository.count(Specification.where(BookingClassEntitySpecification
				.equalsMarktingCarrier(marketingCarrier).and(BookingClassEntitySpecification.equalsRbd(rbd))
				.and(BookingClassEntitySpecification
						.betweenSalesEffectiveFromAndSalesEffectiveToDate(salesEffectiveFromDate)
						.or(BookingClassEntitySpecification
								.betweenSalesEffectiveFromAndSalesEffectiveToDate(salesEffectiveFromDate)))
				.and(BookingClassEntitySpecification
						.betweenUtilEffectiveFromAndUtilEffectiveToDate(utilEffectiveFromDate)
						.or(BookingClassEntitySpecification
								.betweenUtilEffectiveFromAndUtilEffectiveToDate(utilEffectiveToDate)))
				.and(BookingClassEntitySpecification.notEqualsbookingClassId(bookingClassId))));
	}

	@Override
	public List<BookingClassEntity> search(BookingClassModel bookingClassModel, Optional<String> exceptionCall) {
		return bookingClassRepository.findAll(BookingClassEntitySpecification.search(bookingClassModel, exceptionCall));
	}

	@Override
	@Cacheable(cacheNames = { "clientId", "rbd", "marketingCarrier", "utilizationDate", "salesDate" })
	public Optional<BookingClassEntity> getBookingClassByRBD(Optional<String> clientId, Optional<String> rbd,
			Optional<String> marketingCarrier, Optional<String> utilizationDate, Optional<String> salesDate) {
		return bookingClassRepository.findOne(BookingClassEntitySpecification
				.equalsClientId(OptionalUtil.getValue(clientId))
				.and(BookingClassEntitySpecification.equalsRbd(OptionalUtil.getValue(rbd)))
				.and(BookingClassEntitySpecification.equalsMarktingCarrier(OptionalUtil.getValue(marketingCarrier)))
				.and(BookingClassEntitySpecification.betweenUtilEffectiveFromAndUtilEffectiveToDate(
						OptionalUtil.getLocalDateValue(utilizationDate)))
				.and(BookingClassEntitySpecification
						.betweenSalesEffectiveFromAndSalesEffectiveToDate(OptionalUtil.getLocalDateValue(salesDate)))
				.and(BookingClassEntitySpecification.equalsActive()));
	}

	@Override
	@Cacheable(cacheNames = { "clientId", "salesDate", "utilizationDate" })
	public List<BookingClassEntity> getCabinWithRBDS(String clientId, LocalDate salesDate, LocalDate utilizationDate) {

		return bookingClassRepository.findAll(BookingClassEntitySpecification.equalsClientId(clientId)
				.and(BookingClassEntitySpecification.betweenUtilEffectiveFromAndUtilEffectiveToDate(utilizationDate))
				.and(BookingClassEntitySpecification.betweenSalesEffectiveFromAndSalesEffectiveToDate(salesDate))
				.and(BookingClassEntitySpecification.equalsActive()));
	}

	@Override
	public List<String> getRbdByCabin(String cabin) {
		return bookingClassRepository.getRbdByCabin(cabin);
	}

}
