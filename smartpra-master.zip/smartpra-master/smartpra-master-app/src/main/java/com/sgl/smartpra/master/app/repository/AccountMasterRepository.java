package com.sgl.smartpra.master.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.MasAccountEntity;
@Repository
public interface AccountMasterRepository extends JpaRepository<MasAccountEntity, Integer>, JpaSpecificationExecutor<MasAccountEntity> {

	List<MasAccountEntity> findAllByAccountAlphaCode(String byAccountAlphaCode);
}
