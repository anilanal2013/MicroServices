package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.ProrationHighLowQcService;
import com.sgl.smartpra.master.model.ProrationHighLowQc;
import com.sgl.smartpra.master.model.ProrationHighLowQcRes;

@RestController
public class ProrationHighLowQcController {

	@Autowired
	private ProrationHighLowQcService prorationHighLowQcService;

	@GetMapping(value = "/proration-high-low-qc/clientId/{clientId}")
	public List<ProrationHighLowQc> getAllProrationHighLowQc(
			@PathVariable(value = "clientId") Optional<String> clientId, 
			@RequestParam(name = "highLowId") Optional<String> highLowId,
			@RequestParam(name = "qcField") Optional<String> qcField,
			@RequestParam(name = "taxCode") Optional<String> taxCode,
			@RequestParam(name = "effectiveFromDate") @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(name = "effectiveToDate") @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(name = "couponCxrType") Optional<String> couponCxrType,
			@RequestParam(name = "couponCxrList") Optional<String> couponCxrList,
			@RequestParam(name = "issueCxrType") Optional<String> issueCxrType,
			@RequestParam(name = "issueCxrList") Optional<String> issueCxrList) {
		
		ProrationHighLowQc prorationHighLowQc = new ProrationHighLowQc();
		prorationHighLowQc.setHighLowId(highLowId);
		prorationHighLowQc.setQcField(qcField);
		prorationHighLowQc.setTaxCode(taxCode);
		prorationHighLowQc.setEffectiveFromDate(effectiveFromDate);
		prorationHighLowQc.setEffectiveToDate(effectiveToDate);
		prorationHighLowQc.setCouponCxrType(couponCxrType);
		prorationHighLowQc.setCouponCxrList(couponCxrList);
		prorationHighLowQc.setIssueCxrType(issueCxrType);
		prorationHighLowQc.setIssueCxrList(issueCxrList);
		return prorationHighLowQcService.getAllProrationHighLowQc(clientId, prorationHighLowQc);
	}

	@GetMapping(value = "/proration-high-low-qc/{highLowQcId}")
	public ProrationHighLowQc getProrationHighLowIdById(@PathVariable(name = "highLowQcId") Integer highLowQcId) {

		return prorationHighLowQcService.getProrationHighLowIdById(highLowQcId);
	}

	@PostMapping(value = "/proration-high-low-qc")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProrationHighLowQc createProrationHighLowQc(
			@Validated(Create.class) @RequestBody ProrationHighLowQc prorationHighLowQc) {

		return prorationHighLowQcService.createProrationHighLowQc(prorationHighLowQc);
	}

	@PutMapping(value = "/proration-high-low-qc/{prorationHighLowQcId}")
	@ResponseStatus(value = HttpStatus.OK)
	public ProrationHighLowQc updateProrationHighLowQc(
			@PathVariable(value = "prorationHighLowQcId") Integer prorationHighLowQcId,
			@Validated(Update.class) @RequestBody ProrationHighLowQc prorationHighLowQc) {

		return prorationHighLowQcService.updateProrationHighLowQc(prorationHighLowQcId, prorationHighLowQc);
	}

	@GetMapping(value = "/proration-high-low-qc/list")
	public ProrationHighLowQcRes getAllProrationHighLowQc(Pageable pageable,
			@RequestParam(name = "highLowId") Optional<String> highLowId,
			@RequestParam(name = "qcField") Optional<String> qcField,
			@RequestParam(name = "taxCode") Optional<String> taxCode,
			@RequestParam(name = "effectiveFromDate") @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(name = "effectiveToDate") @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {

		ProrationHighLowQc prorationHighLowQc = new ProrationHighLowQc();
		prorationHighLowQc.setHighLowId(highLowId);
		prorationHighLowQc.setQcField(qcField);
		prorationHighLowQc.setTaxCode(taxCode);
		if (OptionalUtil.isPresent(effectiveFromDate)) {
			prorationHighLowQc.setEffectiveFromDate(effectiveFromDate);
		}
		if (OptionalUtil.isPresent(effectiveToDate)) {
			prorationHighLowQc.setEffectiveToDate(effectiveToDate);
		}

		return prorationHighLowQcService.getAllProrationHighLowQc(pageable, prorationHighLowQc);
	}
	
	//proration call
	@GetMapping(value = "/proration-high-low-qc/proration")
	public List<ProrationHighLowQc> getAllProrationHighLowQcProcessing(
			@RequestParam(name = "date") @DateFormat(pattern = "yyyy-MM-dd") Optional<String> date) {
		return prorationHighLowQcService.getAllProrationHighLowQcProcessing(date);
	}
	
	
}
