package com.sgl.smartpra.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the mas_customer database table.
 * 
 */
@Entity
@Table(name = "mas_customer")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class CustomerEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "customer_mas_id")
	private Integer customerMasId;

	@Column(name = "customer_code", nullable = false)
	private String customerCode;

	@Column(name = "client_id", nullable = false)
	private String clientId;

	@Column(name = "customer_name", nullable = true)
	private String customerName;

	@Column(name = "customer_type", nullable = false)
	private String customerType;

	@Column(name = "fop_code", nullable = true)
	private String fopCode;

	@Column(name = "sub_fop_code", nullable = true)
	private String subFopCode;

	@Column(name = "lpo_number", nullable = true)
	private String lpoNumber;

	@Column(name = "debtor_code", nullable = true)
	private String debtorCode;

	@Column(name = "legal_name", nullable = true)
	private String legalName;

	@Column(name = "billing_address1", nullable = true)
	private String billingAddress1;

	@Column(name = "billing_address2", nullable = true)
	private String billingAddress2;

	@Column(name = "billing_address3", nullable = true)
	private String billingAddress3;

	@Column(name = "billing_address4", nullable = true)
	private String billingAddress4;

	@Column(name = "phone_number", nullable = true)
	private String phoneNumber;

	@Column(name = "fax_number", nullable = true)
	private String faxNumber;

	@Column(name = "city_code", nullable = true)
	private String cityCode;

	@Column(name = "email", nullable = true)
	private String email;

	@Column(name = "currency_of_invoice", nullable = true)
	private String currencyOfInvoice;

	@Column(name = "company_code", nullable = true)
	private String companyCode;

	@Column(name = "credit_limit", nullable = true, scale = 16, precision = 3)
	private BigDecimal creditLimit;

	@Column(name = "tax_code", nullable = true)
	private String taxCode;

	@Column(name = "govt_applicable", nullable = true)
	private String govtApplicable;

	@Column(name = "language", nullable = true)
	private String language;

	@Column(name = "tax_gst_registration_no", nullable = true)
	private String taxGstRegistrationNo;

	@Column(name = "vat_exempt_no", nullable = true)
	private String vatExemptNo;

	@Column(name = "cc_agreement_reference", nullable = true)
	private String ccAgreementReference;

	@Column(name = "billing_frequency", nullable = true)
	private String billingFrequency;

	@Column(name = "settlement_due_date", nullable = true)
	private Integer settlementDueDate;

	@Column(name = "financial_doc_type", nullable = true)
	private String financialDocType;

	@Column(name = "invoice_by_email", nullable = true)
	private String invoiceByEmail;

	@Column(name = "account_code", nullable = true)
	private String accountCode;

	@Column(name = "profit_centre", nullable = true)
	private String profitCentre;

	@Column(name = "cost_centre", nullable = true)
	private String costCentre;

	@Column(name = "attribute_1", nullable = true)
	private String attribute1;

	@Column(name = "attribute_2", nullable = true)
	private String attribute2;

	@Column(name = "attribute_3", nullable = true)
	private String attribute3;

	@Column(name = "attribute_4", nullable = true)
	private String attribute4;

	@Column(name = "attribute_5", nullable = true)
	private String attribute5;

	@Column(name = "is_active", nullable = false)
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@Column(name = "agency_code")
	private String agencyCode;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
