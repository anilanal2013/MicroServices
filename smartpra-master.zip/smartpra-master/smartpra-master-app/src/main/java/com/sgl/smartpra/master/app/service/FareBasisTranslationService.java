package com.sgl.smartpra.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.master.model.FareBasisTranslation;

public interface FareBasisTranslationService {
	public FareBasisTranslation createFareBasisTranslation(FareBasisTranslation fareBasisTranslation);

	public FareBasisTranslation getFareBasisTranslationByFbtId(Integer fbtId);

	public FareBasisTranslation updateFareBasisTranslation(Integer fbtId, FareBasisTranslation fareBasisTranslation);

	public void deactivateFareBasisTranslation(Integer fbtId, String lastUpdatedBy);

	public void activateFareBasisTranslation(Integer fbtId, String lastUpdatedBy);
	
	public List<FareBasisTranslation> getFBTIsPattern();

	List<FareBasisTranslation> getFareBasisTranslation(Optional<String> marketingFareBasis,
			Optional<String> marketingTD, Optional<String> fareOwnerCXR, Optional<String> effectiveDate);

	List<FareBasisTranslation> getFareBasisTranslation(Optional<String> marketingFareBasis,
			Optional<String> marketingTD, Optional<String> effectiveDate);

	public List<FareBasisTranslation> getAllfbtMasterSpecificClient(Optional<String> marketingFareBasis,
			Optional<String> marketingTD, Optional<String> clientId, Optional<String> effectiveDate);

}
