package com.sgl.smartpra.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@Table(name = "mas_proration_high_low_qc")
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class ProrationHighLowQcEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "low_high_qc_id")
	private int lowHighQcId;

	@Column(name = "apply_discount")
	private String applyDiscount;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "coupon_cxr_list")
	private String couponCxrList;

	@Column(name = "coupon_cxr_list_flag")
	private String couponCxrListFlag;

	@Column(name = "coupon_cxr_type")
	private String couponCxrType;

	@Column(name = "coupon_from_area")
	private String couponFromArea;

	@Column(name = "coupon_to_area")
	private String couponToArea;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Column(name = "exclude_coupons")
	private String excludeCoupons;

	@Column(name = "exclude_fb_group_code")
	private String excludeFbGroupCode;

	@Column(name = "exclude_tickets")
	private String excludeTickets;

	@Column(name = "high_low_currency_code")
	private String highLowCurrencyCode;

	@Column(name = "high_low_id")
	private String highLowId;

	@Column(name = "high_value")
	private Double highValue;

	@Column(name = "include_fb_group_code")
	private String includeFbGroupCode;

	@Column(name = "issue_cxr_list")
	private String issueCxrList;

	@Column(name = "issue_cxr_list_flag")
	private String issueCxrListFlag;

	@Column(name = "issue_cxr_type")
	private String issueCxrType;

	@Column(name = "low_value")
	private Double lowValue;

	@Column(name = "priority")
	private int priority;

	@Column(name = "qc_field")
	private String qcField;

	@Column(name = "tax_code")
	private String taxCode;

	@Column(name = "violation_action")
	private String violationAction;

	@Column(name = "vv_flag")
	private String vvFlag;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
