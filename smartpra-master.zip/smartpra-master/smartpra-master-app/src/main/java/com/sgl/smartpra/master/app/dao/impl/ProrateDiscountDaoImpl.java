package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.master.app.dao.ProrateDiscountDao;
import com.sgl.smartpra.master.app.dao.entity.ProrateDiscountEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.ProrateDiscountEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.ProrateDiscountRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProrateDiscountDaoImpl implements ProrateDiscountDao {

	@Autowired
	private ProrateDiscountRepository prorateDiscountRepository;

	@Override
	public List<ProrateDiscountEntity> getProrateDiscountByEffectiveDate(String discountCode,
			Optional<String> effectiveDate) {

		return prorateDiscountRepository.findAll(ProrateDiscountEntitySpecification.search(discountCode, effectiveDate)
				.and(ProrateDiscountEntitySpecification.isActive()));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "prorateDiscount", key = "#prorateDiscountEntity.prorateDiscountId") })
	public ProrateDiscountEntity create(ProrateDiscountEntity prorateDiscountEntity) {

		return prorateDiscountRepository.save(prorateDiscountEntity);
	}

	@Override
	@Cacheable(value = "prorateDiscount", key = "#prorateDiscountId")
	public Optional<ProrateDiscountEntity> findById(Integer prorateDiscountId) {

		log.info("Cacheable Prorate Discount Entity's ID= {}", prorateDiscountId);
		return prorateDiscountRepository.findById(prorateDiscountId);
	}

	@Override
	public int verifyIfOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate) {

		return (int) prorateDiscountRepository.count(Specification
				.where(ProrateDiscountEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProrateDiscountEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(ProrateDiscountEntitySpecification.isActive())));
	}

	@Override
	@CachePut(value = "prorateDiscount", key = "#prorateDiscountEntity.prorateDiscountId")
	public ProrateDiscountEntity update(ProrateDiscountEntity prorateDiscountEntity) {
		return prorateDiscountRepository.save(prorateDiscountEntity);
	}

	@Override
	public List<ProrateDiscountEntity> getProrateDiscountByEffectiveDateDiscountType(String discountCode,
			LocalDate effectiveDate, String discountType, String clientId) {

		return prorateDiscountRepository.findAll(ProrateDiscountEntitySpecification
				.searchByCodeDateType(discountCode, effectiveDate, discountType, clientId)
				.and(ProrateDiscountEntitySpecification.isActive()));
	}

	@Override
	public List<ProrateDiscountEntity> searchProrateDiscount(String discountCode, String discountType,
			Optional<String> fbGroupCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> cxr) {

		return prorateDiscountRepository.findAll(ProrateDiscountEntitySpecification.searchProrateDiscount(discountCode,
				discountType, fbGroupCode, effectiveFromDate, effectiveToDate, cxr));
	}

	@Override
	public long getOverlapRecordCount(String discountCode, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String clientId, String fbGroupCode, String cxr, String areaFBWIndicator, String fromArea, String toArea) {

		return prorateDiscountRepository.count(Specification.where(ProrateDiscountEntitySpecification
				.equalsDiscountCode(discountCode)
				.and(ProrateDiscountEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProrateDiscountEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(ProrateDiscountEntitySpecification.equalsClientId(clientId))
				.and(ProrateDiscountEntitySpecification.equalsFbGroupCode(fbGroupCode))
				.and(ProrateDiscountEntitySpecification.equalsCxr(cxr))
				.and(ProrateDiscountEntitySpecification.equalsAreaFBWIndicator(areaFBWIndicator))
				.and(ProrateDiscountEntitySpecification.equalsFromArea(fromArea))
				.and(ProrateDiscountEntitySpecification.equalsToArea(toArea))));
	}

	@Override
	public long getOverlapRecordCount(String discountCode, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String clientId, String fbGroupCode, String cxr, String areaFBWIndicator, String fromArea, String toArea,
			Integer prorateDiscountId) {

		return prorateDiscountRepository.count(Specification.where(ProrateDiscountEntitySpecification
				.equalsDiscountCode(discountCode)
				.and(ProrateDiscountEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProrateDiscountEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(ProrateDiscountEntitySpecification.equalsClientId(clientId))
				.and(ProrateDiscountEntitySpecification.equalsFbGroupCode(fbGroupCode))
				.and(ProrateDiscountEntitySpecification.equalsCxr(cxr))
				.and(ProrateDiscountEntitySpecification.equalsAreaFBWIndicator(areaFBWIndicator))
				.and(ProrateDiscountEntitySpecification.equalsFromArea(fromArea))
				.and(ProrateDiscountEntitySpecification.equalsToArea(toArea))
				.and(ProrateDiscountEntitySpecification.notEqualsProrateDiscountId(prorateDiscountId))));
	}

}
