package com.sgl.smartpra.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.SourceCodeEntity;
import com.sgl.smartpra.master.model.SourceCode;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SourceCodeMapper extends BaseMapper<SourceCode, SourceCodeEntity> {
	
	SourceCodeEntity mapToEntity(SourceCode sourceCode, @MappingTarget SourceCodeEntity sourceCodeEntity);

	@Mapping(source = "sourceCodeId", target = "sourceCodeId", ignore = true)
	SourceCodeEntity mapToEntity(SourceCode sourceCode);
}
