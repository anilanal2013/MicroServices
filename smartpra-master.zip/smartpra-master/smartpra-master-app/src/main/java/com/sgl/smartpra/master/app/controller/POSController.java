package com.sgl.smartpra.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.master.app.service.POSService;
import com.sgl.smartpra.master.model.POS;

@RestController
public class POSController {

	@Autowired
	private POSService posService;

	@GetMapping("/pos")
	public List<POS> getAllpos(@RequestParam(value = "posCode", required = false) Optional<String> posCode,
			@RequestParam(value = "posName", required = false) Optional<String> posName,
			@RequestParam(value = "accountCode", required = false) Optional<String> accountCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {
		return posService.getAllPOS(Optional.of("QR"),posCode, posName, accountCode, effectiveFromDate, effectiveToDate);
	}
	
	@GetMapping("/pos/search/clientid/{clientId}")
	public List<POS> getAllpos(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@RequestParam(value = "posCode", required = false) Optional<String> posCode,
			@RequestParam(value = "posName", required = false) Optional<String> posName,
			@RequestParam(value = "accountCode", required = false) Optional<String> accountCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate) {
		return posService.getAllPOS(clientId,posCode, posName, accountCode, effectiveFromDate, effectiveToDate);
	}

	@GetMapping("/pos/{posId}")
	public POS getPosByPosId(@PathVariable(value = "posId") Integer posId) {
		return posService.findPOSByPOSCode(posId);
	}

	@PostMapping("/pos")
	public POS createPos(@Validated(Create.class) @RequestBody POS pos) {
		return posService.createPOS(pos);
	}

	@PutMapping("/pos/{posId}")
	public POS updatePos(@PathVariable(value = "posId") Integer posId, @Validated(Update.class) @RequestBody POS pos) {
		return posService.updatePOS(posId, pos);
	}

}
