package com.sgl.smartpra.master.app.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.master.app.service.FlightRangeService;
import com.sgl.smartpra.master.model.FlightRange;

@RestController
public class FlightRangeController {

	@Autowired
	private FlightRangeService flightRangeService;

	@PostMapping("/flightRange")
	public FlightRange createFlightRange(@Validated(Create.class) @RequestBody FlightRange flightRange) {
		FlightRange createFlightRange = null;
		try {
			createFlightRange = flightRangeService.createFlightRange(flightRange);
		} catch (DataIntegrityViolationException e) {

			throw new BusinessException("Record already exists");
		}

		return createFlightRange;
	}

	@PutMapping("/flightRange/{flightRangeAutoId}")
	public FlightRange updateFlightRange(@PathVariable(value = "flightRangeAutoId") Integer flightRangeAutoId,
			@Validated(Update.class) @RequestBody FlightRange flightRange) {

		FlightRange updateFlightRange = null;

		try {
			updateFlightRange = flightRangeService.updateFlightRange(flightRangeAutoId, flightRange);
		} catch (DataIntegrityViolationException e) {

			throw new BusinessException("Record already exists");
		}
		return updateFlightRange;
	}

	@PutMapping("/flightRange/{flightRangeAutoId}/deactivate")
	public void deactivateFlightRange(@Valid @PathVariable(value = "flightRangeAutoId") Integer flightRangeAutoId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		FlightRange flightRange = new FlightRange();
		flightRange.setFlightRangeAutoId(flightRangeAutoId);
		flightRange.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		flightRangeService.deactivateFlightRange(flightRange);
	}

	@PutMapping("/flightRange/{flightRangeAutoId}/activate")
	public void activateFlightRange(@Valid @PathVariable(value = "flightRangeAutoId") Integer flightRangeAutoId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		FlightRange flightRange = new FlightRange();
		flightRange.setFlightRangeAutoId(flightRangeAutoId);
		flightRange.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		flightRangeService.activateFlightRange(flightRange);
	}

	@GetMapping("/flightRange")
	public List<FlightRange> getAllFlightRange(
			@RequestParam(value = "flightRangeId", required = false) Optional<String> flightRangeId,
			@RequestParam(value = "isMarketingOperating", required = false) Optional<String> isMarketingOperating,
			@RequestParam(value = "cxrCode", required = false) Optional<String> cxrCode,
			@RequestParam(value = "fromFlightNumber", required = false) Optional<String> flightNumber,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return flightRangeService.getAllFlightRange(flightRangeId, isMarketingOperating, cxrCode, flightNumber,
				activate);
	}

	@GetMapping("/flightRange/{flightRangeAutoId}")
	public FlightRange getFlightRangeByFlightRangeAutoId(
			@PathVariable(value = "flightRangeAutoId") Integer flightRangeAutoId) {
		return flightRangeService.getFlightRangeByFlightRangeAutoId(flightRangeAutoId);
	}

	@GetMapping("/flightRange/search/{flightRangeId}/{isMarketingOperating}/{cxrCode}/{flightNumber}")
	public List<FlightRange> getAllFlightRangeBySearch(
			@PathVariable(value = "flightRangeId", required = true) String flightRangeId,
			@PathVariable(value = "isMarketingOperating", required = true) String isMarketingOperating,
			@PathVariable(value = "cxrCode", required = true) String cxrCode,
			@PathVariable(value = "flightNumber", required = true) String flightNumber,
			@RequestParam(value = "saleDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate saleDate,
			@RequestParam(value = "travelDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate travelDate) {
		return flightRangeService.getFlightRangeBySearch(flightRangeId, isMarketingOperating, cxrCode, flightNumber,
				saleDate, travelDate);
	}

	@GetMapping("/flightRange/validate-issuedate")
	public List<FlightRange> valiadateIssueDate(
			@RequestParam(value = "flightRangeAutoId", required = true) Integer flightRangeAutoId,
			@RequestParam(value = "ticketedIssueDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") String ticketedIssueDate,
			@RequestParam(value = "clientId", required = false) String clientId,
			@RequestParam(value = "flag", required = true) String flag) {
		return flightRangeService.valiadateIssueDate(flightRangeAutoId, ticketedIssueDate,clientId,flag);
	}

}
