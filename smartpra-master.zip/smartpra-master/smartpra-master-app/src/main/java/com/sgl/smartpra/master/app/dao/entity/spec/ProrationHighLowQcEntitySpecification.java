package com.sgl.smartpra.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.entity.ProrationHighLowQcEntity;
import com.sgl.smartpra.master.model.ProrationHighLowQc;

public class ProrationHighLowQcEntitySpecification {

	private static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";
	private static final String EFFECTIVE_TO_DATE = "effectiveToDate";

	public static void orderByHighLowQcByAsc(Root<ProrationHighLowQcEntity> prorationHighLowQcEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String highLowQcId) {
		criteriaQuery.orderBy(criteriaBuilder.asc(prorationHighLowQcEntity.get(highLowQcId)));
	}

	public static Specification<ProrationHighLowQcEntity> search(Optional<String> clientId,ProrationHighLowQc hl){
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(clientId)) {
				predicates.add(criteriaBuilder.equal(prorationHighLowQcEntity.get("clientId"),
						OptionalUtil.getValue(clientId)));
			}
			if (OptionalUtil.isPresent(hl.getHighLowId())) {
				predicates.add(criteriaBuilder.like(prorationHighLowQcEntity.get("highLowId"),
						OptionalUtil.getValue(hl.getHighLowId()) + "%"));
			}
			if (OptionalUtil.isPresent(hl.getQcField())) {
				predicates.add(criteriaBuilder.like(prorationHighLowQcEntity.get("qcField"),
						OptionalUtil.getValue(hl.getQcField()) + "%"));
			}
			if (OptionalUtil.isPresent(hl.getTaxCode())) {
				predicates.add(criteriaBuilder.like(prorationHighLowQcEntity.get("taxCode"),
						OptionalUtil.getValue(hl.getTaxCode()) + "%"));
			}
			if (OptionalUtil.isPresent(hl.getCouponCxrType())) {
				predicates.add(criteriaBuilder.equal(prorationHighLowQcEntity.get("couponCxrType"),
						OptionalUtil.getValue(hl.getCouponCxrType())));
			}
			if (OptionalUtil.isPresent(hl.getCouponCxrList())) {
				predicates.add(criteriaBuilder.like(prorationHighLowQcEntity.get("couponCxrList"),
						"%" + OptionalUtil.getValue(hl.getCouponCxrList()) + "%"));
			}
			if (OptionalUtil.isPresent(hl.getIssueCxrType())) {
				predicates.add(criteriaBuilder.equal(prorationHighLowQcEntity.get("issueCxrType"),
						OptionalUtil.getValue(hl.getIssueCxrType())));
			}
			if (OptionalUtil.isPresent(hl.getIssueCxrList())) {
				predicates.add(criteriaBuilder.like(prorationHighLowQcEntity.get("issueCxrList"),
						"%" + OptionalUtil.getValue(hl.getIssueCxrList()) + "%"));
			}
			if (OptionalUtil.isPresent(hl.getEffectiveFromDate()) && OptionalUtil.isPresent(hl.getEffectiveToDate())) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(hl.getEffectiveFromDate())),
								prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE),
								prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(hl.getEffectiveToDate())),
								prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE),
								prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE))));
			} else {
				if (OptionalUtil.isPresent(hl.getEffectiveFromDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(hl.getEffectiveFromDate())),
							prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE),
							prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(hl.getEffectiveToDate())) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(hl.getEffectiveToDate())),
							prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE),
							prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			orderByHighLowQcByAsc(prorationHighLowQcEntity, criteriaQuery, criteriaBuilder, "lowHighQcId");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProrationHighLowQcEntity> equalsHighLowId(String highLowId) {
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorationHighLowQcEntity.get("highLowId"), highLowId);
	}

	public static Specification<ProrationHighLowQcEntity> equalsClientId(String clientId) {
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorationHighLowQcEntity.get("clientId"), clientId);
	}

	public static Specification<ProrationHighLowQcEntity> equalsQCField(String qcField) {
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorationHighLowQcEntity.get("qcField"), qcField);
	}

	public static Specification<ProrationHighLowQcEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE),
				prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<ProrationHighLowQcEntity> notEqualsLowHighQcIdId(Integer lowHighQcId) {
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(prorationHighLowQcEntity.get("lowHighQcId"), lowHighQcId);
	}

	public static Specification<ProrationHighLowQcEntity> getCount(ProrationHighLowQcEntity mapToEntity) {
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (mapToEntity.getHighLowId() != null) {
				predicates.add(criteriaBuilder.like(prorationHighLowQcEntity.get("highLowId"),
						mapToEntity.getHighLowId() + "%"));
			}
			if (mapToEntity.getQcField() != null) {
				predicates.add(
						criteriaBuilder.like(prorationHighLowQcEntity.get("qcField"), mapToEntity.getQcField() + "%"));
			}
			if (mapToEntity.getTaxCode() != null) {
				predicates.add(
						criteriaBuilder.like(prorationHighLowQcEntity.get("taxCode"), mapToEntity.getTaxCode() + "%"));
			}
			if (mapToEntity.getEffectiveFromDate() != null && mapToEntity.getEffectiveToDate() != null) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveFromDate()),
								prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE),
								prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveToDate()),
								prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE),
								prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE))));
			} else {
				if (mapToEntity.getEffectiveFromDate() != null) {
					predicates.add(criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveFromDate()),
							prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE),
							prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (mapToEntity.getEffectiveToDate() != null) {
					predicates.add(criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveToDate()),
							prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE),
							prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			orderByHighLowQcByAsc(prorationHighLowQcEntity, criteriaQuery, criteriaBuilder, "lowHighQcId");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProrationHighLowQcEntity> greaterThanOrEqualTo(LocalDate effectiveFromDate) {
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(prorationHighLowQcEntity.get(EFFECTIVE_FROM_DATE), effectiveFromDate);
	}

	public static Specification<ProrationHighLowQcEntity> lessThanOrEqualTo(LocalDate effectiveToDate) {
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(prorationHighLowQcEntity.get(EFFECTIVE_TO_DATE), effectiveToDate);

	}

	public static Specification<ProrationHighLowQcEntity> searchHighLow(Optional<String> date) {
		return (prorationHighLowQcEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			/*
			 * if (OptionalUtil.isPresent(qcField)) { predicates.add(
			 * criteriaBuilder.equal(prorationHighLowQcEntity.get("qcField"),
			 * OptionalUtil.getValue(qcField))); }
			 */
			
			
			if (OptionalUtil.isPresent(date)) {
				predicates.add(criteriaBuilder
						.or(criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(date)),
								prorationHighLowQcEntity.get("effectiveFromDate"),
								prorationHighLowQcEntity.get("effectiveToDate"))));
			}
			orderByAsc(prorationHighLowQcEntity, criteriaQuery, criteriaBuilder, "priority");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static void orderByAsc(Root<ProrationHighLowQcEntity> prorationHighLowQcEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String oredrByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(prorationHighLowQcEntity.get(oredrByString)));
	}

}
