package com.sgl.smartpra.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.master.app.dao.entity.FlightRangeEntity;
import com.sgl.smartpra.master.model.FlightRange;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FlightRangeMapper extends BaseMapper<FlightRange, FlightRangeEntity> {

	FlightRangeEntity mapToEntity(FlightRange flightRange, @MappingTarget FlightRangeEntity flightRangeEntity);

	@Mapping(source = "flightRangeAutoId", target = "flightRangeAutoId", ignore = true)
	FlightRangeEntity mapToEntity(FlightRange flightRange);
	
	List<FlightRange> mapToFlightRangeModelList(List<FlightRangeEntity> flightRangeEntityList);

}
