package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.master.app.dao.StockDao;
import com.sgl.smartpra.master.app.dao.entity.StockEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.StockEntitySpecification;
import com.sgl.smartpra.master.app.repository.StockRepository;

@Component
@Repository
@Transactional(rollbackFor=DataAccessException.class)
public class StockDaoImpl implements StockDao {

	@Autowired
	private StockRepository stockRepository;

	@Override
	public List<StockEntity> search(Optional<String> documentSeriesFrom, Optional<String> documentSeriesTo,
			Optional<String> documentType, Optional<String> clientId, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate) {
		return stockRepository.findAll(StockEntitySpecification.search(documentSeriesFrom, documentSeriesTo,
				documentType, clientId, effectiveFromDate, effectiveToDate, activate));
	}

	@Override
	@Cacheable(value = "stock", key = "#id")
	public Optional<StockEntity> findById(Integer id) {
		return stockRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "stock", key = "#stockEntity.stockId") })
	public StockEntity create(StockEntity stockEntity) {
		return stockRepository.save(stockEntity);
	}

	@Override
	@CachePut(value = "stock", key = "#mapToEntity.stockId")
	public StockEntity update(StockEntity mapToEntity) {
		return stockRepository.save(mapToEntity);
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String documentSeriesFrom,
			String documentSeriesTo, String clientId, String documentType) {
		return stockRepository.count(Specification.where(StockEntitySpecification.equalsClientId(clientId))
				.and(StockEntitySpecification.equalsDocumentType(documentType))
				.and(StockEntitySpecification.betweenDocumentFromAndDocumentTo(documentSeriesFrom)
						.or(StockEntitySpecification.betweenDocumentFromAndDocumentTo(documentSeriesTo)))
				.and(StockEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(StockEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.or(StockEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate))));
	}

	@Override
	public List<StockEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return stockRepository
				.findAll((StockEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(StockEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(StockEntitySpecification.isActive())));
	}

	@PersistenceContext
	private EntityManager entityManager;
	

	@Transactional(rollbackFor = BusinessException.class)
	public void updateStaockDetails(StockEntity entity, String document) {

		String q = "Update StcokDetails s set s.clientId=:clientId,s.documentNumber=:documentNumber,s.effectiveDate=:effectiveDate,s.expiryDate=:expiryDate,s.isActive=:isActive,s.lastUpdatedDate=:lastUpdatedDate,s.lastUpdatedBy=:lastUpdatedBy,s.documentType=:documentType where s.stockId=:stockId and s.documentNumber=:documentNumber";
		Query query = entityManager.createQuery(q);
		query.setParameter("clientId", entity.getClientId());
		query.setParameter("documentNumber", document);
		query.setParameter("effectiveDate", entity.getEffectiveFromDate());
		query.setParameter("expiryDate", entity.getEffectiveToDate());
		query.setParameter("isActive", true);
		query.setParameter("lastUpdatedDate", LocalDateTime.now());
		query.setParameter("lastUpdatedBy", entity.getLastUpdatedBy());
		query.setParameter("documentType", entity.getDocumentType());
		query.setParameter("stockId", entity.getStockId());
		query.setParameter("documentNumber", document);
		query.executeUpdate();
		
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String documentSeriesFrom,
			String documentSeriesTo, String clientId, String documentType, Integer stockId) {
		return stockRepository.count(Specification.where(StockEntitySpecification.equalsClientId(clientId))
				.and(StockEntitySpecification.equalsDocumentType(documentType))
				.and(StockEntitySpecification.betweenDocumentFromAndDocumentTo(documentSeriesFrom)
						.or(StockEntitySpecification.betweenDocumentFromAndDocumentTo(documentSeriesTo)))
				.and(StockEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(StockEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.or(StockEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate)))
						.and(StockEntitySpecification.notEqualsStockId(stockId)));
	}

	@Override
	public List<StockEntity> verifyIfOverlapForDocumentSeriesExists(LocalDate effectiveFromDate,
			LocalDate effectiveToDate, Optional<String> documentSeriesFrom, Optional<String> documentSeriesTo) {
		return stockRepository
				.findAll(StockEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(StockEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(StockEntitySpecification
								.betweenDocumentFromAndDocumentTo(OptionalUtil.getValue(documentSeriesFrom))
								.or(StockEntitySpecification
										.betweenDocumentFromAndDocumentTo(OptionalUtil.getValue(documentSeriesTo)))
								.and(StockEntitySpecification.isActive())));
	}

	@Override
	public List<StockEntity> findByListStockId(Integer stockId) {
		return stockRepository.findAll(StockEntitySpecification.equalsStockId(stockId));
	}

}
