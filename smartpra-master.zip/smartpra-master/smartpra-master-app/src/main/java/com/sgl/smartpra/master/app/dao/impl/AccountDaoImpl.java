package com.sgl.smartpra.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.app.dao.AccountDao;
import com.sgl.smartpra.master.app.dao.entity.AccountEntity;
import com.sgl.smartpra.master.app.dao.entity.spec.AccountEntitySpecification;
import com.sgl.smartpra.master.app.dao.repository.AccountRepository;
import com.sgl.smartpra.master.model.AccountModel;

@Component
public class AccountDaoImpl implements AccountDao {

	@Autowired
	private AccountRepository accountRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "accountModel", key = "#accountEntity.accountAlphaCodeId") })
	public AccountEntity createAccount(AccountEntity accountEntity) {

		return accountRepository.save(accountEntity);
	}

	@Override
	@Cacheable(value = "accountModel", key = "#id")
	public Optional<AccountEntity> findById(Integer id) {
		return accountRepository.findById(id);
	}

	@Override
	@CachePut(value = "accountModel", key = "#accountEntity.accountAlphaCodeId")
	public AccountEntity updateAccount(AccountEntity accountEntity) {
		accountEntity.setAccountType(checkString(accountEntity.getAccountType()));
		accountEntity.setAttribute1(checkString(accountEntity.getAttribute1()));
		accountEntity.setAttribute2(checkString(accountEntity.getAttribute2()));
		accountEntity.setAttribute3(checkString(accountEntity.getAttribute3()));
		accountEntity.setAttribute4(checkString(accountEntity.getAttribute4()));
		accountEntity.setAttribute5(checkString(accountEntity.getAttribute5()));
		accountEntity.setAttribute6(checkString(accountEntity.getAttribute6()));
		accountEntity.setAttribute7(checkString(accountEntity.getAttribute7()));
		accountEntity.setAttribute8(checkString(accountEntity.getAttribute8()));
		accountEntity.setAttribute9(checkString(accountEntity.getAttribute9()));
		accountEntity.setAttribute10(checkString(accountEntity.getAttribute10()));
		accountEntity.setAttribute11(checkString(accountEntity.getAttribute11()));
		accountEntity.setAttribute12(checkString(accountEntity.getAttribute12()));
		accountEntity.setAttribute13(checkString(accountEntity.getAttribute13()));
		accountEntity.setAttribute14(checkString(accountEntity.getAttribute14()));
		accountEntity.setAttribute15(checkString(accountEntity.getAttribute15()));
		accountEntity.setAttribute16(checkString(accountEntity.getAttribute16()));
		accountEntity.setAttribute17(checkString(accountEntity.getAttribute17()));
		accountEntity.setAttribute18(checkString(accountEntity.getAttribute18()));
		accountEntity.setAttribute19(checkString(accountEntity.getAttribute19()));
		accountEntity.setAttribute20(checkString(accountEntity.getAttribute20()));
		return accountRepository.save(accountEntity);
	}

	@Override
	public List<AccountEntity> getAllAccount(AccountModel accountModel) {
		return accountRepository.findAll(AccountEntitySpecification.search(accountModel));
	}

	@Override
	public long validateOverlapForCreate(AccountModel accountModel) {
		return accountRepository.count(AccountEntitySpecification
				.equalsClientId(checkString(accountModel.getClientId()))
				.and(AccountEntitySpecification.equalsAccountAlphaCode(checkString(accountModel.getAccountAlphaCode())))
				.and(AccountEntitySpecification.equalsAccountNumCode(checkString(accountModel.getAccountNumCode())))
				.and(AccountEntitySpecification.equalsAccountType(checkString(accountModel.getAccountType())))
				.and(AccountEntitySpecification.equalsAttribute1(checkString(accountModel.getAttribute1())))
				.and(AccountEntitySpecification.equalsAttribute2(checkString(accountModel.getAttribute2())))
				.and(AccountEntitySpecification.equalsAttribute3(checkString(accountModel.getAttribute3())))
				.and(AccountEntitySpecification.equalsAttribute4(checkString(accountModel.getAttribute4())))
				.and(AccountEntitySpecification.equalsAttribute5(checkString(accountModel.getAttribute5())))
				.and(AccountEntitySpecification.equalsAttribute6(checkString(accountModel.getAttribute6())))
				.and(AccountEntitySpecification.equalsAttribute7(checkString(accountModel.getAttribute7())))
				.and(AccountEntitySpecification.equalsAttribute8(checkString(accountModel.getAttribute8())))
				.and(AccountEntitySpecification.equalsAttribute9(checkString(accountModel.getAttribute9())))
				.and(AccountEntitySpecification.equalsAttribute10(checkString(accountModel.getAttribute10())))
				.and(AccountEntitySpecification.equalsAttribute11(checkString(accountModel.getAttribute11())))
				.and(AccountEntitySpecification.equalsAttribute12(checkString(accountModel.getAttribute12())))
				.and(AccountEntitySpecification.equalsAttribute13(checkString(accountModel.getAttribute13())))
				.and(AccountEntitySpecification.equalsAttribute14(checkString(accountModel.getAttribute14())))
				.and(AccountEntitySpecification.equalsAttribute15(checkString(accountModel.getAttribute15())))
				.and(AccountEntitySpecification.equalsAttribute16(checkString(accountModel.getAttribute16())))
				.and(AccountEntitySpecification.equalsAttribute17(checkString(accountModel.getAttribute17())))
				.and(AccountEntitySpecification.equalsAttribute18(checkString(accountModel.getAttribute18())))
				.and(AccountEntitySpecification.equalsAttribute19(checkString(accountModel.getAttribute19())))
				.and(AccountEntitySpecification.equalsAttribute20(checkString(accountModel.getAttribute20())))
				.and((AccountEntitySpecification
						.betweenEffectiveFromAndEffectiveToDate(
								OptionalUtil.getLocalDateValue(accountModel.getEffectiveFromDate()))
						.or(AccountEntitySpecification.betweenEffectiveFromAndEffectiveToDate(
								OptionalUtil.getLocalDateValue(accountModel.getEffectiveToDate()))))
										.or(AccountEntitySpecification
												.greaterThanOrEqualTo(OptionalUtil
														.getLocalDateValue(accountModel.getEffectiveFromDate()))
												.and(AccountEntitySpecification.lessThanOrEqualTo(OptionalUtil
														.getLocalDateValue(accountModel.getEffectiveToDate()))))));
	}

	@Override
	public long validateOverlapForUpdate(String accountAlphaCode, String clientId, String accountNumCode,
			LocalDate effectiveFromDate, LocalDate effectiveToDate, String accountType, String attribute1,
			String attribute2, String attribute3, String attribute4, String attribute5, String attribute6,
			String attribute7, String attribute8, String attribute9, String attribute10, String attribute11,
			String attribute12, String attribute13, String attribute14, String attribute15, String attribute16,
			String attribute17, String attribute18, String attribute19, String attribute20,
			Integer accountAlphaCodeId) {
		return accountRepository.count(AccountEntitySpecification.equalsClientId(checkString(clientId))
				.and(AccountEntitySpecification.equalsAccountAlphaCode(checkString(accountAlphaCode)))
				.and(AccountEntitySpecification.equalsAccountNumCode(checkString(accountNumCode)))
				.and(AccountEntitySpecification.equalsAccountType(checkString(accountType)))
				.and(AccountEntitySpecification.equalsAttribute1(checkString(attribute1)))
				.and(AccountEntitySpecification.equalsAttribute2(checkString(attribute2)))
				.and(AccountEntitySpecification.equalsAttribute3(checkString(attribute3)))
				.and(AccountEntitySpecification.equalsAttribute4(checkString(attribute4)))
				.and(AccountEntitySpecification.equalsAttribute5(checkString(attribute5)))
				.and(AccountEntitySpecification.equalsAttribute6(checkString(attribute6)))
				.and(AccountEntitySpecification.equalsAttribute7(checkString(attribute7)))
				.and(AccountEntitySpecification.equalsAttribute8(checkString(attribute8)))
				.and(AccountEntitySpecification.equalsAttribute9(checkString(attribute9)))
				.and(AccountEntitySpecification.equalsAttribute10(checkString(attribute10)))
				.and(AccountEntitySpecification.equalsAttribute11(checkString(attribute11)))
				.and(AccountEntitySpecification.equalsAttribute12(checkString(attribute12)))
				.and(AccountEntitySpecification.equalsAttribute13(checkString(attribute13)))
				.and(AccountEntitySpecification.equalsAttribute14(checkString(attribute14)))
				.and(AccountEntitySpecification.equalsAttribute15(checkString(attribute15)))
				.and(AccountEntitySpecification.equalsAttribute16(checkString(attribute16)))
				.and(AccountEntitySpecification.equalsAttribute17(checkString(attribute17)))
				.and(AccountEntitySpecification.equalsAttribute18(checkString(attribute18)))
				.and(AccountEntitySpecification.equalsAttribute19(checkString(attribute19)))
				.and(AccountEntitySpecification.equalsAttribute20(checkString(attribute20)))
				.and((AccountEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(AccountEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
								.or(AccountEntitySpecification.greaterThanOrEqualTo(effectiveFromDate))
								.and(AccountEntitySpecification.lessThanOrEqualTo(effectiveToDate)))
				.and(AccountEntitySpecification.notEqualsAccountAlphaCodeId(accountAlphaCodeId)));
	}

	private String checkString(String name) {
		return name != null ? name : "";
	}

	private String checkString(Optional<String> name) {
		return OptionalUtil.isPresent(name) ? OptionalUtil.getValue(name) : "";
	}

	@Override
	public long findByAccountAlphaCode(Optional<String> accountAlphaCode) {

		return accountRepository
				.count(AccountEntitySpecification.equalsAccountAlphaCode(OptionalUtil.getValue(accountAlphaCode)));
	}

	@Override
	public List<AccountEntity> getListOfAccountBYAccountAphaCode(List<String> accountAlphaCode) {

		return accountRepository.findByAccountAlphaCodeIn(accountAlphaCode);
	}

	@Override
	public List<String> getAccountAlphaCodeFromAccountMaster() {
		// TODO Auto-generated method stub
		return accountRepository.getAccountAlphaCodeFromAccountMaster();
	}
}
