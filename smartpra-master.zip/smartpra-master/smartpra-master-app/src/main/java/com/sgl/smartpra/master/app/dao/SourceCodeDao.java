package com.sgl.smartpra.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.master.app.dao.entity.SourceCodeEntity;

@Repository
public interface SourceCodeDao {

	public Optional<SourceCodeEntity> findById(Integer sourceCodeId);

	public List<SourceCodeEntity> search(Optional<String> clientId, Optional<String> sourceType,
			Optional<String> sourceCategory, Optional<Boolean> activate);

	public List<SourceCodeEntity> getAllSourceCode(String sourceCode);

	public SourceCodeEntity create(SourceCodeEntity sourceCodeEntity);

	public SourceCodeEntity update(SourceCodeEntity sourceCodeEntity);

	public void save(SourceCodeEntity sourceCodeEntity);

	List<SourceCodeEntity> findByClientIdAndSourceCode(Optional<String> clientId, Optional<String> sourceCode);

	public long getOverLapForUpdate(String sourceCode, String clientId, Integer sourceCodeId);
	public List<String> getSourceCodeFromSourceCodeMaster();
}
