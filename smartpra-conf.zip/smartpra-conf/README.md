# SmartPRA Conf

SmartPra Conf is a pom library for dealing with dependencies of various application  files.

## Installation

Use the [maven](https://maven.apache.org/download.cgi) to install maven.

```bash
mvn clean install
```

## Clone

```bash
git clone http://wusazedev12:7990/scm/smartpra/smartpra-conf.git
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)