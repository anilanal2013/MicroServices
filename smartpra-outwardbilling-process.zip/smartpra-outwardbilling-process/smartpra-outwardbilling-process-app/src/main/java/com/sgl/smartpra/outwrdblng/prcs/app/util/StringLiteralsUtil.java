package com.sgl.smartpra.outwrdblng.prcs.app.util;


public class StringLiteralsUtil {

	public static final String FLOWNNAMEDQUERY = "Flownoutwardbilling";
	public static final String DOCUMENT_UNIQUE_ID = "document_unique_id";
	public static final String COUPON_NUMBER = "coupon_number";
	public static final String BILLING_PERIOD = "billing_period";
	public static final String BILLED_CARRIER_CODE = "billed_carrier_code";
	public static final String BILLING_MONTH = "billing_month";
	public static final String SOURCE_CODE = "source_code";
	public static final String CURRENCY_OF_INVOICE = "currency_of_invoice";
	public static final String COUPVALID_EXCEP_CREATEDBY = "OutwardAdmin";
	public static final String COUPVALID_EXCEP_ENVIRONMENT = "P";
	public static final String OUTWARD_BILL_EXCEP_TKTNOTFOUND = "LIFT2001";
	public static final String OUTWARD_BILL_EXCEP_SOURCECODE_NOT_FOUND = "OUWD3016";
	public static final String DEFAULT_CURRENCY_NOT_FOUND = "OUWD3005";
	public static final String DEFAULT_ZONE_NOT_FOUND = "OUWD3006";
	public static final String EXCHANGE_RATE_NOT_FOUND_FOR_ATBP_TO_COL = "OUWD3007";
	public static final String EXCHANGE_RATE_NOT_FOUND_FOR_COL_TO_COI = "OUWD3008";
	public static final String ERROR_WHILE_SAVING_IN_OTWRDRPSRY = "OUWD3014";
	public static final String ERROR_WHILE_ALREADY_EXISTS_THE_OTWRDBLNG_RCRDS = "OUWD3014";
	public static final String MISMATCH_BETWEEN_CREDIT_AND_DEBIT = "OUWD3012";
	public static final String TAX_IS_AVAILABLE_WITHOUT_TAX = "OUWD3011";
	public static final String VAT_IS_AVAILABLE_WITHOUT_VAT_BREAKUP = "OUWD3010";
	public static final String INVOICE_GENARATION_WITHOUT_AC_CODES = "OUWD3013";
	public static final String PRI_NOT_AVAILABLE = "OUWD3002";
	public static final String CARRIER_INTERLINE_NOT_FOUND = "OUWD3004";
	public static final String DEFAULT_ZONE = "DEFAULT_CARRIER_ZONE";
	public static final String TKT_CPN_NOT_FOUND = "OUWD3003";
	public static final String OUTWRD_BILING_PRD_NOTFND = "OUWD3001";
	public static final String OTWRD_BILLING_SOURCE_NOT_FOUND = "OUWD3020";
	public static final String Default_Lising_Currency = "DEFAULT_LISTING_CURRENCY";
	public static final String SUPPLEMENTARY_BILLING_IND = "N";
	public static final String TAX_VALUE_NOT_FOUND = "OUWD3011";
	public static final String TRNSITION_TYPEFOR_FLOWN = "FL";
	public static final String ERRORCOUPONSTATUS = "EO";
	public static final String SUCCESSCOUPONSTATUS = "RB";
	public static final String EXCHANGE_TXN_STATUS = "PE";
	public static final String REFUND_TXN_STATUS = "PR";
	public static final String SLF_DOWNGRD_TXN_STATUS = "PD";
	public static final String OBLNG_FREQ = "Outward Billing Frequency";
	public static final String INCLUDE_NEXTPERIOD_TRANS = "Include_Next_Period_Transcations";
	public static final String ADDDYSTOCLOSEOUWD = "Additional_Days_To_Close_Outward_Billing ";
	public static final String START_FIN_MONTH = "Starting Financial Month";
	public static final String NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";
	public static final String EMPTY_STRING = "";
	public static final String SALES_OUTWARD_BLNG_SQL_LITERAL = " select distinct coupon.operating_flight_number,coupon.marketing_flight_date, "
	          + " coupon.marketing_carrier_num_code,main.client_id, origin.document_unique_id , "
	          + " origin.sales_key as batch_key ,sales.tkt_sales_data_dtl_id, "
	          + " main.date_of_issue,main.eticket_ind as etkt_indicator,origin.refund_date , "
	          + " origin.orig_issue_airline as iss_airline, "
	          + " origin.iss_airline as billed_carrier_code,origin.orig_document as  document_no,  "
	          + " origin.orig_cpn_no,coupon.coupon_number as coupon_number,coupon.marketing_flight_number as flight_number , "
	          + " coupon.marketing_flight_date as utilization_date ,coupon.codeshare_agreement_id, "
	          + " coupon.from_airport,main.file_id,coupon.to_airport  ,main.currency_of_sale ,main.atbp_currency as prorate_currency ,sales.transaction_code as transaction_type ,sales.source ,"
	          + " coupon.sector_fare_amount as gross_amount ,coupon.settlement_isc_percentage as isc_percentage,coupon.settlement_isc_value as isc_amount , "
	          + " coupon.tax_value as tax_amount ,coupon.commission_amount as othr_comm ,main.proration_source, "
	          + " coupon.handling_fee_amount ,coupon.tax_value,coupon.ffy_agreement_id,coupon.surcharge_value , "
	          + " main.rfic,main.rfisc,coupon.fnf_indicator FROM SmartPRASales.ticket_orgin origin INNER  JOIN  "
	          + " SmartPRASales.ticket_sales sales ON origin.document_unique_id =sales.document_unique_id INNER  join "
	          + " SmartPRASales.ticket_coupon coupon ON origin.document_unique_id=coupon.document_unique_id INNER  join "
	          + " SmartPRASales.ticket_main main ON origin.document_unique_id=main.document_unique_id AND "
	          + " sales.process_status IN ('AA','EM','MC') AND  "
	          + " origin.outward_trnsfr_flag='N' "
	          + " AND coupon.document_unique_id=:document_unique_id "
	          + " AND  coupon.coupon_number=:coupon_number  ";
	public static final String TICKET_ORIG_RECS_FOR_SALES_OUWRD_BLNG = "SELECT tkt_orgin_id,origin.document_unique_id,origin.iss_airline,origin.orig_document,origin.orig_cpn_no,origin.orig_document FROM SmartPRASales.ticket_main main,SmartPRASales.ticket_sales sales,SmartPRASales.ticket_orgin origin "
	          + "  WHERE sales.process_status IN ('AA','EM','MC') "
	          + " AND sales.document_unique_id=origin.document_unique_id AND   "
	          + " main.document_unique_id=origin.document_unique_id ";

	private StringLiteralsUtil() {

	}
}
