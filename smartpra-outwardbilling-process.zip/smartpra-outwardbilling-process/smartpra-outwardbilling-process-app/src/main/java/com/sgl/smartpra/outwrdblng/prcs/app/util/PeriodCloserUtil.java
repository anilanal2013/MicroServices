package com.sgl.smartpra.outwrdblng.prcs.app.util;

public class PeriodCloserUtil {

	public static final String STARTING_FINANCIAL_MONTH = "STARTING_FINANCIAL_MONTH";
	public static final String OUTWARD_BILLING_FREQUENCY = "OUTWARD_BILLING_FREQUENCY";
	public static final String QA = "QA";
	public static final String CLOSING_INDICATOR_N = "N";
	public static final String CREATED_BY = "Admin";
	public static final String LAST_UPDATED_BY = "Admin";
	public static final String PERIOD_CLOSE_DAILY = "Daily";
	public static final String PERIOD_CLOSE_WEEKLY = "Weekly";
	public static final String CLOSING_INDICATOR_Y = "Y";
	
	//OutwardBillingModules period-wise
	public static final String MISCELLANCEOUS_BILLING = "MSC";
	public static final String PRIME_BILLING = "PRI";
	public static final String REJECTION_BILLING = "REJ";
	public static final String SUPPLEMENTARY_BILLING = "SUB";
	
}
