package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

@EnableConfigurationProperties
@ConfigurationProperties(prefix = "smart-pra")
@Component
@Data
public class InvoiceCurrencyConfig {

	private List<InvoiceCurrency> invoiceCurrencies = new ArrayList<InvoiceCurrency>();

	@Data
	@NoArgsConstructor
	public static class InvoiceCurrency {
		String billedZone;
		String billingZone;
		String currency;

		public String getBilledZone() {
			return billedZone;
		}

		public void setBilledZone(String billedZone) {
			this.billedZone = billedZone;
		}

		public String getBillingZone() {
			return billingZone;
		}

		public void setBillingZone(String billingZone) {
			this.billingZone = billingZone;
		}

		public String getCurrency() {
			return currency;
		}

		public void setCurrency(String currency) {
			this.currency = currency;
		}

	}

}