package com.sgl.smartpra.outwrdblng.prcs.app.service;

import java.util.List;

import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingDetailModel;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingDetail;

public interface OutwrblngprcsService {

	List<OutwardBillingDetail> getOuwrdBlngRecsByInvcNo(String invoiceNumber);

	Integer processSalesOutwardBillingsRecords();

	Integer processFlownOutwardBillingRecords(Integer flightKey, String docId, Integer coupNum);

	OutwardBillingDetailModel getOuwrdBlngByDocAndCoup(String docUniqueId, Integer coupNumber);

	OutwardBillingDetailModel createOutwardBillingDetail(OutwardBillingDetailModel outwardBillingDetailModel);
}
