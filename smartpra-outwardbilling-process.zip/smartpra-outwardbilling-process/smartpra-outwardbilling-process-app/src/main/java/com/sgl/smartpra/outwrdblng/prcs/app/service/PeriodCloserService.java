package com.sgl.smartpra.outwrdblng.prcs.app.service;

import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.PeriodCloserResponse;

public interface PeriodCloserService {

	public Integer populateBillingYear(String billingYear);

	public Integer populateBillingPeriods(String billingYear, String billingMonth);

	public PeriodCloserResponse searchBillingPeriods(String billingYear, String billingMonth);

	public OutwardBillingPeriods billingPeriodsClosingProcess(String billingMonth, Integer billingPeriod);

	public OutwardBillingPeriods skipPeriodsClosingProcess(String billingYear, String billingMonth,
			Integer billingPeriod, String remarks);

}
