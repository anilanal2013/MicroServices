package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "outward_billing_vat")
@NamedQuery(name = "OutwardBillingVat.findAll", query = "SELECT o FROM OutwardBillingVat o")
public class OutwardBillingVat implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "OUTWARD_BILLING_VAT_OUTWARDBILLINGVATID_GENERATOR")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OUTWARD_BILLING_VAT_OUTWARDBILLINGVATID_GENERATOR")
	@Column(name = "outward_billing_vat_id")
	private int outwardBillingVatId;

	@Column(name = "batch_key")
	private long batchKey;

	@Column(name = "billed_carrier_code")
	private String billedCarrierCode;

	@Column(name = "billing_month")
	private String billingMonth;

	@Column(name = "billing_period")
	private int billingPeriod;

	@Column(name = "check_digit")
	private int checkDigit;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "coupon_number")
	private int couponNumber;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;

	@Column(name = "document_number")
	private String documentNumber;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	@Column(name = "financial_year")
	private String financialYear;

	@Column(name = "invoice_number")
	private String invoiceNumber;

	@Column(name = "issuing_carrier_code")
	private String issuingCarrierCode;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name = "order_id")
	private String orderId;

	@Column(name = "record_seq_number")
	private int recordSeqNumber;

	@Column(name = "vat_amount")
	private BigDecimal vatAmount;

	@Column(name = "vat_base_amount")
	private BigDecimal vatBaseAmount;

	@Column(name = "vat_identifier")
	private String vatIdentifier;

	@Column(name = "vat_label")
	private String vatLabel;

	@Column(name = "vat_percentage")
	private BigDecimal vatPercentage;

	@ManyToOne
	@JoinColumn(name = "outward_billing_id")
	private OutwardBillingDetail outwardBillingDetail;

	public OutwardBillingVat() {

	}

	public int getOutwardBillingVatId() {

		return this.outwardBillingVatId;
	}

	public void setOutwardBillingVatId(int outwardBillingVatId) {

		this.outwardBillingVatId = outwardBillingVatId;
	}

	public long getBatchKey() {

		return this.batchKey;
	}

	public void setBatchKey(long batchKey) {

		this.batchKey = batchKey;
	}

	public String getBilledCarrierCode() {

		return this.billedCarrierCode;
	}

	public void setBilledCarrierCode(String billedCarrierCode) {

		this.billedCarrierCode = billedCarrierCode;
	}

	public String getBillingMonth() {

		return this.billingMonth;
	}

	public void setBillingMonth(String billingMonth) {

		this.billingMonth = billingMonth;
	}

	public int getBillingPeriod() {

		return this.billingPeriod;
	}

	public void setBillingPeriod(int billingPeriod) {

		this.billingPeriod = billingPeriod;
	}

	public int getCheckDigit() {

		return this.checkDigit;
	}

	public void setCheckDigit(int checkDigit) {

		this.checkDigit = checkDigit;
	}

	public String getClientId() {

		return this.clientId;
	}

	public void setClientId(String clientId) {

		this.clientId = clientId;
	}

	public int getCouponNumber() {

		return this.couponNumber;
	}

	public void setCouponNumber(int couponNumber) {

		this.couponNumber = couponNumber;
	}

	public String getCreatedBy() {

		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {

		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {

		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {

		this.createdDate = createdDate;
	}

	public String getDocumentNumber() {

		return this.documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {

		this.documentNumber = documentNumber;
	}

	public String getDocumentUniqueId() {

		return this.documentUniqueId;
	}

	public void setDocumentUniqueId(String documentUniqueId) {

		this.documentUniqueId = documentUniqueId;
	}

	public String getFinancialYear() {

		return this.financialYear;
	}

	public void setFinancialYear(String financialYear) {

		this.financialYear = financialYear;
	}

	public String getInvoiceNumber() {

		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {

		this.invoiceNumber = invoiceNumber;
	}

	public String getIssuingCarrierCode() {

		return this.issuingCarrierCode;
	}

	public void setIssuingCarrierCode(String issuingCarrierCode) {

		this.issuingCarrierCode = issuingCarrierCode;
	}

	public String getLastUpdatedBy() {

		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {

		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {

		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {

		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getOrderId() {

		return this.orderId;
	}

	public void setOrderId(String orderId) {

		this.orderId = orderId;
	}

	public int getRecordSeqNumber() {

		return this.recordSeqNumber;
	}

	public void setRecordSeqNumber(int recordSeqNumber) {

		this.recordSeqNumber = recordSeqNumber;
	}

	public BigDecimal getVatAmount() {

		return this.vatAmount;
	}

	public void setVatAmount(BigDecimal vatAmount) {

		this.vatAmount = vatAmount;
	}

	public BigDecimal getVatBaseAmount() {

		return this.vatBaseAmount;
	}

	public void setVatBaseAmount(BigDecimal vatBaseAmount) {

		this.vatBaseAmount = vatBaseAmount;
	}

	public String getVatIdentifier() {

		return this.vatIdentifier;
	}

	public void setVatIdentifier(String vatIdentifier) {

		this.vatIdentifier = vatIdentifier;
	}

	public String getVatLabel() {

		return this.vatLabel;
	}

	public void setVatLabel(String vatLabel) {

		this.vatLabel = vatLabel;
	}

	public BigDecimal getVatPercentage() {

		return this.vatPercentage;
	}

	public void setVatPercentage(BigDecimal vatPercentage) {

		this.vatPercentage = vatPercentage;
	}

	public OutwardBillingDetail getOutwardBillingDetail() {

		return this.outwardBillingDetail;
	}

	public void setOutwardBillingDetail(OutwardBillingDetail outwardBillingDetail) {

		this.outwardBillingDetail = outwardBillingDetail;
	}

}