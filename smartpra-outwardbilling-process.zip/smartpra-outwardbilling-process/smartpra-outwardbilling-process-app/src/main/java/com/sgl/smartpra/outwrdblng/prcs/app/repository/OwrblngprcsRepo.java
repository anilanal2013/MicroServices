package com.sgl.smartpra.outwrdblng.prcs.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingDetail;

@Repository
public interface OwrblngprcsRepo extends
          JpaRepository<OutwardBillingDetail, Long> {

	List<OutwardBillingDetail> getOutwardBillingDetailByinvoiceNumber(@Param("invoiceNumber") String invoiceNumber);
	
	OutwardBillingDetail findByDocumentUniqueIdAndCouponNumber(@Param("documentUniqueId") String documentUniqueId,@Param("couponNumber") Integer couponNumber);
	

	@Query(value = "select entity  from OutwardBillingDetail entity where billingMonth=:billingMonth and billingPeriod = :billingPeriod ")
	List<OutwardBillingDetail> getOuwrdBlngByBlngPrdAndMnth(@Param("billingMonth") String billingMonth, @Param("billingPeriod") Integer billingPeriod);

}
