package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;

@SqlResultSetMapping(name = "OtwrdBlngInfoForInvc", entities = @EntityResult(entityClass = OtwrdBlngInfoForInvc.class, fields = {
          @FieldResult(name = "outwardBillingId", column = "outward_billing_id"),
          @FieldResult(name = "billedCarrierCode", column = "billed_carrier_code"),
          @FieldResult(name = "billingMonth", column = "billing_month"),
          @FieldResult(name = "billingPeriod", column = "billing_period"),
          @FieldResult(name = "sourceCode", column = "source_code"),
          @FieldResult(name = "currencyOfInvoice", column = "currency_of_invoice"),
          @FieldResult(name = "currencyOfListing", column = "currency_of_listing"),
          @FieldResult(name = "documentUniqueId", column = "document_unique_id"),
          @FieldResult(name = "exchangeexchangeRate", column = "exchange_rate"),
          @FieldResult(name = "clientId", column = "client_id"), }))
@Entity
public class OtwrdBlngInfoForInvc {

	@Id
	@Column(name = "outward_billing_id")
	private Integer outwardBillingId;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	@Column(name = "billed_carrier_code")
	private String billedCarrierCode;

	@Column(name = "billing_month")
	private String billingMonth;

	@Column(name = "billing_period")
	private Integer billingPeriod;

	@Column(name = "source_code")
	private Long sourceCode;

	@Column(name = "currency_of_invoice")
	private String currencyOfInvoice;

	@Column(name = "currency_of_listing")
	private String currencyOfListing;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "exchange_rate")
	private BigDecimal exchangeexchangeRate;

	public String getCurrencyOfListing() {

		return currencyOfListing;
	}

	public void setCurrencyOfListing(String currencyOfListing) {

		this.currencyOfListing = currencyOfListing;
	}

	public String getClientId() {

		return clientId;
	}

	public void setClientId(String clientId) {

		this.clientId = clientId;
	}

	public Integer getOutwardBillingId() {

		return outwardBillingId;
	}

	public void setOutwardBillingId(Integer outwardBillingId) {

		this.outwardBillingId = outwardBillingId;
	}

	public String getBilledCarrierCode() {

		return billedCarrierCode;
	}

	public void setBilledCarrierCode(String billedCarrierCode) {

		this.billedCarrierCode = billedCarrierCode;
	}

	public String getBillingMonth() {

		return billingMonth;
	}

	public void setBillingMonth(String billingMonth) {

		this.billingMonth = billingMonth;
	}

	public Integer getBillingPeriod() {

		return billingPeriod;
	}

	public void setBillingPeriod(Integer billingPeriod) {

		this.billingPeriod = billingPeriod;
	}

	public Long getSourceCode() {

		return sourceCode;
	}

	public void setSourceCode(Long sourceCode) {

		this.sourceCode = sourceCode;
	}

	public String getCurrencyOfInvoice() {

		return currencyOfInvoice;
	}

	public void setCurrencyOfInvoice(String currencyOfInvoice) {

		this.currencyOfInvoice = currencyOfInvoice;
	}

	public String getDocumentUniqueId() {

		return documentUniqueId;
	}

	public void setDocumentUniqueId(String documentUniqueId) {

		this.documentUniqueId = documentUniqueId;
	}

	@Override
	public int hashCode() {

		final int prime = 31;
		int result = 1;
		result = prime
		          * result
		          + ((billedCarrierCode == null) ? 0
		                    : billedCarrierCode.hashCode());
		result = prime * result
		          + ((billingMonth == null) ? 0 : billingMonth.hashCode());
		result = prime * result
		          + ((billingPeriod == null) ? 0 : billingPeriod.hashCode());
		result = prime
		          * result
		          + ((currencyOfInvoice == null) ? 0
		                    : currencyOfInvoice.hashCode());
		result = prime * result
		          + ((sourceCode == null) ? 0 : sourceCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		OtwrdBlngInfoForInvc other = (OtwrdBlngInfoForInvc) obj;
		if (billedCarrierCode == null) {
			if (other.billedCarrierCode != null) return false;
		}
		else if (!billedCarrierCode.equals(other.billedCarrierCode))
		     return false;
		if (billingMonth == null) {
			if (other.billingMonth != null) return false;
		}
		else if (!billingMonth.equals(other.billingMonth)) return false;
		if (billingPeriod == null) {
			if (other.billingPeriod != null) return false;
		}
		else if (!billingPeriod.equals(other.billingPeriod)) return false;
		if (currencyOfInvoice == null) {
			if (other.currencyOfInvoice != null) return false;
		}
		else if (!currencyOfInvoice.equals(other.currencyOfInvoice))
		     return false;
		if (sourceCode == null) {
			if (other.sourceCode != null) return false;
		}
		else if (!sourceCode.equals(other.sourceCode)) return false;
		return true;
	}

	@Override
	public String toString() {

		return "OtwrdBlngInfoForInvc [outwardBillingId=" + outwardBillingId
		          + ", billedCarrierCode=" + billedCarrierCode
		          + ", billingMonth=" + billingMonth + ", billingPeriod="
		          + billingPeriod + ", sourceCode=" + sourceCode
		          + ", currencyOfInvoice=" + currencyOfInvoice
		          + ", currencyOfListing=" + currencyOfListing
		          + ", clientId=" + clientId + "]";
	}

}
