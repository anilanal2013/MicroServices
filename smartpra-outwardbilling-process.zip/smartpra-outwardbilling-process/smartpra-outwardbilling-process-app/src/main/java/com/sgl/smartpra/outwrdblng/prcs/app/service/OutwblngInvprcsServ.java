package com.sgl.smartpra.outwrdblng.prcs.app.service;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;

import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingInvoiceModel;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingDetail;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwrdBlngInvocEntity;

public interface OutwblngInvprcsServ {

	String genarateInvcForPrime(String billingMonth, Integer billingPeriod, LocalDate processDate);

	List<OutwrdBlngInvocEntity> getInvcsByBlndPrd(String billingMonth, Integer billingPeriod);

	List<OutwardBillingDetail> getOutwrdblng(String billingMonth, Integer billingPeriod);

	/**
	 * @param outwardBillingInvoiceModel
	 * @return
	 * @throws ParseException 
	 */
	OutwardBillingInvoiceModel createOutwardBillingInvoice(OutwardBillingInvoiceModel outwardBillingInvoiceModel) throws ParseException;

}
