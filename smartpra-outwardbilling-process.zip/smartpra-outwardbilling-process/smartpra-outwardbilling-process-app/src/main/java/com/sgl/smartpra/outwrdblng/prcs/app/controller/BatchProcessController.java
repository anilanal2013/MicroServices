package com.sgl.smartpra.outwrdblng.prcs.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.outwrdblng.prcs.app.service.BatchProcessService;

@RestController
public class BatchProcessController {

	@Autowired
	public BatchProcessService batchProcessService;

	@GetMapping(value = "/outward-billing-invoice/billing-period/batch-processing")
	public void getBatchGenerationProcess() {

		batchProcessService.getBatchGenerationProcess();
	}
}
