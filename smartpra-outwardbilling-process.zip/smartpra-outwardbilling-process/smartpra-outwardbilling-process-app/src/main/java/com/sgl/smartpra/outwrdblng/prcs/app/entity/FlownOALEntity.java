package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import com.sgl.smartpra.outwrdblng.prcs.app.util.StringLiteralsUtil;


@SqlResultSetMapping(name = StringLiteralsUtil.FLOWNNAMEDQUERY, entities = @EntityResult(entityClass = FlownOALEntity.class, fields = {
          @FieldResult(name = "flownRevenueId", column = "flown_revenue_id"),
          @FieldResult(name = "orderId", column = "order_id"),
          @FieldResult(name = "clientId", column = "client_id"),
          @FieldResult(name = "documentUniqueId", column = "document_unique_id"),
          @FieldResult(name = "batchKey", column = "flight_key"),
          @FieldResult(name = "billedCarrierCode", column = "billed_carrier_code"),
          @FieldResult(name = "issueingCarrierCode", column = "issue_airline"),
          @FieldResult(name = "flightNumber", column = "flight_number"),
          @FieldResult(name = "utilizationDate", column = "flight_date"),
          @FieldResult(name = "saleCurrencyCode", column = "salecurrency"),
          @FieldResult(name = "prorateCurrency", column = "proratecurrency"),
          @FieldResult(name = "grossAmount", column = "gross"),
          @FieldResult(name = "documentNumber", column = "document_number"),
          @FieldResult(name = "couponNumber", column = "coupon_number"),
          @FieldResult(name = "fromAirport", column = "from_airport"),
          @FieldResult(name = "toAirport", column = "to_airport"),
          @FieldResult(name = "rfic", column = "rfic"),
          @FieldResult(name = "rfisc", column = "rfisc"),
          @FieldResult(name = "iscAmount", column = "isc_amount"),
          @FieldResult(name = "iscPercentage", column = "isc_percentage"),
          @FieldResult(name = "taxAmount", column = "provisional_total_tax"),
          @FieldResult(name = "esacCode", column = "esac_code"),
          @FieldResult(name = "eticketIndicator", column = "etkt_indicator"),
          @FieldResult(name = "responseLevel", column = "response_level"),
          @FieldResult(name = "prorationSource", column = "proration_source"),
          @FieldResult(name = "codeShareagreementId", column = "codeshare_agreement_id"),
          @FieldResult(name = "opertaingFlightNumber", column = "operating_flight_number"),
          @FieldResult(name = "operatingFlightDate", column = "operating_flight_dept_date"),
          @FieldResult(name = "operatingCarrierCode", column = "operating_carrier_num_code"),
          @FieldResult(name = "fnfIndicator", column = "fnf_indicator"),
          @FieldResult(name = "surchargeAmount", column = "surchargeamount"),
          @FieldResult(name = "handlingFeeAmount", column = "handling_fee_amount"),
          @FieldResult(name = "flightIndicator", column = "flight_indicator"),
          @FieldResult(name = "flightDate", column = "flight_date"),
          @FieldResult(name = "billingType", column = "document_type"),
          @FieldResult(name = "uatpAmount", column = "uatp_amount"),
          @FieldResult(name = "fileId", column = "file_id"),

}))
@Entity
public class FlownOALEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "flown_revenue_id")
	private Integer flownRevenueId;

	@Column(name = "order_id")
	private String orderId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	@Column(name = "flight_key")
	private Integer batchKey;

	@Column(name = "billed_carrier_code")
	private String billedCarrierCode;

	@Column(name = "issue_airline")
	private String issueingCarrierCode;

	@Column(name = "document_number")
	private String documentNumber;

	@Column(name = "coupon_number")
	private Integer couponNumber;

	@Column(name = "flight_number")
	private String flightNumber;

	@Column(name = "flight_date")
	private Date utilizationDate;

	@Column(name = "from_airport")
	private String fromAirport;

	@Column(name = "to_airport")
	private String toAirport;

	@Column(name = "salecurrency")
	private String saleCurrencyCode;

	@Column(name = "prorateCurrency")
	private String prorateCurrency;

	@Column(name = "gross")
	private BigDecimal grossAmount;

	@Column(name = "isc_amount")
	private BigDecimal iscAmount;

	@Column(name = "isc_percentage")
	private BigDecimal iscPercentage;

	@Column(name = "provisional_total_tax")
	private BigDecimal taxAmount;

	@Column(name = "surcharge_value")
	private BigDecimal surchargeAmount;

	@Column(name = "esac_code")
	private String esacCode;

	@Column(name = "rfic")
	private String rfic;

	@Column(name = "rfisc")
	private String rfisc;

	@Column(name = "etkt_indicator")
	private String eticketIndicator;

	@Column(name = "response_level")
	private Integer responseLevel;

	@Column(name = "proration_source")
	private String prorationSource;

	@Column(name = "codeshare_agreement_id")
	private String codeShareagreementId;

	@Column(name = "operating_flight_number")
	private String opertaingFlightNumber;

	@Column(name = "operating_flight_dept_date")
	private Date operatingFlightDate;

	@Column(name = "operating_carrier_num_code")
	private String operatingCarrierCode;

	@Column(name = "fnf_indicator")
	private String fnfIndicator;

	@Column(name = "flight_indicator")
	private Character flightIndicator;


	@Column(name = "document_type ")
	private String billingType;

	@Column(name = "handling_fee_amount")
	private BigDecimal handlingFeeAmount;

	@Column(name = "uatp_amount")
	private BigDecimal uatpAmount;

	@Column(name = "file_id")
	private Long fileId;

	public Long getFileId() {

		return fileId;
	}

	public void setFileId(Long fileId) {

		this.fileId = fileId;
	}

	public BigDecimal getUatpAmount() {

		return uatpAmount;
	}

	public void setUatpAmount(BigDecimal uatpAmount) {

		this.uatpAmount = uatpAmount;
	}

	public BigDecimal getHandlingFeeAmount() {

		return handlingFeeAmount;
	}

	public void setHandlingFeeAmount(BigDecimal handlingFeeAmount) {

		this.handlingFeeAmount = handlingFeeAmount;
	}

	public Integer getFlownRevenueId() {

		return flownRevenueId;
	}

	public void setFlownRevenueId(Integer flownRevenueId) {

		this.flownRevenueId = flownRevenueId;
	}

	public String getOrderId() {

		return orderId;
	}

	public void setOrderId(String orderId) {

		this.orderId = orderId;
	}

	public String getClientId() {

		return clientId;
	}

	public void setClientId(String clientId) {

		this.clientId = clientId;
	}

	public String getDocumentUniqueId() {

		return documentUniqueId;
	}

	public void setDocumentUniqueId(String documentUniqueId) {

		this.documentUniqueId = documentUniqueId;
	}

	public Integer getBatchKey() {

		return batchKey;
	}

	public void setBatchKey(Integer batchKey) {

		this.batchKey = batchKey;
	}

	public String getBilledCarrierCode() {

		return billedCarrierCode;
	}

	public void setBilledCarrierCode(String billedCarrierCode) {

		this.billedCarrierCode = billedCarrierCode;
	}

	public String getIssueingCarrierCode() {

		return issueingCarrierCode;
	}

	public void setIssueingCarrierCode(String issueingCarrierCode) {

		this.issueingCarrierCode = issueingCarrierCode;
	}

	public String getDocumentNumber() {

		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {

		this.documentNumber = documentNumber;
	}

	public Integer getCouponNumber() {

		return couponNumber;
	}

	public void setCouponNumber(Integer couponNumber) {

		this.couponNumber = couponNumber;
	}

	public String getFlightNumber() {

		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {

		this.flightNumber = flightNumber;
	}

	public Date getUtilizationDate() {

		return utilizationDate;
	}

	public void setUtilizationDate(Date utilizationDate) {

		this.utilizationDate = utilizationDate;
	}

	public String getFromAirport() {

		return fromAirport;
	}

	public void setFromAirport(String fromAirport) {

		this.fromAirport = fromAirport;
	}

	public String getToAirport() {

		return toAirport;
	}

	public void setToAirport(String toAirport) {

		this.toAirport = toAirport;
	}

	public void setSaleCurrencyCode(String saleCurrencyCode) {

		this.saleCurrencyCode = saleCurrencyCode;
	}

	public Character getFlightIndicator() {

		return flightIndicator;
	}

	public void setFlightIndicator(Character flightIndicator) {

		this.flightIndicator = flightIndicator;
	}

	public BigDecimal getGrossAmount() {

		return grossAmount;
	}

	public void setGrossAmount(BigDecimal grossAmount) {

		this.grossAmount = grossAmount;
	}

	public BigDecimal getIscAmount() {

		return iscAmount;
	}

	public void setIscAmount(BigDecimal iscAmount) {

		this.iscAmount = iscAmount;
	}

	public BigDecimal getIscPercentage() {

		return iscPercentage;
	}

	public void setIscPercentage(BigDecimal iscPercentage) {

		this.iscPercentage = iscPercentage;
	}

	public BigDecimal getSurchargeAmount() {

		return surchargeAmount;
	}

	public void setSurchargeAmount(BigDecimal surchargeAmount) {

		this.surchargeAmount = surchargeAmount;
	}

	public String getEsacCode() {

		return esacCode;
	}

	public void setEsacCode(String esacCode) {

		this.esacCode = esacCode;
	}

	public String getRfic() {

		return rfic;
	}

	public void setRfic(String rfic) {

		this.rfic = rfic;
	}

	public String getRfisc() {

		return rfisc;
	}

	public void setRfisc(String rfisc) {

		this.rfisc = rfisc;
	}

	public String getEticketIndicator() {

		return eticketIndicator;
	}

	public void setEticketIndicator(String eticketIndicator) {

		this.eticketIndicator = eticketIndicator;
	}

	public String getProrationSource() {

		return prorationSource;
	}

	public void setProrationSource(String prorationSource) {

		this.prorationSource = prorationSource;
	}

	public String getCodeShareagreementId() {

		return codeShareagreementId;
	}

	public void setCodeShareagreementId(String codeShareagreementId) {

		this.codeShareagreementId = codeShareagreementId;
	}

	public String getOpertaingFlightNumber() {

		return opertaingFlightNumber;
	}

	public void setOpertaingFlightNumber(String opertaingFlightNumber) {

		this.opertaingFlightNumber = opertaingFlightNumber;
	}

	public Date getOperatingFlightDate() {

		return operatingFlightDate;
	}

	public void setOperatingFlightDate(Date operatingFlightDate) {

		this.operatingFlightDate = operatingFlightDate;
	}

	public String getOperatingCarrierCode() {

		return operatingCarrierCode;
	}

	public void setOperatingCarrierCode(String operatingCarrierCode) {

		this.operatingCarrierCode = operatingCarrierCode;
	}

	public String getFnfIndicator() {

		return fnfIndicator;
	}

	public void setFnfIndicator(String fnfIndicator) {

		this.fnfIndicator = fnfIndicator;
	}

	public static long getSerialversionuid() {

		return serialVersionUID;
	}

	public Integer getResponseLevel() {

		return responseLevel;
	}

	public void setResponseLevel(Integer responseLevel) {

		this.responseLevel = responseLevel;
	}

	@Override
	public String toString() {

		return "FlownOALEntity [flownRevenueId=" + flownRevenueId
		          + ", orderId=" + orderId + ", clientId=" + clientId
		          + ", documentUniqueId=" + documentUniqueId + ", batchKey="
		          + batchKey + ", billedCarrierCode=" + billedCarrierCode
		          + ", issueingCarrierCode=" + issueingCarrierCode
		          + ", documentNumber=" + documentNumber + ", couponNumber="
		          + couponNumber + ", flightNumber=" + flightNumber
		          + ", utilizationDate=" + utilizationDate + ", fromAirport="
		          + fromAirport + ", toAirport=" + toAirport
		          + ", saleCurrencyCode=" + saleCurrencyCode
		          + ", prorateCurrency=" + prorateCurrency + ", grossAmount="
		          + grossAmount + ", iscAmount=" + iscAmount
		          + ", iscPercentage=" + iscPercentage + ", taxAmount="
		          + taxAmount + ", surchargeAmount=" + surchargeAmount
		          + ", esacCode=" + esacCode + ", rfic=" + rfic + ", rfisc="
		          + rfisc + ", eticketIndicator=" + eticketIndicator
		          + ", responseLevel=" + responseLevel + ", prorationSource="
		          + prorationSource + ", codeShareagreementId="
		          + codeShareagreementId + ", opertaingFlightNumber="
		          + opertaingFlightNumber + ", operatingFlightDate="
		          + operatingFlightDate + ", operatingCarrierCode="
		          + operatingCarrierCode + ", fnfIndicator=" + fnfIndicator
		          + ", flightIndicator=" + flightIndicator + ", sourceCode="
		          + billingType + "]";
	}

	public String getProrateCurrency() {

		return prorateCurrency;
	}

	public void setProrateCurrency(String prorateCurrency) {

		this.prorateCurrency = prorateCurrency;
	}

	public BigDecimal getTaxAmount() {

		return taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {

		this.taxAmount = taxAmount;
	}

	public String getSaleCurrencyCode() {

		return saleCurrencyCode;
	}

	public String getBillingType() {

		return billingType;
	}

	public void setBillingType(String billingType) {

		this.billingType = billingType;
	}

	@Override
	public int hashCode() {

		final int prime = 31;
		int result = 1;
		result = prime * result
		          + ((batchKey == null) ? 0 : batchKey.hashCode());
		result = prime
		          * result
		          + ((billedCarrierCode == null) ? 0
		                    : billedCarrierCode.hashCode());
		result = prime * result
		          + ((billingType == null) ? 0 : billingType.hashCode());
		result = prime * result
		          + ((couponNumber == null) ? 0 : couponNumber.hashCode());
		result = prime
		          * result
		          + ((documentUniqueId == null) ? 0
		                    : documentUniqueId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		FlownOALEntity other = (FlownOALEntity) obj;
		if (batchKey == null) {
			if (other.batchKey != null) return false;
		}
		else if (!batchKey.equals(other.batchKey)) return false;
		if (billedCarrierCode == null) {
			if (other.billedCarrierCode != null) return false;
		}
		else if (!billedCarrierCode.equals(other.billedCarrierCode))
		     return false;
		if (billingType == null) {
			if (other.billingType != null) return false;
		}
		else if (!billingType.equals(other.billingType)) return false;
		if (couponNumber == null) {
			if (other.couponNumber != null) return false;
		}
		else if (!couponNumber.equals(other.couponNumber)) return false;
		if (documentUniqueId == null) {
			if (other.documentUniqueId != null) return false;
		}
		else if (!documentUniqueId.equals(other.documentUniqueId))
		     return false;
		return true;
	}

}