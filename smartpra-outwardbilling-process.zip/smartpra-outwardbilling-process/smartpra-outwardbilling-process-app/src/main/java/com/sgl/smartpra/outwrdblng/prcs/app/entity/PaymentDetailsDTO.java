package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.math.BigDecimal;

public class PaymentDetailsDTO {

	private Integer transPaymentDetailsId;

	private Integer trnTickId;

	private BigDecimal fopAmount;

	private String fopCurrency;

	private String salesKey;

	private String documentUniqueId;

	private String expiryDate;

	private String formOfPayment;

	private String issueAirLine;

	private String dociment;

	private String ccNo;

	private String ccCompanyCode;

	private String fopDesc;

	private String formOfPaymentAccountNumber;

	private String approvalCode;

	private String remittance;

	private String remittanceDesc;

	private BigDecimal remittanceAmount;

	public Integer getTransPaymentDetailsId() {

		return transPaymentDetailsId;
	}

	public void setTransPaymentDetailsId(Integer transPaymentDetailsId) {

		this.transPaymentDetailsId = transPaymentDetailsId;
	}

	public Integer getTrnTickId() {

		return trnTickId;
	}

	public void setTrnTickId(Integer trnTickId) {

		this.trnTickId = trnTickId;
	}


	public BigDecimal getFopAmount() {

		return fopAmount;
	}

	public void setFopAmount(BigDecimal fopAmount) {

		this.fopAmount = fopAmount;
	}

	public String getFopCurrency() {

		return fopCurrency;
	}

	public void setFopCurrency(String fopCurrency) {

		this.fopCurrency = fopCurrency;
	}

	public String getSalesKey() {

		return salesKey;
	}

	public void setSalesKey(String salesKey) { }

	public String getDocumentUniqueId() {

		return documentUniqueId;
	}

	public void setDocumentUniqueId(String documentUniqueId) {

		this.documentUniqueId = documentUniqueId;
	}

	public String getExpiryDate() {

		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {

		this.expiryDate = expiryDate;
	}

	public String getFormOfPayment() {

		return formOfPayment;
	}

	public void setFormOfPayment(String formOfPayment) {

		this.formOfPayment = formOfPayment;
	}

	public String getIssueAirLine() {

		return issueAirLine;
	}

	public void setIssueAirLine(String issueAirLine) {

		this.issueAirLine = issueAirLine;
	}

	public String getDociment() {

		return dociment;
	}

	public void setDociment(String dociment) {

		this.dociment = dociment;
	}

	public String getCcNo() {

		return ccNo;
	}

	public void setCcNo(String ccNo) {

		this.ccNo = ccNo;
	}

	public String getCcCompanyCode() {

		return ccCompanyCode;
	}

	public void setCcCompanyCode(String ccCompanyCode) {

		this.ccCompanyCode = ccCompanyCode;
	}

	public String getFopDesc() {

		return fopDesc;
	}

	public void setFopDesc(String fopDesc) {

		this.fopDesc = fopDesc;
	}

	public String getFormOfPaymentAccountNumber() {

		return formOfPaymentAccountNumber;
	}

	public void setFormOfPaymentAccountNumber(String formOfPaymentAccountNumber) {

		this.formOfPaymentAccountNumber = formOfPaymentAccountNumber;
	}

	public String getApprovalCode() {

		return approvalCode;
	}

	public void setApprovalCode(String approvalCode) {

		this.approvalCode = approvalCode;
	}

	public String getRemittance() {

		return remittance;
	}

	public void setRemittance(String remittance) {

		this.remittance = remittance;
	}

	public String getRemittanceDesc() {

		return remittanceDesc;
	}

	public void setRemittanceDesc(String remittanceDesc) {

		this.remittanceDesc = remittanceDesc;
	}

	public BigDecimal getRemittanceAmount() {

		return remittanceAmount;
	}

	public void setRemittanceAmount(BigDecimal remittanceAmount) {

		this.remittanceAmount = remittanceAmount;
	}
}
