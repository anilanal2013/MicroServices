package com.sgl.smartpra.outwrdblng.prcs.app.util;

import java.util.HashSet;
import java.util.Set;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("set")
public class SettlementMethod {

	private Set<Settle> settles = new HashSet<>();

	public static class Settle {

		String hc_carrier_type;
		Boolean hc_pas_sys;
		Boolean hc_blng_thr_clrnce;
		String bc_carrier_type;
		Boolean bc_pas_sys;
		Boolean bc_blng_thr_clrnce;
		String settlment_mthod;

		public String getHc_carrier_type() {

			return hc_carrier_type;
		}


		public void setHc_carrier_type(String hc_carrier_type) {

			this.hc_carrier_type = hc_carrier_type;
		}


		public Boolean getHc_pas_sys() {

			return hc_pas_sys;
		}


		public void setHc_pas_sys(Boolean hc_pas_sys) {

			this.hc_pas_sys = hc_pas_sys;
		}


		public Boolean getHc_blng_thr_clrnce() {

			return hc_blng_thr_clrnce;
		}


		public void setHc_blng_thr_clrnce(Boolean hc_blng_thr_clrnce) {

			this.hc_blng_thr_clrnce = hc_blng_thr_clrnce;
		}


		public String getBc_carrier_type() {

			return bc_carrier_type;
		}


		public void setBc_carrier_type(String bc_carrier_type) {

			this.bc_carrier_type = bc_carrier_type;
		}


		public Boolean getBc_pas_sys() {

			return bc_pas_sys;
		}


		public void setBc_pas_sys(Boolean bc_pas_sys) {

			this.bc_pas_sys = bc_pas_sys;
		}


		public Boolean getBc_blng_thr_clrnce() {

			return bc_blng_thr_clrnce;
		}


		public void setBc_blng_thr_clrnce(Boolean bc_blng_thr_clrnce) {

			this.bc_blng_thr_clrnce = bc_blng_thr_clrnce;
		}


		public String getSettlment_mthod() {

			return settlment_mthod;
		}


		public void setSettlment_mthod(String settlment_mthod) {

			this.settlment_mthod = settlment_mthod;
		}

		@Override
		public int hashCode() {

			final int prime = 31;
			int result = 1;
			result = prime
			          * result
			          + ((bc_blng_thr_clrnce == null) ? 0
			                    : bc_blng_thr_clrnce.hashCode());
			result = prime
			          * result
			          + ((bc_carrier_type == null) ? 0
			                    : bc_carrier_type.hashCode());
			result = prime * result
			          + ((bc_pas_sys == null) ? 0 : bc_pas_sys.hashCode());
			result = prime
			          * result
			          + ((hc_blng_thr_clrnce == null) ? 0
			                    : hc_blng_thr_clrnce.hashCode());
			result = prime
			          * result
			          + ((hc_carrier_type == null) ? 0
			                    : hc_carrier_type.hashCode());
			result = prime * result
			          + ((hc_pas_sys == null) ? 0 : hc_pas_sys.hashCode());
			return result;
		}


		@Override
		public boolean equals(Object obj) {

			if (this == obj) return true;
			if (obj == null) return false;
			if (getClass() != obj.getClass()) return false;
			Settle other = (Settle) obj;
			if (bc_blng_thr_clrnce == null) {
				if (other.bc_blng_thr_clrnce != null) return false;
			}
			else if (!bc_blng_thr_clrnce.equals(other.bc_blng_thr_clrnce))
			     return false;
			if (bc_carrier_type == null) {
				if (other.bc_carrier_type != null) return false;
			}
			else if (!bc_carrier_type.equals(other.bc_carrier_type))
			     return false;
			if (bc_pas_sys == null) {
				if (other.bc_pas_sys != null) return false;
			}
			else if (!bc_pas_sys.equals(other.bc_pas_sys)) return false;
			if (hc_blng_thr_clrnce == null) {
				if (other.hc_blng_thr_clrnce != null) return false;
			}
			else if (!hc_blng_thr_clrnce.equals(other.hc_blng_thr_clrnce))
			     return false;
			if (hc_carrier_type == null) {
				if (other.hc_carrier_type != null) return false;
			}
			else if (!hc_carrier_type.equals(other.hc_carrier_type))
			     return false;
			if (hc_pas_sys == null) {
				if (other.hc_pas_sys != null) return false;
			}
			else if (!hc_pas_sys.equals(other.hc_pas_sys)) return false;
			return true;
		}


		@Override
		public String toString() {

			return "Settle [hc_carrier_type=" + hc_carrier_type
			          + ", hc_pas_sys=" + hc_pas_sys
			          + ", hc_blng_thr_clrnce=" + hc_blng_thr_clrnce
			          + ", bc_carrier_type=" + bc_carrier_type
			          + ", bc_pas_sys=" + bc_pas_sys
			          + ", bc_blng_thr_clrnce=" + bc_blng_thr_clrnce
			          + ", settlment_mthod=" + settlment_mthod + "]";
		}

		// getters and setters


	}

	public Set<Settle> getSettles() {

		return settles;
	}

	public void setSettles(Set<Settle> settles) {

		this.settles = settles;
	}

	// getters and setters
}