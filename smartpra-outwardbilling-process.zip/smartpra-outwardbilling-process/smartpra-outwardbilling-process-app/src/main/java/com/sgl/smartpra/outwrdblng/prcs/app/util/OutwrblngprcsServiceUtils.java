package com.sgl.smartpra.outwrdblng.prcs.app.util;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.CarrierDetail;
import com.sgl.smartpra.master.model.CarrierInterlineDetailsModel;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.IntegrationAppFeignClient;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.SmartpraExceptionTransactionIntegrationAppClient;
import com.sgl.smartpra.outwrdblng.prcs.app.dao.OutwrdblngprcDao;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.CurrencyRateIn;
import com.sgl.smartpra.outwrdblng.prcs.app.repository.OtwrdInvcPrcsRpo;
import com.sgl.smartpra.outwrdblng.prcs.app.repository.OwrblngprcsRepo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OutwrblngprcsServiceUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(OutwrblngprcsServiceUtils.class);
	@Autowired
	private OutwrdblngprcDao outwardBillingProcessDao;
	@Autowired
	private SmartpraExceptionTransactionIntegrationAppClient exceptionTransIntgAppClient;
	@Autowired
	private OwrblngprcsRepo owrblngprcsRepo;
	@Autowired
	private OtwrdInvcPrcsRpo outwrdInvcPrcsRpo;
	@Autowired
	private com.sgl.smartpra.outwrdblng.prcs.app.mapper.OutwrblngprcsMapper OutwrblngprcsMapper;
	@Autowired
	private MasterFeignClient masterFeignClient;
	private ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
	private String pattern = "yyyy-MM-dd";
	private SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	@Autowired
	private IntegrationAppFeignClient integrationAppFeignClient;
	static Boolean isDefaultZoneAvlbl = true;
	static Boolean isBllngPrdAvlblForPRI = true;
	static SystemParameter currencyOfListing = null;
	Boolean blngThrClrncFrHseFrBlngCrr;
	Boolean blngThrClrncFrHseFrBldCrr;
	Optional<String> carrierTypeFrBlngCrr;
	Boolean psngrSISFrBlngCrr;
	Optional<String> carrierTypeFrBldgCrr;
	Boolean psngrSISFrBldCrr;
	Boolean errorOccured;
	@Autowired
	com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.GlobalMasterAppFeignClient globalMasterAppFeignClient;
	@Autowired
	SettlementMethod settlementMethod;

	public BigDecimal deriveExchangeRates(String fromCurrency, String toCurrency, LocalDate effectiveDate) {

		List<ExceptionParametersValueModel> parametersValueModelList;
		ExceptionParametersValueModel parametersValueModel;
		CurrencyRateIn currencyRateIn = new CurrencyRateIn();
		BigDecimal exchngrate = null;
		LOGGER.info(" from currency {}  and to currency  {} ", fromCurrency, effectiveDate);
		if (fromCurrency != null && toCurrency != null
		          && effectiveDate != null) {
			currencyRateIn.setCurrencyFromCode(fromCurrency);
			currencyRateIn.setCurrencyToCode(toCurrency);
			currencyRateIn.setRateType("FDR");
			currencyRateIn.setConversionDate(effectiveDate.toString());
			try {
				String date = simpleDateFormat.format(effectiveDate);
				currencyRateIn.setConversionDate(date);
				exchngrate = integrationAppFeignClient.getExchangeRate(currencyRateIn).getExchangeRate();
				LOGGER.info("The exchange rate is  {} ", exchngrate);
			}
			catch (Exception e) {
				exceptionTransactionModel.setExceptionCode(StringLiteralsUtil.ERROR_WHILE_SAVING_IN_OTWRDRPSRY);
				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("ExchangeRate");
				parametersValueModel.setParameterValue(null);
				parametersValueModelList.add(parametersValueModel);
				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			}
		}
		return exchngrate;

	}

	public String getCurrentFy(String clientId) {

		FinancialMonthModel financialMonthModel = null;
		String fy = StringLiteralsUtil.EMPTY_STRING;
		try {
			financialMonthModel = masterFeignClient.getCurrentOpenFinancialMonthForFinancialCalendar(clientId);
		}
		catch (Exception e) {
			LOGGER.error("Error thrown while calling method getCurrentOpenFinancialMonthForFinancialCalendar() ", e.getMessage());
		}
		if (financialMonthModel != null) {
			fy = financialMonthModel.getFinancialYear().substring(0, 2).toUpperCase();
		}
		return fy;
	}

	public String generateInvoiceNo(String clientId, String fy, String carrierCode) {

		LOGGER.debug("Start of generateInvoiceNo() {}", carrierCode);
		String invoiceNo = "";

		String maxInvoiceNo = outwrdInvcPrcsRpo.getMaxInvoiceNo(clientId, new StringBuffer("P").append(carrierCode).append(fy).toString());
		if (StringUtils.isBlank(maxInvoiceNo)) {
			invoiceNo = new StringBuffer("P").append(carrierCode).append(fy).append("00001").toString();
		}
		else {
			Integer subInv = Integer.parseInt(maxInvoiceNo.substring(5));
			subInv++;
			String invoiceSeq = getInvoiceSeq(subInv);
			invoiceNo = new StringBuffer("P").append(carrierCode).append(fy).append(invoiceSeq).toString();
		}
		LOGGER.debug("End of generateInvoiceNo() , the invoice number is {} ", invoiceNo);
		return invoiceNo;
	}
	
	
	public boolean isACHMember(CarrierInterlineDetailsModel carrierInterlineDetailsModel) {
		Objects.requireNonNull(carrierInterlineDetailsModel);
		Boolean passengerSis = carrierInterlineDetailsModel.getPassengerSis().orElse(false);
		String zone = carrierInterlineDetailsModel.getZone().orElse("");
		return passengerSis && zone.equals("B");
	}

	public boolean isICHMember(CarrierInterlineDetailsModel carrierInterlineDetailsModel) {
		Objects.requireNonNull(carrierInterlineDetailsModel);
		Boolean passengerSis = carrierInterlineDetailsModel.getPassengerSis().orElse(false);
		String zone = carrierInterlineDetailsModel.getZone().orElse("");
		return passengerSis && !zone.equals("B");
	}


	public String getInvoiceSeq(Integer subInv) {

		String invoiceSeq = "";
		String subStr = subInv.toString();
		// 00001, 00011, 00111, 01111, 11111
		if (subStr.length() == 1) {
			invoiceSeq = "0000" + subStr;
		}
		else if (subStr.length() == 2) {
			invoiceSeq = "000" + subStr;
		}
		else if (subStr.length() == 3) {
			invoiceSeq = "00" + subStr;
		}
		else if (subStr.length() == 4) {
			invoiceSeq = "0" + subStr;
		}
		else {
			invoiceSeq = subStr;
		}
		return invoiceSeq;
	}

	public String deriveSettlmnt(String bldCrr, String blngCrr) {

		Set<SettlementMethod.Settle> setlmntMethodProps = settlementMethod.getSettles();
		SettlementMethod.Settle setlmntMethod = new SettlementMethod.Settle();

		if (bldCrr != null) {
			List<CarrierInterlineDetailsModel> blngList = null;
			try {
				blngList = masterFeignClient.getListOfCarrierInterlineDetailsByEffectiveDate(bldCrr, null);
				CarrierInterlineDetailsModel one = blngList.get(0);
				psngrSISFrBldCrr = one.getPassengerSis().get();
				blngThrClrncFrHseFrBlngCrr = one.getBillingThruClearingHouse().get();
				Carrier carrier = globalMasterAppFeignClient.getCarrierByCarrierCode(one.getCarrierCode().get());
				if (carrier.getCarrierCode() != null) {
					setlmntMethod.setHc_carrier_type(carrier.getCarrierCode().get());
				}
				else {
					setlmntMethod.setHc_carrier_type(StringLiteralsUtil.EMPTY_STRING);
				}
				setlmntMethod.setBc_carrier_type(carrier.getCarrierCode().get());
				setlmntMethod.setBc_pas_sys(psngrSISFrBldCrr);
				setlmntMethod.setBc_blng_thr_clrnce(blngThrClrncFrHseFrBlngCrr);
			}
			catch (Exception e) {
				this.errorOccured = true;
			}
		}
		if (blngCrr != null) {
			List<CarrierInterlineDetailsModel> bldList = null;
			try {
				bldList = masterFeignClient.getListOfCarrierInterlineDetailsByEffectiveDate(blngCrr, null);
				CarrierInterlineDetailsModel one = bldList.get(0);
				psngrSISFrBlngCrr = bldList.get(0).getPassengerSis().get();
				blngThrClrncFrHseFrBlngCrr = bldList.get(0).getBillingThruClearingHouse().get();
				Carrier carrier = globalMasterAppFeignClient.getCarrierByCarrierCode(one.getCarrierCode().get());
				if (carrier.getCarrierCode() != null) {
					setlmntMethod.setHc_carrier_type(carrier.getCarrierCode().get());
				}
				else {
					setlmntMethod.setHc_carrier_type(StringLiteralsUtil.EMPTY_STRING);
				}
				setlmntMethod.setHc_pas_sys(psngrSISFrBldCrr);
				setlmntMethod.setHc_blng_thr_clrnce(blngThrClrncFrHseFrBlngCrr);
			}
			catch (Exception e) {
			}
		}

		for (SettlementMethod.Settle sett : setlmntMethodProps) {
			if (sett.hashCode() == setlmntMethod.hashCode()) {
				LOGGER.error("Derived the settlement method :{}", sett.getSettlment_mthod());
				return sett.getSettlment_mthod();
			}
		}
		return null;
	}
	
	public String getSettlementMethod(String billedCarrierCode,String billingCarrierCode,String billingMonth, Integer billingPeriod) throws ParseException {
		LocalDate periodsEndDate = getOutwardBillingPeriodsEndDate(billingMonth, billingPeriod);
		CarrierInterlineDetailsModel carrierInterlineDetailsBilledCarrier = getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(periodsEndDate, billedCarrierCode);
		CarrierDetail carrierDetailBilledCarrier = getCarrierDetailByCarrierCodeAndEffectiveDate(periodsEndDate, billedCarrierCode);
		CarrierInterlineDetailsModel carrierInterlineDetailsBillingCarrier = getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(periodsEndDate, billingCarrierCode);
		CarrierDetail carrierDetailBillingCarrier = getCarrierDetailByCarrierCodeAndEffectiveDate(periodsEndDate, billingCarrierCode);
		
		Optional<String> carrierTypeBillingCarrier = carrierDetailBillingCarrier.getCarrierType();
		Optional<String> carrierTypeBilledCarrier = carrierDetailBilledCarrier.getCarrierType();
		Boolean passengerSisBilledCarrier = carrierInterlineDetailsBilledCarrier.getPassengerSis().orElse(false);
		Boolean passengerSisBillingCarrier = carrierInterlineDetailsBillingCarrier.getPassengerSis().orElse(false);
		Boolean billingThruClearingHouseBilledCarrier = carrierInterlineDetailsBilledCarrier.getBillingThruClearingHouse().orElse(false);
		Boolean billingThruClearingHouseBillingCarrier = carrierInterlineDetailsBillingCarrier.getBillingThruClearingHouse().orElse(false);
		
		if(!carrierTypeBillingCarrier.isPresent() || !carrierTypeBilledCarrier.isPresent() || !billingThruClearingHouseBilledCarrier || !billingThruClearingHouseBillingCarrier) {
			return "D";
		} else if(!passengerSisBilledCarrier || !passengerSisBillingCarrier) {
			return "B";
		} else if(carrierTypeBillingCarrier.get().equals("ACH")) {
			return "A";
		} else {
			return "I";
		}
	}
	
	public LocalDate getOutwardBillingPeriodsEndDate(String billingMonth, Integer billingPeriod) {
		Objects.requireNonNull(billingMonth, "BillingMonth is required");
		Objects.requireNonNull(billingPeriod, "BillingPeriod is required");
		return  masterFeignClient.getOutwardBillingPeriodsEndDate(billingMonth, billingPeriod);
	}
	
	public CarrierInterlineDetailsModel getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(
			LocalDate outwardBillingPeriodsEndDate, String carrierNumericCode) throws ParseException {
		CarrierInterlineDetailsModel carrierInterlineDetail = null;
			Objects.requireNonNull(outwardBillingPeriodsEndDate, "Outward Billing Periods End Date is required");
			Objects.requireNonNull(carrierNumericCode, "Carrier Numeric Code is required");
			carrierInterlineDetail = masterFeignClient.getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(
					carrierNumericCode, localDate2String("yyyy-MM-dd", outwardBillingPeriodsEndDate));
		return carrierInterlineDetail;
	}
	
	public CarrierDetail getCarrierDetailByCarrierCodeAndEffectiveDate(
			LocalDate outwardBillingPeriodsEndDate, String carrierNumericCode) throws ParseException {
		CarrierDetail carrierDetail = null;
		Objects.requireNonNull(outwardBillingPeriodsEndDate, "Outward Billing Periods End Date is required");
		Objects.requireNonNull(carrierNumericCode, "Carrier Numeric Code is required");
		carrierDetail = globalMasterAppFeignClient.getCarrierTypeByCarrierCode(carrierNumericCode,
				localDate2String("yyyy-MM-dd", outwardBillingPeriodsEndDate));
		return carrierDetail;
	}
	
	public static String localDate2String(String datePattern, LocalDate localDate) throws ParseException {
		Objects.requireNonNull(datePattern, "date format is required");
		Objects.requireNonNull(localDate, "date is required");
		DateTimeFormatter dateTimeFormatter = getDateTimeFormatter(datePattern);
		return localDate.format(dateTimeFormatter);
	}

	public static DateTimeFormatter getDateTimeFormatter(String d_MMM_yyPattern) {
		final DateTimeFormatter formatterInput = new DateTimeFormatterBuilder().parseCaseInsensitive()
				.appendPattern(d_MMM_yyPattern).toFormatter();
		return formatterInput;
	}

}
