package com.sgl.smartpra.outwrdblng.prcs.app.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.sgl.smartpra.outwrdblng.prcs.app.dao.OutwrdblngprcDao;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.FlownOALEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OtwrdBlngInfoForInvc;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwrdBlngInvocEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.ReIssueRefundOALEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.TicketOrigDetEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.repository.OtwrdInvcPrcsRpo;
import com.sgl.smartpra.outwrdblng.prcs.app.service.OutwblngInvprcsServ;
import com.sgl.smartpra.outwrdblng.prcs.app.util.OutwrblngprcsNatSqlQryies;
import com.sgl.smartpra.outwrdblng.prcs.app.util.StringLiteralsUtil;

@Repository
public class OutwrblngprcsDaoImpl implements OutwrdblngprcDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(OutwblngInvprcsServ.class);
	@PersistenceContext
	private EntityManager manager;
	@Autowired
	private OtwrdInvcPrcsRpo outwrblngprcsRepository;
	String invcGenResponseMsg = null;

	@Override
	public Set<FlownOALEntity> fetchConsolidatedRecords(Integer flightKey, String docID, Integer coupNo,Integer hostCarrierCode) {

		String sqlQuery = OutwrblngprcsNatSqlQryies.CONSOLIDATED_REC_SQL_QUERY;
		Query query = manager.createNativeQuery(sqlQuery, StringLiteralsUtil.FLOWNNAMEDQUERY);
		if (flightKey != null) {
			LOGGER.debug("The flight key is ", flightKey);
			sqlQuery = sqlQuery + "  AND revenue.flight_key=:flight_key ";
			query = manager.createNativeQuery(sqlQuery, StringLiteralsUtil.FLOWNNAMEDQUERY);
			query.setParameter("flight_key", flightKey);
		}
		if (docID != null && coupNo != null) {
			sqlQuery = sqlQuery
			          + "  AND revenue.document_unique_id=:document_unique_id AND revenue.coupon_number=:coupon_number ";
			query = manager.createNativeQuery(sqlQuery, StringLiteralsUtil.FLOWNNAMEDQUERY);
			query.setParameter(StringLiteralsUtil.DOCUMENT_UNIQUE_ID, docID);
			query.setParameter(StringLiteralsUtil.COUPON_NUMBER, coupNo);
		}
		query.setParameter("issue_airline", hostCarrierCode);
		Set<FlownOALEntity> uniqueObjs = new java.util.HashSet<>();
		List<FlownOALEntity> list = query.getResultList();
		uniqueObjs.addAll(list);
		return uniqueObjs;
	}

	@Override
	public Integer markTrnasferFlagInFlownRevenueDet(Character flag, String documentuniqueId) {

		String sqlQuery = "update SmartPRAFlown.flown_revenue_details set outward_trnsfr_flag=:flag where document_unique_id=:document_unique_id";
		Query query = manager.createNativeQuery(sqlQuery);
		query.setParameter("flag", 'Y');
		query.setParameter(StringLiteralsUtil.DOCUMENT_UNIQUE_ID, documentuniqueId);
		return query.executeUpdate();
	}

	@Override
	public Integer markTrnasferFlagInTicktOrign(Character flag, String documentuniqueId) {

		String sqlQuery = "update SmartPRASales.ticket_orgin set outward_trnsfr_flag=:flag where document_unique_id=:document_unique_id";
		Query query = manager.createNativeQuery(sqlQuery);
		query.setParameter("flag", flag);
		query.setParameter(StringLiteralsUtil.DOCUMENT_UNIQUE_ID, documentuniqueId);
		return query.executeUpdate();
	}

	@Override
	public List<TicketOrigDetEntity> getUnProcessedOrigRecrds() {

		Query query = manager.createNativeQuery(OutwrblngprcsNatSqlQryies.TIKT_ORIG_RCRDS, "Salesoutwardbilling");
		return query.getResultList();
	}

	@Override
	public List<ReIssueRefundOALEntity> processReIssueFefundRec(Integer hostCarrier) {

		List<ReIssueRefundOALEntity> finalResult = new ArrayList<>();
		Query query = manager.createNativeQuery(OutwrblngprcsNatSqlQryies.CONSOLIDATED_SALES_REC_QUERY, "ReissueRefundoutwardbilling");
		List<TicketOrigDetEntity> ticktOrg1 = getUnProcessedOrigRecrds();
		for (TicketOrigDetEntity tkt : ticktOrg1) {
			String[] coups = tkt.getOrigCouponNumber().split(",");
			if (coups.length > 0) {
				for (int i = 0; i < coups.length; i++) {
					query.setParameter(StringLiteralsUtil.DOCUMENT_UNIQUE_ID, tkt.getDocumentUniqueId());
					query.setParameter(StringLiteralsUtil.COUPON_NUMBER, coups[i]);
					query.setParameter("iss_airline", hostCarrier);
					List<ReIssueRefundOALEntity> list = query.getResultList();
					finalResult.addAll(list);
				}
			}
			else {
				query.setParameter(StringLiteralsUtil.DOCUMENT_UNIQUE_ID, tkt.getDocumentUniqueId());
				query.setParameter(StringLiteralsUtil.COUPON_NUMBER, tkt.getOrigCouponNumber());
				query.setParameter("iss_airline", hostCarrier);
				List<ReIssueRefundOALEntity> list = query.getResultList();
				finalResult.addAll(list);
			}
		}
		return finalResult;
	}

	@Override
	public List<OtwrdBlngInfoForInvc> getSummarizedInfo(String billingMonth, Integer outwrdBlngPrd) {

		Query query = manager.createNativeQuery(OutwrblngprcsNatSqlQryies.INVOICE_SUMMARIZED_INFO, "OtwrdBlngInfoForInvc");
		query.setParameter(StringLiteralsUtil.BILLING_PERIOD, outwrdBlngPrd);
		query.setParameter("billing_month", billingMonth);
		List<OtwrdBlngInfoForInvc> list = (List<OtwrdBlngInfoForInvc>) query.getResultList();
		return list;
	}

	@Override
	public Integer getTransactionCount(OtwrdBlngInfoForInvc invs) {

		Query query = manager.createNativeQuery(OutwrblngprcsNatSqlQryies.OUTWARD_BLNG_TRANSACTION_COUNT);
		query.setParameter(StringLiteralsUtil.BILLED_CARRIER_CODE, invs.getBilledCarrierCode());
		query.setParameter(StringLiteralsUtil.BILLING_MONTH, invs.getBillingMonth());
		query.setParameter(StringLiteralsUtil.BILLING_PERIOD, invs.getBillingPeriod());
		query.setParameter(StringLiteralsUtil.SOURCE_CODE, invs.getSourceCode());
		query.setParameter(StringLiteralsUtil.CURRENCY_OF_INVOICE, invs.getCurrencyOfInvoice());
		return (Integer) query.getSingleResult();
	}

	@Override
	public String saveInvoiceInfo(OtwrdBlngInfoForInvc invs, OutwrdBlngInvocEntity outwrdBlngInvocEntity) {

		LOGGER.info("Fetching the summaraized prorated values ");
		Query query = manager.createNativeQuery(OutwrblngprcsNatSqlQryies.SUMMARAIZED_INFO_GROUP_BY);
		query.setParameter(StringLiteralsUtil.BILLED_CARRIER_CODE, invs.getBilledCarrierCode());
		query.setParameter(StringLiteralsUtil.BILLING_MONTH, invs.getBillingMonth());
		query.setParameter(StringLiteralsUtil.BILLING_PERIOD, invs.getBillingPeriod());
		query.setParameter(StringLiteralsUtil.SOURCE_CODE, invs.getSourceCode());
		query.setParameter(StringLiteralsUtil.CURRENCY_OF_INVOICE, invs.getCurrencyOfInvoice());
		List<Object[]> list = query.getResultList();
		LOGGER.debug("Fetched and size is {} ", list.size());
		BigDecimal def = BigDecimal.valueOf(0.0);
		for (Object[] obj : list) {
			BigDecimal gross = (obj[5] == null) ? def : (BigDecimal) obj[5];
			BigDecimal isc = (obj[8] == null) ? def : (BigDecimal) obj[8];
			BigDecimal tax = (obj[6] == null) ? def : (BigDecimal) obj[6];
			BigDecimal hf = (obj[2] == null) ? def : (BigDecimal) obj[2];
			BigDecimal oc = (obj[3] == null) ? def : (BigDecimal) obj[3];
			BigDecimal uatp = (obj[0] == null) ? def : (BigDecimal) obj[0];
			BigDecimal vat = (obj[7] == null) ? def : (BigDecimal) obj[7];
			outwrdBlngInvocEntity.setUatpAmount(uatp);
			outwrdBlngInvocEntity.setHandingFeeAmount(hf);
			outwrdBlngInvocEntity.setOtherCommAmount(oc);
			outwrdBlngInvocEntity.setGrossAmount(gross);
			outwrdBlngInvocEntity.setTaxAmount(tax);
			outwrdBlngInvocEntity.setVatCommAmount(vat);
			outwrdBlngInvocEntity.setIscAmount(isc);
			BigDecimal netAmount = gross.subtract(isc).add(tax).subtract(hf).subtract(oc).subtract(uatp).subtract(vat);
			outwrdBlngInvocEntity.setNetCommAmount(netAmount);
		}
		LOGGER.info("Calling save in outwrblngprcsRepository ");
		OutwrdBlngInvocEntity savedRec = outwrblngprcsRepository.save(outwrdBlngInvocEntity);
		if (savedRec != null) {
			this.invcGenResponseMsg = "Invoice genaration done successfully for the billing period :"
			          + savedRec.getBillingPeriod();
			LOGGER.debug("Record successfully saved in  outwrblngprcsRepository {} ", invcGenResponseMsg);
			return invcGenResponseMsg;
		}
		else {
			LOGGER.debug("Record not saved in  outwrblngprcsRepository {} ", invcGenResponseMsg);
			return invcGenResponseMsg;
		}
	}

	@Override
	public Integer changeCouponStatusAndUpdIvnNumbr(OtwrdBlngInfoForInvc invs, String invoiceNumber) {

		String sqlQuery = "update SmartPRAInterline.outward_billing_details set coupon_status='OW',invoice_number=:invoice_number where  "
		          + "  billed_carrier_code=:billed_carrier_code AND  billing_month=:billing_month AND  billing_period=:billing_period AND source_code=:source_code AND currency_of_invoice=:currency_of_invoice";
		Query query = manager.createNativeQuery(sqlQuery);
		query.setParameter("invoice_number", invoiceNumber);
		query.setParameter(StringLiteralsUtil.BILLED_CARRIER_CODE, invs.getBilledCarrierCode());
		query.setParameter(StringLiteralsUtil.BILLING_MONTH, invs.getBillingMonth());
		query.setParameter(StringLiteralsUtil.BILLING_PERIOD, invs.getBillingPeriod());
		query.setParameter(StringLiteralsUtil.SOURCE_CODE, invs.getSourceCode());
		query.setParameter(StringLiteralsUtil.CURRENCY_OF_INVOICE, invs.getCurrencyOfInvoice());
		return query.executeUpdate();
	}


}