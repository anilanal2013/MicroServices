package com.sgl.smartpra.outwrdblng.prcs.app.mapper;

import org.mapstruct.Mapper;

import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingDetailModel;
import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingInvoiceModel;
import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingTaxModel;
import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingVatModel;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.FlownOALEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingDetail;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingTax;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingVat;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwrdBlngInvocEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.ReIssueRefundOALEntity;

@Mapper
public interface OutwrblngprcsMapper {

	OutwardBillingDetail mapToOutwardBillingMapperEntity(FlownOALEntity flightDataDetails);

	OutwardBillingVat mapToOutwardBillingVat(FlownOALEntity flightDataDetails);

	OutwardBillingDetail mapToOutwardBillingReIssueRefundConsEntity(ReIssueRefundOALEntity flightDataDetails);
	
	OutwardBillingDetail map(OutwardBillingDetailModel outwardBillingDetailModel);

	OutwardBillingDetailModel map(OutwardBillingDetail outwardBillingDetail);

	OutwardBillingVat map(OutwardBillingVatModel outwardBillingVatModel);

	OutwardBillingVatModel map(OutwardBillingVat outwardBillingVat);
	
	OutwardBillingTax map(OutwardBillingTaxModel OutwardBillingTaxModel);

	OutwardBillingTaxModel map(OutwardBillingTax outwardBillingTax);
	
	OutwrdBlngInvocEntity map(OutwardBillingInvoiceModel outwardBillingInvoiceModel);
	
	OutwardBillingInvoiceModel map(OutwrdBlngInvocEntity outwrdBlngInvocEntity);
}
