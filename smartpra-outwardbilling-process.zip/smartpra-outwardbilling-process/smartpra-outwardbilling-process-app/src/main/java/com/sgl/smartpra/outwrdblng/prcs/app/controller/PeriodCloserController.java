package com.sgl.smartpra.outwrdblng.prcs.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.PeriodCloserResponse;
import com.sgl.smartpra.outwrdblng.prcs.app.service.PeriodCloserService;

@RestController
public class PeriodCloserController {

    @Autowired
    PeriodCloserService periodCloserService;

    @PostMapping(value = "/periodclosure/populatebillingperiods")
    public Integer populateBillingPeriods(@RequestParam("billingYear") String billingYear, 
    		@RequestParam(value = "billingMonth", required = false) String billingMonth) {
    	
    	if(billingMonth == null) {
    		return periodCloserService.populateBillingYear(billingYear);
    	}
    	return periodCloserService.populateBillingPeriods(billingYear, billingMonth);
    }
    
    @GetMapping(value = "/periodclosure/searchbillingyearmonth/{billingYear}/{billingMonth}")
    public PeriodCloserResponse searchBillingPeriods(@PathVariable(value = "billingYear", required = true) String billingYear, 
    		@PathVariable(value = "billingMonth", required = true) String billingMonth) {
    	
    	return periodCloserService.searchBillingPeriods(billingYear, billingMonth);
    }
    
    @PutMapping(value = "/periodclosure/billingperiodclosingprocess")
    public OutwardBillingPeriods billingPeriodsClosingProcess(@RequestParam("billingMonth") String billingMonth, 
    		@RequestParam("billingPeriod") Integer billingPeriod) {

    	return periodCloserService.billingPeriodsClosingProcess(billingMonth, billingPeriod);
    }
    
    @GetMapping(value = "/periodclosure/skippingperiodclosingprocess/{billingYear}/{billingMonth}/{billingPeriod}")
    public OutwardBillingPeriods skipPeriodsClosingProcess(@PathVariable(value = "billingYear", required = true) String billingYear, 
    		@PathVariable(value = "billingMonth", required = true) String billingMonth, 
    		@PathVariable("billingPeriod") Integer billingPeriod,
    		@RequestParam("remarks") String remarks) {

    	return periodCloserService.skipPeriodsClosingProcess(billingYear, billingMonth, billingPeriod, remarks);
    }
}
