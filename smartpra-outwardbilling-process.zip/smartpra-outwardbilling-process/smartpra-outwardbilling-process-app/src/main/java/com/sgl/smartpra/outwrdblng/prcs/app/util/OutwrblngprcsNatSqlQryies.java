package com.sgl.smartpra.outwrdblng.prcs.app.util;

public interface OutwrblngprcsNatSqlQryies {

	String CONSOLIDATED_REC_SQL_QUERY = "select flwnCpn.coupon_status,revenue. flown_revenue_id ,revenue.order_id, revenue.client_id ,revenue.flight_key , "
	          + "	 revenue.document_unique_id,revenue.issue_airline,revenue.billed_carrier_code,revenue.document_number,  "
	          + "	 revenue.coupon_number,revenue.from_airport,revenue.to_airport,sale_currency as salecurrency,  "
	          + "	 provisional_currency as proratecurrency ,revenue.provisional_fare as gross ,revenue.provisional_total_tax ,  "
	          + "	 revenue.provisional_yq+revenue.provisional_yr as surchargeamount ,esac.esac_code ,  "
	          + "	 main.rfic as rfic ,main.rfisc as rfisc ,  "
	          + "	 revenue.etkt_indicator,revenue.uatp_amount,revenue.response_level,revenue.handling_fee_amount,  "
	          + "	 main.proration_source ,revenue.flight_date ,coupon.codeshare_agreement_id,operating_flight_number  ,   "
	          + "	 coupon.operating_carrier_num_code ,revenue.flight_indicator ,revenue.document_type ,  "
	          + "	 flwnCpn.file_id ,operating_flight_dept_date,coupon.fnf_indicator,revenue.flight_number,  "
	          + "	 revenue.isc_percentage,revenue.isc_amount from SmartPRAFlown.flown_revenue_details revenue left JOIN  "
	          + "	 SmartPRASales.ticket_coupon coupon on revenue.document_unique_id=coupon.document_unique_id left JOIN   "
	          + "	 SmartPRAFlown.flown_esac esac on esac.document_unique_id=revenue.document_unique_id left JOIN   "
	          + "	 SmartPRASales.ticket_main main on main.document_unique_id=revenue.document_unique_id inner JOIN   "
	          + "	 SmartPRAFlown.flown_coupon  flwnCpn on flwnCpn.document_unique_id=revenue.document_unique_id  "
	          + "	 AND flwnCpn.coupon_number=revenue.coupon_number AND flwnCpn.coupon_status IN ('AA', 'EM ','MC' ) AND revenue.outward_trnsfr_flag='N' AND revenue.issue_airline !=:issue_airline ";

	String INVOICE_SUMMARIZED_INFO = "SELECT document_unique_id,ex_rate_col_to_coi as exchange_rate,currency_of_listing,outward_billing_id,client_id,billed_carrier_code,billing_month,billing_period,source_code,currency_of_invoice FROM "
	          + "SmartPRAInterline.outward_billing_details"
	          + " WHERE currency_of_listing IS NOT NULL AND coupon_status='RB' AND billing_period=:billing_period AND billing_month=:billing_month AND "
	          + "currency_of_invoice IS NOT NULL AND  ex_rate_pro_curr_col IS NOT NULL AND ex_rate_col_to_coi IS NOT NULL ";

	String OUTWARD_BLNG_TRANSACTION_COUNT = "SELECT count(*) AS transaction_count FROM  SmartPRAInterline.outward_billing_details where   "
	          + "  billed_carrier_code=:billed_carrier_code AND  billing_month=:billing_month AND  billing_period=:billing_period AND source_code=:source_code AND currency_of_invoice=:currency_of_invoice";

	String SUMMARAIZED_INFO_GROUP_BY = "SELECT  sum(uatp_amount) AS uatp_amount,sum(surcharge_amount) AS surcharge_amount,sum(handling_fee_amount)  handling_fee_amount,  "
	          + "SUM(other_commission) AS other_commission,count(*) as txn_count , SUM(gross_amount) AS gross_amount,SUM(tax_amount) AS tax_amount,SUM(vat_amount) AS vat_amount ,sum(isc_amount) as isc_amount "
	          + "FROM SmartPRAInterline.outward_billing_details  "
	          + "WHERE "
	          + "billed_carrier_code=:billed_carrier_code AND billing_month=:billing_month AND billing_period=:billing_period "
	          + "AND source_code=:source_code AND currency_of_invoice=:currency_of_invoice "
	          + "GROUP BY billed_carrier_code,billing_month,billing_period,source_code,currency_of_invoice ";

	String FORM_TKT_ORIG = "SELECT tkt_orgin_id,origin.orig_issue_airline,origin.document_unique_id,origin.orig_document, origin.orig_cpn_no,origin.orig_doc_type  FROM SmartPRASales.ticket_orgin origin,SmartPRASales.ticket_sales sales WHERE origin.orig_issue_airline !='157' AND outward_trnsfr_flag='N' AND sales.document_unique_id=origin.document_unique_id AND sales.transaction_code in ('PE') AND sales.process_status IN ('AA','EM','MC')";

	String CONSOLIDATED_SALES_REC_QUERY = StringLiteralsUtil.SALES_OUTWARD_BLNG_SQL_LITERAL
	          + " AND sales.transaction_code = 'PE' "
	          + " AND coupon.util_type in ('E') "
	          + " AND origin.iss_airline !=:iss_airline "
	          + " UNION "
	          + StringLiteralsUtil.SALES_OUTWARD_BLNG_SQL_LITERAL
	          + " AND sales.transaction_code = 'PR'   "
	          + " AND coupon.util_type in ('R')  "
	          + " AND origin.iss_airline !=:iss_airline "
	          + " UNION "
	          + StringLiteralsUtil.SALES_OUTWARD_BLNG_SQL_LITERAL
	          + " AND sales.transaction_code = 'PD'   "
	          + " AND coupon.util_type in ('I')  "
	          + " AND origin.iss_airline=iss_airline ";

	String TIKT_ORIG_RCRDS = StringLiteralsUtil.TICKET_ORIG_RECS_FOR_SALES_OUWRD_BLNG
	          + " AND sales.transaction_code in ('PE')  "
	          + " UNION  "
	          + StringLiteralsUtil.TICKET_ORIG_RECS_FOR_SALES_OUWRD_BLNG
	          + " AND sales.transaction_code in ('PR')  "
	          + " UNION  "
	          + StringLiteralsUtil.TICKET_ORIG_RECS_FOR_SALES_OUWRD_BLNG
	          + " AND sales.transaction_code in ('PR')  ";


}
