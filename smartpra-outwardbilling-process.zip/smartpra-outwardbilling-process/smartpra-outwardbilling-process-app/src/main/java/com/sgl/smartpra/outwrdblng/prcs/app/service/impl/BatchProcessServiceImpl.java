package com.sgl.smartpra.outwrdblng.prcs.app.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.constant.SmartPRAConstant;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingDetail;
import com.sgl.smartpra.outwrdblng.prcs.app.repository.BatchProcessRepository;
import com.sgl.smartpra.outwrdblng.prcs.app.service.BatchProcessService;

@Service
@Transactional
public class BatchProcessServiceImpl implements BatchProcessService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BatchProcessServiceImpl.class);

	@Autowired
	private MasterFeignClient masterFeignClient;

	@Autowired
	private BatchProcessRepository batchProcessRepository;

	int batchNo;
	int recSeqNo;
	private static final String MAXIMUM_RECORDS_IN_BATCHE = "MAXIMUM_RECORDS_IN_BATCH";

	@Override
	public void getBatchGenerationProcess() {

		SystemParameter systemParameter = masterFeignClient.getSystemParameterByparameterNameAndClientId(MAXIMUM_RECORDS_IN_BATCHE, SmartPRAConstant.CLIENT_ID);
		String sysParamRecCount = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
		int maxBatchTxns = Integer.parseInt(sysParamRecCount);
		
		List<String> invoiceNumList = batchProcessRepository.getByBatchSeqNumAndRecordSeqNo();

		for(String invoiceNumber : invoiceNumList) {
			LOGGER.debug("This is invoiceNumber: "+invoiceNumber);
			batchNo = 1001;
			recSeqNo= 1;
			List<OutwardBillingDetail> invoiceList = batchProcessRepository.getListByInvoiceNumber(invoiceNumber);
			for(OutwardBillingDetail invoiceObj : invoiceList) {
				invoiceObj.setBatchSeqNo(batchNo);
				invoiceObj.setRecordSeqNo(recSeqNo);
				LOGGER.debug(invoiceObj.getInvoiceNumber()+ " --> " + batchNo+" --> "+recSeqNo);
				batchProcessRepository.save(invoiceObj);
				if(recSeqNo == maxBatchTxns) {
					batchNo++;
					recSeqNo = 1;
				} else {
					recSeqNo++;
				}
			}
		}
	}

}
