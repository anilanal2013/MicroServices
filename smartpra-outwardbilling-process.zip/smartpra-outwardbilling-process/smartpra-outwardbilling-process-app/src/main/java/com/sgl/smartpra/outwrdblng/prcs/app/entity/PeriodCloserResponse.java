package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.util.List;

import com.sgl.smartpra.master.model.OutwardBillingModule;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;

public class PeriodCloserResponse {

	List<OutwardBillingPeriods> outwardBillingPeriods;
	
	List<OutwardBillingModule> outwardBillingModule;

	public List<OutwardBillingPeriods> getOutwardBillingPeriods() {
		return outwardBillingPeriods;
	}

	public void setOutwardBillingPeriods(List<OutwardBillingPeriods> outwardBillingPeriods) {
		this.outwardBillingPeriods = outwardBillingPeriods;
	}

	public List<OutwardBillingModule> getOutwardBillingModule() {
		return outwardBillingModule;
	}

	public void setOutwardBillingModule(List<OutwardBillingModule> outwardBillingModule) {
		this.outwardBillingModule = outwardBillingModule;
	}

	@Override
	public String toString() {
		return "PeriodCloserResponse [outwardBillingPeriods=" + outwardBillingPeriods + ", outwardBillingModule="
				+ outwardBillingModule + "]";
	}

}
