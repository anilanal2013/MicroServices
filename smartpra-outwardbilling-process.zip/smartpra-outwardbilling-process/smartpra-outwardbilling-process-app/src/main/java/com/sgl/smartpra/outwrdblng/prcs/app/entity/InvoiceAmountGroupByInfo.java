package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.math.BigDecimal;

public class InvoiceAmountGroupByInfo {

	private String outwardBillingId;

	private BigDecimal uatpAmount;

	private BigDecimal taxAmount;

	private BigDecimal vatAmount;

	private Integer txnCount;

	private BigDecimal grossAmount;

	private BigDecimal surchargeAmount;

	private BigDecimal otherCommissionAmount;

	private BigDecimal handlingFeeAmount;

	public String getOutwardBillingId() {

		return outwardBillingId;
	}

	public void setOutwardBillingId(String outwardBillingId) {

		this.outwardBillingId = outwardBillingId;
	}

	public BigDecimal getUatpAmount() {

		return uatpAmount;
	}

	public void setUatpAmount(BigDecimal uatpAmount) {

		this.uatpAmount = uatpAmount;
	}

	public BigDecimal getTaxAmount() {

		return taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {

		this.taxAmount = taxAmount;
	}

	public BigDecimal getVatAmount() {

		return vatAmount;
	}

	public void setVatAmount(BigDecimal vatAmount) {

		this.vatAmount = vatAmount;
	}

	public Integer getTxnCount() {

		return txnCount;
	}

	public void setTxnCount(Integer txnCount) {

		this.txnCount = txnCount;
	}

	public BigDecimal getGrossAmount() {

		return grossAmount;
	}

	public void setGrossAmount(BigDecimal grossAmount) {

		this.grossAmount = grossAmount;
	}

	public BigDecimal getSurchargeAmount() {

		return surchargeAmount;
	}

	public void setSurchargeAmount(BigDecimal surchargeAmount) {

		this.surchargeAmount = surchargeAmount;
	}

	public BigDecimal getOtherCommissionAmount() {

		return otherCommissionAmount;
	}

	public void setOtherCommissionAmount(BigDecimal otherCommissionAmount) {

		this.otherCommissionAmount = otherCommissionAmount;
	}

	public BigDecimal getHandlingFeeAmount() {

		return handlingFeeAmount;
	}

	public void setHandlingFeeAmount(BigDecimal handlingFeeAmount) {

		this.handlingFeeAmount = handlingFeeAmount;
	}

}
