package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.math.BigDecimal;

public class CurrencyRateOut {

	private BigDecimal exchangeRate;

	private BigDecimal outAmount;

	private String errorCode;

	public BigDecimal getExchangeRate() {

		return exchangeRate;
	}

	public void setExchangeRate(BigDecimal exchangeRate) {

		this.exchangeRate = exchangeRate;
	}

	public BigDecimal getOutAmount() {

		return outAmount;
	}

	public void setOutAmount(BigDecimal outAmount) {

		this.outAmount = outAmount;
	}

	public String getErrorCode() {

		return errorCode;
	}

	public void setErrorCode(String errorCode) {

		this.errorCode = errorCode;
	}

}