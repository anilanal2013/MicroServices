package com.sgl.smartpra.outwrdblng.prcs.app.service.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.transaction.Transactional;

import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.CarrierInterlineDetailsModel;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingDetailModel;
import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingTaxModel;
import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingVatModel;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.IntegrationAppFeignClient;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.SalesAppFeignClient;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.SmartpraExceptionTransactionIntegrationAppClient;
import com.sgl.smartpra.outwrdblng.prcs.app.dao.OutwrdblngprcDao;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.FlownOALEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.InvoiceCurrencyConfig;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingDetail;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingTax;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingVat;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.PaymentDetailsDTO;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.ReIssueRefundOALEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.repository.OtwrdBillingVatRepo;
import com.sgl.smartpra.outwrdblng.prcs.app.repository.OutWardBillingTaxRepo;
import com.sgl.smartpra.outwrdblng.prcs.app.repository.OwrblngprcsRepo;
import com.sgl.smartpra.outwrdblng.prcs.app.service.OutwrblngprcsService;
import com.sgl.smartpra.outwrdblng.prcs.app.util.OutwrblngprcsServiceUtils;
import com.sgl.smartpra.outwrdblng.prcs.app.util.StringLiteralsUtil;

@Service
@Transactional(rollbackOn = Exception.class)
public class OutwrblngprcsServiceImpl implements OutwrblngprcsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(OutwrblngprcsServiceImpl.class);
	@Autowired
	private OutwrdblngprcDao outwardBillingProcessDao;
	@Autowired
	private SmartpraExceptionTransactionIntegrationAppClient exceptionTransIntgAppClient;
	@Autowired
	private OutwrblngprcsServiceUtils outwrblngprcsServiceUtils;
	@Autowired
	private IntegrationAppFeignClient integrationAppFeignClient;
	@Autowired
	private SalesAppFeignClient salesAppFeignClient;

	@Autowired
	private OwrblngprcsRepo owrblngprcsRepo;

	@Autowired
	private OtwrdBillingVatRepo otwrdBillingVatRepo;

	@Autowired
	private OutWardBillingTaxRepo outWardBillingTaxRepo;

	@Autowired
	private com.sgl.smartpra.outwrdblng.prcs.app.mapper.OutwrblngprcsMapper OutwrblngprcsMapper;
	@Autowired
	private MasterFeignClient masterFeignClient;
	private ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
	private List<ExceptionParametersValueModel> parametersValueModelList;
	private ExceptionParametersValueModel parametersValueModel;
	private Character transFlag = 'Y';
	private Boolean hasErrorOccuerd = false;
	private String billingMonth = null;
	private Integer billingPeriod = null;
	private LocalDate outwardEndDate = null;
	private BigDecimal primeToCOL = null;
	private BigDecimal cOLTOCOI = null;
	private Boolean isDefaultZoneAvlbl = true;
	private Boolean isBllngPrdAvlblForPRI = true;
	private SystemParameter currencyOfListing = null;
	private BigDecimal def = BigDecimal.valueOf(0.0);
	private Integer hostCarrier = 157;

	@Override
	public Integer processFlownOutwardBillingRecords(Integer flightKey, String docId, Integer coupNum) {

		List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
		LOGGER.info("Calling the method invokeCommonValidationServices()");
		invokeCommonValidationServices();
		Set<FlownOALEntity> consolidateRecords = outwardBillingProcessDao.fetchConsolidatedRecords(flightKey, docId,
				coupNum, hostCarrier);
		LOGGER.debug("The records of oblng flown size {} ", consolidateRecords.size());
		OutwardBillingDetail outwardBillingDetail = new OutwardBillingDetail();
		outwardBillingDetail.setCouponStatus(StringLiteralsUtil.SUCCESSCOUPONSTATUS);
		Integer recInserted = 0;
		for (FlownOALEntity consolidateRecord : consolidateRecords) {
			exceptionTransactionModel = prepareExceptionTransactionModel(consolidateRecord);
			raiseCommonExceptions(consolidateRecord, null);
			String billedCarirerCode = consolidateRecord.getBilledCarrierCode();
			String currencyOfInvoice = null;
			exceptionTransactionModel = prepareExceptionTransactionModel(consolidateRecord);
			outwardBillingDetail = OutwrblngprcsMapper.mapToOutwardBillingMapperEntity(consolidateRecord);
			outwardBillingDetail.setSourceCode(01);
			outwardBillingDetail.setCouponStatus(StringLiteralsUtil.SUCCESSCOUPONSTATUS);
			try {
				List<CarrierInterlineDetailsModel> carrierInterlineDetailsModel = masterFeignClient
						.getListOfCarrierInterlineDetailsByEffectiveDate(consolidateRecord.getBilledCarrierCode(),
								null);
				if (carrierInterlineDetailsModel.size() > 0
						& carrierInterlineDetailsModel.get(0).getBillingCurrency().isPresent()) {
					currencyOfInvoice = carrierInterlineDetailsModel.get(0).getBillingCurrency().get();
					outwardBillingDetail.setCurrencyOfInvoice(currencyOfInvoice);
				}
			} catch (Exception e) {
				LOGGER.info("Interline details  not found");
				ExceptionTransactionModel exceptionTransactionModel = prepareExceptionTransactionModel(
						consolidateRecord);
				exceptionTransactionModel.setExceptionCode(StringLiteralsUtil.CARRIER_INTERLINE_NOT_FOUND);
				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("Carrier Numeric Code");
				parametersValueModel.setParameterValue(null);
				parametersValueModelList.add(parametersValueModel);

				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("Billing Month");
				parametersValueModel.setParameterValue(null);
				parametersValueModelList.add(parametersValueModel);

				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("Billing period");
				parametersValueModel.setParameterValue(null);
				parametersValueModelList.add(parametersValueModel);
				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				try {
					LOGGER.info("Exception raised for Interline details  not found");
					exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
				} catch (Exception e1) {

				}
				outwardBillingDetail.setCouponStatus(StringLiteralsUtil.ERRORCOUPONSTATUS);
				LOGGER.info("get Interline details based on from  and  to zones");
				InvoiceCurrencyConfig.InvoiceCurrency invoiceCurrency = null;
				try {
					invoiceCurrency = masterFeignClient.getCurrencyOfClearence(
							consolidateRecord.getIssueingCarrierCode(), consolidateRecord.getBilledCarrierCode(), null);
					currencyOfInvoice = invoiceCurrency.getCurrency();
					outwardBillingDetail.setCurrencyOfInvoice(currencyOfInvoice);
					LOGGER.info("The invoice currency is " + invoiceCurrency.getCurrency());
				} catch (Exception ex) {
					LOGGER.error("Couldnt get the invoice currency basesd on zone ");
				}
			}
			outwardBillingDetail.setBilledCarrierCode(billedCarirerCode);
			String coL = null;
			if (null != currencyOfListing) {
				outwardBillingDetail.setCurrencyOfListing(currencyOfListing.getParameterRangeFrom().get());
				coL = currencyOfListing.getParameterRangeFrom().get();
			}
			if (billingMonth != null) {
				outwardBillingDetail.setBillingMonth(billingMonth);
			}
			if (billingPeriod != null) {
				outwardBillingDetail.setBillingPeriod(billingPeriod);
			}
			outwardBillingDetail.setCreatedBy(StringLiteralsUtil.COUPVALID_EXCEP_CREATEDBY);
			outwardBillingDetail.setNoOfPassenger(1);
			outwardBillingDetail.setCreatedDate(new Timestamp(new Date().getTime()));
			outwardBillingDetail.setSupplementaryBillingIndi(StringLiteralsUtil.SUPPLEMENTARY_BILLING_IND);
			outwardBillingDetail.setTransitionType(StringLiteralsUtil.TRNSITION_TYPEFOR_FLOWN);
			outwardBillingDetail.setFimInvoiceIndicator("Y");
			outwardBillingDetail.setClientId("QR");
			if (consolidateRecord.getProrateCurrency() != null) {
				outwardBillingDetail.setProrateCurrency(consolidateRecord.getProrateCurrency());
			} else {
				outwardBillingDetail.setProrateCurrency("USD");
			}
			if (consolidateRecord.getResponseLevel() != null) {
				outwardBillingDetail.setAgreementIndicator("OW");
				if (consolidateRecord.getResponseLevel() == 1) {
					outwardBillingDetail.setPmiIndicator("Y");
				} else if (consolidateRecord.getResponseLevel() == 2 || consolidateRecord.getResponseLevel() == 3) {
					outwardBillingDetail.setPmiIndicator("Z");
				} else if (consolidateRecord.getResponseLevel() == 4) {
					outwardBillingDetail.setPmiIndicator("D");
				}
			}
			if (consolidateRecord.getProrateCurrency() != null && currencyOfListing != null) {
				LOGGER.info("started deriving the exchange rate bw atbp curr and curency of listing");
				primeToCOL = outwrblngprcsServiceUtils.deriveExchangeRates(consolidateRecord.getProrateCurrency(),
						currencyOfListing.getParameterRangeFrom().get(), outwardEndDate);
				outwardBillingDetail.setExRateProCurrCol(primeToCOL);
			}
			if (coL != null && currencyOfInvoice != null) {
				LOGGER.info("started deriving the exchange rate bw col curr and coi");
				cOLTOCOI = outwrblngprcsServiceUtils.deriveExchangeRates(coL, currencyOfInvoice, outwardEndDate);
				outwardBillingDetail.setExRateColToCoi(cOLTOCOI);
			}
			outwardBillingDetail.setNetAmount(genarateNetAmnt(outwardBillingDetail));
			try {
				LOGGER.info("Saving the data in outward repository.....: {}", outwardBillingDetail);
				OutwardBillingDetail savedRecord = owrblngprcsRepo.save(outwardBillingDetail);
				outwardBillingProcessDao.markTrnasferFlagInFlownRevenueDet(transFlag,
						consolidateRecord.getDocumentUniqueId());
				LOGGER.info("saves the data in outward repository !");
				recInserted = recInserted + 1;
			} catch (DataIntegrityViolationException e) {
				recInserted = recInserted - 1;
			} catch (Exception e) {
				recInserted = recInserted - 1;
			}
		}
		return recInserted;
	}

	@Override
	public Integer processSalesOutwardBillingsRecords() {

		invokeCommonValidationServices();
		List<ReIssueRefundOALEntity> consolSalesList = outwardBillingProcessDao.processReIssueFefundRec(hostCarrier);
		Set<ReIssueRefundOALEntity> uniqueSalesSet = new HashSet<>();
		uniqueSalesSet.addAll(consolSalesList);
		Integer recInserted = 0;
		for (ReIssueRefundOALEntity con : uniqueSalesSet) {
			exceptionTransactionModel = prepareExceptionTransactionModelForSales(con);
			raiseCommonExceptions(null, con);
			String currencyOfInvoice = null;
			OutwardBillingDetail outwardBillingDetail = OutwrblngprcsMapper
					.mapToOutwardBillingReIssueRefundConsEntity(con);
			outwardBillingDetail.setCouponStatus(StringLiteralsUtil.SUCCESSCOUPONSTATUS);
			List<CarrierInterlineDetailsModel> carrierInterlineDetailsModel = null;
			if (hasErrorOccuerd) {
				outwardBillingDetail.setCouponStatus(StringLiteralsUtil.ERRORCOUPONSTATUS);
			}
			if (con.getTransactionType() != null && con.getTransactionType().equals("PE")) {
				outwardBillingDetail.setTransitionType("RI");
				if (con.getDateOfIssue() != null) {
					outwardBillingDetail.setUtilizationDate(con.getDateOfIssue());
				}
				if (con.getFfyAgreement() != null && con.getFfyAgreement().equals("N")) {
					outwardBillingDetail.setSourceCode(02);
				} else {
					outwardBillingDetail.setSourceCode(95);
				}
			}
			if (con.getTransactionType() != null && con.getTransactionType().equals("PR")) {
				outwardBillingDetail.setTransitionType("RF");
				if (con.getRefundDate() != null) {
					outwardBillingDetail.setUtilizationDate(con.getRefundDate());
				}
				if (con.getFfyAgreement() != null && con.getFfyAgreement().equals("N")) {
					outwardBillingDetail.setSourceCode(03);
				} else {
					outwardBillingDetail.setSourceCode(96);
				}
			}
			if (con.getTransactionType() != null && con.getTransactionType().equals("PD")) {
				if (con.getRefundDate() != null) {
					outwardBillingDetail.setUtilizationDate(con.getRefundDate());
				}
				outwardBillingDetail.setTransitionType("RF");
				if (con.getFfyAgreement() != null && con.getFfyAgreement().equals("N")) {
					outwardBillingDetail.setSourceCode(03);
				} else {
					outwardBillingDetail.setSourceCode(96);
				}
				try {
					List<PaymentDetailsDTO> tktPymnt = salesAppFeignClient.getPaymentDetails(con.getDocumentUniqueId());
					outwardBillingDetail.setGrossAmount(tktPymnt.get(0).getFopAmount());
				} catch (Exception e) {
					outwardBillingDetail.setGrossAmount(null);
				}
			}
			try {
				carrierInterlineDetailsModel = masterFeignClient
						.getListOfCarrierInterlineDetailsByEffectiveDate(con.getBilledCarrierCode(), null);
			} catch (Exception ex) {
				LOGGER.info("Couldnt get carrier interline details ");
			}
			if (!carrierInterlineDetailsModel.isEmpty()) {
				LOGGER.info("THe crrency of invoice size {} ", carrierInterlineDetailsModel.size());
				if (carrierInterlineDetailsModel.get(0).getBillingCurrency().isPresent()) {
					currencyOfInvoice = carrierInterlineDetailsModel.get(0).getBillingCurrency().get();
					outwardBillingDetail.setCurrencyOfInvoice(currencyOfInvoice);
				}
			} else if (carrierInterlineDetailsModel.size() < 0) {
				LOGGER.info("Billing carrier not found...");
				exceptionTransactionModel.setExceptionCode(StringLiteralsUtil.CARRIER_INTERLINE_NOT_FOUND);
				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("Currency Of Invoice");
				parametersValueModel.setParameterValue(null);
				parametersValueModelList.add(parametersValueModel);
				outwardBillingDetail.setCouponStatus(StringLiteralsUtil.ERRORCOUPONSTATUS);
				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				try {
					exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
				} catch (Exception e) {
					LOGGER.info("Couldnt raise an exception for  carrier interline details not found ");

				}
				outwardBillingDetail.setCouponStatus(StringLiteralsUtil.ERRORCOUPONSTATUS);
			}
			if (currencyOfListing != null && null != con.getProrateCurrency()) {
				primeToCOL = outwrblngprcsServiceUtils.deriveExchangeRates(con.getProrateCurrency(),
						currencyOfListing.getParameterRangeFrom().get(), outwardEndDate);
				outwardBillingDetail.setExRateProCurrCol(primeToCOL);
			}
			if (null != currencyOfListing && currencyOfInvoice != null) {
				cOLTOCOI = outwrblngprcsServiceUtils.deriveExchangeRates(
						currencyOfListing.getParameterRangeFrom().get(), currencyOfInvoice, outwardEndDate);
				outwardBillingDetail.setExRateColToCoi(cOLTOCOI);
			}
			if (currencyOfListing != null) {
				outwardBillingDetail.setCurrencyOfListing(currencyOfListing.getParameterRangeFrom().get());
			}
			outwardBillingDetail.setCreatedBy(StringLiteralsUtil.COUPVALID_EXCEP_CREATEDBY);
			outwardBillingDetail.setCreatedDate(new Timestamp(new Date().getTime()));
			if (null != billingMonth) {
				outwardBillingDetail.setBillingMonth(billingMonth);
			}
			if (null != billingPeriod) {
				outwardBillingDetail.setBillingPeriod(billingPeriod);
			}
			if (outwardBillingDetail.getProrateCurrency() == null) {
				outwardBillingDetail.setProrateCurrency("USD");
			}
			outwardBillingDetail.setNetAmount(genarateNetAmnt(outwardBillingDetail));
			outwardBillingDetail.setSupplementaryBillingIndi(StringLiteralsUtil.SUPPLEMENTARY_BILLING_IND);
			try {
				OutwardBillingDetail savedRecord = owrblngprcsRepo.save(outwardBillingDetail);
				LOGGER.info("THe outward billing details is  " + savedRecord);
				recInserted = recInserted + 1;
				outwardBillingProcessDao.markTrnasferFlagInTicktOrign(transFlag, savedRecord.getDocumentUniqueId());
			} catch (ConstraintViolationException e) {
				recInserted = recInserted - 1;
			} catch (Exception e) {
				recInserted = recInserted - 1;
			}
		}
		return recInserted;
	}

	public Boolean invokeCommonValidationServices() {

		LOGGER.info("Execution started for the method invokeCommonValidationServices()");
		try {
			LOGGER.info("fetching  listing currency started ......");
			this.currencyOfListing = masterFeignClient
					.getSystemParameterByparameterName(StringLiteralsUtil.Default_Lising_Currency).get(0);
			LOGGER.debug("The Listing currency got fetched and is {}.....", currencyOfListing);
		} catch (Exception e) {
			this.hasErrorOccuerd = true;
			LOGGER.error("In the catch block of currency of Listing {}", e);
		}
		try {
			LOGGER.info("Fetching default zone started......");
			masterFeignClient.getSystemParameterByparameterName(StringLiteralsUtil.DEFAULT_ZONE).get(0);
			LOGGER.info("Fetching default zone completed......");
		} catch (Exception e) {
			this.hasErrorOccuerd = true;
			this.isDefaultZoneAvlbl = false;
		}
		try {
			LOGGER.info("fetching outward billings has been got started ");
			OutwardBillingPeriods outwardBillingPeriods = masterFeignClient.getCurrentOpenOutwardBillingPeriods();
			this.billingMonth = outwardBillingPeriods.getBillingMonth();
			this.billingPeriod = outwardBillingPeriods.getBillingPeriod();
			this.outwardEndDate = outwardBillingPeriods.getEndDate();
			LOGGER.info("Fetching outward billings has been got ended ");
		} catch (Exception e) {
			hasErrorOccuerd = true;
		}
		try {
			LOGGER.info("Validating the  PRI has been started ......");
			masterFeignClient.getOutwardBillingModuleUsingBillingMonthAndBillingPeriodAndModuleName(billingMonth,
					billingPeriod, "PRI");
			LOGGER.info("Validating the The PRI got ended ");
		} catch (Exception e) {
			this.hasErrorOccuerd = true;
			this.isBllngPrdAvlblForPRI = false;
		}
		return hasErrorOccuerd;
	}

	public void raiseCommonExceptions(FlownOALEntity flownOALEntity, ReIssueRefundOALEntity reissueEntity) {

		LOGGER.info("inside raiseCommonExceptions() ");
		ExceptionTransactionModel exceptionTransactionModel1 = null;
		if (flownOALEntity != null) {
			exceptionTransactionModel1 = prepareExceptionTransactionModel(flownOALEntity);
		} else if (reissueEntity != null) {
			exceptionTransactionModel1 = prepareExceptionTransactionModelForSales(reissueEntity);
		}
		LOGGER.info("Inside raiseCommonExceptions() ");
		if (currencyOfListing != null) {
			LOGGER.info("The currency listing is not found Exception got triggered ");
			exceptionTransactionModel1.setExceptionCode(StringLiteralsUtil.DEFAULT_CURRENCY_NOT_FOUND);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("system parameter  code");
			parametersValueModel.setParameterValue(null);
			parametersValueModelList.add(parametersValueModel);
			exceptionTransactionModel1.setParametersValueList(parametersValueModelList);
			try {
				exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel1);
			} catch (Exception e) {
				LOGGER.error("Couldnt raise an exception for currency listing is not found ");

			}
		}
		if (isDefaultZoneAvlbl == false) {
			LOGGER.info("Raising the  exception started for isDefaultZoneAvlbl");
			exceptionTransactionModel1.setExceptionCode(StringLiteralsUtil.DEFAULT_CURRENCY_NOT_FOUND);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("system parameter  code");
			parametersValueModel.setParameterValue(null);
			parametersValueModelList.add(parametersValueModel);
			exceptionTransactionModel1.setParametersValueList(parametersValueModelList);
			try {
				exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
				LOGGER.info("Raissing the  exception started for isDefaultZoneAvlbl completed");
			} catch (Exception e) {
				LOGGER.error("In catch block of  exception started for isDefaultZoneAvlbl completed");
			}
		}
		if (isBllngPrdAvlblForPRI == false) {
			LOGGER.info("The PRI NOT found exception has been started");
			exceptionTransactionModel.setExceptionCode(StringLiteralsUtil.PRI_NOT_AVAILABLE);
			parametersValueModelList = new ArrayList<>();
			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("Billing Module Name");
			parametersValueModel.setParameterValue("NULL");
			parametersValueModelList.add(parametersValueModel);
			exceptionTransactionModel.setParametersValueList(parametersValueModelList);

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("Outward Billing Period");
			parametersValueModel.setParameterValue("NULL");
			parametersValueModelList.add(parametersValueModel);
			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			try {
				exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
				LOGGER.info("The PRI  not found exception instantiated ");
			} catch (Exception e) {
				LOGGER.info("Couldnt instantiated exception for PRI  not found    ");
			}
		}
		if (billingPeriod == null) {
			LOGGER.info("The Exception triggering for BILLING PERIOD IS NOT FOUND ");
			exceptionTransactionModel1.setExceptionCode(StringLiteralsUtil.OUTWRD_BILING_PRD_NOTFND);
			parametersValueModel = new ExceptionParametersValueModel();
			try {
				exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel1);
				LOGGER.info("Instantiated Exception for BILLING PERIOD IS NOT FOUND ");
			} catch (Exception e) {
				LOGGER.error("Couldnt instantiated Exception for BILLING PERIOD IS NOT FOUND");
			}
		}
	}

	private BigDecimal genarateNetAmnt(OutwardBillingDetail outwardBillingDetail) {

		return (outwardBillingDetail.getGrossAmount() == null ? def : outwardBillingDetail.getGrossAmount())
				.subtract((outwardBillingDetail.getIscAmount() == null ? def : outwardBillingDetail.getIscAmount()))
				.add((outwardBillingDetail.getTaxAmount() == null ? def : outwardBillingDetail.getTaxAmount()))
				.subtract((outwardBillingDetail.getUatpAmount() == null ? def : outwardBillingDetail.getUatpAmount()))
				.subtract((outwardBillingDetail.getHandlingFeeAmount() == null ? def
						: outwardBillingDetail.getHandlingFeeAmount()))
				.subtract((outwardBillingDetail.getOtherCommission() == null ? def
						: outwardBillingDetail.getOtherCommission()))
				.add((outwardBillingDetail.getVatAmount() == null ? def : outwardBillingDetail.getVatAmount()));
	}

	private static ExceptionTransactionModel prepareExceptionTransactionModel(FlownOALEntity flownCoupon) {

		com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel exceptionTransactionModel = new com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel();
		exceptionTransactionModel.setClientId("QR");
		exceptionTransactionModel.setOrderId(String.valueOf(2));
		exceptionTransactionModel.setCreatedBy(StringLiteralsUtil.COUPVALID_EXCEP_CREATEDBY);
		exceptionTransactionModel.setEnvironment(StringLiteralsUtil.COUPVALID_EXCEP_ENVIRONMENT);
		if (null != flownCoupon.getIssueingCarrierCode()) {
			exceptionTransactionModel.setIssuedCarrier(flownCoupon.getIssueingCarrierCode());
		}
		exceptionTransactionModel.setDocumentUniqueId(flownCoupon.getDocumentUniqueId());
		exceptionTransactionModel.setMainDocument(flownCoupon.getDocumentNumber());
		exceptionTransactionModel.setCouponNumber(flownCoupon.getCouponNumber());
		exceptionTransactionModel.setFileId(flownCoupon.getFileId());
		exceptionTransactionModel.setCreatedBy(StringLiteralsUtil.COUPVALID_EXCEP_CREATEDBY);
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setBatchKey1(flownCoupon.getFlightNumber());
		exceptionTransactionModel.setBatchKey2(flownCoupon.getFromAirport());
		exceptionTransactionModel.setBatchKey3(flownCoupon.getToAirport());
		if (null != flownCoupon.getFlightIndicator())
			exceptionTransactionModel.setBatchKey4(flownCoupon.getFlightIndicator().toString());
		exceptionTransactionModel.setBatchKey5(asLocalDateTime(flownCoupon.getUtilizationDate()));
		return exceptionTransactionModel;
	}

	private static ExceptionTransactionModel prepareExceptionTransactionModelForSales(
			ReIssueRefundOALEntity flownCoupon) {

		com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel exceptionTransactionModel = new com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel();
		exceptionTransactionModel.setClientId("QR");
		exceptionTransactionModel.setOrderId(String.valueOf(2));
		exceptionTransactionModel.setCreatedBy(StringLiteralsUtil.COUPVALID_EXCEP_CREATEDBY);
		exceptionTransactionModel.setEnvironment(StringLiteralsUtil.COUPVALID_EXCEP_ENVIRONMENT);
		exceptionTransactionModel.setIssuedCarrier(flownCoupon.getIssueingCarrierCode());
		exceptionTransactionModel.setDocumentUniqueId(flownCoupon.getDocumentUniqueId());
		exceptionTransactionModel.setMainDocument(flownCoupon.getDocumentNumber());
		exceptionTransactionModel.setCouponNumber(flownCoupon.getCouponNumber());
		exceptionTransactionModel.setFileId(flownCoupon.getFileId());
		exceptionTransactionModel.setCreatedBy(StringLiteralsUtil.COUPVALID_EXCEP_CREATEDBY);
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setBatchKey1(flownCoupon.getFlightNumber());
		exceptionTransactionModel.setBatchKey2(flownCoupon.getFromAirport());
		exceptionTransactionModel.setBatchKey3(flownCoupon.getToAirport());
		if (null != flownCoupon.getEticketIndicator())
			exceptionTransactionModel.setBatchKey4(flownCoupon.getEticketIndicator());
		exceptionTransactionModel.setBatchKey5(asLocalDateTime(flownCoupon.getUtilizationDate()));
		return exceptionTransactionModel;
	}

	public static LocalDateTime asLocalDateTime(Date date) {

		return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

	@Override
	public List<OutwardBillingDetail> getOuwrdBlngRecsByInvcNo(String invoiceNumber) {

		return owrblngprcsRepo.getOutwardBillingDetailByinvoiceNumber(invoiceNumber);
	}

	@Override
	public OutwardBillingDetailModel getOuwrdBlngByDocAndCoup(String documentUniqueId, Integer couponNumber) {
		OutwardBillingDetail outwardBillingDetail = owrblngprcsRepo
				.findByDocumentUniqueIdAndCouponNumber(documentUniqueId, couponNumber);
		return OutwrblngprcsMapper.map(outwardBillingDetail);
	}

	@Override
	public OutwardBillingDetailModel createOutwardBillingDetail(OutwardBillingDetailModel outwardBillingDetailModel) {
		OutwardBillingDetail outwardBillingDetail = OutwrblngprcsMapper.map(outwardBillingDetailModel);
		outwardBillingDetail = owrblngprcsRepo.save(outwardBillingDetail);
		Set<OutwardBillingTaxModel> outwardBillingTaxModel = outwardBillingDetailModel.getOutwardBillingTaxModel();
		Set<OutwardBillingVatModel> outwardBillingVatModel = outwardBillingDetailModel.getOutwardBillingVatModel();
		if (Objects.nonNull(outwardBillingTaxModel) && !outwardBillingTaxModel.isEmpty()) {

			for (OutwardBillingTaxModel taxModel : outwardBillingTaxModel) {
				OutwardBillingTax outwardBillingTax = OutwrblngprcsMapper.map(taxModel);
				outwardBillingTax.setOutwardBillingDetail(outwardBillingDetail);
				outWardBillingTaxRepo.save(outwardBillingTax);
			}

		}

		if (Objects.nonNull(outwardBillingVatModel) && !outwardBillingVatModel.isEmpty()) {

			for (OutwardBillingVatModel vatModel : outwardBillingVatModel) {
				OutwardBillingVat outwardBillingVat = OutwrblngprcsMapper.map(vatModel);
				outwardBillingVat.setOutwardBillingDetail(outwardBillingDetail);
				otwrdBillingVatRepo.save(outwardBillingVat);
			}

		}

		return OutwrblngprcsMapper.map(outwardBillingDetail);
	}
}
