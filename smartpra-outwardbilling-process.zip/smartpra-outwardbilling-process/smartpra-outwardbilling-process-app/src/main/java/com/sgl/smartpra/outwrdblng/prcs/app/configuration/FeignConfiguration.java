package com.sgl.smartpra.outwrdblng.prcs.app.configuration;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.currency.model.CurrencyRate;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.CarrierDetail;
import com.sgl.smartpra.master.model.CarrierInterlineDetailsModel;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.OutwardBillingModule;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.CurrencyRateIn;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.CurrencyRateOut;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.InvoiceCurrencyConfig.InvoiceCurrency;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.PaymentDetailsDTO;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface SmartpraExceptionTransactionIntegrationAppClient {

		@PostMapping("/api/init-exceptionmessage")
		public void initExceptionTrasaction(@RequestBody ExceptionTransactionModel exceptionTransactionModel);
	}

	@FeignClient(value = "smartpra-master-app", configuration=FeignErrorDecoder.class)
	public interface MasterFeignClient {

		@GetMapping("/billing-module/billing-month-period-module-name/{billingMonth}/{billingPeriod}/{moduleName}")
		public List<OutwardBillingModule> getOutwardBillingModuleUsingBillingMonthAndBillingPeriodAndModuleName(@PathVariable(value = "billingMonth", required = true) String billingMonth, @PathVariable(value = "billingPeriod", required = true) Integer billingPeriod, @PathVariable(value = "moduleName", required = true) String moduleName);

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(@PathVariable(value = "parameterName") String parameterName);

		@GetMapping("/carriers/{carrierCode}/carrier-interline-details")
		public List<CarrierInterlineDetailsModel> getListOfCarrierInterlineDetailsByEffectiveDate(@PathVariable(value = "carrierCode") String carrierCode, @RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate);

		@GetMapping("/carrier/{carrierCode}/carrier-interline-details")
		public CarrierInterlineDetailsModel getCarrierInterlineDetailsByCarrierCodeAndEffectiveDate(
				@PathVariable(value = "carrierCode") String carrierCode,
				@RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveDate);
		
		@GetMapping("/billing-period/current-open")
		public OutwardBillingPeriods getCurrentOpenOutwardBillingPeriods();

		@GetMapping("/financial-month/current-open")
		public FinancialMonthModel getCurrentOpenFinancialMonthForFinancialCalendar(@RequestParam(value = "clientId", required = false) String clientId);

		@GetMapping("/financial-month/financial-year")
		public FinancialMonthModel getFinancialYearByFinancialMonth(
				@RequestParam(value = "clientId", required = true) String clientId,
				@RequestParam(value = "financialMonth", required = true) String financialMonth);
		@GetMapping("/currency-of-clearence/{hostCarrierNumericCode}/{billingCarrierNumericCode}")
		public InvoiceCurrency getCurrencyOfClearence(@PathVariable(value = "hostCarrierNumericCode") String hostCarrierNumericCode, @PathVariable(value = "billingCarrierNumericCode") String billingCarrierNumericCode, @RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveDate);
		
		@GetMapping("/system-parameters-with-date/clientId/{clientId}/parameterName/{parameterName}")
		public SystemParameter getSystemParameterByparameterNameAndClientId(
				@PathVariable(value = "parameterName", required = true) String parameterName,
				@PathVariable(value = "clientId", required = true) String clientId);
		
		@GetMapping("/billing-period/end-date/{billingMonth}/{billingPeriod}")
		public LocalDate getOutwardBillingPeriodsEndDate(@PathVariable(value = "billingMonth") String billingMonth,
				@PathVariable(value = "billingPeriod") Integer billingPeriod);
		
		@PostMapping("/billing-period")
		public OutwardBillingPeriods createOutwardBillingPeriods(
				@Validated(Create.class) @RequestBody OutwardBillingPeriods outwardBillingPeriods);
		
		@PostMapping("/billing-module")
		public OutwardBillingModule createOutwardBillingModule(
				@Validated(Create.class) @RequestBody OutwardBillingModule outwardBillingModule);
		
		@GetMapping("/billing-period/billing-month")
		public List<OutwardBillingPeriods> getOutwardBillingPeriodsUsingBillingMonth(
				@RequestParam(value = "billingMonth", required = true) String billingMonth,
				@RequestParam(value = "billingPeriod", required = false) Integer billingPeriod);
		
		@GetMapping("/billing-period/billing-month-periods/{billingMonth}/{billingPeriod}")
		public List<OutwardBillingPeriods> getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriodV(
				@PathVariable(value = "billingMonth", required = true) String billingMonth,
				@PathVariable(value = "billingPeriod", required = true) Integer billingPeriod);
	
		@PutMapping("/billing-period/{outwardBillingId}")
		public OutwardBillingPeriods updateOutwardBillingPeriods(
				@PathVariable(value = "outwardBillingId") Integer outwardBillingId,
				@Validated(Update.class) @RequestBody OutwardBillingPeriods outwardBillingPeriods);
		
		@PutMapping("/billing-module/{billingModuleId}")
		public OutwardBillingModule updateOutwardBillingModule(
				@PathVariable(value = "billingModuleId") Integer billingModuleId,
				@Validated(Update.class) @RequestBody OutwardBillingModule outwardBillingModule);
		
		@GetMapping("/billing-module/billing-month")
		public List<OutwardBillingModule> getOutwardBillingModuleUsingBillingMonth(
				@RequestParam(value = "billingMonth", required = true) String billingMonth,
				@RequestParam(value = "billingPeriod", required = false) Integer billingPeriod,
				@RequestParam(value = "moduleName", required = false) String moduleName);
		
		@GetMapping("/billing-period/billing-month-period/{billingMonth}/{billingPeriod}")
		public List<OutwardBillingPeriods> getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriod(
				@PathVariable(value = "billingMonth", required = true) String billingMonth,
				@PathVariable(value = "billingPeriod", required = true) Integer billingPeriod);
	}

	@FeignClient(value = "smartpra-currency-master-app")
	public interface CurrencyMasterFeignClient {

		@GetMapping("/currency")
		public List<CurrencyRate> getAllCurrencyRates(@RequestParam(value = "currencyRateType", required = false) Optional<String> currencyRateType, @RequestParam(value = "currencyFromCode", required = false) Optional<String> currencyFromCode, @RequestParam(value = "currencyToCode", required = false) Optional<String> currencyToCode, @RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate, @RequestParam(value = "effectiveToDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate, @RequestParam(value = "isActive", required = false) Optional<Boolean> isActive);
	}

	@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface IntegrationAppFeignClient {

		@PostMapping("/integ/erd")
		public CurrencyRateOut getExchangeRate(CurrencyRateIn currencyRateIn);
	}

	@FeignClient(value = "smartpra-global-master-app")
	public interface GlobalMasterAppFeignClient {

		@GetMapping("/carriers/{carrierCode}")
		public Carrier getCarrierByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode);

		@GetMapping("/carriers/details/carrierType/{carrierCode}/{effectiveDate}")
		public CarrierDetail getCarrierTypeByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode,
				@PathVariable(value = "effectiveDate") String effectiveDate);
		
		@GetMapping("/carriers/{carrierCode}/details")
		public List<CarrierDetail> getListOfCarrierDetailsByEffectiveDate(@PathVariable(value = "carrierCode") String carrierCode, @RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate);
	}

	@FeignClient(value = "smartpra-sales-app")
	public interface SalesAppFeignClient {

		@GetMapping("/payment-details")
		public List<PaymentDetailsDTO> getPaymentDetails(@RequestParam(value = "documentNumber", required = false) String documentNumber);

	}
}