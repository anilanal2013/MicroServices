package com.sgl.smartpra.outwrdblng.prcs.app.controller;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingDetailModel;
import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingInvoiceModel;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingDetail;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwrdBlngInvocEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.service.OutwblngInvprcsServ;
import com.sgl.smartpra.outwrdblng.prcs.app.service.OutwrblngprcsService;

@RestController
public class OutwrdblngprcsController {

	@Autowired
	public OutwrblngprcsService outwrblngprcsService;

	@Autowired
	public OutwblngInvprcsServ outwrdblngInvcprcsService;


	@GetMapping(value = "/flown-outwardbilling-process")
	public Integer processFlownOutwardBillings() {

		Integer flightKey = null;
		String docId = null;
		Integer coupNum = null;
		return outwrblngprcsService.processFlownOutwardBillingRecords(flightKey, docId, coupNum);
	}

	@GetMapping(value = "/flown-outwardbilling-process/{flight-key}")
	public Integer processFlownOutwardBillingsByFlightKey(@PathVariable(value = "flight-key") Integer flightKey) {

		String docId = null;
		Integer coupNum = null;
		return outwrblngprcsService.processFlownOutwardBillingRecords(flightKey, docId, coupNum);
	}

	@GetMapping(value = "/flown-outwardbilling-process/doc/{doc-id}/coup/{coup-num}")
	public Integer processFlownOutwardBillingsByDocDetails(@PathVariable(value = "doc-id") String docId, @PathVariable(value = "coup-num") Integer coupNum) {

		Integer flightKey = null;
		return outwrblngprcsService.processFlownOutwardBillingRecords(flightKey, docId, coupNum);
	}

	@GetMapping(value = "/sales-outwardbilling-process")
	public Integer processSalesOutwardBillings() {

		return outwrblngprcsService.processSalesOutwardBillingsRecords();
	}

	@GetMapping(value = "/prime-invoice-genaration/billing-period/{billing-period}/billing-month/{billing-month}/process-date/{process-date}")
	public ResponseEntity<String> processInvoiceForPrime(@PathVariable(value = "billing-month") String billingMonth, @PathVariable(value = "billing-period") Integer billingPeriod, @PathVariable(value = "process-date") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate processDate) {

		if (outwrdblngInvcprcsService.getInvcsByBlndPrd(billingMonth, billingPeriod).size() >= 1) {
			return ResponseEntity.status(404).body("For the billing period and month already invoice genarated ");
		}
		String response = outwrdblngInvcprcsService.genarateInvcForPrime(billingMonth, billingPeriod, processDate);
		if (response != null) {
			return ResponseEntity.status(200).body("For the billing period and month  invoice genarated successfully .");
		}
		else {
			return ResponseEntity.status(404).body("For the billing period and month couldnt found the records in outward billing repository  ");
		}
	}

	@GetMapping(value = "/outward-billing-records/invoice-number/{invoice-number}")
	public List<OutwardBillingDetail> getOuwrdBlngRecsByInvcNo(@PathVariable(value = "invoice-number") String invoiceNumber) {


		return outwrblngprcsService.getOuwrdBlngRecsByInvcNo(invoiceNumber);
	}

	@GetMapping(value = "/outward-billing-invoice/billing-period/{billing-period}/billing-month/{billing-month}")
	List<OutwrdBlngInvocEntity> getInvcsByBlndPrd(@PathVariable(value = "billing-month") String billingMonth, @PathVariable(value = "billing-period") Integer billingPeriod) {

		return outwrdblngInvcprcsService.getInvcsByBlndPrd(billingMonth, billingPeriod);
	}

	@GetMapping(value = "/outward-billing-records/document-unique-id/{document-unique-id}/coup/{coup-number}")
	public OutwardBillingDetailModel getOuwrdBlngByDocAndCoup(@PathVariable(value = "document-unique-id") String docNumber,
			@PathVariable(value = "coup-number") Integer coupNumber) {

		return outwrblngprcsService.getOuwrdBlngByDocAndCoup(docNumber, coupNumber);
	}
	
	@PostMapping(value = "/outward-billing-records")
	public OutwardBillingDetailModel createOutwardBillingDetail(@RequestBody OutwardBillingDetailModel outwardBillingDetailModel) {
		return outwrblngprcsService.createOutwardBillingDetail(outwardBillingDetailModel);
	}
	
	@PostMapping(value = "/outward-billing-invoice")
	public OutwardBillingInvoiceModel createOutwardBillingInvoice(@RequestBody OutwardBillingInvoiceModel outwardBillingInvoiceModel) throws ParseException {
		return outwrdblngInvcprcsService.createOutwardBillingInvoice(outwardBillingInvoiceModel);
	}
}
