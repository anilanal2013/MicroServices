package com.sgl.smartpra.outwrdblng.prcs.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingVat;

@Repository
public interface OtwrdBillingVatRepo extends
          JpaRepository<OutwardBillingVat, Long> {




}
