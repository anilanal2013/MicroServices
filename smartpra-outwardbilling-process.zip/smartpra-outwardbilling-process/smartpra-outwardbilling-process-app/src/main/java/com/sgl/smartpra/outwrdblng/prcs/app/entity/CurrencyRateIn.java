package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.math.BigDecimal;

public class CurrencyRateIn {

	private String currencyFromCode;

	private String currencyToCode;

	private String rateType;

	private String conversionDate;

	private BigDecimal amount;

	public String getCurrencyFromCode() {

		return currencyFromCode;
	}

	public void setCurrencyFromCode(String currencyFromCode) {

		this.currencyFromCode = currencyFromCode;
	}

	public String getCurrencyToCode() {

		return currencyToCode;
	}

	public void setCurrencyToCode(String currencyToCode) {

		this.currencyToCode = currencyToCode;
	}

	public String getRateType() {

		return rateType;
	}

	public void setRateType(String rateType) {

		this.rateType = rateType;
	}

	public String getConversionDate() {

		return conversionDate;
	}

	public void setConversionDate(String conversionDate) {

		this.conversionDate = conversionDate;
	}

	public BigDecimal getAmount() {

		return amount;
	}

	public void setAmount(BigDecimal amount) {

		this.amount = amount;
	}

}