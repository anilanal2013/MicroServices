package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

/**
 * @author Venkataraju
 *
 */
@Data
@Entity
@Table(name = "outward_billing_tax")
public class OutwardBillingTax implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "outward_billing_tax_id")
	private Integer outwardBillingTaxId;

	@ManyToOne
	@JoinColumn(name = "outward_billing_id")
	private OutwardBillingDetail outwardBillingDetail;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "order_id")
	private String orderId;;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	@Column(name = "batch_key")
	private Long batchKey;

	@Column(name = "financial_year")
	private String financialYear;

	@Column(name = "billed_carrier_code")
	private String billedCarrierCode;

	@Column(name = "issuing_carrier_code")
	private String issuingCarrierCode;

	@Column(name = "document_number")
	private String documentNumber;

	@Column(name = "coupon_number")
	private Integer couponNumber;

	@Column(name = "check_digit")
	private Integer checkDigit;

	@Column(name = "billing_month")
	private String billingMonth;

	@Column(name = "billing_period")
	private Integer billingPeriod;

	@Column(name = "invoice_number")
	private String invoiceNumber;

	@Column(name = "record_seq_number")
	private Integer recordSeqNumber;

	@Column(name = "tax_code")
	private String taxCode;

	@Column(name = "country_code")
	private String countryCode;

	@Column(name = "tax_serial_no")
	private Integer taxSerialno;

	@Column(name = "tax_applicable_serial_no")
	private Integer taxApplicableSerialNo;

	@Column(name = "tax_amount")
	private BigDecimal taxAmount;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "last_updated_date")
	private LocalDateTime lastUpdatedDate;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;
}
