package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "outward_billing_details")
@NamedQuery(name = "OutwardBillingDetail.findAll", query = "SELECT o FROM OutwardBillingDetail o")
public class OutwardBillingDetail implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "outward_billing_id")
	private Integer outwardBillingId;

	@Column(name = "agreement_indicator")
	private String agreementIndicator;

	@Column(name = "batch_key")
	private long batchKey;

	@Column(name = "batch_seq_no")
	private int batchSeqNo;

	@Column(name = "billed_carrier_code")
	private String billedCarrierCode;

	@Column(name = "billing_month")
	private String billingMonth;

	@Column(name = "billing_period")
	private int billingPeriod;

	@Column(name = "check_digit")
	private int checkDigit;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "codeshare_agreement_id")
	private String codeshareAgreementId;

	@Column(name = "codeshare_carrier_code")
	private String operatingCarrierCode;

	@Column(name = "codeshare_flight_date")
	private Date operatingFlightDate;

	@Column(name = "codeshare_flight_no")
	private String opertaingFlightNumber;

	@Column(name = "coupon_number")
	private int couponNumber;

	@Column(name = "coupon_status")
	private String couponStatus;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;

	@Column(name = "currency_of_invoice")
	private String currencyOfInvoice;

	@Column(name = "currency_of_listing")
	private String currencyOfListing;

	@Column(name = "document_number")
	private String documentNumber;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	@Column(name = "eticket_indicator")
	private String eticketIndicator;

	@Column(name = "ex_rate_col_to_coi")
	private BigDecimal exRateColToCoi;

	@Column(name = "ex_rate_pro_curr_col")
	private BigDecimal exRateProCurrCol;

	@Column(name = "file_id")
	private int fileId;

	@Column(name = "fim_carrier_code")
	private String fimCarrierCode;

	@Column(name = "fim_check_digit")
	private int fimCheckDigit;

	@Column(name = "fim_coupon_no")
	private int fimCouponNo;

	@Column(name = "fim_invoice_indicator")
	private String fimInvoiceIndicator;

	@Column(name = "fim_number")
	private long fimNumber;

	@Column(name = "financial_year")
	private String financialYear;

	@Column(name = "flight_number")
	private String flightNumber;

	@Column(name = "fnf_indicator")
	private String fnfIndicator;

	@Column(name = "from_airport")
	private String fromAirport;

	@Column(name = "gross_amount")
	private BigDecimal grossAmount;

	@Column(name = "handling_fee_amount")
	private BigDecimal handlingFeeAmount;

	@Column(name = "invoice_number")
	private String invoiceNumber;

	@Column(name = "isc_percentage")
	private BigDecimal iscPercentage;

	@Column(name = "issuing_carrier_code")
	private String issueingCarrierCode;

	@Column(name = "jv_financial_year")
	private String jvFinancialYear;

	@Column(name = "jv_number")
	private String jvNumber;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name = "no_of_passenger")
	private int noOfPassenger;

	@Column(name = "order_id")
	private String orderId;

	@Column(name = "other_commission")
	private BigDecimal otherCommission;

	@Column(name = "pmi_indicator")
	private String pmiIndicator;

	@Column(name = "prorate_currency")
	private String prorateCurrency;

	@Column(name = "proration_source")
	private String prorationSource;

	@Column(name = "record_seq_no")
	private int recordSeqNo;

	private String remarks;

	@Column(name = "response_level")
	private int responseLevel;

	@Column(name = "rfic")
	private String rfic;

	@Column(name = "rfisc")
	private String rfisc;

	@Column(name = "sale_currency_code")
	private String saleCurrencyCode;

	@Column(name = "source_code")
	private int sourceCode;

	@Column(name = "spa_carrier")
	private String spaCarrier;

	@Column(name = "spa_code")
	private String spaCode;

	@Column(name = "supplementary_billing_indi")
	private String supplementaryBillingIndi;

	@Column(name = "surcharge_amount")
	private BigDecimal surchargeAmount;

	@Column(name = "tax_amount")
	private BigDecimal taxAmount;

	@Column(name = "net_amount")
	private BigDecimal netAmount;

	@Column(name = "to_airport")
	private String toAirport;

	@Column(name = "transition_type")
	private String transitionType;

	@Column(name = "uatp_amount")
	private BigDecimal uatpAmount;
	
	@OneToMany(mappedBy = "outwardBillingDetail")
	private Set<OutwardBillingVat> outwardBillingVat;
	
	@OneToMany(mappedBy = "outwardBillingDetail")
	private Set<OutwardBillingTax> outwardBillingTax;

	@Column(name = "utilization_date")
	private Date utilizationDate;

	@Column(name = "vat_amount")
	private BigDecimal vatAmount;

	@Column(name = "isc_amount")
	private BigDecimal iscAmount;

	@Column(name = "sac_code")
	public String esacCode;

	public BigDecimal getIscAmount() {

		return iscAmount;
	}

	public void setIscAmount(BigDecimal iscAmount) {

		this.iscAmount = iscAmount;
	}

	public OutwardBillingDetail() {

	}

	public Integer getOutwardBillingId() {

		return this.outwardBillingId;
	}

	public void setOutwardBillingId(Integer outwardBillingId) {

		this.outwardBillingId = outwardBillingId;
	}

	public String getAgreementIndicator() {

		return this.agreementIndicator;
	}

	public BigDecimal getNetAmount() {

		return netAmount;
	}

	public void setNetAmount(BigDecimal netAmount) {

		this.netAmount = netAmount;
	}

	public Date getUtilizationDate() {

		return utilizationDate;
	}

	public void setUtilizationDate(Date utilizationDate) {

		this.utilizationDate = utilizationDate;
	}

	public void setAgreementIndicator(String agreementIndicator) {

		this.agreementIndicator = agreementIndicator;
	}

	public long getBatchKey() {

		return this.batchKey;
	}

	public void setBatchKey(long batchKey) {

		this.batchKey = batchKey;
	}

	public int getBatchSeqNo() {

		return this.batchSeqNo;
	}

	public String getIssueingCarrierCode() {

		return issueingCarrierCode;
	}

	public void setIssueingCarrierCode(String issueingCarrierCode) {

		this.issueingCarrierCode = issueingCarrierCode;
	}

	public static long getSerialversionuid() {

		return serialVersionUID;
	}

	public void setBatchSeqNo(int batchSeqNo) {

		this.batchSeqNo = batchSeqNo;
	}

	public String getBilledCarrierCode() {

		return this.billedCarrierCode;
	}

	public void setBilledCarrierCode(String billedCarrierCode) {

		this.billedCarrierCode = billedCarrierCode;
	}

	public String getBillingMonth() {

		return this.billingMonth;
	}

	public void setBillingMonth(String billingMonth) {

		this.billingMonth = billingMonth;
	}

	public int getBillingPeriod() {

		return this.billingPeriod;
	}

	public void setBillingPeriod(int billingPeriod) {

		this.billingPeriod = billingPeriod;
	}

	public int getCheckDigit() {

		return this.checkDigit;
	}

	public void setCheckDigit(int checkDigit) {

		this.checkDigit = checkDigit;
	}

	public String getClientId() {

		return this.clientId;
	}

	public void setClientId(String clientId) {

		this.clientId = clientId;
	}

	public String getCodeshareAgreementId() {

		return this.codeshareAgreementId;
	}

	public void setCodeshareAgreementId(String codeshareAgreementId) {

		this.codeshareAgreementId = codeshareAgreementId;
	}

	public int getCouponNumber() {

		return this.couponNumber;
	}

	public void setCouponNumber(int couponNumber) {

		this.couponNumber = couponNumber;
	}

	public String getCouponStatus() {

		return this.couponStatus;
	}

	public void setCouponStatus(String couponStatus) {

		this.couponStatus = couponStatus;
	}

	public String getCreatedBy() {

		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {

		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {

		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {

		this.createdDate = createdDate;
	}

	public String getCurrencyOfInvoice() {

		return this.currencyOfInvoice;
	}

	public void setCurrencyOfInvoice(String currencyOfInvoice) {

		this.currencyOfInvoice = currencyOfInvoice;
	}

	public String getCurrencyOfListing() {

		return this.currencyOfListing;
	}

	public void setCurrencyOfListing(String currencyOfListing) {

		this.currencyOfListing = currencyOfListing;
	}

	public String getDocumentNumber() {

		return this.documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {

		this.documentNumber = documentNumber;
	}

	public String getDocumentUniqueId() {

		return this.documentUniqueId;
	}

	public void setDocumentUniqueId(String documentUniqueId) {

		this.documentUniqueId = documentUniqueId;
	}

	public String getEticketIndicator() {

		return this.eticketIndicator;
	}

	public void setEticketIndicator(String eticketIndicator) {

		this.eticketIndicator = eticketIndicator;
	}

	public BigDecimal getExRateColToCoi() {

		return this.exRateColToCoi;
	}

	public void setExRateColToCoi(BigDecimal exRateColToCoi) {

		this.exRateColToCoi = exRateColToCoi;
	}

	public BigDecimal getExRateProCurrCol() {

		return this.exRateProCurrCol;
	}

	public void setExRateProCurrCol(BigDecimal exRateProCurrCol) {

		this.exRateProCurrCol = exRateProCurrCol;
	}

	public int getFileId() {

		return this.fileId;
	}

	public void setFileId(int fileId) {

		this.fileId = fileId;
	}

	public String getFimCarrierCode() {

		return this.fimCarrierCode;
	}

	public void setFimCarrierCode(String fimCarrierCode) {

		this.fimCarrierCode = fimCarrierCode;
	}

	public int getFimCheckDigit() {

		return this.fimCheckDigit;
	}

	public void setFimCheckDigit(int fimCheckDigit) {

		this.fimCheckDigit = fimCheckDigit;
	}

	public int getFimCouponNo() {

		return this.fimCouponNo;
	}

	public void setFimCouponNo(int fimCouponNo) {

		this.fimCouponNo = fimCouponNo;
	}

	public String getFimInvoiceIndicator() {

		return this.fimInvoiceIndicator;
	}

	public void setFimInvoiceIndicator(String fimInvoiceIndicator) {

		this.fimInvoiceIndicator = fimInvoiceIndicator;
	}

	public long getFimNumber() {

		return this.fimNumber;
	}

	public void setFimNumber(long fimNumber) {

		this.fimNumber = fimNumber;
	}

	public String getFinancialYear() {

		return this.financialYear;
	}

	public void setFinancialYear(String financialYear) {

		this.financialYear = financialYear;
	}

	public String getFlightNumber() {

		return this.flightNumber;
	}

	public void setFlightNumber(String flightNumber) {

		this.flightNumber = flightNumber;
	}

	public String getFnfIndicator() {

		return this.fnfIndicator;
	}

	public void setFnfIndicator(String fnfIndicator) {

		this.fnfIndicator = fnfIndicator;
	}

	public String getFromAirport() {

		return this.fromAirport;
	}

	public void setFromAirport(String fromAirport) {

		this.fromAirport = fromAirport;
	}

	public BigDecimal getGrossAmount() {

		return this.grossAmount;
	}

	public void setGrossAmount(BigDecimal grossAmount) {

		this.grossAmount = grossAmount;
	}

	public BigDecimal getHandlingFeeAmount() {

		return this.handlingFeeAmount;
	}

	public void setHandlingFeeAmount(BigDecimal handlingFeeAmount) {

		this.handlingFeeAmount = handlingFeeAmount;
	}

	public String getInvoiceNumber() {

		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {

		this.invoiceNumber = invoiceNumber;
	}

	public BigDecimal getIscPercentage() {

		return this.iscPercentage;
	}

	public void setIscPercentage(BigDecimal iscPercentage) {

		this.iscPercentage = iscPercentage;
	}

	public String getJvFinancialYear() {

		return this.jvFinancialYear;
	}

	public void setJvFinancialYear(String jvFinancialYear) {

		this.jvFinancialYear = jvFinancialYear;
	}

	public String getJvNumber() {

		return this.jvNumber;
	}

	public void setJvNumber(String jvNumber) {

		this.jvNumber = jvNumber;
	}

	public String getLastUpdatedBy() {

		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {

		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {

		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {

		this.lastUpdatedDate = lastUpdatedDate;
	}

	public int getNoOfPassenger() {

		return this.noOfPassenger;
	}

	public void setNoOfPassenger(int noOfPassenger) {

		this.noOfPassenger = noOfPassenger;
	}

	public String getOrderId() {

		return this.orderId;
	}

	public void setOrderId(String orderId) {

		this.orderId = orderId;
	}

	public BigDecimal getOtherCommission() {

		return this.otherCommission;
	}

	public void setOtherCommission(BigDecimal otherCommission) {

		this.otherCommission = otherCommission;
	}

	public String getPmiIndicator() {

		return this.pmiIndicator;
	}

	public void setPmiIndicator(String pmiIndicator) {

		this.pmiIndicator = pmiIndicator;
	}

	public String getProrateCurrency() {

		return this.prorateCurrency;
	}

	public void setProrateCurrency(String prorateCurrency) {

		this.prorateCurrency = prorateCurrency;
	}

	public String getProrationSource() {

		return this.prorationSource;
	}

	public void setProrationSource(String prorationSource) {

		this.prorationSource = prorationSource;
	}

	public int getRecordSeqNo() {

		return this.recordSeqNo;
	}

	public void setRecordSeqNo(int recordSeqNo) {

		this.recordSeqNo = recordSeqNo;
	}

	public String getRemarks() {

		return this.remarks;
	}

	public void setRemarks(String remarks) {

		this.remarks = remarks;
	}

	public int getResponseLevel() {

		return this.responseLevel;
	}

	public void setResponseLevel(int responseLevel) {

		this.responseLevel = responseLevel;
	}

	public String getRfic() {

		return this.rfic;
	}

	public void setRfic(String rfic) {

		this.rfic = rfic;
	}

	public String getRfisc() {

		return this.rfisc;
	}

	public void setRfisc(String rfisc) {

		this.rfisc = rfisc;
	}

	public int getSourceCode() {

		return this.sourceCode;
	}

	public void setSourceCode(int sourceCode) {

		this.sourceCode = sourceCode;
	}

	public String getSpaCarrier() {

		return this.spaCarrier;
	}

	public void setSpaCarrier(String spaCarrier) {

		this.spaCarrier = spaCarrier;
	}

	public String getSpaCode() {

		return this.spaCode;
	}

	public void setSpaCode(String spaCode) {

		this.spaCode = spaCode;
	}

	public String getSupplementaryBillingIndi() {

		return this.supplementaryBillingIndi;
	}

	public void setSupplementaryBillingIndi(String supplementaryBillingIndi) {

		this.supplementaryBillingIndi = supplementaryBillingIndi;
	}

	public BigDecimal getSurchargeAmount() {

		return this.surchargeAmount;
	}

	public void setSurchargeAmount(BigDecimal surchargeAmount) {

		this.surchargeAmount = surchargeAmount;
	}

	public BigDecimal getTaxAmount() {

		return this.taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {

		this.taxAmount = taxAmount;
	}

	public String getToAirport() {

		return this.toAirport;
	}

	public void setToAirport(String toAirport) {

		this.toAirport = toAirport;
	}

	public String getTransitionType() {

		return this.transitionType;
	}

	public void setTransitionType(String transitionType) {

		this.transitionType = transitionType;
	}

	public BigDecimal getUatpAmount() {

		return this.uatpAmount;
	}

	public void setUatpAmount(BigDecimal uatpAmount) {

		this.uatpAmount = uatpAmount;
	}

	public BigDecimal getVatAmount() {

		return this.vatAmount;
	}

	public String getOperatingCarrierCode() {

		return operatingCarrierCode;
	}

	public void setOperatingCarrierCode(String operatingCarrierCode) {

		this.operatingCarrierCode = operatingCarrierCode;
	}

	public Date getOperatingFlightDate() {

		return operatingFlightDate;
	}

	public void setOperatingFlightDate(Date operatingFlightDate) {

		this.operatingFlightDate = operatingFlightDate;
	}

	public String getOpertaingFlightNumber() {

		return opertaingFlightNumber;
	}

	public void setOpertaingFlightNumber(String opertaingFlightNumber) {

		this.opertaingFlightNumber = opertaingFlightNumber;
	}

	public Set<OutwardBillingVat> getOutwardBillingVat() {

		return outwardBillingVat;
	}

	public void setOutwardBillingVat(Set<OutwardBillingVat> outwardBillingVat) {

		this.outwardBillingVat = outwardBillingVat;
	}

	public void setVatAmount(BigDecimal vatAmount) {

		this.vatAmount = vatAmount;
	}

	public String getEsacCode() {

		return esacCode;
	}


	public void setEsacCode(String esacCode) {

		this.esacCode = esacCode;
	}


	@Override
     public String toString() {

	     return "OutwardBillingDetail [outwardBillingId=" + outwardBillingId
	               + ", agreementIndicator=" + agreementIndicator
	               + ", batchKey=" + batchKey + ", batchSeqNo=" + batchSeqNo
	               + ", billedCarrierCode=" + billedCarrierCode
	               + ", billingMonth=" + billingMonth + ", billingPeriod="
	               + billingPeriod + ", checkDigit=" + checkDigit
	               + ", clientId=" + clientId + ", codeshareAgreementId="
	               + codeshareAgreementId + ", operatingCarrierCode="
	               + operatingCarrierCode + ", operatingFlightDate="
	               + operatingFlightDate + ", opertaingFlightNumber="
	               + opertaingFlightNumber + ", couponNumber=" + couponNumber
	               + ", couponStatus=" + couponStatus + ", createdBy="
	               + createdBy + ", createdDate=" + createdDate
	               + ", currencyOfInvoice=" + currencyOfInvoice
	               + ", currencyOfListing=" + currencyOfListing
	               + ", documentNumber=" + documentNumber
	               + ", documentUniqueId=" + documentUniqueId
	               + ", eticketIndicator=" + eticketIndicator
	               + ", exRateColToCoi=" + exRateColToCoi
	               + ", exRateProCurrCol=" + exRateProCurrCol + ", fileId="
	               + fileId + ", fimCarrierCode=" + fimCarrierCode
	               + ", fimCheckDigit=" + fimCheckDigit + ", fimCouponNo="
	               + fimCouponNo + ", fimInvoiceIndicator="
	               + fimInvoiceIndicator + ", fimNumber=" + fimNumber
	               + ", financialYear=" + financialYear + ", flightNumber="
	               + flightNumber + ", fnfIndicator=" + fnfIndicator
	               + ", fromAirport=" + fromAirport + ", grossAmount="
	               + grossAmount + ", handlingFeeAmount=" + handlingFeeAmount
	               + ", invoiceNumber=" + invoiceNumber + ", iscPercentage="
	               + iscPercentage + ", issueingCarrierCode="
	               + issueingCarrierCode + ", jvFinancialYear="
	               + jvFinancialYear + ", jvNumber=" + jvNumber
	               + ", lastUpdatedBy=" + lastUpdatedBy + ", lastUpdatedDate="
	               + lastUpdatedDate + ", noOfPassenger=" + noOfPassenger
	               + ", orderId=" + orderId + ", otherCommission="
	               + otherCommission + ", pmiIndicator=" + pmiIndicator
	               + ", prorateCurrency=" + prorateCurrency
	               + ", prorationSource=" + prorationSource + ", recordSeqNo="
	               + recordSeqNo + ", remarks=" + remarks + ", responseLevel="
	               + responseLevel + ", rfic=" + rfic + ", rfisc=" + rfisc
	               + ", saleCurrencyCode=" + saleCurrencyCode
	               + ", sourceCode=" + sourceCode + ", spaCarrier="
	               + spaCarrier + ", spaCode=" + spaCode
	               + ", supplementaryBillingIndi=" + supplementaryBillingIndi
	               + ", surchargeAmount=" + surchargeAmount + ", taxAmount="
	               + taxAmount + ", netAmount=" + netAmount + ", toAirport="
	               + toAirport + ", transitionType=" + transitionType
	               + ", uatpAmount=" + uatpAmount + ", outwardBillingVat="
	               + outwardBillingVat + ", utilizationDate="
	               + utilizationDate + ", vatAmount=" + vatAmount
	               + ", iscAmount=" + iscAmount + ", esacCode=" + esacCode
	               + "]";
     }

	public String getSaleCurrencyCode() {

		return saleCurrencyCode;
	}

	public void setSaleCurrencyCode(String saleCurrencyCode) {

		this.saleCurrencyCode = saleCurrencyCode;
	}

	@Override
	public int hashCode() {

		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (batchKey ^ (batchKey >>> 32));
		result = prime
		          * result
		          + ((billedCarrierCode == null) ? 0
		                    : billedCarrierCode.hashCode());
		result = prime
		          * result
		          + ((documentUniqueId == null) ? 0
		                    : documentUniqueId.hashCode());
		result = prime * result + sourceCode;
		result = prime
		          * result
		          + ((supplementaryBillingIndi == null) ? 0
		                    : supplementaryBillingIndi.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		OutwardBillingDetail other = (OutwardBillingDetail) obj;
		if (batchKey != other.batchKey) return false;
		if (billedCarrierCode == null) {
			if (other.billedCarrierCode != null) return false;
		}
		else if (!billedCarrierCode.equals(other.billedCarrierCode))
		     return false;
		if (documentUniqueId == null) {
			if (other.documentUniqueId != null) return false;
		}
		else if (!documentUniqueId.equals(other.documentUniqueId))
		     return false;
		if (sourceCode != other.sourceCode) return false;
		if (supplementaryBillingIndi == null) {
			if (other.supplementaryBillingIndi != null) return false;
		}
		else if (!supplementaryBillingIndi.equals(other.supplementaryBillingIndi))
		     return false;
		return true;
	}

}