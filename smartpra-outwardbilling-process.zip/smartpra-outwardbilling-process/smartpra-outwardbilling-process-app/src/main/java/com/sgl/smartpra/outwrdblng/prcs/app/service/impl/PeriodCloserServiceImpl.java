package com.sgl.smartpra.outwrdblng.prcs.app.service.impl;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.sgl.smartpra.common.constant.SmartPRAConstant;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.master.model.OutwardBillingModule;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.PeriodCloserResponse;
import com.sgl.smartpra.outwrdblng.prcs.app.service.PeriodCloserService;
import com.sgl.smartpra.outwrdblng.prcs.app.util.PeriodCloserUtil;

@Service
@Transactional
public class PeriodCloserServiceImpl implements PeriodCloserService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PeriodCloserServiceImpl.class);

	@Autowired
	MasterFeignClient masterFeignClient;

	Map<String, String> exceptionParamsMap;
	ExceptionTransactionModel exceptionTransactionModel;
	List<ExceptionParametersValueModel> parametersValueModelList;
	ExceptionParametersValueModel parametersValueModel;

	OutwardBillingPeriods outwardBillingPeriods;
	OutwardBillingModule outwardBillingModule;
	List<OutwardBillingPeriods> outwardBillingPeriodsList;

	@Override
	public Integer populateBillingYear(String billingYear) {
		Integer count = 0;
		String strMonth = null;
		Calendar cal = Calendar.getInstance();
		DateFormat monFormat = null;
		String stYear = billingYear.substring(0,2);
		String edYear = billingYear.substring(3,5);
		try {
			int sysParamMonNum = getSysParamMonNum();
			monFormat = new SimpleDateFormat("MMM");
			cal.set(Calendar.MONTH, sysParamMonNum);
			for(int i = 1; i <= 12; i++) {
				strMonth = monFormat.format(cal.getTime());
				if(cal.get(Calendar.MONTH) < sysParamMonNum) {
					LOGGER.info("###financialMonthEndYear "+strMonth + "-" + edYear);
					poupatePeriodsForMonth(edYear, strMonth);
					count++;
				} else {
					LOGGER.info("###financialMonthStartYear "+strMonth + "-" + stYear);
					poupatePeriodsForMonth(stYear, strMonth);
					count++;
				}
				cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)+1);
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return count;
	}

	private Integer getSysParamMonNum() throws ParseException {
		String sysParamMonStr = null;
		Calendar cal = Calendar.getInstance();
		Date sysParamDt = null;
		DateFormat dtFormat = new SimpleDateFormat("MMMM");
		sysParamMonStr = getSysParamFinanceMonth();
		sysParamDt = dtFormat.parse(sysParamMonStr);
		cal.setTime(sysParamDt);
		return cal.get(Calendar.MONTH);
	}

	@Override
	public Integer populateBillingPeriods(String billingYear, String billingMonth) {
		String curYear;
		Integer count = 0;
		Boolean isValid;
		try {
			curYear = getBillingYear(billingYear, billingMonth);
			isValid = poupatePeriodsForMonth(curYear, billingMonth);
			if(isValid.equals(true)) {
				count++;
			} else {
				throw new BusinessException("current billingYear and billingMonth details are available.");
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return count;
	}

	private String getBillingYear(String billingYear, String billingMonth) throws ParseException {
		Date monthDt=null;
		DateFormat monFormat = null;
		int sysParamMonNum = getSysParamMonNum();
		Calendar cal = Calendar.getInstance();
		monFormat = new SimpleDateFormat("MMM");
		monthDt = monFormat.parse(billingMonth);
		cal.setTime(monthDt);
		int curMonNum = cal.get(Calendar.MONTH);
		String stYear = billingYear.substring(0,2);
		String edYear = billingYear.substring(3,5);

		if(curMonNum < sysParamMonNum) {
			return edYear;
		} else {
			return stYear;
		}
	}

	private Boolean poupatePeriodsForMonth(String year, String month) throws ParseException {

		Boolean isValid = null;
		Date startDt = null;
		Date endDt = null;

		Instant instant;
		LocalDateTime localDateTime;
		LocalDate srtLocalDate;
		LocalDate edLocalDate;

		Integer lastDt;
		Integer yr = Integer.parseInt(year);

		if (month.equals("Jan") || month.equals("Mar") || month.equals("May") || month.equals("Jul") || month.equals("Aug") || month.equals("Oct") || month.equals("Dec")) {
			lastDt = 31;
		} else if (month.equals("Feb") && (yr % 4 == 0)) {
			lastDt = 29;
		} else if (month.equals("Feb") && (yr % 4 != 0)) {
			lastDt = 28;
		} else {
			lastDt = 30;
		}

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");

		String billingPeriods[][] = new String[5][2];
		billingPeriods[1][0] = "1";
		billingPeriods[1][1] = "7";
		billingPeriods[2][0] = "8";
		billingPeriods[2][1] = "14";
		billingPeriods[3][0] = "15";
		billingPeriods[3][1] = "21";
		billingPeriods[4][0] = "22";
		billingPeriods[4][1] = lastDt.toString();

		for(int i = 1; i < 5; i++) {

			outwardBillingPeriods = new OutwardBillingPeriods();
			outwardBillingPeriods.setClientId(SmartPRAConstant.CLIENT_ID);
			outwardBillingPeriods.setBillingMonth(month + "-" + year);

			outwardBillingPeriods.setBillingPeriod(i);
			startDt = dateFormat.parse(billingPeriods[i][0] + "-" + month + "-" + year);
			instant = Instant.ofEpochMilli(startDt.getTime());
			localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
			srtLocalDate = localDateTime.toLocalDate();
			outwardBillingPeriods.setStartDate(srtLocalDate);

			endDt = dateFormat.parse(billingPeriods[i][1] + "-" + month + "-" + year);
			instant = Instant.ofEpochMilli(endDt.getTime());
			localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
			edLocalDate = localDateTime.toLocalDate();
			outwardBillingPeriods.setEndDate(edLocalDate);

			outwardBillingPeriods.setClosingIndicator(PeriodCloserUtil.CLOSING_INDICATOR_N);
			outwardBillingPeriods.setCreatedBy(PeriodCloserUtil.CREATED_BY);
			outwardBillingPeriods.setCreatedDate(new Timestamp(new java.util.Date().getTime()));

			LOGGER.info("periodCloser: " + outwardBillingPeriods);

			isValid = createBillingPeriod(outwardBillingPeriods);
			if(isValid.equals(true)) {
				poupateOutwardBillingModule(outwardBillingPeriods);
			}
		}
		return isValid;
	}

	private Boolean createBillingPeriod(OutwardBillingPeriods billingPeriodsValues) {
		Boolean isValid = false;
		try {
			OutwardBillingPeriods outwardBillingPeriods1 = null;
			outwardBillingPeriods1 = masterFeignClient.createOutwardBillingPeriods(billingPeriodsValues);
			if (outwardBillingPeriods1 != null) {
				isValid = true;
			}
		} catch(ResponseStatusException respStatException) {
			LOGGER.error("masterFeignClient.createOutwardBillingPeriods() throws exception : " + respStatException.getMessage());
		}
		return isValid;
	}

	private String getSysParamFinanceMonth() {
		SystemParameter billingMonth = masterFeignClient.getSystemParameterByparameterNameAndClientId(PeriodCloserUtil.STARTING_FINANCIAL_MONTH, PeriodCloserUtil.QA);
		return OptionalUtil.getValue(billingMonth.getParameterRangeFrom());
	}

	private void poupateOutwardBillingModule(OutwardBillingPeriods outwardBillingPeriodsData) {

		List<String> moduleNameList = Arrays.asList(PeriodCloserUtil.MISCELLANCEOUS_BILLING, 
				PeriodCloserUtil.PRIME_BILLING, PeriodCloserUtil.REJECTION_BILLING, 
				PeriodCloserUtil.SUPPLEMENTARY_BILLING);
		for (String moduleName : moduleNameList) {
			OutwardBillingModule outwardBillingModule1 = new OutwardBillingModule();
			outwardBillingModule1.setClientId(outwardBillingPeriodsData.getClientId());
			outwardBillingModule1.setBillingMonth(outwardBillingPeriodsData.getBillingMonth());
			outwardBillingModule1.setBillingPeriod(outwardBillingPeriodsData.getBillingPeriod());
			outwardBillingModule1.setModuleName(moduleName);
			outwardBillingModule1.setCloseIndicator(outwardBillingPeriodsData.getClosingIndicator());
			outwardBillingModule1.setCreatedBy(outwardBillingPeriodsData.getCreatedBy());
			createBillingModules(outwardBillingModule1);
		} //close the modules iteration
	}

	private Boolean createBillingModules(OutwardBillingModule outwardBillingModuleData) {
		Boolean isValid = false;
		try {
			OutwardBillingModule outwardBillingModule1;
			outwardBillingModule1 = masterFeignClient.createOutwardBillingModule(outwardBillingModuleData);
			if (outwardBillingModule1 != null) {
				isValid = true;
			}
		} catch(ResponseStatusException respStatException) {
			LOGGER.error("masterFeignClient.createOutwardBillingPeriods() throws exception : " + respStatException.getMessage());
		}
		return isValid;
	}

	@Override
	public PeriodCloserResponse searchBillingPeriods(String billingYear, String billingMonth) {

		PeriodCloserResponse periodCloserResponse = new PeriodCloserResponse();

		String curYear = null;
		try {
			curYear = getBillingYear(billingYear, billingMonth);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String blngMonth = billingMonth + "-" + curYear;
		LOGGER.info("billingMonth Details: " + blngMonth);

		outwardBillingPeriodsList = masterFeignClient.getOutwardBillingPeriodsUsingBillingMonth(blngMonth, null);
		if (outwardBillingPeriodsList.isEmpty()) {
			throw new BusinessException("Please populate the period billingMonth Details..");
		}
		periodCloserResponse.setOutwardBillingPeriods(outwardBillingPeriodsList);

		List<OutwardBillingModule> outwardBillingModuleList = masterFeignClient.getOutwardBillingModuleUsingBillingMonth(blngMonth, null, null);
		if (outwardBillingModuleList.isEmpty()) {
			throw new BusinessException("Please populate the module billingMonth details..");
		}
		periodCloserResponse.setOutwardBillingModule(outwardBillingModuleList);

		// startDate, endDate Conversion to exact Date.
		//tempDateConvertion(outwardBillingPeriodsList);

		return periodCloserResponse;
	}

	/*private void tempDateConvertion(List<OutwardBillingPeriods> outwardBillingPeriodsList) {

		Date tempDt = null;
		Calendar cal = Calendar.getInstance();

		for (OutwardBillingPeriods outwardBillingPeriods : outwardBillingPeriodsList) {
			if (outwardBillingPeriods.getStartDate() != null) {
				tempDt = outwardBillingPeriods.getStartDate();
				cal.setTime(tempDt);
				cal.set(Calendar.HOUR, 23);
				cal.set(Calendar.MINUTE, 59);
				tempDt = cal.getTime();
				outwardBillingPeriods.setStartDate(new java.sql.Date(tempDt.getTime()));
			}
			if (outwardBillingPeriods.getEndDate() != null) {
				tempDt = outwardBillingPeriods.getEndDate();
				cal.setTime(tempDt);
				cal.set(Calendar.HOUR, 23);
				cal.set(Calendar.MINUTE, 59);
				tempDt = cal.getTime();
				outwardBillingPeriods.setEndDate(new java.sql.Date(tempDt.getTime()));
			}
		}
	}*/

	@Override
	public OutwardBillingPeriods billingPeriodsClosingProcess(String billingMonth, Integer billingPeriod) {

		OutwardBillingPeriods outwardBillingPeriods = new OutwardBillingPeriods();
		String periodClose = dailyAndWeeklyParameter();

		List<OutwardBillingPeriods> outwardBillingPeriodsList = masterFeignClient.getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriodV(billingMonth, billingPeriod);

		if(outwardBillingPeriodsList.isEmpty()) {
			throw new BusinessException("List Values are Empty..");
		}
		LOGGER.info("List Values: "+outwardBillingPeriodsList);

		Integer outwardBillingId = outwardBillingPeriodsList.get(0).getOutwardBillingId();
		outwardBillingPeriods.setClientId(outwardBillingPeriodsList.get(0).getClientId());
		outwardBillingPeriods.setBillingMonth(outwardBillingPeriodsList.get(0).getBillingMonth());
		outwardBillingPeriods.setBillingPeriod(outwardBillingPeriodsList.get(0).getBillingPeriod());
		outwardBillingPeriods.setStartDate(outwardBillingPeriodsList.get(0).getStartDate());
		outwardBillingPeriods.setEndDate(outwardBillingPeriodsList.get(0).getEndDate());

		LOGGER.info("startDt: "+outwardBillingPeriods.getStartDate());
		LOGGER.info("endDt: "+outwardBillingPeriods.getEndDate());

		if (periodClose.equalsIgnoreCase(PeriodCloserUtil.PERIOD_CLOSE_DAILY)) {
			outwardBillingPeriods.setClosingIndicator(PeriodCloserUtil.CLOSING_INDICATOR_Y);
		} else if (periodClose.equalsIgnoreCase(PeriodCloserUtil.PERIOD_CLOSE_WEEKLY)) {
			outwardBillingPeriods.setClosingIndicator(PeriodCloserUtil.CLOSING_INDICATOR_Y);
		}

		outwardBillingPeriods.setLastUpdatedBy(PeriodCloserUtil.LAST_UPDATED_BY);
		outwardBillingPeriods.setSkipInd(outwardBillingPeriodsList.get(0).getSkipInd());
		outwardBillingPeriods.setRemarks(outwardBillingPeriodsList.get(0).getRemarks());
		LOGGER.info("####billingPeriodDetails "+outwardBillingPeriods);

		OutwardBillingPeriods updateClosingIndicator = masterFeignClient.updateOutwardBillingPeriods(outwardBillingId, outwardBillingPeriods);
		if(updateClosingIndicator == null) {
			throw new BusinessException("outwardBillingId and outwardBillingPeriods incorrect while updating time");
		}

		LOGGER.info("updatePeroidClosingIndicator: "+updateClosingIndicator);

		billingMonth = updateClosingIndicator.getBillingMonth();
		billingPeriod = updateClosingIndicator.getBillingPeriod();
		List<OutwardBillingModule> outwardBillingModuleList = masterFeignClient.getOutwardBillingModuleUsingBillingMonth(billingMonth, billingPeriod, null);
		if(outwardBillingModuleList.isEmpty()) {
			throw new BusinessException("billingMonth and billingPeriod incorrect.");
		}
		LOGGER.info("ModuleList: "+outwardBillingModuleList);

		OutwardBillingModule outwardBillingModule2 = new OutwardBillingModule();

		for(OutwardBillingModule outwardBillingModule1 : outwardBillingModuleList) {
			Integer billingModuleId = outwardBillingModule1.getBillingModuleId();
			outwardBillingModule2.setClientId(outwardBillingModule1.getClientId());
			outwardBillingModule2.setBillingMonth(outwardBillingModule1.getBillingMonth());
			outwardBillingModule2.setBillingPeriod(outwardBillingModule1.getBillingPeriod());
			outwardBillingModule2.setCloseIndicator(updateClosingIndicator.getClosingIndicator());

			List<String> moduleNameList = Arrays.asList(PeriodCloserUtil.MISCELLANCEOUS_BILLING, 
					PeriodCloserUtil.PRIME_BILLING, PeriodCloserUtil.REJECTION_BILLING, 
					PeriodCloserUtil.SUPPLEMENTARY_BILLING);
			for (String moduleName : moduleNameList) {
				if (PeriodCloserUtil.MISCELLANCEOUS_BILLING.equals(moduleName)) {
					outwardBillingModule2.setModuleName(outwardBillingModule1.getModuleName());
				} else if (PeriodCloserUtil.PRIME_BILLING.equals(moduleName)) {
					outwardBillingModule2.setModuleName(outwardBillingModule1.getModuleName());
				} else if (PeriodCloserUtil.REJECTION_BILLING.equals(moduleName)) {
					outwardBillingModule2.setModuleName(outwardBillingModule1.getModuleName());
				} else if (PeriodCloserUtil.SUPPLEMENTARY_BILLING.equals(moduleName)) {
					outwardBillingModule2.setModuleName(outwardBillingModule1.getModuleName());
				}
				outwardBillingModule2.setLastUpdatedBy(PeriodCloserUtil.LAST_UPDATED_BY);
				outwardBillingModule2.setSkipInd(outwardBillingModule1.getSkipInd());
				LOGGER.info("updatePeroidCloseIndicator: "+outwardBillingModule2);
				masterFeignClient.updateOutwardBillingModule(billingModuleId, outwardBillingModule2);
			}
		}
		return updateClosingIndicator;
	}

	private String dailyAndWeeklyParameter() {
		SystemParameter billingMonth = masterFeignClient.getSystemParameterByparameterNameAndClientId(PeriodCloserUtil.OUTWARD_BILLING_FREQUENCY, SmartPRAConstant.CLIENT_ID);
		return OptionalUtil.getValue(billingMonth.getParameterRangeFrom());
	}

	public OutwardBillingPeriods skipPeriodsClosingProcess(String billingYear, String billingMonth, Integer billingPeriod, String remarks) {

		String curYear = null;
		try {
			curYear = getBillingYear(billingYear, billingMonth);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String blngMonth = billingMonth + "-" + curYear;
		LOGGER.info("billingMonth Details: " + blngMonth);
		outwardBillingPeriodsList = masterFeignClient.getOutwardBillingPeriodsUsingBillingMonth(blngMonth, null);

		if (outwardBillingPeriodsList.isEmpty()) {
			throw new BusinessException("Please populate the billingMonth Details..");
		}

		OutwardBillingPeriods outwardBillingPeriods1 = new OutwardBillingPeriods();

		List<OutwardBillingPeriods> skipBillingPeriodsList = masterFeignClient.getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriod(blngMonth, billingPeriod);

		if(skipBillingPeriodsList.isEmpty()) {
			throw new BusinessException("billingPeriod details are not available.");
		}

		for (OutwardBillingPeriods outwardBillingPeriods : skipBillingPeriodsList) {
			if (outwardBillingPeriods.getBillingPeriod() == billingPeriod) {
				billingPeriod++;
				if (billingPeriod >= 5) {
					throw new BusinessException("Do not skip for all period closer's.");
				}
				List<OutwardBillingPeriods> skipLatstBillingPeriodsList = masterFeignClient.getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriod(blngMonth, billingPeriod);
				if(skipLatstBillingPeriodsList.isEmpty()) {
					throw new BusinessException("The billingPeriod is Empty");
				}
				else {
					skippingBillingPeriodsSkipIndicator(outwardBillingPeriods.getBillingMonth(), outwardBillingPeriods.getBillingPeriod(), remarks);
				}
				for (OutwardBillingPeriods outwardBillingPeriods2 : skipLatstBillingPeriodsList) {
					outwardBillingPeriods1.setOutwardBillingId(outwardBillingPeriods2.getOutwardBillingId());
					outwardBillingPeriods1.setClientId(outwardBillingPeriods2.getClientId());
					outwardBillingPeriods1.setBillingMonth(outwardBillingPeriods2.getBillingMonth());
					outwardBillingPeriods1.setBillingPeriod(outwardBillingPeriods2.getBillingPeriod());
					outwardBillingPeriods1.setStartDate(outwardBillingPeriods2.getStartDate());
					outwardBillingPeriods1.setEndDate(outwardBillingPeriods2.getEndDate());
					outwardBillingPeriods1.setClosingIndicator(outwardBillingPeriods2.getClosingIndicator());
					outwardBillingPeriods1.setCreatedBy(outwardBillingPeriods2.getCreatedBy());
					outwardBillingPeriods1.setCreatedDate(outwardBillingPeriods2.getCreatedDate());
					outwardBillingPeriods1.setLastUpdatedBy(outwardBillingPeriods2.getLastUpdatedBy());
					outwardBillingPeriods1.setLastUpdatedDate(outwardBillingPeriods2.getLastUpdatedDate());
					outwardBillingPeriods1.setSkipInd(outwardBillingPeriods2.getSkipInd());
					outwardBillingPeriods1.setRemarks(outwardBillingPeriods2.getRemarks());
				}
			}
		}
		return outwardBillingPeriods1;
	}

	private void skippingBillingPeriodsSkipIndicator(String billingMonth, Integer billingPeriod, String remarks) {

		List<OutwardBillingPeriods> outwardBillingPeriodsList = masterFeignClient.getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriodV(billingMonth, billingPeriod);

		if(outwardBillingPeriodsList.isEmpty()) {
			throw new BusinessException("List Values are Empty..");
		}
		LOGGER.info("List Values: "+outwardBillingPeriodsList);

		outwardBillingPeriods = new OutwardBillingPeriods();
		Integer outwardBillingId = outwardBillingPeriodsList.get(0).getOutwardBillingId();
		outwardBillingPeriods.setClientId(outwardBillingPeriodsList.get(0).getClientId());
		outwardBillingPeriods.setBillingMonth(outwardBillingPeriodsList.get(0).getBillingMonth());
		outwardBillingPeriods.setBillingPeriod(outwardBillingPeriodsList.get(0).getBillingPeriod());
		outwardBillingPeriods.setStartDate(outwardBillingPeriodsList.get(0).getStartDate());
		outwardBillingPeriods.setEndDate(outwardBillingPeriodsList.get(0).getEndDate());

		LOGGER.info("startDt: "+outwardBillingPeriods.getStartDate());
		LOGGER.info("endDt: "+outwardBillingPeriods.getEndDate());

		outwardBillingPeriods.setClosingIndicator(outwardBillingPeriodsList.get(0).getClosingIndicator());
		outwardBillingPeriods.setLastUpdatedBy("Admin");

		outwardBillingPeriods.setSkipInd(Boolean.TRUE);
		if(outwardBillingPeriods.getRemarks() == null) {
			outwardBillingPeriods.setRemarks(remarks);
		}
		LOGGER.info("###skippingBillingPeriods "+outwardBillingPeriods);

		OutwardBillingPeriods updateClosingIndicator = masterFeignClient.updateOutwardBillingPeriods(outwardBillingId, outwardBillingPeriods);
		if(updateClosingIndicator == null) {
			throw new BusinessException("outwardBillingId and outwardBillingPeriods incorrect while updating time");
		}
		LOGGER.info("updatePeroidClosingIndicator: "+updateClosingIndicator);

		billingMonth = updateClosingIndicator.getBillingMonth();
		billingPeriod = updateClosingIndicator.getBillingPeriod();
		List<OutwardBillingModule> outwardBillingModuleList = masterFeignClient.getOutwardBillingModuleUsingBillingMonth(billingMonth, billingPeriod, null);
		if(outwardBillingModuleList.isEmpty()) {
			throw new BusinessException("billingMonth and billingPeriod incorrect.");
		}
		LOGGER.info("ModuleList: "+outwardBillingModuleList);

		OutwardBillingModule outwardBillingModule2 = new OutwardBillingModule();

		for(OutwardBillingModule outwardBillingModule1 : outwardBillingModuleList) {
			Integer billingModuleId = outwardBillingModule1.getBillingModuleId();
			outwardBillingModule2.setClientId(outwardBillingModule1.getClientId());
			outwardBillingModule2.setBillingMonth(outwardBillingModule1.getBillingMonth());
			outwardBillingModule2.setBillingPeriod(outwardBillingModule1.getBillingPeriod());
			outwardBillingModule2.setCloseIndicator(updateClosingIndicator.getClosingIndicator());

			List<String> moduleNameList = Arrays.asList(PeriodCloserUtil.MISCELLANCEOUS_BILLING, 
					PeriodCloserUtil.PRIME_BILLING, PeriodCloserUtil.REJECTION_BILLING, 
					PeriodCloserUtil.SUPPLEMENTARY_BILLING);
			for (String moduleName : moduleNameList) {
				if (PeriodCloserUtil.MISCELLANCEOUS_BILLING.equals(moduleName)) {
					outwardBillingModule2.setModuleName(outwardBillingModule1.getModuleName());
				} else if (PeriodCloserUtil.PRIME_BILLING.equals(moduleName)) {
					outwardBillingModule2.setModuleName(outwardBillingModule1.getModuleName());
				} else if (PeriodCloserUtil.REJECTION_BILLING.equals(moduleName)) {
					outwardBillingModule2.setModuleName(outwardBillingModule1.getModuleName());
				} else if (PeriodCloserUtil.SUPPLEMENTARY_BILLING.equals(moduleName)) {
					outwardBillingModule2.setModuleName(outwardBillingModule1.getModuleName());
				}
				outwardBillingModule2.setLastUpdatedBy(updateClosingIndicator.getLastUpdatedBy());
				outwardBillingModule2.setSkipInd(updateClosingIndicator.getSkipInd());
				LOGGER.info("updatePeroidCloseIndicator: "+outwardBillingModule2);
				masterFeignClient.updateOutwardBillingModule(billingModuleId, outwardBillingModule2);
			}
		}
	}

}
