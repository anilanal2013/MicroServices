package com.sgl.smartpra.outwrdblng.prcs.app.mapper;

import org.mapstruct.factory.Mappers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperFactory {

	@Bean
	public OutwrblngprcsMapper getFlightDataDetailsMapper() {

		return Mappers.getMapper(OutwrblngprcsMapper.class);
	}

}
