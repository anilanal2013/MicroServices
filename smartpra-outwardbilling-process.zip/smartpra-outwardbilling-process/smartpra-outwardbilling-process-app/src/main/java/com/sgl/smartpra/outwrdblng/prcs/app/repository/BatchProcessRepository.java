package com.sgl.smartpra.outwrdblng.prcs.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingDetail;

@Repository
public interface BatchProcessRepository extends JpaRepository<OutwardBillingDetail, Long> {

	@Query(value = "select distinct a.invoiceNumber from OutwardBillingDetail a where a.batchSeqNo=0 or a.batchSeqNo is null or a.recordSeqNo=0 or a.recordSeqNo is null")
	List<String> getByBatchSeqNumAndRecordSeqNo();

	@Query("select a from OutwardBillingDetail a where a.invoiceNumber = :invoiceNumber")
	List<OutwardBillingDetail> getListByInvoiceNumber(@Param("invoiceNumber") String invoiceNumber);

}
