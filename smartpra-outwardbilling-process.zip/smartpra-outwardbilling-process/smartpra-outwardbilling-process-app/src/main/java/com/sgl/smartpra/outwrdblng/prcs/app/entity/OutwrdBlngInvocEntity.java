package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "ob_invoice")
@Data
public class OutwrdBlngInvocEntity {

	@Id
	@Column(name = "ob_invoice_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer obInvoiceId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "billing_month")
	private String billingMonth;

	@Column(name = "transactions_count")
	private Integer transCount;

	@Column(name = "billing_period")
	private Integer billingPeriod;

	@Column(name = "billed_airline")
	private String billedCarrierCode;

	@Column(name = "settlement_method")
	private String settlemetMethod;

	@Column(name = "invoice_type")
	private String invoiceType;

	@Column(name = "invoice_number")
	private String invoiceNumber;

	@Column(name = "invoice_date")
	private LocalDate invoiceDate;

	@Column(name = "financial_year")
	private String financialYear;

	@Column(name = "billing_code")
	private Integer billingCode;

	@Column(name = "currency_of_listing")
	private String currencyOfListing;

	@Column(name = "currency_of_invoice")
	private String currencyOfInvoice;

	@Column(name = "exchange_rate")
	private BigDecimal exchangeRate;

	@Column(name = "gross_amount")
	private BigDecimal grossAmount;

	@Column(name = "isc_amount")
	private BigDecimal iscAmount;

	@Column(name = "tax_amount")
	private BigDecimal taxAmount;

	@Column(name = "handing_fee_amount")
	private BigDecimal handingFeeAmount;

	@Column(name = "uatp_amount")
	private BigDecimal uatpAmount;

	@Column(name = "other_commission_amount")
	private BigDecimal otherCommAmount;

	@Column(name = "vat_amount")
	private BigDecimal vatCommAmount;

	@Column(name = "net_amount")
	private BigDecimal netCommAmount;

	@Column(name = "status")
	private Character status;

	@Column(name = "included_in_file")
	private Character includedInFile;

	@Column(name = "sis_validated")
	private Character sisValidated;

	@Column(name = "is_accounted")
	private Character isAccounted;

	// @Column(name = "transactions_count")
	// private Integer transactionCount;

	@Column(name = "file_id")
	private Integer fileId;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "last_updated_date")
	private LocalDateTime updatedDate;

	@Column(name = "last_updated_by")
	private String updatedBy;
	
	@Column(name = "source_code")
	private Integer sourceCode;
	
	@Column(name = "billing_type")
	private Character billingType;

}
