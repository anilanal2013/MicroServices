package com.sgl.smartpra.outwrdblng.prcs.app.dao;

import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Repository;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.FlownOALEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OtwrdBlngInfoForInvc;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwrdBlngInvocEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.ReIssueRefundOALEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.TicketOrigDetEntity;

@Repository
public interface OutwrdblngprcDao {

	Integer markTrnasferFlagInFlownRevenueDet(Character flag, String documentuniqueId);

	List<TicketOrigDetEntity> getUnProcessedOrigRecrds();

	Integer markTrnasferFlagInTicktOrign(Character flag, String documentuniqueId);

	List<OtwrdBlngInfoForInvc> getSummarizedInfo(String billingMonth, Integer outwrdBlngPrd);

	String saveInvoiceInfo(OtwrdBlngInfoForInvc invs, OutwrdBlngInvocEntity outwrdBlngInvocEntity);

	Integer changeCouponStatusAndUpdIvnNumbr(OtwrdBlngInfoForInvc invc, String invoiceNumber);

	Integer getTransactionCount(OtwrdBlngInfoForInvc invs);

	Set<FlownOALEntity> fetchConsolidatedRecords(Integer flightKey, String docId, Integer coupNum,Integer hostCarrierCode);

	List<ReIssueRefundOALEntity> processReIssueFefundRec(Integer hostCarrier);

}
