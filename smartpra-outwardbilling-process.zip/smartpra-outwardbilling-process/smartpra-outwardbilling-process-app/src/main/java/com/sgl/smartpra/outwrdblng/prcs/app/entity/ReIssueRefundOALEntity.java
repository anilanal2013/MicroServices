package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Transient;

@SqlResultSetMapping(name = "ReissueRefundoutwardbilling", entities = @EntityResult(entityClass = ReIssueRefundOALEntity.class, fields = {
          @FieldResult(name = "ticketOrigin", column = "tkt_sales_data_dtl_id"),
          @FieldResult(name = "clientId", column = "client_id"),
          @FieldResult(name = "documentUniqueId", column = "document_unique_id"),
          @FieldResult(name = "batchKey", column = "batch_key"),
          @FieldResult(name = "billedCarrierCode", column = "billed_carrier_code"),
          @FieldResult(name = "issueingCarrierCode", column = "iss_airline"),
          @FieldResult(name = "flightNumber", column = "flight_number"),
          @FieldResult(name = "utilizationDate", column = "utilization_date"),
          @FieldResult(name = "saleCurrencyCode", column = "currency_of_sale"),
          @FieldResult(name = "prorateCurrency", column = "prorate_currency"),
          @FieldResult(name = "grossAmount", column = "gross_amount"),
          @FieldResult(name = "documentNumber", column = "document_no"),
          @FieldResult(name = "couponNumber", column = "coupon_number"),
          @FieldResult(name = "fromAirport", column = "from_airport"),
          @FieldResult(name = "toAirport", column = "to_airport"),
          @FieldResult(name = "saleCurrency", column = "salecurrency"),
          @FieldResult(name = "rfic", column = "rfic"),
          @FieldResult(name = "rfisc", column = "rfisc"),
          @FieldResult(name = "iscAmount", column = "isc_amount"),
          @FieldResult(name = "iscPercentage", column = "isc_percentage"),
          @FieldResult(name = "taxAmount", column = "tax_amount"),
          @FieldResult(name = "eticketIndicator", column = "etkt_indicator"),
          @FieldResult(name = "prorationSource", column = "proration_source"),
          @FieldResult(name = "codeShareagreementId", column = "codeshare_agreement_id"),
          @FieldResult(name = "opertaingFlightNumber", column = "operating_flight_number"),
          @FieldResult(name = "operatingFlightDate", column = "marketing_flight_date"),
          @FieldResult(name = "operatingCarrierCode", column = "marketing_carrier_num_code"),
          @FieldResult(name = "fnfIndicator", column = "fnf_indicator"),
          @FieldResult(name = "surchargeAmount", column = "surcharge_value"),
          @FieldResult(name = "handlingFeeAmount", column = "handling_fee_amount"),
          @FieldResult(name = "flightIndicator", column = "flight_indicator"),
          @FieldResult(name = "flightDate", column = "utilization_date"),
          @FieldResult(name = "otherCommission", column = "othr_comm"),
          @FieldResult(name = "transactionType", column = "transaction_type"),
          @FieldResult(name = "source", column = "source"),
          @FieldResult(name = "ffyAgreement", column = "ffy_agreement_id"),
          @FieldResult(name = "dateOfIssue", column = "date_of_issue"),
          @FieldResult(name = "refundDate", column = "refund_date"),
          @FieldResult(name = "fileId", column = "file_id"),

}))
@Entity
public class ReIssueRefundOALEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "tkt_sales_data_dtl_id")
	private Long ticketOrigin;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	@Column(name = "batch_key")
	private Integer batchKey;

	@Column(name = "transaction_type")
	private String transactionType;

	@Column(name = "billed_carrier_code")
	private String billedCarrierCode;

	@Column(name = "iss_airline")
	private String issueingCarrierCode;

	@Column(name = "document_no")
	private String documentNumber;

	@Column(name = "coupon_number")
	private Integer couponNumber;

	@Column(name = "flight_number")
	private String flightNumber;

	@Column(name = "utilization_date")
	private Date utilizationDate;

	@Column(name = "from_airport")
	private String fromAirport;

	@Column(name = "to_airport")
	private String toAirport;

	@Column(name = "currency_of_sale")
	private String saleCurrencyCode;

	@Column(name = "prorate_currency")
	private String prorateCurrency;

	@Column(name = "gross_amount")
	private BigDecimal grossAmount;

	@Column(name = "isc_amount")
	private BigDecimal iscAmount;

	@Column(name = "isc_percentage")
	private BigDecimal iscPercentage;

	@Column(name = "tax_amount")
	private BigDecimal taxAmount;

	@Column(name = "surcharge_value")
	private BigDecimal surchargeAmount;

	@Column(name = "rfic")
	private String rfic;

	@Column(name = "rfisc")
	private String rfisc;

	@Column(name = "source")
	private String source;

	@Column(name = "ffy_agreement_id")
	private Character ffyAgreement;

	@Column(name = "etkt_indicator")
	private String eticketIndicator;

	@Transient
	private Integer responseLevel;

	@Column(name = "file_id")
	private Long fileId;

	public String getSource() {

		return source;
	}

	public void setSource(String source) {

		this.source = source;
	}

	@Column(name = "proration_source")
	private String prorationSource;

	@Column(name = "codeshare_agreement_id")
	private String codeShareagreementId;

	@Column(name = "operating_flight_number")
	private String opertaingFlightNumber;

	@Column(name = "operating_flight_dept_date")
	private Date operatingFlightDate;

	@Column(name = "operating_carrier_num_code")
	private String operatingCarrierCode;

	@Column(name = "fnf_indicator")
	private String fnfIndicator;

	@Column(name = "flight_date ")
	private Date flightDate;

	@Column(name = "othr_comm ")
	private BigDecimal otherCommission;

	@Column(name = "handling_fee_amount")
	private BigDecimal handlingFeeAmount;

	@Column(name = "date_of_issue")
	private Date dateOfIssue;

	@Column(name = "refund_date")
	private Date refundDate;

	public Date getDateOfIssue() {

		return dateOfIssue;
	}

	public void setDateOfIssue(Date dateOfIssue) {

		this.dateOfIssue = dateOfIssue;
	}

	public Date getRefundDate() {

		return refundDate;
	}

	public void setRefundDate(Date refundDate) {

		this.refundDate = refundDate;
	}

	public BigDecimal getHandlingFeeAmount() {

		return handlingFeeAmount;
	}

	public void setHandlingFeeAmount(BigDecimal handlingFeeAmount) {

		this.handlingFeeAmount = handlingFeeAmount;
	}

	public String getClientId() {

		return clientId;
	}

	public void setClientId(String clientId) {

		this.clientId = clientId;
	}

	public String getDocumentUniqueId() {

		return documentUniqueId;
	}

	public void setDocumentUniqueId(String documentUniqueId) {

		this.documentUniqueId = documentUniqueId;
	}

	public Integer getBatchKey() {

		return batchKey;
	}

	public void setBatchKey(Integer batchKey) {

		this.batchKey = batchKey;
	}

	public String getBilledCarrierCode() {

		return billedCarrierCode;
	}

	public void setBilledCarrierCode(String billedCarrierCode) {

		this.billedCarrierCode = billedCarrierCode;
	}

	public String getIssueingCarrierCode() {

		return issueingCarrierCode;
	}

	public void setIssueingCarrierCode(String issueingCarrierCode) {

		this.issueingCarrierCode = issueingCarrierCode;
	}

	public String getDocumentNumber() {

		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {

		this.documentNumber = documentNumber;
	}

	public Integer getCouponNumber() {

		return couponNumber;
	}

	public void setCouponNumber(Integer couponNumber) {

		this.couponNumber = couponNumber;
	}

	public String getFlightNumber() {

		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {

		this.flightNumber = flightNumber;
	}

	public Date getUtilizationDate() {

		return utilizationDate;
	}

	public void setUtilizationDate(Date utilizationDate) {

		this.utilizationDate = utilizationDate;
	}

	public String getFromAirport() {

		return fromAirport;
	}

	public void setFromAirport(String fromAirport) {

		this.fromAirport = fromAirport;
	}

	public String getToAirport() {

		return toAirport;
	}

	public void setToAirport(String toAirport) {

		this.toAirport = toAirport;
	}

	public String getSaleCurrencyCode() {

		return saleCurrencyCode;
	}

	public void setSaleCurrencyCode(String saleCurrencyCode) {

		this.saleCurrencyCode = saleCurrencyCode;
	}

	public String getProrateCurrency() {

		return prorateCurrency;
	}

	public void setProrateCurrency(String prorateCurrency) {

		this.prorateCurrency = prorateCurrency;
	}

	public BigDecimal getGrossAmount() {

		return grossAmount;
	}

	public void setGrossAmount(BigDecimal grossAmount) {

		this.grossAmount = grossAmount;
	}

	public BigDecimal getIscAmount() {

		return iscAmount;
	}

	public void setIscAmount(BigDecimal iscAmount) {

		this.iscAmount = iscAmount;
	}

	public BigDecimal getIscPercentage() {

		return iscPercentage;
	}

	public void setIscPercentage(BigDecimal iscPercentage) {

		this.iscPercentage = iscPercentage;
	}

	public BigDecimal getTaxAmount() {

		return taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {

		this.taxAmount = taxAmount;
	}

	public BigDecimal getSurchargeAmount() {

		return surchargeAmount;
	}

	public void setSurchargeAmount(BigDecimal surchargeAmount) {

		this.surchargeAmount = surchargeAmount;
	}

	public Long getTicketOrigin() {

		return ticketOrigin;
	}

	public void setTicketOrigin(Long ticketOrigin) {

		this.ticketOrigin = ticketOrigin;
	}

	public String getRfic() {

		return rfic;
	}

	public String getEticketIndicator() {

		return eticketIndicator;
	}

	public void setEticketIndicator(String eticketIndicator) {

		this.eticketIndicator = eticketIndicator;
	}

	public Date getFlightDate() {

		return flightDate;
	}

	public void setFlightDate(Date flightDate) {

		this.flightDate = flightDate;
	}

	public void setRfic(String rfic) {

		this.rfic = rfic;
	}

	public String getRfisc() {

		return rfisc;
	}

	public void setRfisc(String rfisc) {

		this.rfisc = rfisc;
	}

	public String getProrationSource() {

		return prorationSource;
	}

	public void setProrationSource(String prorationSource) {

		this.prorationSource = prorationSource;
	}

	public String getCodeShareagreementId() {

		return codeShareagreementId;
	}

	public void setCodeShareagreementId(String codeShareagreementId) {

		this.codeShareagreementId = codeShareagreementId;
	}

	public String getOpertaingFlightNumber() {

		return opertaingFlightNumber;
	}

	public void setOpertaingFlightNumber(String opertaingFlightNumber) {

		this.opertaingFlightNumber = opertaingFlightNumber;
	}

	public Date getOperatingFlightDate() {

		return operatingFlightDate;
	}

	public void setOperatingFlightDate(Date operatingFlightDate) {

		this.operatingFlightDate = operatingFlightDate;
	}

	public String getOperatingCarrierCode() {

		return operatingCarrierCode;
	}

	public void setOperatingCarrierCode(String operatingCarrierCode) {

		this.operatingCarrierCode = operatingCarrierCode;
	}

	public String getFnfIndicator() {

		return fnfIndicator;
	}

	public void setFnfIndicator(String fnfIndicator) {

		this.fnfIndicator = fnfIndicator;
	}

	public static long getSerialversionuid() {

		return serialVersionUID;
	}

	public Integer getResponseLevel() {

		return responseLevel;
	}

	public void setResponseLevel(Integer responseLevel) {

		this.responseLevel = responseLevel;
	}

	public Long getFileId() {

		return fileId;
	}

	public void setFileId(Long fileId) {

		this.fileId = fileId;
	}

	public BigDecimal getOtherCommission() {

		return otherCommission;
	}

	@Override
	public String toString() {

		return "ReIssueRefundOALEntity [orderId=" + ", clientId=" + clientId
		          + ", documentUniqueId=" + documentUniqueId + ", batchKey="
		          + batchKey + ", transactionType=" + transactionType
		          + ", billedCarrierCode=" + billedCarrierCode
		          + ", issueingCarrierCode=" + issueingCarrierCode
		          + ", documentNumber=" + documentNumber + ", couponNumber="
		          + couponNumber + ", flightNumber=" + flightNumber
		          + ", utilizationDate=" + utilizationDate + ", fromAirport="
		          + fromAirport + ", toAirport=" + toAirport
		          + ", saleCurrencyCode=" + saleCurrencyCode
		          + ", prorateCurrency=" + prorateCurrency + ", grossAmount="
		          + grossAmount + ", iscAmount=" + iscAmount
		          + ", iscPercentage=" + iscPercentage + ", taxAmount="
		          + taxAmount + ", surchargeAmount=" + surchargeAmount
		          + ", rfic=" + rfic + ", rfisc=" + rfisc + ", source="
		          + source + ", ffyAgreement=" + ffyAgreement
		          + ", prorationSource=" + prorationSource
		          + ", codeShareagreementId=" + codeShareagreementId
		          + ", opertaingFlightNumber=" + opertaingFlightNumber
		          + ", operatingFlightDate=" + operatingFlightDate
		          + ", operatingCarrierCode=" + operatingCarrierCode
		          + ", fnfIndicator=" + fnfIndicator + ", otherCommission="
		          + otherCommission + ", handlingFeeAmount="
		          + handlingFeeAmount + ", dateOfIssue=" + dateOfIssue
		          + ", refundDate=" + refundDate + "]";
	}

	public void setOtherCommission(BigDecimal otherCommission) {

		this.otherCommission = otherCommission;
	}

	@Override
	public int hashCode() {

		final int prime = 31;
		int result = 1;
		result = prime * result
		          + ((batchKey == null) ? 0 : batchKey.hashCode());
		result = prime
		          * result
		          + ((billedCarrierCode == null) ? 0
		                    : billedCarrierCode.hashCode());
		result = prime * result
		          + ((couponNumber == null) ? 0 : couponNumber.hashCode());
		result = prime
		          * result
		          + ((documentNumber == null) ? 0 : documentNumber.hashCode());
		result = prime
		          * result
		          + ((documentUniqueId == null) ? 0
		                    : documentUniqueId.hashCode());
		result = prime
		          * result
		          + ((transactionType == null) ? 0
		                    : transactionType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		ReIssueRefundOALEntity other = (ReIssueRefundOALEntity) obj;
		if (batchKey == null) {
			if (other.batchKey != null) return false;
		}
		else if (!batchKey.equals(other.batchKey)) return false;
		if (billedCarrierCode == null) {
			if (other.billedCarrierCode != null) return false;
		}
		else if (!billedCarrierCode.equals(other.billedCarrierCode))
		     return false;
		if (couponNumber == null) {
			if (other.couponNumber != null) return false;
		}
		else if (!couponNumber.equals(other.couponNumber)) return false;
		if (documentNumber == null) {
			if (other.documentNumber != null) return false;
		}
		else if (!documentNumber.equals(other.documentNumber)) return false;
		if (documentUniqueId == null) {
			if (other.documentUniqueId != null) return false;
		}
		else if (!documentUniqueId.equals(other.documentUniqueId))
		     return false;
		if (transactionType == null) {
			if (other.transactionType != null) return false;
		}
		else if (!transactionType.equals(other.transactionType))
		     return false;
		return true;
	}

	public String getTransactionType() {

		return transactionType;
	}

	public void setTransactionType(String transactionType) {

		this.transactionType = transactionType;
	}

	public Character getFfyAgreement() {

		return ffyAgreement;
	}

	public void setFfyAgreement(Character ffyAgreement) {

		this.ffyAgreement = ffyAgreement;
	}

}