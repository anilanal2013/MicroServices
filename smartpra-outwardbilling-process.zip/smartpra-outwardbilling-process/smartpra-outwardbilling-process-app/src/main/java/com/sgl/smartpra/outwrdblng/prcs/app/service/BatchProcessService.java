package com.sgl.smartpra.outwrdblng.prcs.app.service;

public interface BatchProcessService {

	public void getBatchGenerationProcess();

}
