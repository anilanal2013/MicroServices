package com.sgl.smartpra.outwrdblng.prcs.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.SqlResultSetMapping;

@SqlResultSetMapping(name = "Salesoutwardbilling", entities = @EntityResult(entityClass = TicketOrigDetEntity.class, fields = {
          @FieldResult(name = "ticketOrginID", column = "tkt_orgin_id"),
          @FieldResult(name = "issAirline", column = "iss_airline"),
          @FieldResult(name = "origDocument", column = "orig_document"),
          @FieldResult(name = "origCouponNumber", column = "orig_cpn_no"),
          @FieldResult(name = "documentUniqueId", column = "document_unique_id"), }))
@Entity
public class TicketOrigDetEntity {

	@javax.persistence.Id
	@Column(name = "tkt_orgin_id")
	private Integer ticketOrginID;

	@Column(name = "iss_airline")
	private String issAirline;

	@Column(name = "orig_document ")
	private String origDocument;

	@Column(name = "orig_cpn_no")
	private String origCouponNumber;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	public String getDocumentUniqueId() {

		return documentUniqueId;
	}

	public void setDocumentUniqueId(String documentUniqueId) {

		this.documentUniqueId = documentUniqueId;
	}

	public Integer getTicketOrginID() {

		return ticketOrginID;
	}

	public void setTicketOrginID(Integer ticketOrginID) {

		this.ticketOrginID = ticketOrginID;
	}

	public String getIssAirline() {

		return issAirline;
	}

	public void setIssAirline(String issAirline) {

		this.issAirline = issAirline;
	}

	public String getOrigDocument() {

		return origDocument;
	}

	public void setOrigDocument(String origDocument) {

		this.origDocument = origDocument;
	}

	public String getOrigCouponNumber() {

		return origCouponNumber;
	}

	public void setOrigCouponNumber(String origCouponNumber) {

		this.origCouponNumber = origCouponNumber;
	}

}
