package com.sgl.smartpra.outwrdblng.prcs.app.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.outwardbilling.process.model.OutwardBillingInvoiceModel;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.GlobalMasterAppFeignClient;
import com.sgl.smartpra.outwrdblng.prcs.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.outwrdblng.prcs.app.dao.OutwrdblngprcDao;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OtwrdBlngInfoForInvc;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwardBillingDetail;
import com.sgl.smartpra.outwrdblng.prcs.app.entity.OutwrdBlngInvocEntity;
import com.sgl.smartpra.outwrdblng.prcs.app.mapper.OutwrblngprcsMapper;
import com.sgl.smartpra.outwrdblng.prcs.app.repository.OtwrdInvcPrcsRpo;
import com.sgl.smartpra.outwrdblng.prcs.app.repository.OwrblngprcsRepo;
import com.sgl.smartpra.outwrdblng.prcs.app.service.OutwblngInvprcsServ;
import com.sgl.smartpra.outwrdblng.prcs.app.util.OutwrblngprcsServiceUtils;
import com.sgl.smartpra.outwrdblng.prcs.app.util.StringLiteralsUtil;

@Service
@Transactional
public class OwrdblngInvcprcsServImpl implements OutwblngInvprcsServ {

	private static final Logger LOGGER = LoggerFactory.getLogger(OutwblngInvprcsServ.class);
	@Autowired
	private OutwrdblngprcDao outwardBillingProcessDao;
	@Autowired
	private MasterFeignClient masterFeignClient;
	@Autowired
	private GlobalMasterAppFeignClient globalMasterAppFeignClient;
	@Autowired
	private OutwrblngprcsServiceUtils outwrblngprcsServiceUtils;
	@Autowired
	private OtwrdInvcPrcsRpo otwrdInvcPrcsRpo;
	@Autowired
	OwrblngprcsRepo owrblngprcsRepo;
	String responseMsg = null;

	@Autowired
	private OutwrblngprcsMapper outwrblngprcsMapper;
	
	@Override
	public String genarateInvcForPrime(String billingMonth, Integer billingPeriod, LocalDate processDate) {


		LOGGER.info("The Invoicing genaration has started ");
		String sttlmentMethod = null;
		String invNumber = null;
		OutwardBillingPeriods outwardBillingPeriods = null;
		FinancialMonthModel financial = null;
		try {
			outwardBillingPeriods = masterFeignClient.getCurrentOpenOutwardBillingPeriods();
		}
		catch (Exception e) {
			LOGGER.error("Couldnt get the CurrentOpenOutwardBillingPeriods");
		}
		LocalDate outwardEndDate = outwardBillingPeriods.getEndDate();

		BigDecimal exchangeRate;
		LOGGER.info("Invoked  getCurrentOpenFinancialMonthForFinancialCalendar ");
		List<OtwrdBlngInfoForInvc> list = outwardBillingProcessDao.getSummarizedInfo(billingMonth, billingPeriod);
		LOGGER.info("Fetched getSummarizedInfo ");
		Set<OtwrdBlngInfoForInvc> uniqueObjs = new HashSet<>();
		uniqueObjs.addAll(list);
		for (OtwrdBlngInfoForInvc invc : uniqueObjs) {
			OutwrdBlngInvocEntity outwrdBlngInvocEntity = new OutwrdBlngInvocEntity();
			try {
				invNumber = genarateInvoiceNumber(invc, financial);
				LOGGER.info(" genarateInvoiceNumber got called  :", invNumber);
				outwrdBlngInvocEntity.setInvoiceNumber(invNumber);
			}
			catch (Exception e) {
				LOGGER.error(" Error while genarating the invoice number {}", e);
			}
			try {
				financial = masterFeignClient.getCurrentOpenFinancialMonthForFinancialCalendar(null);
				outwrdBlngInvocEntity.setFinancialYear(financial.getFinancialYear());
			}
			catch (Exception e) {
				LOGGER.error(" Error while invoking getCurrentOpenFinancialMonthForFinancialCalendar {}", e);
			}
			outwrdBlngInvocEntity.setBilledCarrierCode(invc.getBilledCarrierCode());
			outwrdBlngInvocEntity.setBillingMonth(invc.getBillingMonth());
			outwrdBlngInvocEntity.setBillingPeriod(invc.getBillingPeriod());
			outwrdBlngInvocEntity.setCurrencyOfInvoice(invc.getCurrencyOfInvoice());
			outwrdBlngInvocEntity.setCurrencyOfListing(invc.getCurrencyOfListing());
			outwrdBlngInvocEntity.setBillingCode(0);
			String settlement = outwrblngprcsServiceUtils.deriveSettlmnt(outwrdBlngInvocEntity.getBilledCarrierCode(), "157");
			if (settlement != null) {
				outwrdBlngInvocEntity.setSettlemetMethod(settlement);
				LOGGER.info("Derived settlement method  {} ", settlement);
			}
			else {
				outwrdBlngInvocEntity.setSettlemetMethod("B");
			}
			if (invc.getClientId() == null) {
				outwrdBlngInvocEntity.setClientId("QR");
			}
			else {
				outwrdBlngInvocEntity.setClientId(invc.getClientId());
			}
			Integer count = outwardBillingProcessDao.getTransactionCount(invc);
			LOGGER.debug("The transaction count  for the invoice number {} in ouwrdblng repository ", invNumber);
			outwrdBlngInvocEntity.setTransCount(count);
			outwrdBlngInvocEntity.setCreatedBy(StringLiteralsUtil.COUPVALID_EXCEP_CREATEDBY);
			outwrdBlngInvocEntity.setInvoiceType("IV");
			outwrdBlngInvocEntity.setCreatedDate(LocalDateTime.now());
			outwrdBlngInvocEntity.setIncludedInFile('Y');
			outwrdBlngInvocEntity.setIsAccounted('Y');
			outwrdBlngInvocEntity.setSisValidated('Y');
			outwrdBlngInvocEntity.setInvoiceDate(processDate);
			try {
				exchangeRate = outwrblngprcsServiceUtils.deriveExchangeRates(invc.getCurrencyOfListing(), invc.getCurrencyOfInvoice(), outwardEndDate);
				outwrdBlngInvocEntity.setExchangeRate(exchangeRate);
				LOGGER.debug("Derived the exchange rate {} bet COL and COI and is ", exchangeRate);
			}
			catch (Exception e) {
				LOGGER.debug("Failed to derive the  exchange rate {} bet COL and COI and is ");
			}
			outwrdBlngInvocEntity.setSettlemetMethod(sttlmentMethod);
			LOGGER.info("Saving the invoice records");
			this.responseMsg = outwardBillingProcessDao.saveInvoiceInfo(invc, outwrdBlngInvocEntity);
			outwardBillingProcessDao.changeCouponStatusAndUpdIvnNumbr(invc, outwrdBlngInvocEntity.getInvoiceNumber());
			LOGGER.info("Saved and  changed coupon status ");
		}
		return responseMsg;
	}

	public String genarateInvoiceNumber(OtwrdBlngInfoForInvc invc, FinancialMonthModel fin) {

		String financialYr = getCurrentFy("QR");
		String billedCarrierDesignator = globalMasterAppFeignClient.getCarrierByCarrierCode(invc.getBilledCarrierCode()).getCarrierDesignatorCode().get();
		return outwrblngprcsServiceUtils.generateInvoiceNo("QR", financialYr, billedCarrierDesignator);

	}

	public String getCurrentFy(String clientId) {

		FinancialMonthModel financialMonthModel = null;
		String fy = StringLiteralsUtil.EMPTY_STRING;
		try {
			financialMonthModel = masterFeignClient.getCurrentOpenFinancialMonthForFinancialCalendar(clientId);
		}
		catch (Exception e) {
			LOGGER.error("Error thrown {} while calling method getCurrentOpenFinancialMonthForFinancialCalendar() ", e.getMessage());
		}
		if (financialMonthModel != null) {
			fy = financialMonthModel.getFinancialYear().substring(0, 2).toUpperCase();
		}
		return fy;
	}

	@Override
	public List<OutwrdBlngInvocEntity> getInvcsByBlndPrd(String billingMonth, Integer billingPeriod) {

		return otwrdInvcPrcsRpo.getOuwrdInvcRecsByBlngMnth(billingMonth, billingPeriod);
	}

	@Override
	public List<OutwardBillingDetail> getOutwrdblng(String billingMonth, Integer billingPeriod) {

		return owrblngprcsRepo.getOuwrdBlngByBlngPrdAndMnth(billingMonth, billingPeriod);
	}

	@Override
	public OutwardBillingInvoiceModel createOutwardBillingInvoice(
			OutwardBillingInvoiceModel outwardBillingInvoiceModel) throws ParseException {
		OutwrdBlngInvocEntity outwrdBlngInvocEntity = outwrblngprcsMapper.map(outwardBillingInvoiceModel);
		String billedCarrierCode = outwrdBlngInvocEntity.getBilledCarrierCode();
		String billingMonth = outwrdBlngInvocEntity.getBillingMonth();
		Integer billingPeriod = outwrdBlngInvocEntity.getBillingPeriod();

		FinancialMonthModel yearByFinancialMonth = masterFeignClient
				.getFinancialYearByFinancialMonth(outwrdBlngInvocEntity.getClientId(), billingMonth);
		String year = yearByFinancialMonth.getFinancialYear().split("-")[0];
		outwrdBlngInvocEntity.setFinancialYear(yearByFinancialMonth.getFinancialYear());
		String settlementMethod = outwrblngprcsServiceUtils.getSettlementMethod(billedCarrierCode, "157", billingMonth,
				billingPeriod);
		
		Carrier carrier = globalMasterAppFeignClient.getCarrierByCarrierCode(billedCarrierCode);
		String billedCarrierDesignatorCode = carrier.getCarrierDesignatorCode().orElse("");
		String invoiceNo = outwrblngprcsServiceUtils.generateInvoiceNo("QR", year, billedCarrierDesignatorCode);
		outwrdBlngInvocEntity.setInvoiceNumber(invoiceNo);
		outwrdBlngInvocEntity.setInvoiceDate(LocalDate.now());
		
		outwrdBlngInvocEntity.setSettlemetMethod(settlementMethod);
		outwrdBlngInvocEntity.setCreatedBy(StringLiteralsUtil.COUPVALID_EXCEP_CREATEDBY);
		outwrdBlngInvocEntity.setCreatedDate(LocalDateTime.now());

		outwrdBlngInvocEntity = otwrdInvcPrcsRpo.save(outwrdBlngInvocEntity);

		return outwrblngprcsMapper.map(outwrdBlngInvocEntity);
	}

}
