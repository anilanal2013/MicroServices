package com.sgl.smartpra.outwardbilling.process.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import lombok.Data;
/**
 * @author Venkataraju
 *
 */
@Data
public class OutwardBillingVatModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private int outwardBillingVatId;

	private long batchKey;

	private String billedCarrierCode;

	private String billingMonth;

	private int billingPeriod;

	private int checkDigit;

	private String clientId;

	private int couponNumber;

	private String createdBy;

	private Timestamp createdDate;

	private String documentNumber;

	private String documentUniqueId;

	private String financialYear;

	private String invoiceNumber;

	private String issuingCarrierCode;

	private String lastUpdatedBy;

	private Timestamp lastUpdatedDate;

	private String orderId;

	private int recordSeqNumber;

	private BigDecimal vatAmount;

	private BigDecimal vatBaseAmount;

	private String vatIdentifier;

	private String vatLabel;

	private BigDecimal vatPercentage;

}