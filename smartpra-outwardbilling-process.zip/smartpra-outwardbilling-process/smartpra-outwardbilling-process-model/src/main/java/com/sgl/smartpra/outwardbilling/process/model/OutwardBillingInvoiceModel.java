package com.sgl.smartpra.outwardbilling.process.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import lombok.Data;
@Data
public class OutwardBillingInvoiceModel {

	private Integer obInvoiceId;
	@NotNull
	private String clientId;
	@NotNull
	private String billingMonth;
	@NotNull
	private Integer transCount;
	@NotNull
	private Integer billingPeriod;
	@NotNull
	private String billedCarrierCode;

	private String settlemetMethod;
	@NotNull
	private String invoiceType;

	private String invoiceNumber;

	private LocalDate invoiceDate;

	private String financialYear;
	@NotNull
	private Integer billingCode;
	@NotNull
	private String currencyOfListing;

	private String currencyOfInvoice;

	private BigDecimal exchangeRate;

	private BigDecimal grossAmount;

	private BigDecimal iscAmount;

	private BigDecimal taxAmount;

	private BigDecimal handingFeeAmount;

	private BigDecimal uatpAmount;
	@NotNull
	private BigDecimal otherCommAmount;

	private BigDecimal vatCommAmount;

	private BigDecimal netCommAmount;

	private Character status;
	@NotNull
	private Character includedInFile;
	@NotNull
	private Character sisValidated;
	@NotNull
	private Integer sourceCode;
	@NotNull
	private Character billingType;
	@NotNull
	private Character isAccounted;

}
