package com.sgl.smartpra.outwardbilling.process.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

/**
 * @author Venkataraju
 *
 */
@Data
public class OutwardBillingTaxModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer outwardBillingTaxId;

	private String clientId;

	private String orderId;;

	private String documentUniqueId;

	private Long batchKey;

	private String financialYear;

	private String billedCarrierCode;

	private String issuingCarrierCode;

	private String documentNumber;

	private Integer couponNumber;

	private Integer checkDigit;

	private String billingMonth;

	private Integer billingPeriod;

	private String invoiceNumber;

	private Integer recordSeqNumber;

	private String taxCode;

	private String countryCode;

	private Integer taxSerialno;

	private Integer taxApplicableSerialNo;

	private BigDecimal taxAmount;

	private LocalDateTime createdDate;

	private String createdBy;

	private LocalDateTime lastUpdatedDate;

	private String lastUpdatedBy;
}
