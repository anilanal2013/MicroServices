package com.sgl.smartpra.outwardbilling.process.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Set;

import lombok.Data;
/**
 * @author Venkataraju
 *
 */
@Data
public class OutwardBillingDetailModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer outwardBillingId;

	private String agreementIndicator;

	private long batchKey;

	private int batchSeqNo;

	private String billedCarrierCode;

	private String billingMonth;

	private int billingPeriod;

	private Integer checkDigit;

	private String clientId;

	private String codeshareAgreementId;

	private String operatingCarrierCode;

	private LocalDate operatingFlightDate;

	private String opertaingFlightNumber;

	private int couponNumber;

	private String couponStatus;

	private String createdBy;

	private Timestamp createdDate;

	private String currencyOfInvoice;

	private String currencyOfListing;

	private String documentNumber;

	private String documentUniqueId;

	private String eticketIndicator;

	private BigDecimal exRateColToCoi;

	private BigDecimal exRateProCurrCol;

	private int fileId;

	private String fimCarrierCode;

	private int fimCheckDigit;

	private int fimCouponNo;

	private String fimInvoiceIndicator;

	private long fimNumber;

	private String financialYear;

	private String flightNumber;

	private String fnfIndicator;

	private String fromAirport;

	private BigDecimal grossAmount;

	private BigDecimal handlingFeeAmount;

	private String invoiceNumber;

	private BigDecimal iscPercentage;

	private String issueingCarrierCode;

	private String jvFinancialYear;

	private String jvNumber;

	private String lastUpdatedBy;

	private Timestamp lastUpdatedDate;

	private int noOfPassenger;

	private String orderId;

	private BigDecimal otherCommission;

	private String pmiIndicator;

	private String prorateCurrency;

	private String prorationSource;

	private int recordSeqNo;

	private String remarks;

	private int responseLevel;

	private String rfic;

	private String rfisc;

	private String saleCurrencyCode;

	private int sourceCode;

	private String spaCarrier;

	private String spaCode;

	private String supplementaryBillingIndi;

	private BigDecimal surchargeAmount;

	private BigDecimal taxAmount;

	private BigDecimal netAmount;

	private String toAirport;

	private String transitionType;

	private BigDecimal uatpAmount;
	
	private Set<OutwardBillingVatModel> outwardBillingVatModel;
	
	private Set<OutwardBillingTaxModel> outwardBillingTaxModel;

	private LocalDate utilizationDate;

	private BigDecimal vatAmount;

	private BigDecimal iscAmount;

	public String esacCode;


}