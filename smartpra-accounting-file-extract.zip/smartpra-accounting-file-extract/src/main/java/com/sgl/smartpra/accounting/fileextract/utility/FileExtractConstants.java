package com.sgl.smartpra.accounting.fileextract.utility;

/**
 * 
 * @author Siva Kumar
 *
 */
public class FileExtractConstants {

	private FileExtractConstants() {

	}

	public static final String SUCCESS = "SUCCESS";

	public static final String FAILURE = "FAILURE";
	
	public static final String EXTRACT = "EXTRACT";
	
	public static final String SYSTEM = "System";
	
	public static final String HEADERRECORD = "HR";
	
	public static final String DETAILEDRECORD = "DR";
	
	public static final String HEADER = "H";
	
	public static final String FILENAME = "FN";
	
	public static final String VALID_SUMM_LIST = "validSummList";
	
	public static final String INVALID_SUMM_LIST = "inValidSummList";
	
	public static final String ACCOUNTTYPE_GL = "GL";
	
	public static final String ACCOUNTTYPE_AP = "AP";
	
	public static final String ACCOUNTTYPE_AR = "AR";
	
	public static final String ERROR_EXTRACT = "ERREXTRACT";
	

}
