package com.sgl.smartpra.accounting.fileextract.config;

import java.math.BigInteger;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sgl.smartpra.batch.global.model.FileLogging;

/**
 * 
 * @author Siva Kumar
 *
 */
@Configuration
@EnableFeignClients
public class FeignConfiguration {

	@FeignClient(value = "smartpra-batch-global-app")
	public interface BatchGlobalFeignClient {

		@PostMapping("/filelog")
		public FileLogging createFileLog(@Valid @RequestBody FileLogging fileLog);

		@PutMapping("/filelog/{fileId}")
		public FileLogging updateFileLog(@PathVariable(value = "fileId") BigInteger fileId,
				@Valid @RequestBody FileLogging fileLog);
	}

	@FeignClient(value = "smartpra-redisCache-app")
	public interface SequenceAppFeignClient {
		
		@GetMapping(value = "/sequence/{seq}")
		public int getSequnce(@PathVariable("seq") String seq);

	}
}
