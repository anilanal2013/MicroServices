package com.sgl.smartpra.accounting.fileextract.utility;

import lombok.Data;

@Data
public class AccountExtractRequest {

	private String clientId;
	
	private String moduleId;
	
	private String subModule;
	
	private String accountType;
	
	private String fileType;
	
	private String monthClosedDate;

}
