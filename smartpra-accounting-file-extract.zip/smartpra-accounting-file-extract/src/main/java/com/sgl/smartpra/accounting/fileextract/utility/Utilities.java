package com.sgl.smartpra.accounting.fileextract.utility;
import java.io.File;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.accounting.entity.AccountingExtractFileNamingEntity;
import com.sgl.smartpra.accounting.model.AccountingMappingConfModel;
import com.sgl.smartpra.accounting.utils.AccountingExtractResponse;
import com.sgl.smartpra.accounting.utils.AccountsConstants;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class Utilities {

    public List<Map<String, Object>> fetchAccountsBasedOnSummarizationAndMappingConf(
            List<Map<String, Object>> summarizationList, List<AccountingMappingConfModel> accountingMappingConfList) {
        log.info("Inside AccountingUtilities class, fetchAccountsBasedOnSummarizationAndMappingConf method");
        try {
            return summarizationList.stream().filter(Objects::nonNull).map(summarizarionObjectIntoMap -> {
                Map<String, Object> finalOutputAccountingMapConfMap = new HashMap<>();
                accountingMappingConfList.stream().filter(Objects::nonNull).forEach(accountingMappingConf -> {
                    mapData(finalOutputAccountingMapConfMap, summarizarionObjectIntoMap, accountingMappingConf);
                });
                return finalOutputAccountingMapConfMap;
            }).collect(Collectors.toList());
        } catch (Exception e) {
            log.error(
                    "Exception Inside AccountingUtilities class, fetchAccountsBasedOnSummarizationAndMappingConf method");
            return Collections.emptyList();
        }
    }

    private void mapData(Map<String, Object> finalOutputAccountingMapConfMap,
                         Map<String, Object> summarizarionObjectIntoMap,
                         AccountingMappingConfModel accountingMappingConf) {
        log.info("Inside AccountingUtilities class, mapData method");
        SimpleDateFormat simpleDateFormat = null;
        try {
            String dataType = StringUtils.lowerCase(accountingMappingConf.getDatatype());
            /*if (StringUtils.equalsIgnoreCase(dataType, "construct")
                    || StringUtils.equalsIgnoreCase(dataType, "LocalDate")) {
                String mTableValue = accountingMappingConf.getValue();
                StringBuilder generatedDynamicValue = getDynamicValueFormation(summarizarionObjectIntoMap, mTableValue,
                        accountingMappingConf.getKeyval(), accountingMappingConf.getDefaultvalue());
                finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), generatedDynamicValue);
            }*/
            /*else {
                if(StringUtils.equalsIgnoreCase("jvNumber", accountingMappingConf.getKeyval())) {
                    String summarizationId = summarizarionObjectIntoMap.get("summarisationId")!=null ? summarizarionObjectIntoMap.get("summarisationId").toString() : null;
                    finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(),
                            generatedJvNumberMap.get(summarizationId)!=null ? generatedJvNumberMap.get(summarizationId) : "");
                } else {
                    finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(),
                            summarizarionObjectIntoMap.getOrDefault(accountingMappingConf.getValue(),
                                    StringUtils.isNotEmpty(accountingMappingConf.getDefaultvalue())
                                            ? accountingMappingConf.getDefaultvalue() : ""));
                }

            }*/
            if (StringUtils.equalsIgnoreCase(dataType, "localdate") && StringUtils
                    .equalsIgnoreCase(StringUtils.lowerCase(accountingMappingConf.getFromdatatype()), "string")) {
                String date = (String) summarizarionObjectIntoMap.get(accountingMappingConf.getValue());
                LocalDate localDate = null;
                if (StringUtils.isNotBlank(date)) {
                    simpleDateFormat = new SimpleDateFormat(accountingMappingConf.getFromformat());
                    try {
                        Date dateCal = simpleDateFormat.parse(date);
                        DateTimeFormatter dateTimeFormatter = DateTimeFormatter
                                .ofPattern(accountingMappingConf.getFormat());
                        localDate = dateCal.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                    } catch (ParseException e) {
                        log.error("Exception occurs in date Format =>localdate " + e.getMessage());
                    }
                }
                finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), localDate);
            } else if (StringUtils.equalsIgnoreCase(StringUtils.lowerCase(accountingMappingConf.getFromdatatype()),
                    "localdate")
                    && StringUtils.equalsIgnoreCase(StringUtils.lowerCase(accountingMappingConf.getDatatype()),
                    "string")) {
                String st = null;
                try {
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter
                            .ofPattern(accountingMappingConf.getFormat());
                    st = ((LocalDate) summarizarionObjectIntoMap.get(accountingMappingConf.getValue()))
                            .format(dateTimeFormatter);
                } catch (Exception e) {
                    log.error("Exception occurs in date Format =>string" + e.getMessage());
                }
                finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), st);
            } else if (StringUtils.equalsIgnoreCase(StringUtils.lowerCase(accountingMappingConf.getFromdatatype()),
                    "date")
                    && StringUtils.equalsIgnoreCase(StringUtils.lowerCase(accountingMappingConf.getDatatype()),
                    "localDate")) {
                LocalDate localDate = LocalDate.now();
                try {
                    localDate = Instant
                            .ofEpochMilli(
                                    ((Date) summarizarionObjectIntoMap.get(accountingMappingConf.getValue())).getTime())
                            .atZone(ZoneId.systemDefault()).toLocalDate();
                } catch (Exception e) {
                    log.error("Exception occurs in date Format " + e.getMessage());
                }
                finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), localDate);
            } else if (StringUtils.equalsIgnoreCase("date", accountingMappingConf.getFromdatatype()) &&
                        StringUtils.equalsIgnoreCase("String" , accountingMappingConf.getDatatype())) {
                simpleDateFormat = new SimpleDateFormat(accountingMappingConf.getFormat() != null ? accountingMappingConf.getFormat() : "YYYY-MM-DD");
                Date date = (Date) summarizarionObjectIntoMap.getOrDefault(accountingMappingConf.getValue(),accountingMappingConf.getDefaultvalue());
                try {

                    finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(),simpleDateFormat.format(date));
                } catch (Exception e ){
                    log.error("Exception in parse "+e.getMessage());
                    finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(),String.valueOf(date));
                }

            } else if (StringUtils.equalsIgnoreCase(StringUtils.lowerCase("construct"), accountingMappingConf.getDatatype())){
                String value = (String)summarizarionObjectIntoMap.getOrDefault(accountingMappingConf.getValue(),
                        accountingMappingConf.getDefaultvalue());
                if(StringUtils.isBlank(value)){
                    value = accountingMappingConf.getDefaultvalue();
                } else {
                    if(StringUtils.containsAny(value,"{","}")){
                        value = constructValue(summarizarionObjectIntoMap, value);

                        finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), value);
                    } else {
                        finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), value);
                    }
                }



            } else if (StringUtils.equalsIgnoreCase(StringUtils.lowerCase("condition"),accountingMappingConf.getDatatype())){
                // TOD condition
                String value = (String)summarizarionObjectIntoMap.getOrDefault(accountingMappingConf.getValue(),
                        accountingMappingConf.getDefaultvalue());
                if(StringUtils.isBlank(value)){
                    value = accountingMappingConf.getDefaultvalue();
                } else {
                    if(StringUtils.containsAny(value,"{","}")){
                        fetchConditionValue(finalOutputAccountingMapConfMap, summarizarionObjectIntoMap, accountingMappingConf, StringUtils.trim(value));

                    } else {

                        finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), StringUtils.trim(value));
                    }


                }
                if(StringUtils.containsAny(value,"{","}")) {
                    fetchConditionValue(finalOutputAccountingMapConfMap, summarizarionObjectIntoMap, accountingMappingConf, StringUtils.trim(value));
                }

            }
            else {
                finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(),
                        summarizarionObjectIntoMap.getOrDefault(accountingMappingConf.getValue(),accountingMappingConf.getDefaultvalue()));
            }
        } catch (Exception e) {
            log.error("Alert -------------------------->Exception inside Accounting Utilities, mapData method");
        }
    }

    private void fetchConditionValue(Map<String, Object> finalOutputAccountingMapConfMap, Map<String, Object> summarizarionObjectIntoMap, AccountingMappingConfModel accountingMappingConf, String value) {

            String test = StringUtils.split(value,"?")[0];
            String testValue = StringUtils.split(value,"?")[1];

            if (StringUtils.containsAny("==", test) && StringUtils.equalsIgnoreCase(
                    (String)summarizarionObjectIntoMap.get(StringUtils.substringBetween(test,"{","}"))
                    ,StringUtils.substringBetween(test,"[","]")) ){
                testValue = constructValue(summarizarionObjectIntoMap, testValue);
                finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), StringUtils.trim(testValue));
            }


    }

    private String constructValue(Map<String, Object> summarizarionObjectIntoMap, String value) {
        String[] al = StringUtils.substringsBetween(value,"{","}");
        if (al == null){
            return value;
        }
        for (String s: al ) {
            value = StringUtils.replace(value,s,(String)summarizarionObjectIntoMap.getOrDefault(s,null));
        }
        value = StringUtils.removeAll(value, "([{}])");
        return value;
    }

    public StringBuilder getDynamicValueFormation(Map<String, Object> summarizarionObjectIntoMap,
                                                  String columnValueToChange, String columnName, String mappingTableDefaultValue) {
        StringBuilder dynamicValueFormat = null;
        String moduleId = summarizarionObjectIntoMap.get("moduleId") != null
                ? summarizarionObjectIntoMap.get("moduleId").toString() : null;
        String accountType = summarizarionObjectIntoMap.get("accountType") != null
                ? summarizarionObjectIntoMap.get("accountType").toString() : null;
        if (columnValueToChange != null) {
            String[] strarr = columnValueToChange.split(",", 0);
            dynamicValueFormat = new StringBuilder();
            DateFormat originalFormat1 = new SimpleDateFormat("yyyy-MM-dd");
            DateFormat formatter1 = new SimpleDateFormat("dd-MMM-yyyy");
            for (String str : strarr) {
                if (str.startsWith("batch") || str.startsWith("accountingAttribute")
                        || str.startsWith("monthClosedDate")) {
                    String value = summarizarionObjectIntoMap.get(str) != null
                            ? summarizarionObjectIntoMap.get(str).toString() : null;
                    Date date = null;
                    if (Arrays.asList("effectiveDate", "journalLineDescription", "saleReportingPeriodEndDate")
                            .contains(columnName)) {
                        if (str.startsWith("batch") && (StringUtils.contains(value, "/"))
                                || StringUtils.contains(value, "-")) {
                            try {
                                date = originalFormat1.parse(value);
                                if (moduleId != null && Arrays.asList("M", "W").contains(moduleId)
                                        && StringUtils.equals("journalLineDescription", columnName)) {
                                    dynamicValueFormat.append(new SimpleDateFormat("MMM").format(date)
                                            + new SimpleDateFormat("yy").format(date));
                                } else {
                                    dynamicValueFormat.append(formatter1.format(date));
                                }
                            } catch (ParseException e) {
                                log.error("Exception occurs in date Format " + e.getMessage());
                            }
                        } else {
                            dynamicValueFormat.append(value);
                        }
                    } /*else if (StringUtils.equalsIgnoreCase(columnName, "jvNumber")) {
						if (str.startsWith("batch") && (StringUtils.contains(value, "/"))
								|| StringUtils.contains(value, "-")) {
							try {
								date = originalFormat1.parse(value);
							} catch (ParseException e) {
								log.error("Exception occurs in date Format " + e.getMessage());
							}
							dynamicValueFormat.append(new SimpleDateFormat("MM").format(date) + "-"
									+ new SimpleDateFormat("yy").format(date));
						} else {
							dynamicValueFormat.append(StringUtils.join(
									StringUtils.leftPad(String.valueOf(summarizarionObjectIntoMap.get(str)), 6, "0")));
						}
					}*/ else {
                        dynamicValueFormat.append(summarizarionObjectIntoMap.get(str));
                    }
                    if (!str.equals("/")) {
                        dynamicValueFormat.append(" ");
                    }
                } else {
                    if (str.equals("/")) {
                        StringBuilder temp = new StringBuilder(dynamicValueFormat.toString().trim());
                        dynamicValueFormat = temp.append(str);
                    } else {
                        dynamicValueFormat.append(str);
                    }
                    if (!str.equals("/")) {
                        dynamicValueFormat.append(" ");
                    }
                }
            }
            try {
                if (StringUtils.isNotBlank(mappingTableDefaultValue) && StringUtils.equalsIgnoreCase(accountType,"GL")) {
                    String attributeValue = (String) summarizarionObjectIntoMap.get(mappingTableDefaultValue);
                    if (attributeValue != null && moduleId != null && StringUtils.equalsIgnoreCase("M", moduleId)
                            && StringUtils.equalsIgnoreCase("journalLineDescription", columnName)) {
                        if (StringUtils.equals("I", attributeValue)) {
                            dynamicValueFormat.insert(0, "Inward ");
                        } else {
                            dynamicValueFormat.insert(0, "Outward ");
                            StringBuilder replaceFromWord = new StringBuilder(
                                    dynamicValueFormat.toString().replace("from", "to"));
                            dynamicValueFormat = replaceFromWord;
                        }
                    }
                    if (attributeValue != null && moduleId != null
                            && Arrays.asList("financialDocumentDayBookType", "sourceReference").contains(columnName)
                            && StringUtils.equalsIgnoreCase("M", moduleId)) {
                        StringBuilder temp = new StringBuilder(dynamicValueFormat.toString().trim());
                        dynamicValueFormat = temp.append(attributeValue);
                    }
                }
            } catch (Exception e) {
                log.error("Exception while invoking summarization method");
            }
        }
        return dynamicValueFormat;
    }

    public static FileLogging initFileLogging(int totalCounts, int transferredCounts, String fileType,
                                              String fileFormat, String status) {
        FileLogging fileLogging = new FileLogging();
        fileLogging.setFileCategory(fileFormat);
        fileLogging.setFileType(fileType);
        fileLogging.setProcessedBy(AccountsConstants.PROCESSED_BY_MANUAL);
        fileLogging.setSource(AccountsConstants.CREATED_BY_ACCOUNTING);
        fileLogging.setCreatedBy(AccountsConstants.CREATED_BY_ACCOUNTING);
        fileLogging.setModuleName(AccountsConstants.CREATED_BY_ACCOUNTING);
        fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_OUTPUT);
        fileLogging.setFileStatus(status);
        fileLogging.setIsEncryptedPostSuccess(AccountsConstants.N);
        fileLogging.setIsEncryptedPriorLoading(AccountsConstants.N);
        fileLogging.setIsRenamedPostSuccess(AccountsConstants.N);
        fileLogging.setIsMovedToRelevantFolder(AccountsConstants.N);
        fileLogging.setIsNotificationSent(AccountsConstants.N);
        fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
        fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
        fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));
        fileLogging.setHeaderCounts(1);
        fileLogging.setTotalCounts(totalCounts);
        fileLogging.setDetailCounts(0);
        fileLogging.setTransferredCounts(transferredCounts);
        fileLogging.setErrorCounts(0);
        fileLogging.setFileName("Accounting - temp");
        return fileLogging;
    }

    public LocalDate convertStringToLocalDate(String stringDate) {
        try {
            if (stringDate != null && StringUtils.isNotEmpty(stringDate.trim())) {
                return LocalDate.parse(stringDate);
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public void constructFileNameAndPaths(AccountingExtractFileNamingEntity fileEntity, String moduleType,
			String subModule, String accountType, LocalDate monthClosedDate, String fileId,
			AccountingExtractResponse accountingExtractResponse) {
		log.info("Inside AccountingFileExtractService class, constructFileNameAndPaths method");
		try {
			if (StringUtils.isBlank(fileEntity.getFileType()) || StringUtils.isBlank(fileEntity.getInterfaceFileName())
					|| StringUtils.isBlank(fileEntity.getSuccessPath())) {
				log.info("Oops ! Some of the values in the file naming config table was empty");
				throw new RuntimeException();
			}
			File directory = new File(fileEntity.getSuccessPath());
			if (!directory.exists()) {
				log.info("************Checking directory is creating or not with the path************");
				directory.mkdirs();
			}
			StringBuilder fileName = new StringBuilder();
			fileName.append(accountType);
			fileName.append("_");
			LocalDateTime todayDateTime = LocalDateTime.now();
//			DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern(fileEntity.getFileDateTimeFormat());
//			DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(fileEntity.getFileDateFormat());
			DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyMMddHH.mm.ss.SSS");
			String formatDateTime = todayDateTime.format(timeFormatter);
			if(StringUtils.equalsIgnoreCase("6E", fileEntity.getClientId())) {
				fileName.append(fileId);
				fileName.append("_");
				fileName.append(dateFormatter.format(LocalDate.now()));
			} else {
				fileName.append(StringUtils.join(StringUtils.leftPad(String.valueOf(fileId), 10, "0")));
				fileName.append("_");
				fileName.append(moduleType);
			}
			String regex = fileEntity.getInterfaceFileName();
			if (!fileName.toString().matches(regex)) {
				throw new RuntimeException();
			}
			
			if(!StringUtils.equalsIgnoreCase("6E", fileEntity.getClientId())) {
				fileName.append("_");
				if (StringUtils.isNotBlank(subModule)) {
					fileName.append(subModule);
					fileName.append("_");
				}
				fileName.append(dateFormatter.format(monthClosedDate));
				fileName.append("_");
				fileName.append(formatDateTime);
			} 
			fileName.append(".");
			fileName.append(fileEntity.getFileType().toLowerCase());
			fileEntity.setInterfaceFileName(fileName.toString());
			StringBuilder tempSuccessPath = new StringBuilder();
			tempSuccessPath.append(fileEntity.getSuccessPath());
			tempSuccessPath.append(accountType);
			tempSuccessPath.append(File.separator);
			tempSuccessPath.append(monthClosedDate.toString());
			tempSuccessPath.append(File.separator);
			StringBuilder tempErrorPath = new StringBuilder();
			tempErrorPath.append(fileEntity.getErrorPath());
			tempErrorPath.append(accountType);
			tempErrorPath.append(File.separator);
			tempErrorPath.append(monthClosedDate.toString());
			tempErrorPath.append(File.separator);
			fileEntity.setSuccessPath(tempSuccessPath.toString());
			fileEntity.setErrorPath(tempErrorPath.toString());
		} catch (Exception e) {
			log.error("Exception inside AccountingFileExtractService class, constructFileNameAndPaths method");
			accountingExtractResponse.setErrorMessage("There was an error in the File Naming Config table entry");
			accountingExtractResponse.setStatus(AccountsConstants.FAILURE);
		}
	}
}