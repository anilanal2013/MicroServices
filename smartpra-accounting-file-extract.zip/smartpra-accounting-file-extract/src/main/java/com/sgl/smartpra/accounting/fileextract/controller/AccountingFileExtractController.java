package com.sgl.smartpra.accounting.fileextract.controller;

import java.time.LocalDate;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.accounting.fileextract.service.AccountingFileExtractServices;
import com.sgl.smartpra.accounting.fileextract.utility.AccountExtractRequest;
import com.sgl.smartpra.accounting.fileextract.utility.FileExtractConstants;
import com.sgl.smartpra.accounting.utils.AccountingExtractResponse;
import com.sgl.smartpra.accounting.utils.AccountingUtilities;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Siva Kumar
 *
 */

@RestController
@Slf4j
@RequestMapping("/accounting-extract")
public class AccountingFileExtractController {

	@Autowired
	private AccountingFileExtractServices extractService;

	@Autowired
	private AccountingUtilities utilities;

	@PostMapping("/saveAccountingExtract")
	public AccountingExtractResponse saveAccountingExtract(@RequestBody AccountExtractRequest request) {
		log.info("Inside AccountingFileExtractController class, saveAccountingExtract method");
		AccountingExtractResponse accountingExtractResponse = new AccountingExtractResponse();
		try {
			String clientId = request.getClientId(); 
			String moduleId = request.getModuleId(); 
			String subModule = request.getSubModule();
			String accountType = request.getAccountType();  
			String fileType = request.getFileType();  
			String monthClosedDate = request.getMonthClosedDate();
			if (StringUtils.isBlank(clientId) || StringUtils.isBlank(moduleId) || StringUtils.isBlank(accountType)
					|| StringUtils.isBlank(fileType)) {
				accountingExtractResponse
						.setErrorMessage("Client Id, Module Id, Account Type, File Type should not be empty");
				accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
				return accountingExtractResponse;
			}
			if (StringUtils.isBlank(subModule) && !StringUtils.equals(accountType,"GL")) {
				accountingExtractResponse
						.setErrorMessage("Sub module should not be empty");
				accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
				return accountingExtractResponse;
			}
			String validateFileType = extractService.validateInputFileType(fileType);
			if (validateFileType != null) {
				accountingExtractResponse.setErrorMessage(validateFileType);
				accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
				return accountingExtractResponse;
			}
			LocalDate localDate = utilities.convertStringToLocalDate(monthClosedDate);
			if (localDate == null) {
				accountingExtractResponse.setErrorMessage("Month Closed Date should be yyyy-mm-dd format");
				accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
				return accountingExtractResponse;
			}
			extractService.saveAccountingExtract(clientId, moduleId, subModule, accountType, fileType.toLowerCase(),
					monthClosedDate, accountingExtractResponse);
		} catch (Exception ex) {
			log.error("Exception inside AccountingFileExtractController class, saveAccountingExtract method");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			accountingExtractResponse.setData(null);
			accountingExtractResponse.setSuccessMessage(null);
			accountingExtractResponse.setErrorMessage(ex.getMessage());
		}
		return accountingExtractResponse;
	}
}
