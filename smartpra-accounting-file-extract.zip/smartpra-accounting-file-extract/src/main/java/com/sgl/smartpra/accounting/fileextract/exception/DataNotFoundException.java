package com.sgl.smartpra.accounting.fileextract.exception;

public class DataNotFoundException extends Exception {
	
	private static final long serialVersionUID = -1071055794200233798L;

	public DataNotFoundException(String s) {
		super(s);
	}

}
