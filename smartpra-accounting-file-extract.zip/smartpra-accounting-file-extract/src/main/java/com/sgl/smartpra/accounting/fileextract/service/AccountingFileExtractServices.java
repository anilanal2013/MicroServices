package com.sgl.smartpra.accounting.fileextract.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.accounting.entity.AccountingAuditTrialEntity;
import com.sgl.smartpra.accounting.entity.AccountingExtractEntity;
import com.sgl.smartpra.accounting.entity.AccountingExtractFileNamingEntity;
import com.sgl.smartpra.accounting.entity.AccountingExtractMappingEntity;
import com.sgl.smartpra.accounting.entity.AccountingFileExtractLogsEntity;
import com.sgl.smartpra.accounting.entity.AccountingKeyEntity;
import com.sgl.smartpra.accounting.entity.AccountingSummarizationEntity;
import com.sgl.smartpra.accounting.exceptions.FeignClientException;
import com.sgl.smartpra.accounting.fileextract.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.accounting.fileextract.config.FeignConfiguration.SequenceAppFeignClient;
import com.sgl.smartpra.accounting.fileextract.exception.DataNotFoundException;
import com.sgl.smartpra.accounting.fileextract.utility.FileExtractConstants;
import com.sgl.smartpra.accounting.mapper.AccountingExtractARAPMapper;
import com.sgl.smartpra.accounting.mapper.AccountingExtractGLMapper;
import com.sgl.smartpra.accounting.model.AccountingExtractModelAPAR;
import com.sgl.smartpra.accounting.model.AccountingExtractModelGL;
import com.sgl.smartpra.accounting.model.AccountingMappingConfModel;
import com.sgl.smartpra.accounting.repository.AccountAuditTrialRepository;
import com.sgl.smartpra.accounting.repository.AccountingExtractFileNamingRepository;
import com.sgl.smartpra.accounting.repository.AccountingExtractMappingRepository;
import com.sgl.smartpra.accounting.repository.AccountingExtractRepository;
import com.sgl.smartpra.accounting.repository.AccountingFileExtractLogsRepository;
import com.sgl.smartpra.accounting.repository.AccountingKeyRepository;
import com.sgl.smartpra.accounting.repository.AccountingSummarizationRepository;
import com.sgl.smartpra.accounting.utils.AccountingExtractResponse;
import com.sgl.smartpra.accounting.utils.AccountingUtilities;
import com.sgl.smartpra.accounting.utils.AccountsConstants;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Siva Kumar
 *
 */

@Service
@Slf4j

public class AccountingFileExtractServices {

	@Autowired
	private AccountingExtractRepository extractRepo;

	@Autowired
	private AccountingExtractMappingRepository mappingRepo;

	@Autowired
	private AccountingExtractFileNamingRepository fileNamingConfigRepo;

	@Autowired
	private AccountingSummarizationRepository summarRepo;

	@Autowired
	AccountingFileExtractLogsRepository logsRepo;

	@Autowired
	private AccountingKeyRepository accountingKeyRepo;

	@Autowired
	private AccountAuditTrialRepository auditTrailRepo;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private AccountingUtilities utilities;

	@Autowired
	private BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	private SequenceAppFeignClient sequenceAppFeignClient;

	@Autowired
	private AccountingExtractGLMapper glMapper;

	@Autowired
	private AccountingExtractARAPMapper arapMapper;

	// @Autowired private AccountingExtractXMLPojo xmlpojo;

	private AccountingExtractResponse accountingExtractResponse;

	// @Autowired
	// private ExceptionLoggingService exceptionLoggingService;

	@Value("${supportedFormat}")
	private String supportedFormat;

	private List<String> listOfFiles = null;

	private String clientId, moduleId, subModule, accountType, fileType = null;

	private LocalDate localMonthClosedDate = null;

	@SuppressWarnings("unchecked")
	@Transactional
	public AccountingExtractResponse saveAccountingExtract(String clientId, String moduleId, String subMod,
			String accountType, String fileType, String monthClosedDate,
			AccountingExtractResponse accountingExtractResponse) {
		log.info("Inside AccountingFileExtractService class, saveAccountingExtract method");
		Instant startTime = Instant.now();
		try {
			this.accountingExtractResponse = accountingExtractResponse;
			this.listOfFiles = new ArrayList<>();
			this.clientId = clientId;
			this.moduleId = moduleId;
			this.subModule = subMod;
			this.accountType = accountType;
			this.fileType = fileType;
			this.localMonthClosedDate = utilities.convertStringToLocalDate(monthClosedDate);
			List<AccountingExtractMappingEntity> headerAndFileNameAndMappingDataList = null;
			String accountTypeWithSuffix = accountType + FileExtractConstants.EXTRACT;
			String tempFileHeaderType = accountTypeWithSuffix + FileExtractConstants.HEADER;
			String tempFileNameType = accountTypeWithSuffix + FileExtractConstants.FILENAME;
			String tempFileDetailedHeader = null;
			String tempFileDetailedRecord = null;
			if (StringUtils.equalsIgnoreCase(accountType, AccountsConstants.ACCOUNTTYPE_GL)) {
				String[] headerAndFileNameAndAccountType = { tempFileHeaderType, tempFileNameType,
						accountTypeWithSuffix };
				headerAndFileNameAndMappingDataList = fetchMappingRecordBasedOnInputParams(
						headerAndFileNameAndAccountType);
			} else {
				accountTypeWithSuffix = accountTypeWithSuffix + FileExtractConstants.HEADERRECORD;
				tempFileHeaderType = accountTypeWithSuffix + FileExtractConstants.HEADER;
				tempFileDetailedRecord = accountType + FileExtractConstants.EXTRACT
						+ FileExtractConstants.DETAILEDRECORD;
				tempFileDetailedHeader = tempFileDetailedRecord + FileExtractConstants.HEADER;
				String[] headerAndFileNameAndAccountType = { accountTypeWithSuffix, tempFileHeaderType,
						tempFileNameType, tempFileDetailedRecord, tempFileDetailedHeader };
				headerAndFileNameAndMappingDataList = fetchMappingRecordBasedOnInputParams(
						headerAndFileNameAndAccountType);
			}
			Map<String, List<AccountingExtractMappingEntity>> headerAndFileNameAndMappingDataMap = null;
			List<AccountingExtractMappingEntity> fileNameDataList = null;
			Map<String, Object> generatedJvNumberMap = null;
			Map<String, Object> validAndInvalidSummMap = null;
			if (headerAndFileNameAndMappingDataList != null && headerAndFileNameAndMappingDataList.isEmpty()) {
				throw new DataNotFoundException("There is no record found for the given inputs in the mapping table ");
			}
			headerAndFileNameAndMappingDataMap = headerAndFileNameAndMappingDataList.stream()
					.collect(Collectors.groupingBy(AccountingExtractMappingEntity::getAccounttype));

			if (headerAndFileNameAndMappingDataMap != null) {
				fileNameDataList = headerAndFileNameAndMappingDataMap.get(tempFileNameType) != null
						? headerAndFileNameAndMappingDataMap.get(tempFileNameType) : Collections.emptyList();
			}
			String fileTypeBasedOnModule = getFileNamePrefixFromMappingTable(fileNameDataList);
			if (!fileNameDataList.isEmpty() && fileTypeBasedOnModule != null) {
				List<AccountingSummarizationEntity> summarizationList = null;
				subModule = StringUtils.isNotEmpty(subMod) ? subMod : null;
				if (StringUtils.equalsIgnoreCase(AccountsConstants.ACCOUNTTYPE_GL, accountType)) {
					if (StringUtils.isNotEmpty(subModule)) {
						summarizationList = summarRepo.getGLRecordFilterBySubModule(clientId, moduleId, subModule,
								accountType, localMonthClosedDate, AccountsConstants.ERROR_EXTRACT);
					} else {
						summarizationList = summarRepo.getGLAllRecord(clientId, moduleId, accountType,
								localMonthClosedDate, AccountsConstants.ERROR_EXTRACT);
					}

				} else {
					summarizationList = summarRepo.getARAPRecord(clientId, moduleId, this.subModule, accountType,
							localMonthClosedDate, AccountsConstants.ERROR_EXTRACT);
				}
				if (summarizationList != null && summarizationList.isEmpty()) {
					throw new DataNotFoundException(
							"There is no record found for the given inputs in the summarization table ");
				}
				validAndInvalidSummMap = validateSummarizationCreditAndDebtiAmount(summarizationList);
				List<AccountingSummarizationEntity> validSummList = (List<AccountingSummarizationEntity>) validAndInvalidSummMap
						.get(FileExtractConstants.VALID_SUMM_LIST);
				if (validSummList == null || validSummList.isEmpty()) {
					throw new DataNotFoundException(
							"There is no valid cr/dr record found for the given inputs in the summarization table ");
				}
				Set<String> summarizationIdsList = getSummarizationIdList(validSummList);
				List<Map<String, Object>> summarizationMappingList = objectMapper.convertValue(validSummList,
						new TypeReference<List<Map<String, Object>>>() {
						});
				List<AccountingExtractMappingEntity> mappingList = headerAndFileNameAndMappingDataMap
						.get(accountTypeWithSuffix) != null
								? headerAndFileNameAndMappingDataMap.get(accountTypeWithSuffix)
								: Collections.emptyList();
				if (!StringUtils.equalsIgnoreCase(accountType, AccountsConstants.ACCOUNTTYPE_GL)) {
					List<AccountingExtractMappingEntity> detailedRecordList = headerAndFileNameAndMappingDataMap
							.get(tempFileDetailedRecord) != null
									? headerAndFileNameAndMappingDataMap.get(tempFileDetailedRecord)
									: Collections.emptyList();
					mappingList.addAll(detailedRecordList);
				}
				if (!mappingList.isEmpty()) {
					generatedJvNumberMap = getJVNumberMap(clientId, accountType, monthClosedDate, summarizationIdsList);
					if (generatedJvNumberMap != null) {
						// Need to change the logic with res to AR/AP
						List<AccountingExtractModelGL> accountingExtractModelListForGL = null;
						List<AccountingExtractModelAPAR> accountingExtractModelListForARAP = null;
						List<Map<String, Object>> finalOutputAccountingMapConfList = new ArrayList<>();
						if (StringUtils.equalsIgnoreCase(AccountsConstants.ACCOUNTTYPE_GL, accountType)) {
							accountingExtractModelListForGL = convertMappingTableIntoExtractModelForGL(
									summarizationMappingList, mappingList, generatedJvNumberMap,
									finalOutputAccountingMapConfList);
							if (!accountingExtractModelListForGL.isEmpty()) {
								accountingExtractResponse = convertExtractModelIntoFileBasedOnAccountType(
										fileTypeBasedOnModule, summarizationList, accountingExtractModelListForGL,
										accountingExtractModelListForARAP, generatedJvNumberMap,
										headerAndFileNameAndMappingDataMap, validAndInvalidSummMap,
										finalOutputAccountingMapConfList);
							} else {
								accountingExtractResponse.setErrorMessage(
										"Error occurs while converting Extact Model from Mapping table ");
								accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
								return accountingExtractResponse;
							}
						} else {
							accountingExtractModelListForARAP = convertMappingTableIntoExtractModelForARAP(
									summarizationMappingList, mappingList, generatedJvNumberMap,
									finalOutputAccountingMapConfList);
							if (!accountingExtractModelListForARAP.isEmpty()) {
								accountingExtractResponse = convertExtractModelIntoFileBasedOnAccountType(
										fileTypeBasedOnModule, summarizationList, accountingExtractModelListForGL,
										accountingExtractModelListForARAP, generatedJvNumberMap,
										headerAndFileNameAndMappingDataMap, validAndInvalidSummMap,
										finalOutputAccountingMapConfList);
							} else {
								accountingExtractResponse.setErrorMessage(
										"Error occurs while converting Extact Model from Mapping table ");
								accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
								return accountingExtractResponse;
							}
						}
					} else {
						accountingExtractResponse.setErrorMessage("There is problem with generating Jv Number");
						accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
						return accountingExtractResponse;
					}
				} else {
					accountingExtractResponse
							.setErrorMessage("There is problem with matching summarization data with mapping data");
					accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
					return accountingExtractResponse;
				}

			} else {
				accountingExtractResponse.setErrorMessage(
						"There is no record found for file name prefix for the given module in the mapping table ");
				accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
				return accountingExtractResponse;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception inside AccountingFileExtractService class, saveAccountingExtract method");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			accountingExtractResponse.setErrorMessage(e.getMessage());
			accountingExtractResponse.setData(null);
			accountingExtractResponse.setStatus(null);
			deleteFiles();
		}
		Instant endTime = Instant.now();
		long timeElapsed = Duration.between(startTime, endTime).toMillis();
		log.info("*********************** Request to Response Time =" + timeElapsed + " ms");
		return accountingExtractResponse;
	}

	private Map<String, Object> validateSummarizationCreditAndDebtiAmount(
			List<AccountingSummarizationEntity> summEntityList) {
		Map<String, Object> validAndInValidSummMap = new HashMap<>();
		List<AccountingSummarizationEntity> validSummList = new ArrayList<>();
		List<AccountingSummarizationEntity> inValidSummList = new ArrayList<>();
		Map<String, List<AccountingSummarizationEntity>> crdrMap = summEntityList.stream()
				.collect(Collectors.groupingBy(AccountingSummarizationEntity::getSummarizationId));
		Set<String> summIdList = getSummarizationIdList(summEntityList);
		for (String summid : summIdList) {
			List<AccountingSummarizationEntity> summList = crdrMap.get(summid);
			BigDecimal sumOfBaseCredit = summList.stream()
					.map(AccountingSummarizationEntity::getCrAmountInBaseCurrency).reduce(BigDecimal::add).get();
			BigDecimal sumofBaseDebit = summList.stream()
					.map(AccountingSummarizationEntity::getDrAmountInBaseCurrency).reduce(BigDecimal::add).get();
			BigDecimal sumOfTransCredit = summList.stream()
					.map(AccountingSummarizationEntity::getCrAmountInTransCurrency).reduce(BigDecimal::add).get();
			BigDecimal sumofTransDebit = summList.stream()
					.map(AccountingSummarizationEntity::getDrAmountInTransCurrency).reduce(BigDecimal::add).get();
			if (sumOfBaseCredit.compareTo(sumofBaseDebit) != 0 || sumOfTransCredit.compareTo(sumofTransDebit) != 0) {
				summList.forEach(summEntity -> {
					summEntity.setStatus(AccountsConstants.ERROR_EXTRACT);
				});
				inValidSummList.addAll(summList);
			} else {
				summList.forEach(summEntity -> {
					summEntity.setStatus(accountType + FileExtractConstants.EXTRACT);
				});
				validSummList.addAll(summList);
				validAndInValidSummMap.put(summid, sumOfBaseCredit + "," + sumofBaseDebit + "," + sumOfTransCredit + ","
						+ sumofTransDebit + "," + summList.size());
			}
		}
		validAndInValidSummMap.put(FileExtractConstants.INVALID_SUMM_LIST, inValidSummList);
		validAndInValidSummMap.put(FileExtractConstants.VALID_SUMM_LIST, validSummList);
		return validAndInValidSummMap;
	}

	/**
	 * @param clientId
	 * @param moduleId
	 * @param accountType
	 * @param tempFileHeaderType
	 * @param tempFileNameType
	 * @return
	 */
	private List<AccountingExtractMappingEntity> fetchMappingRecordBasedOnInputParams(
			String[] headerAndFileNameAndAccountType) {
		return mappingRepo.findByClientIdAndModuleIdAndAccounttypeInOrderBySequencenumberAsc(clientId, moduleId,
				Arrays.asList(headerAndFileNameAndAccountType));
	}

	/**
	 * @param fileNameDataList
	 * @return fileTypeBasedOnModule
	 */
	private String getFileNamePrefixFromMappingTable(List<AccountingExtractMappingEntity> fileNameDataList) {
		String fileTypeBasedOnModule = null;
		if (!fileNameDataList.isEmpty()) {
			fileTypeBasedOnModule = StringUtils.isNotBlank(fileNameDataList.get(0).getValue())
					? fileNameDataList.get(0).getValue() : "XX";
		}
		return fileTypeBasedOnModule;
	}

	/**
	 * @param clientId
	 * @param moduleId
	 * @param subModule
	 * @param accountType
	 * @param fileType
	 * @param localMonthClosedDate
	 * @param csvColumnAndDataList
	 * @param fileTypeBasedOnModule
	 * @param summarizationList
	 * @param accountingExtractModelList
	 */
	@Transactional
	private AccountingExtractResponse convertExtractModelIntoFileBasedOnAccountType(String fileTypeBasedOnModule,
			List<AccountingSummarizationEntity> summarizationList,
			List<AccountingExtractModelGL> accountingExtractModelListForGL,
			List<AccountingExtractModelAPAR> accountingExtractModelListForARAP,
			Map<String, Object> jvNumberAndExtractLogsDataMap,
			Map<String, List<AccountingExtractMappingEntity>> mappingDataMap,
			Map<String, Object> validAndInvalidSummMap, List<Map<String, Object>> arapList) {
		List<AccountingExtractFileNamingEntity> fileNamingConfigList = fileNamingConfigRepo
				.findByClientIdAndModuleIdAndSubModuleIgnoreCaseAndFileTypeAndAccountType(clientId, moduleId, subModule,
						fileType, accountType);
		if (!fileNamingConfigList.isEmpty()) {
			List<AccountingExtractEntity> totalFileList = new ArrayList<>();
			FileLogging filelogging = null;
			AtomicInteger count = new AtomicInteger();
			for (AccountingExtractFileNamingEntity fileConfigEntity : fileNamingConfigList) {
				String tempFileName = fileConfigEntity.getInterfaceFileName();
				String tempSuccessPath = fileConfigEntity.getSuccessPath();
				String tempErrorPath = fileConfigEntity.getErrorPath();
				if (StringUtils.equalsIgnoreCase(fileType, AccountsConstants.FILECATEGORY_CSV)) {
					filelogging = batchGlobalFeignClient.createFileLog(
							AccountingUtilities.initFileLogging(0, 0, accountType, AccountsConstants.FILECATEGORY_CSV,
									FileLoggingConstants.FILELOGGING_FILESTATUS_STARTED));
					if (filelogging != null && filelogging.getFileId() != null) {
						String actualFinRunId = filelogging.getFileId().toString();
						if (StringUtils.equalsIgnoreCase(clientId, "6E")) {
							actualFinRunId = String.valueOf(count.incrementAndGet());
						}
						AccountingKeyEntity existingAccKeyRec = accountingKeyRepo
								.findByClientIdAndModuleIdAndKeyValAndInterfaceType(clientId, moduleId, actualFinRunId,
										accountType + FileExtractConstants.EXTRACT);
						if (existingAccKeyRec != null && !StringUtils.equalsIgnoreCase(clientId, "6E")) {
							actualFinRunId = existingAccKeyRec.getInterfaceJvNumber();
						} else {
							actualFinRunId = StringUtils.join(StringUtils.leftPad(actualFinRunId, 4, "0"));
						}
						AccountingKeyEntity accKeyRec = new AccountingKeyEntity();
						accKeyRec.setClientId(clientId);
						accKeyRec.setInterfaceJvNumber(actualFinRunId);
						accKeyRec.setInterfaceType(accountType + FileExtractConstants.EXTRACT);
						accKeyRec.setKeyVal(filelogging.getFileId().toString());
						accKeyRec.setModuleId(moduleId);
						accKeyRec.setCreatedBy(FileExtractConstants.SYSTEM);
						accKeyRec.setLastUpdatedBy(FileExtractConstants.SYSTEM);
						accountingKeyRepo.save(accKeyRec);
						final String tempFileId = actualFinRunId;
						generateCSVFile(fileTypeBasedOnModule, accountingExtractModelListForGL,
								accountingExtractModelListForARAP, totalFileList, tempFileId, fileConfigEntity,
								mappingDataMap, arapList);
						if (accountingExtractResponse.getErrorMessage() != null) {
							break;
						}
					} else {
						accountingExtractResponse.setErrorMessage("Error while creating log from batch global ");
						accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
						return accountingExtractResponse;
					}
				}
				if (StringUtils.equalsIgnoreCase(AccountsConstants.ACCOUNTTYPE_GL, accountType)) {
					setFileLoggingValues(accountingExtractModelListForGL.size(),
							fileConfigEntity.getInterfaceFileName(), filelogging, clientId);
				} else {

					setFileLoggingValues(accountingExtractModelListForARAP.size(),
							fileConfigEntity.getInterfaceFileName(), filelogging, clientId);
				}
				fileConfigEntity.setInterfaceFileName(tempFileName);
				fileConfigEntity.setSuccessPath(tempSuccessPath);
				fileConfigEntity.setErrorPath(tempErrorPath);
			}
			if (accountingExtractResponse.getErrorMessage() == null) {
				if (!fileNamingConfigList.isEmpty()) {
					persistFileNamingConfig(fileNamingConfigList);
				}
				if (!totalFileList.isEmpty()) {
					persistExtractEntity(totalFileList);
				}
				if (!summarizationList.isEmpty() && !jvNumberAndExtractLogsDataMap.isEmpty()) {
					persistSummarizationEntity(validAndInvalidSummMap, filelogging, jvNumberAndExtractLogsDataMap);
				}

				if (!validAndInvalidSummMap.isEmpty() && !totalFileList.isEmpty()
						&& !jvNumberAndExtractLogsDataMap.isEmpty()) {
					persistFileExtractLogs(summarizationList, validAndInvalidSummMap, jvNumberAndExtractLogsDataMap);
				}
				accountingExtractResponse.setData(totalFileList);
				accountingExtractResponse.setStatus(FileExtractConstants.SUCCESS);
				accountingExtractResponse.setSuccessMessage("Successfully " + fileType + " file is generated !");
			}
		} else {
			accountingExtractResponse
					.setErrorMessage("There is no record found for the given inputs in the file naming config table ");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			deleteFiles();
			return accountingExtractResponse;
		}
		return accountingExtractResponse;
	}

	/**
	 * 
	 */
	private void deleteFiles() {
		log.info(
				"************************************************** Deleting the files ************************************************");
		if (!CollectionUtils.isEmpty(listOfFiles)) {
			listOfFiles.stream().forEach(file -> {
				Path path = Paths.get(file);
				try {
					Files.deleteIfExists(path);
				} catch (IOException e1) {
					accountingExtractResponse.setErrorMessage("Exception while deleting the files");
					accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
				}
			});
		}
	}

	/**
	 * @param clientId
	 * @param moduleId
	 * @param subModule
	 * @param accountType
	 * @param fileType
	 * @param localMonthClosedDate
	 * @param csvColumnAndDataList
	 * @param fileTypeBasedOnModule
	 * @param accountingExtractModelList
	 * @param accountingExtractModelListForARAP
	 * @param totalCsvFileList
	 * @param filelogging
	 * @param fileEntity
	 */
	private void generateCSVFile(String fileTypeBasedOnModule,
			List<AccountingExtractModelGL> accountingExtractModelList,
			List<AccountingExtractModelAPAR> accountingExtractModelListForARAP,
			List<AccountingExtractEntity> totalCsvFileList, String finRunId,
			AccountingExtractFileNamingEntity fileEntity,
			Map<String, List<AccountingExtractMappingEntity>> mappingDataMap,
			List<Map<String, Object>> summarizationMapList) {
		log.info("inside AccountingFileExtractService class, generateCSVFile method");
		try {
			boolean isFileCreated;
			List<AccountingExtractEntity> entityList = new ArrayList<>();
			utilities.constructFileNameAndPaths(fileEntity, fileTypeBasedOnModule, accountType, localMonthClosedDate,
					finRunId, accountingExtractResponse);
			if (accountingExtractResponse.getErrorMessage() != null) {
				return;
			}
			if (StringUtils.equalsIgnoreCase(AccountsConstants.ACCOUNTTYPE_GL, accountType)) {
				isFileCreated = createCSVFileUsingCsvMapperForGL(summarizationMapList, mappingDataMap, fileEntity,
						finRunId);
			} else {
				isFileCreated = createCSVFileUsingCsvMapperForARAP(summarizationMapList, mappingDataMap, fileEntity,
						finRunId);
			}
			if (isFileCreated) {
				if (StringUtils.equalsIgnoreCase(AccountsConstants.ACCOUNTTYPE_GL, accountType)) {
					for (AccountingExtractModelGL model : accountingExtractModelList) {
						setExtractEntityValuesFromModel(finRunId, fileEntity, entityList, model, null);
					}
				} else {
					for (AccountingExtractModelAPAR model : accountingExtractModelListForARAP) {
						setExtractEntityValuesFromModel(finRunId, fileEntity, entityList, null, model);
					}
				}
				totalCsvFileList.addAll(entityList);
			} else {
				log.error("File is not created. Something problem while creating file");
				batchGlobalFeignClient.updateFileLog(new BigInteger(finRunId),
						AccountingUtilities.initFileLogging(0, 0, accountType, AccountsConstants.FILECATEGORY_CSV,
								FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS));
				accountingExtractResponse.setErrorMessage(
						"Something problem while creating csv file. Close the opened file and try agagin");
				accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			}
		} catch (Exception e) {
			log.error("Exception inside AccountingFileExtractService class, generateCSVFile method");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			accountingExtractResponse.setErrorMessage("Error while generateCSVFile ");
			deleteFiles();
		}
	}

	/**
	 * @param summarizationMappingList
	 * @param mappingList
	 * @return
	 * @throws JsonProcessingException
	 * @throws IOException
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 */
	private List<AccountingExtractModelGL> convertMappingTableIntoExtractModelForGL(
			List<Map<String, Object>> summarizationMappingList, List<AccountingExtractMappingEntity> mappingList,
			Map<String, Object> generatedJvNumberMap, List<Map<String, Object>> glList) {
		try {
			List<Map<String, Object>> finalOutputAccountingMapConfList = setSummarizationAndMappingValues(
					summarizationMappingList, mappingList, generatedJvNumberMap);
			glList.addAll(finalOutputAccountingMapConfList);
			return objectMapper.convertValue(finalOutputAccountingMapConfList,
					new TypeReference<List<AccountingExtractModelGL>>() {
					});
		} catch (Exception e) {
			log.error(
					"Exception inside AccountingFileExtractService class, convertMappingTableIntoExtractModelForGL method");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			accountingExtractResponse
					.setErrorMessage("Error while creating convert MappingTable Into ExtractModel for GL");
			return Collections.emptyList();
		}
	}

	/**
	 * @param summarizationMappingList
	 * @param mappingList
	 * @return
	 * @throws JsonProcessingException
	 * @throws IOException
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 */
	private List<AccountingExtractModelAPAR> convertMappingTableIntoExtractModelForARAP(
			List<Map<String, Object>> summarizationMappingList, List<AccountingExtractMappingEntity> mappingList,
			Map<String, Object> generatedJvNumberMap, List<Map<String, Object>> arapList) {
		try {
			List<Map<String, Object>> finalOutputAccountingMapConfList = setSummarizationAndMappingValues(
					summarizationMappingList, mappingList, generatedJvNumberMap);
			arapList.addAll(finalOutputAccountingMapConfList);
			return objectMapper.convertValue(finalOutputAccountingMapConfList,
					new TypeReference<List<AccountingExtractModelAPAR>>() {
					});
		} catch (Exception e) {
			log.error(
					"Exception inside AccountingFileExtractService class, convertMappingTableIntoExtractModelForARAP method");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			accountingExtractResponse
					.setErrorMessage("Error while creating convert MappingTable Into ExtractModel for AP/AP");
			return Collections.emptyList();
		}
	}

	/**
	 * @param summarizationMappingList
	 * @param mappingList
	 * @param generatedJvNumberMap
	 * @return finalOutputAccountingMapConfList
	 */
	private List<Map<String, Object>> setSummarizationAndMappingValues(
			List<Map<String, Object>> summarizationMappingList, List<AccountingExtractMappingEntity> mappingList,
			Map<String, Object> generatedJvNumberMap) {
		try {
			String mappingString = objectMapper.writeValueAsString(mappingList);
			List<AccountingMappingConfModel> accountingMappingConfModelList = objectMapper.readValue(mappingString,
					new TypeReference<List<AccountingMappingConfModel>>() {
					});
			return utilities.fetchAccountsBasedOnSummarizationAndMappingConf(summarizationMappingList,
					accountingMappingConfModelList, generatedJvNumberMap);
		} catch (Exception e) {
			log.error("Exception inside AccountingFileExtractService class, setSummarizationAndMappingValues method");
			return Collections.emptyList();
		}
	}

	/**
	 * @param accountingExtractModelList
	 * @param interfaceFileName
	 * @param filelogging
	 */
	private void setFileLoggingValues(int noOfRecords, String interfaceFileName, FileLogging filelogging,
			String clientId) {
		log.info("Inside AccountingFileExtractService class, setFileLoggingValues method");
		if (filelogging != null) {
			filelogging.setFileName(interfaceFileName);
			filelogging.setClientId(clientId);
			int totalRowsInCSV = noOfRecords;
			filelogging.setTotalCounts(totalRowsInCSV);
			filelogging.setTransferredCounts(totalRowsInCSV);
			filelogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_CREATED);
			try {
				batchGlobalFeignClient.updateFileLog(filelogging.getFileId(), filelogging);
				log.info("Data's are stored in the updated in the file logging table");
			} catch (Exception e) {
				log.error("Exception while calling batchGlobalFeignClient with updateFileLog");
				accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
				accountingExtractResponse
						.setErrorMessage("Exception while calling batchGlobalFeignClient with updateFileLog ");
			}
		}
	}

	/**
	 * @param summarizationList
	 * @param fileId
	 */
	@SuppressWarnings("unchecked")
	private void persistSummarizationEntity(Map<String, Object> validAndInvalidSummMap, FileLogging logging,
			Map<String, Object> jvNumberAndExtractLogsDataMap) {
		log.info("inside AccountingFileExtractService class, persistSummarizationEntity method");
		Instant startTime = Instant.now();
		List<AccountingSummarizationEntity> validSummList = (List<AccountingSummarizationEntity>) validAndInvalidSummMap
				.get(FileExtractConstants.VALID_SUMM_LIST);
		List<AccountingSummarizationEntity> inValidSummList = (List<AccountingSummarizationEntity>) validAndInvalidSummMap
				.get(FileExtractConstants.INVALID_SUMM_LIST);
		try {
			if (accountingExtractResponse.getErrorMessage() == null) {
				validSummList.forEach(summarization -> {
					summarization.setGlInterfaceId(logging.getFileId().toString());
					summarization.setJvNumber(
							jvNumberAndExtractLogsDataMap.get(summarization.getSummarizationId()).toString());
				});
				List<AccountingAuditTrialEntity> auditList = auditTrailRepo
						.findBySummarisationIdIn(getSummarizationIdList(validSummList));
				auditList.forEach(audit -> {
					audit.setInterfaceJVNo(jvNumberAndExtractLogsDataMap.get(audit.getSummarisationId()).toString());
				});
				auditTrailRepo.saveAll(auditList);
				log.info("Data's are updated in the audit trail table");
				summarRepo.saveAll(validSummList);
				summarRepo.saveAll(inValidSummList);
				log.info("Data's are updated in the summarization table");
				Instant endTime = Instant.now();
				long timeElapsed = Duration.between(startTime, endTime).toMillis();
				log.info("*********************** To Save Summ & Audit Trail =" + timeElapsed + " ms");
			}
		} catch (Exception e) {
			log.error("Exception inside AccountingFileExtractService class, persistSummarizationEntity method");
			accountingExtractResponse.setErrorMessage("Something problem while saving in the summarization table");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
		}
	}

	private void persistFileNamingConfig(List<AccountingExtractFileNamingEntity> fileNamingConfigList) {
		log.info("inside AccountingFileExtractService class, persistExtractEntity method");
		try {
			if (accountingExtractResponse.getErrorMessage() == null) {
				fileNamingConfigRepo.saveAll(fileNamingConfigList);
				log.info("Data's are stored in the file naming config table");
			}
		} catch (Exception e) {
			log.error("Exception inside AccountingFileExtractService class, persistFileNamingConfig method");
			accountingExtractResponse.setErrorMessage("Something problem while saving in the accounting extract table");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			deleteFiles();
		}
	}

	/**
	 * @param totalFileList
	 */
	private void persistExtractEntity(List<AccountingExtractEntity> totalFileList) {
		log.info("inside AccountingFileExtractService class, persistExtractEntity method");
		Instant startTime = Instant.now();
		try {
			if (accountingExtractResponse.getErrorMessage() == null) {
				totalFileList.forEach(entity -> {
					entity.setExtractStatus(accountType + FileExtractConstants.EXTRACT);
				});
				extractRepo.saveAll(totalFileList);
				log.info("Data's are stored in the accounting extract table");
				Instant endTime = Instant.now();
				long timeElapsed = Duration.between(startTime, endTime).toMillis();
				log.info("*********************** To Save Extract =" + timeElapsed + " ms");
			}
		} catch (Exception e) {
			log.error("Exception inside AccountingFileExtractService class, persistExtractEntity method");
			accountingExtractResponse.setErrorMessage("Something problem while saving in the accounting extract table");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			deleteFiles();
		}
	}

	/**
	 * @param summarizationIdsList
	 * @param extractFileList
	 */
	private void persistFileExtractLogs(List<AccountingSummarizationEntity> summEntityList,
			Map<String, Object> validAndInvalidSummMap, Map<String, Object> jvNumberAndExtractLogsDataMap) {
		log.info("inside AccountingFileExtractService class, persistFileExtractLogs method");
		Instant startTime = Instant.now();
		try {
			if (accountingExtractResponse.getErrorMessage() == null) {
				Set<String> summIdList = getSummarizationIdList(summEntityList);
				List<AccountingFileExtractLogsEntity> logsList = logsRepo.findBySummarisationIdIn(summIdList);
				log.info("Record retrieved from the File Extract Logs table");
				if (!logsList.isEmpty()) {
					for (AccountingFileExtractLogsEntity item : logsList) {
						String value = validAndInvalidSummMap.get(item.getSummarisationId()) != null
								? validAndInvalidSummMap.get(item.getSummarisationId()).toString() : null;
						String[] temp = value != null ? value.split(",", 0) : null;
						if (temp != null) {
							item.setCrAmtBaseCurrExtractFile(new BigDecimal(temp[0]));
							item.setDrAmtBaseCurrExtractFile(new BigDecimal(temp[1]));
							item.setCrAmtTransCurrExtractFile(new BigDecimal(temp[2]));
							item.setDrAmtTransCurrExtractFile(new BigDecimal(temp[3]));
							item.setTotalNoOfRecordsExtracted(Integer.valueOf(temp[4]));
							item.setMonthCloseDate(localMonthClosedDate);
							item.setInterfaceJvNumber(
									jvNumberAndExtractLogsDataMap.get(item.getSummarisationId()).toString());
						}
					}
					logsRepo.saveAll(logsList);
					log.info("Data's are updated in the File Extract Logs table");
					Instant endTime = Instant.now();
					long timeElapsed = Duration.between(startTime, endTime).toMillis();
					log.info("*********************** To Save Logs =" + timeElapsed + " ms");
				} else {
					log.info("There is no data in the summarization ids in the logs table ->" + summIdList);
				}
			}
		} catch (Exception e) {
			log.error("Exception inside AccountingFileExtractService class, persistFileExtractLogs method"
					+ e.getMessage());
			accountingExtractResponse.setErrorMessage("Something problem while saving in the File Extract Logs table");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			deleteFiles();
		}
	}

	private Set<String> getSummarizationIdList(List<AccountingSummarizationEntity> summEntityList) {
		Set<String> set = summEntityList.stream().map(AccountingSummarizationEntity::getSummarizationId)
				.collect(Collectors.toSet());
		return new TreeSet<>(set);
	}

	private Map<String, Object> getJVNumberMap(String clientId, String accountType, String monthClosedDate,
			Set<String> summarizationIdsList) {
		log.info("inside AccountingFileExtractService class, getJVNumberMapAndExtractLogsData method");
		Map<String, Object> jvNumberMap = new LinkedHashMap<>();
		try {
			log.info("List of summarization id's=>" + summarizationIdsList);
			DateFormat originalFormat1 = new SimpleDateFormat("yyyy-MM-dd");
			AtomicInteger count = new AtomicInteger();
			summarizationIdsList.stream().filter(Objects::nonNull).forEach(item -> {
				if (!jvNumberMap.containsKey(item)) {
					int jvSequence = getJVNumberDynamically(accountType, count);
					Date date = null;
					try {
						date = originalFormat1.parse(monthClosedDate);
					} catch (ParseException e) {
						log.error("Exception occurs in date Format in the getJVNumberMapAndExtractLogsData"
								+ e.getMessage());
					}
					StringBuilder jvNumberWithFormat = new StringBuilder();
					if (StringUtils.equalsIgnoreCase(clientId, "6E")) {
						jvNumberWithFormat.append(new SimpleDateFormat("yy").format(date));
					} else {
						jvNumberWithFormat.append(new SimpleDateFormat("MM").format(date));
					}
					jvNumberWithFormat.append("-");
					jvNumberWithFormat.append(new SimpleDateFormat("yy").format(date));
					jvNumberWithFormat.append("/");
					jvNumberWithFormat
							.append(StringUtils.join(StringUtils.leftPad(String.valueOf(jvSequence), 6, "0")));
					jvNumberMap.put(item, jvNumberWithFormat.toString());
				}
			});

		} catch (Exception e) {
			log.error("Exception inside AccountingFileExtractService class, getJVNumberMapAndExtractLogsData method");
			accountingExtractResponse.setErrorMessage("Something problem while generating JV Number");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
		}
		return jvNumberMap;
	}

	/**
	 * @param accountType
	 * @return
	 */

	@Retryable(value = {
			FeignClientException.class }, maxAttemptsExpression = "#{${retry.maxAttempts}}", backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	private int getJVNumberDynamically(String accountType, AtomicInteger count) {
		try {
			return count.incrementAndGet();
			// jvSequence = sequenceAppFeignClient.getSequnce(accountType +
			// "_extract_sequence");
		} catch (Exception e) {
			log.error("Exception inside AccountingFileExtractService class, getJVNumberDynamically method");
			accountingExtractResponse.setErrorMessage("Something problem while calling redis cache service");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			return 0;
		}
	}

	@Recover
	public int retryForgetJVNumberDynamically(FeignClientException exception) {
		log.info("Maximum retry attempt is over and recovery is done for JVNumber");
		return 0;
	}

	/**
	 * @param clientId
	 * @param moduleId
	 * @param accountType
	 * @param filelogging
	 * @param fileId
	 * @param fileEntity
	 * @param entityList
	 * @param isFileCreated
	 * @param model
	 * @param localMonthClosedDate
	 */

	private void setExtractEntityValuesFromModel(String fileId, AccountingExtractFileNamingEntity fileEntity,
			List<AccountingExtractEntity> entityList, AccountingExtractModelGL glModel,
			AccountingExtractModelAPAR arapModel) {
		try {
			AccountingExtractEntity entityObj = null;
			if (StringUtils.equalsIgnoreCase(AccountsConstants.ACCOUNTTYPE_GL, accountType)) {
				entityObj = glMapper.mapToEntity(glModel);
			} else {
				// entityObj = arapMapper.mapToEntity(arapModel);
				entityObj = new AccountingExtractEntity();
				entityObj.setRecordType(arapModel.getRecordType());
				entityObj.setBusinessUnit(arapModel.getBusinessUnit());
				// entityObj.setInvoiceNumber(arapModel.getInvoiceNumber());
				entityObj.setReasonCode(arapModel.getReasonCode());
				entityObj.setCustomerCode(arapModel.getCustomerCode());
				entityObj.setSourceCode(arapModel.getSourceCode());
				if (StringUtils.isEmpty(arapModel.getReferenceNumber())) {
					entityObj.setReferenceNumber(0);
				} else {
					entityObj.setReferenceNumber(Integer.valueOf(arapModel.getReferenceNumber()));
				}

				if (StringUtils.isEmpty(arapModel.getCurrencyCode())) {
					entityObj.setCurrencyCode("ZZZ");
				} else {
					entityObj.setCurrencyCode(arapModel.getCurrencyCode());
				}
				if (arapModel.getAmountDue() != null) {
					entityObj.setAmountDue(new BigDecimal(arapModel.getAmountDue()));
				} else {
					entityObj.setAmountDue(new BigDecimal("0.000"));
				}

				entityObj.setGlAccount(arapModel.getAccountNumber());
				if (StringUtils.isEmpty(arapModel.getExchangeRate())) {
					entityObj.setExchangeRate(new BigDecimal("0.000"));
				} else {
					entityObj.setExchangeRate(new BigDecimal(arapModel.getExchangeRate()));
				}

				entityObj.setTerms(arapModel.getTerms());
				entityObj.setTaxable(arapModel.getTaxable());
				if (StringUtils.isEmpty(arapModel.getTaxAmount())) {
					entityObj.setTaxAmount(new BigDecimal("0.000"));
				} else {
					entityObj.setTaxAmount(new BigDecimal(arapModel.getTaxAmount()));
				}
				entityObj.setPurchaseOrderNumber(arapModel.getPurchaseOrderNumber());
				entityObj.setExchangeDate(arapModel.getExchangeDate());
				entityObj.setCustomerRef(arapModel.getCustomerRef());
				entityObj.setReserveForFutureUse_1(arapModel.getReserveForFutureUse_1());
				entityObj.setPhoneNumber(arapModel.getPhoneNumber());
				entityObj.setCustomerOrderNumber(arapModel.getCustomerOrderNumber());
				entityObj.setReserveForFutureUse_2(arapModel.getReserveForFutureUse_2());
				entityObj.setFinancialInterfaceRunIdentifier(arapModel.getFinancialInterfaceRunIdentifier());
				if (StringUtils.isEmpty(arapModel.getFinancialDocumentDayBookType())) {
					entityObj.setFinancialDocumentDayBookType("Dummy");
				} else {
					entityObj.setFinancialDocumentDayBookType(arapModel.getFinancialDocumentDayBookType());
				}
				entityObj.setSalesReportingType(arapModel.getSalesReportingType());
				entityObj.setCarrierCode(arapModel.getCarrierCode());
				entityObj.setFinancialDocumentRemarks(arapModel.getFinancialDocumentRemarks());
				entityObj.setOriginatorName(arapModel.getOriginatorName());
				entityObj.setExchangeRateType(arapModel.getExchangeRateType());
				entityObj.setAgentCode(arapModel.getAgentCode());
				if (StringUtils.isEmpty(arapModel.getSourceReference())) {
					entityObj.setSourceReference("Dum");
				} else {
					entityObj.setSourceReference(arapModel.getSourceReference());
				}
				entityObj.setClientSpecificfield_1(arapModel.getClientSpecificfield_1());
				entityObj.setClientSpecificfield_2(arapModel.getClientSpecificfield_2());
				entityObj.setBillingCategory(arapModel.getBillingCategory());
				if (StringUtils.isEmpty(arapModel.getDocumentType())) {
					entityObj.setDocumentType("Dum");
				} else {
					entityObj.setDocumentType(arapModel.getDocumentType());
				}
				entityObj.setInvoiceDueDate(arapModel.getInvoiceDueDate());
				if (StringUtils.isEmpty(arapModel.getQuantity())) {
					entityObj.setQuantity(0);
				} else {
					entityObj.setQuantity(Integer.valueOf(arapModel.getQuantity()));
				}
				if (StringUtils.isEmpty(arapModel.getUnitSellingPrice())) {
					entityObj.setUnitSellingPrice(new BigDecimal("0.000"));
				} else {
					entityObj.setUnitSellingPrice(new BigDecimal(arapModel.getUnitSellingPrice()));
				}
				if (StringUtils.isEmpty(arapModel.getJournalLineDescription())) {
					entityObj.setJournalLineDescription("Dummy");
				} else {
					entityObj.setJournalLineDescription(arapModel.getJournalLineDescription());
				}
				entityObj.setReconciliationCode(arapModel.getReconciliationCode());
				entityObj.setJobNumber(arapModel.getJobNumber());
				entityObj.setClaimNumber(arapModel.getClaimNumber());
				entityObj.setDateOfExpense(arapModel.getDateOfExpense());
				if (StringUtils.isEmpty(arapModel.getFinancialDocumentSequenceNumber())) {
					entityObj.setFinancialDocumentSequenceNumber(0);
				} else {
					entityObj.setFinancialDocumentSequenceNumber(
							Integer.valueOf(arapModel.getFinancialDocumentSequenceNumber()));
				}
				entityObj.setReserveForFutureUse_3(arapModel.getReserveForFutureUse_3());
				entityObj.setReserveForFutureUse_4(arapModel.getReserveForFutureUse_4());
				entityObj.setReserveForFutureUse_5(arapModel.getReserveForFutureUse_5());
				entityObj.setReserveForFutureUse_6(arapModel.getReserveForFutureUse_6());
				entityObj.setOrderNumber(arapModel.getOrderNumber());
				entityObj.setPointOfSale(arapModel.getPointOfSale());
				entityObj.setCostCentreCode(arapModel.getCostCentreCode());
				entityObj.setCostReallocationBusinessUnit("00");
			}
			DateFormat fromFormat = new SimpleDateFormat("dd-MMM-yyyy");
			DateFormat toFormat = new SimpleDateFormat("yyyy-MM-dd");
			String saleReportingDateWithDBFormat = null;
			String invoiceDateWithFormatted = null;
			try {
				if (glModel != null && StringUtils.isNotEmpty(glModel.getSaleReportingPeriodEndDate())) {
					Date date = fromFormat.parse(glModel.getSaleReportingPeriodEndDate());
					saleReportingDateWithDBFormat = toFormat.format(date);
				}
				if (arapModel != null && StringUtils.isNotEmpty(arapModel.getInvoiceDate())) {
					Date date = fromFormat.parse(arapModel.getInvoiceDate());
					invoiceDateWithFormatted = toFormat.format(date);
					entityObj.setInvoiceDate(utilities.convertStringToLocalDate(invoiceDateWithFormatted));
				}
				if (arapModel != null && StringUtils.isNotEmpty(arapModel.getSaleReportingPeriodEndDate())) {
					Date date = fromFormat.parse(arapModel.getSaleReportingPeriodEndDate());
					saleReportingDateWithDBFormat = toFormat.format(date);
				}
			} catch (ParseException e) {
				log.error(
						"Exception occurs in date Format inside AccountingFileExtractService class, setExtractEntityValuesFromModel method");
			}
			if (entityObj != null) {
				entityObj.setEffectiveDate(localMonthClosedDate);
				entityObj.setSaleReportingPeriodEndDate(StringUtils.isNotEmpty(saleReportingDateWithDBFormat)
						? utilities.convertStringToLocalDate(saleReportingDateWithDBFormat) : null);
				entityObj.setModuleId(moduleId);
				entityObj.setClientId(clientId);
				entityObj.setAccountType(accountType);
				entityObj.setInterfaceFileName(fileEntity != null ? fileEntity.getInterfaceFileName() : null);
				entityObj.setCreatedBy(FileExtractConstants.SYSTEM);
				entityObj.setLastUpdatedBy(FileExtractConstants.SYSTEM);
				entityObj.setSubModule(subModule);

				// Need to remove this
				if (StringUtils.equalsIgnoreCase(accountType, AccountsConstants.ACCOUNTTYPE_AP)
						|| StringUtils.equalsIgnoreCase(accountType, AccountsConstants.ACCOUNTTYPE_AR)) {
					entityObj.setDrAmountInBaseCurrency(new BigDecimal("0.00"));
					entityObj.setCrAmountInBaseCurrency(new BigDecimal("0.00"));
					entityObj.setEffectiveDate(localMonthClosedDate);
					entityObj.setExchangePeriod("Dummay");
					entityObj.setSourceCode("Dummy");
					entityObj.setDestinationCurrency("Dum");
					entityObj.setJvNumber("Dummy");
				}
				if (StringUtils.isNoneBlank(fileId)) {
					entityObj.setInterfaceFileId(fileId);
					entityObj.setFinancialInterfaceRunIdentifier(fileId);
				} else {
					entityObj.setInterfaceFileId(BigInteger.ZERO.toString());
				}
				entityList.add(entityObj);
			}
		} catch (Exception e) {
			accountingExtractResponse.setErrorMessage("Something problem while converting model to entity");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			deleteFiles();
		}
	}

	private boolean createCSVFileUsingCsvMapperForGL(List<Map<String, Object>> glSummarList,
			Map<String, List<AccountingExtractMappingEntity>> mappingDataMap,
			AccountingExtractFileNamingEntity fileEntity, String finRunId) {
		log.info("inside AccountingFileExtractService class, createCSVFileUsingCsvMapperForGL method");
		FileWriter fileWriter = null;
		CSVPrinter csvFilePrinter = null;
		try {
			String glData = accountType + FileExtractConstants.EXTRACT;
			List<String> headerSequenceOrderDataList = mappingDataMap.get(glData).stream()
					.filter(e -> e.getAccounttype().equals(glData)).map(AccountingExtractMappingEntity::getKeyval)
					.collect(Collectors.toList());
			List<AccountingExtractMappingEntity> hearderMap = mappingDataMap
					.get(glData + FileExtractConstants.HEADER) != null
							? mappingDataMap.get(glData + FileExtractConstants.HEADER) : Collections.emptyList();
			AccountingExtractMappingEntity glEntity = null;
			Object[] headerArray = null;
			if (!hearderMap.isEmpty()) {
				glEntity = hearderMap.get(0) != null ? hearderMap.get(0) : null;
				if (glEntity != null) {
					headerArray = glEntity.getDefaultvalue() != null ? glEntity.getDefaultvalue().split(",", 0) : null;
				}
			}
			CSVFormat csvFileFormat = CSVFormat.DEFAULT.withRecordSeparator("\n");
			String pathAndFileName = fileEntity.getSuccessPath() + fileEntity.getInterfaceFileName();
			File directory = new File(fileEntity.getSuccessPath());
			if (!directory.exists()) {
				log.info("************New directory created************");
				directory.mkdirs();
			}
			fileWriter = new FileWriter(pathAndFileName);
			csvFilePrinter = new CSVPrinter(fileWriter, csvFileFormat);
			if (headerArray != null) {
				csvFilePrinter.printRecord(headerArray);
			}
			
			for (Map<String, Object> map : glSummarList) {
				List<String> glCsvList = new ArrayList<>();
				for (String headerData : headerSequenceOrderDataList) {
					String value = map.get(headerData) != null ? map.get(headerData).toString() : "";
					if(Arrays.asList("drAmtInTransCurrency","crAmtInTransCurrency").contains(headerData)) {
						continue;
					}
					if (StringUtils.equalsIgnoreCase(headerData, "financialInterfaceRunIdentifier")) {
						glCsvList.add(finRunId);
					} else {
						glCsvList.add(value);
					}
				}
				csvFilePrinter.printRecord(glCsvList);
			}
			listOfFiles.add(pathAndFileName);
			log.info("CSV File Generated Successfully in the path =>" + pathAndFileName);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("exception inside AccountingFileExtractService class, createCSVFileUsingCsvMapperForGL method");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			accountingExtractResponse.setErrorMessage("Something problem while creating csv file");
			return false;
		} finally {
			try {
				if (fileWriter != null && csvFilePrinter != null) {
					fileWriter.flush();
					csvFilePrinter.flush();
					csvFilePrinter.close();
					fileWriter.close();
				}
			} catch (IOException e1) {
				log.error(
						"exception inside AccountingFileExtractService class, createCSVFileUsingCsvMapperForGL method");
			}

		}
	}

	private boolean createCSVFileUsingCsvMapperForARAP(List<Map<String, Object>> arapList,
			Map<String, List<AccountingExtractMappingEntity>> mappingDataMap,
			AccountingExtractFileNamingEntity fileEntity, String finRunId) {
		log.info("inside AccountingFileExtractService class, createCSVFileUsingCsvMapperForARAP method");
		FileWriter fileWriter = null;
		CSVPrinter csvFilePrinter = null;
		try {
			String headerRec = accountType + FileExtractConstants.EXTRACT + FileExtractConstants.HEADERRECORD;
			String detailedRec = accountType + FileExtractConstants.EXTRACT + FileExtractConstants.DETAILEDRECORD;
			List<String> headerSequenceOrderDataList = mappingDataMap.get(headerRec).stream()
					.filter(e -> e.getAccounttype().equals(headerRec)).map(AccountingExtractMappingEntity::getKeyval)
					.collect(Collectors.toList());
			List<String> detailedSequenceOrderDataList = mappingDataMap.get(detailedRec).stream()
					.filter(e -> e.getAccounttype().equals(detailedRec)).map(AccountingExtractMappingEntity::getKeyval)
					.collect(Collectors.toList());
			List<AccountingExtractMappingEntity> hearderMap = mappingDataMap
					.get(headerRec + FileExtractConstants.HEADER) != null
							? mappingDataMap.get(headerRec + FileExtractConstants.HEADER) : Collections.emptyList();
			List<AccountingExtractMappingEntity> dHearderMap = mappingDataMap
					.get(detailedRec + FileExtractConstants.HEADER) != null
							? mappingDataMap.get(detailedRec + FileExtractConstants.HEADER) : Collections.emptyList();
			AccountingExtractMappingEntity headerEntity = null;
			Object[] headerArray = null;
			if (!hearderMap.isEmpty()) {
				headerEntity = hearderMap.get(0) != null ? hearderMap.get(0) : null;
				if (headerEntity != null) {
					headerArray = headerEntity.getDefaultvalue() != null ? headerEntity.getDefaultvalue().split(",", 0)
							: null;
				}
			}
			AccountingExtractMappingEntity dHeaderEntity = null;
			Object[] dHeaderArray = null;
			if (!dHearderMap.isEmpty()) {
				dHeaderEntity = dHearderMap.get(0) != null ? dHearderMap.get(0) : null;
				if (dHeaderEntity != null) {
					dHeaderArray = dHeaderEntity.getDefaultvalue() != null
							? dHeaderEntity.getDefaultvalue().split(",", 0) : null;
				}
			}
			CSVFormat csvFileFormat = CSVFormat.DEFAULT.withRecordSeparator("\n");
			String pathAndFileName = fileEntity.getSuccessPath() + fileEntity.getInterfaceFileName();
			fileWriter = new FileWriter(pathAndFileName);
			csvFilePrinter = new CSVPrinter(fileWriter, csvFileFormat);
			if (headerArray != null) {
				csvFilePrinter.printRecord(headerArray);
			}
			if (dHeaderArray != null) {
				csvFilePrinter.printRecord(dHeaderArray);
			}
			File directory = new File(fileEntity.getSuccessPath());
			if (!directory.exists()) {
				log.info("************New directory created************");
				directory.mkdirs();
			}
			for (Map<String, Object> map : arapList) {
				List<String> arapCsvList = new ArrayList<>();
				String recordType = map.get("recordType").toString();
				if (StringUtils.equalsIgnoreCase(recordType, FileExtractConstants.HEADER)) {
					for (String headerData : headerSequenceOrderDataList) {
						String value = map.get(headerData) != null ? map.get(headerData).toString() : "";
						if (StringUtils.equalsIgnoreCase(headerData, "financialInterfaceRunIdentifier")) {
							arapCsvList.add(finRunId);
						} else {
							arapCsvList.add(value);
						}
					}
				} else {
					for (String detailedData : detailedSequenceOrderDataList) {
						String value = map.get(detailedData) != null ? map.get(detailedData).toString() : "";
						arapCsvList.add(value);
					}
				}
				csvFilePrinter.printRecord(arapCsvList);
			}
			listOfFiles.add(pathAndFileName);
			log.info("CSV File Generated Successfully in the path =>" + pathAndFileName);
			return true;
		} catch (Exception e) {
			log.error("exception inside AccountingFileExtractService class, createCSVFileUsingCsvMapperForARAP method");
			accountingExtractResponse.setStatus(FileExtractConstants.FAILURE);
			accountingExtractResponse.setErrorMessage("Something problem while creating csv file");
			return false;
		} finally {
			try {
				if (fileWriter != null && csvFilePrinter != null) {
					fileWriter.flush();
					csvFilePrinter.flush();
					csvFilePrinter.close();
					fileWriter.close();
				}
			} catch (IOException e1) {
				log.error(
						"exception inside AccountingFileExtractService class, createCSVFileUsingCsvMapperForARAP method");
			}

		}
	}

	public String validateInputFileType(String fileType) {
		if (StringUtils.isNotBlank(supportedFormat)) {
			String[] supportedArray = supportedFormat.split(",", 0);
			if (!Arrays.asList(supportedArray).contains(fileType)) {
				return "Supported File Type's are " + supportedFormat;
			} else {
				return null;
			}
		} else {
			return "There is no configuration in the yml file";
		}
	}

	private void check(Map<String, Object> accountingSummarizationEntity) {
		final String keys = getKeys();
		String keyVal = accountingSummarizationEntity.entrySet().stream().filter(e -> e.getValue() != null)
				.filter(entry -> Arrays.asList(StringUtils.split(keys, ",")).contains(entry.getKey()))
				.collect(Collectors.toMap(Entry::getKey, Entry::getValue)).entrySet().stream()
				.map(entry -> "" + entry.getValue()).collect(Collectors.joining("|", "", ""));
		AccountingKeyEntity accountingKeyEntity = accountingKeyRepo
				.findByClientIdAndModuleIdAndKeyValAndInterfaceType(clientId, moduleId, keyVal, accountType);
	}

	private String getKeys() {
		String keys = "";
		String accountingKey = "";
		String accountingCount = "";
		if (StringUtils.equalsIgnoreCase("GLS", accountType)) {
			accountingKey = "ACCT_SUMM_KEY";
			accountingCount = "ACCOUNTING_GLSUMM_COUNT";
		} else if (StringUtils.equalsIgnoreCase("ARAPSUMM", accountType)) {
			accountingKey = "ACCOUNTING_APARSUMM_KEY";
			accountingCount = "ACCOUNTING_ARAPSUMM_COUNT";
		}
//		SystemParameter systemParameter = smartpraMasterAppClient
//				.getSystemParameterByparameterNameAndClientId(accountingKey, clientId);
//		if (systemParameter != null) {
//			keys = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
//		}
		return keys;
	}
}
