package com.sgl.smartpra.accounting.fileextract.utility;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.sgl.smartpra.accounting.model.AccountingExtractModelGL;

/**
 * 
 * @author Siva Kumar
 *
 */

@XmlRootElement  
public class AccountingExtractXMLPojo {
	
	private List<AccountingExtractModelGL> extractModel;

	@XmlElement  
	public List<AccountingExtractModelGL> getExtractModel() {
		return extractModel;
	}

	public void setExtractModel(List<AccountingExtractModelGL> extractModel) {
		this.extractModel = extractModel;
	}
}
