package com.sgl.smartpra.accounting.fileextract.spec;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.accounting.entity.AccountingSummarizationEntity;

public class AccountingExtractSummarizationSpec {
	
	public static Specification<AccountingSummarizationEntity> filterSummarization(String clientId, String moduleId, String subModule,
			String accountType, String monthClosedDate, String errorStatus){
		List<Predicate> predicates = new ArrayList<>();
		return (summEntity,cq,cb)->{
			if (StringUtils.isNotBlank(moduleId)) {
				predicates.add(cb.equal(summEntity.get("moduleId"),moduleId));
			}
			if (StringUtils.isNotBlank(clientId)) {
				predicates.add(cb.equal(summEntity.get("clientId"),clientId));
			}
			if (StringUtils.isNotBlank(subModule)) {
				predicates.add(cb.equal(summEntity.get("subModule"),subModule));
			}
			if (StringUtils.isNotBlank(accountType)) {
				predicates.add(cb.equal(summEntity.get("accountType"),accountType));
			}
			if (StringUtils.isNotBlank(monthClosedDate)) {
				predicates.add(cb.equal(summEntity.get("monthClosedDate"),monthClosedDate));
			}
			Expression<String> glInterfaceId = summEntity.get("glInterfaceId");
			predicates.add(cb.isNull(glInterfaceId));
			Expression<String> status = summEntity.get("status");
			predicates.add(cb.isNull(status));
			predicates.add(cb.equal(summEntity.get("status"),errorStatus));
			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
			
		};
	}

}
