package com.sgl.smartpra.accounting.fileextract.exception;

public class InvalidCriteriaException extends Exception {

	private static final long serialVersionUID = -836631385290138485L;

	public InvalidCriteriaException(String s) {
		super(s);
	}
}
