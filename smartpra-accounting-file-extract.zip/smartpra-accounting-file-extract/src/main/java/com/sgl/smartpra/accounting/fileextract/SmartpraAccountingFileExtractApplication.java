package com.sgl.smartpra.accounting.fileextract;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * 
 * @author Siva Kumar
 *
 */
@EnableDiscoveryClient
@EntityScan("com.sgl.smartpra.accounting")
@ComponentScan(basePackages= {"com.sgl.smartpra.accounting"})
@EnableJpaRepositories("com.sgl.smartpra.accounting")
@EnableFeignClients(basePackages= {"com.sgl.smartpra.accounting"})
@SpringBootApplication
@EnableScheduling
@EnableTransactionManagement
public class SmartpraAccountingFileExtractApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartpraAccountingFileExtractApplication.class, args);
	}

}
