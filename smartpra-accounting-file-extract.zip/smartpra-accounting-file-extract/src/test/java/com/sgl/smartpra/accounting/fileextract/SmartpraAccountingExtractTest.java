package com.sgl.smartpra.accounting.fileextract;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.netflix.ribbon.RibbonAutoConfiguration;
import org.springframework.cloud.openfeign.FeignAutoConfiguration;
import org.springframework.cloud.openfeign.ribbon.FeignRibbonClientAutoConfiguration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.sgl.smartpra.accounting.entity.AccountingExtractEntity;
import com.sgl.smartpra.accounting.entity.AccountingExtractFileNamingEntity;
import com.sgl.smartpra.accounting.entity.AccountingExtractMappingEntity;
import com.sgl.smartpra.accounting.entity.AccountingFileExtractLogsEntity;
import com.sgl.smartpra.accounting.entity.AccountingSummarizationEntity;
import com.sgl.smartpra.accounting.fileextract.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.accounting.fileextract.config.FeignConfiguration.SequenceAppFeignClient;
import com.sgl.smartpra.accounting.fileextract.controller.AccountingFileExtractController;
import com.sgl.smartpra.accounting.fileextract.service.AccountingFileExtractServices;
import com.sgl.smartpra.accounting.fileextract.utility.AccountExtractRequest;
import com.sgl.smartpra.accounting.fileextract.utility.AccountingExtractXMLPojo;
import com.sgl.smartpra.accounting.fileextract.utility.FileExtractConstants;
import com.sgl.smartpra.accounting.mapper.AccountingExtractARAPMapper;
import com.sgl.smartpra.accounting.mapper.AccountingExtractGLMapper;
import com.sgl.smartpra.accounting.model.AccountingExtractModelGL;
import com.sgl.smartpra.accounting.model.AccountingFileExtractLogsModel;
import com.sgl.smartpra.accounting.repository.AccountAuditTrialRepository;
import com.sgl.smartpra.accounting.repository.AccountingExtractFileNamingRepository;
import com.sgl.smartpra.accounting.repository.AccountingExtractMappingRepository;
import com.sgl.smartpra.accounting.repository.AccountingExtractRepository;
import com.sgl.smartpra.accounting.repository.AccountingFileExtractLogsRepository;
import com.sgl.smartpra.accounting.repository.AccountingKeyRepository;
import com.sgl.smartpra.accounting.repository.AccountingSummarizationRepository;
import com.sgl.smartpra.accounting.utils.AccountingExtractResponse;
import com.sgl.smartpra.accounting.utils.AccountingUtilities;
import com.sgl.smartpra.accounting.utils.AccountsConstants;
import com.sgl.smartpra.batch.global.model.FileLogging;

/**
 * 
 * @author Siva Kumar
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { TestContext.class, WebApplicationContext.class, AccountingFileExtractServices.class,
		ObjectMapper.class, AccountingUtilities.class, AccountingExtractGLMapper.class, AccountingExtractXMLPojo.class,
		AccountingExtractResponse.class, AccountExtractRequest.class })
@TestPropertySource(properties = { "supportedFormat=csv,xml,txt,json,tat" })
@ImportAutoConfiguration({ RibbonAutoConfiguration.class, FeignRibbonClientAutoConfiguration.class,
		FeignAutoConfiguration.class })
public class SmartpraAccountingExtractTest {

	@InjectMocks
	private AccountingFileExtractController fileExtractController;

	@Autowired
	private AccountingFileExtractServices extractService;

	@MockBean
	private AccountingExtractRepository extractRepo;
	
	@MockBean
	private AccountingFileExtractLogsRepository logsRepo;

	@MockBean
	private AccountingExtractMappingRepository mappingRepo;

	@MockBean
	private AccountingExtractFileNamingRepository fileNamingConfigRepo;
	
	@MockBean
	private AccountingKeyRepository accountingKeyRepo;

	@MockBean
	private AccountAuditTrialRepository auditTrailRepo;

	@MockBean
	private BatchGlobalFeignClient batchGlobalFeignClient;

	@MockBean
	private SequenceAppFeignClient sequenceAppFeignClient;
	//
	// @MockBean
	// private AccountingFeignClient accountingFeignClient;

	@MockBean
	private AccountingSummarizationRepository summarRepo;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private AccountingUtilities utilities;

	@MockBean
	private AccountingExtractGLMapper glMapper;

	@MockBean
	private AccountingExtractARAPMapper arapMapper;

	// @MockBean
	// private AccountingFileExtractLogsMapper logMapper;

//	@Autowired
//	private AccountingExtractXMLPojo xmlpojo;

	// @Autowired
	// private ExceptionLoggingService exceptionLoggingService;

	@Autowired
	private AccountingExtractResponse accountingExtractResponse;
	
	private List<String> listOfFiles = null;

	private String clientId, moduleId, subModule, accountType, fileType = null;

	private LocalDate localMonthClosedDate = null;

	@Before
	public void setUp() {
		objectMapper = getObjectMapper();
		ReflectionTestUtils.setField(fileExtractController, "extractService", extractService);
		ReflectionTestUtils.setField(fileExtractController, "utilities", utilities);
		ReflectionTestUtils.setField(extractService, "extractRepo", extractRepo);
		ReflectionTestUtils.setField(extractService, "mappingRepo", mappingRepo);
		ReflectionTestUtils.setField(extractService, "logsRepo", logsRepo);
		ReflectionTestUtils.setField(extractService, "fileNamingConfigRepo", fileNamingConfigRepo);
		ReflectionTestUtils.setField(extractService, "accountingKeyRepo", accountingKeyRepo);
		ReflectionTestUtils.setField(extractService, "auditTrailRepo", auditTrailRepo);
		ReflectionTestUtils.setField(extractService, "objectMapper", objectMapper);
		ReflectionTestUtils.setField(extractService, "utilities", utilities);
		// ReflectionTestUtils.setField(extractService, "accountingFeignClient",
		// accountingFeignClient);
		ReflectionTestUtils.setField(extractService, "batchGlobalFeignClient", batchGlobalFeignClient);
		ReflectionTestUtils.setField(extractService, "sequenceAppFeignClient", sequenceAppFeignClient);
		ReflectionTestUtils.setField(extractService, "glMapper", glMapper);
		ReflectionTestUtils.setField(extractService, "arapMapper", arapMapper);
		// ReflectionTestUtils.setField(extractService, "logMapper", logMapper);
		// ReflectionTestUtils.setField(extractService, "xmlpojo", xmlpojo);
		ReflectionTestUtils.setField(extractService, "accountingExtractResponse", accountingExtractResponse);
	}

	private ObjectMapper getObjectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.registerModule(new JavaTimeModule());
		return mapper;
	}

	private List<AccountingSummarizationEntity> mockDefaultSummarizationData_GL() {
		List<AccountingSummarizationEntity> summarizationModelList = new ArrayList<>();
		AccountingSummarizationEntity model1 = new AccountingSummarizationEntity();
		model1.setSummarizationId("M000000929");
		model1.setModuleId("M");
		model1.setClientId("QR");
		model1.setBaseCurrency("INR");
		model1.setTransactionCurrency("USD");
		model1.setAccountNumCode("1412");
		model1.setConversionRate(new BigDecimal(0.1234));
		model1.setMonthClosedDate(LocalDate.of(2020, Month.FEBRUARY, 3));
		model1.setDrAmountInTransCurrency(new BigDecimal(10));
		model1.setCrAmountInTransCurrency(new BigDecimal(10));
		model1.setDrAmountInBaseCurrency(new BigDecimal(10));
		model1.setDrAmountInBaseCurrency(new BigDecimal(10));
		model1.setBatchKey1("280");
		model1.setBatchKey6(LocalDate.of(2020, Month.FEBRUARY, 3));
		model1.setBatchKey5(LocalDate.of(2020, Month.FEBRUARY, 3));
		model1.setAccountingAttribute8("20-Jan");
		model1.setAccountingAttribute9("4");
		model1.setAccountingAttribute13("APT");
		model1.setAccountingAttribute20("T");
		model1.setAccountType("GL");
		model1.setSubModule("Inward");
		summarizationModelList.add(model1);
		return summarizationModelList;
	}

	private List<AccountingSummarizationEntity> mockDefaultSummarizationData_AP() {
		List<AccountingSummarizationEntity> summarizationModelList = new ArrayList<>();
		AccountingSummarizationEntity model1 = new AccountingSummarizationEntity();
		model1.setSummarizationId("M000000929");
		model1.setModuleId("M");
		model1.setClientId("QR");
		model1.setBaseCurrency("INR");
		model1.setTransactionCurrency("USD");
		model1.setAccountNumCode("1412");
		model1.setConversionRate(new BigDecimal(0.1234));
		model1.setMonthClosedDate(LocalDate.of(2020, Month.FEBRUARY, 3));
		model1.setDrAmountInTransCurrency(new BigDecimal(10));
		model1.setCrAmountInTransCurrency(new BigDecimal(10));
		model1.setDrAmountInBaseCurrency(new BigDecimal(10));
		model1.setDrAmountInBaseCurrency(new BigDecimal(10));
		model1.setBatchKey1("280");
		model1.setBatchKey6(LocalDate.of(2020, Month.FEBRUARY, 3));
		model1.setBatchKey5(LocalDate.of(2020, Month.FEBRUARY, 3));
		model1.setAccountingAttribute8("20-Jan");
		model1.setAccountingAttribute9("4");
		model1.setAccountingAttribute13("APT");
		model1.setAccountingAttribute20("H");
		model1.setAccountType("AP");
		model1.setSubModule("Inward");
		
		AccountingSummarizationEntity model2 = new AccountingSummarizationEntity();
		model2.setSummarizationId("M000000929");
		model2.setModuleId("M");
		model2.setClientId("QR");
		model2.setBaseCurrency("INR");
		model2.setTransactionCurrency("USD");
		model2.setAccountNumCode("1412");
		model2.setConversionRate(new BigDecimal(0.1234));
		model2.setMonthClosedDate(LocalDate.of(2020, Month.FEBRUARY, 3));
		model2.setDrAmountInTransCurrency(new BigDecimal(10));
		model2.setCrAmountInTransCurrency(new BigDecimal(10));
		model2.setDrAmountInBaseCurrency(new BigDecimal(10));
		model2.setDrAmountInBaseCurrency(new BigDecimal(10));
		model2.setBatchKey1("280");
		model2.setBatchKey6(LocalDate.of(2020, Month.FEBRUARY, 3));
		model2.setBatchKey5(LocalDate.of(2020, Month.FEBRUARY, 3));
		model2.setAccountingAttribute8("20-Jan");
		model2.setAccountingAttribute9("4");
		model2.setAccountingAttribute13("APT");
		model2.setAccountingAttribute20("H");
		model2.setAccountType("AP");
		model2.setSubModule("Inward");
		summarizationModelList.add(model1);
		summarizationModelList.add(model2);
		return summarizationModelList;
	}

	private List<AccountingSummarizationEntity> mockDefaultSummarizationData_AR() {
		List<AccountingSummarizationEntity> summarizationModelList = new ArrayList<>();
		AccountingSummarizationEntity model1 = new AccountingSummarizationEntity();
		model1.setModuleId("M");
		model1.setClientId("QR");
		model1.setBaseCurrency("INR");
		model1.setTransactionCurrency("USD");
		model1.setMonthClosedDate(LocalDate.of(2020, Month.FEBRUARY, 3));
		model1.setNarration("Narration");
		model1.setDrAmountInTransCurrency(new BigDecimal(10));
		model1.setCrAmountInTransCurrency(new BigDecimal(10));
		model1.setDrAmountInBaseCurrency(new BigDecimal(10));
		model1.setDrAmountInBaseCurrency(new BigDecimal(10));
		model1.setAccountNumCode("1000");
		model1.setBatchKey1("12345");
		model1.setBatchKey6(LocalDate.of(2020, Month.FEBRUARY, 3));
		model1.setAccountType("AR");

		AccountingSummarizationEntity model2 = new AccountingSummarizationEntity();
		model2.setModuleId("M");
		model2.setClientId("QR");
		model2.setBaseCurrency("INR");
		model2.setTransactionCurrency("USD");
		model2.setMonthClosedDate(LocalDate.of(2020, Month.FEBRUARY, 3));
		model2.setNarration("Narration");
		model1.setDrAmountInTransCurrency(new BigDecimal(10));
		model1.setCrAmountInTransCurrency(new BigDecimal(10));
		model1.setDrAmountInBaseCurrency(new BigDecimal(10));
		model1.setDrAmountInBaseCurrency(new BigDecimal(10));
		model2.setAccountNumCode("1000");
		model2.setBatchKey1("12345");
		model2.setBatchKey6(LocalDate.of(2020, Month.FEBRUARY, 3));
		model2.setAccountType("AP");
		summarizationModelList.add(model1);
		summarizationModelList.add(model2);
		return summarizationModelList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultHeaderAndFileNameAndDataMappingForGL() {
		List<AccountingExtractMappingEntity> mappingList = new ArrayList<>();
		List<AccountingExtractMappingEntity> fileheaderList = mockDefaultMappingTableHeaderData_GL();
		mappingList.addAll(fileheaderList);
		List<AccountingExtractMappingEntity> fileNameList = mockDefaultMappingTableFileNameData_GL();
		mappingList.addAll(fileNameList);
		List<AccountingExtractMappingEntity> mappingDataList = mockDefaultMappingTableData_GL();
		mappingList.addAll(mappingDataList);
		return mappingList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultHeaderAndFileNameAndDataMappingForAP() {
		List<AccountingExtractMappingEntity> mappingList = new ArrayList<>();
		List<AccountingExtractMappingEntity> fileheaderList = mockDefaultMappingTableHeaderData_AP();
		mappingList.addAll(fileheaderList);
		List<AccountingExtractMappingEntity> fileNameList = mockDefaultMappingTableFileNameData_AP();
		mappingList.addAll(fileNameList);
		List<AccountingExtractMappingEntity> mappingDataList = mockDefaultMappingTableData_AP();
		mappingList.addAll(mappingDataList);
		return mappingList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultHeaderAndFileNameAndDataMappingForAR() {
		List<AccountingExtractMappingEntity> mappingList = new ArrayList<>();
		List<AccountingExtractMappingEntity> fileheaderList = mockDefaultMappingTableHeaderData_AR();
		mappingList.addAll(fileheaderList);
		List<AccountingExtractMappingEntity> fileNameList = mockDefaultMappingTableFileNameData_AR();
		mappingList.addAll(fileNameList);
		List<AccountingExtractMappingEntity> mappingDataList = mockDefaultMappingTableData_AR();
		mappingList.addAll(mappingDataList);
		return mappingList;
	}

	private List<AccountingExtractFileNamingEntity> mockDefaultFileNamingData_GL() {
		List<AccountingExtractFileNamingEntity> fileNamingList = new ArrayList<>();
		AccountingExtractFileNamingEntity model1 = new AccountingExtractFileNamingEntity();
		model1.setModuleId("M");
		model1.setClientId("QR");
		model1.setFileType("csv");
		model1.setAccountType("GLEXTRACT");
		model1.setInterfaceFileName("^[A-Z]{2}_[0-9]{10}_[A-Z]{2}");
		model1.setSuccessPath("/opt/smartpra/accounts/success/");
		model1.setErrorPath("/opt/smartpra/accounts/error/");
		fileNamingList.add(model1);
		return fileNamingList;
	}

	private List<AccountingExtractFileNamingEntity> mockDefaultFileNamingData_AP() {
		List<AccountingExtractFileNamingEntity> fileNamingList = new ArrayList<>();
		AccountingExtractFileNamingEntity model1 = new AccountingExtractFileNamingEntity();
		model1.setModuleId("M");
		model1.setClientId("QR");
		model1.setFileType("AP");

		AccountingExtractFileNamingEntity model2 = new AccountingExtractFileNamingEntity();
		model2.setModuleId("M");
		model2.setClientId("QR");
		model2.setFileType("AP");
		fileNamingList.add(model1);
		fileNamingList.add(model2);
		return fileNamingList;
	}

	private List<AccountingExtractFileNamingEntity> mockDefaultFileNamingData_AR() {
		List<AccountingExtractFileNamingEntity> fileNamingList = new ArrayList<>();
		AccountingExtractFileNamingEntity model1 = new AccountingExtractFileNamingEntity();
		model1.setModuleId("M");
		model1.setClientId("QR");
		model1.setFileType("AR");

		AccountingExtractFileNamingEntity model2 = new AccountingExtractFileNamingEntity();
		model2.setModuleId("M");
		model2.setClientId("QR");
		model2.setFileType("AR");
		fileNamingList.add(model1);
		fileNamingList.add(model2);
		return fileNamingList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultMappingTableData_GL() {
		List<AccountingExtractMappingEntity> mappingList = new ArrayList<>();
		AccountingExtractMappingEntity mapping1 = new AccountingExtractMappingEntity();
		mapping1.setClientId("QR");
		mapping1.setModuleId("M");
		mapping1.setSequencenumber(1);
		mapping1.setKeyval("businessUnit");
		mapping1.setDefaultvalue("01");
		mapping1.setAccounttype("GLEXTRACT");
		mappingList.add(mapping1);
		AccountingExtractMappingEntity mapping2 = new AccountingExtractMappingEntity();
		mapping2.setClientId("QR");
		mapping2.setModuleId("M");
		mapping2.setSequencenumber(2);
		mapping2.setKeyval("currencyCode");
		mapping2.setValue("baseCurrency");
		mapping2.setAccounttype("GLEXTRACT");
		mappingList.add(mapping2);
		AccountingExtractMappingEntity mapping3 = new AccountingExtractMappingEntity();
		mapping3.setClientId("QR");
		mapping3.setModuleId("M");
		mapping3.setSequencenumber(3);
		mapping3.setKeyval("costReallocationBusinessUnit");
		mapping3.setDefaultvalue("00");
		mapping3.setAccounttype("GLEXTRACT");
		mappingList.add(mapping3);
		AccountingExtractMappingEntity mapping4 = new AccountingExtractMappingEntity();
		mapping4.setClientId("QR");
		mapping4.setModuleId("M");
		mapping4.setSequencenumber(4);
		mapping4.setKeyval("effectiveDate");
		mapping4.setValue("monthClosedDate");
		mapping4.setDatatype("construct");
		mapping4.setAccounttype("GLEXTRACT");
		mappingList.add(mapping4);
		AccountingExtractMappingEntity mapping5 = new AccountingExtractMappingEntity();
		mapping5.setClientId("QR");
		mapping5.setModuleId("M");
		mapping5.setSequencenumber(5);
		mapping5.setKeyval("journalLineDescription");
		mapping5.setValue(
				"Billing from,batchKey1,for,Charge category,accountingAttribute13,billing period,accountingAttribute8,/,0,accountingAttribute9");
		mapping5.setDatatype("construct");
		mapping5.setAccounttype("GLEXTRACT");
		mapping5.setDefaultvalue("subModule");
		mappingList.add(mapping5);
		AccountingExtractMappingEntity mapping6 = new AccountingExtractMappingEntity();
		mapping6.setClientId("QR");
		mapping6.setModuleId("M");
		mapping6.setSequencenumber(6);
		mapping6.setKeyval("reversalDate");
		mapping6.setAccounttype("GLEXTRACT");
		mappingList.add(mapping6);
		AccountingExtractMappingEntity mapping7 = new AccountingExtractMappingEntity();
		mapping7.setClientId("QR");
		mapping7.setModuleId("M");
		mapping7.setSequencenumber(7);
		mapping7.setKeyval("exchangeRate");
		mapping7.setValue("conversionRate");
		mapping7.setAccounttype("GLEXTRACT");
		mappingList.add(mapping7);
		AccountingExtractMappingEntity mapping8 = new AccountingExtractMappingEntity();
		mapping8.setClientId("QR");
		mapping8.setModuleId("M");
		mapping8.setSequencenumber(8);
		mapping8.setKeyval("statisticalAmount");
		mapping8.setAccounttype("GLEXTRACT");
		mappingList.add(mapping8);
		AccountingExtractMappingEntity mapping9 = new AccountingExtractMappingEntity();
		mapping9.setClientId("QR");
		mapping9.setModuleId("M");
		mapping9.setSequencenumber(9);
		mapping9.setKeyval("drAmtInBaseCurrency");
		mapping9.setValue("debitAmountInBaseCurrency");
		mapping9.setAccounttype("GLEXTRACT");
		mappingList.add(mapping9);
		AccountingExtractMappingEntity mapping10 = new AccountingExtractMappingEntity();
		mapping10.setClientId("QR");
		mapping10.setModuleId("M");
		mapping10.setSequencenumber(10);
		mapping10.setKeyval("crAmtInBaseCurrency");
		mapping10.setValue("creditAmountInBaseCurrency");
		mapping10.setAccounttype("GLEXTRACT");
		mappingList.add(mapping10);
		AccountingExtractMappingEntity mapping11 = new AccountingExtractMappingEntity();
		mapping11.setClientId("QR");
		mapping11.setModuleId("M");
		mapping11.setSequencenumber(11);
		mapping11.setKeyval("glAccount");
		mapping11.setValue("accountNumcode");
		mapping11.setAccounttype("GLEXTRACT");
		mappingList.add(mapping11);
		AccountingExtractMappingEntity mapping12 = new AccountingExtractMappingEntity();
		mapping12.setClientId("QR");
		mapping12.setModuleId("M");
		mapping12.setSequencenumber(12);
		mapping12.setKeyval("exchangePeriod");
		mapping12.setDefaultvalue("IATA");
		mapping12.setAccounttype("GLEXTRACT");
		mappingList.add(mapping12);
		AccountingExtractMappingEntity mapping13 = new AccountingExtractMappingEntity();
		mapping13.setClientId("QR");
		mapping13.setModuleId("M");
		mapping13.setSequencenumber(13);
		mapping13.setKeyval("sourceCode");
		mapping13.setDefaultvalue("ALTRA_MISC");
		mapping13.setAccounttype("GLEXTRACT");
		mappingList.add(mapping13);
		AccountingExtractMappingEntity mapping14 = new AccountingExtractMappingEntity();
		mapping14.setClientId("QR");
		mapping14.setModuleId("M");
		mapping14.setSequencenumber(14);
		mapping14.setKeyval("destinationCurrency");
		mapping14.setValue("baseCurrency");
		mapping14.setAccounttype("GLEXTRACT");
		mappingList.add(mapping14);
		AccountingExtractMappingEntity mapping15 = new AccountingExtractMappingEntity();
		mapping15.setClientId("QR");
		mapping15.setModuleId("M");
		mapping15.setSequencenumber(15);
		mapping15.setKeyval("reconciliationCode");
		mapping15.setValue("accountingAttribute8,/,0,accountingAttribute9,batchKey1");
		mapping15.setDatatype("construct");
		mapping15.setAccounttype("GLEXTRACT");
		mappingList.add(mapping15);
		AccountingExtractMappingEntity mapping16 = new AccountingExtractMappingEntity();
		mapping16.setClientId("QR");
		mapping16.setModuleId("M");
		mapping16.setSequencenumber(16);
		mapping16.setKeyval("jobNumber");
		mapping16.setAccounttype("GLEXTRACT");
		mappingList.add(mapping16);
		AccountingExtractMappingEntity mapping17 = new AccountingExtractMappingEntity();
		mapping17.setClientId("QR");
		mapping17.setModuleId("M");
		mapping17.setSequencenumber(17);
		mapping17.setKeyval("claimNumber");
		mapping17.setAccounttype("GLEXTRACT");
		mappingList.add(mapping17);
		AccountingExtractMappingEntity mapping18 = new AccountingExtractMappingEntity();
		mapping18.setClientId("QR");
		mapping18.setModuleId("M");
		mapping18.setSequencenumber(18);
		mapping18.setKeyval("flightParticulars");
		mapping18.setAccounttype("GLEXTRACT");
		mappingList.add(mapping18);
		AccountingExtractMappingEntity mapping19 = new AccountingExtractMappingEntity();
		mapping19.setClientId("QR");
		mapping19.setModuleId("M");
		mapping19.setSequencenumber(19);
		mapping19.setKeyval("dateOfExpense");
		mapping19.setAccounttype("GLEXTRACT");
		mappingList.add(mapping19);
		AccountingExtractMappingEntity mapping20 = new AccountingExtractMappingEntity();
		mapping20.setClientId("QR");
		mapping20.setModuleId("M");
		mapping20.setSequencenumber(20);
		mapping20.setKeyval("financialInterfaceRunIdentifier");
		mapping20.setAccounttype("GLEXTRACT");
		mappingList.add(mapping20);
		AccountingExtractMappingEntity mapping21 = new AccountingExtractMappingEntity();
		mapping21.setClientId("QR");
		mapping21.setModuleId("M");
		mapping21.setSequencenumber(21);
		mapping21.setKeyval("financialDocumentDayBookType");
		mapping21.setValue("MG");
		mapping21.setDatatype("construct");
		mapping21.setDefaultvalue("subModule");
		mapping21.setAccounttype("GLEXTRACT");
		mappingList.add(mapping21);
		AccountingExtractMappingEntity mapping22 = new AccountingExtractMappingEntity();
		mapping22.setClientId("QR");
		mapping22.setModuleId("M");
		mapping22.setSequencenumber(22);
		mapping22.setKeyval("jvNumber");
		mapping22.setAccounttype("GLEXTRACT");
		mappingList.add(mapping22);
		AccountingExtractMappingEntity mapping23 = new AccountingExtractMappingEntity();
		mapping23.setClientId("QR");
		mapping23.setModuleId("M");
		mapping23.setSequencenumber(23);
		mapping23.setKeyval("reserveForFutureUse_1");
		mapping23.setAccounttype("GLEXTRACT");
		mappingList.add(mapping23);
		AccountingExtractMappingEntity mapping24 = new AccountingExtractMappingEntity();
		mapping24.setClientId("QR");
		mapping24.setModuleId("M");
		mapping24.setSequencenumber(24);
		mapping24.setKeyval("orderNumber");
		mapping24.setAccounttype("GLEXTRACT");
		mappingList.add(mapping24);
		AccountingExtractMappingEntity mapping25 = new AccountingExtractMappingEntity();
		mapping25.setClientId("QR");
		mapping25.setModuleId("M");
		mapping25.setSequencenumber(25);
		mapping25.setKeyval("saleReportingPeriodEndDate");
		mapping25.setAccounttype("GLEXTRACT");
		mappingList.add(mapping25);
		AccountingExtractMappingEntity mapping26 = new AccountingExtractMappingEntity();
		mapping26.setClientId("QR");
		mapping26.setModuleId("M");
		mapping26.setSequencenumber(26);
		mapping26.setKeyval("agentCode");
		mapping26.setValue("batchKey1");
		mapping26.setAccounttype("GLEXTRACT");
		mappingList.add(mapping26);
		AccountingExtractMappingEntity mapping27 = new AccountingExtractMappingEntity();
		mapping27.setClientId("QR");
		mapping27.setModuleId("M");
		mapping27.setSequencenumber(27);
		mapping27.setKeyval("sourceReference");
		mapping27.setValue("MG");
		mapping27.setDefaultvalue("subModule");
		mapping27.setDatatype("construct");
		mapping27.setAccounttype("GLEXTRACT");
		mappingList.add(mapping27);
		AccountingExtractMappingEntity mapping28 = new AccountingExtractMappingEntity();
		mapping28.setClientId("QR");
		mapping28.setModuleId("M");
		mapping28.setSequencenumber(28);
		mapping28.setKeyval("reserveForFutureUse_2");
		mapping28.setAccounttype("GLEXTRACT");
		mappingList.add(mapping28);
		AccountingExtractMappingEntity mapping29 = new AccountingExtractMappingEntity();
		mapping29.setClientId("QR");
		mapping29.setModuleId("M");
		mapping29.setSequencenumber(29);
		mapping29.setKeyval("reserveForFutureUse_3");
		mapping29.setAccounttype("GLEXTRACT");
		mappingList.add(mapping29);
		AccountingExtractMappingEntity mapping30 = new AccountingExtractMappingEntity();
		mapping30.setClientId("QR");
		mapping30.setModuleId("M");
		mapping30.setSequencenumber(30);
		mapping30.setKeyval("pointOfSale");
		mapping30.setAccounttype("GLEXTRACT");
		mappingList.add(mapping30);
		AccountingExtractMappingEntity mapping31 = new AccountingExtractMappingEntity();
		mapping31.setClientId("QR");
		mapping31.setModuleId("M");
		mapping31.setSequencenumber(31);
		mapping31.setKeyval("costCentreCode");
		mapping31.setAccounttype("GLEXTRACT");
		mappingList.add(mapping31);
		return mappingList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultMappingTableData_AP() {
		List<AccountingExtractMappingEntity> mappingList = new ArrayList<>();
		AccountingExtractMappingEntity mapping1 = new AccountingExtractMappingEntity();
		mapping1.setClientId("QR");
		mapping1.setModuleId("M");
		mapping1.setSequencenumber(1);
		mapping1.setKeyval("businessUnit");
		mapping1.setDefaultvalue("01");
		mapping1.setAccounttype("AP");
		mappingList.add(mapping1);
		AccountingExtractMappingEntity mapping2 = new AccountingExtractMappingEntity();
		mapping2.setClientId("QR");
		mapping2.setModuleId("M");
		mapping2.setSequencenumber(2);
		mapping2.setKeyval("currencyCode");
		mapping2.setValue("baseCurrency");
		mapping2.setAccounttype("AP");
		mappingList.add(mapping2);
		AccountingExtractMappingEntity mapping3 = new AccountingExtractMappingEntity();
		mapping3.setClientId("QR");
		mapping3.setModuleId("M");
		mapping3.setSequencenumber(3);
		mapping3.setKeyval("costReallocationBusinessUnit");
		mapping3.setDefaultvalue("00");
		mapping3.setAccounttype("AP");
		mappingList.add(mapping3);
		AccountingExtractMappingEntity mapping4 = new AccountingExtractMappingEntity();
		mapping4.setClientId("QR");
		mapping4.setModuleId("M");
		mapping4.setSequencenumber(4);
		mapping4.setKeyval("effectiveDate");
		mapping4.setValue("monthClosedDate");
		mapping4.setDatatype("LocalDate");
		mapping4.setFormat("yyyy-MM-dd");
		mapping4.setFromdatatype("localdate");
		mapping4.setFromformat("dd-MMM-yyyy");
		mapping4.setAccounttype("AP");
		mappingList.add(mapping4);
		AccountingExtractMappingEntity mapping5 = new AccountingExtractMappingEntity();
		mapping5.setClientId("QR");
		mapping5.setModuleId("M");
		mapping5.setSequencenumber(5);
		mapping5.setKeyval("journalLineDescription");
		mapping5.setValue("Sales GL for,batchKey6,for,batchKey1");
		mapping5.setDatatype("construct");
		mapping5.setAccounttype("AP");
		mappingList.add(mapping5);
		AccountingExtractMappingEntity mapping6 = new AccountingExtractMappingEntity();
		mapping6.setClientId("QR");
		mapping6.setModuleId("M");
		mapping6.setSequencenumber(6);
		mapping6.setKeyval("reversalDate");
		mapping6.setAccounttype("AP");
		mappingList.add(mapping6);
		AccountingExtractMappingEntity mapping7 = new AccountingExtractMappingEntity();
		mapping7.setClientId("QR");
		mapping7.setModuleId("M");
		mapping7.setSequencenumber(7);
		mapping7.setKeyval("exchangeRate");
		mapping7.setDefaultvalue("1");
		mapping7.setAccounttype("AP");
		mappingList.add(mapping7);
		AccountingExtractMappingEntity mapping8 = new AccountingExtractMappingEntity();
		mapping8.setClientId("QR");
		mapping8.setModuleId("M");
		mapping8.setSequencenumber(8);
		mapping8.setKeyval("statisticalAmount");
		mapping8.setAccounttype("AP");
		mappingList.add(mapping8);
		AccountingExtractMappingEntity mapping9 = new AccountingExtractMappingEntity();
		mapping9.setClientId("QR");
		mapping9.setModuleId("M");
		mapping9.setSequencenumber(9);
		mapping9.setKeyval("enteredDebit");
		mapping9.setValue("debitAmountInBaseCurrency");
		mapping9.setAccounttype("AP");
		mappingList.add(mapping9);
		AccountingExtractMappingEntity mapping10 = new AccountingExtractMappingEntity();
		mapping10.setClientId("QR");
		mapping10.setModuleId("M");
		mapping10.setSequencenumber(10);
		mapping10.setKeyval("enteredCredit");
		mapping10.setValue("creditAmountInBaseCurrency");
		mapping10.setAccounttype("AP");
		mappingList.add(mapping10);
		AccountingExtractMappingEntity mapping11 = new AccountingExtractMappingEntity();
		mapping11.setClientId("QR");
		mapping11.setModuleId("M");
		mapping11.setSequencenumber(11);
		mapping11.setKeyval("glAccount");
		mapping11.setValue("accountNumcode");
		mapping11.setAccounttype("AP");
		mappingList.add(mapping11);
		AccountingExtractMappingEntity mapping12 = new AccountingExtractMappingEntity();
		mapping12.setClientId("QR");
		mapping12.setModuleId("M");
		mapping12.setSequencenumber(12);
		mapping12.setKeyval("exchangePeriod");
		mapping12.setDefaultvalue("IATA");
		mapping12.setAccounttype("AP");
		mappingList.add(mapping12);
		AccountingExtractMappingEntity mapping13 = new AccountingExtractMappingEntity();
		mapping13.setClientId("QR");
		mapping13.setModuleId("M");
		mapping13.setSequencenumber(13);
		mapping13.setKeyval("sourceCode");
		mapping13.setDefaultvalue("ALTRA_PRA_SALE");
		mapping13.setAccounttype("AP");
		mappingList.add(mapping13);
		AccountingExtractMappingEntity mapping14 = new AccountingExtractMappingEntity();
		mapping14.setClientId("QR");
		mapping14.setModuleId("M");
		mapping14.setSequencenumber(14);
		mapping14.setKeyval("destinationCurrency");
		mapping14.setValue("baseCurrency");
		mapping14.setAccounttype("AP");
		mappingList.add(mapping14);
		AccountingExtractMappingEntity mapping15 = new AccountingExtractMappingEntity();
		mapping15.setClientId("QR");
		mapping15.setModuleId("M");
		mapping15.setSequencenumber(15);
		mapping15.setKeyval("reconciliationCode");
		mapping15.setAccounttype("AP");
		mappingList.add(mapping15);
		AccountingExtractMappingEntity mapping16 = new AccountingExtractMappingEntity();
		mapping16.setClientId("QR");
		mapping16.setModuleId("M");
		mapping16.setSequencenumber(16);
		mapping16.setKeyval("jobNumber");
		mapping16.setAccounttype("AP");
		mappingList.add(mapping16);
		AccountingExtractMappingEntity mapping17 = new AccountingExtractMappingEntity();
		mapping17.setClientId("QR");
		mapping17.setModuleId("M");
		mapping17.setSequencenumber(17);
		mapping17.setKeyval("claimNumber");
		mapping17.setAccounttype("AP");
		mappingList.add(mapping17);
		AccountingExtractMappingEntity mapping18 = new AccountingExtractMappingEntity();
		mapping18.setClientId("QR");
		mapping18.setModuleId("M");
		mapping18.setSequencenumber(18);
		mapping18.setKeyval("flightParticulars");
		mapping18.setAccounttype("AP");
		mappingList.add(mapping18);
		AccountingExtractMappingEntity mapping19 = new AccountingExtractMappingEntity();
		mapping19.setClientId("QR");
		mapping19.setModuleId("M");
		mapping19.setSequencenumber(19);
		mapping19.setKeyval("dateOfExpense");
		mapping19.setAccounttype("AP");
		mappingList.add(mapping19);
		AccountingExtractMappingEntity mapping20 = new AccountingExtractMappingEntity();
		mapping20.setClientId("QR");
		mapping20.setModuleId("M");
		mapping20.setSequencenumber(20);
		mapping20.setKeyval("financialInterfaceRunIdentifier");
		mapping20.setValue("glInterfaceID");
		mapping20.setAccounttype("AP");
		mappingList.add(mapping20);
		AccountingExtractMappingEntity mapping21 = new AccountingExtractMappingEntity();
		mapping21.setClientId("QR");
		mapping21.setModuleId("M");
		mapping21.setSequencenumber(21);
		mapping21.setKeyval("financialDocumentDayBookType");
		mapping21.setDefaultvalue("PSJ");
		mapping21.setAccounttype("AP");
		mappingList.add(mapping21);
		AccountingExtractMappingEntity mapping22 = new AccountingExtractMappingEntity();
		mapping22.setClientId("QR");
		mapping22.setModuleId("M");
		mapping22.setSequencenumber(22);
		mapping22.setKeyval("jvNumber");
		mapping22.setValue("batchKey6,/,batchKey1");
		mapping22.setDatatype("construct");
		mapping22.setAccounttype("AP");
		mappingList.add(mapping22);
		AccountingExtractMappingEntity mapping23 = new AccountingExtractMappingEntity();
		mapping23.setClientId("QR");
		mapping23.setModuleId("M");
		mapping23.setSequencenumber(23);
		mapping23.setKeyval("reserveForFutureUse_1");
		mapping23.setAccounttype("AP");
		mappingList.add(mapping23);
		AccountingExtractMappingEntity mapping24 = new AccountingExtractMappingEntity();
		mapping24.setClientId("QR");
		mapping24.setModuleId("M");
		mapping24.setSequencenumber(24);
		mapping24.setKeyval("orderNumber");
		mapping24.setAccounttype("AP");
		mappingList.add(mapping24);
		AccountingExtractMappingEntity mapping25 = new AccountingExtractMappingEntity();
		mapping25.setClientId("QR");
		mapping25.setModuleId("M");
		mapping25.setSequencenumber(25);
		mapping25.setKeyval("saleReportingPeriodEndDate");
		mapping25.setValue("batchKey6");
		mapping25.setDatatype("LocalDate");
		mapping25.setFormat("yyyy-MM-dd");
		mapping25.setFromdatatype("localdate");
		mapping25.setFromformat("dd-MMM-yyyy");
		mapping25.setAccounttype("AP");
		mappingList.add(mapping25);
		AccountingExtractMappingEntity mapping26 = new AccountingExtractMappingEntity();
		mapping26.setClientId("QR");
		mapping26.setModuleId("M");
		mapping26.setSequencenumber(26);
		mapping26.setKeyval("agentCode");
		mapping26.setValue("batchKey1");
		mapping26.setAccounttype("AP");
		mappingList.add(mapping26);
		AccountingExtractMappingEntity mapping27 = new AccountingExtractMappingEntity();
		mapping27.setClientId("QR");
		mapping27.setModuleId("M");
		mapping27.setSequencenumber(27);
		mapping27.setKeyval("sourceReference");
		mapping27.setDefaultvalue("PSJ");
		mapping27.setAccounttype("AP");
		mappingList.add(mapping27);
		AccountingExtractMappingEntity mapping28 = new AccountingExtractMappingEntity();
		mapping28.setClientId("QR");
		mapping28.setModuleId("M");
		mapping28.setSequencenumber(28);
		mapping28.setKeyval("reserveForFutureUse_2");
		mapping28.setAccounttype("AP");
		mappingList.add(mapping28);
		AccountingExtractMappingEntity mapping29 = new AccountingExtractMappingEntity();
		mapping29.setClientId("QR");
		mapping29.setModuleId("M");
		mapping29.setSequencenumber(29);
		mapping29.setKeyval("reserveForFutureUse_3");
		mapping29.setAccounttype("AP");
		mappingList.add(mapping29);
		AccountingExtractMappingEntity mapping30 = new AccountingExtractMappingEntity();
		mapping30.setClientId("QR");
		mapping30.setModuleId("M");
		mapping30.setSequencenumber(30);
		mapping30.setKeyval("pointOfSale");
		mapping30.setAccounttype("AP");
		mappingList.add(mapping30);
		AccountingExtractMappingEntity mapping31 = new AccountingExtractMappingEntity();
		mapping31.setClientId("QR");
		mapping31.setModuleId("M");
		mapping31.setSequencenumber(31);
		mapping31.setKeyval("costCentreCode");
		mapping31.setAccounttype("AP");
		mappingList.add(mapping31);
		return mappingList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultMappingTableData_AR() {
		List<AccountingExtractMappingEntity> mappingList = new ArrayList<>();
		AccountingExtractMappingEntity mapping1 = new AccountingExtractMappingEntity();
		mapping1.setClientId("QR");
		mapping1.setModuleId("M");
		mapping1.setSequencenumber(1);
		mapping1.setKeyval("businessUnit");
		mapping1.setDefaultvalue("01");
		mapping1.setAccounttype("AR");
		mappingList.add(mapping1);
		AccountingExtractMappingEntity mapping2 = new AccountingExtractMappingEntity();
		mapping2.setClientId("QR");
		mapping2.setModuleId("M");
		mapping2.setSequencenumber(2);
		mapping2.setKeyval("currencyCode");
		mapping2.setValue("baseCurrency");
		mapping2.setAccounttype("AR");
		mappingList.add(mapping2);
		AccountingExtractMappingEntity mapping3 = new AccountingExtractMappingEntity();
		mapping3.setClientId("QR");
		mapping3.setModuleId("M");
		mapping3.setSequencenumber(3);
		mapping3.setKeyval("costReallocationBusinessUnit");
		mapping3.setDefaultvalue("00");
		mapping3.setAccounttype("AR");
		mappingList.add(mapping3);
		AccountingExtractMappingEntity mapping4 = new AccountingExtractMappingEntity();
		mapping4.setClientId("QR");
		mapping4.setModuleId("M");
		mapping4.setSequencenumber(4);
		mapping4.setKeyval("effectiveDate");
		mapping4.setValue("monthClosedDate");
		mapping4.setDatatype("LocalDate");
		mapping4.setFormat("yyyy-MM-dd");
		mapping4.setFromdatatype("localdate");
		mapping4.setFromformat("dd-MMM-yyyy");
		mapping4.setAccounttype("AR");
		mappingList.add(mapping4);
		AccountingExtractMappingEntity mapping5 = new AccountingExtractMappingEntity();
		mapping5.setClientId("QR");
		mapping5.setModuleId("M");
		mapping5.setSequencenumber(5);
		mapping5.setKeyval("journalLineDescription");
		mapping5.setValue("Sales GL for,batchKey6,for,batchKey1");
		mapping5.setDatatype("construct");
		mapping5.setAccounttype("AR");
		mappingList.add(mapping5);
		AccountingExtractMappingEntity mapping6 = new AccountingExtractMappingEntity();
		mapping6.setClientId("QR");
		mapping6.setModuleId("M");
		mapping6.setSequencenumber(6);
		mapping6.setKeyval("reversalDate");
		mapping6.setAccounttype("AR");
		mappingList.add(mapping6);
		AccountingExtractMappingEntity mapping7 = new AccountingExtractMappingEntity();
		mapping7.setClientId("QR");
		mapping7.setModuleId("M");
		mapping7.setSequencenumber(7);
		mapping7.setKeyval("exchangeRate");
		mapping7.setDefaultvalue("1");
		mapping7.setAccounttype("AR");
		mappingList.add(mapping7);
		AccountingExtractMappingEntity mapping8 = new AccountingExtractMappingEntity();
		mapping8.setClientId("QR");
		mapping8.setModuleId("M");
		mapping8.setSequencenumber(8);
		mapping8.setKeyval("statisticalAmount");
		mapping8.setAccounttype("AR");
		mappingList.add(mapping8);
		AccountingExtractMappingEntity mapping9 = new AccountingExtractMappingEntity();
		mapping9.setClientId("QR");
		mapping9.setModuleId("M");
		mapping9.setSequencenumber(9);
		mapping9.setKeyval("enteredDebit");
		mapping9.setValue("debitAmountInBaseCurrency");
		mapping9.setAccounttype("AR");
		mappingList.add(mapping9);
		AccountingExtractMappingEntity mapping10 = new AccountingExtractMappingEntity();
		mapping10.setClientId("QR");
		mapping10.setModuleId("M");
		mapping10.setSequencenumber(10);
		mapping10.setKeyval("enteredCredit");
		mapping10.setValue("creditAmountInBaseCurrency");
		mapping10.setAccounttype("AR");
		mappingList.add(mapping10);
		AccountingExtractMappingEntity mapping11 = new AccountingExtractMappingEntity();
		mapping11.setClientId("QR");
		mapping11.setModuleId("M");
		mapping11.setSequencenumber(11);
		mapping11.setKeyval("glAccount");
		mapping11.setValue("accountNumcode");
		mapping11.setAccounttype("AR");
		mappingList.add(mapping11);
		AccountingExtractMappingEntity mapping12 = new AccountingExtractMappingEntity();
		mapping12.setClientId("QR");
		mapping12.setModuleId("M");
		mapping12.setSequencenumber(12);
		mapping12.setKeyval("exchangePeriod");
		mapping12.setDefaultvalue("IATA");
		mapping12.setAccounttype("AR");
		mappingList.add(mapping12);
		AccountingExtractMappingEntity mapping13 = new AccountingExtractMappingEntity();
		mapping13.setClientId("QR");
		mapping13.setModuleId("M");
		mapping13.setSequencenumber(13);
		mapping13.setKeyval("sourceCode");
		mapping13.setDefaultvalue("ALTRA_PRA_SALE");
		mapping13.setAccounttype("AR");
		mappingList.add(mapping13);
		AccountingExtractMappingEntity mapping14 = new AccountingExtractMappingEntity();
		mapping14.setClientId("QR");
		mapping14.setModuleId("M");
		mapping14.setSequencenumber(14);
		mapping14.setKeyval("destinationCurrency");
		mapping14.setValue("baseCurrency");
		mapping14.setAccounttype("AR");
		mappingList.add(mapping14);
		AccountingExtractMappingEntity mapping15 = new AccountingExtractMappingEntity();
		mapping15.setClientId("QR");
		mapping15.setModuleId("M");
		mapping15.setSequencenumber(15);
		mapping15.setKeyval("reconciliationCode");
		mapping15.setAccounttype("AR");
		mappingList.add(mapping15);
		AccountingExtractMappingEntity mapping16 = new AccountingExtractMappingEntity();
		mapping16.setClientId("QR");
		mapping16.setModuleId("M");
		mapping16.setSequencenumber(16);
		mapping16.setKeyval("jobNumber");
		mapping16.setAccounttype("AR");
		mappingList.add(mapping16);
		AccountingExtractMappingEntity mapping17 = new AccountingExtractMappingEntity();
		mapping17.setClientId("QR");
		mapping17.setModuleId("M");
		mapping17.setSequencenumber(17);
		mapping17.setKeyval("claimNumber");
		mapping17.setAccounttype("GLEXTRACT");
		mappingList.add(mapping17);
		AccountingExtractMappingEntity mapping18 = new AccountingExtractMappingEntity();
		mapping18.setClientId("QR");
		mapping18.setModuleId("M");
		mapping18.setSequencenumber(18);
		mapping18.setKeyval("flightParticulars");
		mapping18.setAccounttype("AR");
		mappingList.add(mapping18);
		AccountingExtractMappingEntity mapping19 = new AccountingExtractMappingEntity();
		mapping19.setClientId("QR");
		mapping19.setModuleId("M");
		mapping19.setSequencenumber(19);
		mapping19.setKeyval("dateOfExpense");
		mapping19.setAccounttype("AR");
		mappingList.add(mapping19);
		AccountingExtractMappingEntity mapping20 = new AccountingExtractMappingEntity();
		mapping20.setClientId("QR");
		mapping20.setModuleId("M");
		mapping20.setSequencenumber(20);
		mapping20.setKeyval("financialInterfaceRunIdentifier");
		mapping20.setValue("glInterfaceID");
		mapping20.setAccounttype("AR");
		mappingList.add(mapping20);
		AccountingExtractMappingEntity mapping21 = new AccountingExtractMappingEntity();
		mapping21.setClientId("QR");
		mapping21.setModuleId("M");
		mapping21.setSequencenumber(21);
		mapping21.setKeyval("financialDocumentDayBookType");
		mapping21.setDefaultvalue("PSJ");
		mapping21.setAccounttype("AR");
		mappingList.add(mapping21);
		AccountingExtractMappingEntity mapping22 = new AccountingExtractMappingEntity();
		mapping22.setClientId("QR");
		mapping22.setModuleId("M");
		mapping22.setSequencenumber(22);
		mapping22.setKeyval("jvNumber");
		mapping22.setValue("batchKey6,/,batchKey1");
		mapping22.setDatatype("construct");
		mapping22.setAccounttype("AR");
		mappingList.add(mapping22);
		AccountingExtractMappingEntity mapping23 = new AccountingExtractMappingEntity();
		mapping23.setClientId("QR");
		mapping23.setModuleId("M");
		mapping23.setSequencenumber(23);
		mapping23.setKeyval("reserveForFutureUse_1");
		mapping23.setAccounttype("AR");
		mappingList.add(mapping23);
		AccountingExtractMappingEntity mapping24 = new AccountingExtractMappingEntity();
		mapping24.setClientId("QR");
		mapping24.setModuleId("M");
		mapping24.setSequencenumber(24);
		mapping24.setKeyval("orderNumber");
		mapping24.setAccounttype("AR");
		mappingList.add(mapping24);
		AccountingExtractMappingEntity mapping25 = new AccountingExtractMappingEntity();
		mapping25.setClientId("QR");
		mapping25.setModuleId("M");
		mapping25.setSequencenumber(25);
		mapping25.setKeyval("saleReportingPeriodEndDate");
		mapping25.setValue("batchKey6");
		mapping25.setDatatype("LocalDate");
		mapping25.setFormat("yyyy-MM-dd");
		mapping25.setFromdatatype("localdate");
		mapping25.setFromformat("dd-MMM-yyyy");
		mapping25.setAccounttype("AR");
		mappingList.add(mapping25);
		AccountingExtractMappingEntity mapping26 = new AccountingExtractMappingEntity();
		mapping26.setClientId("QR");
		mapping26.setModuleId("M");
		mapping26.setSequencenumber(26);
		mapping26.setKeyval("agentCode");
		mapping26.setValue("batchKey1");
		mapping26.setAccounttype("AR");
		mappingList.add(mapping26);
		AccountingExtractMappingEntity mapping27 = new AccountingExtractMappingEntity();
		mapping27.setClientId("QR");
		mapping27.setModuleId("M");
		mapping27.setSequencenumber(27);
		mapping27.setKeyval("sourceReference");
		mapping27.setDefaultvalue("PSJ");
		mapping27.setAccounttype("AR");
		mappingList.add(mapping27);
		AccountingExtractMappingEntity mapping28 = new AccountingExtractMappingEntity();
		mapping28.setClientId("QR");
		mapping28.setModuleId("M");
		mapping28.setSequencenumber(28);
		mapping28.setKeyval("reserveForFutureUse_2");
		mapping28.setAccounttype("AR");
		mappingList.add(mapping28);
		AccountingExtractMappingEntity mapping29 = new AccountingExtractMappingEntity();
		mapping29.setClientId("QR");
		mapping29.setModuleId("M");
		mapping29.setSequencenumber(29);
		mapping29.setKeyval("reserveForFutureUse_3");
		mapping29.setAccounttype("AR");
		mappingList.add(mapping29);
		AccountingExtractMappingEntity mapping30 = new AccountingExtractMappingEntity();
		mapping30.setClientId("QR");
		mapping30.setModuleId("M");
		mapping30.setSequencenumber(30);
		mapping30.setKeyval("pointOfSale");
		mapping30.setAccounttype("AR");
		mappingList.add(mapping30);
		AccountingExtractMappingEntity mapping31 = new AccountingExtractMappingEntity();
		mapping31.setClientId("QR");
		mapping31.setModuleId("M");
		mapping31.setSequencenumber(31);
		mapping31.setKeyval("costCentreCode");
		mapping31.setAccounttype("AR");
		mappingList.add(mapping31);
		return mappingList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultMappingTableHeaderData_GL() {
		List<AccountingExtractMappingEntity> headerList = new ArrayList<>();
		AccountingExtractMappingEntity header = new AccountingExtractMappingEntity();
		header.setClientId("QR");
		header.setModuleId("M");
		header.setSequencenumber(1);
		header.setKeyval("GL Header");
		header.setDefaultvalue(
				"Business Unit,Currency Code,Cost Reallocation Business Unit,Effective Date,Journal Line Description,Reversal Date,Exchange Rate,Statistical Amount,Entered Debit,Entered Credit,GL account,Exchange Period,Source Code,Destination Currency,Reconciliation Code,Job Number,Claim Number,Flight Particulars,Date of expense,Financial Interface Run Identifier,Financial Document DayBook Type,Jv Number,ReserveForFutureUse_1,Order Number,Sale Reporting Period EndDate,Agent Code,Source Reference,ReserveForFutureUse_2,ReserveForFutureUse_3,Point Of Sale,Cost Centre Code");
		header.setAccounttype("GLEXTRACTH");
		headerList.add(header);
		return headerList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultMappingTableFileNameData_GL() {
		List<AccountingExtractMappingEntity> fileNameList = new ArrayList<>();
		AccountingExtractMappingEntity fileNameObject = new AccountingExtractMappingEntity();
		fileNameObject.setClientId("QR");
		fileNameObject.setModuleId("M");
		fileNameObject.setSequencenumber(1);
		fileNameObject.setKeyval("GL FileName");
		fileNameObject.setValue("MG");
		fileNameObject.setAccounttype("GLEXTRACTFN");
		fileNameList.add(fileNameObject);
		return fileNameList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultMappingTableFileNameData_AP() {
		List<AccountingExtractMappingEntity> fileNameList = new ArrayList<>();
		AccountingExtractMappingEntity fileNameObject = new AccountingExtractMappingEntity();
		fileNameObject.setClientId("QR");
		fileNameObject.setModuleId("M");
		fileNameObject.setSequencenumber(1);
		fileNameObject.setKeyval("AP FileName");
		fileNameObject.setValue("SP");
		fileNameObject.setAccounttype("APFN");
		fileNameList.add(fileNameObject);
		return fileNameList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultMappingTableFileNameData_AR() {
		List<AccountingExtractMappingEntity> fileNameList = new ArrayList<>();
		AccountingExtractMappingEntity fileNameObject = new AccountingExtractMappingEntity();
		fileNameObject.setClientId("QR");
		fileNameObject.setModuleId("M");
		fileNameObject.setSequencenumber(1);
		fileNameObject.setKeyval("AR FileName");
		fileNameObject.setValue("SR");
		fileNameObject.setAccounttype("ARFN");
		fileNameList.add(fileNameObject);
		return fileNameList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultMappingTableHeaderData_AP() {
		List<AccountingExtractMappingEntity> headerList = new ArrayList<>();
		AccountingExtractMappingEntity header = new AccountingExtractMappingEntity();
		header.setClientId("QR");
		header.setModuleId("M");
		header.setSequencenumber(1);
		header.setKeyval("AP Header");
		header.setDefaultvalue(
				"Business Unit,Currency Code,Cost Reallocation Business Unit,Effective Date,Journal Line Description,Reversal Date,Exchange Rate,Statistical Amount,Entered Debit,Entered Credit,GL account,Exchange Period,Source Code,Destination Currency,Reconciliation Code,Job Number,Claim Number,Flight Particulars,Date of expense,Financial Interface Run Identifier,Financial Document DayBook Type,Jv Number,ReserveForFutureUse_1,Order Number,Sale Reporting Period EndDate,Agent Code,Source Reference,ReserveForFutureUse_2,ReserveForFutureUse_3,Point Of Sale,Cost Centre Code");
		header.setAccounttype("APH");
		headerList.add(header);
		return headerList;
	}

	private List<AccountingExtractMappingEntity> mockDefaultMappingTableHeaderData_AR() {
		List<AccountingExtractMappingEntity> headerList = new ArrayList<>();
		AccountingExtractMappingEntity header = new AccountingExtractMappingEntity();
		header.setClientId("QR");
		header.setModuleId("M");
		header.setSequencenumber(1);
		header.setKeyval("AR Header");
		header.setDefaultvalue(
				"Business Unit,Currency Code,Cost Reallocation Business Unit,Effective Date,Journal Line Description,Reversal Date,Exchange Rate,Statistical Amount,Entered Debit,Entered Credit,GL account,Exchange Period,Source Code,Destination Currency,Reconciliation Code,Job Number,Claim Number,Flight Particulars,Date of expense,Financial Interface Run Identifier,Financial Document DayBook Type,Jv Number,ReserveForFutureUse_1,Order Number,Sale Reporting Period EndDate,Agent Code,Source Reference,ReserveForFutureUse_2,ReserveForFutureUse_3,Point Of Sale,Cost Centre Code");
		header.setAccounttype("ARH");
		headerList.add(header);
		return headerList;
	}

	private AccountingExtractEntity getDefaultAccountingExtractEntity(AccountingExtractModelGL model) {
		AccountingExtractEntity extractEntity = new AccountingExtractEntity();
		return extractEntity;
	}

	private AccountingExtractModelGL getDefaultAccountingExtractModel() {
		AccountingExtractModelGL model = new AccountingExtractModelGL();
		return model;
	}

	private List<AccountingFileExtractLogsModel> getDefaultAccountingFileExtractLogsModel() {
		return new ArrayList<AccountingFileExtractLogsModel>();
	}

	private FileLogging makeDefaultFileLogging() {
		FileLogging fileLogging = new FileLogging();
		fileLogging.setFileId(BigInteger.ONE);
		fileLogging.setFileName("Accounting-temp");
		return fileLogging;
	}

	private List<AccountingFileExtractLogsEntity> mockExtractLogsEntityData() {
		List<AccountingFileExtractLogsEntity> logEntityList = new ArrayList<>();
		AccountingFileExtractLogsEntity logsEntity1 = new AccountingFileExtractLogsEntity();
		logsEntity1.setClientId("QR");
		logsEntity1.setModuleId("M");
		logsEntity1.setCrAmtBaseCurrAuditTrail(new BigDecimal("51"));
		logsEntity1.setCrAmtBaseCurrAcctgSummn(new BigDecimal("101"));
		logsEntity1.setDrAmtBaseCurrAuditTrail(new BigDecimal("50"));
		logsEntity1.setDrAmtBaseCurrAcctgSummn(new BigDecimal("100"));
		logsEntity1.setFileExtractId(1);
		logsEntity1.setInterfaceType("GL");
		logsEntity1.setMonthCloseDate(LocalDate.of(2020, Month.FEBRUARY, 3));
		logsEntity1.setSummarisationId("10");
		logsEntity1.setSummarisedRecordCount(15);
		logsEntity1.setTotalRecExtractAuditTrail(15);

		AccountingFileExtractLogsEntity logsEntity2 = new AccountingFileExtractLogsEntity();
		logsEntity2.setClientId("QR");
		logsEntity2.setModuleId("M");
		logsEntity2.setCrAmtBaseCurrAuditTrail(new BigDecimal("51"));
		logsEntity2.setCrAmtBaseCurrAcctgSummn(new BigDecimal("101"));
		logsEntity2.setDrAmtBaseCurrAuditTrail(new BigDecimal("50"));
		logsEntity2.setDrAmtBaseCurrAcctgSummn(new BigDecimal("100"));
		logsEntity2.setFileExtractId(1);
		logsEntity2.setInterfaceType("GL");
		logsEntity2.setMonthCloseDate(LocalDate.of(2020, Month.FEBRUARY, 3));
		logsEntity2.setSummarisationId("10");
		logsEntity2.setSummarisedRecordCount(15);
		logsEntity2.setTotalRecExtractAuditTrail(15);
		logEntityList.add(logsEntity1);
		logEntityList.add(logsEntity2);
		return logEntityList;
	}

	//@Test
	public void test_saveAccountingExtract_Success_GL_CSV() {
		Mockito.doReturn(mockDefaultSummarizationData_GL()).when(summarRepo).getGLAllRecord("QR", "M", "GL",
				LocalDate.of(2020, Month.FEBRUARY, 3), AccountsConstants.ERROR_EXTRACT);
		Mockito.doReturn(mockDefaultFileNamingData_GL()).when(fileNamingConfigRepo)
				.findByClientIdAndModuleIdAndSubModuleIgnoreCaseAndFileTypeAndAccountType("QR", "M", null, "csv", "GL");
		String[] headerAndFileNameAndAccountType = { "GLEXTRACTH", "GLEXTRACTFN", "GLEXTRACT" };
		Mockito.doReturn(mockDefaultHeaderAndFileNameAndDataMappingForGL()).when(mappingRepo)
				.findByClientIdAndModuleIdAndAccounttypeInOrderBySequencenumberAsc("QR", "M",
						Arrays.asList(headerAndFileNameAndAccountType));
		when(glMapper.mapToEntity(Mockito.any(AccountingExtractModelGL.class)))
				.thenReturn(getDefaultAccountingExtractEntity(getDefaultAccountingExtractModel()));
		Mockito.doReturn(getDefaultAccountingExtractEntity(getDefaultAccountingExtractModel())).when(glMapper)
				.mapToEntity(Mockito.any(AccountingExtractModelGL.class));
		Mockito.doReturn(makeDefaultFileLogging()).when(batchGlobalFeignClient)
				.createFileLog(Mockito.any(FileLogging.class));
		AccountExtractRequest req = new AccountExtractRequest();
		req.setAccountType("GL");
		req.setClientId("QR");
		req.setModuleId("M");
		req.setFileType("csv");
		req.setMonthClosedDate("2020-02-03");
		accountingExtractResponse = fileExtractController.saveAccountingExtract(req);
		assertEquals(FileExtractConstants.SUCCESS, accountingExtractResponse.getStatus());
	}

	// @Test
	public void test_saveAccountingExtract_Success_AP_CSV() {
		Mockito.doReturn(mockDefaultSummarizationData_AP()).when(summarRepo).getGLRecordFilterBySubModule("QR", "S",
				"GL", null, LocalDate.of(2020, Month.FEBRUARY, 3), null);
		Mockito.doReturn(mockDefaultFileNamingData_AP()).when(fileNamingConfigRepo)
				.findByClientIdAndModuleIdAndSubModuleIgnoreCaseAndFileTypeAndAccountType("QR", "S", null, "csv", "AP");
		String[] headerAndFileNameAndAccountType = { "APH", "APFN", "AP" };
		Mockito.doReturn(mockDefaultHeaderAndFileNameAndDataMappingForAP()).when(mappingRepo)
				.findByClientIdAndModuleIdAndAccounttypeInOrderBySequencenumberAsc("QR", "S",
						Arrays.asList(headerAndFileNameAndAccountType));
		// when(extractMapper.mapToEntity(Mockito.any(AccountingExtractModel.class)))
		// .thenReturn(getDefaultAccountingExtractEntity());
		Mockito.doReturn(makeDefaultFileLogging()).when(batchGlobalFeignClient)
				.createFileLog(Mockito.any(FileLogging.class));
		// accountingExtractResponse =
		// fileExtractController.saveAccountingExtract("QR", "S", null, "AP",
		// "csv",
		// "2020-02-03");
		assertEquals(FileExtractConstants.SUCCESS, accountingExtractResponse.getStatus());
	}

	// @Test
	public void test_saveAccountingExtract_Success_1_AR_CSV() {
		Mockito.doReturn(mockDefaultSummarizationData_AR()).when(summarRepo).getGLRecordFilterBySubModule("QR", "S",
				"GL", null, LocalDate.of(2020, Month.FEBRUARY, 3), null);
		Mockito.doReturn(mockDefaultFileNamingData_AR()).when(fileNamingConfigRepo)
				.findByClientIdAndModuleIdAndSubModuleIgnoreCaseAndFileTypeAndAccountType("QR", "S", null, "csv", "AR");
		String[] headerAndFileNameAndAccountType = { "ARH", "ARFN", "AR" };
		Mockito.doReturn(mockDefaultHeaderAndFileNameAndDataMappingForAR()).when(mappingRepo)
				.findByClientIdAndModuleIdAndAccounttypeInOrderBySequencenumberAsc("QR", "S",
						Arrays.asList(headerAndFileNameAndAccountType));
		// when(extractMapper.mapToEntity(Mockito.any(AccountingExtractModel.class)))
		// .thenReturn(getDefaultAccountingExtractEntity());
		Mockito.doReturn(makeDefaultFileLogging()).when(batchGlobalFeignClient)
				.createFileLog(Mockito.any(FileLogging.class));
		// accountingExtractResponse =
		// fileExtractController.saveAccountingExtract("QR", "S", null, "AR",
		// "csv",
		// "2020-02-03");
		assertEquals(FileExtractConstants.SUCCESS, accountingExtractResponse.getStatus());
	}

}