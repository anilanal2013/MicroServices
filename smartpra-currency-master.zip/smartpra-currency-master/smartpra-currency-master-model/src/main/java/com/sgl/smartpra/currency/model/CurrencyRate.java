package com.sgl.smartpra.currency.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.OptionalPattern;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.ValidValues;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CurrencyRate extends BaseModel {
	
	private static final long serialVersionUID = 1L;

	private Integer currencyRateId;

	@RequiredNotEmpty(message = "Please provide Currency Rate Type", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, message = "Currency Rate Type should be any of the following: BSR, BKR, MMR, FDR, ROE, CSR, CCR", groups = {
			Update.class, Create.class })
	@ValidValues(values = "BSR,BKR,MMR,FDR,ROE,CSR,CCR", message = "Currency Rate Type should be any of the following: BSR, BKR, MMR, FDR, ROE, CSR, CCR", groups = { 
			Create.class, Update.class })
	private Optional<String> currencyRateType;

	
	@RequiredNotEmpty(message = "Please provide Exchange Rate", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> exchangeRate;

	@RequiredNotEmpty(message = "Please provide Currency From Code", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, message = "Currency From Code should be 3-alpha code", groups = { Update.class,
			Create.class })
	private Optional<String> currencyFromCode;

	@RequiredNotEmpty(message = "Please provide Currency To Code", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, message = "Currency To Code should be 3-alpha code", groups = { Update.class, Create.class })
	private Optional<String> currencyToCode;

	@RequiredNotEmpty(message = "Please provide effectiveFromDate",groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;

	@RequiredNotEmpty(message = "Please provide effectiveToDate",groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;

	@OptionalNotEmpty(groups = {Create.class,Update.class})
	private Optional<Integer> inboundFileId;
	
	@Null(message = "isActive is not a valid input", groups = { Create.class, Update.class })
	private Boolean isActive;

}
