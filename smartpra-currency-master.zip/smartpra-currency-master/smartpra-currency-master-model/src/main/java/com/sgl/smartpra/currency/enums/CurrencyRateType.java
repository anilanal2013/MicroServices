package com.sgl.smartpra.currency.enums;

public enum CurrencyRateType {

	BSR("BSR"), BKR("BKR"), MMR("MMR"), FDR("FDR"), ROE("ROE"), CSR("CSR");

	private String currencyRateTypes;

	CurrencyRateType(String currencyRateTypes) {
		this.currencyRateTypes = currencyRateTypes;
	}

	public String getCurrencyRateType() {
		return currencyRateTypes;
	}

	public String toString() {
		return currencyRateTypes;
	}

}
