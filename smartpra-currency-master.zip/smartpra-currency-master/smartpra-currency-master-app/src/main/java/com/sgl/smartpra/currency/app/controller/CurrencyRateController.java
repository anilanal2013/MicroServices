package com.sgl.smartpra.currency.app.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.currency.app.dao.entity.CurrencyRateEntity;
import com.sgl.smartpra.currency.app.service.CurrencyRateService;
import com.sgl.smartpra.currency.model.CurrencyRate;

@RestController
public class CurrencyRateController {

	@Autowired
	private CurrencyRateService currencyRateService;

	@GetMapping("/currency")
	public List<CurrencyRate> getAllCurrencyRates(
			@RequestParam(value = "currencyRateType", required = false) Optional<String> currencyRateType,
			@RequestParam(value = "currencyFromCode", required = false) Optional<String> currencyFromCode,
			@RequestParam(value = "currencyToCode", required = false) Optional<String> currencyToCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "isActive", required = false) Optional<Boolean> isActive) {
		return currencyRateService.getAllCurrencyRates(currencyRateType, currencyFromCode, currencyToCode, effectiveFromDate, effectiveToDate, isActive);
	}

	@GetMapping("/currency/{currencyRateType}/{currencyFromCode}/{currencyToCode}/{effectiveDate}")
	public CurrencyRate getEffectiveCurrencyRate(
			@PathVariable(value = "currencyRateType", required = true) String currencyRateType,
			@PathVariable(value = "currencyFromCode", required = true) String currencyFromCode,
			@PathVariable(value = "currencyToCode", required = true) String currencyToCode,
			@PathVariable(value = "effectiveDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date effectiveDate) {
		return currencyRateService.getEffectiveCurrencyRate(currencyRateType, currencyFromCode, currencyToCode,
				effectiveDate);
	}

	@GetMapping("/currency/{currencyRateId}")
	public CurrencyRate findCurrencyRateByCurrencyRateId(
			@PathVariable(value = "currencyRateId") Integer currencyRateId) {
		return currencyRateService.findCurrencyRateByCurrencyRateId(currencyRateId);
	}

	@PostMapping("/currency")
	public CurrencyRate createCurrencyRate(@Validated(Create.class) @RequestBody CurrencyRate currencyRate) {
		return currencyRateService.createCurrencyRate(currencyRate);
	}

	@PutMapping("/currency/{currencyRateId}")
	public CurrencyRate updateCurrencyRate(@PathVariable(value = "currencyRateId") Integer currencyRateId,
			@Validated(Update.class) @RequestBody CurrencyRate currencyRate) {
		return currencyRateService.updateCurrencyRate(currencyRateId, currencyRate);
	}

	@PutMapping("/currency/{currencyRateId}/deactivate")
	public void deactivateCurrencyRate(@Valid @PathVariable(value = "currencyRateId") Integer currencyRateId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		currencyRateService.deactivateCurrencyRate(currencyRateId, lastUpdatedBy);
	}

	@PutMapping("/currency/{currencyRateId}/activate")
	public void activateCurrencyRate(@Valid @PathVariable(value = "currencyRateId") Integer currencyRateId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		currencyRateService.activateCurrencyRate(currencyRateId, lastUpdatedBy);
	}

	@PostMapping("/currency/copy")
	public CurrencyRate copyCurrencyRate(@Validated(Create.class) @RequestBody CurrencyRate currencyRate,
			@RequestParam(value = "effectiveFromDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date effectiveToDate) {
		return currencyRateService.copyCurrencyRate(currencyRate, effectiveFromDate, effectiveToDate);
	}

	@PostMapping("/currency/derive-bkr")
	public CurrencyRate deriveCurrencyBKR(@Validated(Create.class) @RequestBody CurrencyRate currencyRate,
			@RequestParam(value = "effectiveFromDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date effectiveToDate) {
		return currencyRateService.deriveCurrencyBKR(currencyRate, effectiveFromDate, effectiveToDate);
	}

	@PostMapping("/currency/bkr-fdr")
	public List<CurrencyRateEntity> deriveBKRFromFDR(
			@RequestParam(value = "effectiveDate", required = true) String effectiveDate,
			@RequestParam(value = "currencyCode", required = true) String currencyCode) {
		return currencyRateService.deriveBKRFromFDR(effectiveDate,currencyCode);

	}

}
