package com.sgl.smartpra.currency.app.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.currency.app.dao.entity.CurrencyRateEntity;
import com.sgl.smartpra.currency.model.CurrencyRate;


public interface CurrencyRateService {

	public List<CurrencyRate> getAllCurrencyRates(Optional<String> currencyRateType, Optional<String> currencyFromCode, Optional<String> currencyToCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> isActive);
	
	public CurrencyRate getEffectiveCurrencyRate(String currencyRateType, String currencyFromCode,String currencyToCode, Date effectiveDate);

	public CurrencyRate findCurrencyRateByCurrencyRateId(Integer currencyRateId);

	public CurrencyRate createCurrencyRate(CurrencyRate currencyRate);

	public CurrencyRate updateCurrencyRate(Integer currencyRateId, CurrencyRate currencyRate);

	public void deactivateCurrencyRate(Integer currencyRateId, String lastUpdatedBy);

	public void activateCurrencyRate(Integer currencyRateId, String lastUpdatedBy);
	
	public CurrencyRate copyCurrencyRate(CurrencyRate currencyRate, Date effectiveFromDate,Date effectiveToDate );
	
	public CurrencyRate deriveCurrencyBKR(CurrencyRate currencyRate, Date effectiveFromDate,Date effectiveToDate );

	public List<CurrencyRateEntity> deriveBKRFromFDR(String effectiveDate, String currencyCode); 
}
