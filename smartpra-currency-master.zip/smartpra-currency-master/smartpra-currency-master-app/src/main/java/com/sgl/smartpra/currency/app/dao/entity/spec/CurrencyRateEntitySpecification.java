package com.sgl.smartpra.currency.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.currency.app.dao.entity.CurrencyRateEntity;

public class CurrencyRateEntitySpecification {

	private CurrencyRateEntitySpecification() {
	}

	public static Specification<CurrencyRateEntity> equalsCurrencyRateType(String currencyRateType) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(currencyRateEntity.get("currencyRateType"), currencyRateType);
	}

	public static Specification<CurrencyRateEntity> equalsCurrencyFromCode(String currencyFromCode) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(currencyRateEntity.get("currencyFromCode"), currencyFromCode);
	}

	public static Specification<CurrencyRateEntity> equalsCurrencyToCode(String currencyToCode) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(currencyRateEntity.get("currencyToCode"), currencyToCode);
	}

	public static Specification<CurrencyRateEntity> equalsEffectiveFromDate(LocalDate effectiveToDate) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(currencyRateEntity.get("effectiveFromDate"), effectiveToDate);
	}

	public static Specification<CurrencyRateEntity> betweenEffectiveFromDateAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), currencyRateEntity.get("effectiveFromDate"),
				currencyRateEntity.get("effectiveToDate"));
	}

	public static Specification<CurrencyRateEntity> likeCurrencyRateType(String currencyRateType) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(currencyRateEntity.get("currencyRateType"), currencyRateType + "%");
	}

	public static Specification<CurrencyRateEntity> likeCurrencyFromCode(String currencyFromCode) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(currencyRateEntity.get("currencyFromCode"), currencyFromCode + "%");
	}

	public static Specification<CurrencyRateEntity> likeCurrencyToCode(String currencyToCode) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(currencyRateEntity.get("currencyToCode"), currencyToCode + "%");
	}

	public static Specification<CurrencyRateEntity> isActive(Boolean isActive) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(currencyRateEntity.get("isActive"), isActive);
	}

	public static Specification<CurrencyRateEntity> notEqualsCurrencyRateId(Integer currencyRateId) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(currencyRateEntity.get("currencyRateId"), currencyRateId);
	}

	public static void orderByEffectiveToDateByAsc(Root<CurrencyRateEntity> currencyRateEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(currencyRateEntity.get(orderByString)));
	}

	public static Specification<CurrencyRateEntity> search(Optional<String> currencyRateType,
			Optional<String> currencyFromCode, Optional<String> currencyToCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<Boolean> isActive) {
		return (currencyRateEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(currencyRateType)) {
				predicates.add(criteriaBuilder.like(currencyRateEntity.get("currencyRateType"),
						OptionalUtil.getValue(currencyRateType) + "%"));
			}

			if (OptionalUtil.isPresent(currencyFromCode)) {
				predicates.add(criteriaBuilder.like(currencyRateEntity.get("currencyFromCode"),
						OptionalUtil.getValue(currencyFromCode) + "%"));
			}

			if (OptionalUtil.isPresent(currencyToCode)) {
				predicates.add(criteriaBuilder.like(currencyRateEntity.get("currencyToCode"),
						OptionalUtil.getValue(currencyToCode) + "%"));
			}

			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								currencyRateEntity.get("effectiveFromDate"), currencyRateEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								currencyRateEntity.get("effectiveFromDate"),
								currencyRateEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							currencyRateEntity.get("effectiveFromDate"), currencyRateEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							currencyRateEntity.get("effectiveFromDate"), currencyRateEntity.get("effectiveToDate")));
				}
			}

			if (OptionalUtil.getValue(isActive) == null || OptionalUtil.getValue(isActive)) {
				predicates.add(criteriaBuilder.isTrue(currencyRateEntity.get("isActive")));
			} else {
				predicates.add(criteriaBuilder.isFalse(currencyRateEntity.get("isActive")));
			}

			orderByEffectiveToDateByAsc(currencyRateEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
