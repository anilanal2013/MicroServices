package com.sgl.smartpra.currency.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.currency.app.dao.entity.CurrencyRateEntity;
import com.sgl.smartpra.currency.model.CurrencyRate;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)

public interface CurrencyRateMapper extends BaseMapper<CurrencyRate, CurrencyRateEntity> {

	CurrencyRateEntity mapToEntity(CurrencyRate currencyRate, @MappingTarget CurrencyRateEntity currencyRateEntity);

	CurrencyRateEntity mapToEntity(CurrencyRate currencyRate);

}
