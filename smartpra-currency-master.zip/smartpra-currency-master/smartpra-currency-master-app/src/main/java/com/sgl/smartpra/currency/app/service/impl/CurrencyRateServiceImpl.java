package com.sgl.smartpra.currency.app.service.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Pattern;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.currency.app.configuration.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.currency.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.currency.app.dao.CurrencyRateDao;
import com.sgl.smartpra.currency.app.dao.entity.CurrencyRateEntity;
import com.sgl.smartpra.currency.app.dao.repository.CurrencyRateRepository;
import com.sgl.smartpra.currency.app.mapper.CurrencyRateMapper;
import com.sgl.smartpra.currency.app.service.CurrencyRateService;
import com.sgl.smartpra.currency.enums.CurrencyRateType;
import com.sgl.smartpra.currency.enums.deriveMonthFirstAndLastDate;
import com.sgl.smartpra.currency.model.CurrencyRate;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.master.model.SystemParameter;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class CurrencyRateServiceImpl implements CurrencyRateService {

	@Autowired
	CurrencyRateRepository currencyRateRepository;

	@Autowired
	CurrencyRateMapper currencyRateMapper;

	@Autowired
	CurrencyRateDao currencyRateDao;

	@Autowired
	private MasterFeignClient masterFeignClient;

	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;

	private static final String LASTUPDATEDBYVALIDLENGTH = "LastUpdatedBy should be minimum of 1 and maximum of 15 characters";
	private static final String MANDATORYLASTUPDATEDBY = "Please provide lastupdatedby";
	private static final String CR = "Currency Rate ";
	private static final String CRINACTIVE = "Currency Rate is already in deactivated state";
	private static final String CRACTIVE = "Currency Rate is already in activated state";
	private static final String DATEVALIDATION1 = "Overlapping period for ";
	private static final String DATEVALIDATION2 = " for period ";
	private static final String DATEVALIDATION3 = " is not allowed.";
	private static final String RATE = "Rate ";
	private static final String MISSINGPREVIOUSDAY = " missing for previous day ";
	private static final String CURRENCYCODES = " for the currency codes ";
	private static final String DEACTIVATESTATE = "Record already exist in deactivated state";
	private static final String INVALIDFROMCODE = "Invalid Currency From Code ";
	private static final String INVALIDTOCODE = "Invalid CurrencyToCode ";
	private static final String COPYDEACTIVATESTATE = "Copy Record already exist in deactivated state";
	private static final String COPYACTIVATESTATE = "Record already exist";
	private static final String NOSAMEDATE = "Source and Target periods cannot be same";
	private static final String NOCURRENCYRECORD = "No record found for Currency Type: ";
	private static final String CODES = " and Codes: ";
	public static final String EFFECTIVE_DATE = "Please provide a valid effectiveDate: Like 01/2019";
	public static final String EFFECTIVE_FROM_DATE_ON_UPDATE = "Can't Change Effective To Date";
	public static final String DATE_PATTERN = "dd/MM/yyyy";
	public static final String DATE_PATTERN1 = "yyyy-MM-dd";
	public static final String EFFECTIVE_TO_DATE = "Effective To date ";
	public static final String GREATER_EFFECTIVE_FROM_DATE = " should be greater than Effective From date ";
	public static final String CAN_NOT_BLANK = " cannot be blank";
	public static final String CONTEXT = "Context ";

	@Override
	public List<CurrencyRate> getAllCurrencyRates(Optional<String> currencyRateType, Optional<String> currencyFromCode,
			Optional<String> currencyToCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> isActive) {
		return currencyRateMapper.mapToModel(currencyRateDao.search(currencyRateType, currencyFromCode, currencyToCode,
				effectiveFromDate, effectiveToDate, isActive));
	}

	@Override
	public CurrencyRate findCurrencyRateByCurrencyRateId(Integer currencyRateId) {
		return currencyRateMapper.mapToModel(currencyRateDao.findById(currencyRateId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(currencyRateId))));
	}

	@Override
	public CurrencyRate createCurrencyRate(CurrencyRate currencyRate) {
		DateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN1);

		Integer currencyRateId = currencyRate.getCurrencyRateId();

		if (currencyRateId != null) {
			throw new BusinessException("Currency Rate Id should not be part of request body.");
		}
		validateExchangeRate(currencyRate);
		String rateType = OptionalUtil.getValue(currencyRate.getCurrencyRateType());
		String fromCode = OptionalUtil.getValue(currencyRate.getCurrencyFromCode());
		String toCode = OptionalUtil.getValue(currencyRate.getCurrencyToCode());
		BigDecimal exchangeRate =new BigDecimal(OptionalUtil.getValue(currencyRate.getExchangeRate()));

		Date fromDate = null;
		Date toDate = null;
		try {
			fromDate = dateFormat.parse(OptionalUtil.getValue(currencyRate.getEffectiveFromDate()));
			toDate = dateFormat.parse(OptionalUtil.getValue(currencyRate.getEffectiveToDate()));
		} catch (ParseException e) {
			log.error(CONTEXT + e);
		}

		checkValidInputs(fromCode, toCode, fromDate, toDate, exchangeRate);
		sameDateInActiveRecord(rateType, fromCode, toCode, fromDate, toDate);

		checkFirstRecord(rateType, fromCode, toCode, fromDate);

		overlapCheck(rateType, fromCode, toCode, fromDate, toDate);
		checkLastRecord(rateType, fromCode, toCode, fromDate);

		currencyRate.setIsActive(Boolean.TRUE);
		currencyRate.setCreatedDate(java.time.LocalDateTime.now());

		return currencyRateMapper.mapToModel(currencyRateDao.create(currencyRateMapper.mapToEntity(currencyRate)));

	}

	@Override
	public CurrencyRate updateCurrencyRate(Integer currencyRateId, CurrencyRate currencyRate) {
		DateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN1);

		CurrencyRateEntity currencyRateEntity = currencyRateDao.findById(currencyRateId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(currencyRateId)));
		validateExchangeRate(currencyRate);
		// update only if the record is active
		if (!currencyRateEntity.getIsActive()) {
			throw new BusinessException(CR + currencyRateEntity.getCurrencyRateType() + CURRENCYCODES
					+ currencyRateEntity.getCurrencyFromCode() + " , is not active for the period from "
					+ currencyRateEntity.getEffectiveFromDate() + " TO " + currencyRateEntity.getEffectiveToDate());
		}

		String rateType = OptionalUtil.getValue(currencyRate.getCurrencyRateType());
		String fromCode = OptionalUtil.getValue(currencyRate.getCurrencyFromCode());
		String toCode = OptionalUtil.getValue(currencyRate.getCurrencyToCode());
		BigDecimal exchangeRate =new BigDecimal(OptionalUtil.getValue(currencyRate.getExchangeRate()));

		Date fromDate = null;
		Date toDate = null;
		try {
			fromDate = dateFormat.parse(OptionalUtil.getValue(currencyRate.getEffectiveFromDate()));
			toDate = dateFormat.parse(OptionalUtil.getValue(currencyRate.getEffectiveToDate()));
		} catch (ParseException e1) {
			log.error(CONTEXT + e1);
		}

		checkValidInputs(fromCode, toCode, fromDate, toDate, exchangeRate);
		sameDateInActiveRecord(rateType, fromCode, toCode, fromDate, toDate);

		Date inputFromdate = null;
		Date inputTodate = null;
		boolean recordId = false;

		Date firstRecordDate = convertDate(
				currencyRateRepository.checkFirstRecordDate(OptionalUtil.getValue(currencyRate.getCurrencyRateType()),
						OptionalUtil.getValue(currencyRate.getCurrencyFromCode()),
						OptionalUtil.getValue(currencyRate.getCurrencyToCode())));

		Date lastRecordToDate = convertDate(
				currencyRateRepository.checkLastRecord(OptionalUtil.getValue(currencyRate.getCurrencyRateType()),
						OptionalUtil.getValue(currencyRate.getCurrencyFromCode()),
						OptionalUtil.getValue(currencyRate.getCurrencyToCode())));

		List<CurrencyRateEntity> recordEntity = currencyRateRepository.geCurrencyRateEntities(rateType,
				convertLocalDate(fromDate), convertLocalDate(toDate), fromCode, toCode);

		if (!recordEntity.isEmpty()) {
			for (int i = 0; i < recordEntity.size(); i++) {

				if (currencyRateId == recordEntity.get(i).getCurrencyRateId()) {
					recordId = true;
				}
			}
		}

		validateOverlapForUpdate(currencyRate, currencyRateEntity);
		checkEffectiveFromEqualsEffectiveTo(currencyRate, currencyRateEntity);

		if (firstRecordDate != null && lastRecordToDate != null) {

			try {
				DateFormat format = new SimpleDateFormat(DATE_PATTERN1, Locale.ENGLISH);
				inputFromdate = format.parse(OptionalUtil.getValue(currencyRate.getEffectiveFromDate()));
				inputTodate = format.parse(OptionalUtil.getValue(currencyRate.getEffectiveToDate()));

			} catch (ParseException e) {
				log.error(CONTEXT + e);
			}

			if (inputFromdate.equals(convertDate(currencyRateEntity.getEffectiveFromDate()))
					&& inputTodate.equals(convertDate(currencyRateEntity.getEffectiveToDate()))) {

				if (!recordId) {
					overlapCheckForUpdate(rateType, fromCode, toCode, fromDate, toDate,
							currencyRateEntity.getCurrencyRateId());
				}
				setEntityValues(currencyRateEntity, currencyRate);
				return currencyRateMapper.mapToModel(
						currencyRateDao.update(currencyRateMapper.mapToEntity(currencyRate, currencyRateEntity)));
			}

			if (!OptionalUtil.getLocalDateValue(currencyRate.getEffectiveFromDate())
					.equals(currencyRateEntity.getEffectiveFromDate()) && recordId
					&& OptionalUtil.getValue(currencyRate.getCurrencyRateType())
							.equalsIgnoreCase(currencyRateEntity.getCurrencyRateType())) {
				throw new BusinessException("Efective From Date cannot be changed");
			}

			if (firstRecordDate.equals(convertDate(currencyRateEntity.getEffectiveFromDate()))
					&& (inputFromdate.before(firstRecordDate) || inputFromdate.after(firstRecordDate))
					&& (lastRecordToDate.equals(convertDate(currencyRateEntity.getEffectiveToDate()))
							&& (inputTodate.before(lastRecordToDate) || inputFromdate.after(lastRecordToDate)))) {

				if (!recordId) {
					overlapCheckForUpdate(rateType, fromCode, toCode, fromDate, toDate,
							currencyRateEntity.getCurrencyRateId());
				}

				DateTime start = new DateTime(lastRecordToDate);
				DateTime end = new DateTime(OptionalUtil.getValue(currencyRate.getEffectiveFromDate()));

				Days diffInDays = Days.daysBetween(start, end);

				try {
					DateFormat format = new SimpleDateFormat(DATE_PATTERN, Locale.ENGLISH);
					Date date = format.parse(format.format(lastRecordToDate));
					if (diffInDays.getDays() > 1 || diffInDays.getDays() < 0) {

						LocalDateTime nextDay = LocalDateTime.fromDateFields(date).plusDays(1);

						throw new BusinessException(
								RATE + currencyRate.getCurrencyRateType() + MISSINGPREVIOUSDAY + nextDay);
					}
				} catch (ParseException e) {
					log.error(CONTEXT + e);
				}

				setEntityValues(currencyRateEntity, currencyRate);

				return currencyRateMapper.mapToModel(
						currencyRateDao.update(currencyRateMapper.mapToEntity(currencyRate, currencyRateEntity)));

			}

			if (firstRecordDate.equals(convertDate(currencyRateEntity.getEffectiveFromDate()))
					&& (inputFromdate.before(firstRecordDate) || inputFromdate.after(firstRecordDate))
					&& !lastRecordToDate.equals(convertDate(currencyRateEntity.getEffectiveToDate()))) {

				overlapCheckForUpdate(rateType, fromCode, toCode, fromDate, toDate,
						currencyRateEntity.getCurrencyRateId());

				DateTime start = new DateTime(lastRecordToDate);
				DateTime end = new DateTime(OptionalUtil.getValue(currencyRate.getEffectiveFromDate()));

				Days diffInDays = Days.daysBetween(start, end);

				try {
					DateFormat format = new SimpleDateFormat(DATE_PATTERN, Locale.ENGLISH);
					Date date = format.parse(format.format(lastRecordToDate));
					if (diffInDays.getDays() > 1 || diffInDays.getDays() < 0) {

						LocalDateTime nextDay = LocalDateTime.fromDateFields(date).plusDays(1);

						throw new BusinessException(
								RATE + currencyRate.getCurrencyRateType() + MISSINGPREVIOUSDAY + nextDay);
					}
				} catch (ParseException e) {
					log.error(CONTEXT + e);
				}
			}

			if (!firstRecordDate.equals(convertDate(currencyRateEntity.getEffectiveFromDate()))
					|| (inputTodate.before(lastRecordToDate) || inputTodate.after(lastRecordToDate))
							&& lastRecordToDate.equals(convertDate(currencyRateEntity.getEffectiveToDate()))) {

				if (inputFromdate.after(firstRecordDate) || lastRecordToDate.before(inputTodate)) {
					overlapCheckForUpdate(rateType, fromCode, toCode, fromDate, toDate,
							currencyRateEntity.getCurrencyRateId());
				}

				DateTime start = new DateTime(lastRecordToDate);
				DateTime end = new DateTime(OptionalUtil.getValue(currencyRate.getEffectiveFromDate()));

				Days diffInDays = Days.daysBetween(start, end);

				try {
					DateFormat format = new SimpleDateFormat(DATE_PATTERN, Locale.ENGLISH);
					Date date = format.parse(format.format(lastRecordToDate));

					if (currencyRateDao.checkEffectiveFromEqualsEffectiveTo(
							OptionalUtil.getValue(currencyRate.getCurrencyRateType()),
							currencyRateEntity.getEffectiveToDate().plusDays(1), currencyRateEntity.getCurrencyRateId(),
							OptionalUtil.getValue(currencyRate.getCurrencyFromCode()),
							OptionalUtil.getValue(currencyRate.getCurrencyToCode())) != 0) {
						if (diffInDays.getDays() > 1 || diffInDays.getDays() < 0) {

							LocalDateTime nextDay = LocalDateTime.fromDateFields(date).plusDays(1);

							throw new BusinessException(
									RATE + currencyRate.getCurrencyRateType() + MISSINGPREVIOUSDAY + nextDay);
						}
					}

				} catch (ParseException e) {
					log.error(CONTEXT + e);
				}

				DateTime dbFromDate = new DateTime(currencyRateEntity.getEffectiveFromDate().toString());
				DateTime inputFromDate = new DateTime(OptionalUtil.getValue(currencyRate.getEffectiveFromDate()));

				Days diffInDBDays = Days.daysBetween(dbFromDate, inputFromDate);

				if (diffInDBDays.getDays() > 0) {

					throw new BusinessException(
							RATE + currencyRate.getCurrencyRateType() + MISSINGPREVIOUSDAY + dbFromDate);
				}

				overlapCheckForUpdate(rateType, fromCode, toCode, fromDate, toDate,
						currencyRateEntity.getCurrencyRateId());
				setEntityValues(currencyRateEntity, currencyRate);

				return currencyRateMapper.mapToModel(
						currencyRateDao.update(currencyRateMapper.mapToEntity(currencyRate, currencyRateEntity)));
			}

			if (!firstRecordDate.equals(convertDate(currencyRateEntity.getEffectiveFromDate()))
					&& !lastRecordToDate.equals(convertDate(currencyRateEntity.getEffectiveToDate()))) {

				DateTime dbFromDate = new DateTime(currencyRateEntity.getEffectiveFromDate());
				DateTime inputFromDate = new DateTime(OptionalUtil.getValue(currencyRate.getEffectiveFromDate()));

				Days diffInDBDays = Days.daysBetween(dbFromDate, inputFromDate);

				if (diffInDBDays.getDays() > 0) {

					throw new BusinessException(
							RATE + currencyRate.getCurrencyRateType() + MISSINGPREVIOUSDAY + dbFromDate);
				}

				DateTime start = new DateTime(lastRecordToDate);
				DateTime end = new DateTime(OptionalUtil.getValue(currencyRate.getEffectiveFromDate()));

				Days diffInDays = Days.daysBetween(start, end);

				try {
					DateFormat format = new SimpleDateFormat(DATE_PATTERN, Locale.ENGLISH);
					Date date = format.parse(format.format(lastRecordToDate));
					if (diffInDays.getDays() > 1 || diffInDays.getDays() < 0) {

						LocalDateTime nextDay = LocalDateTime.fromDateFields(date).plusDays(1);

						throw new BusinessException(
								RATE + currencyRate.getCurrencyRateType() + MISSINGPREVIOUSDAY + nextDay);
					}
				} catch (ParseException e) {
					log.error(CONTEXT + e);
				}

				overlapCheckForUpdate(rateType, fromCode, toCode, fromDate, toDate,
						currencyRateEntity.getCurrencyRateId());
				setEntityValues(currencyRateEntity, currencyRate);
			}

		}

		if (!recordId) {
			overlapCheckForUpdate(rateType, fromCode, toCode, fromDate, toDate, currencyRateEntity.getCurrencyRateId());
		}
		setEntityValues(currencyRateEntity, currencyRate);
		return currencyRateMapper
				.mapToModel(currencyRateDao.update(currencyRateMapper.mapToEntity(currencyRate, currencyRateEntity)));

	}

	public CurrencyRateEntity setEntityValues(CurrencyRateEntity currencyRateEntity, CurrencyRate currencyRate) {
		currencyRateEntity.setCurrencyRateType(OptionalUtil.getValue(currencyRate.getCurrencyRateType()));
		currencyRateEntity.setExchangeRate(new BigDecimal(OptionalUtil.getValue(currencyRate.getExchangeRate())));
		currencyRateEntity.setCurrencyFromCode(OptionalUtil.getValue(currencyRate.getCurrencyFromCode()));
		currencyRateEntity.setCurrencyToCode(OptionalUtil.getValue(currencyRate.getCurrencyToCode()));
		currencyRateEntity.setEffectiveFromDate(
				java.time.LocalDate.parse(OptionalUtil.getValue(currencyRate.getEffectiveFromDate())));
		currencyRateEntity.setEffectiveToDate(
				java.time.LocalDate.parse(OptionalUtil.getValue(currencyRate.getEffectiveToDate())));
		if (OptionalUtil.isPresent(currencyRate.getInboundFileId())) {
			currencyRateEntity.setInboundFileId(OptionalUtil.getValue(currencyRate.getInboundFileId()));
		}
		currencyRateEntity.setLastUpdatedBy(OptionalUtil.getValue(currencyRate.getLastUpdatedBy()));
		currencyRateEntity.setLastUpdatedDate(java.time.LocalDateTime.now());

		return currencyRateEntity;
	}

	public void checkValidInputs(String fromCode, String toCode, Date fromDate, Date toDate, BigDecimal exchangeRate) {

		if (fromCode.equals(toCode)) {
			throw new BusinessException(
					"From Currency code " + fromCode + " and To Currency code " + toCode + " cannot be same");
		}

		if (exchangeRate.doubleValue() <= 0) {
			throw new BusinessException("Invalid Exchange Rate " + exchangeRate);
		}

		if (!globalMasterFeignClient.validateCurrencyCode(fromCode)) {
			throw new BusinessException(INVALIDFROMCODE + fromCode);
		}

		if (!globalMasterFeignClient.validateCurrencyCode(toCode)) {
			throw new BusinessException("Invalid Currency To Code " + toCode);
		}

		boolean dateCheck = toDate.after(fromDate);

		boolean dateEqualCheck = toDate.equals(fromDate);

		if (!dateEqualCheck) {
			if (!dateCheck) {
				throw new BusinessException(EFFECTIVE_TO_DATE + toDate + GREATER_EFFECTIVE_FROM_DATE + fromDate);
			}
		}

	}

	public void sameDateInActiveRecord(String rateType, String fromCode, String toCode, Date fromDate, Date toDate) {

		int sameRecordCount = currencyRateRepository.checkSameInActiveRecord(rateType, fromCode, toCode,
				convertLocalDate(fromDate), convertLocalDate(toDate));

		if (sameRecordCount == 1) {
			throw new BusinessException(DEACTIVATESTATE);
		}
	}

	public void overlapCheck(String rateType, String fromCode, String toCode, Date fromDate, Date toDate) {

		int count = currencyRateRepository.verifyIfOverlapExits(convertLocalDate(fromDate), convertLocalDate(toDate),
				rateType, fromCode, toCode);
		if (count > 0) {
			throw new BusinessException(
					"Effective dates " + fromDate + " - " + toDate + " are overlapping for Rate type " + rateType);

		}
	}

	public void overlapCheckForUpdate(String rateType, String fromCode, String toCode, Date fromDate, Date toDate,
			Integer currencyRateId) {

		int count = currencyRateRepository.verifyIfOverlapExitsForUpdate(convertLocalDate(fromDate),
				convertLocalDate(toDate), rateType, fromCode, toCode, currencyRateId);
		if (count > 0) {
			throw new BusinessException(
					DATEVALIDATION1 + rateType + DATEVALIDATION2 + fromDate + " & " + toDate + DATEVALIDATION3);
		}
	}

	public void checkFirstRecord(String rateType, String fromCode, String toCode, Date fromDate) {

		Date firstRecordDate = convertDate(currencyRateRepository.checkFirstRecordDate(rateType, fromCode, toCode));

		if (firstRecordDate != null) {
			DateTime dbFromDate = new DateTime(firstRecordDate);
			DateTime modelToDate = new DateTime(fromDate);

			Days diffInDBDays = Days.daysBetween(dbFromDate, modelToDate);

			if (diffInDBDays.getDays() < 0) {

				throw new BusinessException(RATE + rateType + MISSINGPREVIOUSDAY + dbFromDate);
			}
		}
	}

	public void checkLastRecord(String rateType, String fromCode, String toCode, Date fromDate) {

		Date lastRecordToDate = convertDate(currencyRateRepository.checkLastRecord(rateType, fromCode, toCode));

		if (lastRecordToDate != null) {

			DateTime start = new DateTime(lastRecordToDate);
			DateTime end = new DateTime(fromDate);

			Days diffInDays = Days.daysBetween(start, end);

			try {
				DateFormat format = new SimpleDateFormat(DATE_PATTERN, Locale.ENGLISH);
				Date date = format.parse(format.format(lastRecordToDate));
				if (diffInDays.getDays() > 1 || diffInDays.getDays() < 0) {

					LocalDateTime nextDay = LocalDateTime.fromDateFields(date).plusDays(1);

					throw new BusinessException(RATE + rateType + MISSINGPREVIOUSDAY + nextDay);
				}
			} catch (ParseException e) {
				log.error(CONTEXT + e);
			}
		}
	}

	@Override
	public void deactivateCurrencyRate(Integer currencyRateId, String lastUpdatedBy) {
		CurrencyRateEntity currencyRateEntity = currencyRateDao.findById(currencyRateId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(currencyRateId)));

		if (!currencyRateEntity.getIsActive())
			throw new BusinessException(CRINACTIVE);

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		currencyRateEntity.setLastUpdatedBy(lastUpdatedBy);
		currencyRateEntity.setLastUpdatedDate(java.time.LocalDateTime.now());
		currencyRateEntity.setIsActive(Boolean.FALSE);
		currencyRateDao.update(currencyRateEntity);

	}

	@Override
	public void activateCurrencyRate(Integer currencyRateId, String lastUpdatedBy) {
		CurrencyRateEntity currencyRateEntity = currencyRateDao.findById(currencyRateId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(currencyRateId)));

		if (currencyRateEntity.getIsActive())
			throw new BusinessException(CRACTIVE);

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		String fromCode = currencyRateEntity.getCurrencyFromCode();
		String toCode = currencyRateEntity.getCurrencyToCode();

		if (!globalMasterFeignClient.validateCurrencyCode(fromCode)) {
			throw new BusinessException(INVALIDFROMCODE + fromCode);
		}

		if (!globalMasterFeignClient.validateCurrencyCode(toCode)) {
			throw new BusinessException(INVALIDTOCODE + toCode);
		}

		int count = currencyRateRepository.verifyRecordExits(currencyRateEntity.getEffectiveFromDate(),
				currencyRateEntity.getEffectiveToDate(), currencyRateEntity.getCurrencyRateType(),
				currencyRateEntity.getCurrencyFromCode(), currencyRateEntity.getCurrencyToCode());

		if (count > 0) {
			throw new BusinessException(DATEVALIDATION1 + currencyRateEntity.getCurrencyRateType() + DATEVALIDATION2
					+ currencyRateEntity.getEffectiveFromDate() + " & " + currencyRateEntity.getEffectiveToDate()
					+ DATEVALIDATION3);
		}

		Date lastRecordToDate = convertDate(
				currencyRateRepository.checkLastRecord(currencyRateEntity.getCurrencyRateType(),
						currencyRateEntity.getCurrencyFromCode(), currencyRateEntity.getCurrencyToCode()));

		if (lastRecordToDate != null) {

			DateTime start1 = new DateTime(lastRecordToDate);
			DateTime end1 = new DateTime(currencyRateEntity.getEffectiveFromDate());

			Days diffInDays = Days.daysBetween(start1, end1);

			try {
				DateFormat format = new SimpleDateFormat(DATE_PATTERN, Locale.ENGLISH);
				Date date = format.parse(format.format(lastRecordToDate));
				if (diffInDays.getDays() > 1 || diffInDays.getDays() < 0) {

					LocalDateTime nextDay = LocalDateTime.fromDateFields(date).plusDays(1);

					throw new BusinessException(
							RATE + currencyRateEntity.getCurrencyRateType() + MISSINGPREVIOUSDAY + nextDay);
				}
			} catch (ParseException e) {
				log.error(CONTEXT + e);
				e.printStackTrace();
			}

		}

		currencyRateEntity.setLastUpdatedBy(lastUpdatedBy);
		currencyRateEntity.setLastUpdatedDate(java.time.LocalDateTime.now());
		currencyRateEntity.setIsActive(Boolean.TRUE);
		currencyRateDao.update(currencyRateEntity);

	}

	@Override
	public CurrencyRate copyCurrencyRate(CurrencyRate currencyRate, Date effectiveFromDate, Date effectiveToDate) {

		String rateType = OptionalUtil.getValue(currencyRate.getCurrencyRateType());
		String fromCode = OptionalUtil.getValue(currencyRate.getCurrencyFromCode());
		String toCode = OptionalUtil.getValue(currencyRate.getCurrencyToCode());
		BigDecimal exchangeRate =new BigDecimal(OptionalUtil.getValue(currencyRate.getExchangeRate()));

		if (effectiveFromDate == null) {
			throw new BusinessException("This field Effective From Date " + effectiveFromDate + CAN_NOT_BLANK);
		}

		if (effectiveToDate == null) {
			throw new BusinessException("This field Effective To Date " + effectiveToDate + CAN_NOT_BLANK);
		}

		Date copyFromDate = null;
		Date copyToDate = null;
		Date inputFromdate = null;
		Date inputTodate = null;

		try {
			DateFormat format = new SimpleDateFormat(DATE_PATTERN1, Locale.ENGLISH);
			copyFromDate = effectiveFromDate;
			copyToDate = effectiveToDate;
			inputFromdate = format.parse(format.format(currencyRate.getEffectiveFromDate()));
			inputTodate = format.parse(format.format(currencyRate.getEffectiveToDate()));

		} catch (ParseException e) {
			log.error(CONTEXT + e);
		}

		checkValidInputs(fromCode, toCode, inputFromdate, inputTodate, exchangeRate);

		boolean dateCheck = copyToDate.after(copyFromDate);

		boolean dateEqualCheck = copyToDate.equals(copyFromDate);

		if (!dateEqualCheck) {
			if (!dateCheck) {
				throw new BusinessException(
						EFFECTIVE_TO_DATE + copyToDate + GREATER_EFFECTIVE_FROM_DATE + copyFromDate);
			}
		}

		boolean copyFromDateCheck = copyFromDate.equals(inputFromdate);
		boolean copyToDateCheck = copyToDate.equals(inputTodate);

		if (copyFromDateCheck && copyToDateCheck) {
			throw new BusinessException(NOSAMEDATE);
		}

		int currencyRateCount = currencyRateRepository.checkCRRecord(rateType, fromCode, toCode);
		if (currencyRateCount == 0) {
			throw new BusinessException(NOCURRENCYRECORD + "Rate Type and Codes: " + fromCode + "&" + toCode);
		}

		int copyRecordCount = currencyRateRepository.verifyIfOverlapExits(convertLocalDate(copyFromDate),
				convertLocalDate(copyToDate), rateType, fromCode, toCode);

		if (copyRecordCount == 0) {
			throw new BusinessException(NOCURRENCYRECORD + rateType + CODES + fromCode + " & " + toCode
					+ DATEVALIDATION2 + copyFromDate + " & " + copyToDate);
		}
		if (copyRecordCount > 1) {
			throw new BusinessException(
					DATEVALIDATION1 + rateType + DATEVALIDATION2 + copyFromDate + " & " + copyToDate + DATEVALIDATION3);
		}

		int inActiveRecordCount = currencyRateRepository.checkSameInActiveRecord(rateType, fromCode, toCode,
				convertLocalDate(copyFromDate), convertLocalDate(copyToDate));
		if (inActiveRecordCount == 1) {
			throw new BusinessException(COPYDEACTIVATESTATE);
		}

		int inputInActiveRecordCount = currencyRateRepository.checkSameInActiveRecord(rateType, fromCode, toCode,
				convertLocalDate(inputFromdate), convertLocalDate(inputTodate));
		if (inputInActiveRecordCount == 1) {
			throw new BusinessException(COPYDEACTIVATESTATE);
		}

		int activeRecordCount = currencyRateRepository.checkSameActiveRecord(rateType, fromCode, toCode,
				convertLocalDate(inputFromdate), convertLocalDate(inputTodate));
		if (activeRecordCount == 1) {
			throw new BusinessException(COPYACTIVATESTATE);
		}

		overlapCheck(rateType, fromCode, toCode, inputFromdate, inputTodate); // input date overlap check

		checkLastRecord(rateType, fromCode, toCode, inputFromdate); // check for last record and gap between dates

		List<CurrencyRateEntity> currencyRateEntity = currencyRateRepository.geCurrencyRateEntities(rateType,
				convertLocalDate(copyFromDate), convertLocalDate(copyToDate), fromCode, toCode);

		if (!currencyRateEntity.isEmpty()) {
			for (int i = 0; i < currencyRateEntity.size(); i++) {
				currencyRate.setExchangeRate(Optional.of(String.valueOf(currencyRateEntity.get(i).getExchangeRate())));
			}
		}
		if (!currencyRateEntity.isEmpty()) {
			if (currencyRateEntity.size() > 1) {
				throw new BusinessException(DATEVALIDATION1 + currencyRate.getCurrencyRateType() + DATEVALIDATION2
						+ effectiveFromDate + " & " + effectiveToDate + DATEVALIDATION3);
			}
		}

		currencyRate.setIsActive(Boolean.TRUE);
		currencyRate.setCreatedDate(java.time.LocalDateTime.now());
		return currencyRateMapper.mapToModel(currencyRateRepository.save(currencyRateMapper.mapToEntity(currencyRate)));
	}

	@Override
	public CurrencyRate deriveCurrencyBKR(CurrencyRate currencyRate, Date effectiveFromDate, Date effectiveToDate) {

		String rateType = OptionalUtil.getValue(currencyRate.getCurrencyRateType());
		String fromCode = OptionalUtil.getValue(currencyRate.getCurrencyFromCode());
		String toCode = OptionalUtil.getValue(currencyRate.getCurrencyToCode());
		BigDecimal exchangeRate = new BigDecimal(OptionalUtil.getValue(currencyRate.getExchangeRate()));

		CurrencyRateType bkr = CurrencyRateType.BKR;

		if (!rateType.equals(bkr.getCurrencyRateType())) {
			throw new BusinessException("This field Currency Rate Type " + bkr.getCurrencyRateType() + CAN_NOT_BLANK);
		}

		if (effectiveFromDate == null) {
			throw new BusinessException("This field Effective From Date " + effectiveFromDate + CAN_NOT_BLANK);
		}

		if (effectiveToDate == null) {
			throw new BusinessException("This field Effective To Date " + effectiveToDate + CAN_NOT_BLANK);
		}

		Date copyFromDate = null;
		Date copyToDate = null;
		Date inputFromdate = null;
		Date inputTodate = null;

		try {
			DateFormat format = new SimpleDateFormat(DATE_PATTERN1, Locale.ENGLISH);
			copyFromDate = effectiveFromDate;
			copyToDate = effectiveToDate;
			inputFromdate = format.parse(format.format(currencyRate.getEffectiveFromDate()));
			inputTodate = format.parse(format.format(currencyRate.getEffectiveToDate()));

		} catch (ParseException e) {
			log.error(CONTEXT + e);
		}

		checkValidInputs(fromCode, toCode, inputFromdate, inputTodate, exchangeRate);

		boolean dateCheck = copyToDate.after(copyFromDate);
		boolean dateEqualCheck = copyToDate.equals(copyFromDate);

		if (!dateEqualCheck) {
			if (!dateCheck) {
				throw new BusinessException(
						EFFECTIVE_TO_DATE + copyToDate + GREATER_EFFECTIVE_FROM_DATE + copyFromDate);
			}
		}

		boolean copyFromDateCheck = copyFromDate.equals(inputFromdate);
		boolean copyToDateCheck = copyToDate.equals(inputTodate);

		if (copyFromDateCheck && copyToDateCheck) {
			throw new BusinessException(NOSAMEDATE);
		}

		int inputInActiveRecordCount = currencyRateRepository.checkSameInActiveRecord(rateType, fromCode, toCode,
				convertLocalDate(inputFromdate), convertLocalDate(inputTodate));
		if (inputInActiveRecordCount == 1) {
			throw new BusinessException(COPYDEACTIVATESTATE);
		}

		int activeRecordCount = currencyRateRepository.checkSameActiveRecord(rateType, fromCode, toCode,
				convertLocalDate(inputFromdate), convertLocalDate(inputTodate));
		if (activeRecordCount == 1) {
			throw new BusinessException(COPYACTIVATESTATE);
		}

		int copyRecordCount = currencyRateRepository.verifyIfOverlapExits(convertLocalDate(inputFromdate),
				convertLocalDate(inputTodate), rateType, fromCode, toCode);

		if (copyRecordCount >= 1) {
			throw new BusinessException(
					rateType + " is available for the period " + inputFromdate + " & " + inputTodate);
		}

		checkLastRecord(rateType, fromCode, toCode, inputFromdate); // check for last record and gap between dates

		String fdr = "FDR";
		String usd = "USD";
		BigDecimal fromExchangeRate = null;
		BigDecimal toExchangeRate = null;
		// FDR - fromCode & USD
		List<CurrencyRateEntity> currencyRateFromCodeEntity = currencyRateRepository.geCurrencyRateEntities(fdr,
				convertLocalDate(copyFromDate), convertLocalDate(copyToDate), fromCode, usd);

		if (currencyRateFromCodeEntity.isEmpty()) {
			throw new BusinessException(NOCURRENCYRECORD + fdr + CODES + fromCode + " & " + usd + DATEVALIDATION2
					+ copyFromDate + " & " + copyToDate);
		}

		if (!currencyRateFromCodeEntity.isEmpty()) {
			if (currencyRateFromCodeEntity.size() > 1) {
				throw new BusinessException(DATEVALIDATION1 + rateType + DATEVALIDATION2 + copyFromDate + " & "
						+ copyToDate + DATEVALIDATION3);
			}
			for (int i = 0; i < currencyRateFromCodeEntity.size(); i++) {
				fromExchangeRate = currencyRateFromCodeEntity.get(i).getExchangeRate();
			}
		}

		// FDR - toCode & USD
		List<CurrencyRateEntity> currencyRateToCodeEntity = currencyRateRepository.geCurrencyRateEntities(fdr,
				convertLocalDate(copyFromDate), convertLocalDate(copyToDate), toCode, usd);

		if (currencyRateToCodeEntity.isEmpty()) {
			throw new BusinessException(NOCURRENCYRECORD + fdr + CODES + toCode + " & " + usd + DATEVALIDATION2
					+ copyFromDate + " & " + copyToDate);
		}

		if (!currencyRateToCodeEntity.isEmpty()) {
			if (currencyRateToCodeEntity.size() > 1) {
				throw new BusinessException(DATEVALIDATION1 + rateType + DATEVALIDATION2 + copyFromDate + " & "
						+ copyToDate + DATEVALIDATION3);
			}
			for (int i = 0; i < currencyRateToCodeEntity.size(); i++) {
				toExchangeRate = currencyRateToCodeEntity.get(i).getExchangeRate();
			}
		}

		Double deriveExchangeRate = (toExchangeRate.doubleValue() / fromExchangeRate.doubleValue());

		DecimalFormat df = new DecimalFormat(".########");
		deriveExchangeRate = Double.parseDouble(df.format(deriveExchangeRate));
		currencyRate.setExchangeRate(Optional.of(String.valueOf(deriveExchangeRate)));

		currencyRate.setIsActive(Boolean.TRUE);
		currencyRate.setCreatedDate(java.time.LocalDateTime.now());
		return currencyRateMapper.mapToModel(currencyRateRepository.save(currencyRateMapper.mapToEntity(currencyRate)));
	}

	@Override
	public CurrencyRate getEffectiveCurrencyRate(String currencyRateType, String currencyFromCode,
			String currencyToCode, Date effectiveDate) {
		CurrencyRateEntity currencyRateEntity;

		if (currencyRateType != null && currencyFromCode != null && currencyToCode != null && effectiveDate != null) {
			currencyRateEntity = currencyRateRepository.getEffectiveCurrencyRate(currencyRateType, currencyFromCode,
					currencyToCode, convertLocalDate(effectiveDate));
			if (currencyRateEntity != null) {
				return currencyRateMapper.mapToModel(currencyRateEntity);
			} else {
				throw new BusinessException(NOCURRENCYRECORD + currencyRateType + DATEVALIDATION2 + effectiveDate);
			}

		} else {
			throw new BusinessException(NOCURRENCYRECORD + currencyRateType + DATEVALIDATION2 + effectiveDate);
		}
	}

	@Override
	public List<CurrencyRateEntity> deriveBKRFromFDR(String effectiveDate, String currencyCode) {
		DateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN1);
		BigDecimal exchangeRate2 = null;
		Date fromDate = null;
		Date toDate = null;
		CurrencyRate currencyRate = null;
		List<CurrencyRateEntity> currencyRateList = null;

		currencyRateList = new ArrayList<>();
		currencyRate = new CurrencyRate();

		int year = Integer.parseInt(effectiveDate.substring(3));
		int month = Integer.parseInt(effectiveDate.substring(0, 2));

		// validation for date format
		SimpleDateFormat formatter = new SimpleDateFormat("MM/yyyy");
		java.util.Date date = null;
		try {
			date = formatter.parse(effectiveDate);
		} catch (ParseException e) {
			throw new BusinessException(EFFECTIVE_DATE);
		}
		List<CurrencyRateEntity> currencyEntities = currencyRateRepository.getBKRFromFDR(month, year, currencyCode);
		if (currencyEntities.isEmpty()) {
			throw new BusinessException("No record found for Currency Type : FDR and Codes: " + currencyCode
					+ " with Effective Date : " + effectiveDate);
		}
		// system parameter validation
		String parameterRangeFrom = null;
		List<SystemParameter> systemParameterByparameterName = masterFeignClient
				.getSystemParameterByparameterName("DEFAULT_CURRENCY_CODE");
		if (systemParameterByparameterName.isEmpty()) {
			throw new BusinessException("Default currency code not available");
		}
		if (!systemParameterByparameterName.get(0).getIsActive()) {
			throw new BusinessException("Default currency code is not active");
		}
		for (SystemParameter systemParameter : systemParameterByparameterName) {
			parameterRangeFrom = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
		}
		ArrayList<String> currencyFromCodeList = new ArrayList<>();
		for (int i = 0; i < currencyEntities.size(); i++) {
			CurrencyRateEntity currencyRateEntity2 = currencyEntities.get(i);
			boolean equalsIgnoreCase = currencyRateEntity2.getCurrencyFromCode().equalsIgnoreCase(parameterRangeFrom);
			String currencyFromCode = currencyRateEntity2.getCurrencyFromCode();
			if (!currencyRateEntity2.getCurrencyFromCode().isEmpty() && !currencyFromCode.equals(parameterRangeFrom)) {// .equalsIgnoreCase("INR")
				currencyFromCodeList.add(currencyFromCode);
			}
			if (equalsIgnoreCase) {
				exchangeRate2 = currencyRateEntity2.getExchangeRate();
			}
		}
		CurrencyRateEntity mapToCurrencyRateModel = null;
		String currencyFromCode = null;
		Double exc = null;
		Integer flag = 0;
		for (Iterator<String> iterator = currencyFromCodeList.iterator(); iterator.hasNext();) {
			currencyFromCode = (String) iterator.next();
			List<BigDecimal> fromCodeByExchange = currencyRateRepository.getCurrencyFromCodeByExchangeRate(month, year,
					currencyFromCode, currencyCode);
			if (fromCodeByExchange.size() > 1) {
				throw new BusinessException("Two records found with same effective periods and default currency code "
						+ parameterRangeFrom);
			}
			BigDecimal fromCodeByExchangeRate = currencyRateRepository.getCurrencyFromCodeByExcRate(month, year,
					currencyFromCode, currencyCode);
			try {
				exc = (exchangeRate2.doubleValue() / fromCodeByExchangeRate.doubleValue());
			} catch (NullPointerException e) {
				throw new BusinessException("FDR Record not found with default currency code : " + parameterRangeFrom);
			}
			String createdByFDR = currencyRateRepository.getCreatedByFDR(month, year, currencyFromCode, currencyCode);
			currencyRate.setCurrencyRateType(Optional.of("BKR"));
			currencyRate.setCreatedBy(Optional.of(createdByFDR));
			currencyRate.setCurrencyFromCode(Optional.of(currencyFromCode));
			currencyRate.setExchangeRate(Optional.of(String.valueOf(exc)));
			currencyRate.setIsActive(Boolean.TRUE);
			currencyRate.setCreatedDate(java.time.LocalDateTime.now());
			currencyRate.setCurrencyToCode(Optional.of(parameterRangeFrom));
			try {
				deriveMonthFirstAndLastDate simpleDate = new deriveMonthFirstAndLastDate();
				Date date1 = new SimpleDateFormat("MM/yyyy").parse(effectiveDate);
				fromDate = new SimpleDateFormat("yyyy/MM/dd").parse(simpleDate.getFirstDay(date1));
				toDate = new SimpleDateFormat("yyyy/MM/dd").parse(simpleDate.getLastDay(date1));
			} catch (Exception e) {
				log.error(CONTEXT + e);
			}
			currencyRate.setEffectiveFromDate(Optional.of(dateFormat.format(fromDate)));
			currencyRate.setEffectiveToDate(Optional.of(dateFormat.format(toDate)));

			int verifyIfOverlapExits = currencyRateRepository.verifyIfOverlapExits(convertLocalDate(fromDate),
					convertLocalDate(toDate), "BKR", currencyFromCode, parameterRangeFrom);
			if (verifyIfOverlapExits <= 0) {
				mapToCurrencyRateModel = currencyRateRepository.save(currencyRateMapper.mapToEntity(currencyRate));
				currencyRateList.add(mapToCurrencyRateModel);
				flag++;
			}
		}

		if (flag == 0) {
			throw new BusinessException("Record already exists");
		}
		return currencyRateList;
	}

	public Date convertDate(java.time.LocalDate localDate) {
		if (localDate != null) {
			return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		} else {
			return null;
		}
	}

	public java.time.LocalDate convertLocalDate(Date date) {
		if (date != null) {
			return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		} else {
			return null;
		}
	}

	private void validateOverlapForUpdate(CurrencyRate currencyRate, CurrencyRateEntity currencyRateEntity) {
		if (currencyRateDao.getOverLapRecordCount(OptionalUtil.getValue(currencyRate.getCurrencyRateType()),
				OptionalUtil.getLocalDateValue(currencyRate.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(currencyRate.getEffectiveToDate()),
				currencyRateEntity.getCurrencyRateId(), OptionalUtil.getValue(currencyRate.getCurrencyFromCode()),
				OptionalUtil.getValue(currencyRate.getCurrencyToCode())) != 0) {
			throw new BusinessException(DATEVALIDATION1 + OptionalUtil.getValue(currencyRate.getCurrencyRateType())
					+ DATEVALIDATION2 + OptionalUtil.getLocalDateValue(currencyRate.getEffectiveFromDate()) + ","
					+ OptionalUtil.getLocalDateValue(currencyRate.getEffectiveToDate()) + "&"
					+ OptionalUtil.getValue(currencyRate.getCurrencyFromCode()) + "&"
					+ OptionalUtil.getValue(currencyRate.getCurrencyToCode()) + DATEVALIDATION3);

		}
	}

	protected void validateExchangeRate(CurrencyRate currencyRate) {
		Boolean operationCheck = false;
		if (OptionalUtil.isPresent(currencyRate.getExchangeRate())) {
			String exchangeRate = OptionalUtil.getValue(currencyRate.getExchangeRate());
			operationCheck = Pattern.compile("^[0-9]\\d{0,11}(\\.\\d{1,8})?%?$").matcher(exchangeRate).find();
			if (!operationCheck) {
				throw new BusinessException("Exchange Rate should be of 20,8 format");
			}
		}
	}

	private void checkEffectiveFromEqualsEffectiveTo(CurrencyRate currencyRate, CurrencyRateEntity currencyRateEntity) {
		if (!currencyRateEntity.getEffectiveToDate()
				.equals(OptionalUtil.getLocalDateValue(currencyRate.getEffectiveToDate()))) {
			if (currencyRateDao.checkEffectiveFromEqualsEffectiveTo(
					OptionalUtil.getValue(currencyRate.getCurrencyRateType()),
					currencyRateEntity.getEffectiveToDate().plusDays(1), currencyRateEntity.getCurrencyRateId(),
					OptionalUtil.getValue(currencyRate.getCurrencyFromCode()),
					OptionalUtil.getValue(currencyRate.getCurrencyToCode())) != 0) {
				throw new BusinessException(EFFECTIVE_FROM_DATE_ON_UPDATE);

			}
		}

	}

}
