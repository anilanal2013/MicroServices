package com.sgl.smartpra.currency.app.mapper;

import org.mapstruct.factory.Mappers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperFactory {

	/*
	 * @Bean public CurrencyRateMapper getCurrencyRateMapper() { return
	 * Mappers.getMapper(CurrencyRateMapper.class); }
	 */

}