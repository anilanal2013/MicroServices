package com.sgl.smartpra.currency.app.configuration;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.sgl.smartpra.master.model.SystemParameter;


@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-global-master-app")
	public interface GlobalMasterFeignClient {

		@GetMapping("/currencies/{currencyCode}/validate")
		public boolean validateCurrencyCode(@PathVariable(value = "currencyCode") String currencyCode);
	}

	@FeignClient(value = "smartpra-batch-global-app")
	public interface GlobalBatchFeignClient {

		@GetMapping("/inboundFileLogs/{inboundFileId}/validate")
		public boolean validateInboundFileId(@PathVariable(value = "inboundFileId") Integer inboundFileId);
	}

	@FeignClient(value = "smartpra-master-app")
	public interface MasterFeignClient {

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(
				@PathVariable(value = "parameterName") String parameterName);
		}
	}


