package com.sgl.smartpra.currency.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.currency.app.dao.CurrencyRateDao;
import com.sgl.smartpra.currency.app.dao.entity.CurrencyRateEntity;
import com.sgl.smartpra.currency.app.dao.entity.spec.CurrencyRateEntitySpecification;
import com.sgl.smartpra.currency.app.dao.repository.CurrencyRateRepository;
import com.sgl.smartpra.currency.model.CurrencyRate;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CurrencyRateDaoImpl extends CommonSearchDao<CurrencyRate> implements CurrencyRateDao {

	@Autowired
	private CurrencyRateRepository currencyRateRepository;

	@Override
	@Cacheable(value = "currencyRate", key = "#id")
	public Optional<CurrencyRateEntity> findById(Integer id) {
		log.info("Cacheable CurrecnyRate Entity's ID= {}", id);
		return currencyRateRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "currencyRate", key = "#currencyRateEntity.currencyRateId"),
			@CacheEvict(value = "currencyRateSearch", allEntries = true) })
	public CurrencyRateEntity create(CurrencyRateEntity currencyRateEntity) {
		return currencyRateRepository.save(currencyRateEntity);
	}

	@Override
	@CachePut(value = "currencyRate", key = "#currencyRateEntity.currencyRateId")
	@CacheEvict(value = "currencyRateSearch", allEntries = true)
	public CurrencyRateEntity update(CurrencyRateEntity currencyRateEntity) {
		return currencyRateRepository.save(currencyRateEntity);
	}

	@Override
	public List<CurrencyRateEntity> search(Optional<String> currencyRateType, Optional<String> currencyFromCode,
			Optional<String> currencyToCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> isActive) {
		return currencyRateRepository.findAll(CurrencyRateEntitySpecification.search(currencyRateType, currencyFromCode,
				currencyToCode, effectiveFromDate, effectiveToDate, isActive));
	}

	@Override
	public long getOverLapRecordCount(String currencyRateType, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			Integer currencyRateId, String currencyFromCode, String currencyToCode) {
		return currencyRateRepository.count(Specification
				.where(CurrencyRateEntitySpecification.equalsCurrencyRateType(currencyRateType))
				.and(CurrencyRateEntitySpecification.equalsCurrencyFromCode(currencyFromCode))
				.and(CurrencyRateEntitySpecification.equalsCurrencyToCode(currencyToCode))
				.and(CurrencyRateEntitySpecification.notEqualsCurrencyRateId(currencyRateId))
				.and(CurrencyRateEntitySpecification.betweenEffectiveFromDateAndEffectiveToDate(effectiveFromDate)
				.or(CurrencyRateEntitySpecification.betweenEffectiveFromDateAndEffectiveToDate(effectiveToDate))));
	}

	@Override
	public long checkEffectiveFromEqualsEffectiveTo(String currencyRateType, LocalDate effectiveToDate, Integer currencyRateId,
			String currencyFromCode, String currencyToCode) {
		return currencyRateRepository
				.count(Specification.where(CurrencyRateEntitySpecification.equalsCurrencyRateType(currencyRateType))
						.and(CurrencyRateEntitySpecification.equalsCurrencyFromCode(currencyFromCode))
						.and(CurrencyRateEntitySpecification.equalsCurrencyToCode(currencyToCode))
						.and(CurrencyRateEntitySpecification.equalsEffectiveFromDate(effectiveToDate))
						.and(CurrencyRateEntitySpecification.notEqualsCurrencyRateId(currencyRateId)));
	}

}
