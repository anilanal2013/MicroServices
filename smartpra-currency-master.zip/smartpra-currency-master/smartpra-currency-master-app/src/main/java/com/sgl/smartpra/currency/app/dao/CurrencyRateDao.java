package com.sgl.smartpra.currency.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.currency.app.dao.entity.CurrencyRateEntity;

public interface CurrencyRateDao {

	public Optional<CurrencyRateEntity> findById(Integer id);

	public CurrencyRateEntity create(CurrencyRateEntity currencyRateEntity);

	public CurrencyRateEntity update(CurrencyRateEntity currencyRateEntity);

	public List<CurrencyRateEntity> search(Optional<String> currencyRateType, Optional<String> currencyFromCode,
			Optional<String> currencyToCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> isActive);
	
	public long getOverLapRecordCount(String currencyRateType,LocalDate effectiveFromDate, LocalDate effectiveToDate, Integer currencyRateId, String currencyFromCode,
			String currencyToCode);
	
	public long checkEffectiveFromEqualsEffectiveTo(String currencyRateType, LocalDate effectiveToDate,
			Integer currencyRateId, String currencyFromCode, String currencyToCode);
}
