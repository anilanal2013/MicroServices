package com.sgl.smartpra.currency.app.dao.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.currency.app.dao.entity.CurrencyRateEntity;

@Repository
public interface CurrencyRateRepository
		extends JpaRepository<CurrencyRateEntity, Integer>, JpaSpecificationExecutor<CurrencyRateEntity> {

	@Query(value = "select count(*) from CurrencyRateEntity d where "
			+ " (((?1 between d.effectiveFromDate and d.effectiveToDate) or "
			+ "(?2 between d.effectiveFromDate and d.effectiveToDate)) or "
			+ " (d.effectiveFromDate >=?1 and d.effectiveToDate<=?2 )) and "
			+ " d.currencyRateType = ?3 and d.currencyFromCode =?4 and d.currencyToCode =?5 and d.isActive = TRUE")
	int verifyIfOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate, String currencyRateType,
			String currencyFromCode, String currencyToCode);
	
	@Query(value = "select count(*) from CurrencyRateEntity d where "
			+ " (((?1 between d.effectiveFromDate and d.effectiveToDate) or "
			+ "(?2 between d.effectiveFromDate and d.effectiveToDate)) or "
			+ " (d.effectiveFromDate >=?1 and d.effectiveToDate<=?2 )) and "
			+ " d.currencyRateType = ?3 and d.currencyFromCode =?4 and d.currencyToCode =?5 and d.currencyRateId !=?6 and d.isActive = TRUE")
	int verifyIfOverlapExitsForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, String currencyRateType,
			String currencyFromCode, String currencyToCode, Integer currencyRateId);

	@Query(value = "select count(*) from CurrencyRateEntity d where "
			+ " ((?1 between d.effectiveFromDate and d.effectiveToDate) or "
			+ "(?2 between d.effectiveFromDate and d.effectiveToDate) or"
			+ " (d.effectiveFromDate >= ?1 and d.effectiveToDate<= ?2 )) "
			+ " and d.currencyRateType = ?3 and d.currencyFromCode =?4 and d.currencyToCode =?5 and d.isActive = TRUE")
	int verifyRecordExits(LocalDate effectiveFromDate, LocalDate effectiveToDate, String currencyRateType,
			String currencyFromCode, String currencyToCode);

	@Query("SELECT effectiveToDate from CurrencyRateEntity c where  c.currencyRateType =?1 and "
			+ " c.currencyFromCode =?2 and c.currencyToCode =?3 and c.isActive = TRUE and "
			+ " c.effectiveToDate = (SELECT MAX(effectiveToDate)  FROM CurrencyRateEntity d "
			+ "where d.currencyRateType =?1 and d.currencyFromCode =?2 and d.currencyToCode =?3 and d.isActive = TRUE)")
	LocalDate checkLastRecord(String currencyRateType, String currencyFromCode, String currencyToCode);

	@Query(value = "SELECT COUNT(*) from CurrencyRateEntity  c where  c.currencyRateType =?1 "
			+ " AND c.currencyFromCode =?2 and c.currencyToCode =?3  "
			+ " and c.effectiveFromDate =?4 and c.effectiveToDate =?5 and  c.isActive= FALSE ")
	int checkSameInActiveRecord(String currencyRateType, String currencyFromCode, String currencyToCode,
			LocalDate effectiveFromDate, LocalDate effectiveToDate);

	@Query(value = "select min(c.effectiveFromDate) from CurrencyRateEntity c where "
			+ "c.currencyRateType=?1 and c.currencyFromCode=?2 and c.currencyToCode=?3 and c.isActive=TRUE ")
	LocalDate checkFirstRecordDate(String currencyRateType, String currencyFromCode, String currencyToCode);

	@Query(value = "SELECT c FROM CurrencyRateEntity c WHERE (((?2 between c.effectiveFromDate and c.effectiveToDate) "
			+ " or (?3 between c.effectiveFromDate and c.effectiveToDate)) or "
			+ " (c.effectiveFromDate>=?2 and c.effectiveToDate<=?3)) and c.currencyRateType=?1 and c.currencyFromCode=?4 "
			+ " and c.currencyToCode=?5 and c.isActive=TRUE ")
	List<CurrencyRateEntity> geCurrencyRateEntities(String currencyRateType, LocalDate effectiveFromDate,
			LocalDate effectiveToDate, String currencyFromCode, String currencyToCode);

	@Query(value = "SELECT COUNT(*) from CurrencyRateEntity  c where  c.currencyRateType =?1 "
			+ " AND c.currencyFromCode =?2 and c.currencyToCode =?3  "
			+ " and c.effectiveFromDate =?4 and c.effectiveToDate =?5 and  c.isActive= TRUE ")
	int checkSameActiveRecord(String currencyRateType, String currencyFromCode, String currencyToCode,
			LocalDate effectiveFromDate, LocalDate effectiveToDate);

	@Query(value = "SELECT COUNT(*) from CurrencyRateEntity  c where  c.currencyRateType =?1 "
			+ " AND c.currencyFromCode =?2 and c.currencyToCode =?3  and  c.isActive= TRUE ")
	int checkCRRecord(String currencyRateType, String currencyFromCode, String currencyToCode);

	@Query(value = "select a from CurrencyRateEntity a  where "
			+ "((:effectiveDate between a.effectiveFromDate  AND a.effectiveToDate) "
			+ " or (a.effectiveFromDate >=:effectiveDate and a.effectiveToDate <=:effectiveDate )) "
			+ "AND a.currencyRateType =:currencyRateType AND a.currencyFromCode =:currencyFromCode AND a.currencyToCode =:currencyToCode"
			+ " AND a.isActive = TRUE")
	public CurrencyRateEntity getEffectiveCurrencyRate(@Param("currencyRateType") String currencyRateType,
			@Param("currencyFromCode") String currencyFromCode, @Param("currencyToCode") String currencyToCode,
			@Param("effectiveDate") LocalDate effectiveDate);

	@Query(value = "select b from CurrencyRateEntity b where"
			+ " ((?1 between b.effectiveFromDate and b.effectiveToDate) or "
			+ " (?2 between b.effectiveFromDate and b.effectiveToDate)) and b.currencyRateType=?3 and b.isActive =TRUE")
	List<CurrencyRateEntity> getCurrencyEntities(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String currencyRateType);

	@Query(value = "select exchangeRate from CurrencyRateEntity b where MONTH(effective_from_date) =?1 and YEAR(effective_from_date) =?2 and b.currencyFromCode=?3 and currency_to_code =?4 and b.currencyRateType='FDR' and b.isActive = TRUE ")
	List<BigDecimal> getCurrencyFromCodeByExchangeRate(int month, int year, String currencyFromCode,String currencyCode);

	@Query(value = "select exchangeRate from CurrencyRateEntity b where MONTH(effective_from_date) =?1 and YEAR(effective_from_date) =?2 and b.currencyFromCode=?3 and currency_to_code =?4 and b.currencyRateType='FDR' and b.isActive = TRUE ")
	BigDecimal getCurrencyFromCodeByExcRate(int month, int year, String currencyFromCode,String currencyCode);

	@Query(value = "select b from CurrencyRateEntity b where MONTH(effective_from_date) =?1 and YEAR(effective_from_date) =?2 and currency_to_code =?3 AND currency_rate_type='FDR' and b.isActive = TRUE")
	List<CurrencyRateEntity> getBKRFromFDR(int month, int year,String currencyCode);

	@Query(value = "select createdBy from CurrencyRateEntity b where MONTH(effective_from_date) =?1 and YEAR(effective_from_date) =?2 and b.currencyFromCode=?3 and currency_to_code =?4 and b.currencyRateType='FDR' and b.isActive = TRUE ")
	String getCreatedByFDR(int month, int year, String currencyFromCode,String currencyCode);

}
