package com.sgl.smartpra.currency.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
@Table(name = "global_mas_currency_rate")
public class CurrencyRateEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "currency_rate_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer currencyRateId;

	@Column(name = "currency_rate_type", nullable = false)
	private String currencyRateType;

	@Column(name = "exchange_rate", nullable = false, scale = 20, precision = 8)
	private BigDecimal exchangeRate;

	@Column(name = "currency_from_code", nullable = false)
	private String currencyFromCode;

	@Column(name = "currency_to_code", nullable = false)
	private String currencyToCode;

	@Column(name = "effective_from_date", nullable = false)
	// @Temporal(TemporalType.DATE)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	// @Temporal(TemporalType.DATE)
	private LocalDate effectiveToDate;

	@Column(name = "inbound_file_id", nullable = false)
	private Integer inboundFileId;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
