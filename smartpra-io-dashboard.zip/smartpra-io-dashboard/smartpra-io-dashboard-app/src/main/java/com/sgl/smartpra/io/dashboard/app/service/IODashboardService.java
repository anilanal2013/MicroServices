package com.sgl.smartpra.io.dashboard.app.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.sgl.smartpra.io.dashboard.model.filedetails.ErroneousFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.MultiRecordExceptions;
import com.sgl.smartpra.io.dashboard.model.filedetails.PartiallyTransferredFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.TechnicallyFailedFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.TransferredFileDetails;
import com.sgl.smartpra.io.dashboard.model.filestatus.FileStatus;
import com.sgl.smartpra.io.dashboard.model.query.IODashboardQuery;

public interface IODashboardService {

	public FileStatus getFileStatus(IODashboardQuery ioDashboardQuery);

	public List<ErroneousFileDetails> getErroneousFileDetails(IODashboardQuery ioDashboardQuery);

	public List<TransferredFileDetails> getTransferredFileDetails(IODashboardQuery ioDashboardQuery);

	public List<PartiallyTransferredFileDetails> getPartiallyTransferredFileDetails(IODashboardQuery ioDashboardQuery);

	public List<TechnicallyFailedFileDetails> getTechnicallyFailedFileDetails(IODashboardQuery ioDashboardQuery);

	public List<MultiRecordExceptions> getMultiRecordExceptions(IODashboardQuery ioDashboardQuery);
	
	ResponseEntity<List<String>> getBatchFilesDetails(String module,String fileType);
}
