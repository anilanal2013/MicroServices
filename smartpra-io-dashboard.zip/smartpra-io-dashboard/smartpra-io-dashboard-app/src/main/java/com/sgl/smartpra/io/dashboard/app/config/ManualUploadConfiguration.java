package com.sgl.smartpra.io.dashboard.app.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ManualUploadConfiguration {

    @Value("${batch.directory.sales.bsp.input}")
    private String bspInputDir;

    @Value("${batch.directory.sales.arc.input}")
    private String arcInputDir;
    
    @Value("${batch.directory.sales.amadeus.input}")
    private String salesAmadeusInputDir;    

    @Value("${batch.directory.flown.amadeus.input}")
    private String amadeusInputDir;

    @Value("${batch.directory.miscbilling.isxml.input}")
    private String miscBillingDir;

    @Value("${batch.directory.interline.idec.input}")
    private String interlineIdecDir;


    @Value("${batch.directory.interline.form3.input}")
    private String interlineForm3Dir;

    public void setMiscBillingDir(String miscBillingDir) {
        this.miscBillingDir = miscBillingDir;
    }

    public String getInterlineIdecDir() {
        return interlineIdecDir;
    }

    public void setInterlineIdecDir(String interlineIdecDir) {
        this.interlineIdecDir = interlineIdecDir;
    }

    public String getInterlineForm3Dir() {
        return interlineForm3Dir;
    }

    public void setInterlineForm3Dir(String interlineForm3Dir) {
        this.interlineForm3Dir = interlineForm3Dir;
    }

    public String getBspInputDir() {
        return bspInputDir;
    }

    public String getArcInputDir() {
        return arcInputDir;
    }


    public String getAmadeusInputDir() {
        return amadeusInputDir;
    }

    public String getMiscBillingDir() {
        return miscBillingDir;
    }

	public String getSalesAmadeusInputDir() {
		return salesAmadeusInputDir;
	}


}
