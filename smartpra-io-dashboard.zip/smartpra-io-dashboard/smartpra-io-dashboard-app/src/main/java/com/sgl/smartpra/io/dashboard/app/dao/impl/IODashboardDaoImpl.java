package com.sgl.smartpra.io.dashboard.app.dao.impl;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.global.app.dao.result.ExpectedFrequencyResult;
import com.sgl.smartpra.batch.global.app.dao.result.FileStatusResult;
import com.sgl.smartpra.batch.global.app.dao.result.MultiRecordExceptionsResult;
import com.sgl.smartpra.batch.global.app.entity.FileLoggingEntity;
import com.sgl.smartpra.batch.global.app.repository.FileLogRepository;
import com.sgl.smartpra.io.dashboard.app.dao.IODashboardDao;

@Component
public class IODashboardDaoImpl implements IODashboardDao {

	@Autowired
	private FileLogRepository fileLogRepository;

	@Override
	public List<FileStatusResult> getFileStatus(LocalDate fromDate, LocalDate toDate) {
		return fileLogRepository.getFileLogStatus(fromDate, toDate);
	}

	@Override
	public List<FileLoggingEntity> getFileDetails(LocalDate fromDate, LocalDate toDate, Integer lovModuleId,
			String fileStatus) {
		return fileLogRepository.getFileDetails(toTimestamp(fromDate), toTimestamp(toDate), lovModuleId, fileStatus);
	}

	private static Timestamp toTimestamp(LocalDate localDate) {
		Date date = Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		return new Timestamp(date.getTime());
	}

	@Override
	public ExpectedFrequencyResult getExpectedFrequencyAndModuleName(String source, Integer lovModuleId) {
		return fileLogRepository.getExpectedFrequencyAndModuleNameResult(source, lovModuleId);
	}

	@Override
	public List<MultiRecordExceptionsResult> getMultiRecordExceptions(Integer fileLogId) {
		return fileLogRepository.getMultiRecordExceptions(fileLogId);
	}
}
