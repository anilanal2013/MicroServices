package com.sgl.smartpra.io.dashboard.app.dao;

import java.time.LocalDate;
import java.util.List;

import com.sgl.smartpra.batch.global.app.dao.result.ExpectedFrequencyResult;
import com.sgl.smartpra.batch.global.app.dao.result.FileStatusResult;
import com.sgl.smartpra.batch.global.app.dao.result.MultiRecordExceptionsResult;
import com.sgl.smartpra.batch.global.app.entity.FileLoggingEntity;

public interface IODashboardDao {

	public List<FileStatusResult> getFileStatus(LocalDate fromDate, LocalDate toDate);
	
	public List<FileLoggingEntity> getFileDetails(LocalDate fromDate, LocalDate toDate, Integer lovModuleId, String fileStatus);
	
	public ExpectedFrequencyResult getExpectedFrequencyAndModuleName(String source, Integer lovModuleId);
	
	public List<MultiRecordExceptionsResult> getMultiRecordExceptions(Integer fileLogId);

}
