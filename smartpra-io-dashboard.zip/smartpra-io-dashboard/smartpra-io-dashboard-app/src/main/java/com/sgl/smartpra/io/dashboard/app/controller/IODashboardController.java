package com.sgl.smartpra.io.dashboard.app.controller;

import java.time.YearMonth;
import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.io.dashboard.app.service.IODashboardService;
import com.sgl.smartpra.io.dashboard.exception.mgmt.ManualAssignmentSearch;
import com.sgl.smartpra.io.dashboard.exception.mgmt.ManualAssignmentSearchResult;
import com.sgl.smartpra.io.dashboard.model.filedetails.ErroneousFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.MultiRecordExceptions;
import com.sgl.smartpra.io.dashboard.model.filedetails.PartiallyTransferredFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.TechnicallyFailedFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.TransferredFileDetails;
import com.sgl.smartpra.io.dashboard.model.filestatus.FileStatus;
import com.sgl.smartpra.io.dashboard.model.query.IODashboardQuery;

@RestController
@RequestMapping("/in-interface")
public class IODashboardController {

	@Autowired
	private IODashboardService ioDashboardService;

	@GetMapping("/getFileStatusByDate")
	public FileStatus getFileStatusByDates(
			@RequestParam(name = "fromDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> fromDate,
			@RequestParam(name = "toDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> toDate) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		ioDashboardQuery.setFromDate(fromDate);
		ioDashboardQuery.setToDate(toDate);
		return ioDashboardService.getFileStatus(ioDashboardQuery);
	}

	@GetMapping("/getFileStatusByMonth")
	public FileStatus getFileStatusByMonth(
			@RequestParam(name = "month", required = true) @NotNull @Range(min = 1, max = 12) Integer month,
			@RequestParam(name = "year", required = true) @NotNull @Size(min = 4, max = 4) Integer year) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		YearMonth yearMonth = YearMonth.of(year, month);
		ioDashboardQuery.setFromDate(Optional.of(yearMonth.atDay(1).toString()));
		ioDashboardQuery.setToDate(Optional.of(yearMonth.atEndOfMonth().toString()));
		return ioDashboardService.getFileStatus(ioDashboardQuery);
	}

	@GetMapping("/erroneous/getFileDetailsByDate")
	public List<ErroneousFileDetails> getErroneousFileDetailsByDate(
			@RequestParam(name = "fromDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> fromDate,
			@RequestParam(name = "toDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> toDate,
			@RequestParam(name = "lovModuleId", required = true) @RequiredNotEmpty Optional<Integer> lovModuleId) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		ioDashboardQuery.setFromDate(fromDate);
		ioDashboardQuery.setToDate(toDate);
		ioDashboardQuery.setLovModuleId(lovModuleId);
		return ioDashboardService.getErroneousFileDetails(ioDashboardQuery);
	}

	@GetMapping("/erroneous/getFileDetailsByMonth")
	public List<ErroneousFileDetails> getErroneousFileDetailsByMonth(
			@RequestParam(name = "month", required = true) @NotNull @Range(min = 1, max = 12) Integer month,
			@RequestParam(name = "year", required = true) @NotNull @Size(min = 4, max = 4) Integer year,
			@RequestParam(name = "lovModuleId", required = true) @RequiredNotEmpty Optional<Integer> lovModuleId) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		YearMonth yearMonth = YearMonth.of(year, month);
		ioDashboardQuery.setFromDate(Optional.of(yearMonth.atDay(1).toString()));
		ioDashboardQuery.setToDate(Optional.of(yearMonth.atEndOfMonth().toString()));
		ioDashboardQuery.setLovModuleId(lovModuleId);
		return ioDashboardService.getErroneousFileDetails(ioDashboardQuery);
	}

	@GetMapping("/transferred/getFileDetailsByDate")
	public List<TransferredFileDetails> getTransferredFileDetailsByDate(
			@RequestParam(name = "fromDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> fromDate,
			@RequestParam(name = "toDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> toDate,
			@RequestParam(name = "lovModuleId", required = true) @RequiredNotEmpty Optional<Integer> lovModuleId) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		ioDashboardQuery.setFromDate(fromDate);
		ioDashboardQuery.setToDate(toDate);
		ioDashboardQuery.setLovModuleId(lovModuleId);
		return ioDashboardService.getTransferredFileDetails(ioDashboardQuery);
	}

	@GetMapping("/transferred/getFileDetailsByMonth")
	public List<TransferredFileDetails> getTransferredFileDetailsByMonth(
			@RequestParam(name = "month", required = true) @NotNull @Range(min = 1, max = 12) Integer month,
			@RequestParam(name = "year", required = true) @NotNull @Size(min = 4, max = 4) Integer year,
			@RequestParam(name = "lovModuleId", required = true) @RequiredNotEmpty Optional<Integer> lovModuleId) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		YearMonth yearMonth = YearMonth.of(year, month);
		ioDashboardQuery.setFromDate(Optional.of(yearMonth.atDay(1).toString()));
		ioDashboardQuery.setToDate(Optional.of(yearMonth.atEndOfMonth().toString()));
		ioDashboardQuery.setLovModuleId(lovModuleId);
		return ioDashboardService.getTransferredFileDetails(ioDashboardQuery);
	}

	@GetMapping("/partiallyTransferred/getFileDetailsByDate")
	public List<PartiallyTransferredFileDetails> getPartiallyTransferredFileDetailsByDate(
			@RequestParam(name = "fromDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> fromDate,
			@RequestParam(name = "toDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> toDate,
			@RequestParam(name = "lovModuleId", required = true) @RequiredNotEmpty Optional<Integer> lovModuleId) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		ioDashboardQuery.setFromDate(fromDate);
		ioDashboardQuery.setToDate(toDate);
		ioDashboardQuery.setLovModuleId(lovModuleId);
		return ioDashboardService.getPartiallyTransferredFileDetails(ioDashboardQuery);
	}

	@GetMapping("/partiallyTransferred/getFileDetailsByMonth")
	public List<PartiallyTransferredFileDetails> getPartiallyTransferredFileDetailsByMonth(
			@RequestParam(name = "month", required = true) @NotNull @Range(min = 1, max = 12) Integer month,
			@RequestParam(name = "year", required = true) @NotNull @Size(min = 4, max = 4) Integer year,
			@RequestParam(name = "lovModuleId", required = true) @RequiredNotEmpty Optional<Integer> lovModuleId) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		YearMonth yearMonth = YearMonth.of(year, month);
		ioDashboardQuery.setFromDate(Optional.of(yearMonth.atDay(1).toString()));
		ioDashboardQuery.setToDate(Optional.of(yearMonth.atEndOfMonth().toString()));
		ioDashboardQuery.setLovModuleId(lovModuleId);
		return ioDashboardService.getPartiallyTransferredFileDetails(ioDashboardQuery);
	}

	@GetMapping("/technicallyFailed/getFileDetailsByDate")
	public List<TechnicallyFailedFileDetails> getTechnicallyFailedFileDetailsByDate(
			@RequestParam(name = "fromDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> fromDate,
			@RequestParam(name = "toDate", required = true) @RequiredNotEmpty @DateFormat(pattern = "yyyy-MM-dd") Optional<String> toDate,
			@RequestParam(name = "lovModuleId", required = true) @RequiredNotEmpty Optional<Integer> lovModuleId) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		ioDashboardQuery.setFromDate(fromDate);
		ioDashboardQuery.setToDate(toDate);
		ioDashboardQuery.setLovModuleId(lovModuleId);
		return ioDashboardService.getTechnicallyFailedFileDetails(ioDashboardQuery);
	}

	@GetMapping("/technicallyFailed/getFileDetailsByMonth")
	public List<TechnicallyFailedFileDetails> getTechnicallyFailedFileDetailsByMonth(
			@RequestParam(name = "month", required = true) @NotNull @Range(min = 1, max = 12) Integer month,
			@RequestParam(name = "year", required = true) @NotNull @Size(min = 4, max = 4) Integer year,
			@RequestParam(name = "lovModuleId", required = true) @RequiredNotEmpty Optional<Integer> lovModuleId) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		YearMonth yearMonth = YearMonth.of(year, month);
		ioDashboardQuery.setFromDate(Optional.of(yearMonth.atDay(1).toString()));
		ioDashboardQuery.setToDate(Optional.of(yearMonth.atEndOfMonth().toString()));
		ioDashboardQuery.setLovModuleId(lovModuleId);
		return ioDashboardService.getTechnicallyFailedFileDetails(ioDashboardQuery);
	}

	@GetMapping("/getMultiRecordExceptions")
	public List<MultiRecordExceptions> getMultiRecordExceptions(
			@RequestParam(name = "fileLogId", required = true) @RequiredNotEmpty Optional<Integer> fileLogId) {
		IODashboardQuery ioDashboardQuery = new IODashboardQuery();
		ioDashboardQuery.setFileLogId(fileLogId);
		return ioDashboardService.getMultiRecordExceptions(ioDashboardQuery);
	}

	@PostMapping("/searchExceptions")
	public ManualAssignmentSearchResult searchExceptions(@RequestBody ManualAssignmentSearch manualAssignmentSearch) {
		System.out.println(manualAssignmentSearch);
		System.out.println(manualAssignmentSearch.getSeverity());
		return null;
	}
	
	@GetMapping("/geManulUploadFileDetails")
	public ResponseEntity<List<String>> geManulUploadFileDetails(
			@RequestParam(name = "module", required = true) String module, @RequestParam(name = "fileType", required = true) String fileType) {
		return ioDashboardService.getBatchFilesDetails(module, fileType);
	}
}
