package com.sgl.smartpra.io.dashboard.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.batch.global.app.dao.result.MultiRecordExceptionsResult;
import com.sgl.smartpra.batch.global.app.entity.FileLoggingEntity;
import com.sgl.smartpra.io.dashboard.model.filedetails.ErroneousFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.MultiRecordExceptions;
import com.sgl.smartpra.io.dashboard.model.filedetails.PartiallyTransferredFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.TechnicallyFailedFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.TransferredFileDetails;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface IODashboardMapper {

	@Mapping(source = "fileLoggingEntity.fileId", target = "fileLogId")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "uploadDate")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "receivedDate")
	@Mapping(source = "fileLoggingEntity.processedBy", target = "user")
	@Mapping(source = "fileLoggingEntity.source", target = "source")
	@Mapping(source = "fileLoggingEntity.totalCounts", target = "loadingSummary.numberOfPhysicalRecords")
	@Mapping(source = "fileLoggingEntity.detailCounts", target = "loadingSummary.numberOfActualRecords")
	@Mapping(source = "fileLoggingEntity.transferredCounts", target = "loadingSummary.numberOfTransferredRecords")
	@Mapping(source = "fileLoggingEntity.errorCounts", target = "loadingSummary.numberOfErrorRecords")
	public ErroneousFileDetails mapToErroneousFileDetails(FileLoggingEntity fileLoggingEntity);

	public List<ErroneousFileDetails> mapToErroneousFileDetails(List<FileLoggingEntity> fileLoggingEntityList);

	@Mapping(source = "fileLoggingEntity.fileId", target = "fileLogId")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "uploadDate")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "receivedDate")
	@Mapping(source = "fileLoggingEntity.processedBy", target = "user")
	@Mapping(source = "fileLoggingEntity.source", target = "source")
	public TechnicallyFailedFileDetails mapToTechnicallyFailedFileDetails(FileLoggingEntity fileLoggingEntity);

	public List<TechnicallyFailedFileDetails> mapToTechnicallyFailedFileDetails(
			List<FileLoggingEntity> fileLoggingEntityList);

	@Mapping(source = "fileLoggingEntity.fileId", target = "fileLogId")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "uploadDate")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "transferredDate")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "reportedDate")
	@Mapping(source = "fileLoggingEntity.processedBy", target = "user")
	@Mapping(source = "fileLoggingEntity.source", target = "source")
	@Mapping(source = "fileLoggingEntity.totalCounts", target = "loadingSummary.numberOfPhysicalRecords")
	@Mapping(source = "fileLoggingEntity.detailCounts", target = "loadingSummary.numberOfActualRecords")
	@Mapping(source = "fileLoggingEntity.transferredCounts", target = "loadingSummary.numberOfTransferredRecords")
	public TransferredFileDetails mapToTransferredFileDetails(FileLoggingEntity fileLoggingEntity);

	@Mapping(source = "fileLoggingEntity.fileId", target = "fileLogId")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "uploadDate")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "transferredDate")
	@Mapping(source = "fileLoggingEntity.createdDate", target = "reportedDate")
	@Mapping(source = "fileLoggingEntity.processedBy", target = "user")
	@Mapping(source = "fileLoggingEntity.source", target = "source")
	@Mapping(source = "fileLoggingEntity.totalCounts", target = "loadingSummary.numberOfPhysicalRecords")
	@Mapping(source = "fileLoggingEntity.detailCounts", target = "loadingSummary.numberOfActualRecords")
	@Mapping(source = "fileLoggingEntity.transferredCounts", target = "loadingSummary.numberOfTransferredRecords")
	@Mapping(source = "fileLoggingEntity.errorCounts", target = "loadingSummary.numberOfErrorRecords")
	@Mapping(source = "fileLoggingEntity.remarks", target = "loadingException")
	public PartiallyTransferredFileDetails mapToPartiallyTransferredFileDetails(FileLoggingEntity fileLoggingEntity);

	public List<MultiRecordExceptions> mapToMultiRecordExceptions(List<MultiRecordExceptionsResult> multiRecordExceptionsResult);
}
