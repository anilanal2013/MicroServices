package com.sgl.smartpra.io.dashboard.app.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.sgl.smartpra.batch.global.app.dao.result.ExpectedFrequencyResult;
import com.sgl.smartpra.batch.global.app.dao.result.FileStatusResult;
import com.sgl.smartpra.batch.global.app.entity.FileLoggingEntity;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.io.dashboard.app.config.ManualUploadConfiguration;
import com.sgl.smartpra.io.dashboard.app.dao.IODashboardDao;
import com.sgl.smartpra.io.dashboard.app.mapper.IODashboardMapper;
import com.sgl.smartpra.io.dashboard.app.service.IODashboardService;
import com.sgl.smartpra.io.dashboard.model.filedetails.ErroneousFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.MultiRecordExceptions;
import com.sgl.smartpra.io.dashboard.model.filedetails.PartiallyTransferredFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.TechnicallyFailedFileDetails;
import com.sgl.smartpra.io.dashboard.model.filedetails.TransferredFileDetails;
import com.sgl.smartpra.io.dashboard.model.filestatus.FileStatus;
import com.sgl.smartpra.io.dashboard.model.filestatus.ModulewiseFileStatus;
import com.sgl.smartpra.io.dashboard.model.filestatus.StatusCount;
import com.sgl.smartpra.io.dashboard.model.query.IODashboardQuery;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class IODashboardServiceImpl implements IODashboardService {

    @Autowired
    private IODashboardDao ioDashboardDao;

    @Autowired
    private IODashboardMapper ioDashboardMapper;

    @Autowired
    ManualUploadConfiguration manualUploadConfiguration;

    private static final String ERRONEOUS = "ER";

    private static final String TECHNICALLY_FAILED = "TF";

    private static final String PARTIALLY_TRANSFERRED = "PT";

    private static final String TRANSFERRED = "TR";

    private static final String FLOWN = "FLOWN";

    private static final String SALES = "SALES";

    private static final String SALE = "SALE";

    private static final String INTERLINE = "INTERLINE";

    private static final String BSP_FILE = "BSP";

    private static final String ARC_FILE = "ARC";
    
    private static final String SALES_AMADEUS_FILE = "AMADEUS";

    private static final String AMADEUS_FILE = "AMADEUS";

    private static final String IDEC = "IDEC";

    private static final String FORM3 = "FORM3";

    private static final String ISXML = "ISXML";

    private static final String MISC_BILLING = "MISCBILLING";

    private static final String MISCBILLING = "MISCELLANEOUS";


    @Override
    public FileStatus getFileStatus(IODashboardQuery ioDashboardQuery) {
        return mapToFileStatus(
                ioDashboardDao.getFileStatus(OptionalUtil.getLocalDateValue(ioDashboardQuery.getFromDate()),
                        OptionalUtil.getLocalDateValue(ioDashboardQuery.getToDate())));
    }

    @Override
    public List<ErroneousFileDetails> getErroneousFileDetails(IODashboardQuery ioDashboardQuery) {
        return ioDashboardMapper.mapToErroneousFileDetails(
                ioDashboardDao.getFileDetails(OptionalUtil.getLocalDateValue(ioDashboardQuery.getFromDate()),
                        OptionalUtil.getLocalDateValue(ioDashboardQuery.getToDate()),
                        OptionalUtil.getValue(ioDashboardQuery.getLovModuleId()), ERRONEOUS));
    }

    @Override
    public List<TechnicallyFailedFileDetails> getTechnicallyFailedFileDetails(IODashboardQuery ioDashboardQuery) {
        return ioDashboardMapper.mapToTechnicallyFailedFileDetails(
                ioDashboardDao.getFileDetails(OptionalUtil.getLocalDateValue(ioDashboardQuery.getFromDate()),
                        OptionalUtil.getLocalDateValue(ioDashboardQuery.getToDate()),
                        OptionalUtil.getValue(ioDashboardQuery.getLovModuleId()), TECHNICALLY_FAILED));
    }

    @Override
    public List<PartiallyTransferredFileDetails> getPartiallyTransferredFileDetails(IODashboardQuery ioDashboardQuery) {
        List<FileLoggingEntity> fileLoggingEntityList = ioDashboardDao.getFileDetails(
                OptionalUtil.getLocalDateValue(ioDashboardQuery.getFromDate()),
                OptionalUtil.getLocalDateValue(ioDashboardQuery.getToDate()),
                OptionalUtil.getValue(ioDashboardQuery.getLovModuleId()), PARTIALLY_TRANSFERRED);
        List<PartiallyTransferredFileDetails> partiallyTransferredFileDetailsList = new ArrayList<>();
        fileLoggingEntityList.forEach(fileLoggingEntity -> {
            PartiallyTransferredFileDetails partiallyTransferredFileDetails = ioDashboardMapper
                    .mapToPartiallyTransferredFileDetails(fileLoggingEntity);
            ExpectedFrequencyResult expectedFrequencyAndModuleNameResult = ioDashboardDao
                    .getExpectedFrequencyAndModuleName(fileLoggingEntity.getSource(), fileLoggingEntity.getModuleId());
            if (expectedFrequencyAndModuleNameResult != null) {
                partiallyTransferredFileDetails
                        .setExpectedFrequency(expectedFrequencyAndModuleNameResult.getExpectedFrequency());
                partiallyTransferredFileDetails.setModule(expectedFrequencyAndModuleNameResult.getModuleName());
            }
            partiallyTransferredFileDetailsList.add(partiallyTransferredFileDetails);
        });
        return partiallyTransferredFileDetailsList;
    }

    @Override
    public List<TransferredFileDetails> getTransferredFileDetails(IODashboardQuery ioDashboardQuery) {
        List<FileLoggingEntity> fileLoggingEntityList = ioDashboardDao.getFileDetails(
                OptionalUtil.getLocalDateValue(ioDashboardQuery.getFromDate()),
                OptionalUtil.getLocalDateValue(ioDashboardQuery.getToDate()),
                OptionalUtil.getValue(ioDashboardQuery.getLovModuleId()), TRANSFERRED);
        List<TransferredFileDetails> transferredFileDetailsList = new ArrayList<>();
        fileLoggingEntityList.forEach(fileLoggingEntity -> {
            TransferredFileDetails transferredFileDetails = ioDashboardMapper
                    .mapToTransferredFileDetails(fileLoggingEntity);
            ExpectedFrequencyResult expectedFrequencyAndModuleNameResult = ioDashboardDao
                    .getExpectedFrequencyAndModuleName(fileLoggingEntity.getSource(), fileLoggingEntity.getModuleId());
            if (expectedFrequencyAndModuleNameResult != null) {
                transferredFileDetails
                        .setExpectedFrequency(expectedFrequencyAndModuleNameResult.getExpectedFrequency());
                transferredFileDetails.setModule(expectedFrequencyAndModuleNameResult.getModuleName());
            }
            transferredFileDetailsList.add(transferredFileDetails);
        });
        return transferredFileDetailsList;
    }

    @Override
    public List<MultiRecordExceptions> getMultiRecordExceptions(IODashboardQuery ioDashboardQuery) {
        return ioDashboardMapper.mapToMultiRecordExceptions(
                ioDashboardDao.getMultiRecordExceptions(OptionalUtil.getValue(ioDashboardQuery.getFileLogId())));
    }

    private FileStatus mapToFileStatus(List<FileStatusResult> fileStatusResultList) {
        FileStatus fileStatus = new FileStatus();
        if (fileStatusResultList != null && !fileStatusResultList.isEmpty()) {
            for (FileStatusResult fileStatusResult : fileStatusResultList) {
                ModulewiseFileStatus modulewiseFileStatus = getModulewiseFileStatus(fileStatus,
                        fileStatusResult.getFieldShortDesc());
                modulewiseFileStatus.setModuleLovId(fileStatusResult.getLovModuleId());
                mapStatusCount(modulewiseFileStatus, fileStatusResult.getStatusType(),
                        fileStatusResult.getStatusCount());
                setModulewiseFileStatus(fileStatus, fileStatusResult.getFieldShortDesc(), modulewiseFileStatus);
            }
        }
        return fileStatus;

    }

    private void setModulewiseFileStatus(FileStatus fileStatus, String moduleName,
                                         ModulewiseFileStatus modulewiseFileStatus) {
        switch (moduleName.toUpperCase()) {
            case FLOWN:
                fileStatus.setUplift(modulewiseFileStatus);
                break;
            case SALES:
                fileStatus.setSales(modulewiseFileStatus);
                break;
            case SALE:
                fileStatus.setSales(modulewiseFileStatus);
                break;
            case INTERLINE:
                fileStatus.setInterline(modulewiseFileStatus);
                break;
            case MISCBILLING:
                fileStatus.setMiscellaneous(modulewiseFileStatus);
            default:
                fileStatus.setOthers(modulewiseFileStatus);
                break;
        }
    }

    private ModulewiseFileStatus getModulewiseFileStatus(FileStatus fileStatus, String moduleName) {
        switch (moduleName.toUpperCase()) {
            case FLOWN:
                return fileStatus.getUplift() != null ? fileStatus.getUplift() : new ModulewiseFileStatus();
            case SALES:
                return fileStatus.getSales() != null ? fileStatus.getSales() : new ModulewiseFileStatus();
            case SALE:
                return fileStatus.getSales() != null ? fileStatus.getSales() : new ModulewiseFileStatus();
            case INTERLINE:
                return fileStatus.getInterline() != null ? fileStatus.getInterline() : new ModulewiseFileStatus();
            case MISCBILLING:
                return fileStatus.getMiscellaneous() != null ? fileStatus.getMiscellaneous() : new ModulewiseFileStatus();
            default:
                return fileStatus.getOthers() != null ? fileStatus.getOthers() : new ModulewiseFileStatus();
        }
    }

    private void mapStatusCount(ModulewiseFileStatus modulewiseFileStatus, String statusType, Integer count) {
        StatusCount statusCount = new StatusCount();
        statusCount.setStatusType(statusType);
        statusCount.setCount(count);
        if (ERRONEOUS.equalsIgnoreCase(statusType)) {
            modulewiseFileStatus.setErroneous(statusCount);
        } else if (TECHNICALLY_FAILED.equalsIgnoreCase(statusType)) {
            modulewiseFileStatus.setTechnicallyFailed(statusCount);
        } else if (PARTIALLY_TRANSFERRED.equalsIgnoreCase(statusType)) {
            modulewiseFileStatus.setPartiallyTransferred(statusCount);
        } else if (TRANSFERRED.equalsIgnoreCase(statusType)) {
            modulewiseFileStatus.setTransferred(statusCount);
        }
    }

    @Override
    public ResponseEntity<List<String>> getBatchFilesDetails(String module, String fileType) {
        log.info("========================================" + module + "========" + fileType);
        String fileDir = null;
        List<String> fileNameList = null;
        MultiValueMap<String, String> errorMessage = new LinkedMultiValueMap<>();
        if (module.equalsIgnoreCase(SALES) && fileType.equalsIgnoreCase(BSP_FILE)) {
            log.info("=======================BspInputDir=================" + manualUploadConfiguration.getBspInputDir());
            fileDir = manualUploadConfiguration.getBspInputDir();

        } else if (module.equalsIgnoreCase(SALES) && fileType.equalsIgnoreCase(ARC_FILE)) {
            System.out.println("=======================ArcInputDir=================" + manualUploadConfiguration.getArcInputDir());
            fileDir = manualUploadConfiguration.getArcInputDir();

        } else if (module.equalsIgnoreCase(FLOWN) && fileType.equalsIgnoreCase(AMADEUS_FILE)) {
            System.out.println("=======================AmadeusInputDir=================" + manualUploadConfiguration.getAmadeusInputDir());
            fileDir = manualUploadConfiguration.getAmadeusInputDir();

        } else if (module.equalsIgnoreCase(MISC_BILLING) && fileType.equalsIgnoreCase(ISXML)) {
            log.info("=======================MiscBillingDir=================" + manualUploadConfiguration.getMiscBillingDir());
            fileDir = manualUploadConfiguration.getMiscBillingDir();

        } else if (module.equalsIgnoreCase(INTERLINE) && fileType.equalsIgnoreCase(IDEC)) {
            System.out.println("=======================InterlineIdec=================" + manualUploadConfiguration.getInterlineIdecDir());
            fileDir = manualUploadConfiguration.getInterlineIdecDir();

        } else if (module.equalsIgnoreCase(INTERLINE) && fileType.equalsIgnoreCase(FORM3)) {
            log.info("=======================InterlineForm3=================" + manualUploadConfiguration.getInterlineForm3Dir());
            fileDir = manualUploadConfiguration.getInterlineForm3Dir();
        } else {
            errorMessage.add("Module or File type ", "Given Module  " + module + "  and/or File type " + fileType + "  are invalid or not configured yet for IO dashboard, contact DEV team");
        }
        if (fileDir != null && !fileDir.isEmpty()) {
            File folder = new File(fileDir);
            File[] listOfFiles = folder.listFiles();
            if (listOfFiles != null && listOfFiles.length > 0) {
                fileNameList = new ArrayList<>();
                for (File file : listOfFiles) {
                    if (file.isFile()) {
                        fileNameList.add(file.getName());
                        System.out.println(file.getName());
                    }
                }
            } else {

                errorMessage.add("No file", "No Files presents in this foler please the check respective input folder " + fileDir);
            }
        } else {
            errorMessage.add("Invlid File path", "Please create input folder with this structure: " + fileDir);
        }
        if (fileNameList != null) {
            return new ResponseEntity<>(fileNameList, errorMessage, HttpStatus.OK);
        } else {
            fileNameList = new ArrayList<>();
            return new ResponseEntity<>(fileNameList, errorMessage, HttpStatus.OK);
        }

    }

}
