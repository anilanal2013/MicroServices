package com.sgl.smartpra.io.dashboard.model.query;

import java.util.Optional;

import lombok.Data;

@Data
public class IODashboardQuery {

	private Optional<String> fromDate;
	
	private Optional<String> toDate;
	
	private Optional<Integer> lovModuleId;
	
	private Optional<String> statusType; 
	
	private Optional<Integer> fileLogId;
	
}
