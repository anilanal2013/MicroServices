package com.sgl.smartpra.io.dashboard.model.filedetails;

import java.io.Serializable;

import lombok.Data;

@Data
public class MultiRecordExceptions implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer fileLogId;
	
	private String errorDescription;

	private String cause;

	private String action;

	private String complexity;

	private Integer resolutionEffort;
	
	private Integer recordNumber;
}
