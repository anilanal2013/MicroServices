package com.sgl.smartpra.io.dashboard.exception.mgmt;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonTypeName;

import lombok.Data;
import lombok.EqualsAndHashCode;

@JsonTypeName("flown")
@Data
@EqualsAndHashCode(callSuper=false)
public class FlownSearch extends ManualAssignmentSearch{

	private LocalDate flightDatePeriod;

	private String flightNumberRange;

	private String fromRegion;

	private String toRegion;
}
