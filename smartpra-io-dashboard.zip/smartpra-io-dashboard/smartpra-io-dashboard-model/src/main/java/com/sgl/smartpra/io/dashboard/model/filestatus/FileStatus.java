package com.sgl.smartpra.io.dashboard.model.filestatus;

import java.io.Serializable;

import lombok.Data;

@Data
public class FileStatus implements Serializable{

	private static final long serialVersionUID = 1L;

	private ModulewiseFileStatus sales;

	private ModulewiseFileStatus uplift;

	private ModulewiseFileStatus interline;

	private ModulewiseFileStatus others;

	private ModulewiseFileStatus miscellaneous;

}
