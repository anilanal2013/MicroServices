package com.sgl.smartpra.io.dashboard.model.filedetails;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PartiallyTransferredFileDetails extends TransferredFileDetails {

	private static final long serialVersionUID = 1L;

	private String loadingException;
}
