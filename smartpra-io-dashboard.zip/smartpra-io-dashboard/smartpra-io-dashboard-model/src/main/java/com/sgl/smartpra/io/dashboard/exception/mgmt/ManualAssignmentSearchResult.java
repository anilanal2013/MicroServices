package com.sgl.smartpra.io.dashboard.exception.mgmt;

import java.io.Serializable;

import lombok.Data;

@Data
public class ManualAssignmentSearchResult implements Serializable {

	private static final long serialVersionUID = 1L;

	private String issueAirline;

	private String airlineType;

	private String countryCode;

	private String exceptionCode;

	private String exceptionType;

	private String ticketNumber;

	private String exceptionDesc;

	private int aging;
}
