package com.sgl.smartpra.io.dashboard.model.filedetails;

import java.io.Serializable;

import lombok.Data;

@Data
public class LoadingSummary implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer numberOfPhysicalRecords;

	private Integer numberOfActualRecords;

	private Integer numberOfTransferredRecords;

	private Integer numberOfRejectedRecords;

	private Integer numberOfErrorRecords;

}
