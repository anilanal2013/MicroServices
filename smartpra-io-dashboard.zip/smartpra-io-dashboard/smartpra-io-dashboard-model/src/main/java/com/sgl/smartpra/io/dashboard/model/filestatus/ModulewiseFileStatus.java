package com.sgl.smartpra.io.dashboard.model.filestatus;

import java.io.Serializable;

import lombok.Data;

@Data
public class ModulewiseFileStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer moduleLovId;

//	private StatusCount expected;
//
//	private StatusCount outstanding;

	private StatusCount erroneous;

	private StatusCount transferred;

	private StatusCount partiallyTransferred;

	private StatusCount technicallyFailed;

}
