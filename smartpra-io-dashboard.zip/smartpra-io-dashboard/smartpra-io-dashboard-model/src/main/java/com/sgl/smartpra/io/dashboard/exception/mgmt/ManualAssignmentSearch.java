package com.sgl.smartpra.io.dashboard.exception.mgmt;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;

import lombok.Data;

@Data
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = As.PROPERTY)
@JsonSubTypes({ @JsonSubTypes.Type(value = SaleSearch.class, name = "sale"),
		@JsonSubTypes.Type(value = FlownSearch.class, name = "flown") })
public abstract class ManualAssignmentSearch {

	private int moduleLovId;

	private String severity;

	private LocalDate fromDate;

	private LocalDate toDate;

	private int aging;

}
