package com.sgl.smartpra.io.dashboard.model.filedetails;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ErroneousFileDetails extends FileDetails {

	private static final long serialVersionUID = 1L;

	private String source;

	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate receivedDate;

	private String user;

	private LoadingSummary loadingSummary;

}
