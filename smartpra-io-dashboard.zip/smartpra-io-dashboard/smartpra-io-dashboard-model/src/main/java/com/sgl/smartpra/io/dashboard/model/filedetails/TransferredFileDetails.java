package com.sgl.smartpra.io.dashboard.model.filedetails;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class TransferredFileDetails extends FileDetails {

	private static final long serialVersionUID = 1L;

	private String module;

	private String expectedFrequency;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate transferredDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate reportedDate;

	private LoadingSummary loadingSummary;

}
