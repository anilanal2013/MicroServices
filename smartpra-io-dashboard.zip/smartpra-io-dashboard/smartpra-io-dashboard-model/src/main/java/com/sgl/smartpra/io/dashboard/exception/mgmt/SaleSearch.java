package com.sgl.smartpra.io.dashboard.exception.mgmt;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonTypeName;

import lombok.Data;
import lombok.EqualsAndHashCode;

@JsonTypeName("sale")
@Data
@EqualsAndHashCode(callSuper=false)
public class SaleSearch extends ManualAssignmentSearch {

	private LocalDate issuePeriod;

	private LocalDate reportingPeriod;

	private String reportingAgency;

	private String saleAgency;

	private String placeOfSale;
}
