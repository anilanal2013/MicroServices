package com.sgl.smartpra.io.dashboard.model.filedetails;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class FileDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer fileLogId;

	private String fileName;

	private String fileType;
	
	private String source;
	
	private String user;

	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate uploadDate;

}
