package com.sgl.smartpra.job.scheduler.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class JobDetailsModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer jobId;

	private String clientId;

	private String jobName;

	private String jobType;

	private String moduleName;

	private String category;

	private String frequency;

	private Integer delay;
	
	private Integer sequence;

	private String parameter1;

	private String parameter2;

	private String parameter3;

	private String parameter4;

	private Boolean skipIndicator;
	
	private Boolean timeLimitIndicator;
	
	private Boolean rollingDisplayIndicator;

	private String effectiveFromDate;

	private String effectiveToDate;

	private String lastUpdatedBy;

	private LocalDateTime createdDate;

	private LocalDateTime lastUpdatedDate;
	
	private Integer estimatedTime;
	
	private Integer stream;
	
	private String url;
}
