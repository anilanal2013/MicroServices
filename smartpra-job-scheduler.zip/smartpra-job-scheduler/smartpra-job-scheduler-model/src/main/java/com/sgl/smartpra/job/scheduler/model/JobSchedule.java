package com.sgl.smartpra.job.scheduler.model;

import lombok.Data;

@Data
public class JobSchedule {
	
	private String jobName;
	
	private String nextFire;
	
	private String clientId;

	private String jobType;

	private String moduleName;

	private String category;

	private String frequency;

	private Integer delay;
	
	private Integer sequence;
	
}
