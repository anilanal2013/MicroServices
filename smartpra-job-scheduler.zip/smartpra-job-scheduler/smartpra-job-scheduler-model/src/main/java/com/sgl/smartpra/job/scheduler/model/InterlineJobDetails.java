package com.sgl.smartpra.job.scheduler.model;

import java.util.Map;

import lombok.Data;

@Data
public class InterlineJobDetails {
	String jobName;
	Map<String, String> jobParams;
}
