package com.sgl.smartpra.job.scheduler.app.config;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.sgl.smartpra.job.scheduler.app.job.QuartzJob;

@Configuration
public class JobSchedulerQuartzConfig {
	
	@Value("${spring.datasource.url}")
	private String dataSourceUrl;
	
	@Value("${spring.datasource.driverClassName}")
	private String dataSourceDriver;

	@Bean
	public JobDetail jobDetail() {
		JobDataMap jobDataMap = new JobDataMap();
		jobDataMap.put("jobName", "backGroundJob");

		return JobBuilder.newJob(QuartzJob.class).withIdentity("backGroundJob").setJobData(jobDataMap).storeDurably()
				.build();
	}

	@Bean
	public Trigger jobTrigger() {

		CronScheduleBuilder cronScheduleBuilder = CronScheduleBuilder.cronSchedule("0 30 6 1/1 * ? *");
		//CronScheduleBuilder cronScheduleBuilder = CronScheduleBuilder.cronSchedule(generateDailyCronExp());
		return TriggerBuilder.newTrigger().forJob(jobDetail()).withIdentity("backGroundJobTrigger")
				.withSchedule(cronScheduleBuilder).build();
	}

	@Bean
	public SchedulerFactoryBean schedulerFactoryBean() throws IOException {
		SchedulerFactoryBean scheduler = new SchedulerFactoryBean();
		scheduler.setTriggers(jobTrigger());
		scheduler.setQuartzProperties(quartzProperties());
		scheduler.setJobDetails(jobDetail());
		scheduler.setApplicationContextSchedulerContextKey("applicationContext");
		return scheduler;
	}

	@Bean
	public Properties quartzProperties() throws IOException {
		//PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
		//propertiesFactoryBean.setLocation(new ClassPathResource("/quartz.properties"));
		//propertiesFactoryBean.afterPropertiesSet();
		//return propertiesFactoryBean.getObject();
		
		Properties prop = new Properties();
		prop.put("org.quartz.threadPool.threadCount", "50");
		prop.put("quartz.scheduler.instanceName", "JobScheduler");
		prop.put("org.quartz.jobStore.class", "org.quartz.impl.jdbcjobstore.JobStoreTX");
		prop.put("org.quartz.jobStore.driverDelegateClass", "org.quartz.impl.jdbcjobstore.StdJDBCDelegate");
		prop.put("org.quartz.jobStore.dataSource", "quartzDataSource");
		prop.put("org.quartz.jobStore.tablePrefix", getTablePrefix());
		prop.put("org.quartz.jobStore.isClustered", "false");
		prop.put("org.quartz.dataSource.quartzDataSource.driver", dataSourceDriver);
		prop.put("org.quartz.dataSource.quartzDataSource.URL", getDataSource());
		prop.put("org.quartz.dataSource.quartzDataSource.user", dataSourceUrl.split("user=")[1].split(";")[0]);
		prop.put("org.quartz.dataSource.quartzDataSource.password", dataSourceUrl.split("password=")[1]);
		prop.put("org.quartz.dataSource.quartzDataSource.maxConnections", "10");
		return prop;
		
	}

	private String generateDailyCronExp() {
		final Calendar rightNow = Calendar.getInstance();
		rightNow.add(Calendar.MINUTE, 2);
		String format = new SimpleDateFormat("MMM").format(rightNow.getTime());
		return String.format("%1$s %2$s %3$s %4$s %5$s %6$s %7$s", rightNow.get(Calendar.SECOND),
				rightNow.get(Calendar.MINUTE), rightNow.get(Calendar.HOUR_OF_DAY), rightNow.get(Calendar.DAY_OF_MONTH),
				format.toUpperCase(), "?", rightNow.get(Calendar.YEAR));
	}
	
	private String getTablePrefix() {
		return dataSourceUrl.split("instanceName=")[1].split(";")[0] + ".SmartPRAGlobalBatch.QRTZ_";
	}
	
	private String getDataSource() {
		return dataSourceUrl.split("1433")[0] + "1433";
	}
}