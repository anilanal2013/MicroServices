package com.sgl.smartpra.job.scheduler.app.config;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.accounting.model.AccountingSummarization;
import com.sgl.smartpra.accounting.model.AccountingSummarizationInput;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.job.scheduler.model.InterlineJobDetails;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Configuration
public class FeignConfiguration {

	//@FeignClient(value = "smartpra-batch-bsp", url="http://10.245.240.45:8060/smartpra/bsp-batch")
	@FeignClient(value = "smartpra-batch-bsp")
	public interface BatchBSPFeignClient {
		@RequestMapping("/bsp/processFile/scheduler")
		public String processBSP(@RequestParam("clientId") String clientId);
	}

	//@FeignClient(value = "smartpra-batch-arc", url="http://10.245.240.45:8060/smartpra/arc-batch")
	@FeignClient(value = "smartpra-batch-arc")
	public interface BatchARCFeignClient {
		@RequestMapping("/arc/processFile/scheduler")
		public String processARC(@RequestParam("clientId") String clientId);
	}

	//@FeignClient(value = "smartpra-batch-sales-amadeus", url="http://10.245.240.45:8060/smartpra/sales-amadeus-batch")
	@FeignClient(value = "smartpra-batch-sales-amadeus")
	public interface BatchSalesAmadeusFeignClient {
		@RequestMapping("/salesAmadeus/processFile/scheduler")
		public String processSalesAmadeus(@RequestParam("clientId") String clientId);
	}
	
	@FeignClient(value = "smartpra-sales-service")
	public interface BatchSalesServiceFeignClient {
		@RequestMapping("/salesProration/transactionType")
		public Map<String, Set<String>> getTransactionTypeDocuments(@RequestParam(value = "fromDate") String fromDate,
				@RequestParam(value = "toDate") String toDate, @RequestParam(value = "clientId") String clientId);
	}

	@FeignClient(value = "smartpra-master-app")
	public interface MasterFeignClient {
		@RequestMapping("/job/with-effective-date")
		public List<JobDetailsModel> getAllActiveJob(@RequestParam("effectiveFromDate") String effectiveFromDate);
		
		@RequestMapping("/job/{jobId}")
		public JobDetailsModel findByJobId(@PathVariable(value = "jobId") Integer jobId); 
		
		@PutMapping("/job/{jobId}")
		public JobDetailsModel updateJob(@PathVariable(value = "jobId") Integer jobId,
				@RequestBody @Validated(Update.class) JobDetailsModel job);
	}

	//@FeignClient(value = "smartpra-batch-interline-app", url="http://10.245.240.45:8060/smartpra/interline-batch")
	@FeignClient(value = "smartpra-batch-interline-app")
	public interface BatchInterlineFeingClient {
		@RequestMapping("/invokejob/{clientId}/form3StgTransferJob")
		public String invokeForm3Job(@PathVariable("clientId") String clientId);

		@RequestMapping("/invokejob/{clientId}/idecStgTransferJob")
		public String invokeIdecJob(@PathVariable("clientId") String clientId);

		@PostMapping("/invokeBatchjob")
		public String invokeBatchJob(@RequestBody InterlineJobDetails jobDetails);
	}

	@FeignClient(value = "smartpra-batch-amadeus")
	public interface BatchAmadeusFeignClient {
		@RequestMapping("/invokejob")
		public String invokeAmadeusJob(@RequestParam("inboundFileName") String inboundFileName);
	}

	@FeignClient(value = "smartpra-batch-flight-bhr")
	public interface BatchFlightBHRFeignClient {
		@RequestMapping("/flightBhrInFile/version/{version}/invokejob")
		public String invokeBhrJob(@PathVariable("version") String version, @RequestParam("fileName") String fileName);

		@RequestMapping("/fligt-reco/invoke-job")
		public String invokeRecoJob(@RequestParam("fileName") String fileName);

	}

	@FeignClient(value = "smartpra-batch-oneworld")
	public interface BatchOneWorldFeignClient {
		@RequestMapping("/codeshare/invokejob")
		public String invokeCodeShareob(@RequestParam("inboundFileName") String inboundFileName);

		@RequestMapping("/esal-in/invokejob")
		public String invokeEsalJob(@RequestParam("inboundFileName") String inboundFileName);

		@RequestMapping("/requestfile/invokejob")
		public String invokeRequestInFileJob(@RequestParam("inboundFileName") String inboundFileName);

		@RequestMapping("/requestOutfile/invokejob")
		public String invokeRequestOutFileJob();

		@RequestMapping("/response-in/invokejob")
		public String invokeResponseInFileJob(@RequestParam("inboundFileName") String inboundFileName);

		@RequestMapping("/responseOutfile/invokejob")
		public String invokeResponseOutFileJob();

	}

	@FeignClient(value = "smartpra-flown-app")
	public interface FlownServiceFeignClient {
		@RequestMapping("/prorataioncall/between-fligtdate")
		public String prorateCouponByFlightDate(@RequestParam(value = "fromFlightDate") String fromFlightDate,
				@RequestParam(value = "toFlightDate") String toFlightDate);
	}
	
	//@FeignClient(value = "smartpra-batch-miscellaneous-billing", url = "http://10.245.240.45:8060/smartpra/miscellaneous-billing-batch")
	@FeignClient(value = "smartpra-batch-miscellaneous-billing")
	public interface MiscellaneousBillingBatchFeingClient {

		@RequestMapping("/miscellaneous-billing/inwardJob/scheduler")
		public String invokeInboundJob(@RequestParam("clientId") String clientId);

		@RequestMapping("/miscellaneous-billing/invokejob/suppdoc")
		public void invokejobSuppDoc(@RequestParam("clientId") String clientId);

		@RequestMapping("/miscellaneous-billing/invokeoutwardjob")
		public String invokeGenerateOutwardXml(@RequestParam(value = "clientId") String clientId);

		@RequestMapping("/miscellaneous-billing/outward/suppdoc")
		public String outwardSuppDoc(@RequestParam(value = "clientId") String clientId,
				@RequestParam(value = "billingMonth") String billingMonth,
				@RequestParam(value = "billingPeriod") String billingPeriod);
	}

	@FeignClient(value = "smartpra-miscellaneous-billing-app")
	public interface MiscellaneousBillingFeingClient {
		@PostMapping("/misc-billing-invoice/outward-invoice/save")
		public String processOutwardInvoices(@RequestParam(value = "billingMonth") String billingMonth,
				@RequestParam(value = "billingPeriod") Integer billingPeriod,
				@RequestParam(value = "clientId") String clientId);
	}

	@FeignClient(value = "smartpra-batch-fdr")
	public interface CurrencyRateFDRFeingClient {
		@RequestMapping("/fdr/invoke-job/jobschedular")
		public String handle(@RequestParam("clientId") String clientId);
	}

	@FeignClient(value = "smartpra-batch-mmr")
	public interface CurrencyRateMMRFeingClient {
		@RequestMapping("/mmr/invoke-job/jobschedular")
		public String handle(@RequestParam("clientId") String clientId);
	}

	@FeignClient(value = "smartpra-batch-roe")
	public interface CurrencyRateROEFeingClient {
		@RequestMapping("/roe/invoke-job/jobschedular")
		public String handle(@RequestParam("clientId") String clientId);
	}
	
	//@FeignClient(value = "smartpra-accounting-summarization-app", url = "http://10.245.240.45:8060/smartpra/smartpra-accounting-summarization-app")
	@FeignClient(value = "smartpra-accounting-summarization-app")
	public interface AccountingFeingClient {
		@PostMapping("/summarizeAuditTrailData")
		public List<AccountingSummarization> summarizeAuditTrailData(@RequestBody AccountingSummarizationInput accountingSummarizationInput);	
	}
	
	//@FeignClient(value = "smartpra-accounting-file-extract", url = "http://10.245.240.45:8060/smartpra/smartpra-accounting-file-extract/")
	@FeignClient(value = "smartpra-accounting-file-extract")
	public interface AccountingFileExtFeingClient {
	
		@PostMapping("/saveAccountingExtract")
		public void saveAccountingExtract(@RequestParam("clientId") String clientId,
				@RequestParam("moduleId") String moduleId, @RequestParam("subModule") String subModule,
				@RequestParam("accountType") String accountType, @RequestParam("fileType") String fileType,
				@RequestParam("monthClosedDate") String monthClosedDate);
	
	}
	
	
}
