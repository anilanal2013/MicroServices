package com.sgl.smartpra.job.scheduler.app.component;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.BatchInterlineFeingClient;
import com.sgl.smartpra.job.scheduler.model.InterlineJobDetails;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Component
public class InterlineJobComponent {

	private static final Logger log = LoggerFactory.getLogger(InterlineJobComponent.class);

	@Autowired
	private BatchInterlineFeingClient batchInterlineFeingClient;

	public void executeInterlineJob(JobDetailsModel job) {
		final String jobName = job.getJobName();
		final String clientId = job.getClientId();
		if ("Form-3 File Loading".equalsIgnoreCase(jobName)) {
			log.info("Calling Inetrline Form-3 job for clientId :: {}", clientId);
			final String from3Response = batchInterlineFeingClient.invokeForm3Job(job.getClientId());
			log.info("Inetrline Form-3 job's Response :: {}", from3Response);
		} else if ("Idec File Loading".equalsIgnoreCase(jobName)) {
			log.info("Calling Inetrline Idec job for clientId :: {}", clientId);
			final String idecResponse = batchInterlineFeingClient.invokeIdecJob(job.getClientId());
			log.info("Inetrline Idec job's response :: {}", idecResponse);
		} else if ("IB closing".equalsIgnoreCase(jobName)) {
			final InterlineJobDetails requsetBody = constructRequsetBody(job, "ibProrationClosing");
			log.info("Calling IB closing job for clientId :: {}", clientId);
			final String ibClosingResponse = batchInterlineFeingClient.invokeBatchJob(requsetBody);
			log.info("Inetrline IB closing job's response :: {}", ibClosingResponse);
		}  else if ("IB Reproration".equalsIgnoreCase(jobName)) {
			final InterlineJobDetails requsetBody = constructRequsetBody(job, "ReProrationJob");
			log.info("Calling Inetrline IB Reproration job for clientId :: {}", clientId);
			final String ibReprorationResponse = batchInterlineFeingClient.invokeBatchJob(requsetBody);
			log.info("Inetrline IB Reproration job's response :: {}", ibReprorationResponse);
		}  else if ("IB Accounting".equalsIgnoreCase(jobName)) {
			final InterlineJobDetails requsetBody = constructRequsetBody(job, "form3AccountingJob");
			log.info("Calling Inetrline IB Accounting job for clientId :: {}", clientId);
			final String ibAccountingResponse = batchInterlineFeingClient.invokeBatchJob(requsetBody);
			log.info("Inetrline IB Accounting job's response :: {}", ibAccountingResponse);
		}
	}

	private InterlineJobDetails constructRequsetBody(JobDetailsModel job, String jobName) {
		InterlineJobDetails interlineJobDetails = new InterlineJobDetails();
		interlineJobDetails.setJobName(jobName);
		Map<String, String> jobParams = new HashMap<>();
		if(job.getParameter3() != null  && job.getParameter3() != "") {
			jobParams.put("billingMonth", job.getParameter3());
		}
		jobParams.put("clientId", job.getClientId());
		interlineJobDetails.setJobParams(jobParams);
		return interlineJobDetails;
	}

}
