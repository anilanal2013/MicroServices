package com.sgl.smartpra.job.scheduler.app.job;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.sgl.smartpra.job.scheduler.app.service.DayJobService;

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class DayQuartzJob extends QuartzJobBean {

	private static final Logger log = LoggerFactory.getLogger(DayQuartzJob.class);

	private String jobName;

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		try {
			log.info("Inside executeJob in <DayQuartzJob> with Job Name :: <{}>", jobName);

			final ApplicationContext applicationContext = (ApplicationContext) context.getScheduler().getContext()
					.get("applicationContext");
		    final JobDataMap dataMap = context.getJobDetail().getJobDataMap();
			final DayJobService service = applicationContext.getBean(DayJobService.class);
			service.executeJob(jobName, dataMap);
			log.info("Ends executing DayQuartzJob");
		} catch (Exception e) {
			log.error("{}",e);
		}
	}
}