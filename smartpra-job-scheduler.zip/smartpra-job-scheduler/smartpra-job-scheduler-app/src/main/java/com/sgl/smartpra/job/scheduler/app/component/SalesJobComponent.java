package com.sgl.smartpra.job.scheduler.app.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.BatchARCFeignClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.BatchBSPFeignClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.BatchSalesAmadeusFeignClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.BatchSalesServiceFeignClient;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Component
public class SalesJobComponent {

	private static final Logger log = LoggerFactory.getLogger(SalesJobComponent.class);

	@Autowired
	private BatchBSPFeignClient batchBSPFeignClient;

	@Autowired
	private BatchARCFeignClient batchARCFeignClient;

	@Autowired
	private BatchSalesAmadeusFeignClient batchSalesAmadeusFeignClient;
	
	@Autowired
	private BatchSalesServiceFeignClient batchSalesServiceFeignClient;

	public void executeSalesJob(JobDetailsModel job) {
		final String jobName = job.getJobName();
		final String clientId = job.getClientId();
		if ("BSP File Loading".equalsIgnoreCase(jobName)) {
			log.info("Calling BSP job for Client Id :: {}", clientId);
			final String processBSP = batchBSPFeignClient.processBSP(clientId);
			log.info("BSP output :: {}", processBSP);
		} else if ("ARC File Loading".equalsIgnoreCase(jobName)) {
			log.info("Calling ARC job for Client Id :: {}", clientId);
			final String processARC = batchARCFeignClient.processARC(clientId);
			log.info("ARC output :: {}", processARC);
		} else if ("Sales Amadeus File Loading".equalsIgnoreCase(jobName)) {
			log.info("Calling Sales Amadeus job for Client Id :: {}", clientId);
			final String processSalesAmadeus = batchSalesAmadeusFeignClient.processSalesAmadeus(clientId);
			log.info("Sales Amadeus output :: {}", processSalesAmadeus);
		} else if ("Sales Proration".equalsIgnoreCase(jobName)) {
			log.info("Calling Sales Proration job for Client Id :: {}", clientId);
			batchSalesServiceFeignClient.getTransactionTypeDocuments(job.getParameter1(), job.getParameter2(), clientId);
			log.info("Sales Proration :: Executed");
		}
	}

}
