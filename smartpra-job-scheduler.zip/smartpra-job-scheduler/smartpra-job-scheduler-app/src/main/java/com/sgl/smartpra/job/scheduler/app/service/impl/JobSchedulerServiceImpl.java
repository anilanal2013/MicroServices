package com.sgl.smartpra.job.scheduler.app.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.job.scheduler.app.component.SchedulerComponent;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.job.scheduler.app.service.JobSchedulerService;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Service
public class JobSchedulerServiceImpl implements JobSchedulerService {

	private static final Logger log = LoggerFactory.getLogger(JobSchedulerServiceImpl.class);

	private static final String DATE_FORMAT = "yyyy-MM-dd";

	@Value("${job.day.start.time}")
	private String dayJobStartTime;

	@Value("${job.night.start.time}")
	private String nightJobStartTime;

	@Autowired
	private MasterFeignClient masterFeignClient;

	@Autowired
	private SchedulerComponent schedulerComponent;

	@Override
	public void executeJob(String jobName) {
		log.info("Inside executeJob in <JobSchedulerServiceImpl> with Job Name :: <{}>", jobName);

		try {
			final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
			final String currentDateStr = sdf.format(new Date());
			final List<JobDetailsModel> allActiveJob = masterFeignClient.getAllActiveJob(currentDateStr);
			
			final List<JobDetailsModel> dailyJobs = allActiveJob.stream().filter(x -> x.getFrequency().equals("D"))
					.collect(Collectors.toList());
			final List<JobDetailsModel> dailyDayJobs = dailyJobs.stream().filter(x -> x.getJobType().equals("D"))
					.sorted(Comparator.comparingInt(JobDetailsModel::getSequence)).collect(Collectors.toList());
			final List<JobDetailsModel> dailyNightJobs = dailyJobs.stream().filter(x -> x.getJobType().equals("N"))
					.sorted(Comparator.comparingInt(JobDetailsModel::getSequence)).collect(Collectors.toList());

			final List<JobDetailsModel> weeklyJobs = allActiveJob.stream().filter(x -> x.getFrequency().equals("W"))
					.collect(Collectors.toList());
			final List<JobDetailsModel> weeklyDayJobs = weeklyJobs.stream().filter(x -> x.getJobType().equals("D"))
					.sorted(Comparator.comparingInt(JobDetailsModel::getSequence)).collect(Collectors.toList());
			final List<JobDetailsModel> weeklyNightJobs = weeklyJobs.stream().filter(x -> x.getJobType().equals("N"))
					.sorted(Comparator.comparingInt(JobDetailsModel::getSequence)).collect(Collectors.toList());

			final List<JobDetailsModel> monthlyJobs = allActiveJob.stream().filter(x -> x.getFrequency().equals("M"))
					.collect(Collectors.toList());
			final List<JobDetailsModel> monthlyDayJobs = monthlyJobs.stream().filter(x -> x.getJobType().equals("D"))
					.sorted(Comparator.comparingInt(JobDetailsModel::getSequence)).collect(Collectors.toList());
			final List<JobDetailsModel> monthlyNightJobs = monthlyJobs.stream().filter(x -> x.getJobType().equals("N"))
					.sorted(Comparator.comparingInt(JobDetailsModel::getSequence)).collect(Collectors.toList());
			
			
			createJobTrigger(dailyDayJobs, dayJobStartTime);
			createJobTrigger(dailyNightJobs, nightJobStartTime);
			
			createJobTrigger(weeklyDayJobs, dayJobStartTime);
			createJobTrigger(weeklyNightJobs, nightJobStartTime);
			
			createJobTrigger(monthlyDayJobs, dayJobStartTime);
			createJobTrigger(monthlyNightJobs, nightJobStartTime);

		} catch (Exception e) {
			log.error("{}", e);
		}
	}

	private void createJobTrigger(final List<JobDetailsModel> jobs, String startTime) {
		Map<Integer, List<JobDetailsModel>> dayJobBySequnce = constructMapBySequnce(jobs);
		Calendar rightNow = Calendar.getInstance();
		log.info("Job start time :: {}", startTime);
		final String[] dayStarTime = dayJobStartTime.split("-");
		rightNow.set(Calendar.HOUR, Integer.parseInt(dayStarTime[0]));
		rightNow.set(Calendar.MINUTE, Integer.parseInt(dayStarTime[1]));
		rightNow.set(Calendar.SECOND, 0); 
		dayJobBySequnce.entrySet().forEach(seqList -> {
			final Map<String, List<JobDetailsModel>> dailyDayMap = constructMapByModuleName(seqList.getValue());
			dailyDayMap.entrySet().parallelStream().forEach(entry -> {
				entry.getValue().forEach(x -> schedulerComponent.addNewJob(x, rightNow, x.getJobName()));
			});
		});
	}
	
	private Map<Integer, List<JobDetailsModel>> constructMapBySequnce(final List<JobDetailsModel> dailyDayJobs) {
		final Map<Integer, List<JobDetailsModel>> map = new TreeMap<>();
		dailyDayJobs.forEach(dailyJob -> {
			Integer key = dailyJob.getSequence();
			if (map.containsKey(key)) {
				map.get(key).add(dailyJob);
			} else {
				List<JobDetailsModel> objs = new ArrayList<>();
				objs.add(dailyJob);
				map.put(key, objs);
			}
		});
		return map;
	}

	private Map<String, List<JobDetailsModel>> constructMapByModuleName(final List<JobDetailsModel> dailyDayJobs) {
		final Map<String, List<JobDetailsModel>> map = new HashMap<>();
		dailyDayJobs.forEach(dailyJob -> {
			String key = dailyJob.getModuleName();
			if (map.containsKey(key)) {
				map.get(key).add(dailyJob);
			} else {
				List<JobDetailsModel> objs = new ArrayList<>();
				objs.add(dailyJob);
				map.put(key, objs);
			}
		});
		return map;
	}

}
