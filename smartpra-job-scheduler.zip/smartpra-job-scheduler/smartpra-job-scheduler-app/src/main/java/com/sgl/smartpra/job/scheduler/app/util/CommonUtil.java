package com.sgl.smartpra.job.scheduler.app.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class CommonUtil {
	
	private CommonUtil() {
		throw new IllegalStateException("Utility class");
	}

	public static List<String> getFilesList(String filePath) {
		List<String> filesList = new ArrayList<>();
		File folder = new File(filePath);
		for (File file : folder.listFiles()) {
		    if (file.isFile()) {
		    	filesList.add(file.getName());
		    }
		}
		return filesList;
	}

}
