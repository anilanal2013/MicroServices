package com.sgl.smartpra.job.scheduler.app.component;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.BatchAmadeusFeignClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.BatchFlightBHRFeignClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.BatchOneWorldFeignClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.FlownServiceFeignClient;
import com.sgl.smartpra.job.scheduler.app.util.CommonUtil;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Component
public class FlownJobComponent {

	private static final Logger log = LoggerFactory.getLogger(FlownJobComponent.class);

	@Autowired
	private BatchAmadeusFeignClient batchAmadeusFeignClient;

	@Autowired
	private BatchFlightBHRFeignClient batchFlightBHRFeignClient;

	@Autowired
	private BatchOneWorldFeignClient batchOneWorldFeignClient;

	@Autowired
	private FlownServiceFeignClient flownServiceFeignClient;
	
	@Value("${local.server.folder.path}")
	private String serverFilepath;

	@Async
	public void executeFlownJob(JobDetailsModel job) throws IOException {
		final String jobName = job.getJobName();
		final String clientId = job.getClientId();
		if ("Amadeus File Loading".equalsIgnoreCase(jobName)) {
			List<String> ftpFiles = CommonUtil.getFilesList(getFTPPath("amadeus"));
			ftpFiles.stream().forEach(x -> {
				log.info("Calling Amadeus job for file name :: {}", x);
				batchAmadeusFeignClient.invokeAmadeusJob(x);
			});
		} else if ("Flight BHR InFile".equalsIgnoreCase(jobName)) {
			List<String> ftpFiles = CommonUtil.getFilesList(getFTPPath("bhr"));
			ftpFiles.stream().forEach(x -> {
				log.info("Calling BHR InFile job for file name :: {}", x);
				batchFlightBHRFeignClient.invokeBhrJob(job.getParameter1(), x);
			});
		} else if ("Flight Reco File Loading".equalsIgnoreCase(jobName)) {
			List<String> ftpFiles = CommonUtil.getFilesList(getFTPPath("fl-reco"));
			ftpFiles.stream().forEach(x -> {
				log.info("Calling Reco job for file name :: {}", x);
				batchFlightBHRFeignClient.invokeRecoJob(x);
			});
		} else if ("Code Share".equalsIgnoreCase(jobName)) {
			List<String> ftpFiles = CommonUtil.getFilesList(getFTPPath("fl-code-share"));
			ftpFiles.stream().forEach(x -> {
				log.info("Calling Code Share job for file name :: {}", x);
				batchOneWorldFeignClient.invokeCodeShareob(x);
			});
		} else if ("ESAL IN".equalsIgnoreCase(jobName)) {
			List<String> ftpFiles = CommonUtil.getFilesList(getFTPPath("fl-esal"));
			ftpFiles.stream().forEach(x -> {
				log.info("Calling ESAL IN job for file name :: {}", x);
				batchOneWorldFeignClient.invokeEsalJob(x);
			});
		} else if ("Request IN File".equalsIgnoreCase(jobName)) {
			List<String> ftpFiles = CommonUtil.getFilesList(getFTPPath("fl-request-in"));
			ftpFiles.stream().forEach(x -> {
				log.info("Calling Request IN job for file name :: {}", x);
				batchOneWorldFeignClient.invokeRequestInFileJob(x);
			});
		} else if ("Request OUT File".equalsIgnoreCase(jobName)) {
			List<String> ftpFiles = CommonUtil.getFilesList(getFTPPath("fl-request-out"));
			ftpFiles.stream().forEach(x -> {
				log.info("Calling Request OUT job for file name :: {}", x);
				batchOneWorldFeignClient.invokeRequestOutFileJob();
			});
		} else if ("Response IN File".equalsIgnoreCase(jobName)) {
			List<String> ftpFiles = CommonUtil.getFilesList(getFTPPath("fl-response-in"));
			ftpFiles.stream().forEach(x -> {
				log.info("Calling Response IN job for file name :: {}", x);
				batchOneWorldFeignClient.invokeResponseInFileJob(x);
			});
		} else if ("Response OUT File".equalsIgnoreCase(jobName)) {
			List<String> ftpFiles = CommonUtil.getFilesList(getFTPPath("fl-response-out"));
			ftpFiles.stream().forEach(x -> {
				log.info("Calling Response OUT job for file name :: {}", x);
				batchOneWorldFeignClient.invokeResponseOutFileJob();
			});
		} else if ("Flown Proration".equalsIgnoreCase(jobName)) {
			log.info("Calling Flown Proration job for Client Id :: {}", clientId);
			String outCome = flownServiceFeignClient.prorateCouponByFlightDate(job.getParameter1(),
					job.getParameter2());
			log.info("Flown Proration job's outCome :: {}", outCome);
		}

	}

	private String getFTPPath(String jobName) {
		return serverFilepath+"/flown/" + jobName;
	}

}
