package com.sgl.smartpra.job.scheduler.app.job;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.sgl.smartpra.job.scheduler.app.service.JobSchedulerService;

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class QuartzJob extends QuartzJobBean {

	private static final Logger log = LoggerFactory.getLogger(QuartzJob.class);

	private String jobName;

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		try {
			log.info("Inside executeJob in <QuartzJob> with Job Name :: <{}>", jobName);

			ApplicationContext applicationContext = (ApplicationContext) context.getScheduler().getContext()
					.get("applicationContext");

			JobSchedulerService service = applicationContext.getBean(JobSchedulerService.class);
			service.executeJob(jobName);
			log.info("Ends executing QuartzJob");
		} catch (Exception e) {
			log.error("{}",e);
		}
	}
}