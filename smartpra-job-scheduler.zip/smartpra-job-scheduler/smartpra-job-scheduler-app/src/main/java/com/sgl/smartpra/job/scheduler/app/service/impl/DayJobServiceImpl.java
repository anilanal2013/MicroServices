package com.sgl.smartpra.job.scheduler.app.service.impl;

import org.quartz.JobDataMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.job.scheduler.app.component.AccountingJobComponent;
import com.sgl.smartpra.job.scheduler.app.component.FlownJobComponent;
import com.sgl.smartpra.job.scheduler.app.component.InterlineJobComponent;
import com.sgl.smartpra.job.scheduler.app.component.MiscBillingComponent;
import com.sgl.smartpra.job.scheduler.app.component.SFTPComponent;
import com.sgl.smartpra.job.scheduler.app.component.SalesJobComponent;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.job.scheduler.app.service.DayJobService;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Service
public class DayJobServiceImpl implements DayJobService {

	private static final Logger log = LoggerFactory.getLogger(DayJobServiceImpl.class);
	
	@Autowired
	private MasterFeignClient masterFeignClient;

	@Autowired
	private SalesJobComponent salesJobComponent;
	
	@Autowired 
	private InterlineJobComponent interlineJobComponent;
	
	@Autowired 
	private FlownJobComponent flownJobComponent;
	
	@Autowired 
	private SFTPComponent sftpComponent;
	
	@Autowired 
	private MiscBillingComponent miscBillingComponent;
	
	@Autowired 
	private AccountingJobComponent accountingJobComponent;
	
	

	@Override
	public void executeJob(String jobName, JobDataMap jobDataMap) {
		log.info("Inside executeJob in <DayJobServiceImpl> with Job Name :: <{}>", jobName);
		try {
			log.info("Before Calling Feign Cient");
			
			JobDetailsModel job = (JobDetailsModel) jobDataMap.get("job");
			
			job = masterFeignClient.findByJobId(job.getJobId());
			Integer delay = job.getDelay();
			if(delay != null && delay != 0) {
				Thread.sleep(delay.longValue() * 60 * 1000L);
				job.setDelay(0);
				job.setLastUpdatedBy("Job-scheduler");
				masterFeignClient.updateJob(job.getJobId(), job);
			}
			
			if ("GL".equals(job.getModuleName())) {
				sftpComponent.executeFTPJob(job);
			} else if ("SA".equals(job.getModuleName())) {
				salesJobComponent.executeSalesJob(job);
			} else if ("IN".equals(job.getModuleName())) {
				interlineJobComponent.executeInterlineJob(job);
			} else if ("FL".equals(job.getModuleName())) {
				flownJobComponent.executeFlownJob(job);
			} else if ("MS".equals(job.getModuleName())) {
				miscBillingComponent.executeMiscBillingJob(job);
			} else if ("AC".equals(job.getModuleName())) {
				accountingJobComponent.executeAccountingJob(job);
			}

			log.info("After Calling Feign Cient");
		} catch (Exception e) {
			log.error("{}", e);
		}
	}

}
