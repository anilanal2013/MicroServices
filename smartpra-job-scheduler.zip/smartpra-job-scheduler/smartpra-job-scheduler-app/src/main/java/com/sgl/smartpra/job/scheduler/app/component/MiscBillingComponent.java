package com.sgl.smartpra.job.scheduler.app.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.MiscellaneousBillingBatchFeingClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.MiscellaneousBillingFeingClient;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Component
public class MiscBillingComponent {

	private static final Logger log = LoggerFactory.getLogger(MiscBillingComponent.class);

	@Autowired
	private MiscellaneousBillingBatchFeingClient batchMiscFeignClient;

	@Autowired
	private MiscellaneousBillingFeingClient miscBillingFeignClient;

	public void executeMiscBillingJob(JobDetailsModel job) {
		final String jobName = job.getJobName();
		final String clientId = job.getClientId();
		if ("IS-XML upload".equalsIgnoreCase(jobName)) {
			log.info("Calling IS-XML upload job for Client Id :: {}", clientId);
			final String invokeInboundJob = batchMiscFeignClient.invokeInboundJob(clientId);
			log.info("IS-XML upload :: {}", invokeInboundJob);
		} else if ("IS-XML Supporting Upload".equalsIgnoreCase(jobName)) {
			log.info("Calling IS-XML Supporting upload job for Client Id :: {}", clientId);
			batchMiscFeignClient.invokejobSuppDoc(clientId);
			log.info("IS-XML Supporting Done");
		} else if ("IS-XML File Generation".equalsIgnoreCase(jobName)) {
			log.info("Calling IS-XML File Generation job for Client Id :: {}", clientId);
			final String invokeGenerateOutwardXml = batchMiscFeignClient.invokeGenerateOutwardXml(clientId);
			log.info("IS-XML File Generation :: {}", invokeGenerateOutwardXml);
		} else if ("IS-XML Supporting Doc".equalsIgnoreCase(jobName)) {
			log.info("Calling IS-XML Supporting Doc job for Client Id :: {}", clientId);
			final String outwardSuppDoc = batchMiscFeignClient.outwardSuppDoc(clientId, job.getParameter1(), job.getParameter2());
			log.info("IS-XML Supporting Doc :: {}", outwardSuppDoc);
		} else if ("InvoiceNo Generation".equalsIgnoreCase(jobName)) {
			log.info("Calling InvoiceNo Generation job for Client Id :: {}", clientId);
			Integer parseInt = null;
			if (job.getParameter2() != null && job.getParameter2() != "") {
				parseInt = Integer.parseInt(job.getParameter2());
			}
			final String processOutwardInvoices = miscBillingFeignClient.processOutwardInvoices(job.getParameter1(), parseInt, clientId);
			log.info("InvoiceNo Generation :: {}", processOutwardInvoices);
		}
	}

}
