package com.sgl.smartpra.job.scheduler.app.component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.accounting.model.AccountingSummarizationInput;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.AccountingFeingClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.AccountingFileExtFeingClient;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Component
public class AccountingJobComponent {

	private static final Logger log = LoggerFactory.getLogger(AccountingJobComponent.class);

	private static final String DATE_FORMAT = "yyyy-MM-dd";

	@Autowired
	private AccountingFeingClient accountingFeingClient;

	@Autowired
	private AccountingFileExtFeingClient accountingFileExtFeingClient;

	@Async
	public void executeAccountingJob(JobDetailsModel job) {
		final String jobName = job.getJobName();
		final String clientId = job.getClientId();
		if ("GL Summarization".equalsIgnoreCase(jobName) || "AR Summarization".equalsIgnoreCase(jobName)
				|| "AP Summarization".equalsIgnoreCase(jobName)) {
			log.info("Calling BSP job for Client Id :: {}", clientId);
			AccountingSummarizationInput accSummIn = constructAccSummInObj(job, clientId);
			accountingFeingClient.summarizeAuditTrailData(accSummIn);
		} else if ("GL Extract".equalsIgnoreCase(jobName) || "AR Extract".equalsIgnoreCase(jobName)
				|| "AP Extract".equalsIgnoreCase(jobName)) {
			accountingFileExtFeingClient.saveAccountingExtract(clientId, job.getParameter1(), job.getParameter2(),
					jobName.split(" ")[0], job.getParameter3(), job.getParameter4());
		}
	}

	private AccountingSummarizationInput constructAccSummInObj(JobDetailsModel job, final String clientId) {
		final AccountingSummarizationInput accSummIn = new AccountingSummarizationInput();
		accSummIn.setModule(job.getParameter1());
		accSummIn.setAccountType(job.getJobName().split(" ")[0]);
		final DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DATE_FORMAT);
		final LocalDate fromDate = LocalDate.parse(job.getParameter2(), dtf);
		accSummIn.setFromDate(fromDate);
		accSummIn.setInterfaceType(job.getParameter3());
		accSummIn.setClientId(clientId);
		return accSummIn;
	}

}
