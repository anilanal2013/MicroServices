package com.sgl.smartpra.job.scheduler.app.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.job.scheduler.app.job.QuartzJob;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;
import com.sgl.smartpra.job.scheduler.model.JobSchedule;

@RestController
public class JobSchedulerController {

	@Autowired
	private Scheduler scheduler;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@GetMapping("/jobScheduled")
	public List<JobSchedule> getjobScheduled() {
		List<JobSchedule> jobs = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		try {
			List<String> jobGroupNames = scheduler.getJobGroupNames();
			for (String jobGroupName : jobGroupNames) {
				Set<JobKey> jobKeys = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(jobGroupName));
				for (JobKey jobKey : jobKeys) {
					List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);
					JobDetailsModel jobDetails = (JobDetailsModel) scheduler.getJobDetail(jobKey).getJobDataMap()
							.get("job");
					if (jobDetails != null) {
						for (Trigger trigger : triggers) {
							Date nextFireTime = trigger.getNextFireTime();
							JobSchedule jobScheduleObj = modelMapper.map(jobDetails, JobSchedule.class);
							jobScheduleObj.setNextFire(nextFireTime != null ? sdf.format(nextFireTime) : null);
							jobs.add(jobScheduleObj);
						}
					}
				}
			}
			jobs.stream().sorted(Comparator.comparingInt(JobSchedule::getSequence))
					.sorted(Comparator.comparing(JobSchedule::getModuleName))
					.sorted(Comparator.comparing(JobSchedule::getNextFire));
		} catch (SchedulerException e) {
			e.printStackTrace();
		}
		return jobs;
	}

	@PutMapping("/deleteTrigger/{jobName}/{jobGroup}")
	public String deleteTrigger(@PathVariable(value = "jobName") String jobName,
			@PathVariable(value = "jobGroup") String jobGroup) throws SchedulerException {
		JobKey jobKey = new JobKey(jobName, jobGroup);
		if (scheduler.deleteJob(jobKey)) {
			return "deleted";
		} else {
			return "Failed";
		}
	}

	@PutMapping("/resumeTrigger/{jobName}/{jobGroup}")
	public void resumeTrigger(@PathVariable(value = "jobName") String jobName,
			@PathVariable(value = "jobGroup") String jobGroup) throws SchedulerException {
		JobKey jobKey = new JobKey(jobName, jobGroup);
		scheduler.resumeJob(jobKey);
	}

	@PutMapping("/pauseTrigger/{jobName}/{jobGroup}")
	public void pauseTrigger(@PathVariable(value = "jobName") String jobName,
			@PathVariable(value = "jobGroup") String jobGroup) throws SchedulerException {
		JobKey jobKey = new JobKey(jobName, jobGroup);
		scheduler.pauseJob(jobKey);
	}

	@PutMapping("/addNewJob/{jobName}/{jobGroup}/{cronExp}")
	public String addNewJob(@PathVariable(value = "jobName") String jobName,
			@PathVariable(value = "jobGroup") String jobGroup, @PathVariable(value = "cronExp") String cronExp)
			throws SchedulerException {

		JobDataMap jobDataMap = new JobDataMap();
		jobDataMap.put("jobName", jobName);

		JobDetail job = JobBuilder.newJob(QuartzJob.class).withIdentity(jobName, jobGroup).setJobData(jobDataMap)
				.storeDurably().build();

		Trigger trigger = TriggerBuilder.newTrigger().withIdentity(jobName + "-trigger", jobGroup).startNow()
				.withSchedule(CronScheduleBuilder.cronSchedule("0 0/5 * 1/1 * ? *")).build();
		scheduler.scheduleJob(job, trigger);

		return "success";
	}

	@PutMapping("/jobRescheduled/{jobName}/{jobGroup}/{cronExp}")
	public String jobRescheduled(@PathVariable(value = "jobName") String jobName,
			@PathVariable(value = "jobGroup") String jobGroup, @PathVariable(value = "cronExp") String cronExp)
			throws SchedulerException {
		Trigger newTrigger = TriggerBuilder.newTrigger().withIdentity(jobName + "-trigger", jobGroup).startNow()
				.withSchedule(CronScheduleBuilder.cronSchedule("0 */3 * ? * *")).build();

		JobKey jobKey = new JobKey(jobName, jobGroup);
		List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);
		for (Trigger oldTrigger : triggers) {
			scheduler.rescheduleJob(TriggerKey.triggerKey(oldTrigger.getKey().getName()), newTrigger);
		}

		return "success";

	}

}
