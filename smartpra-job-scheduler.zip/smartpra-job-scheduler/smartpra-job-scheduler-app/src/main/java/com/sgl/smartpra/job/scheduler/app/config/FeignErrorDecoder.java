package com.sgl.smartpra.job.scheduler.app.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import feign.codec.ErrorDecoder;

public class FeignErrorDecoder implements ErrorDecoder {

    private static final Logger LOGGER = LoggerFactory.getLogger(FeignErrorDecoder.class);
    
    @Override
    public Exception decode(String methodKey, feign.Response response) {
 
    	LOGGER.error("Feign exception thrown with http status : {}, methodKey : {}", response.status(),  methodKey );
    	return new ResponseStatusException(HttpStatus.valueOf(response.status())); 
    }      
 }
