package com.sgl.smartpra.job.scheduler.app.component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.job.scheduler.app.job.DayQuartzJob;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Component
public class SchedulerComponent {

	private static final Logger log = LoggerFactory.getLogger(SchedulerComponent.class);

	private static final String CRON_EXP = "%1$s %2$s %3$s %4$s %5$s %6$s %7$s";

	private static final String GROUP = "DEFAULT";
	
	private static final String DATE_FORMAT = "yyyy-MM-dd";
	
	@Value("${job.day.start.time}")
	private String dayJobStartTime;
	
	@Value("${job.night.start.time}")
	private String nightJobStartTime;

	@Autowired
	private Scheduler scheduler;
	
	public void addNewJob(JobDetailsModel job, Calendar rightNow, String jobName) {
		try {
			String cronExp = null;
			if (job.getFrequency().equals("D")) {
				cronExp = generateDailyCronExp(rightNow);
			} else if (job.getFrequency().equals("W")) {
				cronExp = generateWeeklyCronExp(rightNow);
			} else if (job.getFrequency().equals("M")) {
				cronExp = generateMonthlyCronExp(rightNow);
			}
			
			scheduleJob(job, jobName, cronExp);
			if(job.getEstimatedTime() != null) {
				rightNow.add(Calendar.MINUTE, job.getEstimatedTime());
			}
		} catch (SchedulerException | ParseException e) {
			log.error("Daily Job {} :: Falied - Message ::{}", jobName, e);
		}
	}


	private void scheduleJob(JobDetailsModel job, String jobName, String cronExp)
			throws SchedulerException, ParseException {
		final JobDataMap jobDataMap = new JobDataMap();
		jobDataMap.put("job", job);
		jobDataMap.put("jobName", jobName);
		final JobDetail jobDetail = JobBuilder.newJob(DayQuartzJob.class).withIdentity(jobName, GROUP).setJobData(jobDataMap)
				.storeDurably().build();
		
		final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		Date startDate = sdf.parse(job.getEffectiveFromDate());
		Date endDate = sdf.parse(job.getEffectiveToDate());
		
		final Trigger trigger = TriggerBuilder.newTrigger()
				.withIdentity(jobName, GROUP)
				.startAt(startDate)
				.endAt(endDate)
				.withSchedule(CronScheduleBuilder.cronSchedule(cronExp)).build();
		final JobKey jobKey = new JobKey(jobName, GROUP);
		if(!scheduler.checkExists(jobKey)) {
			log.info(
					"New Job -> Name :: {} from Module :: {} with Sequence :: {} and Frequency :: {} , scheduled with Cron Expression :: {}",
					jobName, job.getModuleName(), job.getSequence(), job.getFrequency(), cronExp);
			scheduler.scheduleJob(jobDetail, trigger);
		} 
	}

	private String generateDailyCronExp(final Calendar rightNow) {
		return String.format(CRON_EXP, rightNow.get(Calendar.SECOND),
				rightNow.get(Calendar.MINUTE), rightNow.get(Calendar.HOUR_OF_DAY), "1/1",
				"*", "?", "*");
	}

	private String generateWeeklyCronExp(final Calendar rightNow) {
		return String.format(CRON_EXP, rightNow.get(Calendar.SECOND),
				rightNow.get(Calendar.MINUTE), rightNow.get(Calendar.HOUR_OF_DAY), "?", "*", "SAT", "*");
	}
	
	private String generateMonthlyCronExp(final Calendar rightNow) {
		return String.format(CRON_EXP, rightNow.get(Calendar.SECOND),
				rightNow.get(Calendar.MINUTE), rightNow.get(Calendar.HOUR_OF_DAY), "1", "1/1", "?", "*");
	}

}
