package com.sgl.smartpra.job.scheduler.app.service;

public interface JobSchedulerService {

	void executeJob(String jobName);

}
