package com.sgl.smartpra.job.scheduler.app.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Component
public class GeneralComponent {

	private static final Logger log = LoggerFactory.getLogger(GeneralComponent.class);

	@Autowired
	private SFTPComponent sftpComponent;
	
	@Autowired
	private CurrencyRateComponent currencyRateComponent;

	public void executeFTPJob(JobDetailsModel job) {
		final String jobName = job.getJobName();
		log.info("Inside GeneralComponent for Job name :: {}", jobName);
		if ("Move files from IINET to SGS SFTP".equalsIgnoreCase(jobName)) {
			sftpComponent.executeFTPJob(job);
		} else {
			currencyRateComponent.executeCurrencyRateJob(job);
		}

	}

}