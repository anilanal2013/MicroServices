package com.sgl.smartpra.job.scheduler.app.component;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.CurrencyRateFDRFeingClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.CurrencyRateMMRFeingClient;
import com.sgl.smartpra.job.scheduler.app.config.FeignConfiguration.CurrencyRateROEFeingClient;
import com.sgl.smartpra.job.scheduler.app.util.CommonUtil;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Component
public class CurrencyRateComponent {

	private static final Logger log = LoggerFactory.getLogger(CurrencyRateComponent.class);

	@Autowired
	private CurrencyRateFDRFeingClient currencyRateFDRFeingClient;

	@Autowired
	private CurrencyRateMMRFeingClient currencyRateMMRFeingClient;

	@Autowired
	private CurrencyRateROEFeingClient currencyRateROEFeingClient;

	@Async
	public void executeCurrencyRateJob(JobDetailsModel job) {
		final String jobName = job.getJobName();
		final String clientId = job.getClientId();
		if ("Currency Rate - FDR".equalsIgnoreCase(jobName)) {
			log.info("Calling FDR job for Client Id :: {}", clientId);
			currencyRateFDRFeingClient.handle(clientId);
		} else if ("Currency Rate - MMR".equalsIgnoreCase(jobName)) {
			log.info("Calling MMR job for file name :: {}", clientId);
			currencyRateMMRFeingClient.handle(clientId);
		} else if ("Currency Rate - ROE".equalsIgnoreCase(jobName)) {
			log.info("Calling ROE job for file name :: {}", clientId);
			currencyRateROEFeingClient.handle(clientId);
		}
	}

}
