package com.sgl.smartpra.job.scheduler.app.config;

import org.springframework.context.annotation.Bean;

public class FeignDecoderConfiguration {

	@Bean
	public FeignErrorDecoder feignErrorDecoder() {
		return new FeignErrorDecoder();
	}
}
