package com.sgl.smartpra.job.scheduler.app.service;

import org.quartz.JobDataMap;

public interface DayJobService {

	void executeJob(String jobName, JobDataMap jobDataMap);

}
