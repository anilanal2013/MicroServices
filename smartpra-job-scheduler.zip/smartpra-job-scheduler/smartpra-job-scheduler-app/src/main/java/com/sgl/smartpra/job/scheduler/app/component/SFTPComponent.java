package com.sgl.smartpra.job.scheduler.app.component;

import java.io.File;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;
import org.springframework.integration.sftp.session.SftpSession;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.SftpException;
import com.sgl.smartpra.job.scheduler.model.JobDetailsModel;

@Component
public class SFTPComponent {

	private static final Logger log = LoggerFactory.getLogger(SFTPComponent.class);

	private static final String DELIMITER = "/";

	@Value("${local.server.folder.path}")
	private String serverFilepath;

	public void executeFTPJob(JobDetailsModel job) {

		try {
			final String jobName = job.getJobName();
			if ("Move files from IINET to SGS SFTP".equalsIgnoreCase(jobName)) {
				final String src = job.getParameter4();
				final String dst = serverFilepath + DELIMITER + job.getClientId();
				new File(dst).mkdirs(); 
				final ChannelSftp sftpChannel = getSftpFactory(job).getClientInstance();
				downloadFiles(src, dst, sftpChannel);
				
			} else {
				final String dst = job.getParameter4();
				final String src = serverFilepath + DELIMITER + job.getClientId();
				final ChannelSftp sftpChannel = getSftpFactory(job).getClientInstance();
				uploadFiles(src, dst, sftpChannel);
			}
		} catch (SftpException e) {
			log.error("Error File transfer :: {}", e);
		}

	}

	private SftpSession getSftpFactory(JobDetailsModel job) {

		DefaultSftpSessionFactory factory = new DefaultSftpSessionFactory();
		factory.setHost("10.245.240.45");
		factory.setPort(22);
		factory.setAllowUnknownKeys(true);
		factory.setUser("gsiadmin");
		factory.setPassword("mb31$RjQcd");

//		factory.setHost(job.getParameter1());
//		factory.setPort(22);
//		factory.setAllowUnknownKeys(true);
//		factory.setUser(job.getParameter2());
//		factory.setPassword(job.getParameter3());

		return factory.getSession();

	}

	private void downloadFiles(String sourcePath, String destPath, ChannelSftp sftpChannel) throws SftpException {
		Vector<LsEntry> directory = sftpChannel.ls(sourcePath);
		for (LsEntry file : directory) {
			final String filename = file.getFilename();
			if (!file.getAttrs().isDir()) {
				new File(destPath + DELIMITER + filename);
				sftpChannel.get(sourcePath + DELIMITER + filename, destPath + DELIMITER + filename);
			} else if (!".".equals(filename) && !"..".equals(filename)) {
				new File(destPath + DELIMITER + filename).mkdirs();
				downloadFiles(sourcePath + DELIMITER + filename, destPath + DELIMITER + filename, sftpChannel);
			}
		}
	}
	
	
	private void uploadFiles(String sourcePath, String destPath, ChannelSftp sftpChannel) throws SftpException {
		File directory = new File(sourcePath);
		for (File file : directory.listFiles()) {
			final String filename = file.getName();
			if (!file.isDirectory()) {
				sftpChannel.put(sourcePath + DELIMITER + filename, destPath + DELIMITER + filename);
			} else if (!".".equals(filename) && !"..".equals(filename)) {
				sftpChannel.mkdir(destPath + DELIMITER + filename);
				uploadFiles(sourcePath + DELIMITER + filename, destPath + DELIMITER + filename, sftpChannel);
			}
		}
	}
	
}