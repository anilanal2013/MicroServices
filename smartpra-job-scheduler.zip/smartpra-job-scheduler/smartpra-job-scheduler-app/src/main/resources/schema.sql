DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_CALENDARS;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_CRON_TRIGGERS;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_FIRED_TRIGGERS;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_PAUSED_TRIGGER_GRPS;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_SCHEDULER_STATE;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_LOCKS;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_JOB_DETAILS;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_SIMPLE_TRIGGERS;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.qrtz_simprop_triggers;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_BLOB_TRIGGERS;
DROP TABLE  IF EXISTS SmartPRAGlobalBatch.QRTZ_TRIGGERS;
 
create table SmartPRAGlobalBatch.qrtz_calendars (
  sched_name varchar(120) not null,
  calendar_name varchar (200)  not null ,
  calendar image not null
);
 
create table SmartPRAGlobalBatch.qrtz_cron_triggers (
  sched_name varchar(120) not null,
  trigger_name varchar (200)  not null ,
  trigger_group varchar (200)  not null ,
  cron_expression varchar (120)  not null ,
  time_zone_id varchar (80)
);
 
create table SmartPRAGlobalBatch.qrtz_fired_triggers (
  sched_name varchar(120) not null,
  entry_id varchar (95)  not null ,
  trigger_name varchar (200)  not null ,
  trigger_group varchar (200)  not null ,
  instance_name varchar (200)  not null ,
  fired_time bigint not null ,
  sched_time bigint not null ,
  priority integer not null ,
  state varchar (16)  not null,
  job_name varchar (200)  null ,
  job_group varchar (200)  null ,
  is_nonconcurrent [varchar] (1)  null ,
  requests_recovery [varchar] (1)  null
);
 
create table SmartPRAGlobalBatch.qrtz_paused_trigger_grps (
  sched_name varchar(120) not null,
  trigger_group varchar (200)  not null
);
 
create table SmartPRAGlobalBatch.qrtz_scheduler_state (
  sched_name varchar(120) not null,
  instance_name varchar (200)  not null ,
  last_checkin_time bigint not null ,
  checkin_interval bigint not null
);
 
create table SmartPRAGlobalBatch.qrtz_locks (
  sched_name varchar(120) not null,
  lock_name varchar (40)  not null
);
 
create table SmartPRAGlobalBatch.qrtz_job_details (
  sched_name varchar(120) not null,
  job_name varchar (200)  not null ,
  job_group varchar (200)  not null ,
  description varchar (250) null ,
  job_class_name varchar (250)  not null ,
  is_durable [varchar] (1)  not null ,
  is_nonconcurrent [varchar] (1)  not null ,
  is_update_data [varchar] (1)  not null ,
  requests_recovery [varchar] (1)  not null ,
  job_data image null
);
 
create table SmartPRAGlobalBatch.qrtz_simple_triggers (
  sched_name varchar(120) not null,
  trigger_name varchar (200)  not null ,
  trigger_group varchar (200)  not null ,
  repeat_count bigint not null ,
  repeat_interval bigint not null ,
  times_triggered bigint not null
);
 
create table SmartPRAGlobalBatch.qrtz_simprop_triggers
  (         
    sched_name varchar(120) not null,
    trigger_name varchar(200) not null,
    trigger_group varchar(200) not null,
    str_prop_1 varchar(512) null,
    str_prop_2 varchar(512) null,
    str_prop_3 varchar(512) null,
    int_prop_1 integer null,
    int_prop_2 integer null,
    long_prop_1 bigint null,
    long_prop_2 bigint null,
    dec_prop_1 numeric(13,4) null,
    dec_prop_2 numeric(13,4) null,
    bool_prop_1 [varchar] (1) null,
    bool_prop_2 [varchar] (1) null,
);
 
create table SmartPRAGlobalBatch.qrtz_blob_triggers (
  sched_name varchar(120) not null,
  trigger_name varchar (200)  not null ,
  trigger_group varchar (200)  not null ,
  blob_data image null
);
 
create table SmartPRAGlobalBatch.qrtz_triggers (
  sched_name varchar(120) not null,
  trigger_name varchar (200)  not null ,
  trigger_group varchar (200)  not null ,
  job_name varchar (200)  not null ,
  job_group varchar (200)  not null ,
  description varchar (250) null ,
  next_fire_time bigint null ,
  prev_fire_time bigint null ,
  priority integer null ,
  trigger_state varchar (16)  not null ,
  trigger_type varchar (8)  not null ,
  start_time bigint not null ,
  end_time bigint null ,
  calendar_name varchar (200)  null ,
  misfire_instr smallint null ,
  job_data image null
);
 
alter table SmartPRAGlobalBatch.qrtz_calendars  add
  constraint pk_GlobalBatch_qrtz_calendars primary key 
  (
    sched_name,
    calendar_name
  );
 
alter table SmartPRAGlobalBatch.qrtz_cron_triggers  add
  constraint pk_GlobalBatch_qrtz_cron_triggers primary key 
  (
    sched_name,
    trigger_name,
    trigger_group
  );
 
alter table SmartPRAGlobalBatch.qrtz_fired_triggers  add
  constraint pk_GlobalBatch_qrtz_fired_triggers primary key 
  (
    sched_name,
    entry_id
  );
 
alter table SmartPRAGlobalBatch.qrtz_paused_trigger_grps  add
  constraint pk_GlobalBatch_qrtz_paused_trigger_grps primary key 
  (
    sched_name,
    trigger_group
  );
 
alter table SmartPRAGlobalBatch.qrtz_scheduler_state  add
  constraint pk_GlobalBatch_qrtz_scheduler_state primary key 
  (
    sched_name,
    instance_name
  );
 
alter table SmartPRAGlobalBatch.qrtz_locks  add
  constraint pk_GlobalBatch_qrtz_locks primary key 
  (
    sched_name,
    lock_name
  );
 
alter table SmartPRAGlobalBatch.qrtz_job_details  add
  constraint pk_GlobalBatch_qrtz_job_details primary key 
  (
    sched_name,
    job_name,
    job_group
  );
 
alter table SmartPRAGlobalBatch.qrtz_simple_triggers  add
  constraint pk_GlobalBatch_qrtz_simple_triggers primary key 
  (
    sched_name,
    trigger_name,
    trigger_group
  );
 
alter table SmartPRAGlobalBatch.qrtz_simprop_triggers  add
  constraint pk_GlobalBatch_qrtz_simprop_triggers primary key 
  (
    sched_name,
    trigger_name,
    trigger_group
  );
 
alter table SmartPRAGlobalBatch.qrtz_triggers  add
  constraint pk_GlobalBatch_qrtz_triggers primary key 
  (
    sched_name,
    trigger_name,
    trigger_group
  );

   
COMMIT;