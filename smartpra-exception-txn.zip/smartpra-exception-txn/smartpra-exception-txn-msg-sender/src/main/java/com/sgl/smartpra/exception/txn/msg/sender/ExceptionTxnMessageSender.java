package com.sgl.smartpra.exception.txn.msg.sender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.exception.txn.model.validator.ModelValidator;
import com.sgl.smartpra.mq.producer.Producer;

@Component
public class ExceptionTxnMessageSender implements MessageSender {

	@Autowired
	private Producer producer;

	@Autowired
	private ModelValidator modelValidator;

	public void send(String exchange, String routingKey, ExceptionTransactionModel exceptionTransactionModel,
			ExceptionMasterModel exceptionMasterModel) {
		modelValidator.validate(exceptionTransactionModel, exceptionMasterModel);
		producer.send(exchange, routingKey, exceptionTransactionModel);
	}

}
