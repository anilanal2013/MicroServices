package com.sgl.smartpra.exception.txn.msg.sender;

import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

public interface MessageSender {

	public void send(String exchange, String routingKey, ExceptionTransactionModel exceptionTransactionModel,
			ExceptionMasterModel exceptionMasterModel);
}
