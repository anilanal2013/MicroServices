package com.sgl.smartpra.exception.txn.msg.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.sgl.smartpra.exception.txn.msg.sender.ExceptionTxnMessageSender;
import com.sgl.smartpra.exception.txn.msg.sender.MessageSender;
import com.sgl.smartpra.exception.txn.validator.config.ExceptionTxnValidatorConfig;
import com.sgl.smartpra.mq.configuration.MQProducerConfiguration;

@Configuration
@Import({ MQProducerConfiguration.class, ExceptionTxnValidatorConfig.class })
public class ExceptionTxnMsgSenderConfig {

	@Bean
	public MessageSender messageSender() {
		return new ExceptionTxnMessageSender();
	}
}
