/*
package com.sgl.smartpra.exception.txn.msg.intg.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.sgl.smartpra.exception.txn.msg.config.ExceptionTxnMsgSenderConfig;

@SpringBootApplication
@Import(ExceptionTxnMsgSenderConfig.class)
public class ExceptionTxnMsgSenderTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionTxnMsgSenderTestApplication.class, args);
	}
}
*/
