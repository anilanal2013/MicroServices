/*
package com.sgl.smartpra.exception.txn.msg.intg.test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.sgl.smartpra.exception.master.repository.ExceptionMasterRepository;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.msg.sender.MessageSender;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = ExceptionTxnMsgSenderTestApplication.class)
@ActiveProfiles(profiles="DEV")
//@ActiveProfiles(profiles="local")
public class MessageSenderIntegrationTest {

	@Autowired
	private MessageSender messageSender;

	@Value("${rabbitmq.exchange}")
	private String exchange;

	@Value("${rabbitmq.exception.msg.routingKey}")
	private String routingKey;

	@Autowired
	private ExceptionMasterRepository exceptionMasterRepository;

	private String EXCEPTION_CODE_STRING = RandomStringUtils.randomAlphanumeric(8);
	
	@Before
	public void insertExceptionMasterRecord() {
		ExceptionMasterEntity exceptionMasterEntity = prepareExceptionMasterEntity();
		List<ExceptionParametersDefinitionEntity> parametersDefinitionEntityList = new ArrayList<>();
		parametersDefinitionEntityList.add(prepareParametersDefinitionEntity(exceptionMasterEntity));
		exceptionMasterEntity.setParametersDefinitionEntityList(parametersDefinitionEntityList);
		exceptionMasterRepository.save(exceptionMasterEntity);
		System.out.println(exceptionMasterEntity);
	}

	private ExceptionMasterEntity prepareExceptionMasterEntity() {
		ExceptionMasterEntity exceptionMasterEntity = new ExceptionMasterEntity();
		exceptionMasterEntity.setExceptionMasterId(1);
		exceptionMasterEntity.setCreatedBy("INTG-TEST");
		exceptionMasterEntity.setExceptionAction("CountryName error is fixed");
		exceptionMasterEntity.setExceptionCategory("B");
		exceptionMasterEntity.setExceptionCause("CountryName is incorrect");
		exceptionMasterEntity.setExceptionDesc("CountryName is Invalid");
		exceptionMasterEntity.setExceptionSeverity("S");
		exceptionMasterEntity.setExceptionType("E");
		exceptionMasterEntity.setExpectedResolutionTime(10);
		exceptionMasterEntity.setExceptionCode(EXCEPTION_CODE_STRING);
		exceptionMasterEntity.setLovId(636);
		exceptionMasterEntity.setScreenId(1);
		exceptionMasterEntity.setVisible(true);
		
		return exceptionMasterEntity;
	}

	private ExceptionParametersDefinitionEntity prepareParametersDefinitionEntity(
			ExceptionMasterEntity exceptionMasterEntity) {
		ExceptionParametersDefinitionEntity parametersDefinitionEntity = new ExceptionParametersDefinitionEntity();
		parametersDefinitionEntity.setParameterName("countryName");
		parametersDefinitionEntity.setParameterType("P");
		parametersDefinitionEntity.setCreatedBy("INTG-TEST");
		parametersDefinitionEntity.setParameterDefinitionId(1);
		parametersDefinitionEntity.setExceptionMasterEntity(exceptionMasterEntity);
		return parametersDefinitionEntity;
	}

	public ExceptionTransactionModel prepareExceptionTransactionModel() {
	*/
/*	ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setExceptionCode(EXCEPTION_CODE_STRING);
		exceptionTransactionModel.setClientId("1");
		exceptionTransactionModel.setOrderId(String.valueOf(2));// for future use
		exceptionTransactionModel.setCouponNumber(1);
		exceptionTransactionModel.setCreatedBy("INTG-TEST");
		exceptionTransactionModel.setDocumentNumber("1234");
		exceptionTransactionModel.setEnvironment("S");
		exceptionTransactionModel.setExceptionDetails("Country Name is Invalid");
		exceptionTransactionModel.setExceptionStatus(ExceptionStatusEnum.NEW);
		exceptionTransactionModel.setExceptionTime(new java.sql.Timestamp(Calendar.getInstance().getTimeInMillis()));
		exceptionTransactionModel.setExceptionTransactionId(1L);
		exceptionTransactionModel.setIssuedCarrier("ETH");
		exceptionTransactionModel.setResolutionCode("1234");
		exceptionTransactionModel.setResolutionRemarks("CountryName is fixed");
		exceptionTransactionModel.setResolutionTime(10);
		exceptionTransactionModel.setExceptionType("E");

		List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
		ExceptionParametersValueModel parametersValueModel = new ExceptionParametersValueModel();
		parametersValueModel.setParameterName("countryName");
		parametersValueModel.setParameterValue("INDIA");
		parametersValueModelList.add(parametersValueModel);
		exceptionTransactionModel.setParametersValueList(parametersValueModelList);*//*


		return null;
	}

	@Test
	public void testExceptionTxnMsgSender() {
		*/
/*try {
			messageSender.send(exchange, routingKey, prepareExceptionTransactionModel());
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(e.toString());
		}*//*

	}
}
*/
