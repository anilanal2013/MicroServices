package com.sgl.smartpra.exception.txn.enums;

public enum AssignmentTypeEnum {

	AUTO("A"), MANUAL("M"), PULL_PUSH("P");

	private String assignmentTypeValue;

	private AssignmentTypeEnum(String assignmentTypeValue) {
		this.assignmentTypeValue = assignmentTypeValue;
	}

	public String getAssignmentTypeValue() {
		return assignmentTypeValue;
	}
}
