package com.sgl.smartpra.exception.txn.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ExceptionTxnClosedModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<Long> transactionIds;
	
	private String aggregationId;
	
	private String lastUpdatedBy;

	private Boolean isForceClosed;

	private String forceClosedRemarks;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime lastUpdatedDate;

	private String invoiceUrn;

	private String exceptionTransactionType;


}
