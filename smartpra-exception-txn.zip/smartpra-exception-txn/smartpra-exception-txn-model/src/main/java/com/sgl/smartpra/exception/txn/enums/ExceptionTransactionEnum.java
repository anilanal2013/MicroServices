package com.sgl.smartpra.exception.txn.enums;

public enum ExceptionTransactionEnum {

    BSP("B"), AMADEUS("A"), ARC("R"),
    SSIM("S"), TAX("T"), ACCOUNTING("V"),
    MISC("M");

    private String transactionTypeEnum;

    public String getExceptionTypeValue() {
        return transactionTypeEnum;
    }

    private ExceptionTransactionEnum(String transactionTypeEnum) {
        this.transactionTypeEnum = transactionTypeEnum;
    }

}
