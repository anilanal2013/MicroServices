package com.sgl.smartpra.exception.txn.enums.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.sgl.smartpra.exception.txn.enums.ExceptionCategoryEnum;

@Converter
public class ExceptionCategoryEnumConverter implements AttributeConverter<ExceptionCategoryEnum, String> {

	@Override
	public String convertToDatabaseColumn(ExceptionCategoryEnum attribute) {
		return attribute.getExceptionCategoryValue();
	}

	@Override
	public ExceptionCategoryEnum convertToEntityAttribute(String dbData) {
		ExceptionCategoryEnum[] exceptionCategoryEnums = ExceptionCategoryEnum.values();
		for (int i = 0; i < exceptionCategoryEnums.length; i++) {
			if (exceptionCategoryEnums[i].getExceptionCategoryValue().equalsIgnoreCase(dbData)) {
				return exceptionCategoryEnums[i];
			}
		}
		return null;
	}
}
