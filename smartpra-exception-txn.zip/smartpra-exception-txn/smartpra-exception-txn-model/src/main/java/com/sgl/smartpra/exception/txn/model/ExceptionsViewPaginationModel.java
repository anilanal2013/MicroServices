package com.sgl.smartpra.exception.txn.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ExceptionsViewPaginationModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<? extends ExceptionsViewModel> exceptionsViewModelList;

	private long totalCount;

}
