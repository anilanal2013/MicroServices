package com.sgl.smartpra.exception.txn.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sgl.smartpra.exception.txn.enums.ExceptionCategoryEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionSeverityEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionTypeEnum;
import lombok.Data;

import javax.persistence.Id;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class ExceptionsViewModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private Long exceptionTransId;

	private Integer moduleId;

	private String moduleName;

	private String issueAirline;

	private String airlineType;

	private String exceptionCode;

	private ExceptionTypeEnum exceptionType;

	private Integer exceptionMasterId;

	private String exceptionDetails;

	private Integer aging;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime exceptionDate;

	private ExceptionSeverityEnum exceptionSeverity;

	private String mainDocument;

	private String originalDocument;

	private String conjunctionDocument;

	private Integer couponNumber;

	private String documentUniqueId;

	private Long fileId;

	private String environment;

	private String assignedTo;

	private ExceptionCategoryEnum exceptionCategory;

	private String isForceClosed;



}
