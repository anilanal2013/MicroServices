package com.sgl.smartpra.exception.txn.model;

import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ExceptionTxnAggregationModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private String aggregationId;

	private Integer exceptionMasId;

	private ExceptionStatusEnum exceptionStatus;

	private Integer units;

	private String createdBy;

	private String lastUpdatedBy;

	private List<Long> transactionIds;

	private AssignmentTypeEnum assignmentType;

	private Long groupId;

	private Long teamId;

	private Long userId;
	
	private Boolean approvalRequired;
	
	private String clientId;

    private Integer moduleLovId;

	private String assignedBy;

	private LocalDateTime assignedDate;


}
