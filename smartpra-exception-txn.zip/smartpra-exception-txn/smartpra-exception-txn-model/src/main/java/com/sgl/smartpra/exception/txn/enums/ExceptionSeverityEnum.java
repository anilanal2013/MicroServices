package com.sgl.smartpra.exception.txn.enums;

public enum ExceptionSeverityEnum {
	
	SIMPLE ("S"), MEDIUM ("M"), COMPLEX ("C");

	private String exceptionTypeValue;

	public String getExceptionTypeValue() {
		return exceptionTypeValue;
	}

	private ExceptionSeverityEnum(String exceptionTypeValue) {
		this.exceptionTypeValue = exceptionTypeValue;
	}

}
