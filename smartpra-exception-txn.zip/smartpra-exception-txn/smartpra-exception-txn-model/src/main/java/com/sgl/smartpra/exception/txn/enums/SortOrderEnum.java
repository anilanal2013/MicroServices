package com.sgl.smartpra.exception.txn.enums;

public enum SortOrderEnum {

	ASCENDING("ASC"), DESCENDING("DESC");

	private String sortOrderValue;

	public String getSortOrderValue() {
		return sortOrderValue;
	}

	private SortOrderEnum(String sortOrderValue) {
		this.sortOrderValue = sortOrderValue;
	}

}
