package com.sgl.smartpra.exception.txn.model;

import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class ExceptionTxnWIPModel extends ExceptionTxnBaseModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long exceptionTransactionId;

	private String environment;

	private String clientId;

	private Integer orderId;

	private AssignmentTypeEnum assignedType;

	private String issuedCarrier;

	private String mainDocument;

	private String originalDocument;

	private String conjunctionDocument;

	private Integer couponNumber;

	private String documentUniqueId;

	private Integer fileId;

	private String exceptionDetails;

	private ExceptionStatusEnum exceptionStatus;

	private LocalDateTime exceptionDate;

	private String filetypeMapping;

	private Long groupId;

	private Long teamId;

	private Long userId;

	private String aggregationId;

	private Boolean isApprovedRequired;

	private Long approverTeamId;

	private Long approverGroupId;

	private Long approverUserId;

	private LocalDateTime assignedDate;

	private String assignedBy;

	private Integer exceptionMasterId;

	private String batchKey1;

	private String batchKey2;

	private String batchKey3;

	private String batchKey4;

	private LocalDateTime batchKey5;

	private LocalDateTime batchKey6;

	private String documentNumber;

	private LocalDate dateOfIssue;

	private String pnr;

	private Long stagingReferenceId;

	private String createdBy;

	private LocalDateTime createdDate;

	private String lastUpdatedBy;

	private LocalDateTime lastupdatedDate;

	private String invoiceUrn;

	private String exceptionSeverity;

	private String exceptionType;

	private Long inwardTransactionId;

	private String inwardTransactionType;

	private String exceptionTransactionType;
}

