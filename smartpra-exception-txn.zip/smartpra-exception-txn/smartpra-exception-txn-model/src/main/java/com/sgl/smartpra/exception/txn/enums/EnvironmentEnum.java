package com.sgl.smartpra.exception.txn.enums;

public enum EnvironmentEnum {


	STAGING("S"),

	PRODUCTION("P");

	private String environmentValue;

	public String getEnvironmentValue() {
		return environmentValue;
	}

	private EnvironmentEnum(String environmentValue) {
		this.environmentValue = environmentValue;
	}

}
