package com.sgl.smartpra.exception.txn.enums.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.sgl.smartpra.exception.txn.enums.ExceptionSeverityEnum;

@Converter
public class ExceptionSeverityEnumConverter implements AttributeConverter<ExceptionSeverityEnum, String> {

	@Override
	public String convertToDatabaseColumn(ExceptionSeverityEnum attribute) {
		return attribute.getExceptionTypeValue();
	}

	@Override
	public ExceptionSeverityEnum convertToEntityAttribute(String dbData) {
		ExceptionSeverityEnum[] exceptionSeverityEnums = ExceptionSeverityEnum.values();
		for (int i = 0; i < exceptionSeverityEnums.length; i++) {
			if (exceptionSeverityEnums[i].getExceptionTypeValue().equalsIgnoreCase(dbData)) {
				return exceptionSeverityEnums[i];
			}
		}
		return null;
	}
}
