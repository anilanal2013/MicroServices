package com.sgl.smartpra.exception.txn.enums.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.sgl.smartpra.exception.txn.enums.EnvironmentEnum;

@Converter
public class EnvironmentEnumConverter implements AttributeConverter<EnvironmentEnum, String> {

	@Override
	public String convertToDatabaseColumn(EnvironmentEnum attribute) {
		return attribute.getEnvironmentValue();
	}

	@Override
	public EnvironmentEnum convertToEntityAttribute(String dbData) {
		EnvironmentEnum[] environmentEnums = EnvironmentEnum.values();
		for (int i = 0; i < environmentEnums.length; i++) {
			if (environmentEnums[i].getEnvironmentValue().equalsIgnoreCase(dbData)) {
				return environmentEnums[i];
			}
		}
		return null;
	}
}
