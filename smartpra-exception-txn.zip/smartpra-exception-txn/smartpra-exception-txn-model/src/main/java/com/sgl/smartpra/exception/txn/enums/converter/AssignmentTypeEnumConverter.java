package com.sgl.smartpra.exception.txn.enums.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;

@Converter
public class AssignmentTypeEnumConverter implements AttributeConverter<AssignmentTypeEnum, String> {

	@Override
	public String convertToDatabaseColumn(AssignmentTypeEnum attribute) {
		return attribute.getAssignmentTypeValue();
	}

	@Override
	public AssignmentTypeEnum convertToEntityAttribute(String dbData) {
		AssignmentTypeEnum[] assignmentTypeEnums = AssignmentTypeEnum.values();
		for (int i = 0; i < assignmentTypeEnums.length; i++) {
			if (assignmentTypeEnums[i].getAssignmentTypeValue().equalsIgnoreCase(dbData)) {
				return assignmentTypeEnums[i];
			}
		}
		return null;
	}
}
