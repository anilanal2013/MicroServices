package com.sgl.smartpra.exception.txn.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class ExceptionTxnAssignmentModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotEmpty
	private List<Long> transactionIds;

	@NotNull
	private Long groupId;

	private Long teamId;

	private Long userId;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime assignedDate;

	private String assignedBy;

	@NotNull
	@Valid
	private AssignmentTypeEnum assignedType;

	@NotNull
	@Valid
	private ExceptionStatusEnum exceptionStatus;

	private String aggregationId;

	private Long approverGroupId;

	private Long approverTeamId;

	private Long approverUserId;

	private Boolean isApproverRequired;

	private Long stagingReferenceId;

    private Boolean isPullPush;
}
