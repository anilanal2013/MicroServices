package com.sgl.smartpra.exception.txn.constants;

public class SystemParameterConstants {

    public SystemParameterConstants() {
    }

    public static final String PUSH_PULL_MECHANISM = "PUSH_PULL_MECHANISM";


}
