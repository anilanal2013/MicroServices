package com.sgl.smartpra.exception.txn.enums;

public enum ExceptionTypeEnum {

	ERROR("E"), WARNING("W"), INFORMATIVE("I");

	private String exceptionTypeValue;

	public String getExceptionTypeValue() {
		return exceptionTypeValue;
	}

	private ExceptionTypeEnum(String exceptionTypeValue) {
		this.exceptionTypeValue = exceptionTypeValue;
	}

}
