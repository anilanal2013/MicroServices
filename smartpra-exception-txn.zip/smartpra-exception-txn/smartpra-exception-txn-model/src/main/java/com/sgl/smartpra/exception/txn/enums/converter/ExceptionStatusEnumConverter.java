package com.sgl.smartpra.exception.txn.enums.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;

@Converter
public class ExceptionStatusEnumConverter implements AttributeConverter<ExceptionStatusEnum, String> {

	@Override
	public String convertToDatabaseColumn(ExceptionStatusEnum attribute) {
		return attribute.getExceptionStatusValue();
	}

	@Override
	public ExceptionStatusEnum convertToEntityAttribute(String dbData) {
		ExceptionStatusEnum[] exceptionStatusEnums = ExceptionStatusEnum.values();
		for (int i = 0; i < exceptionStatusEnums.length; i++) {
			if (exceptionStatusEnums[i].getExceptionStatusValue().equalsIgnoreCase(dbData)) {
				return exceptionStatusEnums[i];
			}
		}
		return null;
	}
}
