package com.sgl.smartpra.exception.txn.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sgl.smartpra.exception.txn.enums.*;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

@Data
public class ExceptionTxnSearchModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer moduleId;

	@NotNull
	@Valid
	private ModuleNameEnum moduleName;

	@Valid
	private ExceptionStatusEnum exceptionStatus;
	
	private ExceptionCategoryEnum exceptionCategory;

	private String environment;
	
	private ExceptionTypeEnum exceptionType;

	private Long groupId;

	private Long teamId;

	private Long userId;
	
	private Integer aging;

	private String airlineType;
	
	private String exceptionCode;

	private String documentUniqueId;

	private String couponNumber;
	
	private String isForceClosed;

	@Valid
	private ExceptionSeverityEnum exceptionSeverity;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate fromDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate toDate;

	@Valid
	private SortOrderEnum sortOrder;

	private String agencyCode;

	private String batchType;

	private String batchNumber;

	private String reportingCurrency;
 
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate fromReportingPeriod;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate toReporingPeriod;

	private String flightNumber;

	private String fromAirport;

	private String toAirport;

	private String upliftStation;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate departureDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate flightCreationDate;

	private String countryCode;
	
	private String billingCarrier;

	private String billedCarrier;

	private String sourceCode;

	private String invoiceNo;

    private String chargeCategory;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate invoiceDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate billingDate;

	private Long stagingReferenceId;


}
