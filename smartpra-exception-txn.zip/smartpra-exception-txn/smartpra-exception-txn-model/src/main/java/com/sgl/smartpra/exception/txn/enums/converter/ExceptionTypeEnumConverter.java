package com.sgl.smartpra.exception.txn.enums.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.sgl.smartpra.exception.txn.enums.ExceptionTypeEnum;

@Converter
public class ExceptionTypeEnumConverter implements AttributeConverter<ExceptionTypeEnum, String> {

	@Override
	public String convertToDatabaseColumn(ExceptionTypeEnum attribute) {
		return attribute.getExceptionTypeValue();
	}

	@Override
	public ExceptionTypeEnum convertToEntityAttribute(String dbData) {
		ExceptionTypeEnum[] exceptionTypeEnums = ExceptionTypeEnum.values();
		for (int i = 0; i < exceptionTypeEnums.length; i++) {
			if (exceptionTypeEnums[i].getExceptionTypeValue().equalsIgnoreCase(dbData)) {
				return exceptionTypeEnums[i];
			}
		}
		return null;
	}
}
