package com.sgl.smartpra.exception.txn.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Optional;

@Data
public class ExceptionTxnClosedSearchModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long exceptionTransactionId;

    private Optional<Integer> couponNumber;

    private Optional<String> documentUniqueId;

    private Optional<Boolean> isForceClosed;

    private Optional<String> exceptionCode;
}
