package com.sgl.smartpra.exception.txn.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExceptionTransactionModel extends ExceptionTxnBaseModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long exceptionTransactionId;

	@NotEmpty
	private String exceptionCode;

	@NotEmpty
	private String environment;

	@NotEmpty
	private String clientId;

	private String orderId;

	private String issuedCarrier;

	private String mainDocument;

	private String originalDocument;

	private String conjunctionDocument;

	private Integer couponNumber;

	private String documentUniqueId;

	private Long fileId;

	private String fileTypeMapping;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime exceptionDate;

	private Integer exceptionMasterId;

	private List<ExceptionParametersValueModel> parametersValueList;

	private String createdBy;

	private String lastUpdatedBy;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime createdDate;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime lastUpdatedDate;

	private String batchKey1;

	private String batchKey2;

	private String batchKey3;

	private String batchKey4;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime batchKey5;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime batchKey6;

	private String documentNumber;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate dateOfIssue;

	private String pnr;

	private Long stagingReferenceId;
	
	private String invoiceUrn;

	private String exceptionSeverity;

	private String exceptionType;

	private Long accountingTransactionId;

	private Long inwardTransactionId;

	private String inwardTransactionType;

	private String exceptionTransactionType;


}
