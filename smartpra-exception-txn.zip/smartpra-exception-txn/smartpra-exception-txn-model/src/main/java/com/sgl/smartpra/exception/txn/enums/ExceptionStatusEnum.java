package com.sgl.smartpra.exception.txn.enums;

public enum ExceptionStatusEnum {

	TRANSFERRED("T"),
	ASSIGNED("A"),
	WORK_IN_PROGRESS("W"),
	CLOSED("C"),
	FORCE_CLOSED("F"),
	SYSTEM_FORCE_CLOSED("S"),
	HOLD("H");

	private String exceptionStatusValue;

	public String getExceptionStatusValue() {
		return exceptionStatusValue;
	}

	private ExceptionStatusEnum(String exceptionStatusValue) {
		this.exceptionStatusValue = exceptionStatusValue;
	}

}
