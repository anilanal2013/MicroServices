package com.sgl.smartpra.exception.txn.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = false)
public class MiscExceptionsViewModel extends ExceptionsViewModel {

    private static final long serialVersionUID = 1L;

    private String billingCarrier;

    private String billedCarrier;

    private String chargeCategory;

    private String invoiceNo;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime invoiceDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime billingDate;

    private Long groupId;

    private Long teamId;

    private Long userId;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime assignedDate;

    private String assignedBy;

    private String aggregationId;

}
