package com.sgl.smartpra.exception.txn.enums;

public enum AggregationLevelEnum {

    LEVEL_1("1"), SALES("2"), FLOWN("3"), INWARD("4"), OUTWARD("5"), MISC("6");

    private String aggregationLevel;

    private AggregationLevelEnum(String aggregationLevel) {
        this.aggregationLevel = aggregationLevel;
    }

    public String getAggregationLevel() {
        return aggregationLevel;
    }
}
