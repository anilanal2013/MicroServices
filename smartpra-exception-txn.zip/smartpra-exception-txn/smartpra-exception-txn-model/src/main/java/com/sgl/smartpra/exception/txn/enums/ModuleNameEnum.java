package com.sgl.smartpra.exception.txn.enums;

public enum ModuleNameEnum {

    SALE, FLOWN, INWARD, OUTWARD, MISC, PRORATION, GENERAL
}
