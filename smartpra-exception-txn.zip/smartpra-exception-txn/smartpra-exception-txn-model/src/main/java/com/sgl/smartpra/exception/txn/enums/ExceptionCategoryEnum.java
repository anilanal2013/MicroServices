package com.sgl.smartpra.exception.txn.enums;

public enum ExceptionCategoryEnum {

	BUSINESS("B"), CLIENT_MASTER("C"), TECHNICAL("L"), TICKET_DATA("T"), SYSTEM("S");

	private String exceptionCategoryValue;

	public String getExceptionCategoryValue() {
		return exceptionCategoryValue;
	}

	public void setExceptionCategoryValue(String exceptionCategoryValue) {
		this.exceptionCategoryValue = exceptionCategoryValue;
	}

	private ExceptionCategoryEnum(String exceptionCategoryValue) {
		this.exceptionCategoryValue = exceptionCategoryValue;
	}

}
