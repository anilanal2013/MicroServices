package com.sgl.smartpra.exception.txn.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ProrationExceptionsViewModel extends ExceptionsViewModel {
	
	private static final long serialVersionUID = 1L;
	
	private Long groupId;

	private Long teamId;

	private Long userId;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDateTime assignedDate;

	private String assignedBy;

	private String aggregationId;

}
