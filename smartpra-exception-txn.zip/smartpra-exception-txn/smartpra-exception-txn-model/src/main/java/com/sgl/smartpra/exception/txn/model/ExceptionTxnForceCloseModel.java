package com.sgl.smartpra.exception.txn.model;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class ExceptionTxnForceCloseModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long exceptionTransactionId;

    private Integer exceptionMasterId;

    private String exceptionCode;

    private String documentUniqueId;

    private Integer couponNumber;

    private String remarks;

    private Integer taskId;

    private Boolean taskForceClosed;

    private Boolean exceptionForceClosed;

}
