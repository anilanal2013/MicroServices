package com.sgl.smartpra.exception.txn.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper= false)
public class InwardExceptionsViewModel extends ExceptionsViewModel {

	private static final long serialVersionUID = 1L;
	
	private String billingCarrier;

	private String billedCarrier;

	private String sourceCode;

	private String invoiceNo;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDateTime invoiceDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDateTime billingDate;
	
	private Long groupId;

	private Long teamId;

	private Long userId;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDateTime assignedDate;

	private String assignedBy;

	private String aggregationId;
	
	

}
