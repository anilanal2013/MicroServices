package com.sgl.smartpra.exception.txn.app.mapper;

import com.sgl.smartpra.common.validator.Equal;
import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnForceCloseModel;
import org.mapstruct.*;

import java.util.List;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionTxnForceClosedMapper {

   public ExceptionTransactionEntity mapToExceptionTransactionEntity(ExceptionTxnForceCloseModel exceptionTxnForceCloseModel);

    public ExceptionTxnWipEntity mapToExceptionTransactionWipEntity(ExceptionTxnForceCloseModel exceptionTxnForceCloseModel);


}
