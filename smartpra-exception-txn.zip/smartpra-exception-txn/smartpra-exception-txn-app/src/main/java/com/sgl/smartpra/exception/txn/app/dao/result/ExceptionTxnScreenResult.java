package com.sgl.smartpra.exception.txn.app.dao.result;

import lombok.Data;

import java.io.Serializable;

@Data
public class ExceptionTxnScreenResult implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long screenId;
    private Long exceptionTransactionId;
    private String documentUniqueId;
    private String exceptionDetails;
    private Long exceptionMasId;
    private String clientId;
    private String isApprovalRequired;
    private String invoiceUrn;
    private Long couponNumber;
    private Integer moduleLovId;
    private String fieldValue;

    public ExceptionTxnScreenResult(Long screenId, Long exceptionTransactionId, String documentUniqueId, String exceptionDetails, Long exceptionMasId, String clientId, String isApprovalRequired, String invoiceUrn, Long couponNumber, Integer moduleLovId, String fieldValue) {
        this.screenId = screenId;
        this.exceptionTransactionId = exceptionTransactionId;
        this.documentUniqueId = documentUniqueId;
        this.exceptionDetails = exceptionDetails;
        this.exceptionMasId = exceptionMasId;
        this.clientId = clientId;
        this.isApprovalRequired = isApprovalRequired;
        this.invoiceUrn = invoiceUrn;
        this.couponNumber = couponNumber;
        this.moduleLovId = moduleLovId;
        this.fieldValue = fieldValue;
    }
}
