package com.sgl.smartpra.exception.txn.app.dao;

import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ExceptionTxnDao {

	// -------------- GET & FIND -------------------
	public List<ExceptionTransactionEntity> findAllExceptionTxnRecords(List<Long> transactionIds);

	public Optional<ExceptionTransactionEntity> findByExceptionTransactionId(Long exceptionTransactionId);

	public List<ExceptionTransactionEntity> findByExceptionMasterId(Integer exceptionMasterId);

	public boolean existsById(Long exceptionTransactionId);

	public ExceptionTransactionEntity getOne(Long exceptionTransactionId);

    public List<ExceptionTransactionEntity> findAll(Example<ExceptionTransactionEntity> exceptionTransactionEntityExample);

	// ----------- CREATE OR UPDATE------------

	public ExceptionTransactionEntity save(ExceptionTransactionEntity exceptionTransactionEntity);
	// ----------- DELETE -------------

	public void deleteByExceptionTransactionId(Long exceptionTransactionId);

    public void deleteByDocumentUniqueIdAndCouponNumber(String documentUniqueId, Integer couponNumber);

	public void deleteExceptionTxnRecords(List<ExceptionTransactionEntity> exceptionTransactionEntityList);

	public List<ExceptionTransactionEntity> deleteExceptionTxnRecords(Long fileId);
	// ----------- Manual TL Ops Board --------------------------
	long getSaleOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);

	long getFlownOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);

	long getInwardOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);

	long getOutwardOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);

    long getMiscOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
    
    long getProrationOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
    
    long getGeneralOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);

	public Page<SaleOpenExceptionsEntity> searchSaleOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

	public Page<FlownOpenExceptionsEntity> searchFlownOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

	public Page<InwardOpenExceptionsEntity> searchInwardOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

	public Page<OutwardOpenExceptionsEntity> searchOutwardOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

    public Page<MiscOpenExceptionsEntity> searchMiscOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

    public Page<ProrationOpenExceptionsEntity> searchProrationOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

    public Page<GeneralOpenExceptionsEntity> searchGeneralOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

    public List<SaleOpenExceptionsEntity> searchSaleOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    public List<FlownOpenExceptionsEntity> searchFlownOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    public List<InwardOpenExceptionsEntity> searchInwardOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    public List<OutwardOpenExceptionsEntity> searchOutwardOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    public List<MiscOpenExceptionsEntity> searchMiscOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    public List<ProrationOpenExceptionsEntity> searchProrationOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    public List<GeneralOpenExceptionsEntity> searchGeneralOpenExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    List<ExceptionTransactionEntity> aggregateByExceptionCodeAndDescription(List<Long> transactionIds);

	Page<ExceptionTransactionEntity> getAllOpenExceptions(ExceptionTransactionEntity exceptionTransactionModel, Pageable pageable);

    List<SaleOpenExceptionsEntity> aggregateSalesException(List<Long> transactionIds);

    Page<ExceptionTransactionEntity> findAllExceptionTxnId(int exceptionCount);

	long getAllOpenExceptionTxnCount(ExceptionTransactionEntity transactionModel);

}
