package com.sgl.smartpra.exception.txn.app.dao.repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.OutwardOpenExceptionsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OutwardOpenExceptionsRepository
        extends JpaRepository<OutwardOpenExceptionsEntity, Long>, JpaSpecificationExecutor<OutwardOpenExceptionsEntity> {

    public List<OutwardOpenExceptionsEntity> findByModuleId(Integer moduleId);

}
