package com.sgl.smartpra.exception.txn.app.dao.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Immutable
@Table(name = "INWARD_CLOSED_EXCEPTIONS_VIEW", schema = "dbo")
public class InwardClosedExceptionsEntity  extends ExceptionsViewEntity {
	
	private static final long serialVersionUID = 1L;

	@Column(name = "key_1")
	private String billingCarrier;

	@Column(name = "key_2")
	private String billedCarrier;

	@Column(name = "key_3")
	private String sourceCode;

	@Column(name = "key_4")
	private String invoiceNo;

	@Column(name = "key_5")
	private LocalDateTime invoiceDate;

	@Column(name = "key_6")
	private LocalDateTime billingDate;
	
	private Long groupId;

	private Long teamId;

	private Long userId;
	
	@Column(name="created_date")
	private LocalDateTime assignedDate;
	
	@Column(name="created_by")
	private String assignedBy;
	
	private String aggregationId;
	
	private LocalDateTime lastUpdatedDate;
	
	private String lastUpdatedBy;

    private String airlineType;

	private String  isForceClosed;


}
