package com.sgl.smartpra.exception.txn.app.dao.repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.MiscClosedExceptionsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface MiscClosedExceptionsRepository
        extends JpaRepository<MiscClosedExceptionsEntity, Long>, JpaSpecificationExecutor<MiscClosedExceptionsEntity> {


}
