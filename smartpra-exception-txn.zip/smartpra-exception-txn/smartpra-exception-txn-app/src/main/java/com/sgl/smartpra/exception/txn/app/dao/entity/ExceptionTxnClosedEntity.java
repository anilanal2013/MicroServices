package com.sgl.smartpra.exception.txn.app.dao.entity;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.enums.converter.AssignmentTypeEnumConverter;
import com.sgl.smartpra.exception.txn.enums.converter.ExceptionStatusEnumConverter;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "exception_transaction_closed", schema = "SmartPRAException")
@Getter
@Setter
@DynamicUpdate
@DynamicInsert
@ToString(callSuper = false)
public class ExceptionTxnClosedEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "exception_trans_id", nullable = false)
	private Long exceptionTransactionId;

	private String environment;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "order_id")
	private Integer orderId;

	@Column(name = "assigned_type")
	@Convert(converter = AssignmentTypeEnumConverter.class)
	private AssignmentTypeEnum assignedType;

	@Column(name = "issued_carrier")
	private String issuedCarrier;

	private String mainDocument;

	private String originalDocument;

	private String conjunctionDocument;

	@Column(name = "coupon_number")
	private Integer couponNumber;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	@Column(name = "file_id")
	private Integer fileId;

	@Column(name = "exception_details")
	private String exceptionDetails;

	@Column(name = "exception_status")
	@Convert(converter = ExceptionStatusEnumConverter.class)
	private ExceptionStatusEnum exceptionStatus;

	@Column(name = "exception_date")
	private LocalDateTime exceptionDate;

	@Column(name = "filetype_mapping")
	private String filetypeMapping;

	@Column(name = "group_id")
	private Long groupId;

	@Column(name = "team_id")
	private Long teamId;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "aggregation_id")
	private String aggregationId;

	@Column(name = "is_approved_required")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isApprovedRequired;

	@Column(name = "approver_team_id")
	private Long approverTeamId;

	@Column(name = "approver_group_id")
	private Long approverGroupId;

	@Column(name = "approver_user_id")
	private Long approverUserId;

	@Column(name = "assigned_date")
	private LocalDateTime assignedDate;

	@Column(name = "assigned_by")
	private String assignedBy;

	@Column(name = "exception_mas_id")
	private Integer exceptionMasterId;

	@Column(name = "key_1")
	private String batchKey1;

	@Column(name = "key_2")
	private String batchKey2;

	@Column(name = "key_3")
	private String batchKey3;

	@Column(name = "key_4")
	private String batchKey4;

	@Column(name = "key_5")
	private LocalDateTime batchKey5;

	@Column(name = "key_6")
	private LocalDateTime batchKey6;

	private String documentNumber;

	private LocalDate dateOfIssue;

	private String pnr;

	private Long stagingReferenceId;

    private String invoiceUrn;

    @Column(name = "is_force_closed")
    @Convert(converter = BooleanToStringConverter.class)
    private Boolean isForceClosed;

    @Column(name = "force_closed_remarks")
    private String forceClosedRemarks;

	@Column(name = "accounting_transaction_id")
	private Long accountingTransactionId;

	@Column(name = "inward_transaction_id")
	private Long inwardTransactionId;

	@Column(name = "inward_transaction_type")
	private String inwardTransactionType;

	@Column(name = "exception_transaction_type")
	private String exceptionTransactionType;

}
