package com.sgl.smartpra.exception.txn.app.dao.spec;

import com.sgl.smartpra.exception.txn.app.dao.entity.MiscOpenExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class MiscOpenExceptionsEntitySpec {

    private MiscOpenExceptionsEntitySpec() {

    }

    public static Specification<MiscOpenExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return (miscOpenExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (exceptionTxnSearchModel.getModuleId() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("moduleId"),
                        exceptionTxnSearchModel.getModuleId()));
            }

            if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("exceptionSeverity"),
                        exceptionTxnSearchModel.getExceptionSeverity()));
            }
            if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("exceptionSeverity"),
                        exceptionTxnSearchModel.getExceptionSeverity()));
            }

            //Advanced Parameters starts here
            if (exceptionTxnSearchModel.getBillingCarrier() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("billingCarrier"),
                        exceptionTxnSearchModel.getBillingCarrier()));
            }
            if (exceptionTxnSearchModel.getBilledCarrier() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("billedCarrier"),
                        exceptionTxnSearchModel.getBilledCarrier()));
            }
            if (exceptionTxnSearchModel.getChargeCategory() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("chargeCategory"),
                        exceptionTxnSearchModel.getChargeCategory()));
            }

            if (exceptionTxnSearchModel.getInvoiceNo() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("invoiceNo"),
                        exceptionTxnSearchModel.getInvoiceNo()));
            }
            if (exceptionTxnSearchModel.getInvoiceDate() != null) {
                predicates.add(criteriaBuilder.between(miscOpenExceptionsEntity.get("invoiceDate"),
                        exceptionTxnSearchModel.getInvoiceDate().atStartOfDay(),
                        exceptionTxnSearchModel.getInvoiceDate().atTime(LocalTime.MAX)));
            }

            if (exceptionTxnSearchModel.getBillingDate() != null) {
                predicates.add(criteriaBuilder.between(miscOpenExceptionsEntity.get("billingDate"),
                        exceptionTxnSearchModel.getBillingDate().atStartOfDay(), exceptionTxnSearchModel.getBillingDate().atTime(LocalTime.MAX)));
            }

            if (exceptionTxnSearchModel.getAging() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("aging"),
                        exceptionTxnSearchModel.getAging()));
            }

            if (exceptionTxnSearchModel.getEnvironment() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("environment"),
                        exceptionTxnSearchModel.getEnvironment()));
            }

            if (exceptionTxnSearchModel.getExceptionCategory() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("exceptionCategory"),
                        exceptionTxnSearchModel.getExceptionCategory()));
            }

            if (exceptionTxnSearchModel.getExceptionType() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("exceptionType"),
                        exceptionTxnSearchModel.getExceptionType()));
            }

            if (exceptionTxnSearchModel.getExceptionCode() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("exceptionCode"),
                        exceptionTxnSearchModel.getExceptionCode()));
            }
            if (exceptionTxnSearchModel.getStagingReferenceId() != null) {
                predicates.add(criteriaBuilder.equal(miscOpenExceptionsEntity.get("stagingReferenceId"),
                        exceptionTxnSearchModel.getStagingReferenceId()));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));

        };
    }
}