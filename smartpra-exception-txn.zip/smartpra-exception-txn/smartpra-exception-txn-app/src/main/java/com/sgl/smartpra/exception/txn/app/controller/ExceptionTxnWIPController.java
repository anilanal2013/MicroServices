package com.sgl.smartpra.exception.txn.app.controller;

import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnWIPService;
import com.sgl.smartpra.exception.txn.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/wip")
public class ExceptionTxnWIPController {

	@Autowired
	private ExceptionTxnWIPService exceptionTxnWIPService;

	@PostMapping
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void createWip(@RequestBody @Valid ExceptionTxnAssignmentModel exceptionTxnAssignmentModel) {
		exceptionTxnWIPService.sendToExceptionTxnAssignmentQueue(exceptionTxnAssignmentModel);
	}

	@PutMapping
	public void updateExpTxnWIPRecord(@RequestBody @Valid ExceptionTxnAggregationModel exceptionTxnAggregationModel) {
		exceptionTxnWIPService.updateExceptionTxnWIPRecords(exceptionTxnAggregationModel);
	}

	@GetMapping("/findByAggregationId/{aggregationId}")
	public List<ExceptionTxnWIPModel> getExceptionTxnWIPRecords(@PathVariable("aggregationId") String aggregationId) {
		return exceptionTxnWIPService.getExceptionTxnWIPRecords(aggregationId);
	}

	@PostMapping(path = "/searchWIPExceptions")
	public ExceptionsViewPaginationModel searchExceptionTxnWIPRecords(Pageable pageable,
			@RequestBody ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return exceptionTxnWIPService.searchExceptionTxnWIPRecords(pageable, exceptionTxnSearchModel);
	}

	@PutMapping(path="/update")
	public void updateWipTxn(@RequestBody List<ExceptionTxnWIPModel> exceptionTxnWIPModel){
		exceptionTxnWIPService.updateWipTxn(exceptionTxnWIPModel);
	}

	@PutMapping("/moveFromExceptionTnxToWip")
	public void moveFromExceptionTnxToWip(@RequestBody ExceptionTxnAggregationModel exceptionTxnAggregationModel){
		exceptionTxnWIPService.moveFromExceptionTnxToWip(exceptionTxnAggregationModel);
	}

	@PutMapping("/reassign/{aggregationId}")
	public void reassignExceptionByAggregationId(@PathVariable("aggregationId") String aggregationId){
		exceptionTxnWIPService.reassignExceptionByAggregationId(aggregationId);
	}

}
