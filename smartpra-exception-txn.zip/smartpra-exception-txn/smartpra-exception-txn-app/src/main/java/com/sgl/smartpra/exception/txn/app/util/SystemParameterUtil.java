package com.sgl.smartpra.exception.txn.app.util;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.model.SystemParameter;

import java.util.List;

public class SystemParameterUtil {

    public SystemParameterUtil() {
    }

    public static boolean isPushPull(List<SystemParameter> systemParameters) {
        if (OptionalUtil.getValue(systemParameters.get(0).getParameterRangeFrom()).equalsIgnoreCase("Y"))
            return true;
        else if (OptionalUtil.getValue(systemParameters.get(0).getParameterRangeFrom()).equalsIgnoreCase("N"))
            return false;
        else
            return true;
    }

}
