package com.sgl.smartpra.exception.txn.app.service.impl;

import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnWipDao;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionTxnAggregatedResult;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionTxnScreenResult;
import com.sgl.smartpra.exception.txn.app.service.ExceptionAggregationService;
import com.sgl.smartpra.exception.txn.enums.AggregationLevelEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotEmpty;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
@Slf4j
public class ExceptionAggregationServiceImpl implements ExceptionAggregationService {

    @Autowired
    ExceptionTxnWipDao exceptionTxnWipDao;


    @Override
    public List<ExceptionTxnAggregatedResult> aggregateExceptionTransactions(@NotEmpty List<Long> transactionIds) {

        List<ExceptionTxnScreenResult> exceptionTransactionList =
                exceptionTxnWipDao.getExceptionTransactionWip(transactionIds);

        List<ExceptionTxnAggregatedResult> aggregatedExceptionList = new ArrayList<>();
        List<ExceptionTxnScreenResult> generalExceptionsList = filterGeneralExceptions(exceptionTransactionList);

        switch (AggregationLevelEnum.values()[0]) {
            case LEVEL_1:
                aggregateByExceptionCodeAndDescription(aggregatedExceptionList, generalExceptionsList);
            case FLOWN:
                aggregateByDocumentUniqueIdAndScreenIdAndCouponId(aggregatedExceptionList, exceptionTransactionList);
            case SALES:
                aggregateByDocumentUniqueIdAndScreenId(aggregatedExceptionList, exceptionTransactionList);
            case MISC:
                aggregateByInvoiceUrnAndScreenId(aggregatedExceptionList, exceptionTransactionList);
                break;
            default:
                throw new IllegalStateException("Unexpected level");
        }

        /** Each of the aggregation levels will not consider exceptions with any of the key parameters as null.
         *  All such exceptions will remain un-aggregated. Also there might be other exceptions which doesn't fit into the aggregation models.
         *  These exceptions will still left behind in exceptionTransactionList and Each of these exceptions will be added as separate aggregated tasks.
         */
        if (!exceptionTransactionList.isEmpty()) {
            exceptionTransactionList.stream().map(exceptionTransaction -> setAggrgateResultModel(exceptionTransaction.getExceptionMasId(),
                    Arrays.asList(exceptionTransaction))).forEach(aggregatedExceptionList::add);
        }

        /**
         * Left over general aggregation list will be added to aggregation list to make it into a single task
         * */
        if (!generalExceptionsList.isEmpty()) {
            generalExceptionsList.stream().map(exceptionTransaction -> setAggrgateResultModel(exceptionTransaction.getExceptionMasId(),
                    Arrays.asList(exceptionTransaction))).forEach(aggregatedExceptionList::add);
        }

        exceptionTransactionList.clear();
        generalExceptionsList.clear();

        return aggregatedExceptionList;
    }

    private List<ExceptionTxnScreenResult> filterGeneralExceptions(List<ExceptionTxnScreenResult> exceptionTransactionList) {
        List<ExceptionTxnScreenResult> exceptionTxnScreenResults = exceptionTransactionList.stream().filter(exceptionTxnScreenResult -> exceptionTxnScreenResult != null && "GL".equalsIgnoreCase(exceptionTxnScreenResult.getFieldValue())).collect(Collectors.toList());
        exceptionTransactionList.removeIf(exceptionTxnScreenResult -> ("GL".equalsIgnoreCase(exceptionTxnScreenResult.getFieldValue())));
        return exceptionTxnScreenResults;
    }


    private void aggregateByInvoiceUrnAndScreenId(List<ExceptionTxnAggregatedResult> aggregatedExceptionList,
                                                  List<ExceptionTxnScreenResult> exceptionTransactionList) {

        Map<String, Map<Long, List<ExceptionTxnScreenResult>>> exceptionWipGroupResultMap = new HashMap<>();

        exceptionTransactionList.stream().filter(exceptionTxnScreenResult -> exceptionTxnScreenResult.getInvoiceUrn() != null &&
                exceptionTxnScreenResult.getScreenId() != null).forEachOrdered(exceptionTxnScreenResult -> exceptionWipGroupResultMap.computeIfAbsent(exceptionTxnScreenResult.getInvoiceUrn(),
                key -> new HashMap<>()).computeIfAbsent(exceptionTxnScreenResult.getScreenId(), k -> new ArrayList<>()).add(exceptionTxnScreenResult));

        exceptionWipGroupResultMap.forEach((exceptionDetails, groupModel) -> groupModel.forEach((exceptionMasterId, exceptionWipModelList)
                -> aggregatedExceptionList.add(setAggrgateResultModel(exceptionMasterId, exceptionWipModelList))
        ));
        getAggregatedTransactionsIds(aggregatedExceptionList, exceptionTransactionList);
    }

    /**
     * @param aggregatedExceptionList
     * @param wipResultList           work contains the current manually un-aggregated exceptions
     * @return function will aggregate the exception and group it into units.
     */
    private void aggregateByExceptionCodeAndDescription(List<ExceptionTxnAggregatedResult> aggregatedExceptionList, List<ExceptionTxnScreenResult> wipResultList) {

        //This function will allow you to group exceptions by exception code and exception description
        Map<String, Map<Long, List<ExceptionTxnScreenResult>>> exceptionWipGroupResultMap =
                wipResultList.stream().collect(Collectors.groupingBy(ExceptionTxnScreenResult::getExceptionDetails,
                        Collectors.groupingBy(ExceptionTxnScreenResult::getExceptionMasId)));

        //Once grouped successfully this will be set into a aggregation model
        exceptionWipGroupResultMap.forEach((exceptionDetails, groupModel) -> groupModel.forEach((exceptionMasterId, exceptionWipModelList)
                -> aggregatedExceptionList.add(setAggrgateResultModel(exceptionMasterId, exceptionWipModelList))
        ));


        getAggregatedTransactionsIds(aggregatedExceptionList, wipResultList);
    }


    private void aggregateByDocumentUniqueIdAndScreenId(List<ExceptionTxnAggregatedResult> aggregatedResultList,
                                                        List<ExceptionTxnScreenResult> wipResultList) {

        Map<String, Map<Long, List<ExceptionTxnScreenResult>>> exceptionWipGroupResultMap =
                new HashMap<>();
        wipResultList.stream().filter(exceptionTxnScreenResult -> exceptionTxnScreenResult.getDocumentUniqueId() != null &&
                exceptionTxnScreenResult.getScreenId() != null).forEachOrdered(exceptionTxnScreenResult ->
                exceptionWipGroupResultMap.computeIfAbsent(exceptionTxnScreenResult.getDocumentUniqueId(),
                        key -> new HashMap<>()).computeIfAbsent(exceptionTxnScreenResult.getScreenId(), k -> new ArrayList<>()).add(exceptionTxnScreenResult));

        exceptionWipGroupResultMap.forEach((exceptionDetails, groupModel) -> groupModel.forEach((exceptionMasterId, exceptionWipModelList)
                -> aggregatedResultList.add(setAggrgateResultModel(exceptionMasterId, exceptionWipModelList))
        ));
        getAggregatedTransactionsIds(aggregatedResultList, wipResultList);
    }


    private List<Long> getAggregatedTransactionsIds(List<ExceptionTxnAggregatedResult> exceptionTxnAggregatedResultList,
                                                    List<ExceptionTxnScreenResult> exceptionWipResult) {
        List<Long> aggregatedTransactionIds = new ArrayList<>();

        //get all transaction ids with 2 units
        exceptionTxnAggregatedResultList.stream().
                filter(exceptionTxnAggregatedResult -> exceptionTxnAggregatedResult.getUnits() >= 2).
                map(ExceptionTxnAggregatedResult::getTransactionIds).forEachOrdered(aggregatedTransactionIds::addAll);

        // remove the aggregated transactions id from wip list
        // so that next level of exceptions can aggregate the non aggregated values
        aggregatedTransactionIds.forEach((Long transactionId) ->
                exceptionWipResult.removeIf(exceptionTxnScreenResult -> exceptionTxnScreenResult.getExceptionTransactionId() == transactionId)
        );
        exceptionTxnAggregatedResultList.removeIf(exceptionTxnAggregatedResult -> exceptionTxnAggregatedResult.getTransactionIds().size() == 1);

        return aggregatedTransactionIds;
    }

    private ExceptionTxnAggregatedResult setAggrgateResultModel(Long exceptionMasterId, List<ExceptionTxnScreenResult> exceptionWipModelList) {
        ExceptionTxnAggregatedResult exceptionTxnAggregatedResult = new ExceptionTxnAggregatedResult();
        exceptionTxnAggregatedResult.setUnits(exceptionWipModelList.size());
        exceptionTxnAggregatedResult.setExceptionMasId(exceptionMasterId);
        exceptionTxnAggregatedResult.setTransactionIds(getExceptionTransactionByWip(exceptionWipModelList));
        exceptionTxnAggregatedResult.setClientId(exceptionWipModelList.get(0).getClientId());
        exceptionTxnAggregatedResult.setIsApprovalRequired(exceptionWipModelList.get(0).getIsApprovalRequired());
        return exceptionTxnAggregatedResult;
    }


    private List<Long> getExceptionTransactionByWip(List<ExceptionTxnScreenResult> exceptionWipModelList) {
        return exceptionWipModelList.stream().map(ExceptionTxnScreenResult::getExceptionTransactionId).collect(Collectors.toList());
    }

    private void aggregateByDocumentUniqueIdAndScreenIdAndCouponId(List<ExceptionTxnAggregatedResult> aggregatedResultList,
                                                                   List<ExceptionTxnScreenResult> wipResultList) {
        Map<String, Map<Long, Map<Long, List<ExceptionTxnScreenResult>>>> exceptionWipGroupResultMap =
                new HashMap<>();
        wipResultList.stream().filter(exceptionTxnScreenResult -> exceptionTxnScreenResult.getDocumentUniqueId() != null &&
                exceptionTxnScreenResult.getScreenId() != null && exceptionTxnScreenResult.getCouponNumber() != null).forEachOrdered(exceptionTxnScreenResult ->
                exceptionWipGroupResultMap.computeIfAbsent(exceptionTxnScreenResult.getDocumentUniqueId(),
                        key -> new HashMap<>()).computeIfAbsent(exceptionTxnScreenResult.getScreenId(),
                        key -> new HashMap<>()).computeIfAbsent(exceptionTxnScreenResult.getCouponNumber(), k -> new ArrayList<>()).add(exceptionTxnScreenResult));

        exceptionWipGroupResultMap.forEach((documentUniqueId, groupModel) -> groupModel.forEach((screenId, groupModel2) -> groupModel2.forEach((couponId, exceptionWipModelList) -> aggregatedResultList.add(setAggrgateResultModel(exceptionWipModelList.get(0).getExceptionMasId(), exceptionWipModelList)))));
        getAggregatedTransactionsIds(aggregatedResultList, wipResultList);

    }

}
