package com.sgl.smartpra.exception.txn.app.service.impl;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;
import com.sgl.smartpra.exception.master.model.ExceptionParametersDefinitionModel;
import com.sgl.smartpra.exception.txn.app.config.FeignConfiguration.ExceptionMasterAppFeignClient;
import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionParametersValueEntity;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnAuditEntity;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionParametersValueMapper;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTransactionMapper;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTxnAuditMapper;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTransactionService;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnAuditService;
import com.sgl.smartpra.exception.txn.model.*;
import com.sgl.smartpra.exception.txn.model.validator.ModelValidator;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
@Slf4j
public class ExceptionTransactionServiceImpl implements ExceptionTransactionService {

	@Autowired
	private ExceptionTransactionMapper exceptionTransactionMapper;

	@Autowired
	private ExceptionParametersValueMapper exceptionParametersValueMapper;

	@Autowired
	private ModelValidator modelValidator;

	@Autowired
	private ExceptionTxnAuditService exceptionTxnAuditService;

	@Autowired
	private ExceptionMasterAppFeignClient exceptionMasterAppFeignClient;

	@Autowired
	private ExceptionTxnDao exceptionTxnDao;

	@Autowired
	private ExceptionTxnAuditMapper exceptionTxnAuditMapper;

	private static final String EXCEPTION_MASTER_PARAMETER_START_FORMAT = "[";

	private static final String EXCEPTION_MASTER_PARAMETER_KEYWORD_FORMAT = "parameter";

	private static final String EXCEPTION_MASTER_PARAMETER_END_FORMAT = "]";

	public ExceptionTransactionModel getExceptionTransactionById(Long exceptionTransactionId) {
		ExceptionTransactionEntity exceptionTransactionEntity = exceptionTxnDao
				.findByExceptionTransactionId(exceptionTransactionId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(exceptionTransactionId)));
		return prepareExceptionTransactionModel(exceptionTransactionEntity);
	}

	public List<ExceptionTransactionModel> getExceptionTransactionListByExceptionCode(String exceptionCode) {
		ExceptionMasterModel exceptionMasterModel = exceptionMasterAppFeignClient.findByExceptionCode(exceptionCode);
		List<ExceptionTransactionEntity> exceptionTransactionEntityList = exceptionTxnDao
				.findByExceptionMasterId(exceptionMasterModel.getExceptionMasterId());

		List<ExceptionTransactionModel> exceptionTransactionModelList = new ArrayList<>();
		exceptionTransactionEntityList.forEach(exceptionTransactionEntity -> exceptionTransactionModelList
				.add(prepareExceptionTransactionModel(exceptionTransactionEntity)));
		return exceptionTransactionModelList;

	}

	public Long createExceptionTransaction(ExceptionTransactionModel exceptionTransactionModel,
			boolean isValidationRequired) {
		if (isValidationRequired) {
			modelValidator.validate(exceptionTransactionModel,
					exceptionMasterAppFeignClient.findByExceptionCode(exceptionTransactionModel.getExceptionCode()));
		}
		return saveExceptionTransactionEntity(exceptionTransactionModel, new ExceptionTransactionEntity())
				.getExceptionTransactionId();
	}

	public void updateExceptionTransaction(ExceptionTransactionModel exceptionTransactionModel,
			boolean isValidationRequired) {
		log.debug("{}", exceptionTransactionModel);
		if (isValidationRequired) {
			modelValidator.validate(exceptionTransactionModel,
					exceptionMasterAppFeignClient.findByExceptionCode(exceptionTransactionModel.getExceptionCode()));
		}
		if (!exceptionTxnDao.existsById(exceptionTransactionModel.getExceptionTransactionId())) {
			throw new RecordNotFoundException(String.valueOf(exceptionTransactionModel.getExceptionTransactionId()));
		}
		// delete the mapping from ParametersValue Table
		exceptionTxnDao.deleteByExceptionTransactionId(exceptionTransactionModel.getExceptionTransactionId());
		saveExceptionTransactionEntity(exceptionTransactionModel,
				exceptionTxnDao.getOne(exceptionTransactionModel.getExceptionTransactionId()));
	}

	private ExceptionTransactionEntity saveExceptionTransactionEntity(
			ExceptionTransactionModel exceptionTransactionModel,
			ExceptionTransactionEntity exceptionTransactionEntity) {

		exceptionTransactionMapper.mapToExceptionTransactionEntity(exceptionTransactionModel,
				exceptionTransactionEntity);

		// set parent-exception master entity
		ExceptionMasterModel exceptionMasterModel = exceptionMasterAppFeignClient
				.findByExceptionCode(exceptionTransactionModel.getExceptionCode());
		exceptionTransactionEntity.setExceptionMasterId(exceptionMasterModel.getExceptionMasterId());

		List<ExceptionParametersDefinitionModel> parametersDefinitionList = exceptionMasterModel
				.getParametersDefinitionList();

		int index = 0;
		String exceptionDesc = OptionalUtil.getValue(exceptionMasterModel.getExceptionDesc());

		if (parametersDefinitionList != null && !parametersDefinitionList.isEmpty()) {

			for (ExceptionParametersDefinitionModel parametersDefinitionModel : parametersDefinitionList) {
				// Replace the indexed parameters list with actual parameter
				// definition name
				exceptionTransactionEntity.setExceptionDetails(exceptionDesc.replace(
						(EXCEPTION_MASTER_PARAMETER_START_FORMAT + EXCEPTION_MASTER_PARAMETER_KEYWORD_FORMAT
								+ (index + 1) + EXCEPTION_MASTER_PARAMETER_END_FORMAT),
						(EXCEPTION_MASTER_PARAMETER_START_FORMAT
								+ OptionalUtil.getValue(parametersDefinitionModel.getParameterName())
								+ EXCEPTION_MASTER_PARAMETER_END_FORMAT)));
				exceptionTransactionModel.getParametersValueList().forEach(parametersValueModel -> {
					if (OptionalUtil.getValue(parametersDefinitionModel.getParameterName())
							.equalsIgnoreCase(parametersValueModel.getParameterName())) {
						ExceptionParametersValueEntity parametersValueEntity = exceptionParametersValueMapper
								.mapToParametersValueEntity(parametersValueModel,
										exceptionTransactionModel.getCreatedBy());
						parametersValueEntity
								.setParameterDefinitionId(parametersDefinitionModel.getParameterDefinitionId());
						exceptionTransactionEntity.addExceptionParametersValueEntity(parametersValueEntity);
						// replace parameter definition name with corresponding
						// parameter values
						exceptionTransactionEntity
								.setExceptionDetails(exceptionTransactionEntity.getExceptionDetails().replace(
										(EXCEPTION_MASTER_PARAMETER_START_FORMAT
												+ parametersValueModel.getParameterName()
												+ EXCEPTION_MASTER_PARAMETER_END_FORMAT),
										(parametersValueModel.getParameterName() + ":"
												+ parametersValueModel.getParameterValue())));
					}
				});
				index++;
				exceptionDesc = exceptionTransactionEntity.getExceptionDetails();
			}
			// Formatted Exception Msg with ParamValues substituted
			exceptionTransactionEntity.setExceptionDetails(exceptionDesc);
		} else {
			// Param Def is not configured, so set the message from Master
			exceptionTransactionEntity.setExceptionDetails(exceptionDesc);
		}

		log.debug("{}", exceptionTransactionEntity);
		return exceptionTxnDao.save(exceptionTransactionEntity);
	}

	private ExceptionTransactionModel prepareExceptionTransactionModel(
			ExceptionTransactionEntity exceptionTransactionEntity) {
		ExceptionTransactionModel exceptionTransactionModel = exceptionTransactionMapper
				.mapToModel(exceptionTransactionEntity);
		exceptionTransactionModel.setParametersValueList(
				exceptionParametersValueMapper.mapToModel(exceptionTransactionEntity.getParametersValueEntityList()));
		return exceptionTransactionModel;
	}

	@Override
	public ExceptionsViewPaginationModel searchOpenExceptionTxnRecords(ExceptionTxnSearchModel exceptionTxnSearchModel,
			Pageable pageable) {
		ExceptionsViewPaginationModel exceptionsViewPaginationModel = new ExceptionsViewPaginationModel();
		switch (exceptionTxnSearchModel.getModuleName()) {
		case SALE:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTransactionMapper.mapToSaleExceptionsViewModelList(exceptionTxnDao
							.searchSaleOpenExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnDao.getSaleOpenExceptionsCount(exceptionTxnSearchModel));
			break;
		case FLOWN:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTransactionMapper.mapToFlownExceptionsViewModelList(exceptionTxnDao
							.searchFlownOpenExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnDao.getFlownOpenExceptionsCount(exceptionTxnSearchModel));
			break;
		case INWARD:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTransactionMapper.mapToInwardExceptionsViewModelList(exceptionTxnDao
							.searchInwardOpenExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnDao.getInwardOpenExceptionsCount(exceptionTxnSearchModel));
			break;
		case OUTWARD:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTransactionMapper.mapToOutwardExceptionsViewModelList(exceptionTxnDao
							.searchOutwardOpenExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnDao.getOutwardOpenExceptionsCount(exceptionTxnSearchModel));

			break;
		case MISC:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTransactionMapper.mapToMiscOpenExceptionsViewModelList(exceptionTxnDao
							.searchMiscOpenExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnDao.getMiscOpenExceptionsCount(exceptionTxnSearchModel));

			break;
		case PRORATION:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTransactionMapper.mapToProrationOpenExceptionsViewModelList(exceptionTxnDao
							.searchProrationOpenExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnDao.getProrationOpenExceptionsCount(exceptionTxnSearchModel));

			break;
		case GENERAL:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTransactionMapper.mapToGeneralOpenExceptionsViewModelList(exceptionTxnDao
							.searchGeneralOpenExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnDao.getGeneralOpenExceptionsCount(exceptionTxnSearchModel));

			break;
		default:
			break;
		}
		return exceptionsViewPaginationModel;
	}

	@Override
	public List<? extends ExceptionsViewModel> searchOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		switch (exceptionTxnSearchModel.getModuleName()) {
		case SALE:
			return exceptionTransactionMapper.mapToSaleExceptionsViewModelList(
					exceptionTxnDao.searchSaleOpenExceptionTxnRecords(exceptionTxnSearchModel));
		case FLOWN:
			return exceptionTransactionMapper.mapToFlownExceptionsViewModelList(
					exceptionTxnDao.searchFlownOpenExceptionTxnRecords(exceptionTxnSearchModel));
		case INWARD:
			return exceptionTransactionMapper.mapToInwardExceptionsViewModelList(
					exceptionTxnDao.searchInwardOpenExceptionTxnRecords(exceptionTxnSearchModel));
		case OUTWARD:
			return exceptionTransactionMapper.mapToOutwardExceptionsViewModelList(
					exceptionTxnDao.searchOutwardOpenExceptionTxnRecords(exceptionTxnSearchModel));
		case MISC:
			return exceptionTransactionMapper.mapToMiscOpenExceptionsViewModelList(
					exceptionTxnDao.searchMiscOpenExceptionTxnRecords(exceptionTxnSearchModel));
		case PRORATION:
			return exceptionTransactionMapper.mapToProrationOpenExceptionsViewModelList(
					exceptionTxnDao.searchProrationOpenExceptionTxnRecords(exceptionTxnSearchModel));
		case GENERAL:
			return exceptionTransactionMapper.mapToGeneralOpenExceptionsViewModelList(
					exceptionTxnDao.searchGeneralOpenExceptionTxnRecords(exceptionTxnSearchModel));
		default:
			break;
		}
		return new ArrayList<>();
	}

	@Override
	public void deleteExceptionTxnRecords(Long fileId, String actionedBy) {

		List<ExceptionTxnAuditEntity> exceptionTxnAuditEntities = exceptionTxnAuditMapper
				.mapFromExceptionTxnToExceptionAuditMapper(exceptionTxnDao.deleteExceptionTxnRecords(fileId));

		exceptionTxnAuditEntities.forEach(exceptionTxnAuditEntity -> exceptionTxnAuditEntity.setActionedBy(actionedBy));

		exceptionTxnAuditService.createExceptionTransactionAuditRecord(exceptionTxnAuditEntities);

	}

	@Override
	public Page<ExceptionTransactionEntity> getAllExceptionTransactionIds(int exceptionCount) {
		return exceptionTxnDao.findAllExceptionTxnId(exceptionCount);
	}

	@Override
	public OpenExceptionsPaginationModel getAllOpenExceptionTxn(ExceptionTransactionModel transactionModel,
			Pageable pageable) {
		OpenExceptionsPaginationModel openExceptionsPaginationModel = new OpenExceptionsPaginationModel();
		Map<Integer, String> exceptionMasIdSeverityMap = new HashMap<>();
		Map<Integer, String> exceptionMasIdTypeMap = new HashMap<>();

		ExceptionTransactionEntity exceptionTransactionEntity = exceptionTransactionMapper
				.mapToEntity(transactionModel);

		// Fetching Exception Severity and type from master and adding the same
		// to each exception Transaction models
		List<ExceptionTransactionModel> exceptionTransactionModels = exceptionTransactionMapper
				.mapToModel(exceptionTxnDao.getAllOpenExceptions(exceptionTransactionEntity, pageable).getContent());
		Set<Integer> uniqueExceptionMasIds = exceptionTransactionModels.stream()
				.map(ExceptionTransactionModel::getExceptionMasterId).collect(Collectors.toSet());
		List<Integer> uniqueExceptionMasIdsList = new ArrayList<>(uniqueExceptionMasIds);
		List<ExceptionMasterViewModel> exceptionMasterViewModels = exceptionMasterAppFeignClient
				.getAllExceptionsByMasterIds(uniqueExceptionMasIdsList);

		exceptionMasterViewModels.forEach(exceptionMasterViewModel -> {
			exceptionMasIdSeverityMap.put(exceptionMasterViewModel.getExceptionMasId(),
					exceptionMasterViewModel.getExceptionSeverity());
			exceptionMasIdTypeMap.put(exceptionMasterViewModel.getExceptionMasId(),
					exceptionMasterViewModel.getExceptionType());
		});
		exceptionTransactionModels.forEach(exceptionTransactionModel -> {
			exceptionTransactionModel.setExceptionSeverity(
					exceptionMasIdSeverityMap.get(exceptionTransactionModel.getExceptionMasterId()));
			exceptionTransactionModel
					.setExceptionType(exceptionMasIdTypeMap.get(exceptionTransactionModel.getExceptionMasterId()));
		});

		openExceptionsPaginationModel.setExceptionTransactionModels(exceptionTransactionModels);
		openExceptionsPaginationModel
				.setTotalCount(exceptionTxnDao.getAllOpenExceptionTxnCount(exceptionTransactionEntity));
		return openExceptionsPaginationModel;
	}

}
