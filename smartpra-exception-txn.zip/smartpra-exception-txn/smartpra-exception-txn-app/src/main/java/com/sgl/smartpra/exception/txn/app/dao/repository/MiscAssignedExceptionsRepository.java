package com.sgl.smartpra.exception.txn.app.dao.repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.MiscAssignedExceptionsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface MiscAssignedExceptionsRepository
        extends JpaRepository<MiscAssignedExceptionsEntity, Long>, JpaSpecificationExecutor<MiscAssignedExceptionsEntity> {


}
