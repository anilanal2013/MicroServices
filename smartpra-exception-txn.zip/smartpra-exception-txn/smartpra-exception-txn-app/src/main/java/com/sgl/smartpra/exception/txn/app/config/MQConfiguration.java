package com.sgl.smartpra.exception.txn.app.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.sgl.smartpra.mq.configuration.MQConsumerConfiguration;
import com.sgl.smartpra.mq.configuration.MQProducerConfiguration;

@Configuration
@Import({ MQProducerConfiguration.class, MQConsumerConfiguration.class })
public class MQConfiguration {

}
