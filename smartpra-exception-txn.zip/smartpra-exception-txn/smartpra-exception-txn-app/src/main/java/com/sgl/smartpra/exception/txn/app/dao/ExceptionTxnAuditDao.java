package com.sgl.smartpra.exception.txn.app.dao;

import java.util.List;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnAuditEntity;

public interface ExceptionTxnAuditDao {
	
	public void createExceptionTransactionAuditRecord(List<ExceptionTxnAuditEntity> exceptionTxnAuditEntity);

}
