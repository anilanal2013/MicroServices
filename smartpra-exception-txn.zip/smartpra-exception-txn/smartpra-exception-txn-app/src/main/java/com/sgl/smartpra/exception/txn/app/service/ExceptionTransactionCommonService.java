package com.sgl.smartpra.exception.txn.app.service;

import com.sgl.smartpra.exception.txn.model.*;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ExceptionTransactionCommonService {

    void deleteExceptionById(String documentUniqueId, Integer couponNumber);

    List<? extends ExceptionTxnBaseModel> search(ExceptionTxnClosedSearchModel searchModel);

    List<ExceptionsViewModel> getAllExceptionTxn(ExceptionTxnSearchModel exceptionTxnSearchModel);

    OpenExceptionsPaginationModel getAllOpenExceptionTxn(ExceptionTransactionModel exceptionTxnSearchModel, Pageable pageable);

    WipExceptionsPaginationModel getAllCommonWipExceptions(ExceptionTxnWIPModel exceptionTransactionModel, Pageable pageable);
}
