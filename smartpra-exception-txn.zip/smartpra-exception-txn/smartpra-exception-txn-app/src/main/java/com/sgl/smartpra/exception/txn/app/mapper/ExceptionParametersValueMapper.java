package com.sgl.smartpra.exception.txn.app.mapper;

import java.util.Optional;

import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionParametersValueEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionParametersValueMapper
		extends BaseMapper<ExceptionParametersValueModel, ExceptionParametersValueEntity> {

	// ------- ENTITY MAPPER -----------
	ExceptionParametersValueEntity mapToParametersValueEntity(
            ExceptionParametersValueModel exceptionParametersValueModel, String createdBy);

	// -------- OPTIONAL WRAP & UNWRAP
	default <T> T unwrapOptional(Optional<T> optional) {
		return optional.orElse(null);
	}

	default Optional<String> wrapOptional(String string) {
		return Optional.of(string);
	}

}
