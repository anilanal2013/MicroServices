package com.sgl.smartpra.exception.txn.app.dao.spec;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.exception.txn.app.dao.entity.ProrationAssignedExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;

public class ProrationAssignedExceptionsEntitySpec {

	private ProrationAssignedExceptionsEntitySpec() {
	}

	public static Specification<ProrationAssignedExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return (prorationAssignedExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

            if (exceptionTxnSearchModel.getDocumentUniqueId() != null) {
                predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("documentUniqueId"),
                        exceptionTxnSearchModel.getDocumentUniqueId()));
            }

            if (exceptionTxnSearchModel.getCouponNumber() != null) {
                predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("couponNumber"),
                        exceptionTxnSearchModel.getCouponNumber()));
            }

            if (exceptionTxnSearchModel.getModuleId() != null) {
                predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("moduleId"),
                        exceptionTxnSearchModel.getModuleId()));
            }

			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() == null) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(prorationAssignedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay())));
			} else if (exceptionTxnSearchModel.getFromDate() == null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(prorationAssignedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			} else if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.between(prorationAssignedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay()),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			}

			if (exceptionTxnSearchModel.getAging() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("aging"),
						exceptionTxnSearchModel.getAging()));
			}
			
			if (exceptionTxnSearchModel.getEnvironment() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("environment"),
						exceptionTxnSearchModel.getEnvironment()));
			}
			
			if (exceptionTxnSearchModel.getExceptionCategory() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("exceptionCategory"),
						exceptionTxnSearchModel.getExceptionCategory()));
			}

			if (exceptionTxnSearchModel.getExceptionType() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("exceptionType"),
						exceptionTxnSearchModel.getExceptionType()));
			}
			if (exceptionTxnSearchModel.getAirlineType() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("airlineType"),
						exceptionTxnSearchModel.getAirlineType()));
			}
			if (exceptionTxnSearchModel.getExceptionCode() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("exceptionCode"),
						exceptionTxnSearchModel.getExceptionCode()));
			}
			if (exceptionTxnSearchModel.getTeamId() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("teamId"),
						exceptionTxnSearchModel.getTeamId()));
			}
			if (exceptionTxnSearchModel.getGroupId() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("groupId"),
						exceptionTxnSearchModel.getGroupId()));
			}
			if (exceptionTxnSearchModel.getUserId() != null) {
				predicates.add(criteriaBuilder.equal(prorationAssignedExceptionsEntity.get("userId"),
						exceptionTxnSearchModel.getUserId()));
			}
			
			
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
}
