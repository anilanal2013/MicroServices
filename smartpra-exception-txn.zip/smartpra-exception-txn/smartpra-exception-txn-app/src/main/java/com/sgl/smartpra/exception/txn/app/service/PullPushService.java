package com.sgl.smartpra.exception.txn.app.service;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnAssignmentModel;

import java.util.List;

public interface PullPushService {


    void autoAllocateExceptionTxns(ExceptionTxnAssignmentModel exceptionTxnAssignmentModel, List<ExceptionTransactionEntity> transactionEntityList);

}

