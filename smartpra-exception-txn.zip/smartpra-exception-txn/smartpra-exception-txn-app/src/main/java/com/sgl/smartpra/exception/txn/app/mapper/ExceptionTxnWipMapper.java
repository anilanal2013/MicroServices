package com.sgl.smartpra.exception.txn.app.mapper;

import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionTxnAggregatedResult;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionTypeEnum;
import com.sgl.smartpra.exception.txn.model.*;
import org.mapstruct.*;

import java.util.List;
import java.util.Optional;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionTxnWipMapper extends BaseMapper<ExceptionTxnWIPModel, ExceptionTxnWipEntity> {

	// ------ EXCEPTION TXN WIP ENTITY MAPPER -----------------
	@Mapping(source = "assignedBy", target = "createdBy")
	ExceptionTxnWipEntity mapToEntity(ExceptionTxnAssignmentModel exceptionTxnAssignmentModel,
                                      @MappingTarget ExceptionTxnWipEntity exceptionTransactionWipEntity);
	@Mapping(source = "assignmentType", target = "assignedType")
	ExceptionTxnWipEntity mapToEntity(ExceptionTxnAggregationModel exceptionTxnAggregationModel,
                                      @MappingTarget ExceptionTxnWipEntity exceptionTransactionWipEntity);

	ExceptionTxnWipEntity mapToExceptionTransactionWipEntity(ExceptionTransactionEntity exceptionTransactionEntity);

	// ------- SALE ASSIGNED/WIP EXCEPTIONS ENTITY MAPPER ------
	SaleExceptionsViewModel mapToSaleExceptionsViewModel(SaleAssignedExceptionsEntity saleAssignedExceptionsEntity);

	List<SaleExceptionsViewModel> mapToSaleExceptionsViewModelList(
            List<SaleAssignedExceptionsEntity> saleAssignedExceptionsEntityList);

	// ------- FLOWN ASSIGNED/WIP EXCEPTIONS ENTITY MAPPER ------
	FlownExceptionsViewModel mapToFlownExceptionsViewModel(FlownAssignedExceptionsEntity flownAssignedExceptionsEntity);

	FlownAssignedExceptionsEntity mapToFlownAssignedExceptionsEntity(FlownExceptionsViewModel flownExceptionsViewModel);

	List<FlownExceptionsViewModel> mapToFlownExceptionsViewModelList(
            List<FlownAssignedExceptionsEntity> flownAssignedExceptionsEntityList);

	// ------- INWARD ASSIGNED/WIP EXCEPTIONS ENTITY MAPPER ------
	InwardExceptionsViewModel mapToInwardExceptionsViewModel(
            InwardAssignedExceptionsEntity inwardAssignedExceptionsEntity);

	List<InwardExceptionsViewModel> mapToInwardExceptionsViewModelList(
            List<InwardAssignedExceptionsEntity> inwardAssignedExceptionsEntityList);

	// ------- OUTWARD ASSIGNED/WIP EXCEPTIONS ENTITY MAPPER ------
	OutwardExceptionsViewModel mapToOutwardExceptionsViewModel(
            OutwardAssignedExceptionsEntity outwardAssignedExceptionsEntity);

	List<OutwardExceptionsViewModel> mapToOutwardExceptionsViewModelList(
            List<OutwardAssignedExceptionsEntity> outwardAssignedExceptionsEntityList);

	// ------- OUTWARD ASSIGNED/WIP EXCEPTIONS ENTITY MAPPER ------

	MiscExceptionsViewModel mapToMiscExceptionsViewModel(MiscAssignedExceptionsEntity miscAssignedExceptionsEntity);

	List<MiscExceptionsViewModel> mapToMiscExceptionsViewModelList(
            List<MiscAssignedExceptionsEntity> outwardAssignedExceptionsEntityList);

	// ------- PRORATION ASSIGNED/WIP EXCEPTIONS ENTITY MAPPER ------
	ProrationExceptionsViewModel mapToProrationExceptionsViewModel(
            ProrationAssignedExceptionsEntity prorationAssignedExceptionsEntity);

	List<ProrationExceptionsViewModel> mapToProrationExceptionsViewModelList(
            List<ProrationAssignedExceptionsEntity> prorationAssignedExceptionsEntityList);

	// ------- GENERAL ASSIGNED/WIP EXCEPTIONS ENTITY MAPPER ------
	GeneralExceptionsViewModel mapToGeneralExceptionsViewModel(
            GeneralAssignedExceptionsEntity generalAssignedExceptionsEntity);

	List<GeneralExceptionsViewModel> mapToGeneralExceptionsViewModelList(
            List<GeneralAssignedExceptionsEntity> generalAssignedExceptionsEntityList);

	// -------- AGGREGATION MAPPER --------------
	ExceptionTxnAggregationModel mapToExceptionTxnAggregationModel(
            ExceptionTxnAggregatedResult exceptionTxnAggregatedResult);

	// ----- OPTIONAL WRAP & UNWRAP -------------
	@Override
	default <T> T unwrapOptional(Optional<T> optional) {
		return optional.orElse(null);
	}

	@Override
	default Optional<String> wrapOptional(String string) {
		return Optional.of(string);
	}

	default ExceptionStatusEnum toExceptionStatusEnum(String exceptionStatusValue) {
		for (ExceptionStatusEnum exceptionStatusEnum : ExceptionStatusEnum.values()) {
			if (exceptionStatusEnum.getExceptionStatusValue().equals(exceptionStatusValue)) {
				return exceptionStatusEnum;
			}
		}
		return null;
	}

	default ExceptionTypeEnum toExceptionTypeEnum(String exceptionTypeValue) {
		for (ExceptionTypeEnum exceptionTypeEnum : ExceptionTypeEnum.values()) {
			if (exceptionTypeEnum.getExceptionTypeValue().equals(exceptionTypeValue)) {
				return exceptionTypeEnum;
			}
		}
		return null;
	}
}
