package com.sgl.smartpra.exception.txn.app.dao.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "exception_param_value", schema = "SmartPRAException")
@Getter
@Setter
public class ExceptionParametersValueEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "param_value_id")
	private Long paramValueId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "exception_trans_id", nullable = false)
	private ExceptionTransactionEntity exceptionTransactionEntity;

	@Column(name = "param_def_id", nullable = false)
	private Long parameterDefinitionId;

	@Column(name = "param_value")
	private String parameterValue;

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof ExceptionParametersValueEntity))
			return false;
		return paramValueId != null && paramValueId.equals(((ExceptionParametersValueEntity) o).paramValueId);
	}

	@Override
	public int hashCode() {
		return 60;
	}
}
