package com.sgl.smartpra.exception.txn.app.service.impl;

import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;
import com.sgl.smartpra.exception.master.model.UserModel;
import com.sgl.smartpra.exception.txn.app.config.FeignConfiguration;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionWipCountModel;
import com.sgl.smartpra.exception.txn.app.service.ExceptionAllocationService;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnWIPService;
import com.sgl.smartpra.task.mgmt.model.TaskAssignment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ExceptionAllocationServiceImpl implements ExceptionAllocationService {
    @Autowired
    FeignConfiguration.ExceptionMasterAppFeignClient exceptionMasterAppFeignClient;

    @Autowired
    FeignConfiguration.SmartpraTaskMgmtAppClient smartpraTaskMgmtAppClient;

    @Autowired
    private ExceptionTxnWIPService exceptionTxnWIPService;

    /* Returns user Id of the user with least number of tasks; Returns null if there are no users present in user master table */
    @Override
    public Long allocateUserByTaskLoad() {
        Long userWithMinTaskLoad = null;
        List<UserModel> usersList = exceptionMasterAppFeignClient.getAllUsers();

        if (usersList != null && !usersList.isEmpty()) {
            List<Long> userIdsList = new ArrayList<>();
            Map<Long, Integer> userTaskMap = new HashMap<>();
            Map.Entry<Long, Integer> minTaskCount;

            usersList.forEach(user -> { userIdsList.add(user.getUserId()); userTaskMap.put(user.getUserId(), 0);});
            List<TaskAssignment> assignedTaskList = smartpraTaskMgmtAppClient.findByAssignedUserIdIn(userIdsList);

            if (!assignedTaskList.isEmpty())
                assignedTaskList.stream().filter(task -> userTaskMap.containsKey(task.getAssignedUserId())).forEach(task -> userTaskMap.replace(task.getAssignedUserId(), userTaskMap.get(task.getAssignedUserId()) + 1));

            minTaskCount = userTaskMap.entrySet().stream().min(Map.Entry.comparingByValue()).orElse(null);

            if (minTaskCount != null)
                userWithMinTaskLoad = minTaskCount.getKey();

        } else {
            log.info("NO USERS FOUND WHILE CALCULATING USER TASK");
        }
        return userWithMinTaskLoad;
    }

    /* Returns user Id of the user with least work time. Returns null if there are no users present in user master table */
    @Override
    public Long allocateUserByMinWorkTime() {
        Long userWithMinWorkTime = null;
        List<UserModel> usersList = exceptionMasterAppFeignClient.getAllUsers();

        if (usersList != null && !usersList.isEmpty()) {
            List<Long> userIds = new ArrayList<>();
            HashMap<Long, Integer> userTimeMap = new HashMap<>();
            HashMap<Integer, Integer> exceptionResolutionTimeMap;
            Map.Entry<Long, Integer> minUserTime;

            usersList.forEach(user -> {
                userIds.add(user.getUserId());
                userTimeMap.put(user.getUserId(), 0);
            });

            List<ExceptionWipCountModel> exceptionMasIdUserIdList = exceptionTxnWIPService.getAssignedUserExceptions(userIds);

            List<Integer> exceptionMasList = exceptionMasIdUserIdList.stream().map(ExceptionWipCountModel::getExceptionMasterId).collect(Collectors.toList());
            List<ExceptionMasterViewModel> exceptionMasterList = exceptionMasterAppFeignClient.getAllExceptionsByMasterIds(exceptionMasList);

            exceptionResolutionTimeMap = exceptionMasterList.stream().collect(Collectors.toMap(ExceptionMasterViewModel::getExceptionMasId, ExceptionMasterViewModel::getExpectedResolutionTime, (a, b) -> b, HashMap::new));
            for (ExceptionWipCountModel idPair : exceptionMasIdUserIdList) {
                userTimeMap.replace(idPair.getUserId(), userTimeMap.get(idPair.getUserId()) + exceptionResolutionTimeMap.get(idPair.getExceptionMasterId()));
            }

            minUserTime = userTimeMap.entrySet().stream().min(Map.Entry.comparingByValue()).orElse(null);
            if (minUserTime != null)
                userWithMinWorkTime = minUserTime.getKey();

        } else {
            log.info("NO USERS FOUND WHILE CALCULATING USER MIN WORK TIME");
        }
        return userWithMinWorkTime;
    }
}
