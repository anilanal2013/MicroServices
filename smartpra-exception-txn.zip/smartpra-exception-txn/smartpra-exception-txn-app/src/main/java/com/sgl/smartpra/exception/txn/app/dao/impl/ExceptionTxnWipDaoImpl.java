package com.sgl.smartpra.exception.txn.app.dao.impl;

import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnWipDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.app.dao.repository.*;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionTxnScreenResult;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionWipCountModel;
import com.sgl.smartpra.exception.txn.app.dao.spec.*;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class ExceptionTxnWipDaoImpl implements ExceptionTxnWipDao {

    @Autowired
    private SaleAssignedExceptionsRepository saleAssignedExceptionsRepository;

    @Autowired
    private FlownAssignedExceptionsRepository flownAssignedExceptionsRepository;

    @Autowired
    private InwardAssignedExceptionsRepository inwardAssignedExceptionsRepository;

    @Autowired
    private OutwardAssignedExceptionsRepository outwardAssignedExceptionsRepository;

    @Autowired
    private MiscAssignedExceptionsRepository miscAssignedExceptionsRepository;
    
    @Autowired
    private ProrationAssignedExceptionsRepository prorationAssignedExceptionsRepository;
    
    @Autowired
    private GeneralAssignedExceptionsRepository generalAssignedExceptionsRepository;

    @Autowired
    private ExceptionTxnWipRepository exceptionTxnWipRepository;

    @Override
    public void save(List<ExceptionTxnWipEntity> exceptionTxnWipEntityList) {
        exceptionTxnWipRepository.saveAll(exceptionTxnWipEntityList);
    }

    @Override
    public List<ExceptionTxnWipEntity> findByTransactionIds(List<Long> transactionIds) {
        return exceptionTxnWipRepository.findByExceptionTransactionIdIn(transactionIds);
    }

    @Override
    public ExceptionTxnWipEntity findByTransactionId(Long transactionId) {
        return exceptionTxnWipRepository.findByExceptionTransactionId(transactionId);
    }

    @Override
    public List<ExceptionTxnWipEntity> findByAggregationId(String aggregationId) {
        return exceptionTxnWipRepository.findByAggregationId(aggregationId);
    }

    @Override
    public long findCountByAggregationId(String aggregationId) {
        ExceptionTxnWipEntity wipEntity = new ExceptionTxnWipEntity();
        wipEntity.setAggregationId(aggregationId);
        return exceptionTxnWipRepository.count(Example.of(wipEntity));
    }


    @Override
    public Page<SaleAssignedExceptionsEntity> searchSaleAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
        return saleAssignedExceptionsRepository
                .findAll(SaleAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
    }

    @Override
    public Page<FlownAssignedExceptionsEntity> searchFlownAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
        return flownAssignedExceptionsRepository
                .findAll(FlownAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
    }

    @Override
    public Page<InwardAssignedExceptionsEntity> searchInwardAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
        return inwardAssignedExceptionsRepository
                .findAll(InwardAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
    }

    @Override
    public Page<OutwardAssignedExceptionsEntity> searchOutwardAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
        return outwardAssignedExceptionsRepository
                .findAll(OutwardAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
    }

    @Override
    public Page<MiscAssignedExceptionsEntity> searchMiscAssignedExceptionTxnRecords(ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
        return miscAssignedExceptionsRepository
                .findAll(MiscAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
    }
    
    @Override
    public Page<ProrationAssignedExceptionsEntity> searchProrationAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
        return prorationAssignedExceptionsRepository
                .findAll(ProrationAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
    }
    
    @Override
    public Page<GeneralAssignedExceptionsEntity> searchGeneralAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
        return generalAssignedExceptionsRepository
                .findAll(GeneralAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
    }

    @Override
    public List<SaleAssignedExceptionsEntity> searchSaleAssignedExceptionTxnRecords(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return saleAssignedExceptionsRepository
                .findAll(SaleAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }

    @Override
    public List<FlownAssignedExceptionsEntity> searchFlownAssignedExceptionTxnRecords(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return flownAssignedExceptionsRepository
                .findAll(FlownAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));

    }

    @Override
    public List<InwardAssignedExceptionsEntity> searchInwardAssignedExceptionTxnRecords(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return inwardAssignedExceptionsRepository
                .findAll(InwardAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));

    }

    @Override
    public List<OutwardAssignedExceptionsEntity> searchOutwardAssignedExceptionTxnRecords(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return outwardAssignedExceptionsRepository
                .findAll(OutwardAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }

    @Override
    public List<MiscAssignedExceptionsEntity> searchMiscAssignedExceptionTxnRecords(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return miscAssignedExceptionsRepository
                .findAll(MiscAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }

    @Override
    public List<ExceptionTxnScreenResult> getExceptionTransactionWip(List<Long> transactionIds) {
        return exceptionTxnWipRepository.getWipTxnScreenResult(transactionIds);
    }

    @Override
    public void deleteByDocumentUniqueIdAndCouponNumber(String documentUniqueId, Integer couponNumber) {
        exceptionTxnWipRepository.deleteByDocumentUniqueIdAndCouponNumber(documentUniqueId, couponNumber);
    }

    @Override
    public List<ExceptionTxnWipEntity> findAll(Example<ExceptionTxnWipEntity> exceptionTxnWipEntityExample) {
        return exceptionTxnWipRepository.findAll(exceptionTxnWipEntityExample);
    }

    @Override
    public long getSaleAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return saleAssignedExceptionsRepository.count(SaleAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }

    @Override
    public long getFlownAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return flownAssignedExceptionsRepository
                .count(FlownAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }

    @Override
    public long getInwardAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return inwardAssignedExceptionsRepository
                .count(InwardAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }

    @Override
    public long getOutwardAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return outwardAssignedExceptionsRepository
                .count(OutwardAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }

    @Override
    public long getMiscAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return miscAssignedExceptionsRepository
                .count(MiscAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }
    
    @Override
    public long getProrationAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return prorationAssignedExceptionsRepository
                .count(ProrationAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }
    
    @Override
    public long getGeneralAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return generalAssignedExceptionsRepository
                .count(GeneralAssignedExceptionsEntitySpec.search(exceptionTxnSearchModel));
    }


    @Override
    public void deleteExceptionTxnWipRecords(List<ExceptionTxnWipEntity> exceptionTxnWipEntityList) {
        exceptionTxnWipRepository.deleteAll(exceptionTxnWipEntityList);
    }

    @Override
    public void deleteExceptionTxnWipRecord(ExceptionTxnWipEntity exceptionTxnWipEntity) {
        exceptionTxnWipRepository.delete(exceptionTxnWipEntity);
    }

    @Override
    public List<ExceptionWipCountModel> getAssignedUserExceptions(List<Long> userIds) {
        return exceptionTxnWipRepository.findDistinctExceptionMasIdByUserIdIn(userIds);
    }

    @Override
    public Page<ExceptionTxnWipEntity> getAllWipExceptions(ExceptionTxnWipEntity exceptionTransactionEntity, Pageable pageable) {
        return exceptionTxnWipRepository.findAll(Example.of(exceptionTransactionEntity), pageable);
    }

    @Override
    public long getAllWipExceptionTxnCount(ExceptionTxnWipEntity exceptionTransactionEntity) {
        return exceptionTxnWipRepository.count(Example.of(exceptionTransactionEntity));
    }
}
