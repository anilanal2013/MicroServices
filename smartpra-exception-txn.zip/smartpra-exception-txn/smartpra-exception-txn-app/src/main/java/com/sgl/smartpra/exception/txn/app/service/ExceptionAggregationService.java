package com.sgl.smartpra.exception.txn.app.service;

import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionTxnAggregatedResult;

import javax.validation.constraints.NotEmpty;
import java.util.List;

public interface ExceptionAggregationService {

    List<ExceptionTxnAggregatedResult> aggregateExceptionTransactions(@NotEmpty List<Long> transactionIds);
}
