package com.sgl.smartpra.exception.txn.app.dao.impl;

import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnClosedDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.app.dao.repository.*;
import com.sgl.smartpra.exception.txn.app.dao.spec.FlownClosedExceptionsEntitySpec;
import com.sgl.smartpra.exception.txn.app.dao.spec.GeneralClosedExceptionsEntitySpec;
import com.sgl.smartpra.exception.txn.app.dao.spec.InwardClosedExceptionsEntitySpec;
import com.sgl.smartpra.exception.txn.app.dao.spec.MiscClosedExceptionsEntitySpec;
import com.sgl.smartpra.exception.txn.app.dao.spec.OutwardClosedExceptionsEntitySpec;
import com.sgl.smartpra.exception.txn.app.dao.spec.ProrationClosedExceptionsEntitySpec;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class ExceptionTxnClosedDaoImpl implements ExceptionTxnClosedDao {

	@Autowired
	private ExceptionTxnClosedRepository exceptionTxnClosedRepository;

	@Autowired
	private FlownClosedExceptionsRepository flownClosedExceptionsRepository;

	@Autowired
	private InwardClosedExceptionsRepository inwardClosedExceptionsRepository;

	@Autowired
	private OutwardClosedExceptionsRepository outwardClosedExceptionsRepository;

	@Autowired
	private MiscClosedExceptionsRepository miscClosedExceptionsRepository;

	@Autowired
	private ProrationClosedExceptionsRepository prorationClosedExceptionsRepository;

	@Autowired
	private GeneralClosedExceptionsRepository generalClosedExceptionsRepository;

	@Override
	public void saveAll(List<ExceptionTxnClosedEntity> exceptionTxnClosedEntityList) {
		exceptionTxnClosedRepository.saveAll(exceptionTxnClosedEntityList);
	}
	@Override
	public void save(ExceptionTxnClosedEntity exceptionTxnClosedEntity) {
		exceptionTxnClosedRepository.save(exceptionTxnClosedEntity);
	}
	@Override
	public List<FlownClosedExceptionsEntity> searchFlownClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return flownClosedExceptionsRepository.findAll(FlownClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}
	@Override
	public List<InwardClosedExceptionsEntity> searchInwardClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return inwardClosedExceptionsRepository
				.findAll(InwardClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}
	@Override
	public List<OutwardClosedExceptionsEntity> searchOutwardClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return outwardClosedExceptionsRepository
				.findAll(OutwardClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}
	@Override
	public List<MiscClosedExceptionsEntity> searchMiscClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return miscClosedExceptionsRepository.findAll(MiscClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}
	@Override
	public List<GeneralClosedExceptionsEntity> searchGeneralClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return generalClosedExceptionsRepository
				.findAll(GeneralClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}
	@Override
	public List<ProrationClosedExceptionsEntity> searchProrationClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return prorationClosedExceptionsRepository
				.findAll(ProrationClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public Page<FlownClosedExceptionsEntity> searchFlownClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return flownClosedExceptionsRepository.findAll(FlownClosedExceptionsEntitySpec.search(exceptionTxnSearchModel),
				pageable);
	}
	@Override
	public Page<InwardClosedExceptionsEntity> searchInwardClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return inwardClosedExceptionsRepository
				.findAll(InwardClosedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
	}
	@Override
	public Page<MiscClosedExceptionsEntity> searchMiscClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return miscClosedExceptionsRepository.findAll(MiscClosedExceptionsEntitySpec.search(exceptionTxnSearchModel),
				pageable);
	}
	@Override
	public Page<OutwardClosedExceptionsEntity> searchOutwardClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return outwardClosedExceptionsRepository
				.findAll(OutwardClosedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
	}
	@Override
	public Page<ProrationClosedExceptionsEntity> searchProrationClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return prorationClosedExceptionsRepository
				.findAll(ProrationClosedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
	}
	@Override
	public Page<GeneralClosedExceptionsEntity> searchGeneralClosedExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return generalClosedExceptionsRepository
				.findAll(GeneralClosedExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
	}

	@Override
	public Long getFlownClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return flownClosedExceptionsRepository.count(FlownClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}
	@Override
	public Long getInwardClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return inwardClosedExceptionsRepository.count(InwardClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}	
	@Override
	public Long getOutwardClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return outwardClosedExceptionsRepository
				.count(OutwardClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}
	@Override
	public Long getMiscClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return miscClosedExceptionsRepository.count(MiscClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}
	@Override
	public Long getProrationClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return prorationClosedExceptionsRepository
				.count(ProrationClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}
	@Override
	public Long getGeneralClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return generalClosedExceptionsRepository
				.count(GeneralClosedExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public List<ExceptionTxnClosedEntity> search(Example<ExceptionTxnClosedEntity> exceptionTxnClosedEntity) {
		return exceptionTxnClosedRepository.findAll(exceptionTxnClosedEntity);
	}
}
