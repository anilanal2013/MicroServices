package com.sgl.smartpra.exception.txn.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Immutable
@Table(name = "GENERAL_CLOSED_EXCEPTION_VIEW", schema = "dbo")
public class GeneralClosedExceptionsEntity extends ExceptionsViewEntity {

	private static final long serialVersionUID = 1L;
	
	private String countryCode;

	private Long groupId;

	private Long teamId;

	private Long userId;
	
	@Column(name="created_date")
	private LocalDateTime assignedDate;
	
	@Column(name="created_by")
	private String assignedBy;
	
	private String aggregationId;
	
	private LocalDateTime lastUpdatedDate;
	
	private String lastUpdatedBy;

    private String airlineType;

	private String isForceClosed;

}
