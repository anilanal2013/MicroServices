package com.sgl.smartpra.exception.txn.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.OutwardAssignedExceptionsEntity;

@Repository
public interface OutwardAssignedExceptionsRepository extends JpaRepository<OutwardAssignedExceptionsEntity, Long>,
		JpaSpecificationExecutor<OutwardAssignedExceptionsEntity> {

	public List<OutwardAssignedExceptionsEntity> findByModuleId(Integer moduleId);

}
