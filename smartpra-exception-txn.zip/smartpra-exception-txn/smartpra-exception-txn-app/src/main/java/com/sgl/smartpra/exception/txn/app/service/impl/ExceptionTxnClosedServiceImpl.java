package com.sgl.smartpra.exception.txn.app.service.impl;

import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnClosedDao;
import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnWipDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnClosedEntity;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnWipEntity;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTxnClosedMapper;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnClosedService;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnClosedModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import com.sgl.smartpra.exception.txn.model.ExceptionsViewPaginationModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class ExceptionTxnClosedServiceImpl implements ExceptionTxnClosedService {

	@Autowired
	private ExceptionTxnClosedDao exceptionTxnClosedDao;

	@Autowired
	private ExceptionTxnWipDao exceptionTxnWipDao;

	@Autowired
	private ExceptionTxnClosedMapper exceptionTxnClosedMapper;

	@Override
	public void createExceptionTxnClosedRecords(ExceptionTxnClosedModel exceptionTxnClosedModel) {
		log.info("{}", exceptionTxnClosedModel);
		// fetch records from the Exception Txn Table
		List<ExceptionTxnWipEntity> exceptionTxnWipEntityList = exceptionTxnWipDao
				.findByAggregationId(exceptionTxnClosedModel.getAggregationId());

		List<ExceptionTxnClosedEntity> exceptionTxnClosedEntityList = new ArrayList<>();
		// Move the record to Exception Txn Closed Table
		exceptionTxnWipEntityList.forEach(exceptionTxnWipEntity -> {
			ExceptionTxnClosedEntity exceptionTxnClosedEntity = exceptionTxnClosedMapper
					.mapToExceptionTxnClosedEntity(exceptionTxnWipEntity);
			exceptionTxnClosedEntity.setLastUpdatedBy(exceptionTxnClosedModel.getLastUpdatedBy());
			exceptionTxnClosedEntity.setExceptionStatus(ExceptionStatusEnum.CLOSED);
			exceptionTxnClosedEntityList.add(exceptionTxnClosedEntity);
			log.info("{}", exceptionTxnClosedEntity);
		});
		// Save all the ExceptionTxnClosed Records in Batch
		exceptionTxnClosedDao.saveAll(exceptionTxnClosedEntityList);

		// once moved, delete from Exception Txn WIP Table
		exceptionTxnWipDao.deleteExceptionTxnWipRecords(exceptionTxnWipEntityList);

	}

	@Override
	public ExceptionsViewPaginationModel searchExceptionTxnClosedRecords(Pageable pageable,
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		ExceptionsViewPaginationModel exceptionsViewPaginationModel = new ExceptionsViewPaginationModel();
		switch (exceptionTxnSearchModel.getModuleName()) {
		case SALE:
			break;
		case FLOWN:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTxnClosedMapper.mapToFlownExceptionsViewModelList(exceptionTxnClosedDao
							.searchFlownClosedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnClosedDao.getFlownClosedExceptionsCount(exceptionTxnSearchModel));
			break;
		case INWARD:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTxnClosedMapper.mapToInwardExceptionsViewModelList(exceptionTxnClosedDao
							.searchInwardClosedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnClosedDao.getInwardClosedExceptionsCount(exceptionTxnSearchModel));
			break;
		case OUTWARD:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTxnClosedMapper.mapToOutwardExceptionsViewModelList(exceptionTxnClosedDao
							.searchOutwardClosedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnClosedDao.getOutwardClosedExceptionsCount(exceptionTxnSearchModel));
			break;
		case MISC:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTxnClosedMapper.mapToMiscExceptionsViewModelList(exceptionTxnClosedDao
							.searchMiscClosedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnClosedDao.getMiscClosedExceptionsCount(exceptionTxnSearchModel));
			break;
		case PRORATION:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTxnClosedMapper.mapToProrationExceptionsViewModelList(exceptionTxnClosedDao
							.searchProrationClosedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnClosedDao.getProrationClosedExceptionsCount(exceptionTxnSearchModel));
			break;
		case GENERAL:
			exceptionsViewPaginationModel.setExceptionsViewModelList(
					exceptionTxnClosedMapper.mapToGeneralExceptionsViewModelList(exceptionTxnClosedDao
							.searchGeneralClosedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent()));
			exceptionsViewPaginationModel
					.setTotalCount(exceptionTxnClosedDao.getGeneralClosedExceptionsCount(exceptionTxnSearchModel));
			break;
		default:
			break;
		}
		return exceptionsViewPaginationModel;
	}

}
