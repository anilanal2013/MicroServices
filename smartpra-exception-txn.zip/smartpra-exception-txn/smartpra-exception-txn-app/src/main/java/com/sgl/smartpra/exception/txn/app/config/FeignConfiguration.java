package com.sgl.smartpra.exception.txn.app.config;

import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;
import com.sgl.smartpra.exception.master.model.UserModel;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.task.mgmt.model.TaskAssignment;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Configuration
public class FeignConfiguration {

    @FeignClient(value = "smartpra-exception-master-app")
    public interface ExceptionMasterAppFeignClient {
        @GetMapping("/exception/findByExceptionCode/{exceptionCode}")
        public ExceptionMasterModel findByExceptionCode(@PathVariable(value = "exceptionCode") String exceptionCode);

        @GetMapping("/user/getuser")
        public UserModel getUserByNameOrEmail(@RequestParam(value = "user") String user);

        @GetMapping("/user/{userId}")
        public UserModel getUserByUserId(@PathVariable("userId") Long userId);

        @GetMapping(path = "/exception/{clientId}/{exceptionMasterId}")
        public ExceptionMasterModel findByExceptionMasterId(@PathVariable(value = "clientId") String clientId, @PathVariable(value = "exceptionMasterId") Integer exceptionMasterId);

        @GetMapping("/user/allUsers")
        public List<UserModel> getAllUsers();


        @PostMapping("/exception/findByMasterIds")
        public List<ExceptionMasterViewModel> getAllExceptionsByMasterIds(@RequestBody() List<Integer> exceptionMasIds);

    }

    @FeignClient(value = "smartpra-master-app", fallback = MasterFeignHystrix.class,fallbackFactory = FallBackFactory.class)
    public interface SmartpraMasterAppClient {

        @GetMapping("/system-parameters-with-date/{parameterName}")
        public List<SystemParameter> getSystemParameterByparameterName(
                @PathVariable(value = "parameterName") String parameterName);
        
        @GetMapping("/system-parameters-with-date/clientId/{clientId}/parameterName/{parameterName}")
        public SystemParameter getSystemParameterByparameterNameAndClientId(
                @PathVariable(value = "parameterName", required = true) String parameterName,
                @PathVariable(value = "clientId", required = true) String clientId);

    }

    @FeignClient(value = "smartpra-task-mgmt-app")
    public interface SmartpraTaskMgmtAppClient {

        @PostMapping("/task/allUsers")
        public List<TaskAssignment> findByAssignedUserIdIn(@RequestBody List<Long> assignedUserIds);

        @PutMapping("/{taskId}")
        public TaskAssignment updateTask(@PathVariable("taskId") Integer taskId,
                                         @RequestBody @Validated(value = Update.class) TaskAssignment taskAssignment);

    }

}