package com.sgl.smartpra.exception.txn.app.dao.spec;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.exception.txn.app.dao.entity.FlownClosedExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;

public class FlownClosedExceptionsEntitySpec {

	private FlownClosedExceptionsEntitySpec() {
	}

	public static Specification<FlownClosedExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return (flownClosedExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (exceptionTxnSearchModel.getModuleId()!= null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("moduleId"),
						exceptionTxnSearchModel.getModuleId()));
			}

			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getFlightNumber() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("flightNumber"),
						exceptionTxnSearchModel.getFlightNumber()));
			}
			if (exceptionTxnSearchModel.getFromAirport() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("fromAirport"),
						exceptionTxnSearchModel.getFromAirport()));
			}
			if (exceptionTxnSearchModel.getToAirport() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("toAirport"),
						exceptionTxnSearchModel.getToAirport()));
			}
			if (exceptionTxnSearchModel.getUpliftStation() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("upliftStation"),
						exceptionTxnSearchModel.getUpliftStation()));
			}
			if (exceptionTxnSearchModel.getDepartureDate() != null) {
				predicates.add(criteriaBuilder.between(flownClosedExceptionsEntity.get("departureDate"),
						exceptionTxnSearchModel.getDepartureDate().atStartOfDay(),
						exceptionTxnSearchModel.getDepartureDate().atTime(LocalTime.MAX)));
			}
			if (exceptionTxnSearchModel.getFlightCreationDate() != null) {
				predicates.add(criteriaBuilder.between(flownClosedExceptionsEntity.get("flightCreationDate"),
						exceptionTxnSearchModel.getFlightCreationDate().atStartOfDay(),
						exceptionTxnSearchModel.getFlightCreationDate().atTime(LocalTime.MAX)));
			}
			

			if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() == null) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(flownClosedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay())));
			} else if (exceptionTxnSearchModel.getFromDate() == null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(flownClosedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			} else if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.between(flownClosedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay()),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			}

			if (exceptionTxnSearchModel.getAging() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("aging"),
						exceptionTxnSearchModel.getAging()));
			}
			
			if (exceptionTxnSearchModel.getEnvironment() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("environment"),
						exceptionTxnSearchModel.getEnvironment()));
			}
			
			if (exceptionTxnSearchModel.getExceptionCategory() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("exceptionCategory"),
						exceptionTxnSearchModel.getExceptionCategory()));
			}

			if (exceptionTxnSearchModel.getExceptionType() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("exceptionType"),
						exceptionTxnSearchModel.getExceptionType()));
			}
			if (exceptionTxnSearchModel.getAirlineType() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("airlineType"),
						exceptionTxnSearchModel.getAirlineType()));
			}
			if (exceptionTxnSearchModel.getExceptionCode() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("exceptionCode"),
						exceptionTxnSearchModel.getExceptionCode()));
			}
			if (exceptionTxnSearchModel.getCountryCode() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("countryCode"),
						exceptionTxnSearchModel.getCountryCode()));
			}
			if (exceptionTxnSearchModel.getIsForceClosed() != null) {
				predicates.add(criteriaBuilder.equal(flownClosedExceptionsEntity.get("isForceClosed"),
						exceptionTxnSearchModel.getIsForceClosed()));
			}
			
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

}
