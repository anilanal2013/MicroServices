package com.sgl.smartpra.exception.txn.app.config;

import com.esotericsoftware.minlog.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sgl.smartpra.master.model.SystemParameter;

import java.util.Optional;


@Configuration
public class CronConfiguration {

	@Autowired
	FeignConfiguration.SmartpraMasterAppClient smartpraMasterAppClient;

	public static final String TRIGGER_PULL_PUSH_FIXED_RATE = "TRIGGER_PULL_PUSH_FIXED_RATE";

	public static final String CLIENT_ID = "QR";

	@Bean(name = "systemParameter")
	public SystemParameter getPullPushFrequency() {
		SystemParameter systemParameter = new SystemParameter();
		systemParameter.setParameterRangeFrom(Optional.of("71111"));
		try {
			return smartpraMasterAppClient
					.getSystemParameterByparameterNameAndClientId(TRIGGER_PULL_PUSH_FIXED_RATE, CLIENT_ID);
		} catch (Exception e) {
			Log.error("Master Service Is Unavailable");
		}
		return systemParameter;
	}

	}

