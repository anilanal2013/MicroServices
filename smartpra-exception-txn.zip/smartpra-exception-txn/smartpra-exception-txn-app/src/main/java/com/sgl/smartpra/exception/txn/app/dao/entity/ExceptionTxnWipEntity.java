package com.sgl.smartpra.exception.txn.app.dao.entity;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionTxnScreenResult;
import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.enums.converter.AssignmentTypeEnumConverter;
import com.sgl.smartpra.exception.txn.enums.converter.ExceptionStatusEnumConverter;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;


@Entity
@Table(name = "exception_transaction_wip", schema = "SmartPRAException")
@Getter
@Setter
@DynamicUpdate
@DynamicInsert
@NamedNativeQueries({
        @NamedNativeQuery(name = "getWipTxnScreenResult", resultSetMapping = "GetWipTxnScreenResult",
                query = "SELECT m.screen_id,w.exception_trans_id,w.document_unique_id, " +
                        "w.exception_details,w.exception_mas_id,m.client_id,m.is_approval_required,w.invoice_urn,w.coupon_number,m.module_lov_id,l.field_value " +
                        "FROM SmartPRAException.exception_transaction w  " +
                        "LEFT JOIN SmartPRAMaster.mas_exception m  " +
                        "ON m.exception_mas_id = w.exception_mas_id " +
                        "LEFT JOIN SmartPRAMaster.mas_screen_master s  " +
                        "ON s.screen_id = m.screen_id " +
                        "LEFT JOIN SmartPRAMaster.mas_list_of_values l " +
                        "ON l.lov_id = m.module_lov_id " +
                        "WHERE w.exception_trans_id IN(?1)")})
@SqlResultSetMappings({
        @SqlResultSetMapping(name = "GetWipTxnScreenResult", classes = {
                @ConstructorResult(targetClass = ExceptionTxnScreenResult.class, columns = {
                        @ColumnResult(name = "screen_id", type = Long.class),
                        @ColumnResult(name = "exception_trans_id", type = Long.class),
                        @ColumnResult(name = "document_unique_id", type = String.class),
                        @ColumnResult(name = "exception_details", type = String.class),
                        @ColumnResult(name = "exception_mas_id", type = Long.class),
                        @ColumnResult(name = "client_id", type = String.class),
                        @ColumnResult(name = "is_approval_required", type = String.class),
                        @ColumnResult(name = "invoice_urn ", type = String.class),
                        @ColumnResult(name = "coupon_number ", type = Long.class),
                        @ColumnResult(name = "module_lov_id ", type = Integer.class),
                        @ColumnResult(name = "field_value ", type = String.class)
                })})})

public class ExceptionTxnWipEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "exception_trans_id", nullable = false)
    private Long exceptionTransactionId;

    private String environment;

    @Column(name = "client_id")
    private String clientId;

    @Column(name = "order_id")
    private Integer orderId;

    @Column(name = "assigned_type")
    @Convert(converter = AssignmentTypeEnumConverter.class)
    private AssignmentTypeEnum assignedType;

    @Column(name = "issued_carrier")
    private String issuedCarrier;

    private String mainDocument;

    private String originalDocument;

    private String conjunctionDocument;

    @Column(name = "coupon_number")
    private Integer couponNumber;

    @Column(name = "document_unique_id")
    private String documentUniqueId;

    @Column(name = "file_id")
    private Integer fileId;

    @Column(name = "exception_details")
    private String exceptionDetails;

    @Column(name = "exception_status")
    @Convert(converter = ExceptionStatusEnumConverter.class)
    private ExceptionStatusEnum exceptionStatus;

    @Column(name = "exception_date")
    private LocalDateTime exceptionDate;

    @Column(name = "filetype_mapping")
    private String filetypeMapping;

    @Column(name = "group_id")
    private Long groupId;

    @Column(name = "team_id")
    private Long teamId;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "aggregation_id")
    private String aggregationId;

    @Column(name = "is_approved_required")
    @Convert(converter = BooleanToStringConverter.class)
    private Boolean isApprovedRequired;

    @Column(name = "approver_team_id")
    private Long approverTeamId;

    @Column(name = "approver_group_id")
    private Long approverGroupId;

    @Column(name = "approver_user_id")
    private Long approverUserId;

    @Column(name = "assigned_date")
    private LocalDateTime assignedDate;

    @Column(name = "assigned_by")
    private String assignedBy;

    @Column(name = "exception_mas_id")
    private Integer exceptionMasterId;

    @Column(name = "key_1")
    private String batchKey1;

    @Column(name = "key_2")
    private String batchKey2;

    @Column(name = "key_3")
    private String batchKey3;

    @Column(name = "key_4")
    private String batchKey4;

    @Column(name = "key_5")
    private LocalDateTime batchKey5;

    @Column(name = "key_6")
    private LocalDateTime batchKey6;

    private String documentNumber;

    private LocalDate dateOfIssue;

    private String pnr;

    private Long stagingReferenceId;

    private String invoiceUrn;

    @Column(name = "accounting_transaction_id")
    private Long accountingTransactionId;

    @Column(name = "inward_transaction_id")
    private Long inwardTransactionId;

    @Column(name = "inward_transaction_type")
    private String inwardTransactionType;

    @Column(name = "exception_transaction_type")
    private String exceptionTransactionType;


}
