package com.sgl.smartpra.exception.txn.app;

import com.sgl.smartpra.exception.txn.validator.config.ExceptionTxnValidatorConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@Import(ExceptionTxnValidatorConfig.class)
@EnableDiscoveryClient
@EnableFeignClients
@EnableScheduling
@EnableCircuitBreaker
public class ExceptionTransactionApplication {
	public static void main(String[] args) {
		SpringApplication.run(ExceptionTransactionApplication.class, args);
	}
}
