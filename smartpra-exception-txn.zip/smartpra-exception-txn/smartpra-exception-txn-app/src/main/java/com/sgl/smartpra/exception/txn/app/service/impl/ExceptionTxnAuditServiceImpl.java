package com.sgl.smartpra.exception.txn.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnAuditDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnAuditEntity;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnAuditService;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ExceptionTxnAuditServiceImpl implements ExceptionTxnAuditService {

	@Autowired
	private ExceptionTxnAuditDao exceptionTxnAuditDao;

	public void createExceptionTransactionAuditRecord(List<ExceptionTxnAuditEntity> exceptionTxnAuditEntity) {

		exceptionTxnAuditDao.createExceptionTransactionAuditRecord(exceptionTxnAuditEntity);

	}
}
