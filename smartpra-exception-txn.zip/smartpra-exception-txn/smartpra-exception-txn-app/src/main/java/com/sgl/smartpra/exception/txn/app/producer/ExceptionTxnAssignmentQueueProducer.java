package com.sgl.smartpra.exception.txn.app.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.exception.txn.model.ExceptionTxnAggregationModel;
import com.sgl.smartpra.mq.producer.Producer;

@Component
public class ExceptionTxnAssignmentQueueProducer {

	@Autowired
	private Producer producer;

	@Value("${exception-txn-assignment-exchange}")
	private String exceptionTxnAssignmentExchange;

	@Value("${exception-txn-assignment-routing-key}")
	private String exceptionTxnAssignmentRoutingKey;

	public void publish(ExceptionTxnAggregationModel exceptionTxnAggregationModel) {
		producer.send(exceptionTxnAssignmentExchange, exceptionTxnAssignmentRoutingKey, exceptionTxnAggregationModel);
	}
}
