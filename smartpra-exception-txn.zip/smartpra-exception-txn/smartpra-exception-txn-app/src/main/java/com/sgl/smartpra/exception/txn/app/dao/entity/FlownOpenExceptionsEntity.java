package com.sgl.smartpra.exception.txn.app.dao.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Immutable
@Table(name = "FLOWN_OPEN_EXCEPTIONS_VIEW", schema = "dbo")
public class FlownOpenExceptionsEntity extends ExceptionsViewEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "key_1")
	private String flightNumber;

	@Column(name = "key_2")
	private String fromAirport;

	@Column(name = "key_3")
	private String toAirport;

	@Column(name = "key_4")
	private String upliftStation;

	@Column(name = "key_5")
	private LocalDateTime departureDate;

	@Column(name = "key_6")
	private LocalDateTime flightCreationDate;

	private String countryCode;

    private String airlineType;


}
