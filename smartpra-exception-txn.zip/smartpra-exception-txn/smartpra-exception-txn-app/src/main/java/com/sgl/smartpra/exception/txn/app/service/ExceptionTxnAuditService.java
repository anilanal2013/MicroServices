package com.sgl.smartpra.exception.txn.app.service;

import java.util.List;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnAuditEntity;

public interface ExceptionTxnAuditService {

	public void createExceptionTransactionAuditRecord(List<ExceptionTxnAuditEntity> exceptionTxnAuditEntity);
}
