package com.sgl.smartpra.exception.txn.app.dao.repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.SaleAssignedExceptionsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SaleAssignedExceptionsRepository
		extends JpaRepository<SaleAssignedExceptionsEntity, Long>, JpaSpecificationExecutor<SaleAssignedExceptionsEntity> {

	public List<SaleAssignedExceptionsEntity> findByModuleId(Integer moduleId);
}
