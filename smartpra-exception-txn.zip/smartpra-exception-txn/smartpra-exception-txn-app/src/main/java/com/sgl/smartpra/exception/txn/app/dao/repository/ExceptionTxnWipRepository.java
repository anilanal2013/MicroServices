package com.sgl.smartpra.exception.txn.app.dao.repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnWipEntity;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionTxnScreenResult;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionWipCountModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExceptionTxnWipRepository
        extends JpaRepository<ExceptionTxnWipEntity, Long>, JpaSpecificationExecutor<ExceptionTxnWipEntity> {

    public List<ExceptionTxnWipEntity> findByExceptionTransactionIdIn(List<Long> transactionIds);

    public List<ExceptionTxnWipEntity> findByAggregationId(String aggregationId);

    @Query(nativeQuery = true, name = "getWipTxnScreenResult")
    public List<ExceptionTxnScreenResult> getWipTxnScreenResult(List<Long> transactionIds);

    ExceptionTxnWipEntity findByExceptionTransactionId(Long transactionId);

    void deleteByDocumentUniqueIdAndCouponNumber(String documentUniqueId, Integer couponNumber);

    public List<ExceptionWipCountModel> findDistinctExceptionMasIdByUserIdIn(List<Long> userIds);
}
