package com.sgl.smartpra.exception.txn.app.dao;

import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ExceptionTxnClosedDao {

	// --------- CREATE OR UPDATE ------------
	public void saveAll(List<ExceptionTxnClosedEntity> exceptionTxnClosedEntityList);

	public void save(ExceptionTxnClosedEntity exceptionTxnClosedEntity);


	// Paged Results Starts Here
	public Page<FlownClosedExceptionsEntity> searchFlownClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

	public Page<InwardClosedExceptionsEntity> searchInwardClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

	public Page<OutwardClosedExceptionsEntity> searchOutwardClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

	public Page<MiscClosedExceptionsEntity> searchMiscClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);
	
	public Page<ProrationClosedExceptionsEntity> searchProrationClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);
	
	public Page<GeneralClosedExceptionsEntity> searchGeneralClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

	public List<FlownClosedExceptionsEntity> searchFlownClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	public List<InwardClosedExceptionsEntity> searchInwardClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

	public List<OutwardClosedExceptionsEntity> searchOutwardClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

	public List<MiscClosedExceptionsEntity> searchMiscClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	public List<ProrationClosedExceptionsEntity> searchProrationClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	public List<GeneralClosedExceptionsEntity> searchGeneralClosedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

	Long getFlownClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	Long getInwardClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	Long getOutwardClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	Long getMiscClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	Long getProrationClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	Long getGeneralClosedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	List<ExceptionTxnClosedEntity> search(Example<ExceptionTxnClosedEntity> exceptionTxnClosedEntity);
}
