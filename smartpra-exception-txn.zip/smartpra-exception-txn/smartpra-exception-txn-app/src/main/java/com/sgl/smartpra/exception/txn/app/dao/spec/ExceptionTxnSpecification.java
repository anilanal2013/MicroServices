package com.sgl.smartpra.exception.txn.app.dao.spec;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnWipEntity;

public final class ExceptionTxnSpecification {

	private ExceptionTxnSpecification() {
	}

	public static Specification<ExceptionTransactionEntity> exceptionTransactionsIn(final List<Long> transactionIds) {
		return (exceptionTransactionEntity, criteriaQuery, criteriaBuilder) -> exceptionTransactionEntity
				.get("exceptionTransactionId").in(transactionIds);

	}

	public static Specification<ExceptionTxnWipEntity> exceptionMasIdEquals(final Integer exceptionMasId) {
		return (exceptionTxnWipEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(exceptionTxnWipEntity.get("exceptionMasterId"), exceptionMasId);

	}

	public static Specification<ExceptionTxnWipEntity> exceptionStatusEquals(final String status) {
		return (exceptionTxnWipEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(exceptionTxnWipEntity.get("exceptionStatus"), status);

	}

}
