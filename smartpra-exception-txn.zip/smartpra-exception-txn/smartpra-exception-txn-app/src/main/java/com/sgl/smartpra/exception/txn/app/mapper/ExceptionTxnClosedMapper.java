package com.sgl.smartpra.exception.txn.app.mapper;

import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionTypeEnum;
import com.sgl.smartpra.exception.txn.model.*;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import java.util.List;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionTxnClosedMapper extends BaseMapper<ExceptionTxnClosedModel, ExceptionTxnClosedEntity> {

	ExceptionTxnClosedEntity mapToExceptionTxnClosedEntity(ExceptionTxnWipEntity exceptionTxnWipEntity);

	ExceptionTxnClosedEntity mapOpenExceptionsToExceptionTxnClosedEntity(ExceptionTransactionEntity exceptionTransactionEntity);

	// ------- FLOWN CLOSED EXCEPTIONS ENTITY MAPPER ------
	FlownExceptionsViewModel mapToFlownExceptionsViewModel(FlownClosedExceptionsEntity flownClosedExceptionsEntity);

	List<FlownExceptionsViewModel> mapToFlownExceptionsViewModelList(
            List<FlownClosedExceptionsEntity> flownClosedExceptionsEntityList);

	// ------- INWARD CLOSED EXCEPTIONS ENTITY MAPPER ------
	InwardExceptionsViewModel mapToInwardExceptionsViewModel(InwardClosedExceptionsEntity inwardClosedExceptionsEntity);

	List<InwardExceptionsViewModel> mapToInwardExceptionsViewModelList(
            List<InwardClosedExceptionsEntity> inwardClosedExceptionsEntityList);

	// ------- OUTWARD CLOSED EXCEPTIONS ENTITY MAPPER ------
	OutwardExceptionsViewModel mapToOutwardExceptionsViewModel(
            OutwardClosedExceptionsEntity outwardClosedExceptionsEntity);

	List<OutwardExceptionsViewModel> mapToOutwardExceptionsViewModelList(
            List<OutwardClosedExceptionsEntity> outwardClosedExceptionsEntityList);

	// ------- MISC CLOSED EXCEPTION ENTITY MAPPPER

	MiscExceptionsViewModel mapToMiscExceptionsViewModel(MiscClosedExceptionsEntity miscClosedExceptionsEntity);

	List<MiscExceptionsViewModel> mapToMiscExceptionsViewModelList(
            List<MiscClosedExceptionsEntity> outwardClosedExceptionsEntityList);

	// ------- PRORATION CLOSED EXCEPTIONS ENTITY MAPPER ------
	ProrationExceptionsViewModel mapToProrationExceptionsViewModel(
            ProrationClosedExceptionsEntity prorationClosedExceptionsEntity);

	List<ProrationExceptionsViewModel> mapToProrationExceptionsViewModelList(
            List<ProrationClosedExceptionsEntity> prorationClosedExceptionsEntityList);

	// ------- GENERAL CLOSED EXCEPTIONS ENTITY MAPPER ------
	GeneralExceptionsViewModel mapToGeneralExceptionsViewModel(
            GeneralClosedExceptionsEntity generalClosedExceptionsEntity);

	List<GeneralExceptionsViewModel> mapToGeneralExceptionsViewModelList(
            List<GeneralClosedExceptionsEntity> generalClosedExceptionsEntityList);

	// ----- Enum Values Mapper -------------
	default ExceptionStatusEnum toExceptionStatusEnum(String exceptionStatusValue) {
		for (ExceptionStatusEnum exceptionStatusEnum : ExceptionStatusEnum.values()) {
			if (exceptionStatusEnum.getExceptionStatusValue().equals(exceptionStatusValue)) {
				return exceptionStatusEnum;
			}
		}
		return null;
	}

	default ExceptionTypeEnum toExceptionTypeEnum(String exceptionTypeValue) {
		for (ExceptionTypeEnum exceptionTypeEnum : ExceptionTypeEnum.values()) {
			if (exceptionTypeEnum.getExceptionTypeValue().equals(exceptionTypeValue)) {
				return exceptionTypeEnum;
			}
		}
		return null;
	}
}
