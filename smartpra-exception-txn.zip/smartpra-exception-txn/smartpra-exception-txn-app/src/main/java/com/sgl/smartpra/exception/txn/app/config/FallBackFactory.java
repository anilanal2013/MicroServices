package com.sgl.smartpra.exception.txn.app.config;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sgl.smartpra.master.model.SystemParameter;
import feign.hystrix.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class FallBackFactory implements FallbackFactory<FeignConfiguration.SmartpraMasterAppClient> {

    @Override
    public FeignConfiguration.SmartpraMasterAppClient create(Throwable throwable) {
        return new FeignConfiguration.SmartpraMasterAppClient() {
            @Override
            public List<SystemParameter> getSystemParameterByparameterName(String parameterName) {
                List<SystemParameter> systemParameters =new ArrayList<>();
                systemParameters.forEach(systemParameter -> systemParameter.setParameterRangeFrom(Optional.of("Y")));
                return systemParameters;
            }

            @Override
            public SystemParameter getSystemParameterByparameterNameAndClientId(String parameterName, String clientId) {
                SystemParameter systemParameter =new SystemParameter();
                systemParameter.setParameterRangeFrom(Optional.of("71111"));
                return systemParameter;
            }

        };
    }
}
