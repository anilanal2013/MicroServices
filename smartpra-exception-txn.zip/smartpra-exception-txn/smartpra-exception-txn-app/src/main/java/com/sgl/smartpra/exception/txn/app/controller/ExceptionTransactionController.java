package com.sgl.smartpra.exception.txn.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.exception.txn.app.service.ExceptionTransactionService;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import com.sgl.smartpra.exception.txn.model.ExceptionsViewPaginationModel;

@RestController
@RequestMapping("/exception-transaction")
public class ExceptionTransactionController {

	@Autowired
	private ExceptionTransactionService exceptionTransactionService;

	@GetMapping(path = "/findByExceptionTransactionId/{exceptionTransactionId}")
	public ExceptionTransactionModel findByExceptionTransactionId(
			@PathVariable(value = "exceptionTransactionId") Long exceptionTransactionId) {
		return exceptionTransactionService.getExceptionTransactionById(exceptionTransactionId);
	}

	@GetMapping(path = "/findByExceptionCode/{exceptionCode}")
	public List<ExceptionTransactionModel> findByExceptionCode(
			@PathVariable(value = "exceptionCode") String exceptionCode) {
		return exceptionTransactionService.getExceptionTransactionListByExceptionCode(exceptionCode);
	}

	@PutMapping("/{exceptionTransactionId}")
	public void updateExceptionTransaction(@PathVariable(value = "exceptionTransactionId") Long exceptionTransactionId,
			@RequestBody ExceptionTransactionModel exceptionTransaction) {
		exceptionTransaction.setExceptionTransactionId(exceptionTransactionId);
		exceptionTransactionService.updateExceptionTransaction(exceptionTransaction, true);
	}

	@PostMapping(path = "/searchOpenExceptions")
	public ExceptionsViewPaginationModel searchOpenExceptionTxnRecords(Pageable pageable,
			@RequestBody ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return exceptionTransactionService.searchOpenExceptionTxnRecords(exceptionTxnSearchModel, pageable);
	}

	@DeleteMapping(path = "/deleteExceptions/{fileId}/{actionedBy}")
	public void deleteExceptionTxnRecords(@PathVariable(value = "fileId") Long fileId,
			@PathVariable(value = "actionedBy") String actionedBy) {
		exceptionTransactionService.deleteExceptionTxnRecords(fileId, actionedBy );
	}



}
