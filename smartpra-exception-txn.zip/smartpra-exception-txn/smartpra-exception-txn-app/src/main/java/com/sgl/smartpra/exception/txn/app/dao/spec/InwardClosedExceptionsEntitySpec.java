package com.sgl.smartpra.exception.txn.app.dao.spec;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.exception.txn.app.dao.entity.InwardClosedExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;

public final class InwardClosedExceptionsEntitySpec {

	private InwardClosedExceptionsEntitySpec() {
	}

	public static Specification<InwardClosedExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return (inwardClosedExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (exceptionTxnSearchModel.getModuleId()!= null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("moduleId"),
						exceptionTxnSearchModel.getModuleId()));
			}

			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getBillingCarrier() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("billingCarrier"),
						exceptionTxnSearchModel.getBillingCarrier()));
			}
			if (exceptionTxnSearchModel.getBilledCarrier() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("billedCarrier"),
						exceptionTxnSearchModel.getBilledCarrier()));
			}
			if (exceptionTxnSearchModel.getSourceCode() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("sourceCode"),
						exceptionTxnSearchModel.getSourceCode()));
			}
			if (exceptionTxnSearchModel.getInvoiceNo() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("invoiceNo"),
						exceptionTxnSearchModel.getInvoiceNo()));
			}
			if (exceptionTxnSearchModel.getInvoiceDate() != null) {
				predicates.add(criteriaBuilder.between(inwardClosedExceptionsEntity.get("invoiceDate"),
						exceptionTxnSearchModel.getInvoiceDate().atStartOfDay(),
						exceptionTxnSearchModel.getInvoiceDate().atTime(LocalTime.MAX)));
			}

			if (exceptionTxnSearchModel.getBillingDate() != null) {
				predicates.add(criteriaBuilder.between(inwardClosedExceptionsEntity.get("billingDate"),
						exceptionTxnSearchModel.getBillingDate().atStartOfDay(),exceptionTxnSearchModel.getBillingDate().atTime(LocalTime.MAX)));
			}

			if (exceptionTxnSearchModel.getAging() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("aging"),
						exceptionTxnSearchModel.getAging()));
			}

			if (exceptionTxnSearchModel.getEnvironment() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("environment"),
						exceptionTxnSearchModel.getEnvironment()));
			}

			if (exceptionTxnSearchModel.getExceptionCategory() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("exceptionCategory"),
						exceptionTxnSearchModel.getExceptionCategory()));
			}

			if (exceptionTxnSearchModel.getExceptionType() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("exceptionType"),
						exceptionTxnSearchModel.getExceptionType()));
			}
			if (exceptionTxnSearchModel.getAirlineType() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("airlineType"),
						exceptionTxnSearchModel.getAirlineType()));
			}
			if (exceptionTxnSearchModel.getExceptionCode() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("exceptionCode"),
						exceptionTxnSearchModel.getExceptionCode()));
			}
			if (exceptionTxnSearchModel.getIsForceClosed() != null) {
				predicates.add(criteriaBuilder.equal(inwardClosedExceptionsEntity.get("isForceClosed"),
						exceptionTxnSearchModel.getIsForceClosed()));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));

		};
	}
}
