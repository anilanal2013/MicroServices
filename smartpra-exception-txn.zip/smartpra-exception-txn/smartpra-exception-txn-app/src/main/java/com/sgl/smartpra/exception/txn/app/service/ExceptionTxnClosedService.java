package com.sgl.smartpra.exception.txn.app.service;

import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.exception.txn.model.ExceptionTxnClosedModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import com.sgl.smartpra.exception.txn.model.ExceptionsViewPaginationModel;

public interface ExceptionTxnClosedService {

	public void createExceptionTxnClosedRecords(ExceptionTxnClosedModel exceptionTxnClosedModel);

	public ExceptionsViewPaginationModel searchExceptionTxnClosedRecords(Pageable pageable,
                                                                         ExceptionTxnSearchModel exceptionTxnSearchModel);

}