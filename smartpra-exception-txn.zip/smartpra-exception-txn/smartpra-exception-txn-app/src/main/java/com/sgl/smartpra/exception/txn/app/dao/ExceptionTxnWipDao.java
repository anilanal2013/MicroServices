package com.sgl.smartpra.exception.txn.app.dao;

import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionTxnScreenResult;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionWipCountModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ExceptionTxnWipDao {

	// --------- CREATE OR UPDATE ------------
	public void save(List<ExceptionTxnWipEntity> exceptionTxnWipEntityList);

	// -------- FIND, GET --------------------
	public List<ExceptionTxnWipEntity> findByTransactionIds(List<Long> transactionIds);

    public ExceptionTxnWipEntity findByTransactionId(Long transactionIds);

	public List<ExceptionTxnWipEntity> findByAggregationId(String aggregationId);

    public long findCountByAggregationId(String aggregationId);

	// --------- DELETE ----------------------
	public void deleteExceptionTxnWipRecords(List<ExceptionTxnWipEntity> exceptionTxnWipEntityList);

    public void deleteExceptionTxnWipRecord(ExceptionTxnWipEntity exceptionTxnWipEntity);

	// ------ MANUAL TL OPS BOARD -----------
	long getSaleAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);

	long getFlownAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	long getInwardAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
	
	long getOutwardAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);

    long getMiscAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
    
    long getProrationAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);
    
    long getGeneralAssignedExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel);

	public Page<SaleAssignedExceptionsEntity> searchSaleAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

	public Page<FlownAssignedExceptionsEntity> searchFlownAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);
	
	public Page<InwardAssignedExceptionsEntity> searchInwardAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);
	
	public Page<OutwardAssignedExceptionsEntity> searchOutwardAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

    public Page<MiscAssignedExceptionsEntity> searchMiscAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);
    
    public Page<ProrationAssignedExceptionsEntity> searchProrationAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);
    
    public Page<GeneralAssignedExceptionsEntity> searchGeneralAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable);

    //	Non Pageable Results
    List<SaleAssignedExceptionsEntity> searchSaleAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    List<FlownAssignedExceptionsEntity> searchFlownAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    List<InwardAssignedExceptionsEntity> searchInwardAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    List<OutwardAssignedExceptionsEntity> searchOutwardAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

    List<MiscAssignedExceptionsEntity> searchMiscAssignedExceptionTxnRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel);

	List<ExceptionTxnScreenResult> getExceptionTransactionWip(List<Long> transactionIds);

    void deleteByDocumentUniqueIdAndCouponNumber(String documentUniqueId, Integer couponNumber);

    List<ExceptionTxnWipEntity> findAll(Example<ExceptionTxnWipEntity> exceptionTxnWipEntityExample);

	List<ExceptionWipCountModel> getAssignedUserExceptions(List<Long> userIds);

	Page<ExceptionTxnWipEntity> getAllWipExceptions(ExceptionTxnWipEntity exceptionTransactionEntity, Pageable pageable);

	long getAllWipExceptionTxnCount(ExceptionTxnWipEntity exceptionTransactionEntity);
}
