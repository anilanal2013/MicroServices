package com.sgl.smartpra.exception.txn.app.service.impl;

import com.sgl.smartpra.exception.master.model.ExceptionMasterViewModel;
import com.sgl.smartpra.exception.txn.app.config.FeignConfiguration;
import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnDao;
import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnWipDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnWipEntity;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionTxnAggregatedResult;
import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionWipCountModel;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTransactionMapper;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTxnWipMapper;
import com.sgl.smartpra.exception.txn.app.producer.ExceptionTxnAssignmentQueueProducer;
import com.sgl.smartpra.exception.txn.app.service.ExceptionAggregationService;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnWIPService;
import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ExceptionTxnWIPServiceImpl implements ExceptionTxnWIPService {

    @Autowired
    private ExceptionTxnDao exceptionTxnDao;

    @Autowired
    private ExceptionTxnWipDao exceptionTxnWipDao;

    @Autowired
    private ExceptionTxnAssignmentQueueProducer exceptionTxnAssignmentQueueProducer;

    @Autowired
    private ExceptionTxnWipMapper exceptionTxnWipMapper;

    @Autowired
    private FeignConfiguration.ExceptionMasterAppFeignClient exceptionMasterAppFeignClient;

    @Autowired
    ExceptionAggregationService exceptionAggregationService;

    @Autowired
    ExceptionTransactionMapper exceptionTransactionMapper;


    @Override
    public void updateExceptionTxnWIPRecords(ExceptionTxnAggregationModel exceptionTxnAggregationModel) {
        log.info("{}", exceptionTxnAggregationModel);
        List<ExceptionTxnWipEntity> exceptionTxnWipEntityList = exceptionTxnWipDao
                .findByTransactionIds(exceptionTxnAggregationModel.getTransactionIds());
        exceptionTxnWipEntityList.forEach(exceptionTxnWipEntity -> {
            exceptionTxnWipEntity.setAggregationId(exceptionTxnAggregationModel.getAggregationId());
            exceptionTxnWipEntity.setGroupId(exceptionTxnAggregationModel.getGroupId());
            exceptionTxnWipEntity.setTeamId(exceptionTxnAggregationModel.getTeamId());
            exceptionTxnWipEntity.setUserId(exceptionTxnAggregationModel.getUserId());
            exceptionTxnWipEntity.setLastUpdatedBy(exceptionTxnAggregationModel.getLastUpdatedBy());
        });
        log.debug("{}", exceptionTxnWipEntityList);
        exceptionTxnWipDao.save(exceptionTxnWipEntityList);

    }

    @Override
    public ExceptionsViewPaginationModel searchExceptionTxnWIPRecords(Pageable pageable,
                                                                      ExceptionTxnSearchModel exceptionTxnSearchModel) {
        ExceptionsViewPaginationModel exceptionsViewPaginationModel = new ExceptionsViewPaginationModel();
        switch (exceptionTxnSearchModel.getModuleName()) {
            case SALE:

                List<SaleExceptionsViewModel> saleExceptionsViewModels = exceptionTxnWipMapper
                        .mapToSaleExceptionsViewModelList(exceptionTxnWipDao
                                .searchSaleAssignedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent());
                /* Mapping User names from user view */
                if (!saleExceptionsViewModels.isEmpty())
                    saleExceptionsViewModels.stream().filter(user -> user.getUserId() != null)
                            .forEachOrdered(user -> user.setAssignedTo(mapUserNameByUserId(user.getUserId())));

                exceptionsViewPaginationModel.setExceptionsViewModelList(saleExceptionsViewModels);

                exceptionsViewPaginationModel
                        .setTotalCount(exceptionTxnWipDao.getSaleAssignedExceptionsCount(exceptionTxnSearchModel));
                break;
            case FLOWN:
                List<FlownExceptionsViewModel> flownExceptionsViewModels = exceptionTxnWipMapper
                        .mapToFlownExceptionsViewModelList(exceptionTxnWipDao
                                .searchFlownAssignedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent());
                /* Mapping User names from user view */
                if (!flownExceptionsViewModels.isEmpty())
                    flownExceptionsViewModels.stream().filter(user -> user.getUserId() != null)
                            .forEachOrdered(user -> user.setAssignedTo(mapUserNameByUserId(user.getUserId())));

                exceptionsViewPaginationModel.setExceptionsViewModelList(flownExceptionsViewModels);

                exceptionsViewPaginationModel
                        .setTotalCount(exceptionTxnWipDao.getFlownAssignedExceptionsCount(exceptionTxnSearchModel));
                break;
            case INWARD:
                List<InwardExceptionsViewModel> inwardExceptionsViewModels = exceptionTxnWipMapper
                        .mapToInwardExceptionsViewModelList(exceptionTxnWipDao
                                .searchInwardAssignedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent());
                /* Mapping User names from user view */
                if (!inwardExceptionsViewModels.isEmpty())
                    inwardExceptionsViewModels.stream().filter(user -> user.getUserId() != null)
                            .forEachOrdered(user -> user.setAssignedTo(mapUserNameByUserId(user.getUserId())));

                exceptionsViewPaginationModel.setExceptionsViewModelList(inwardExceptionsViewModels);

                exceptionsViewPaginationModel
                        .setTotalCount(exceptionTxnWipDao.getInwardAssignedExceptionsCount(exceptionTxnSearchModel));
                break;
            case OUTWARD:
                List<OutwardExceptionsViewModel> outwardExceptionsViewModels = exceptionTxnWipMapper
                        .mapToOutwardExceptionsViewModelList(exceptionTxnWipDao
                                .searchOutwardAssignedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent());
                /* Mapping User names from user view */
                if (!outwardExceptionsViewModels.isEmpty())
                    outwardExceptionsViewModels.stream().filter(user -> user.getUserId() != null)
                            .forEachOrdered(user -> user.setAssignedTo(mapUserNameByUserId(user.getUserId())));

                exceptionsViewPaginationModel.setExceptionsViewModelList(outwardExceptionsViewModels);

                exceptionsViewPaginationModel
                        .setTotalCount(exceptionTxnWipDao.getOutwardAssignedExceptionsCount(exceptionTxnSearchModel));
                break;
            case MISC:
                List<MiscExceptionsViewModel> miscExceptionsViewModels = exceptionTxnWipMapper
                        .mapToMiscExceptionsViewModelList(exceptionTxnWipDao
                                .searchMiscAssignedExceptionTxnRecords(exceptionTxnSearchModel, pageable).getContent());
                /* Mapping User names from user view */
                if (!miscExceptionsViewModels.isEmpty())
                    miscExceptionsViewModels.stream().filter(user -> user.getUserId() != null)
                            .forEachOrdered(user -> user.setAssignedTo(mapUserNameByUserId(user.getUserId())));

                exceptionsViewPaginationModel.setExceptionsViewModelList(miscExceptionsViewModels);

                exceptionsViewPaginationModel
                        .setTotalCount(exceptionTxnWipDao.getMiscAssignedExceptionsCount(exceptionTxnSearchModel));
                break;
            case PRORATION:
                List<ProrationExceptionsViewModel> prorationExceptionsViewModels = exceptionTxnWipMapper
                        .mapToProrationExceptionsViewModelList(exceptionTxnWipDao
                                .searchProrationAssignedExceptionTxnRecords(exceptionTxnSearchModel, pageable)
                                .getContent());
                /* Mapping User names from user view */
                if (!prorationExceptionsViewModels.isEmpty())
                    prorationExceptionsViewModels.stream().filter(user -> user.getUserId() != null)
                            .forEachOrdered(user -> user.setAssignedTo(mapUserNameByUserId(user.getUserId())));

                exceptionsViewPaginationModel.setExceptionsViewModelList(prorationExceptionsViewModels);

                exceptionsViewPaginationModel
                        .setTotalCount(exceptionTxnWipDao.getProrationAssignedExceptionsCount(exceptionTxnSearchModel));
                break;
            case GENERAL:
                List<GeneralExceptionsViewModel> generalExceptionsViewModels = exceptionTxnWipMapper
                        .mapToGeneralExceptionsViewModelList(exceptionTxnWipDao
                                .searchGeneralAssignedExceptionTxnRecords(exceptionTxnSearchModel, pageable)
                                .getContent());
                /* Mapping User names from user view */
                if (!generalExceptionsViewModels.isEmpty())
                    generalExceptionsViewModels.stream().filter(user -> user.getUserId() != null)
                            .forEachOrdered(user -> user.setAssignedTo(mapUserNameByUserId(user.getUserId())));

                exceptionsViewPaginationModel.setExceptionsViewModelList(generalExceptionsViewModels);

                exceptionsViewPaginationModel
                        .setTotalCount(exceptionTxnWipDao.getGeneralAssignedExceptionsCount(exceptionTxnSearchModel));
                break;

            default:
                break;
        }
        return exceptionsViewPaginationModel;
    }

    @Override
    public List<? extends ExceptionsViewModel> searchExceptionTxnWIPRecords(
            ExceptionTxnSearchModel exceptionTxnSearchModel) {
        switch (exceptionTxnSearchModel.getModuleName()) {
            case SALE:
                return exceptionTxnWipMapper.mapToSaleExceptionsViewModelList(
                        exceptionTxnWipDao.searchSaleAssignedExceptionTxnRecords(exceptionTxnSearchModel));
            case FLOWN:
                return exceptionTxnWipMapper.mapToFlownExceptionsViewModelList(
                        exceptionTxnWipDao.searchFlownAssignedExceptionTxnRecords(exceptionTxnSearchModel));
            case INWARD:
                return exceptionTxnWipMapper.mapToInwardExceptionsViewModelList(
                        exceptionTxnWipDao.searchInwardAssignedExceptionTxnRecords(exceptionTxnSearchModel));
            case OUTWARD:
                return exceptionTxnWipMapper.mapToOutwardExceptionsViewModelList(
                        exceptionTxnWipDao.searchOutwardAssignedExceptionTxnRecords(exceptionTxnSearchModel));
            default:
                break;
        }

        return new ArrayList<>();
    }

    private String mapUserNameByUserId(Long userId) {
        return exceptionMasterAppFeignClient.getUserByUserId(userId).getUserFullName();
    }

    @Override
    public List<ExceptionTxnWIPModel> getExceptionTxnWIPRecords(String aggregationId) {
        return exceptionTxnWipMapper.mapToModel(exceptionTxnWipDao.findByAggregationId(aggregationId));
    }

    public void updateWipTxn(List<ExceptionTxnWIPModel> exceptionTxnWIPModel) {

        exceptionTxnWipDao.save(exceptionTxnWipMapper.mapToEntity(exceptionTxnWIPModel));
    }

    /*
     * This function is a common que for both auto exception and manual
     * exception
     */
    @Override
    public void sendToExceptionTxnAssignmentQueue(ExceptionTxnAssignmentModel exceptionTxnAssignmentModel) {
        List<ExceptionTxnAggregatedResult> exceptionTxnAggregatedResultList = exceptionAggregationService
                .aggregateExceptionTransactions(exceptionTxnAssignmentModel.getTransactionIds());

        exceptionTxnAggregatedResultList.forEach(exceptionTxnAggregatedResult -> {
            ExceptionTxnAggregationModel exceptionTxnAggregationModel = prepareAggregationModel(
                    exceptionTxnAggregatedResult, exceptionTxnAssignmentModel);
            exceptionTxnAssignmentQueueProducer.publish(exceptionTxnAggregationModel);
        });
    }

    private ExceptionTxnAggregationModel prepareAggregationModel(
            ExceptionTxnAggregatedResult exceptionTxnAggregatedResult,
            ExceptionTxnAssignmentModel exceptionTxnAssignmentModel) {

        exceptionTxnAggregatedResult
                .setAssignmentType(exceptionTxnAssignmentModel.getAssignedType().equals(AssignmentTypeEnum.PULL_PUSH)
                        ? AssignmentTypeEnum.PULL_PUSH : AssignmentTypeEnum.MANUAL);
        exceptionTxnAggregatedResult.setCreatedBy(exceptionTxnAssignmentModel.getAssignedBy());
        exceptionTxnAggregatedResult.setExceptionStatus(ExceptionStatusEnum.ASSIGNED);
        exceptionTxnAggregatedResult.setClientId("QR");
        exceptionTxnAggregatedResult.setExceptionMasId(exceptionTxnAggregatedResult.getExceptionMasId());
        exceptionTxnAggregatedResult.setIsApprovalRequired(exceptionTxnAggregatedResult.getIsApprovalRequired());

        ExceptionTxnAggregationModel exceptionTxnAggregationModel = exceptionTxnWipMapper
                .mapToExceptionTxnAggregationModel(exceptionTxnAggregatedResult);

        exceptionTxnAggregationModel
                .setApprovalRequired("Y".equalsIgnoreCase(exceptionTxnAggregatedResult.getIsApprovalRequired())
                        ? Boolean.TRUE : Boolean.FALSE);

        setUserModel(exceptionTxnAggregationModel, exceptionTxnAssignmentModel);

        return exceptionTxnAggregationModel;

    }

    @Override
    public List<ExceptionWipCountModel> getAssignedUserExceptions(List<Long> userIds) {
        return exceptionTxnWipDao.getAssignedUserExceptions(userIds);
    }

    @Override
    public WipExceptionsPaginationModel getAllCommonWipExceptions(ExceptionTxnWIPModel exceptionTransactionModel,
                                                                  Pageable pageable) {
        WipExceptionsPaginationModel wipExceptionsPaginationModel = new WipExceptionsPaginationModel();
        Map<Integer, String> exceptionMasIdSeverityMap = new HashMap<>();
        Map<Integer, String> exceptionMasIdTypeMap = new HashMap<>();

        ExceptionTxnWipEntity exceptionTransactionEntity = exceptionTxnWipMapper.mapToEntity(exceptionTransactionModel);

        // Fetching Exception Severity and type from master and adding the same
        // to each exception Transaction WIP models
        List<ExceptionTxnWIPModel> exceptionTxnWIPModels = exceptionTxnWipMapper
                .mapToModel(exceptionTxnWipDao.getAllWipExceptions(exceptionTransactionEntity, pageable).getContent());

        Set<Integer> uniqueExceptionMasIds = exceptionTxnWIPModels.stream()
                .map(ExceptionTxnWIPModel::getExceptionMasterId).collect(Collectors.toSet());
        List<Integer> uniqueExceptionMasIdsList = new ArrayList<>(uniqueExceptionMasIds);

        List<ExceptionMasterViewModel> exceptionMasterViewModels = exceptionMasterAppFeignClient
                .getAllExceptionsByMasterIds(uniqueExceptionMasIdsList);

        exceptionMasterViewModels.forEach(exceptionMasterViewModel -> {
            exceptionMasIdSeverityMap.put(exceptionMasterViewModel.getExceptionMasId(),
                    exceptionMasterViewModel.getExceptionSeverity());
            exceptionMasIdTypeMap.put(exceptionMasterViewModel.getExceptionMasId(),
                    exceptionMasterViewModel.getExceptionType());
        });

        exceptionTxnWIPModels.forEach(exceptionTxnWIPModel -> {
            exceptionTxnWIPModel
                    .setExceptionSeverity(exceptionMasIdSeverityMap.get(exceptionTxnWIPModel.getExceptionMasterId()));
            exceptionTxnWIPModel
                    .setExceptionType(exceptionMasIdTypeMap.get(exceptionTxnWIPModel.getExceptionMasterId()));
        });

        wipExceptionsPaginationModel.setExceptionTransactionModels(exceptionTxnWIPModels);
        wipExceptionsPaginationModel
                .setTotalCount(exceptionTxnWipDao.getAllWipExceptionTxnCount(exceptionTransactionEntity));
        return wipExceptionsPaginationModel;
    }

    private ExceptionTxnAggregationModel setUserModel(ExceptionTxnAggregationModel exceptionTxnAggregationModel,
                                                      ExceptionTxnAssignmentModel exceptionTxnAssignmentModel) {
        // when it is user mode need to set users , group and team
        if (exceptionTxnAssignmentModel.getAssignedType().equals(AssignmentTypeEnum.MANUAL)) {
            exceptionTxnAggregationModel.setGroupId(exceptionTxnAssignmentModel.getGroupId());
            exceptionTxnAggregationModel.setTeamId(exceptionTxnAssignmentModel.getTeamId());
            exceptionTxnAggregationModel.setUserId(exceptionTxnAssignmentModel.getUserId());
        }
        return exceptionTxnAggregationModel;
    }

    @Override
    public void moveFromExceptionTnxToWip(ExceptionTxnAggregationModel exceptionTxnAggregationModel) {

        // fetch records from the Exception Txn Table
        List<ExceptionTransactionEntity> exceptionTransactionEntityList = exceptionTxnDao
                .findAllExceptionTxnRecords(exceptionTxnAggregationModel.getTransactionIds());

        List<ExceptionTxnWipEntity> exceptionTxnWipEntityList = new ArrayList<>();

        // Move the record to Exception Txn WIP Table
        exceptionTransactionEntityList.forEach(txnEntity -> exceptionTxnWipEntityList
                .add(exceptionTxnWipMapper.mapToEntity(exceptionTxnAggregationModel,
                        exceptionTxnWipMapper.mapToExceptionTransactionWipEntity(txnEntity))));
        exceptionTxnWipDao.save(exceptionTxnWipEntityList);

        // once moved, delete from Exception Txn Table
        exceptionTxnDao.deleteExceptionTxnRecords(exceptionTransactionEntityList);
    }

    @Override
    public void reassignExceptionByAggregationId(String exceptionTxnAggregationModel) {
        CompletableFuture.runAsync(() -> reassignExceptionByAggregationIdDAO(exceptionTxnAggregationModel));
    }


    private void reassignExceptionByAggregationIdDAO(String exceptionTxnAggregationModel) {
        List<ExceptionTxnWipEntity> exceptionTxnWipEntityList =
                exceptionTxnWipDao.findByAggregationId(exceptionTxnAggregationModel);

        List<Long> transactionIdSet = exceptionTxnWipEntityList.stream().map(ExceptionTxnWipEntity::getExceptionTransactionId).collect(Collectors.toList());

        List<ExceptionTxnWipEntity> exceptionTxnWipEntities = exceptionTxnWipDao.findByTransactionIds(transactionIdSet);

        exceptionTxnWipEntities.forEach(exceptionTxnWipEntity -> exceptionTxnWipEntity.setExceptionStatus(ExceptionStatusEnum.HOLD));

        exceptionTxnWipDao.save(exceptionTxnWipEntities);
    }

}
