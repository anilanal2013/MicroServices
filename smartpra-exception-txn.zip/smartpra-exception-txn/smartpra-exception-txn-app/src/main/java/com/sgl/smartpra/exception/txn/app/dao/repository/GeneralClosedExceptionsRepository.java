package com.sgl.smartpra.exception.txn.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.GeneralClosedExceptionsEntity;

@Repository
public interface GeneralClosedExceptionsRepository extends JpaRepository<GeneralClosedExceptionsEntity, Long>,
JpaSpecificationExecutor<GeneralClosedExceptionsEntity>  {

}
