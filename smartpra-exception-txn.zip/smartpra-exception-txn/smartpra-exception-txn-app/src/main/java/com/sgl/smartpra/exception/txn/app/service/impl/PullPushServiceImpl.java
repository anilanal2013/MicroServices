package com.sgl.smartpra.exception.txn.app.service.impl;

import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnDao;
import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnWipDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTxnWipMapper;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnWIPService;
import com.sgl.smartpra.exception.txn.app.service.PullPushService;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnAssignmentModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class PullPushServiceImpl implements PullPushService {

    @Autowired
    private ExceptionTxnDao exceptionTxnDao;

    @Autowired
    private ExceptionTxnWipDao exceptionTxnWipDao;

    @Autowired
    private ExceptionTxnWipMapper exceptionTxnWipMapper;

    @Autowired
    private ExceptionTxnWIPService exceptionTxnWIPService;


    @Override
    public void autoAllocateExceptionTxns(ExceptionTxnAssignmentModel exceptionTxnAssignmentModel, List<ExceptionTransactionEntity> transactionEntityList) {
        exceptionTxnWIPService.sendToExceptionTxnAssignmentQueue(exceptionTxnAssignmentModel);
    }
}

