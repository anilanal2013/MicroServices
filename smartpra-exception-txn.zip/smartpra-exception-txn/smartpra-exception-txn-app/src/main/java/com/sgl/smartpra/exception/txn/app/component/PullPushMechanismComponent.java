package com.sgl.smartpra.exception.txn.app.component;

import com.esotericsoftware.minlog.Log;
import com.sgl.smartpra.exception.txn.app.config.FeignConfiguration;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTransactionService;
import com.sgl.smartpra.exception.txn.app.service.PullPushService;
import com.sgl.smartpra.exception.txn.app.util.SystemParameterUtil;
import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnAssignmentModel;
import com.sgl.smartpra.master.model.SystemParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.sgl.smartpra.exception.txn.constants.SystemParameterConstants.PUSH_PULL_MECHANISM;


@Component
public class PullPushMechanismComponent {


    private static final String AUTO_PULL_PUSH = "AUTO_PULL_PUSH";


    @Autowired
    private PullPushService pullPushService;

    @Autowired
    private ExceptionTransactionService exceptionTransactionService;

    @Autowired
    private FeignConfiguration.SmartpraMasterAppClient smartpraMasterAppClient;
    
    @Autowired
    private SystemParameter systemParameter;

    public static final String CLIENT_ID = "QR";

    /**
     * This Function should be triggered only when the pull push mechanism is enabled
     * The frequency of the function should be triggered every n minutes defined in system parameter
     */
    @Scheduled(fixedRateString = "#{@systemParameter.getParameterRangeFrom().get()}")
    private void triggerPullPush() {

        List<SystemParameter> systemParameters = getSystemParameter();

        if (!SystemParameterUtil.isPushPull(systemParameters)) {
            ExceptionTxnAssignmentModel exceptionTxnAssignmentModel = new ExceptionTxnAssignmentModel();
            List<ExceptionTransactionEntity> transactionEntityList = exceptionTransactionService.getAllExceptionTransactionIds(1500).getContent();
            if (!transactionEntityList.isEmpty()) {
                exceptionTxnAssignmentModel.setAssignedType(AssignmentTypeEnum.PULL_PUSH);
                exceptionTxnAssignmentModel.setAssignedBy(AUTO_PULL_PUSH);
                exceptionTxnAssignmentModel.setIsPullPush(true);
                exceptionTxnAssignmentModel.setAssignedDate(LocalDateTime.now());
                exceptionTxnAssignmentModel.setExceptionStatus(ExceptionStatusEnum.ASSIGNED);
                exceptionTxnAssignmentModel.setTransactionIds(transactionEntityList.stream().map(ExceptionTransactionEntity::getExceptionTransactionId).collect(Collectors.toList()));
                pullPushService.autoAllocateExceptionTxns(exceptionTxnAssignmentModel, transactionEntityList);
            }
        }

    }

    private List<SystemParameter> getSystemParameter(){
        List<SystemParameter> systemParameters = new ArrayList<>();
        SystemParameter systemParameter = new SystemParameter();
        systemParameter.setParameterRangeFrom(Optional.of("Y"));
        systemParameters.add(systemParameter);
        try {
            return smartpraMasterAppClient.getSystemParameterByparameterName(PUSH_PULL_MECHANISM);
        } catch (Exception e) {
            Log.error("Master Service Is Unavailable");
        }
        return systemParameters;
    }


}
