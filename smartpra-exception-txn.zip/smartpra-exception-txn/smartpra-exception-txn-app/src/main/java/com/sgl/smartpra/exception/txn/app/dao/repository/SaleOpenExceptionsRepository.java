package com.sgl.smartpra.exception.txn.app.dao.repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.SaleOpenExceptionsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SaleOpenExceptionsRepository
		extends JpaRepository<SaleOpenExceptionsEntity, Long>, JpaSpecificationExecutor<SaleOpenExceptionsEntity> {

	public List<SaleOpenExceptionsEntity> findByModuleId(Integer moduleId);

    @Query(value = "select s.screenId, s.documentUniqueId from SaleOpenExceptionsEntity s where s.exceptionTransId in (?1) group by s.documentUniqueId,s.screenId")
    List<SaleOpenExceptionsEntity> groupByScreenIdAndMasterId(List<Long> transactionIds);
}
