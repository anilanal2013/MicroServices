package com.sgl.smartpra.exception.txn.app.dao.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Immutable
@Table(name = "GENERAL_ASSIGNED_EXCEPTION_VIEW", schema = "dbo")
public class GeneralAssignedExceptionsEntity extends ExceptionsViewEntity {

	private static final long serialVersionUID = 1L;
	
	private Long groupId;

	private Long teamId;

	private Long userId;
	
	@Column(name="created_date")
	private LocalDateTime assignedDate;
	
	@Column(name="created_by")
	private String assignedBy;
	
	private String aggregationId;

}
