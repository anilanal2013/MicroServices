package com.sgl.smartpra.exception.txn.app.controller;

import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnForceClosedService;
import com.sgl.smartpra.exception.txn.enums.ModuleNameEnum;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnForceCloseModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import com.sgl.smartpra.exception.txn.model.ExceptionsViewModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@RestController
@RequestMapping("/forceClose")
public class ExceptionTxnForceCloseController {

    @Autowired
    private ExceptionTxnForceClosedService exceptionTxnForceClosedService;


    @GetMapping
    public List<? extends ExceptionsViewModel> getForceCloseException(@RequestParam(value = "documentUniqueId", required = false) String documentUniqueId,
                                                                      @RequestParam(value = "couponNumber", required = false) String couponNumber,
                                                                      @RequestParam(value = "moduleName", required = true) @NotNull @Valid ModuleNameEnum moduleName) {
        ExceptionTxnSearchModel exceptionTxnSearchModel = new ExceptionTxnSearchModel();
        exceptionTxnSearchModel.setCouponNumber(couponNumber);
        exceptionTxnSearchModel.setDocumentUniqueId(documentUniqueId);
        exceptionTxnSearchModel.setIsForceClosed("Y");
        exceptionTxnSearchModel.setModuleName(moduleName);
        return exceptionTxnForceClosedService.search(exceptionTxnSearchModel);
    }

    @PostMapping
    public ExceptionTxnForceCloseModel forceCloseException(@RequestBody ExceptionTxnForceCloseModel forceCloseModel) {
        return exceptionTxnForceClosedService.forceCloseExceptionByTransactionId(forceCloseModel);
    }

    @PostMapping("/flown")
    public void flownForceCloseException(@RequestBody ExceptionTxnForceCloseModel exceptionTxnForceCloseModel){
          exceptionTxnForceClosedService.flownForceCloseException(exceptionTxnForceCloseModel);
    }
}