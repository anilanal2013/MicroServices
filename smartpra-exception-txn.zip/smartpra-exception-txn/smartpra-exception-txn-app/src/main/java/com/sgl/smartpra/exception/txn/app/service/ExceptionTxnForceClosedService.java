package com.sgl.smartpra.exception.txn.app.service;

import com.sgl.smartpra.exception.txn.model.ExceptionTxnForceCloseModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import com.sgl.smartpra.exception.txn.model.ExceptionsViewModel;

import java.util.List;

public interface ExceptionTxnForceClosedService {

    List<? extends ExceptionsViewModel> search(ExceptionTxnSearchModel exceptionTxnSearchModel);

    ExceptionTxnForceCloseModel forceCloseExceptionByTransactionId(ExceptionTxnForceCloseModel exceptionTransactionId);

    void flownForceCloseException(ExceptionTxnForceCloseModel exceptionTxnForceCloseModel);

}