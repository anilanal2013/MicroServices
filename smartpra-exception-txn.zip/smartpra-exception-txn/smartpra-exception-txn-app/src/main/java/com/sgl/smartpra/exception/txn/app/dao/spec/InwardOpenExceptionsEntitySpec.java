package com.sgl.smartpra.exception.txn.app.dao.spec;

import com.sgl.smartpra.exception.txn.app.dao.entity.InwardOpenExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class InwardOpenExceptionsEntitySpec {

	private InwardOpenExceptionsEntitySpec() {

	}

	public static Specification<InwardOpenExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return (inwardOpenExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();


            if (exceptionTxnSearchModel.getDocumentUniqueId() != null) {
                predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("documentUniqueId"),
                        exceptionTxnSearchModel.getDocumentUniqueId()));
            }

            if (exceptionTxnSearchModel.getCouponNumber() != null) {
                predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("couponNumber"),
                        exceptionTxnSearchModel.getCouponNumber()));
            }


            if (exceptionTxnSearchModel.getModuleId() != null) {
                predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("moduleId"),
                        exceptionTxnSearchModel.getModuleId()));
            }

			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getBillingCarrier() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("billingCarrier"),
						exceptionTxnSearchModel.getBillingCarrier()));
			}
			if (exceptionTxnSearchModel.getBilledCarrier() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("billedCarrier"),
						exceptionTxnSearchModel.getBilledCarrier()));
			}
			if (exceptionTxnSearchModel.getSourceCode() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("sourceCode"),
						exceptionTxnSearchModel.getSourceCode()));
			}
			if (exceptionTxnSearchModel.getInvoiceNo() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("invoiceNo"),
						exceptionTxnSearchModel.getInvoiceNo()));
			}
			if (exceptionTxnSearchModel.getInvoiceDate() != null) {
				predicates.add(criteriaBuilder.between(inwardOpenExceptionsEntity.get("invoiceDate"),
						exceptionTxnSearchModel.getInvoiceDate().atStartOfDay(),
						exceptionTxnSearchModel.getInvoiceDate().atTime(LocalTime.MAX)));
			}

			if (exceptionTxnSearchModel.getBillingDate() != null) {
				predicates.add(criteriaBuilder.between(inwardOpenExceptionsEntity.get("billingDate"),
						exceptionTxnSearchModel.getBillingDate().atStartOfDay(),exceptionTxnSearchModel.getBillingDate().atTime(LocalTime.MAX)));
			}

			if (exceptionTxnSearchModel.getAging() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("aging"),
						exceptionTxnSearchModel.getAging()));
			}

			if (exceptionTxnSearchModel.getEnvironment() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("environment"),
						exceptionTxnSearchModel.getEnvironment()));
			}

			if (exceptionTxnSearchModel.getExceptionCategory() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("exceptionCategory"),
						exceptionTxnSearchModel.getExceptionCategory()));
			}

			if (exceptionTxnSearchModel.getExceptionType() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("exceptionType"),
						exceptionTxnSearchModel.getExceptionType()));
			}
			if (exceptionTxnSearchModel.getAirlineType() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("airlineType"),
						exceptionTxnSearchModel.getAirlineType()));
			}
			if (exceptionTxnSearchModel.getExceptionCode() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("exceptionCode"),
						exceptionTxnSearchModel.getExceptionCode()));
			}
			if (exceptionTxnSearchModel.getStagingReferenceId() != null) {
				predicates.add(criteriaBuilder.equal(inwardOpenExceptionsEntity.get("stagingReferenceId"),
						exceptionTxnSearchModel.getStagingReferenceId()));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));

		};
	}
}