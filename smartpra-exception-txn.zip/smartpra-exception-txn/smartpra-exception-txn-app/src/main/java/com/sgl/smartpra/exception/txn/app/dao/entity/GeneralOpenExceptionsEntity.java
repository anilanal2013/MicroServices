package com.sgl.smartpra.exception.txn.app.dao.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Immutable
@Table(name = "GENERAL_OPEN_EXCEPTION_VIEW", schema = "dbo")
public class GeneralOpenExceptionsEntity extends ExceptionsViewEntity {

	private static final long serialVersionUID = 1L;
	
	
}
