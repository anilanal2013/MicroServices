package com.sgl.smartpra.exception.txn.app.dao.entity;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "exception_transaction_audit", schema = "SmartPRAException")
@Getter
@Setter
@DynamicUpdate
@DynamicInsert
public class ExceptionTxnAuditEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "exception_trans_id")
	private Long exceptionTransactionId;

	@Column(name = "environment", nullable = false)
	private String environment;

	@Column(name = "client_id", nullable = false)
	private String clientId;

	@Column(name = "order_id")
	private Integer orderId;

	@Column(name = "issued_carrier")
	private String issuedCarrier;

	private String mainDocument;

	private String originalDocument;

	private String conjunctionDocument;

	@Column(name = "coupon_number")
	private Integer couponNumber;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	@Column(name = "file_id")
	private Long fileId;

	@Column(name = "exception_details", nullable = false)
	private String exceptionDetails;

	@Column(name = "exception_date", nullable = false)
	private LocalDateTime exceptionDate;

	@Column(name = "exception_mas_id", nullable = false)
	private Integer exceptionMasterId;

	@Column(name = "key_1")
	private String batchKey1;

	@Column(name = "key_2")
	private String batchKey2;

	@Column(name = "key_3")
	private String batchKey3;

	@Column(name = "key_4")
	private String batchKey4;

	@Column(name = "key_5")
	private LocalDateTime batchKey5;

	@Column(name = "key_6")
	private LocalDateTime batchKey6;

	private String documentNumber;

	private LocalDate dateOfIssue;

	private String pnr;

	private Long stagingReferenceId;

	@Column(name = "actioned_by", nullable = false)
	private String actionedBy;

	private LocalDateTime actionedDate;

	private String invoiceUrn;

	@PrePersist
	public void prePersist() {
		actionedDate = LocalDateTime.now();
	}
}
