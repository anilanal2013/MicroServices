package com.sgl.smartpra.exception.txn.app.dao.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Data
@EqualsAndHashCode(callSuper=false)
@Immutable
@Table(name = "SALE_OPEN_EXCEPTIONS_VIEW", schema = "dbo")
public class SaleOpenExceptionsEntity extends ExceptionsViewEntity {

	private static final long serialVersionUID = 1L;

    private String airlineType;

	@Column(name = "key_1")
	private String agencyCode;

	@Column(name = "key_2")
	private String batchType;

	@Column(name = "key_3")
	private String batchNumber;

	@Column(name = "key_4")
	private String reportingCurrency;

	@Column(name = "key_5")
	private LocalDateTime fromReportingPeriod;

	@Column(name = "key_6")
	private LocalDateTime toReporingPeriod;

}
