package com.sgl.smartpra.exception.txn.app.consumer;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTransactionService;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mq.consumer.Consumer;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ExceptionTransactionQueueConsumer implements Consumer {

	@Autowired
	private ExceptionTransactionService exceptionTransactionService;

	@Override
	public void receive(String message) throws IOException {
		try {
			exceptionTransactionService.createExceptionTransaction(
					new ObjectMapper().readValue(message, ExceptionTransactionModel.class), false);
		} catch (Exception e) {
			log.error("Exception occurred in [" + this.getClass().getName() + "].receive():E={}", e);
		}
	}
}
