package com.sgl.smartpra.exception.txn.app.dao.spec;

import com.sgl.smartpra.exception.txn.app.dao.entity.SaleOpenExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class SaleOpenExceptionsEntitySpec {

    private SaleOpenExceptionsEntitySpec() {
    }

    public static Specification<SaleOpenExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {

        return (saleOpenExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (exceptionTxnSearchModel.getDocumentUniqueId() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("documentUniqueId"),
                        exceptionTxnSearchModel.getDocumentUniqueId()));
            }

            if (exceptionTxnSearchModel.getCouponNumber() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("couponNumber"),
                        exceptionTxnSearchModel.getCouponNumber()));
            }

            if (exceptionTxnSearchModel.getModuleId() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("moduleId"),
                        exceptionTxnSearchModel.getModuleId()));
            }

            if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("exceptionSeverity"),
                        exceptionTxnSearchModel.getExceptionSeverity()));
            }
            if (exceptionTxnSearchModel.getAgencyCode() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("agencyCode"),
                        exceptionTxnSearchModel.getAgencyCode()));
            }
            if (exceptionTxnSearchModel.getBatchType() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("batchType"),
                        exceptionTxnSearchModel.getBatchType()));
            }
            if (exceptionTxnSearchModel.getBatchNumber() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("batchNumber"),
                        exceptionTxnSearchModel.getBatchNumber()));
            }
            if (exceptionTxnSearchModel.getReportingCurrency() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("reportingCurrency"),
                        exceptionTxnSearchModel.getReportingCurrency()));
            }

            if (exceptionTxnSearchModel.getFromReportingPeriod() != null
                    && exceptionTxnSearchModel.getToReporingPeriod() == null) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(saleOpenExceptionsEntity.get("fromReportingPeriod"),
                        criteriaBuilder.literal(exceptionTxnSearchModel.getFromReportingPeriod().atStartOfDay())));
            } else if (exceptionTxnSearchModel.getFromReportingPeriod() == null
                    && exceptionTxnSearchModel.getToReporingPeriod() != null) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(saleOpenExceptionsEntity.get("toReporingPeriod"),
                        criteriaBuilder.literal(exceptionTxnSearchModel.getToReporingPeriod().atTime(LocalTime.MAX))));
            } else if (exceptionTxnSearchModel.getFromReportingPeriod() != null
                    && exceptionTxnSearchModel.getToReporingPeriod() != null) {
                predicates
                        .add(criteriaBuilder.or(
                                criteriaBuilder.between(
                                        criteriaBuilder.literal(
                                                exceptionTxnSearchModel.getFromReportingPeriod().atStartOfDay()),
                                        saleOpenExceptionsEntity.get("fromReportingPeriod"),
                                        saleOpenExceptionsEntity.get("toReporingPeriod")),
                                criteriaBuilder.between(
                                        criteriaBuilder.literal(
                                                exceptionTxnSearchModel.getToReporingPeriod().atTime(LocalTime.MAX)),
                                        saleOpenExceptionsEntity.get("fromReportingPeriod"),
                                        saleOpenExceptionsEntity.get("toReporingPeriod"))));
            }

            if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() == null) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(saleOpenExceptionsEntity.get("exceptionDate"),
                        criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay())));
            } else if (exceptionTxnSearchModel.getFromDate() == null && exceptionTxnSearchModel.getToDate() != null) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(saleOpenExceptionsEntity.get("exceptionDate"),
                        criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
            } else if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() != null) {
                predicates.add(criteriaBuilder.between(saleOpenExceptionsEntity.get("exceptionDate"),
                        criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay()),
                        criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
            }

            if (exceptionTxnSearchModel.getAging() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("aging"),
                        exceptionTxnSearchModel.getAging()));
            }

            if (exceptionTxnSearchModel.getEnvironment() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("environment"),
                        exceptionTxnSearchModel.getEnvironment()));
            }

            if (exceptionTxnSearchModel.getExceptionCategory() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("exceptionCategory"),
                        exceptionTxnSearchModel.getExceptionCategory()));
            }

            if (exceptionTxnSearchModel.getExceptionType() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("exceptionType"),
                        exceptionTxnSearchModel.getExceptionType()));
            }
            if (exceptionTxnSearchModel.getAirlineType() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("airlineType"),
                        exceptionTxnSearchModel.getAirlineType()));
            }
            if (exceptionTxnSearchModel.getExceptionCode() != null) {
                predicates.add(criteriaBuilder.equal(saleOpenExceptionsEntity.get("exceptionCode"),
                        exceptionTxnSearchModel.getExceptionCode()));
            }
            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
        };

    }
}
