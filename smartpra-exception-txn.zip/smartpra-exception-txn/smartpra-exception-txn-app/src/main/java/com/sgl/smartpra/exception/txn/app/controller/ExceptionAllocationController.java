package com.sgl.smartpra.exception.txn.app.controller;

import com.sgl.smartpra.exception.txn.app.service.ExceptionAllocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/exception-taskAllocation")
public class ExceptionAllocationController {

    @Autowired
    ExceptionAllocationService exceptionAllocationService;

    @GetMapping("/allocateByTaskLoad")
    public Long allocateUserByTaskLoad(){
        return exceptionAllocationService.allocateUserByTaskLoad();
    }

    @GetMapping("/allocateByMinWorkTime")
    public Long allocateUserByMinWorkTime(){
        return exceptionAllocationService.allocateUserByMinWorkTime();
    }
}
