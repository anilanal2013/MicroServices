package com.sgl.smartpra.exception.txn.app.dao.result;

import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ExceptionTxnAggregatedResult implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer units;

    private String clientId;

    private Long exceptionMasId;

    private String isApprovalRequired;

    private String lastUpdatedBy;

    private String createdBy;

    private String aggregationId;

    private List<Long> transactionIds;

    private AssignmentTypeEnum assignmentType;

    private ExceptionStatusEnum exceptionStatus;

    private Long groupId;

    private Long teamId;

    private Long userId;

    private Integer moduleLovId;


}
