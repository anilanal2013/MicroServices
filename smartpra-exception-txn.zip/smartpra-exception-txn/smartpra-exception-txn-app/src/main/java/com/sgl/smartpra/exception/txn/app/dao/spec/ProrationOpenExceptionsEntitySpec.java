package com.sgl.smartpra.exception.txn.app.dao.spec;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.exception.txn.app.dao.entity.ProrationOpenExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;

public final class ProrationOpenExceptionsEntitySpec {

	private ProrationOpenExceptionsEntitySpec() {
	}

	public static Specification<ProrationOpenExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return (prorationOpenExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

            if (exceptionTxnSearchModel.getDocumentUniqueId() != null) {
                predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("documentUniqueId"),
                        exceptionTxnSearchModel.getDocumentUniqueId()));
            }

            if (exceptionTxnSearchModel.getCouponNumber() != null) {
                predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("couponNumber"),
                        exceptionTxnSearchModel.getCouponNumber()));
            }

            if (exceptionTxnSearchModel.getModuleId() != null) {
                predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("moduleId"),
                        exceptionTxnSearchModel.getModuleId()));
            }

			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() == null) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(prorationOpenExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay())));
			} else if (exceptionTxnSearchModel.getFromDate() == null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(prorationOpenExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			} else if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.between(prorationOpenExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay()),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			}

			if (exceptionTxnSearchModel.getAging() != null) {
				predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("aging"),
						exceptionTxnSearchModel.getAging()));
			}
			
			if (exceptionTxnSearchModel.getEnvironment() != null) {
				predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("environment"),
						exceptionTxnSearchModel.getEnvironment()));
			}
			
			if (exceptionTxnSearchModel.getExceptionCategory() != null) {
				predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("exceptionCategory"),
						exceptionTxnSearchModel.getExceptionCategory()));
			}

			if (exceptionTxnSearchModel.getExceptionType() != null) {
				predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("exceptionType"),
						exceptionTxnSearchModel.getExceptionType()));
			}
			if (exceptionTxnSearchModel.getAirlineType() != null) {
				predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("airlineType"),
						exceptionTxnSearchModel.getAirlineType()));
			}
			if (exceptionTxnSearchModel.getExceptionCode() != null) {
				predicates.add(criteriaBuilder.equal(prorationOpenExceptionsEntity.get("exceptionCode"),
						exceptionTxnSearchModel.getExceptionCode()));
			}
			
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
}
