package com.sgl.smartpra.exception.txn.app.controller;

import com.sgl.smartpra.exception.txn.app.service.ExceptionTransactionCommonService;
import com.sgl.smartpra.exception.txn.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/common")
public class ExceptionTransactionCommonController {

    @Autowired
    private ExceptionTransactionCommonService exceptionTransactionCommonService;


    @DeleteMapping(path = "/delete/exception")
    public void deleteExceptionById(@RequestParam(value = "documentUniqueId") String documentUniqueId,
                                    @RequestParam(value = "couponNumber") Integer couponNumber) {
        exceptionTransactionCommonService.deleteExceptionById(documentUniqueId, couponNumber);
    }

    @PostMapping(path = "/exceptions")
    public List<ExceptionsViewModel> getAllExceptions(@RequestBody ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return exceptionTransactionCommonService.getAllExceptionTxn(exceptionTxnSearchModel);
    }


    @PostMapping(path = "/open/exceptions")
    public OpenExceptionsPaginationModel getAllCommonOpenExceptions(@RequestBody ExceptionTransactionModel exceptionTransactionModel, Pageable pageable) {
        return exceptionTransactionCommonService.getAllOpenExceptionTxn(exceptionTransactionModel, pageable);
    }

    @PostMapping(path = "/wip/exceptions")
    public WipExceptionsPaginationModel getAllCommonWipExceptions(@RequestBody ExceptionTxnWIPModel exceptionTxnWIPModel, Pageable pageable) {
        return exceptionTransactionCommonService.getAllCommonWipExceptions(exceptionTxnWIPModel, pageable);
    }


}
