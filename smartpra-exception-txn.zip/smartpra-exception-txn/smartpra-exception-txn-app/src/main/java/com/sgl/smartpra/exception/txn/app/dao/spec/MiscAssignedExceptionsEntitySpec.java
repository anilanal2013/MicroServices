package com.sgl.smartpra.exception.txn.app.dao.spec;

import com.sgl.smartpra.exception.txn.app.dao.entity.MiscAssignedExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class MiscAssignedExceptionsEntitySpec {
    private MiscAssignedExceptionsEntitySpec() {

    }

    public static Specification<MiscAssignedExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return (miscAssignedExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (exceptionTxnSearchModel.getModuleId() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("moduleId"),
                        exceptionTxnSearchModel.getModuleId()));
            }

            if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("exceptionSeverity"),
                        exceptionTxnSearchModel.getExceptionSeverity()));
            }
            if (exceptionTxnSearchModel.getBillingCarrier() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("billingCarrier"),
                        exceptionTxnSearchModel.getBillingCarrier()));
            }
            if (exceptionTxnSearchModel.getBilledCarrier() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("billedCarrier"),
                        exceptionTxnSearchModel.getBilledCarrier()));
            }
            if (exceptionTxnSearchModel.getChargeCategory() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("chargeCategory"),
                        exceptionTxnSearchModel.getChargeCategory()));
            }
            if (exceptionTxnSearchModel.getInvoiceNo() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("invoiceNo"),
                        exceptionTxnSearchModel.getInvoiceNo()));
            }

            if (exceptionTxnSearchModel.getInvoiceDate() != null) {
                predicates.add(criteriaBuilder.between(miscAssignedExceptionsEntity.get("invoiceDate"),
                        exceptionTxnSearchModel.getInvoiceDate().atStartOfDay(),
                        exceptionTxnSearchModel.getInvoiceDate().atTime(LocalTime.MAX)));
            }

            if (exceptionTxnSearchModel.getBillingDate() != null) {
                predicates.add(criteriaBuilder.between(miscAssignedExceptionsEntity.get("billingDate"),
                        exceptionTxnSearchModel.getBillingDate().atStartOfDay(), exceptionTxnSearchModel.getBillingDate().atTime(LocalTime.MAX)));
            }

            if (exceptionTxnSearchModel.getAging() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("aging"),
                        exceptionTxnSearchModel.getAging()));
            }

            if (exceptionTxnSearchModel.getEnvironment() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("environment"),
                        exceptionTxnSearchModel.getEnvironment()));
            }

            if (exceptionTxnSearchModel.getExceptionCategory() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("exceptionCategory"),
                        exceptionTxnSearchModel.getExceptionCategory()));
            }

            if (exceptionTxnSearchModel.getExceptionType() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("exceptionType"),
                        exceptionTxnSearchModel.getExceptionType()));
            }

            if (exceptionTxnSearchModel.getExceptionCode() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("exceptionCode"),
                        exceptionTxnSearchModel.getExceptionCode()));
            }

            if (exceptionTxnSearchModel.getStagingReferenceId() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("stagingReferenceId"),
                        exceptionTxnSearchModel.getStagingReferenceId()));
            }
            if (exceptionTxnSearchModel.getTeamId() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("teamId"),
                        exceptionTxnSearchModel.getTeamId()));
            }
            if (exceptionTxnSearchModel.getGroupId() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("groupId"),
                        exceptionTxnSearchModel.getGroupId()));
            }
            if (exceptionTxnSearchModel.getUserId() != null) {
                predicates.add(criteriaBuilder.equal(miscAssignedExceptionsEntity.get("userId"),
                        exceptionTxnSearchModel.getUserId()));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
        };
    }
}
