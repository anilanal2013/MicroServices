package com.sgl.smartpra.exception.txn.app.mapper;

import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.model.*;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import java.util.List;
import java.util.Optional;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionTransactionMapper extends BaseMapper<ExceptionTransactionModel, ExceptionTransactionEntity> {

	ExceptionTransactionEntity mapToExceptionTransactionEntity(ExceptionTransactionModel exceptionTransactionModel,
                                                               @MappingTarget ExceptionTransactionEntity exceptionTransactionEntity);

	// ------------ SALE OPEN EXCEPTIONS ENTITY MAPPER --------------
	SaleExceptionsViewModel mapToSaleExceptionsViewModel(SaleOpenExceptionsEntity saleOpenExceptionsEntity);

	List<SaleExceptionsViewModel> mapToSaleExceptionsViewModelList(
            List<SaleOpenExceptionsEntity> saleOpenExceptionsEntityList);

	// ------------- FLOWN OPEN EXCEPIONS ENTITY MAPPER ------------
	FlownExceptionsViewModel mapToFlownExceptionsViewModel(FlownOpenExceptionsEntity flownOpenExceptionsEntity);

	List<FlownExceptionsViewModel> mapToFlownExceptionsViewModelList(
            List<FlownOpenExceptionsEntity> flownOpenExceptionsEntityList);

	// ------------- INWARD OPEN EXCEPIONS ENTITY MAPPER ------------
	InwardExceptionsViewModel mapToInwardExceptionsViewModel(InwardOpenExceptionsEntity inwardOpenExceptionsEntity);

	List<InwardExceptionsViewModel> mapToInwardExceptionsViewModelList(
            List<InwardOpenExceptionsEntity> inwardOpenExceptionsEntityList);

	// ------------- OUTWARD OPEN EXCEPIONS ENTITY MAPPER ------------
	OutwardExceptionsViewModel mapToOutwardExceptionsViewModel(OutwardOpenExceptionsEntity outwardOpenExceptionsEntity);

	List<OutwardExceptionsViewModel> mapToOutwardExceptionsViewModelList(
            List<OutwardOpenExceptionsEntity> outwardOpenExceptionsEntityList);

	// --------------- MISC OPEN EXCEPTION ENTITY MAPPER

	MiscExceptionsViewModel mapToMiscOpenExceptionsViewModel(MiscOpenExceptionsEntity miscOpenExceptionsEntity);

	List<MiscExceptionsViewModel> mapToMiscOpenExceptionsViewModelList(
            List<MiscOpenExceptionsEntity> miscOpenExceptionsEntities);

	// --------------- PRORATION OPEN EXCEPTION ENTITY MAPPER

	ProrationExceptionsViewModel mapToProrationOpenExceptionsViewModel(
            ProrationOpenExceptionsEntity prorationOpenExceptionsEntity);

	List<ProrationExceptionsViewModel> mapToProrationOpenExceptionsViewModelList(
            List<ProrationOpenExceptionsEntity> prorationOpenExceptionsEntities);

	// --------------- GENERAL OPEN EXCEPTION ENTITY MAPPER

	GeneralExceptionsViewModel mapToGeneralOpenExceptionsViewModel(
            GeneralOpenExceptionsEntity generalOpenExceptionsEntity);

	List<GeneralExceptionsViewModel> mapToGeneralOpenExceptionsViewModelList(
            List<GeneralOpenExceptionsEntity> generalOpenExceptionsEntities);

	// ----------- OPTIONAL WRAP & UNWRAP ----------------------
	@Override
	default <T> T unwrapOptional(Optional<T> optional) {
		return optional.orElse(null);
	}

	@Override
	default Optional<String> wrapOptional(String string) {
		return Optional.of(string);
	}
}
