package com.sgl.smartpra.exception.txn.app.dao.impl;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnAuditDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnAuditEntity;
import com.sgl.smartpra.exception.txn.app.dao.repository.ExceptionTxnAuditRepository;

@Component
@Transactional
public class ExceptionTxnAuditDaoImpl implements ExceptionTxnAuditDao {
	
	private ExceptionTxnAuditRepository exceptionTxnAuditRepository;

	public void createExceptionTransactionAuditRecord(List<ExceptionTxnAuditEntity> exceptionTxnAuditEntity){
		
		 exceptionTxnAuditRepository.saveAll(exceptionTxnAuditEntity);
	}
}
