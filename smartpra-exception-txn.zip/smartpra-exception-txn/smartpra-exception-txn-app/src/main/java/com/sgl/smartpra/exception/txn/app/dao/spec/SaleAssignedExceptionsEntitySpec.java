package com.sgl.smartpra.exception.txn.app.dao.spec;

import com.sgl.smartpra.exception.txn.app.dao.entity.SaleAssignedExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class SaleAssignedExceptionsEntitySpec {

	private SaleAssignedExceptionsEntitySpec() {
	}

	public static Specification<SaleAssignedExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return (saleAssignedExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (exceptionTxnSearchModel.getModuleId() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("moduleId"),
						exceptionTxnSearchModel.getModuleId()));
			}

			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getBatchType() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("batchType"),
						exceptionTxnSearchModel.getBatchType()));
			}
			if (exceptionTxnSearchModel.getBatchNumber() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("batchNumber"),
						exceptionTxnSearchModel.getBatchNumber()));
			}
			if (exceptionTxnSearchModel.getReportingCurrency() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("reportingCurrency"),
						exceptionTxnSearchModel.getReportingCurrency()));
			}
			if (exceptionTxnSearchModel.getFromReportingPeriod() != null
					&& exceptionTxnSearchModel.getToReporingPeriod() == null) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(
						saleAssignedExceptionsEntity.get("fromReportingPeriod"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromReportingPeriod().atStartOfDay())));
			} else if (exceptionTxnSearchModel.getFromReportingPeriod() == null
					&& exceptionTxnSearchModel.getToReporingPeriod() != null) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(saleAssignedExceptionsEntity.get("toReporingPeriod"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToReporingPeriod().atTime(LocalTime.MAX))));
			} else if (exceptionTxnSearchModel.getFromReportingPeriod() != null
					&& exceptionTxnSearchModel.getToReporingPeriod() != null) {
				predicates
						.add(criteriaBuilder.or(
								criteriaBuilder.between(
										criteriaBuilder.literal(
												exceptionTxnSearchModel.getFromReportingPeriod().atStartOfDay()),
										saleAssignedExceptionsEntity.get("fromReportingPeriod"),
										saleAssignedExceptionsEntity.get("toReporingPeriod")),
								criteriaBuilder.between(
										criteriaBuilder.literal(
												exceptionTxnSearchModel.getToReporingPeriod().atTime(LocalTime.MAX)),
										saleAssignedExceptionsEntity.get("fromReportingPeriod"),
										saleAssignedExceptionsEntity.get("toReporingPeriod"))));
			}

			if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() == null) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(saleAssignedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay())));
			} else if (exceptionTxnSearchModel.getFromDate() == null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(saleAssignedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			} else if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.between(saleAssignedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay()),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			}

			if (exceptionTxnSearchModel.getAging() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("aging"),
						exceptionTxnSearchModel.getAging()));
			}
			
			if (exceptionTxnSearchModel.getEnvironment() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("environment"),
						exceptionTxnSearchModel.getEnvironment()));
			}
			
			if (exceptionTxnSearchModel.getExceptionCategory() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("exceptionCategory"),
						exceptionTxnSearchModel.getExceptionCategory()));
			}

			if (exceptionTxnSearchModel.getExceptionType() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("exceptionType"),
						exceptionTxnSearchModel.getExceptionType()));
			}
			if (exceptionTxnSearchModel.getAirlineType() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("airlineType"),
						exceptionTxnSearchModel.getAirlineType()));
			}
			if (exceptionTxnSearchModel.getExceptionCode() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("exceptionCode"),
						exceptionTxnSearchModel.getExceptionCode()));
			}
			if (exceptionTxnSearchModel.getTeamId() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("teamId"),
						exceptionTxnSearchModel.getTeamId()));
			}
			if (exceptionTxnSearchModel.getGroupId() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("groupId"),
						exceptionTxnSearchModel.getGroupId()));
			}
			if (exceptionTxnSearchModel.getUserId() != null) {
				predicates.add(criteriaBuilder.equal(saleAssignedExceptionsEntity.get("userId"),
						exceptionTxnSearchModel.getUserId()));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
}
