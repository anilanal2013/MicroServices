package com.sgl.smartpra.exception.txn.app.service;

import com.sgl.smartpra.exception.txn.app.dao.result.ExceptionWipCountModel;
import com.sgl.smartpra.exception.txn.model.*;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ExceptionTxnWIPService {

    public void updateExceptionTxnWIPRecords(ExceptionTxnAggregationModel exceptionTxnAggregationModel);

    public List<ExceptionTxnWIPModel> getExceptionTxnWIPRecords(String aggregationId);

    public ExceptionsViewPaginationModel searchExceptionTxnWIPRecords(Pageable pageable,
                                                                      ExceptionTxnSearchModel exceptionTxnSearchModel);

    public List<? extends ExceptionsViewModel> searchExceptionTxnWIPRecords(ExceptionTxnSearchModel exceptionTxnSearchModel);

    public void sendToExceptionTxnAssignmentQueue(ExceptionTxnAssignmentModel exceptionTxnAssignmentModel);

    public void updateWipTxn(List<ExceptionTxnWIPModel> exceptionTxnWIPModel);

    List<ExceptionWipCountModel> getAssignedUserExceptions(List<Long> userIds);

    WipExceptionsPaginationModel getAllCommonWipExceptions(ExceptionTxnWIPModel exceptionTransactionModel, Pageable pageable);

    void moveFromExceptionTnxToWip(ExceptionTxnAggregationModel exceptionTxnAggregationModels);

    void reassignExceptionByAggregationId(String exceptionTxnAggregationModel);

}

