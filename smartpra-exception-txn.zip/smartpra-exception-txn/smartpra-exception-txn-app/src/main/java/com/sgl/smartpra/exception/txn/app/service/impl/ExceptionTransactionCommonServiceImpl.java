package com.sgl.smartpra.exception.txn.app.service.impl;

import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnDao;
import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnWipDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTransactionMapper;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTxnSearchMapper;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTxnSearchWipMapper;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTxnWipMapper;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTransactionCommonService;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTransactionService;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnWIPService;
import com.sgl.smartpra.exception.txn.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;


@Service
@Transactional
@Slf4j
public class ExceptionTransactionCommonServiceImpl implements ExceptionTransactionCommonService {


    @Autowired
    private ExceptionTxnDao exceptionTxnDao;

    @Autowired
    private ExceptionTxnWipDao exceptionTxnWipDao;

    @Autowired
    private ExceptionTransactionMapper exceptionTransactionMapper;

    @Autowired
    private ExceptionTxnSearchMapper exceptionTxnSearchMapper;

    @Autowired
    private ExceptionTxnSearchWipMapper exceptionTxnSearchWipMapper;

    @Autowired
    private ExceptionTxnWipMapper exceptionTxnWipMapper;

    @Autowired
    private ExceptionTransactionService exceptionTransactionService;

    @Autowired
    private ExceptionTxnWIPService exceptionTxnWIPService;


    @Override
    public void deleteExceptionById(String documentUniqueId, Integer couponNumber) {
        CompletableFuture.runAsync(() -> exceptionTxnDao.deleteByDocumentUniqueIdAndCouponNumber(documentUniqueId,
                couponNumber));
        CompletableFuture.runAsync(() -> exceptionTxnWipDao.deleteByDocumentUniqueIdAndCouponNumber(documentUniqueId,
                couponNumber));
    }

    @Override
    public List<? extends ExceptionTxnBaseModel> search(ExceptionTxnClosedSearchModel searchModel) {

        List<ExceptionTransactionEntity> transactionEntityList = exceptionTxnDao.
                findAll(Example.of(exceptionTxnSearchMapper.mapToEntity(searchModel)));

        return transactionEntityList != null && transactionEntityList.isEmpty() ? exceptionTxnWipMapper.mapToModel(exceptionTxnWipDao.
                findAll(Example.of(exceptionTxnSearchWipMapper.mapToEntity(searchModel)))) : exceptionTransactionMapper.mapToModel(transactionEntityList);

    }

    @Override
    public List<ExceptionsViewModel> getAllExceptionTxn(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        List<ExceptionsViewModel> exceptionsViewModels = new ArrayList<>();
        exceptionsViewModels.addAll(exceptionTransactionService.searchOpenExceptionTxnRecords(exceptionTxnSearchModel));
        exceptionsViewModels.addAll(exceptionTxnWIPService.searchExceptionTxnWIPRecords(exceptionTxnSearchModel));
        return exceptionsViewModels;
    }

    @Override
    public OpenExceptionsPaginationModel getAllOpenExceptionTxn(ExceptionTransactionModel transactionModel, Pageable pageable) {
        return exceptionTransactionService.getAllOpenExceptionTxn(transactionModel, pageable);
    }

    @Override
    public WipExceptionsPaginationModel getAllCommonWipExceptions(ExceptionTxnWIPModel exceptionTxnWIPModel, Pageable pageable) {
        return exceptionTxnWIPService.getAllCommonWipExceptions(exceptionTxnWIPModel, pageable);
    }


}
