package com.sgl.smartpra.exception.txn.app.dao.entity;

import com.sgl.smartpra.exception.txn.enums.ExceptionCategoryEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionSeverityEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionTypeEnum;
import com.sgl.smartpra.exception.txn.enums.converter.ExceptionCategoryEnumConverter;
import com.sgl.smartpra.exception.txn.enums.converter.ExceptionSeverityEnumConverter;
import com.sgl.smartpra.exception.txn.enums.converter.ExceptionTypeEnumConverter;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@MappedSuperclass
public class ExceptionsViewEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private Long exceptionTransId;

	@Column(name = "module_lov_id")
	private Integer moduleId;

	@Column(name = "field_short_desc")
	private String moduleName;

	@Column(name = "issued_carrier")
	private String issueAirline;

	private String exceptionCode;

	@Convert(converter = ExceptionTypeEnumConverter.class)
	private ExceptionTypeEnum exceptionType;

	@Column(name = "exception_mas_id")
	private Integer exceptionMasterId;

	@Convert(converter = ExceptionCategoryEnumConverter.class)
	private ExceptionCategoryEnum exceptionCategory;

	private String exceptionDetails;

	private Integer aging;

	private LocalDateTime exceptionDate;

	@Convert(converter = ExceptionSeverityEnumConverter.class)
	private ExceptionSeverityEnum exceptionSeverity;

	private String mainDocument;

	private String originalDocument;

	private String conjunctionDocument;

	private Integer couponNumber;

	private String documentUniqueId;

	private Long fileId;

	private String environment;

	private Long stagingReferenceId;

    private Integer screenId;


}
