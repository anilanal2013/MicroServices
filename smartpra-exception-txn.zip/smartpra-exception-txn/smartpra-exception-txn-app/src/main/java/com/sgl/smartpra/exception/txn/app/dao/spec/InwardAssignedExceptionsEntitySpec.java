package com.sgl.smartpra.exception.txn.app.dao.spec;

import com.sgl.smartpra.exception.txn.app.dao.entity.InwardAssignedExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class InwardAssignedExceptionsEntitySpec  {
	private InwardAssignedExceptionsEntitySpec() {
		
	}

	public static Specification<InwardAssignedExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return (inwardAssignedExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

            if (exceptionTxnSearchModel.getModuleId() != null) {
                predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("moduleId"),
                        exceptionTxnSearchModel.getModuleId()));
            }

			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getBillingCarrier() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("billingCarrier"),
						exceptionTxnSearchModel.getBillingCarrier()));
			}
			if (exceptionTxnSearchModel.getBilledCarrier() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("billedCarrier"),
						exceptionTxnSearchModel.getBilledCarrier()));
			}
			if (exceptionTxnSearchModel.getSourceCode() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("sourceCode"),
						exceptionTxnSearchModel.getSourceCode()));
			}
			if (exceptionTxnSearchModel.getInvoiceNo() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("invoiceNo"),
						exceptionTxnSearchModel.getInvoiceNo()));
			}

			if (exceptionTxnSearchModel.getInvoiceDate() != null) {
				predicates.add(criteriaBuilder.between(inwardAssignedExceptionsEntity.get("invoiceDate"),
						exceptionTxnSearchModel.getInvoiceDate().atStartOfDay(),
						exceptionTxnSearchModel.getInvoiceDate().atTime(LocalTime.MAX)));
			}

			if (exceptionTxnSearchModel.getBillingDate() != null) {
				predicates.add(criteriaBuilder.between(inwardAssignedExceptionsEntity.get("billingDate"),
						exceptionTxnSearchModel.getBillingDate().atStartOfDay(),exceptionTxnSearchModel.getBillingDate().atTime(LocalTime.MAX)));
			}

			if (exceptionTxnSearchModel.getAging() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("aging"),
						exceptionTxnSearchModel.getAging()));
			}
			
			if (exceptionTxnSearchModel.getEnvironment() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("environment"),
						exceptionTxnSearchModel.getEnvironment()));
			}
			
			if (exceptionTxnSearchModel.getExceptionCategory() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("exceptionCategory"),
						exceptionTxnSearchModel.getExceptionCategory()));
			}

			if (exceptionTxnSearchModel.getExceptionType() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("exceptionType"),
						exceptionTxnSearchModel.getExceptionType()));
			}
			if (exceptionTxnSearchModel.getAirlineType() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("airlineType"),
						exceptionTxnSearchModel.getAirlineType()));
			}
			if (exceptionTxnSearchModel.getExceptionCode() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("exceptionCode"),
						exceptionTxnSearchModel.getExceptionCode()));
			}

			if (exceptionTxnSearchModel.getStagingReferenceId() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("stagingReferenceId"),
						exceptionTxnSearchModel.getStagingReferenceId()));
			}
			if (exceptionTxnSearchModel.getTeamId() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("teamId"),
						exceptionTxnSearchModel.getTeamId()));
			}
			if (exceptionTxnSearchModel.getGroupId() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("groupId"),
						exceptionTxnSearchModel.getGroupId()));
			}
			if (exceptionTxnSearchModel.getUserId() != null) {
				predicates.add(criteriaBuilder.equal(inwardAssignedExceptionsEntity.get("userId"),
						exceptionTxnSearchModel.getUserId()));
			}
			
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
}
		}
