package com.sgl.smartpra.exception.txn.app.dao.spec;

import com.sgl.smartpra.exception.txn.app.dao.entity.OutwardAssignedExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class OutwardAssignedExceptionsEntitySpec {

	private OutwardAssignedExceptionsEntitySpec() {

	}

	public static Specification<OutwardAssignedExceptionsEntity> search(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return (outwardAssignedExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
            if (exceptionTxnSearchModel.getModuleId() != null) {
                predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("moduleId"),
                        exceptionTxnSearchModel.getModuleId()));
            }

			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getBillingCarrier() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("billingCarrier"),
						exceptionTxnSearchModel.getBillingCarrier()));
			}
			if (exceptionTxnSearchModel.getBilledCarrier() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("billedCarrier"),
						exceptionTxnSearchModel.getBilledCarrier()));
			}
			if (exceptionTxnSearchModel.getSourceCode() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("sourceCode"),
						exceptionTxnSearchModel.getSourceCode()));
			}
			if (exceptionTxnSearchModel.getInvoiceNo() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("invoiceNo"),
						exceptionTxnSearchModel.getInvoiceNo()));
			}

			if (exceptionTxnSearchModel.getInvoiceDate() != null) {
				predicates.add(criteriaBuilder.between(outwardAssignedExceptionsEntity.get("invoiceDate"),
						exceptionTxnSearchModel.getInvoiceDate().atStartOfDay(),
						exceptionTxnSearchModel.getInvoiceDate().atTime(LocalTime.MAX)));
			}

			if (exceptionTxnSearchModel.getBillingDate() != null) {
				predicates.add(criteriaBuilder.between(outwardAssignedExceptionsEntity.get("billingDate"),
						exceptionTxnSearchModel.getBillingDate().atStartOfDay(),exceptionTxnSearchModel.getBillingDate().atTime(LocalTime.MAX)));
			}

			if (exceptionTxnSearchModel.getAging() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("aging"),
						exceptionTxnSearchModel.getAging()));
			}

			if (exceptionTxnSearchModel.getEnvironment() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("environment"),
						exceptionTxnSearchModel.getEnvironment()));
			}

			if (exceptionTxnSearchModel.getExceptionCategory() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("exceptionCategory"),
						exceptionTxnSearchModel.getExceptionCategory()));
			}

			if (exceptionTxnSearchModel.getExceptionType() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("exceptionType"),
						exceptionTxnSearchModel.getExceptionType()));
			}
			if (exceptionTxnSearchModel.getAirlineType() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("airlineType"),
						exceptionTxnSearchModel.getAirlineType()));
			}
			if (exceptionTxnSearchModel.getExceptionCode() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("exceptionCode"),
						exceptionTxnSearchModel.getExceptionCode()));
			}
			if (exceptionTxnSearchModel.getStagingReferenceId() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("stagingReferenceId"),
						exceptionTxnSearchModel.getStagingReferenceId()));
			}
			if (exceptionTxnSearchModel.getTeamId() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("teamId"),
						exceptionTxnSearchModel.getTeamId()));
			}
			if (exceptionTxnSearchModel.getGroupId() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("groupId"),
						exceptionTxnSearchModel.getGroupId()));
			}
			if (exceptionTxnSearchModel.getUserId() != null) {
				predicates.add(criteriaBuilder.equal(outwardAssignedExceptionsEntity.get("userId"),
						exceptionTxnSearchModel.getUserId()));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
