package com.sgl.smartpra.exception.txn.app.dao.result;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Id;

public interface ExceptionWipCountModel {

	@Id
	Integer getExceptionMasterId();

	Long getUserId();

}
