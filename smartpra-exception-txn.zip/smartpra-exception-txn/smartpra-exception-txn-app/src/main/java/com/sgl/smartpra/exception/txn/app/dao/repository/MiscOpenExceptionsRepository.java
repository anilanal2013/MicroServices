package com.sgl.smartpra.exception.txn.app.dao.repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.MiscOpenExceptionsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MiscOpenExceptionsRepository
        extends JpaRepository<MiscOpenExceptionsEntity, Long>, JpaSpecificationExecutor<MiscOpenExceptionsEntity> {


    public List<MiscOpenExceptionsEntity> findByModuleId(Integer moduleId);

}
