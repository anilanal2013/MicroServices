package com.sgl.smartpra.exception.txn.app.dao.impl;

import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.*;
import com.sgl.smartpra.exception.txn.app.dao.repository.*;
import com.sgl.smartpra.exception.txn.app.dao.spec.*;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Component
@Transactional
public class ExceptionTxnDaoImpl implements ExceptionTxnDao {

	@Autowired
	private SaleOpenExceptionsRepository saleOpenExceptionsRepository;

	@Autowired
	private FlownOpenExceptionsRepository flownOpenExceptionsRepository;

	@Autowired
	private InwardOpenExceptionsRepository inwardOpenExceptionsRepository;

	@Autowired
	private OutwardOpenExceptionsRepository outwardOpenExceptionsRepository;

	@Autowired
	private MiscOpenExceptionsRepository miscOpenExceptionsRepository;

	@Autowired
	private ProrationOpenExceptionsRepository prorationOpenExceptionsRepository;

	@Autowired
	private GeneralOpenExceptionsRepository generalOpenExceptionsRepository;

	@Autowired
	private ExceptionTransactionRepository exceptionTransactionRepository;

	@Autowired
	private ExceptionParametersValueRepository parametersValueRepository;

	@Override
	public void deleteExceptionTxnRecords(List<ExceptionTransactionEntity> exceptionTransactionEntityList) {
		exceptionTransactionRepository.deleteAll(exceptionTransactionEntityList);
	}

	@Override
	public List<ExceptionTransactionEntity> findAllExceptionTxnRecords(List<Long> transactionIds) {
		return exceptionTransactionRepository
				.findAll(Specification.where(ExceptionTxnSpecification.exceptionTransactionsIn(transactionIds)));
	}

	@Override
	public Optional<ExceptionTransactionEntity> findByExceptionTransactionId(Long exceptionTransactionId) {
		return exceptionTransactionRepository.findById(exceptionTransactionId);
	}

	@Override
	public List<ExceptionTransactionEntity> findByExceptionMasterId(Integer exceptionMasterId) {
		return exceptionTransactionRepository.findByExceptionMasterId(exceptionMasterId);
	}

	@Override
	public boolean existsById(Long exceptionTransactionId) {
		return exceptionTransactionRepository.existsById(exceptionTransactionId);
	}

	@Override
	public ExceptionTransactionEntity getOne(Long exceptionTransactionId) {
		return exceptionTransactionRepository.getOne(exceptionTransactionId);
	}

	@Override
	public List<ExceptionTransactionEntity> findAll(
			Example<ExceptionTransactionEntity> exceptionTransactionEntityExample) {
		return exceptionTransactionRepository.findAll(exceptionTransactionEntityExample);
	}


	@Override
	public ExceptionTransactionEntity save(ExceptionTransactionEntity exceptionTransactionEntity) {
		return exceptionTransactionRepository.save(exceptionTransactionEntity);
	}

	@Override
	public void deleteByExceptionTransactionId(Long exceptionTransactionId) {
		parametersValueRepository.deleteAll(parametersValueRepository
				.findByExceptionTransactionEntityExceptionTransactionId(exceptionTransactionId));
	}

	@Override
	public void deleteByDocumentUniqueIdAndCouponNumber(String documentUniqueId, Integer couponNumber) {
		exceptionTransactionRepository.deleteByDocumentUniqueIdAndCouponNumber(documentUniqueId, couponNumber);
	}

	@Override
	public List<ExceptionTransactionEntity> deleteExceptionTxnRecords(Long fileId) {
		return exceptionTransactionRepository.deleteByFileId(fileId);
	}

	@Override
	public Page<SaleOpenExceptionsEntity> searchSaleOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return saleOpenExceptionsRepository.findAll(SaleOpenExceptionsEntitySpec.search(exceptionTxnSearchModel),
				pageable);
	}

	@Override
	public Page<FlownOpenExceptionsEntity> searchFlownOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return flownOpenExceptionsRepository.findAll(FlownOpenExceptionsEntitySpec.search(exceptionTxnSearchModel),
				pageable);
	}

	@Override
	public Page<InwardOpenExceptionsEntity> searchInwardOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return inwardOpenExceptionsRepository.findAll(InwardOpenExceptionsEntitySpec.search(exceptionTxnSearchModel),
				pageable);
	}

	@Override
	public Page<OutwardOpenExceptionsEntity> searchOutwardOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return outwardOpenExceptionsRepository.findAll(OutwardOpenExceptionsEntitySpec.search(exceptionTxnSearchModel),
				pageable);
	}

	@Override
	public Page<MiscOpenExceptionsEntity> searchMiscOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return miscOpenExceptionsRepository.findAll(MiscOpenExceptionsEntitySpec.search(exceptionTxnSearchModel),
				pageable);
	}

	@Override
	public Page<ProrationOpenExceptionsEntity> searchProrationOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return prorationOpenExceptionsRepository
				.findAll(ProrationOpenExceptionsEntitySpec.search(exceptionTxnSearchModel), pageable);
	}

	@Override
	public Page<GeneralOpenExceptionsEntity> searchGeneralOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel, Pageable pageable) {
		return generalOpenExceptionsRepository.findAll(GeneralOpenExceptionsEntitySpec.search(exceptionTxnSearchModel),
				pageable);
	}

	@Override
	public List<SaleOpenExceptionsEntity> searchSaleOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return saleOpenExceptionsRepository.findAll(SaleOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public List<FlownOpenExceptionsEntity> searchFlownOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return flownOpenExceptionsRepository.findAll(FlownOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public List<InwardOpenExceptionsEntity> searchInwardOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return inwardOpenExceptionsRepository.findAll(InwardOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public List<OutwardOpenExceptionsEntity> searchOutwardOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return outwardOpenExceptionsRepository.findAll(OutwardOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public List<MiscOpenExceptionsEntity> searchMiscOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return miscOpenExceptionsRepository.findAll(MiscOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public List<ProrationOpenExceptionsEntity> searchProrationOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return prorationOpenExceptionsRepository
				.findAll(ProrationOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public List<GeneralOpenExceptionsEntity> searchGeneralOpenExceptionTxnRecords(
			ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return generalOpenExceptionsRepository.findAll(GeneralOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public List<ExceptionTransactionEntity> aggregateByExceptionCodeAndDescription(List<Long> transactionIds) {
		return exceptionTransactionRepository.findByExceptionTransactionIdIn(transactionIds);
	}

	@Override
	public Page<ExceptionTransactionEntity> getAllOpenExceptions(ExceptionTransactionEntity exceptionTransactionEntity,
			Pageable pageable) {
		return exceptionTransactionRepository.findAll(Example.of(exceptionTransactionEntity), pageable);
	}

	@Override
	public List<SaleOpenExceptionsEntity> aggregateSalesException(List<Long> transactionIds) {
		return saleOpenExceptionsRepository.groupByScreenIdAndMasterId(transactionIds);
	}

	@Override
	public Page<ExceptionTransactionEntity> findAllExceptionTxnId(int exceptionCount) {
		Pageable pageable = new PageRequest(0, exceptionCount);
		return exceptionTransactionRepository.findAll(pageable);
	}

	@Override
	public long getAllOpenExceptionTxnCount(ExceptionTransactionEntity transactionModel) {
		return exceptionTransactionRepository.count(Example.of(transactionModel));
	}

	@Override
	public long getSaleOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return saleOpenExceptionsRepository.count(SaleOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public long getFlownOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return flownOpenExceptionsRepository.count(FlownOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public long getInwardOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return inwardOpenExceptionsRepository.count(InwardOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public long getOutwardOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return outwardOpenExceptionsRepository.count(OutwardOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public long getMiscOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return miscOpenExceptionsRepository.count(MiscOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public long getProrationOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return prorationOpenExceptionsRepository
				.count(ProrationOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

	@Override
	public long getGeneralOpenExceptionsCount(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return generalOpenExceptionsRepository.count(GeneralOpenExceptionsEntitySpec.search(exceptionTxnSearchModel));
	}

}
