package com.sgl.smartpra.exception.txn.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnAuditEntity;


@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionTxnAuditMapper {
	
	public List<ExceptionTxnAuditEntity> mapFromExceptionTxnToExceptionAuditMapper(
            List<ExceptionTransactionEntity> exceptionTransactionEntity) ;

}
