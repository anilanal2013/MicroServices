package com.sgl.smartpra.exception.txn.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.GeneralAssignedExceptionsEntity;

@Repository
public interface GeneralAssignedExceptionsRepository  extends JpaRepository<GeneralAssignedExceptionsEntity, Long>,
JpaSpecificationExecutor<GeneralAssignedExceptionsEntity> {

}
