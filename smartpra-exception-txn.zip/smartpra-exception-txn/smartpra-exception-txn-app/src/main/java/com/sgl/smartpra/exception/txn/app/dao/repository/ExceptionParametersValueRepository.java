package com.sgl.smartpra.exception.txn.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionParametersValueEntity;

@Repository
public interface ExceptionParametersValueRepository extends JpaRepository<ExceptionParametersValueEntity, Long>,
		JpaSpecificationExecutor<ExceptionParametersValueEntity> {

	List<ExceptionParametersValueEntity> findByExceptionTransactionEntityExceptionTransactionId(
            Long exceptionTransactionId);
}
