package com.sgl.smartpra.exception.txn.app.service;

public interface ExceptionAllocationService {

    public Long allocateUserByTaskLoad();

    public Long allocateUserByMinWorkTime();
}
