package com.sgl.smartpra.exception.txn.app.dao.spec;

import com.sgl.smartpra.exception.txn.app.dao.entity.MiscClosedExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class MiscClosedExceptionsEntitySpec {

    private MiscClosedExceptionsEntitySpec() {
    }

    public static Specification<MiscClosedExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return (miscClosedExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (exceptionTxnSearchModel.getModuleId() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("moduleId"),
                        exceptionTxnSearchModel.getModuleId()));
            }
            if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("exceptionSeverity"),
                        exceptionTxnSearchModel.getExceptionSeverity()));
            }
            if (exceptionTxnSearchModel.getBillingCarrier() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("billingCarrier"),
                        exceptionTxnSearchModel.getBillingCarrier()));
            }
            if (exceptionTxnSearchModel.getBilledCarrier() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("billedCarrier"),
                        exceptionTxnSearchModel.getBilledCarrier()));
            }
            if (exceptionTxnSearchModel.getChargeCategory() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("chargeCategory"),
                        exceptionTxnSearchModel.getChargeCategory()));
            }
            if (exceptionTxnSearchModel.getInvoiceNo() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("invoiceNo"),
                        exceptionTxnSearchModel.getInvoiceNo()));
            }
            if (exceptionTxnSearchModel.getInvoiceDate() != null) {
                predicates.add(criteriaBuilder.between(miscClosedExceptionsEntity.get("invoiceDate"),
                        exceptionTxnSearchModel.getInvoiceDate().atStartOfDay(),
                        exceptionTxnSearchModel.getInvoiceDate().atTime(LocalTime.MAX)));
            }

            if (exceptionTxnSearchModel.getBillingDate() != null) {
                predicates.add(criteriaBuilder.between(miscClosedExceptionsEntity.get("billingDate"),
                        exceptionTxnSearchModel.getBillingDate().atStartOfDay(), exceptionTxnSearchModel.getBillingDate().atTime(LocalTime.MAX)));
            }

            if (exceptionTxnSearchModel.getAging() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("aging"),
                        exceptionTxnSearchModel.getAging()));
            }

            if (exceptionTxnSearchModel.getEnvironment() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("environment"),
                        exceptionTxnSearchModel.getEnvironment()));
            }

            if (exceptionTxnSearchModel.getExceptionCategory() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("exceptionCategory"),
                        exceptionTxnSearchModel.getExceptionCategory()));
            }

            if (exceptionTxnSearchModel.getExceptionType() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("exceptionType"),
                        exceptionTxnSearchModel.getExceptionType()));
            }

            if (exceptionTxnSearchModel.getExceptionCode() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("exceptionCode"),
                        exceptionTxnSearchModel.getExceptionCode()));
            }
            if (exceptionTxnSearchModel.getIsForceClosed() != null) {
                predicates.add(criteriaBuilder.equal(miscClosedExceptionsEntity.get("isForceClosed"),
                        exceptionTxnSearchModel.getIsForceClosed()));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));

        };
    }
}
