package com.sgl.smartpra.exception.txn.app.mapper;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionTypeEnum;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnClosedSearchModel;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import java.util.Optional;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionTxnSearchMapper extends BaseMapper<ExceptionTxnClosedSearchModel, ExceptionTransactionEntity> {


    // ----- Enum Values Mapper -------------
    default ExceptionStatusEnum toExceptionStatusEnum(String exceptionStatusValue) {
        for (ExceptionStatusEnum exceptionStatusEnum : ExceptionStatusEnum.values()) {
            if (exceptionStatusEnum.getExceptionStatusValue().equals(exceptionStatusValue)) {
                return exceptionStatusEnum;
            }
        }
        return null;
    }

    default ExceptionTypeEnum toExceptionTypeEnum(String exceptionTypeValue) {
        for (ExceptionTypeEnum exceptionTypeEnum : ExceptionTypeEnum.values()) {
            if (exceptionTypeEnum.getExceptionTypeValue().equals(exceptionTypeValue)) {
                return exceptionTypeEnum;
            }
        }
        return null;
    }

    // ----- OPTIONAL WRAP & UNWRAP -------------
    @Override
    default <T> T unwrapOptional(Optional<T> optional) {
        return optional.orElse(null);
    }

    @Override
    default Optional<String> wrapOptional(String string) {
        return Optional.of(string);
    }

    @Override
    default Optional<Long> wrapOptional(Long l) {
        return Optional.of(l);
    }

    @Override
    default Optional<Integer> wrapOptional(Integer integer) {
        return Optional.of(integer);
    }

    @Override
    default Optional<Boolean> wrapOptional(Boolean b) {
        return Optional.of(b);
    }
}
