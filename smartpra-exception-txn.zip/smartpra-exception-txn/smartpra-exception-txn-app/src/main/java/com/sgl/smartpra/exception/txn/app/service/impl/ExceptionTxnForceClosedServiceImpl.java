package com.sgl.smartpra.exception.txn.app.service.impl;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.txn.app.config.FeignConfiguration;
import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnClosedDao;
import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnDao;
import com.sgl.smartpra.exception.txn.app.dao.ExceptionTxnWipDao;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnClosedEntity;
import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTxnWipEntity;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTxnClosedMapper;
import com.sgl.smartpra.exception.txn.app.mapper.ExceptionTxnForceClosedMapper;
import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnForceClosedService;
import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnForceCloseModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import com.sgl.smartpra.exception.txn.model.ExceptionsViewModel;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.task.mgmt.enums.TaskStatusEnum;
import com.sgl.smartpra.task.mgmt.model.TaskAssignment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class ExceptionTxnForceClosedServiceImpl implements ExceptionTxnForceClosedService {

    public static final String DEFAULT_CLIENT_ID = "QR";

    public static final long GROUP_ID = 0L;

    @Autowired
    private ExceptionTxnClosedDao exceptionTxnClosedDao;

    @Autowired
    private ExceptionTxnWipDao exceptionTxnWipDao;

    @Autowired
    private ExceptionTxnDao exceptionTxnDao;

    @Autowired
    private ExceptionTxnClosedMapper exceptionTxnClosedMapper;

    @Autowired
    private ExceptionTxnForceClosedMapper exceptionTxnForceClosedMapper;

    @Autowired
    private FeignConfiguration.ExceptionMasterAppFeignClient exceptionMasterAppFeignClient;

    @Autowired
    private FeignConfiguration.SmartpraTaskMgmtAppClient smartpraTaskMgmtAppClient;

    @Override
    public List<? extends ExceptionsViewModel> search(ExceptionTxnSearchModel txnClosedSearchModel) {
        switch (txnClosedSearchModel.getModuleName()) {
            case SALE:
                break;
            case FLOWN:
                return exceptionTxnClosedMapper.mapToFlownExceptionsViewModelList(
                        exceptionTxnClosedDao.searchFlownClosedExceptionTxnRecords(txnClosedSearchModel));
            case INWARD:
                return exceptionTxnClosedMapper.mapToInwardExceptionsViewModelList(
                        exceptionTxnClosedDao.searchInwardClosedExceptionTxnRecords(txnClosedSearchModel));
            case OUTWARD:
                return exceptionTxnClosedMapper.mapToOutwardExceptionsViewModelList(
                        exceptionTxnClosedDao.searchOutwardClosedExceptionTxnRecords(txnClosedSearchModel));
            case MISC:
                return exceptionTxnClosedMapper.mapToMiscExceptionsViewModelList(
                        exceptionTxnClosedDao.searchMiscClosedExceptionTxnRecords(txnClosedSearchModel));
        }
        return new ArrayList<>();
    }

    @Override
    public ExceptionTxnForceCloseModel forceCloseExceptionByTransactionId(ExceptionTxnForceCloseModel forceCloseModel) {

        // Get the wip entity by wip transaction id
        ExceptionTxnWipEntity exceptionTxnWipEntity = exceptionTxnWipDao
                .findByTransactionId(forceCloseModel.getExceptionTransactionId());

        // check if the particular exception can be force closed , by using
        // exception master id link with master table to check
        ExceptionMasterModel exceptionMasterModel = exceptionMasterAppFeignClient
                .findByExceptionMasterId(DEFAULT_CLIENT_ID, exceptionTxnWipEntity.getExceptionMasterId());

        // if exception can be force closed then move to close and delete the
        // wip
        Optional<Boolean> forceCloseIndicator = exceptionMasterModel.getForceCloseIndicator();

        forceCloseIndicator.ifPresent(canForceClose -> {
            if (Boolean.TRUE.equals(canForceClose) || !("E").equalsIgnoreCase(OptionalUtil.getValue(exceptionMasterModel.getExceptionType()))) {
                ExceptionTxnClosedEntity exceptionTxnClosedEntity = exceptionTxnClosedMapper
                        .mapToExceptionTxnClosedEntity(exceptionTxnWipEntity);
                exceptionTxnClosedEntity.setIsForceClosed(true);
                exceptionTxnClosedEntity.setForceClosedRemarks(forceCloseModel.getRemarks());

                // create force closed exception via async
                CompletableFuture.runAsync(() -> exceptionTxnClosedDao.save(exceptionTxnClosedEntity));

                // delete exception wip records via async
                CompletableFuture.runAsync(() -> exceptionTxnWipDao.deleteExceptionTxnWipRecord(exceptionTxnWipEntity));

                forceCloseModel.setExceptionForceClosed(true);

                if (forceCloseModel.getTaskId() != null) {
                    long wipExceptionCount = exceptionTxnWipDao.findCountByAggregationId(exceptionTxnWipEntity.getAggregationId());
                    if (wipExceptionCount == 0) {
                        TaskAssignment taskAssignment = new TaskAssignment();
                        taskAssignment.setTaskStatus(TaskStatusEnum.FORCE_CLOSED);
                        taskAssignment.setTaskId(forceCloseModel.getTaskId());
                        smartpraTaskMgmtAppClient.updateTask(forceCloseModel.getTaskId(), taskAssignment);
                        forceCloseModel.setTaskForceClosed(true);
                    } else {
                        forceCloseModel.setTaskForceClosed(false);
                    }
                }
            } else {
                throw new BusinessException("Exception Cant be force closed");
            }

        });
        return forceCloseModel;
    }

    @Override
    public void flownForceCloseException(ExceptionTxnForceCloseModel exceptionTxnForceCloseModel) {

        List<ExceptionTxnClosedEntity> exceptionTxnClosedEntities = new ArrayList<>();
        exceptionTxnForceCloseModel.setExceptionMasterId(exceptionMasterAppFeignClient.findByExceptionCode(
                exceptionTxnForceCloseModel.getExceptionCode()).getExceptionMasterId());
        forceCloseFlownOpenExceptions(exceptionTxnForceCloseModel, exceptionTxnClosedEntities);
        forceCloseFlownWipExceptions(exceptionTxnForceCloseModel, exceptionTxnClosedEntities);
    }

    private void forceCloseFlownOpenExceptions(ExceptionTxnForceCloseModel exceptionTxnForceCloseModel,
                                               List<ExceptionTxnClosedEntity> exceptionTxnClosedEntities) {
        List<ExceptionTransactionEntity> exceptionTransactionEntityList = new ArrayList<>();

        List<ExceptionTransactionEntity> exceptionTransactionEntities = exceptionTxnDao.findAll(
                Example.of(exceptionTxnForceClosedMapper.mapToExceptionTransactionEntity(exceptionTxnForceCloseModel),
                        ExampleMatcher.matching()));

        if (!exceptionTransactionEntities.isEmpty()) {
            exceptionTransactionEntities.forEach(exceptionTransactionEntity -> {
                ExceptionTxnClosedEntity exceptionTxnClosedEntity = exceptionTxnClosedMapper.
                        mapOpenExceptionsToExceptionTxnClosedEntity(exceptionTransactionEntity);
                exceptionTxnClosedEntity.setAssignedType(AssignmentTypeEnum.AUTO);
                exceptionTxnClosedEntity.setExceptionStatus(ExceptionStatusEnum.SYSTEM_FORCE_CLOSED);
                exceptionTxnClosedEntity.setGroupId(GROUP_ID);
                exceptionTxnClosedEntity.setForceClosedRemarks(exceptionTxnForceCloseModel.getRemarks());
                exceptionTxnClosedEntity.setIsForceClosed(true);
                exceptionTxnClosedEntities.add(exceptionTxnClosedEntity);
                exceptionTransactionEntityList.add(exceptionTransactionEntity);
            });
            exceptionTxnClosedDao.saveAll(exceptionTxnClosedEntities);
            exceptionTxnDao.deleteExceptionTxnRecords(exceptionTransactionEntityList);
        }
    }

    private void forceCloseFlownWipExceptions(ExceptionTxnForceCloseModel exceptionTxnForceCloseModel,
                                              List<ExceptionTxnClosedEntity> exceptionTxnClosedEntities) {

        List<ExceptionTxnWipEntity> exceptionTxnWipEntityList = new ArrayList<>();

        List<ExceptionTxnWipEntity> exceptionTxnWipEntities = exceptionTxnWipDao.findAll(
                Example.of(exceptionTxnForceClosedMapper.mapToExceptionTransactionWipEntity(exceptionTxnForceCloseModel),
                        ExampleMatcher.matching()));

        if (!exceptionTxnWipEntities.isEmpty()) {
            exceptionTxnWipEntities.forEach(exceptionTxnWipEntity -> {
                ExceptionTxnClosedEntity exceptionTxnClosedEntity = exceptionTxnClosedMapper.
                        mapToExceptionTxnClosedEntity(exceptionTxnWipEntity);
                exceptionTxnClosedEntity.setForceClosedRemarks(exceptionTxnForceCloseModel.getRemarks());
                exceptionTxnClosedEntity.setIsForceClosed(true);
                exceptionTxnClosedEntity.setGroupId(GROUP_ID);
                exceptionTxnClosedEntities.add(exceptionTxnClosedEntity);
                exceptionTxnWipEntityList.add(exceptionTxnWipEntity);
            });
            exceptionTxnClosedDao.saveAll(exceptionTxnClosedEntities);
            exceptionTxnWipDao.deleteExceptionTxnWipRecords(exceptionTxnWipEntityList);
        }
    }

}
