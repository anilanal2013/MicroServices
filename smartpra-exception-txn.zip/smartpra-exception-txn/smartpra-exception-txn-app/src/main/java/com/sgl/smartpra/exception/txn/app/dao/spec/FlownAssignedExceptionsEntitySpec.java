package com.sgl.smartpra.exception.txn.app.dao.spec;

import com.sgl.smartpra.exception.txn.app.dao.entity.FlownAssignedExceptionsEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.Predicate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class FlownAssignedExceptionsEntitySpec {

	private FlownAssignedExceptionsEntitySpec() {
	}

	public static Specification<FlownAssignedExceptionsEntity> search(ExceptionTxnSearchModel exceptionTxnSearchModel) {
		return (flownAssignedExceptionsEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (exceptionTxnSearchModel.getModuleId() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("moduleId"),
						exceptionTxnSearchModel.getModuleId()));
			}

			if (exceptionTxnSearchModel.getExceptionSeverity() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("exceptionSeverity"),
						exceptionTxnSearchModel.getExceptionSeverity()));
			}
			if (exceptionTxnSearchModel.getFlightNumber() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("flightNumber"),
						exceptionTxnSearchModel.getFlightNumber()));
			}
			if (exceptionTxnSearchModel.getFromAirport() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("fromAirport"),
						exceptionTxnSearchModel.getFromAirport()));
			}
			if (exceptionTxnSearchModel.getToAirport() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("toAirport"),
						exceptionTxnSearchModel.getToAirport()));
			}
			if (exceptionTxnSearchModel.getUpliftStation() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("upliftStation"),
						exceptionTxnSearchModel.getUpliftStation()));
			}
			if (exceptionTxnSearchModel.getDepartureDate() != null) {
				predicates.add(criteriaBuilder.between(flownAssignedExceptionsEntity.get("departureDate"),
						exceptionTxnSearchModel.getDepartureDate().atStartOfDay(),
						exceptionTxnSearchModel.getDepartureDate().atTime(LocalTime.MAX)));
			}
			if (exceptionTxnSearchModel.getFlightCreationDate() != null) {
				predicates.add(criteriaBuilder.between(flownAssignedExceptionsEntity.get("flightCreationDate"),
						exceptionTxnSearchModel.getFlightCreationDate().atStartOfDay(),
						exceptionTxnSearchModel.getFlightCreationDate().atTime(LocalTime.MAX)));
			}

			if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() == null) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(flownAssignedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay())));
			} else if (exceptionTxnSearchModel.getFromDate() == null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(flownAssignedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			} else if (exceptionTxnSearchModel.getFromDate() != null && exceptionTxnSearchModel.getToDate() != null) {
				predicates.add(criteriaBuilder.between(flownAssignedExceptionsEntity.get("exceptionDate"),
						criteriaBuilder.literal(exceptionTxnSearchModel.getFromDate().atStartOfDay()),
						criteriaBuilder.literal(exceptionTxnSearchModel.getToDate().atTime(LocalTime.MAX))));
			}

			if (exceptionTxnSearchModel.getAging() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("aging"),
						exceptionTxnSearchModel.getAging()));
			}
			
			if (exceptionTxnSearchModel.getEnvironment() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("environment"),
						exceptionTxnSearchModel.getEnvironment()));
			}
			
			if (exceptionTxnSearchModel.getExceptionCategory() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("exceptionCategory"),
						exceptionTxnSearchModel.getExceptionCategory()));
			}

			if (exceptionTxnSearchModel.getExceptionType() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("exceptionType"),
						exceptionTxnSearchModel.getExceptionType()));
			}
			if (exceptionTxnSearchModel.getAirlineType() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("airlineType"),
						exceptionTxnSearchModel.getAirlineType()));
			}
			if (exceptionTxnSearchModel.getExceptionCode() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("exceptionCode"),
						exceptionTxnSearchModel.getExceptionCode()));
			}
			if (exceptionTxnSearchModel.getCountryCode() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("countryCode"),
						exceptionTxnSearchModel.getCountryCode()));
			}
			if (exceptionTxnSearchModel.getTeamId() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("teamId"),
						exceptionTxnSearchModel.getTeamId()));
			}
			if (exceptionTxnSearchModel.getGroupId() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("groupId"),
						exceptionTxnSearchModel.getGroupId()));
			}
			if (exceptionTxnSearchModel.getUserId() != null) {
				predicates.add(criteriaBuilder.equal(flownAssignedExceptionsEntity.get("userId"),
						exceptionTxnSearchModel.getUserId()));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
}
