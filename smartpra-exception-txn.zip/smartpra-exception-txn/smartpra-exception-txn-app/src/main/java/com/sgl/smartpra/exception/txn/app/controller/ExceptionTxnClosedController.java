package com.sgl.smartpra.exception.txn.app.controller;

import com.sgl.smartpra.exception.txn.app.service.ExceptionTxnClosedService;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnClosedModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnSearchModel;
import com.sgl.smartpra.exception.txn.model.ExceptionsViewPaginationModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@RequestMapping("/closed")
public class ExceptionTxnClosedController {

    @Autowired
    private ExceptionTxnClosedService exceptionTxnClosedService;

    @PostMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void createExpTxnClosedRecords(@RequestBody @Valid ExceptionTxnClosedModel exceptionTxnClosedModel) {
        exceptionTxnClosedService.createExceptionTxnClosedRecords(exceptionTxnClosedModel);
    }

    @PostMapping(path = "/searchClosedExceptions")
    public ExceptionsViewPaginationModel searchExceptionTxnClosedRecords(Pageable pageable,
                                                                         @RequestBody ExceptionTxnSearchModel exceptionTxnSearchModel) {
        return exceptionTxnClosedService.searchExceptionTxnClosedRecords(pageable, exceptionTxnSearchModel);
    }

}