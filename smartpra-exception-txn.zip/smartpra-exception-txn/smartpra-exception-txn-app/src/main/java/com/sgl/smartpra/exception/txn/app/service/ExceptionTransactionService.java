package com.sgl.smartpra.exception.txn.app.service;

import com.sgl.smartpra.exception.txn.app.dao.entity.ExceptionTransactionEntity;
import com.sgl.smartpra.exception.txn.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ExceptionTransactionService {

	public ExceptionTransactionModel getExceptionTransactionById(Long exceptionTransactionId);

	public Long createExceptionTransaction(ExceptionTransactionModel exceptionTransactionModel,
                                           boolean isValidationRequired);

	public void updateExceptionTransaction(ExceptionTransactionModel exceptionTransactionModel,
                                           boolean isValidationRequired);

	public List<ExceptionTransactionModel> getExceptionTransactionListByExceptionCode(String exceptionCode);

	public ExceptionsViewPaginationModel searchOpenExceptionTxnRecords(ExceptionTxnSearchModel exceptionTxnSearchModel,
                                                                       Pageable pageable);

	public List<? extends ExceptionsViewModel> searchOpenExceptionTxnRecords(ExceptionTxnSearchModel exceptionTxnSearchModel);

	public void deleteExceptionTxnRecords(Long fileId, String actionedBy);

	Page<ExceptionTransactionEntity> getAllExceptionTransactionIds(int getAllExceptionTransactionIds);

    OpenExceptionsPaginationModel getAllOpenExceptionTxn(ExceptionTransactionModel transactionModel, Pageable pageable);
}
