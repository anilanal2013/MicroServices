package com.sgl.smartpra.exception.txn.model.validator;

import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

public interface ModelValidator {

	public void validate(ExceptionTransactionModel exceptionTransactionModel,
			ExceptionMasterModel exceptionMasterModel);
}
