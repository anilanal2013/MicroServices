package com.sgl.smartpra.exception.txn.model.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.master.model.ExceptionParametersDefinitionModel;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.exceptions.exception.ConstraintValidationException;
import com.sgl.smartpra.exceptions.exception.ParametersMismatchException;

@Component
public class ExceptionTxnModelValidator implements ModelValidator {

	public void validate(ExceptionTransactionModel exceptionTransactionModel,
			ExceptionMasterModel exceptionMasterModel) {
		validateConstraints(exceptionTransactionModel);
		validateParametersMatch(exceptionTransactionModel, exceptionMasterModel);
	}

	public void validateConstraints(ExceptionTransactionModel exceptionTransactionVO) {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<ExceptionTransactionModel>> constraintViolations = validator
				.validate(exceptionTransactionVO);
		if (constraintViolations != null && !constraintViolations.isEmpty()) {
			throw new ConstraintValidationException(constraintViolations);
		}
	}

	public void validateParametersMatch(ExceptionTransactionModel exceptionTransactionModel,
			ExceptionMasterModel exceptionMasterModel) {
		List<ExceptionParametersDefinitionModel> parametersDefinitionList = exceptionMasterModel
				.getParametersDefinitionList();
		List<ExceptionParametersValueModel> parametersValueList = exceptionTransactionModel.getParametersValueList();
		List<Integer> matchingParametersNameList = new ArrayList<>();

		// validate if parameter definition list is configured for the given exception
		// and if yes then validate whether it matches param value list
		if ((parametersDefinitionList != null && parametersValueList == null)
				|| (parametersDefinitionList == null && parametersValueList != null)) {
			throw new ParametersMismatchException("ParametersValueList", "ParametersDefinitionList",exceptionMasterModel.getExceptionCode());
		}

		// Provided Param definition has been configured for the given exception
		// validate if the size matches with param value list size
		if (parametersDefinitionList != null && parametersValueList != null
				&& parametersDefinitionList.size() != parametersValueList.size()) {
			throw new ParametersMismatchException("ParametersValueList", "ParametersDefinitionList",exceptionMasterModel.getExceptionCode());
		}

		// Assuming the Size of Param def and Param Value list matches, validate whether
		// parameter names in the value list match with the configured param definition
		// names list
		if (parametersDefinitionList != null && parametersValueList != null
				&& parametersDefinitionList.size() == parametersValueList.size()) {
			for (ExceptionParametersDefinitionModel parametersDefinitionModel : parametersDefinitionList) {
				parametersValueList.forEach(parametersValueModel -> {
					if (OptionalUtil.getValue(parametersDefinitionModel.getParameterName())
							.equals(parametersValueModel.getParameterName())) {
						matchingParametersNameList.add(1);
					}
				});
			}
			if (matchingParametersNameList.size() != parametersDefinitionList.size()) {
				throw new ParametersMismatchException("ParametersValueList", "ParametersDefinitionList", exceptionMasterModel.getExceptionCode());
			}
		}

	}

}
