package com.sgl.smartpra.exception.txn.validator.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sgl.smartpra.exception.txn.model.validator.ExceptionTxnModelValidator;
import com.sgl.smartpra.exception.txn.model.validator.ModelValidator;

@Configuration
public class ExceptionTxnValidatorConfig {

	@Bean
	public ModelValidator modelValidator() {
		return new ExceptionTxnModelValidator();
	}
}
