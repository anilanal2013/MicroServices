package com.sgl.smartpra.excep.txn.intell.dao;

import java.util.Optional;

import com.sgl.smartpra.excep.txn.intell.dao.entity.ExceptionTxnAggregationEntity;

public interface ExceptionTxnAggregationDao {

	public Optional<ExceptionTxnAggregationEntity> findByAggregationId(String aggregationId);
	
	public void save(ExceptionTxnAggregationEntity exceptionTxnAggregationEntity);

}
