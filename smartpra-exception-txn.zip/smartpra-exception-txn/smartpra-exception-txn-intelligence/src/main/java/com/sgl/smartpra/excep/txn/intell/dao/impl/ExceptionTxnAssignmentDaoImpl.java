package com.sgl.smartpra.excep.txn.intell.dao.impl;

import com.sgl.smartpra.excep.txn.intell.dao.ExceptionTxnAssignmentDao;
import com.sgl.smartpra.excep.txn.intell.dao.entity.ExceptionTxnAggregationEntity;
import com.sgl.smartpra.excep.txn.intell.dao.repository.ExceptionTxnAggregationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Component
@Transactional
public class ExceptionTxnAssignmentDaoImpl implements ExceptionTxnAssignmentDao {

	@Autowired
	private ExceptionTxnAggregationRepository exceptionAggregationRepository;

	@Override
	public void save(ExceptionTxnAggregationEntity exceptionAggregationEntity) {
		exceptionAggregationRepository.save(exceptionAggregationEntity);
	}

	@Override
	public Optional<ExceptionTxnAggregationEntity> findByAggregationId(String aggregationId) {
		return exceptionAggregationRepository.findById(aggregationId);
		
	}
}
