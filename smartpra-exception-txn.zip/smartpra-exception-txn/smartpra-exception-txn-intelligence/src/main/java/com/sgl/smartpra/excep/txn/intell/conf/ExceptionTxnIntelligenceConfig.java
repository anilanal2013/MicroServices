package com.sgl.smartpra.excep.txn.intell.conf;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.sgl.smartpra.mq.configuration.MQConsumerConfiguration;

@Configuration
@Import(MQConsumerConfiguration.class)
public class ExceptionTxnIntelligenceConfig {

}
