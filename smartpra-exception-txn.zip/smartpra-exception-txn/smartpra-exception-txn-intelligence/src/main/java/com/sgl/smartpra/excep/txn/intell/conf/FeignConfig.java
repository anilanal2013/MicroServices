package com.sgl.smartpra.excep.txn.intell.conf;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sgl.smartpra.exception.txn.model.ExceptionTxnAggregationModel;
import com.sgl.smartpra.task.mgmt.model.TaskAssignment;
import com.sgl.smartpra.task.mgmt.model.UserTask;

@Configuration
public class FeignConfig {

	@FeignClient(value = "smartpra-exception-txn-app")
	public interface ExceptionTxnAppFeignClient {

		@PutMapping("/wip")
		public void updateExpTxnWIPRecord(@RequestBody ExceptionTxnAggregationModel exceptionTxnAggregationModel);

		@PutMapping("/wip/moveFromExceptionTnxToWip")
		public void moveFromExceptionTnxToWip(@RequestBody ExceptionTxnAggregationModel exceptionTxnAggregationModel);
	}

	@FeignClient(value = "smartpra-task-mgmt-app")
	public interface TaskManagementAppFeignClient {

		@PostMapping("/task")
		public TaskAssignment createTask(@RequestBody TaskAssignment taskAssignment);

		@GetMapping("/task/users/{teamId}")
		public List<UserTask> getAllUserTask(@PathVariable("teamId") Long teamId);
	}

}
