package com.sgl.smartpra.excep.txn.intell.service;

import com.sgl.smartpra.exception.txn.model.ExceptionTxnAggregationModel;

public interface ExceptionTxnAggregationService {

	public void updateExceptionTxnAggregationRecord(ExceptionTxnAggregationModel exceptionTxnAggregationModel);
}
