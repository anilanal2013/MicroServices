package com.sgl.smartpra.excep.txn.intell.util;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public final class UUIDUtil {

	private static final String DATE_TIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss:SSS";

	public static String getCurrentDateTimeString() {
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_PATTERN);
		return dateTimeFormatter.format(LocalDateTime.now());
	}

	public static String getUUID(String patternString) {
		return UUID.nameUUIDFromBytes(patternString.getBytes(StandardCharsets.UTF_8)).toString();

	}

	public static String getUUID() {
		return UUID.nameUUIDFromBytes(getCurrentDateTimeString().getBytes(StandardCharsets.UTF_8)).toString();

	}

}
