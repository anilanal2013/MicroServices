package com.sgl.smartpra.excep.txn.intell.consumer;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.excep.txn.intell.service.ExceptionTxnAssignmentService;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnAggregationModel;
import com.sgl.smartpra.mq.consumer.Consumer;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ExceptionTxnAssignmentMsgConsumer implements Consumer {

	@Autowired
	private ExceptionTxnAssignmentService exceptionTxnAssignmentService;

	@Override
	public void receive(String message) throws IOException {
		try {
			exceptionTxnAssignmentService.assignExceptionTransactions(
					new ObjectMapper().readValue(message, ExceptionTxnAggregationModel.class));
		} catch (Exception e) {
			log.error("Exception occured in ExceptionTxnAssignmentQueueConsumer: E{}", e);
		}
	}

}
