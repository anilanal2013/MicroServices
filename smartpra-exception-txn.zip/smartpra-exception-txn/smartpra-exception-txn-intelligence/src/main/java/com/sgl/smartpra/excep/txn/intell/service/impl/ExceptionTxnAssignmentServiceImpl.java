package com.sgl.smartpra.excep.txn.intell.service.impl;

import com.sgl.smartpra.excep.txn.intell.conf.FeignConfig.ExceptionTxnAppFeignClient;
import com.sgl.smartpra.excep.txn.intell.conf.FeignConfig.TaskManagementAppFeignClient;
import com.sgl.smartpra.excep.txn.intell.dao.ExceptionTxnAssignmentDao;
import com.sgl.smartpra.excep.txn.intell.dao.entity.ExceptionTxnAggregationEntity;
import com.sgl.smartpra.excep.txn.intell.mapper.ExceptionTxnAggregationMapper;
import com.sgl.smartpra.excep.txn.intell.service.ExceptionTxnAssignmentService;
import com.sgl.smartpra.excep.txn.intell.util.UUIDUtil;
import com.sgl.smartpra.exception.txn.enums.AssignmentTypeEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnAggregationModel;
import com.sgl.smartpra.task.mgmt.enums.TaskStatusEnum;
import com.sgl.smartpra.task.mgmt.model.TaskAssignment;
import com.sgl.smartpra.task.mgmt.model.UserTask;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class ExceptionTxnAssignmentServiceImpl implements ExceptionTxnAssignmentService {

    @Autowired
    private ExceptionTxnAssignmentDao exceptionTxnAssignmentDao;

    @Autowired
    private ExceptionTxnAggregationMapper exceptionTxnAggregationMapper;

    @Autowired
    private ExceptionTxnAppFeignClient exceptionTxnAppFeignClient;

    @Autowired
    private TaskManagementAppFeignClient taskManagementAppFeignClient;

    private static final String LAST_UPDATED_BY_SYSTEM = "SYSTEM";

    @Override
    public void assignExceptionTransactions(ExceptionTxnAggregationModel exceptionTxnAggregationModel) {
        if (exceptionTxnAggregationModel.getAssignmentType() == AssignmentTypeEnum.MANUAL) {
            manualExceptionTxnAssignment(exceptionTxnAggregationModel);
        } else if (exceptionTxnAggregationModel.getAssignmentType() == AssignmentTypeEnum.PULL_PUSH) {
            autoExceptionTxnAssignment(exceptionTxnAggregationModel);
        }
    }

    private void manualExceptionTxnAssignment(ExceptionTxnAggregationModel exceptionTxnAggregationModel) {
        exceptionTxnAggregationModel.setAggregationId(UUIDUtil.getUUID());
        log.info("{}", exceptionTxnAggregationModel);

        // if user is not present, auto populating users to that particular task
        if (exceptionTxnAggregationModel.getUserId() == null) {
            exceptionTxnAggregationModel.setUserId(assignUserId(exceptionTxnAggregationModel.getTeamId()));
        }

        createExceptionTxnAggregationRecord(exceptionTxnAggregationModel);

        // create task assignment
        createTaskAssignmentRecord(exceptionTxnAggregationModel, AssignmentTypeEnum.MANUAL);

        // update the exception txn table with aggregation id, userId (if the userId was
        // not provided during manual assignment)
        moveExceptionTxnToWip(exceptionTxnAggregationModel, AssignmentTypeEnum.MANUAL);
    }

    private void autoExceptionTxnAssignment(ExceptionTxnAggregationModel exceptionTxnAggregationModel) {
        exceptionTxnAggregationModel.setAggregationId(UUIDUtil.getUUID());

        log.info("{}", exceptionTxnAggregationModel);

        createExceptionTxnAggregationRecord(exceptionTxnAggregationModel);

        // create task assignment
        createTaskAssignmentRecord(exceptionTxnAggregationModel, AssignmentTypeEnum.PULL_PUSH);

        // update the exception txn table with aggregation id, userId (if the userId was
        // not provided during manual assignment)
        moveExceptionTxnToWip(exceptionTxnAggregationModel,  AssignmentTypeEnum.PULL_PUSH);

    }

    private void createExceptionTxnAggregationRecord(ExceptionTxnAggregationModel exceptionTxnAggregationModel) {
        ExceptionTxnAggregationEntity exceptionAggregationEntity = exceptionTxnAggregationMapper
                .mapToEntity(exceptionTxnAggregationModel);
        log.info("{}", exceptionAggregationEntity);
        exceptionTxnAssignmentDao.save(exceptionAggregationEntity);

    }

    private void moveExceptionTxnToWip(ExceptionTxnAggregationModel exceptionTxnAggregationModel, AssignmentTypeEnum assignmentType) {
        exceptionTxnAggregationModel.setExceptionStatus(ExceptionStatusEnum.ASSIGNED);
        exceptionTxnAggregationModel.setLastUpdatedBy(LAST_UPDATED_BY_SYSTEM);
        exceptionTxnAggregationModel.setAssignedBy(assignmentType.getAssignmentTypeValue());
        exceptionTxnAggregationModel.setAssignedDate(LocalDateTime.now());
//        exceptionTxnAppFeignClient.updateExpTxnWIPRecord(exceptionTxnAggregationModel);
        exceptionTxnAppFeignClient.moveFromExceptionTnxToWip(exceptionTxnAggregationModel);
    }

    private void createTaskAssignmentRecord(ExceptionTxnAggregationModel exceptionTxnAggregationModel, AssignmentTypeEnum assignmentTypeEnum) {
        TaskAssignment taskAssignment = exceptionTxnAggregationMapper.mapToTaskAssignment(exceptionTxnAggregationModel);
        taskAssignment.setAssignedGroupId(exceptionTxnAggregationModel.getGroupId());
        taskAssignment.setAssignedTeamId(exceptionTxnAggregationModel.getTeamId());
        taskAssignment.setAssignedUserId(exceptionTxnAggregationModel.getUserId());
        taskAssignment.setTaskStatus(AssignmentTypeEnum.PULL_PUSH == assignmentTypeEnum ? TaskStatusEnum.OPEN : TaskStatusEnum.ASSIGNED);
        taskAssignment.setIsAdhocTask(Boolean.FALSE);
        taskAssignment.setModuleLovId(exceptionTxnAggregationModel.getModuleLovId());
        taskManagementAppFeignClient.createTask(taskAssignment);
    }

    /*
     * TODO CHECK THIS ISSUE
     * */
    private Long assignUserId(Long teamId) {
        if (teamId != null) {
            List<UserTask> userTaskList = taskManagementAppFeignClient.getAllUserTask(teamId);
            if (userTaskList != null && !userTaskList.isEmpty()) {
                return userTaskList.get(0).getUserId();
            }
            return 0L;
        } else {
            return 0L;
        }
    }

}
