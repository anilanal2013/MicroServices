package com.sgl.smartpra.excep.txn.intell.dao.repository;

import com.sgl.smartpra.excep.txn.intell.dao.entity.ExceptionTxnAggregationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ExceptionTxnAggregationRepository extends JpaRepository<ExceptionTxnAggregationEntity, String> {


}
