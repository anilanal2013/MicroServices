package com.sgl.smartpra.excep.txn.intell.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.excep.txn.intell.dao.ExceptionTxnAggregationDao;
import com.sgl.smartpra.excep.txn.intell.dao.entity.ExceptionTxnAggregationEntity;
import com.sgl.smartpra.excep.txn.intell.mapper.ExceptionTxnAggregationMapper;
import com.sgl.smartpra.excep.txn.intell.service.ExceptionTxnAggregationService;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnAggregationModel;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExceptionTxnAggregationServiceImpl implements ExceptionTxnAggregationService {

	@Autowired
	private ExceptionTxnAggregationDao exceptionTxnAggregationDao;

	@Autowired
	private ExceptionTxnAggregationMapper exceptionTxnAggregationMapper;

	@Override
	public void updateExceptionTxnAggregationRecord(ExceptionTxnAggregationModel exceptionTxnAggregationModel) {
		ExceptionTxnAggregationEntity exceptionTxnAggregationEntity = exceptionTxnAggregationDao
				.findByAggregationId(exceptionTxnAggregationModel.getAggregationId())
				.orElseThrow(() -> new RecordNotFoundException(exceptionTxnAggregationModel.getAggregationId()));
		exceptionTxnAggregationDao.save(
				exceptionTxnAggregationMapper.mapToEntity(exceptionTxnAggregationModel, exceptionTxnAggregationEntity));

	}
}
