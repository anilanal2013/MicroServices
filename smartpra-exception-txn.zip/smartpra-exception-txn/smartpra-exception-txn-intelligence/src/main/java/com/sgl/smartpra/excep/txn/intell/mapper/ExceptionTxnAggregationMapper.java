package com.sgl.smartpra.excep.txn.intell.mapper;

import java.util.Optional;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.excep.txn.intell.dao.entity.ExceptionTxnAggregationEntity;
import com.sgl.smartpra.exception.txn.model.ExceptionTxnAggregationModel;
import com.sgl.smartpra.task.mgmt.model.TaskAssignment;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ExceptionTxnAggregationMapper {

	ExceptionTxnAggregationEntity mapToEntity(ExceptionTxnAggregationModel exceptionTxnAggregationModel);

	ExceptionTxnAggregationEntity mapToEntity(ExceptionTxnAggregationModel exceptionTxnAggregationModel,
                                              @MappingTarget ExceptionTxnAggregationEntity exceptionTxnAggregationEntity);

	TaskAssignment mapToTaskAssignment(ExceptionTxnAggregationModel exceptionTxnAggregationModel);

	// ----- OPTIONAL WRAP & UNWRAP -------------
	default <T> T unwrapOptional(Optional<T> optional) {
		return optional.orElse(null);
	}

	default Optional<String> wrapOptional(String string) {
		return Optional.of(string);
	}

	default Optional<Long> wrapOptional(Long l) {
		return Optional.of(l);
	}

	default Optional<Integer> wrapOptional(Integer integer) {
		return Optional.of(integer);
	}

	default Optional<Boolean> wrapOptional(Boolean b) {
		return Optional.of(b);
	}

}
