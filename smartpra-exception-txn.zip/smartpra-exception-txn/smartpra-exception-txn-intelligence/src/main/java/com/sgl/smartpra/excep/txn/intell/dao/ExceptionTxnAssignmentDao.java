package com.sgl.smartpra.excep.txn.intell.dao;

import java.util.Optional;

import com.sgl.smartpra.excep.txn.intell.dao.entity.ExceptionTxnAggregationEntity;

public interface ExceptionTxnAssignmentDao {

	public void save(ExceptionTxnAggregationEntity exceptionAggregationEntity);

	public Optional<ExceptionTxnAggregationEntity> findByAggregationId(String aggregationId);
}
