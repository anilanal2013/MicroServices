package com.sgl.smartpra.excep.txn.intell.dao.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.excep.txn.intell.dao.ExceptionTxnAggregationDao;
import com.sgl.smartpra.excep.txn.intell.dao.entity.ExceptionTxnAggregationEntity;
import com.sgl.smartpra.excep.txn.intell.dao.repository.ExceptionTxnAggregationRepository;

@Component
public class ExceptionTxnAggregationDaoImpl implements ExceptionTxnAggregationDao {

	@Autowired
	private ExceptionTxnAggregationRepository exceptionTxnAggregationRepository;

	@Override
	public Optional<ExceptionTxnAggregationEntity> findByAggregationId(String aggregationId) {
		return exceptionTxnAggregationRepository.findById(aggregationId);
	}

	@Override
	public void save(ExceptionTxnAggregationEntity exceptionTxnAggregationEntity) {
		exceptionTxnAggregationRepository.save(exceptionTxnAggregationEntity);
	}
}
