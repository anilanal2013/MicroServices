package com.sgl.smartpra.excep.txn.intell.service;

import com.sgl.smartpra.exception.txn.model.ExceptionTxnAggregationModel;

public interface ExceptionTxnAssignmentService {

	public void assignExceptionTransactions(ExceptionTxnAggregationModel exceptionTxnAggregationModel);

}
