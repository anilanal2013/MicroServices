package com.sgl.smartpra.batch.fdr.app.utils;

public class FDRConstants {
	public static final String FILELOGGING_FILETYPE_FDR_IN = "FDR-IN";
	public static final String FILELOGGING_MODULE = "Others";
	public static final String MODULE_ID = "4";

	public static final String DEFAULT_CLIENT_ID = "QR";

	public static final String CREATEDBY = "FDR_BATCH";
	public static final String UPDATEDBY = "FDR_BATCH";

	public static final String PROD_JOB_NAME = "importFDRProdData";

	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";
	public static final String FLIGHT_NUMBER_OPTION = "FLIGHT_NUMBER_OPTION";

	public static final String FDR = "Industry";

	public static final String FLIGHT_STATUS_UNDER_PROCESS = "U";
	public static final String FLIGHT_STATUS_OUTSTANDING = "O";

	public static final String SERVICE_TYPE_SCHEDULE = "S";
	public static final String FLIGHT_TYPE_DEFAULT = "A";
	public static final String ESTIMATION_FLAG_DEFAULT = "N";
	public static final String BALANCE_FLAG_DEFAULT = "N";
	public static final String SSIM_IND_DEFAULT = "N";

	public static final String CONTROL_VALUE = "V";
	public static final String CONTROL_CAL = "C";

	public static final String PAX_TYPE = "PAX TYPE";
	public static final String PAX_TYPE_I = "I";
	public static final String PAX_TYPE_C = "C";
	public static final String PAX_TYPE_A = "A";

	public static final String DOC_TYPE = "Doc Type";
	public static final String DOC_TYPE_PAX = "PAX";
	public static final String DOC_TYPE_EBT = "EBT";
	public static final String DOC_TYPE_MCO = "MCO";
	public static final String DOC_TYPE_EMD = "EMD";

	public static final String NON_REVENUE_IND = "NonRev Ind";
	public static final String NON_REVENUE_IND_N = "N";
	public static final String NON_REVENUE_IND_Y = "Y";

	public static final String CABIN = "Cabin";
	public static final String CABIN_F = "F";
	public static final String CABIN_C = "C";
	public static final String CABIN_W = "W";
	public static final String CABIN_Y = "Y";

	public static final String SELF_OAL_S = "S";
	public static final String SELF_OAL_O = "O";
	public static final String SELF_OAL_B = "B";
}
