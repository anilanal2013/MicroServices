package com.sgl.smartpra.batch.fdr.app.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.fdr.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.fdr.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.fdr.app.utils.FDRCommonUtil;
import com.sgl.smartpra.batch.fdr.app.utils.FDRConstants;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.global.model.RecordErrorLog;
import com.sgl.smartpra.common.util.FileLoggingConstants;

@Service
public class FDRService {
	private static final Logger LOGGER = LoggerFactory.getLogger(FDRService.class);

	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	@Qualifier(value = "importFdrJob")
	Job importFdrJob;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Value("${batch.directory.fdr.failed}")
	private String failedDir;

	@Value("${batch.directory.fdr.input}")
	private String inputDir;

	@Value("${batch.directory.fdr.duplicate}")
	private String duplicateDir;

	public String executeFDRStgInboundJob(String fileName, String processedBy) throws Exception {

		LOGGER.info("fdrService : executeProvisoStgInboundJob");

		String clientId = FDRCommonUtil.getHostCarrierDesigCode(smartpraMasterAppClient);

		clientId = StringUtils.isEmpty(clientId) ? FDRConstants.DEFAULT_CLIENT_ID : clientId;

		LOGGER.info("fdrService : clientId : " + clientId);

		FileLogging fileLogging = FDRCommonUtil.initFileLogging();

		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_INPUT);
		fileLogging.setFileName(fileName);
		fileLogging.setProcessedBy(processedBy);
		fileLogging.setFileType(FDRConstants.FILELOGGING_FILETYPE_FDR_IN);
		fileLogging.setClientId(clientId);
		fileLogging.setJobName(importFdrJob.getName());

		FileErrorLog fileErrorLog;
		List<FileErrorLog> fileErrorLogList;

		List<FileLogging> fileList = batchGlobalFeignClient.getFileLogByFileName(fileName);

		if (CollectionUtils.isNotEmpty(fileList)) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			String errorMsg = "File with same name " + fileName + " has been already loaded in system with file id "
					+ fileList.get(0).getFileId();

			FDRCommonUtil.moveFile(inputDir + fileName, duplicateDir + fileName + tmpName);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setClientId(clientId);
			fileLogging.setRemarks(errorMsg);
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Invalid File Input");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}

		// Validate file
		String valdationMessage = FDRCommonUtil.validateFile(inputDir + fileName);
		if (StringUtils.isNotEmpty(valdationMessage)) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			FDRCommonUtil.moveFile(inputDir + fileName, failedDir + fileName + tmpName);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setClientId(clientId);
			fileLogging.setRemarks(valdationMessage);
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Invalid File Input");
			fileErrorLog.setErrorDescription(valdationMessage);
			fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return valdationMessage;
		}

		Map<String, Object> recordMap = FDRCommonUtil.getFileHeader(inputDir + fileName);
		RecordErrorLog recordErrorLog;
		List<RecordErrorLog> recordErrorLogList;
		// Header validation
		if (recordMap.isEmpty()) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());

			String errorMsg = "Input file " + fileName + " error in header ";
			FDRCommonUtil.moveFile(inputDir + fileName, failedDir + fileName + tmpName);

			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setRemarks(errorMsg);
			recordErrorLog = new RecordErrorLog();
			recordErrorLog.setRecordNumber(0);
			recordErrorLog.setRecordValue("Header");
			recordErrorLog.setRecordStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			recordErrorLog.setFileId(fileLogging.getFileId());
			recordErrorLog.setErrorDetail("Invalid File Input");
			recordErrorLog.setErrorDescription(errorMsg);
			recordErrorLogList = new ArrayList<>();
			recordErrorLogList.add(recordErrorLog);
			fileLogging.setRecordErrorLog(recordErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}

		fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);

		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addString("fileName", fileName).addString("clientId", clientId)
				.addLong("fileId", fileLogging.getFileId().longValue()).toJobParameters();
		jobLauncher.run(importFdrJob, jobParameters);

		return "Batch job has been invoked";

	}
}
