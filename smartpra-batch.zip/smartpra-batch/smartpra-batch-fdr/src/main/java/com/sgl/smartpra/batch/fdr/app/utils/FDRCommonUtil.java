package com.sgl.smartpra.batch.fdr.app.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.sgl.smartpra.batch.fdr.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.master.model.SystemParameter;

public class FDRCommonUtil {

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	public static FileLogging initFileLogging() {

		FileLogging fileLogging = new FileLogging();
		fileLogging.setFileCategory(FileLoggingConstants.FILELOGGING_FILECATEGORY_TEXT);
		fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setModuleName(FDRConstants.FILELOGGING_MODULE);
		fileLogging.setSource(FDRConstants.FDR);
		fileLogging.setCreatedBy(FDRConstants.CREATEDBY);
		fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));

		// may not be mandatory
		fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_STARTED);
		fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setTotalCounts(0);
		fileLogging.setTransferredCounts(0);
		fileLogging.setIsEncryptedPostSuccess("N");
		fileLogging.setIsEncryptedPriorLoading("N");
		fileLogging.setIsRenamedPostSuccess("N");
		fileLogging.setIsMovedToRelevantFolder("N");
		fileLogging.setIsNotificationSent("N");
		fileLogging.setModuleId(FDRConstants.MODULE_ID);
		return fileLogging;
	}

	public static String getHostCarrierDesigCode(SmartpraMasterAppClient smartpraMasterAppClient) {
		String hostCarrierDesigCode = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient
				.getSystemParameterByparameterName(FDRConstants.PARAM_DEFAULT_CARRIER_ALPHA_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierDesigCode = OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());
		}
		return hostCarrierDesigCode;
	}

	public static String getFileSize(String fileName) {
		File fileObj = new File(fileName);
		return FileUtils.byteCountToDisplaySize(fileObj.length());
	}

	public static boolean moveFile(String source, String target) {
		Path moveResp = null;
		try {
			moveResp = Files.move(Paths.get(source), Paths.get(target));
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return moveResp != null ? true : false;
	}

	public static String validateFile(String fileName) {
		String errorMessage = null;
		File file = new File(fileName);
		String fileNm = file.getName();
		if (!SmartpraFileUtility.fileExists(fileName)) {
			return errorMessage = "File " + fileNm + " not found";
		}

		if (SmartpraFileUtility.isEmptyFile(fileName)) {
			return errorMessage = fileNm + " has no record i.e. Blank file reported";
		}
		return errorMessage;
	}

	public static Map<String, Object> getFileHeader(String fileName) throws Exception {

		Map<String, Object> recordMap = null;
		try {
			File file = new File(fileName);

			BufferedReader bufferedReader = new BufferedReader(new FileReader(file));

			String readLine = bufferedReader.readLine();
			int h_count = 0;

			recordMap = new HashMap<>();
			if (readLine.startsWith("1")) {
				h_count++;
				recordMap.put("header", h_count);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return recordMap;
	}
}
