package com.sgl.smartpra.batch.fdr.app.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.annotation.Scope;

import com.sgl.smartpra.batch.fdr.app.domain.CurrencyHeader;



@Scope(value="step")
public class FDRHeaderProcessor implements ItemProcessor<CurrencyHeader, CurrencyHeader> {


	public CurrencyHeader process(CurrencyHeader item) throws Exception {
		return item;
	}


}
