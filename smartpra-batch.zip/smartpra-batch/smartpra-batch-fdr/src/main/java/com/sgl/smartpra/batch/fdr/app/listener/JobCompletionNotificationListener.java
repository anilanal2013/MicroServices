package com.sgl.smartpra.batch.fdr.app.listener;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.fdr.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.fdr.app.utils.FDRCommonUtil;
import com.sgl.smartpra.batch.fdr.app.utils.FDRConstants;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;

@Component
public class JobCompletionNotificationListener extends JobExecutionListenerSupport {

	private static final Logger LOGGER = LoggerFactory.getLogger(JobCompletionNotificationListener.class);

	@Value("${batch.directory.fdr.processed}")
	private String processedDir;

	@Value("${batch.directory.fdr.failed}")
	private String failedDir;

	@Value("${batch.directory.fdr.input}")
	private String inputDir;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Override
	public void afterJob(JobExecution jobExecution) {
		StepExecution stepExecution = jobExecution.getStepExecutions().stream().findAny().get();

		Integer skipCount = (Integer) jobExecution.getExecutionContext().get("duplicateRecord");

		Integer readCount = stepExecution.getReadCount();
		JobParameters jobParameters = jobExecution.getJobParameters();
		Integer errorCount = (Integer) stepExecution.getExecutionContext().get("errorCount") != null
				? (Integer) stepExecution.getExecutionContext().get("errorCount")
				: 0;
		Integer currencyHeaderCount = (Integer) stepExecution.getExecutionContext().get("currencyHeaderCount");

		Integer headerCount = (currencyHeaderCount != null ? currencyHeaderCount : 0);

		long fileId = jobParameters.getLong("fileId");
		String fileName = jobParameters.getString("fileName");

		FileLogging fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileId));
		fileName = StringUtils.isNotEmpty(fileName) ? fileName : fileLogging.getFileName();
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));

			fileLogging.setSkippedRecordCount(skipCount);
			fileLogging.setTotalCounts(readCount);
			fileLogging.setHeaderCounts(headerCount);
			fileLogging.setDetailCounts(readCount - headerCount);
			fileLogging.setTransferredCounts(readCount - headerCount);
			fileLogging.setErrorCounts(errorCount);
			fileLogging.setJobName(stepExecution.getStepName());
			fileLogging.setFileSize(
					StringUtils.isEmpty(fileLogging.getFileSize()) ? FDRCommonUtil.getFileSize(inputDir + fileName)
							: fileLogging.getFileSize());

			if (FDRConstants.PROD_JOB_NAME.equals("importFDRProdData")) {

				fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
				if (SmartpraFileUtility.fileExists(inputDir + fileName)) {
					FDRCommonUtil.moveFile(inputDir + fileName, processedDir + fileName);
				}
				fileLogging.setIsMovedToRelevantFolder("Y");
			}
			LOGGER.info("!!! JOB FINISHED! Time to verify the results");
		} else {
			fileLogging.setTotalCounts(readCount);
			fileLogging.setDetailCounts(0);
			fileLogging.setTransferredCounts(0);
			fileLogging.setHeaderCounts(0);
			fileLogging.setErrorCounts(readCount);
			fileLogging.setJobName(stepExecution.getStepName());
			fileLogging.setFileSize(
					StringUtils.isEmpty(fileLogging.getFileSize()) ? FDRCommonUtil.getFileSize(inputDir + fileName)
							: fileLogging.getFileSize());
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
			fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK);
			FileErrorLog fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail(jobExecution.getStatus().toString());
			fileErrorLog.setErrorDescription(jobExecution.getFailureExceptions().toString());
			ArrayList<FileErrorLog> fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			FDRCommonUtil.moveFile(inputDir + fileName, failedDir + fileName + tmpName);

			fileLogging.setIsMovedToRelevantFolder("Y");
			LOGGER.info("!!! JOB FINISHED -FAILED ! Time to verify the results");
		}
		fileLogging = batchGlobalFeignClient.updateFileLog(BigInteger.valueOf(fileId), fileLogging);

	}

}