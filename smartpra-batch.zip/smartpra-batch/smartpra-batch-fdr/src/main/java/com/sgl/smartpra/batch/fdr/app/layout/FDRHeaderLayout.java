package com.sgl.smartpra.batch.fdr.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class FDRHeaderLayout extends FixedLengthRecordLayout{

public FDRHeaderLayout() {
		
		fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("effectiveDate",16,23));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("value",24,26));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("variationTo",27,32));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("trailingSpaces",33,null));
	}
	
}
