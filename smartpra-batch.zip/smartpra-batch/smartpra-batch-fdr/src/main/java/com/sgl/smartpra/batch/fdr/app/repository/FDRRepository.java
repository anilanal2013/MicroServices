package com.sgl.smartpra.batch.fdr.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.fdr.app.domain.CurrencyRate;

@Repository
public interface FDRRepository extends JpaRepository<CurrencyRate, Integer> {

	
}
