
package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sgl.smartpra.batch.sales.validator.app.processor.SalesValidatorProcessor;


/**
 * The persistent class for the sales_file_header_stg database table.
 * 
 */
@Entity
@Table(name="sales_file_header_stg")
public class SalesFileHeaderStg  extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="file_hdr_id", unique=true, nullable=false)
	private int fileHdrId;

	@Column(name="bsp_identifier")
	private String bspIdentifier;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="file_id")
	private int fileId;

	@Column(name="file_seq_number")
	private String fileSeqNumber;

	private String filler1;

	@Column(name="handbook_revision_number")
	private String handbookRevisionNumber;

	@Column(name="iso_country_code")
	private String isoCountryCode;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="processing_date")
	private String processingDate;

	@Column(name="processing_time")
	private String processingTime;

	@Column(name="prod_status")
	private String prodStatus;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="tkt_airline_code_number")
	private String tktAirlineCodeNumber;

	//bi-directional many-to-one association to BillingAnalysisCurrencyStg
	@JsonIgnore
	@OneToMany(mappedBy="salesFileHeaderStg", cascade = CascadeType.MERGE)
	private List<BillingAnalysisCurrencyStg> billingAnalysisCurrencyStgs;

	//bi-directional many-to-one association to BillingAnalysisHdrStg
	@JsonIgnore
	@OneToMany(mappedBy="salesFileHeaderStg", cascade = CascadeType.MERGE)
	private List<BillingAnalysisHdrStg> billingAnalysisHdrStgs;

	//bi-directional many-to-one association to FileTotalCurrTypeStg
	@JsonIgnore
	@OneToMany(mappedBy="salesFileHeaderStg", cascade = CascadeType.MERGE)
	private List<FileTotalCurrTypeStg> fileTotalCurrTypeStgs;

	//bi-directional many-to-one association to ReportingOfficeHdrStg
	@JsonIgnore
	@OneToMany(mappedBy="salesFileHeaderStg", cascade = CascadeType.MERGE)
	private List<ReportingOfficeHdrStg> reportingOfficeHdrStgs;

	//bi-directional many-to-one association to TransactionHdrStg
	@JsonIgnore
	@OneToMany(mappedBy="salesFileHeaderStg", cascade = CascadeType.MERGE)
	private List<TransactionHdrStg> transactionHdrStgs;

	public SalesFileHeaderStg() {
	}

	public int getFileHdrId() {
		return this.fileHdrId;
	}

	public void setFileHdrId(int fileHdrId) {
		this.fileHdrId = fileHdrId;
	}

	public String getBspIdentifier() {
		return this.bspIdentifier;
	}

	public void setBspIdentifier(String bspIdentifier) {
		this.bspIdentifier = bspIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public int getFileId() {
		return this.fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getFileSeqNumber() {
		return this.fileSeqNumber;
	}

	public void setFileSeqNumber(String fileSeqNumber) {
		this.fileSeqNumber = fileSeqNumber;
	}

	public String getFiller1() {
		return this.filler1;
	}

	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}

	public String getHandbookRevisionNumber() {
		return this.handbookRevisionNumber;
	}

	public void setHandbookRevisionNumber(String handbookRevisionNumber) {
		this.handbookRevisionNumber = handbookRevisionNumber;
	}

	public String getIsoCountryCode() {
		return this.isoCountryCode;
	}

	public void setIsoCountryCode(String isoCountryCode) {
		this.isoCountryCode = isoCountryCode;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getProcessingDate() {
		return this.processingDate;
	}

	public void setProcessingDate(String processingDate) {
		this.processingDate = processingDate;
	}

	public String getProcessingTime() {
		return this.processingTime;
	}

	public void setProcessingTime(String processingTime) {
		this.processingTime = processingTime;
	}

	public String getProdStatus() {
		return this.prodStatus;
	}

	public void setProdStatus(String prodStatus) {
		this.prodStatus = prodStatus;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTktAirlineCodeNumber() {
		return this.tktAirlineCodeNumber;
	}

	public void setTktAirlineCodeNumber(String tktAirlineCodeNumber) {
		this.tktAirlineCodeNumber = tktAirlineCodeNumber;
	}

	public List<BillingAnalysisCurrencyStg> getBillingAnalysisCurrencyStgs() {
		return this.billingAnalysisCurrencyStgs;
	}

	public void setBillingAnalysisCurrencyStgs(List<BillingAnalysisCurrencyStg> billingAnalysisCurrencyStgs) {
		this.billingAnalysisCurrencyStgs = billingAnalysisCurrencyStgs;
	}

	public BillingAnalysisCurrencyStg addBillingAnalysisCurrencyStg(BillingAnalysisCurrencyStg billingAnalysisCurrencyStg) {
		List<BillingAnalysisCurrencyStg> couponList2 = getBillingAnalysisCurrencyStgs();
		if(couponList2 == null) this.billingAnalysisCurrencyStgs = new ArrayList<BillingAnalysisCurrencyStg>();
		getBillingAnalysisCurrencyStgs().add(billingAnalysisCurrencyStg);
		return billingAnalysisCurrencyStg;
	}

	public BillingAnalysisCurrencyStg removeBillingAnalysisCurrencyStg(BillingAnalysisCurrencyStg billingAnalysisCurrencyStg) {
		getBillingAnalysisCurrencyStgs().remove(billingAnalysisCurrencyStg);
		billingAnalysisCurrencyStg.setSalesFileHeaderStg(null);

		return billingAnalysisCurrencyStg;
	}

	public List<BillingAnalysisHdrStg> getBillingAnalysisHdrStgs() {
		return this.billingAnalysisHdrStgs;
	}

	public void setBillingAnalysisHdrStgs(List<BillingAnalysisHdrStg> billingAnalysisHdrStgs) {
		this.billingAnalysisHdrStgs = billingAnalysisHdrStgs;
	}

	/*public BillingAnalysisHdrStg addBillingAnalysisHdrStg(BillingAnalysisHdrStg billingAnalysisHdrStg) {
		getBillingAnalysisHdrStgs().add(billingAnalysisHdrStg);
		billingAnalysisHdrStg.setSalesFileHeaderStg(this);

		return billingAnalysisHdrStg;
	}
	*/

	public BillingAnalysisHdrStg addBillingAnalysisHdrStg(BillingAnalysisHdrStg billingAnalysisHdrStg) {
List<BillingAnalysisHdrStg> couponList= getBillingAnalysisHdrStgs();
if(couponList==null)  this.billingAnalysisHdrStgs = new ArrayList<BillingAnalysisHdrStg>();
		getBillingAnalysisHdrStgs().add(billingAnalysisHdrStg);
		return billingAnalysisHdrStg;
	}


	public BillingAnalysisHdrStg removeBillingAnalysisHdrStg(BillingAnalysisHdrStg billingAnalysisHdrStg) {
		getBillingAnalysisHdrStgs().remove(billingAnalysisHdrStg);
		billingAnalysisHdrStg.setSalesFileHeaderStg(null);
		return billingAnalysisHdrStg;
	}

	public List<FileTotalCurrTypeStg> getFileTotalCurrTypeStgs() {
		return this.fileTotalCurrTypeStgs;
	}

	public void setFileTotalCurrTypeStgs(List<FileTotalCurrTypeStg> fileTotalCurrTypeStgs) {
		this.fileTotalCurrTypeStgs = fileTotalCurrTypeStgs;
	}

	public FileTotalCurrTypeStg addFileTotalCurrTypeStg(FileTotalCurrTypeStg fileTotalCurrTypeStg) {
		List<FileTotalCurrTypeStg> couponlist1 = getFileTotalCurrTypeStgs();
		if(couponlist1 == null) this.fileTotalCurrTypeStgs = new ArrayList<FileTotalCurrTypeStg>();
		getFileTotalCurrTypeStgs().add(fileTotalCurrTypeStg);
		return fileTotalCurrTypeStg;
	}


	public FileTotalCurrTypeStg removeFileTotalCurrTypeStg(FileTotalCurrTypeStg fileTotalCurrTypeStg) {
		getFileTotalCurrTypeStgs().remove(fileTotalCurrTypeStg);
		fileTotalCurrTypeStg.setSalesFileHeaderStg(null);

		return fileTotalCurrTypeStg;
	}

	public List<ReportingOfficeHdrStg> getReportingOfficeHdrStgs() {
		return this.reportingOfficeHdrStgs;
	}

	public void setReportingOfficeHdrStgs(List<ReportingOfficeHdrStg> reportingOfficeHdrStgs) {
		this.reportingOfficeHdrStgs = reportingOfficeHdrStgs;
	}

	public ReportingOfficeHdrStg addReportingOfficeHdrStg(ReportingOfficeHdrStg reportingOfficeHdrStg) {
		List<ReportingOfficeHdrStg> couponList3 = getReportingOfficeHdrStgs();
		if(couponList3 == null)  this.reportingOfficeHdrStgs = new ArrayList<ReportingOfficeHdrStg>();
		getReportingOfficeHdrStgs().add(reportingOfficeHdrStg);
		return reportingOfficeHdrStg;
	}
	

	public ReportingOfficeHdrStg removeReportingOfficeHdrStg(ReportingOfficeHdrStg reportingOfficeHdrStg) {
		getReportingOfficeHdrStgs().remove(reportingOfficeHdrStg);
		reportingOfficeHdrStg.setSalesFileHeaderStg(null);

		return reportingOfficeHdrStg;
	}

	public List<TransactionHdrStg> getTransactionHdrStgs() {
		return this.transactionHdrStgs;
	}

	public void setTransactionHdrStgs(List<TransactionHdrStg> transactionHdrStgs) {
		this.transactionHdrStgs = transactionHdrStgs;
	}

	public TransactionHdrStg addTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		List<TransactionHdrStg> couponList4 = getTransactionHdrStgs();
		if(couponList4 == null) 
		this.transactionHdrStgs = new ArrayList<TransactionHdrStg>();
		getTransactionHdrStgs().add(transactionHdrStg);
		return transactionHdrStg;
	}


	public TransactionHdrStg removeTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		getTransactionHdrStgs().remove(transactionHdrStg);
		transactionHdrStg.setSalesFileHeaderStg(null);

		return transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	/*
	 * @Override public LineTokenizer lineTokenizer() {
	 * 
	 * FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
	 * FileHeaderStgLayout fileHeaderStgLayout = new FileHeaderStgLayout();
	 * tokenizer.setColumns(fileHeaderStgLayout.getColumns());
	 * tokenizer.setNames(fileHeaderStgLayout.getNames()); return tokenizer;
	 * 
	 * }
	 */

	/*
	 * @Override public FieldSetMapper<BSPRecord> fieldSetMapper() {
	 * BeanWrapperFieldSetMapper<BSPRecord> fieldSetMapper = new
	 * BeanWrapperFieldSetMapper<BSPRecord>();
	 * fieldSetMapper.setTargetType(SalesFileHeaderStg.class); return
	 * fieldSetMapper; }
	 */

	
	public ItemProcessor<SalesFileHeaderStg, SalesFileHeaderStg> processor() {
		return new SalesValidatorProcessor();
	}

	/*
	 * @Override public ItemWriter<? super BSPRecord> writer() { return new
	 * FileHeaderStgWriter(); }
	 */

}