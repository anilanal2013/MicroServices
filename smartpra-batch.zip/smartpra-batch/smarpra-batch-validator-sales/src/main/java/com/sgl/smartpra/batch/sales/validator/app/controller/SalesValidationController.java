package com.sgl.smartpra.batch.sales.validator.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.sales.validator.app.service.SalesValidationService;

/**
 * 
 * @author mansound1
 *
 */

@RestController
public class SalesValidationController {

	@Autowired
	private SalesValidationService salesValidationService;

	@GetMapping("/init-sales-validation")
	public void initSalesValidations() {
		salesValidationService.initiateSalesValidation();
	}
}
