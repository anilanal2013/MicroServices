package com.sgl.smartpra.batch.sales.validator.app.domain;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the transaction_hdr_stg database table.
 * 
 */
@Entity
@Table(name="transaction_hdr_stg")
public class TransactionHdrStg extends BSPRecord  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="transaction_hdr_id")
	private int transactionHdrId;

	@Column(name="auto_repricing_eng_indicator")
	private String autoRepricingEngIndicator;

	@Column(name="comm_agreement_ref")
	private String commAgreementRef;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="customer_file_ref")
	private String customerFileRef;

	@Column(name="data_input_status_indicator")
	private String dataInputStatusIndicator;

	private String filler4;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="net_reporting_calculation_type")
	private String netReportingCalculationType;

	@Column(name="net_reporting_indicator")
	private String netReportingIndicator;

	@Column(name="net_reporting_method_indicator")
	private String netReportingMethodIndicator;

	@Column(name="reporting_system_identifier")
	private String reportingSystemIdentifier;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="settlement_auth_code")
	private String settlementAuthCode;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="tkt_airline_code_number")
	private String tktAirlineCodeNumber;

	@Column(name="trans_record_counter")
	private String transRecordCounter;

	@Column(name="transaction_number")
	private String transactionNumber;

	//bi-directional many-to-one association to AddlCardInformationStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<AddlCardInformationStg> addlCardInformationStgs;

	//bi-directional many-to-one association to AddlInfoFopStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<AddlInfoFopStg> addlInfoFopStgs;

	//bi-directional many-to-one association to AddlInfoPaxStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<AddlInfoPaxStg> addlInfoPaxStgs;

	//bi-directional many-to-one association to AddlTaxInformtionStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<AddlTaxInformtionStg> addlTaxInformtionStgs;

	//bi-directional many-to-one association to Card3dAuthInfoStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<Card3dAuthInfoStg> card3dAuthInfoStgs;

	//bi-directional many-to-one association to CardAuthInformationStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<CardAuthInformationStg> cardAuthInformationStgs;

	//bi-directional many-to-one association to CommissionRecordStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<CommissionRecordStg> commissionRecordStgs;

	//bi-directional many-to-one association to CpnTaxInformationStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<CpnTaxInformationStg> cpnTaxInformationStgs;

	//bi-directional many-to-one association to DocumentAmountStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<DocumentAmountStg> documentAmountStgs;

	//bi-directional many-to-one association to EmdCpnDetailStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<EmdCpnDetailStg> emdCpnDetailStgs;

	//bi-directional many-to-one association to EmdRemarksRecStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<EmdRemarksRecStg> emdRemarksRecStgs;

	//bi-directional many-to-one association to FareCalculationStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<FareCalculationStg> fareCalculationStgs;

	//bi-directional many-to-one association to FormOfPaymentRecStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<FormOfPaymentRecStg> formOfPaymentRecStgs;

	//bi-directional many-to-one association to ItineraryAddlDataStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<ItineraryAddlDataStg> itineraryAddlDataStgs;

	//bi-directional many-to-one association to ItineraryDataSegmentStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<ItineraryDataSegmentStg> itineraryDataSegmentStgs;

	//bi-directional many-to-one association to NettingValuesStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<NettingValuesStg> nettingValuesStgs;

	//bi-directional many-to-one association to OffSubtotTransCurrStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<OffSubtotTransCurrStg> offSubtotTransCurrStgs;

	//bi-directional many-to-one association to OffTotalCurrStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<OffTotalCurrStg> offTotalCurrStgs;

	//bi-directional many-to-one association to StandaredAmountStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<StandaredAmountStg> standaredAmountStgs;

	//bi-directional many-to-one association to TaxCommissionStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<TaxCommissionStg> taxCommissionStgs;

	//bi-directional many-to-one association to TicketIdentificationStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<TicketIdentificationStg> ticketIdentificationStgs;

	//bi-directional many-to-one association to TktDocumentInfoStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<TktDocumentInfoStg> tktDocumentInfoStgs;

	//bi-directional many-to-one association to SalesFileHeaderStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
	@JoinColumn(name="file_hdr_id")
	private SalesFileHeaderStg salesFileHeaderStg;

	//bi-directional many-to-one association to TransactionInfoStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<TransactionInfoStg> transactionInfoStgs;

	//bi-directional many-to-one association to UnticketedPointInfoStg
	@JsonIgnore
	@OneToMany(mappedBy="transactionHdrStg", cascade = CascadeType.MERGE)
	private List<UnticketedPointInfoStg> unticketedPointInfoStgs;

	public TransactionHdrStg() {
	}

	public int getTransactionHdrId() {
		return this.transactionHdrId;
	}

	public void setTransactionHdrId(int transactionHdrId) {
		this.transactionHdrId = transactionHdrId;
	}

	public String getAutoRepricingEngIndicator() {
		return this.autoRepricingEngIndicator;
	}

	public void setAutoRepricingEngIndicator(String autoRepricingEngIndicator) {
		this.autoRepricingEngIndicator = autoRepricingEngIndicator;
	}

	public String getCommAgreementRef() {
		return this.commAgreementRef;
	}

	public void setCommAgreementRef(String commAgreementRef) {
		this.commAgreementRef = commAgreementRef;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCustomerFileRef() {
		return this.customerFileRef;
	}

	public void setCustomerFileRef(String customerFileRef) {
		this.customerFileRef = customerFileRef;
	}

	public String getDataInputStatusIndicator() {
		return this.dataInputStatusIndicator;
	}

	public void setDataInputStatusIndicator(String dataInputStatusIndicator) {
		this.dataInputStatusIndicator = dataInputStatusIndicator;
	}

	public String getFiller4() {
		return this.filler4;
	}

	public void setFiller4(String filler4) {
		this.filler4 = filler4;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getNetReportingCalculationType() {
		return this.netReportingCalculationType;
	}

	public void setNetReportingCalculationType(String netReportingCalculationType) {
		this.netReportingCalculationType = netReportingCalculationType;
	}

	public String getNetReportingIndicator() {
		return this.netReportingIndicator;
	}

	public void setNetReportingIndicator(String netReportingIndicator) {
		this.netReportingIndicator = netReportingIndicator;
	}

	public String getNetReportingMethodIndicator() {
		return this.netReportingMethodIndicator;
	}

	public void setNetReportingMethodIndicator(String netReportingMethodIndicator) {
		this.netReportingMethodIndicator = netReportingMethodIndicator;
	}

	public String getReportingSystemIdentifier() {
		return this.reportingSystemIdentifier;
	}

	public void setReportingSystemIdentifier(String reportingSystemIdentifier) {
		this.reportingSystemIdentifier = reportingSystemIdentifier;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getSettlementAuthCode() {
		return this.settlementAuthCode;
	}

	public void setSettlementAuthCode(String settlementAuthCode) {
		this.settlementAuthCode = settlementAuthCode;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTktAirlineCodeNumber() {
		return this.tktAirlineCodeNumber;
	}

	public void setTktAirlineCodeNumber(String tktAirlineCodeNumber) {
		this.tktAirlineCodeNumber = tktAirlineCodeNumber;
	}

	public String getTransRecordCounter() {
		return this.transRecordCounter;
	}

	public void setTransRecordCounter(String transRecordCounter) {
		this.transRecordCounter = transRecordCounter;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public List<AddlCardInformationStg> getAddlCardInformationStgs() {
		return this.addlCardInformationStgs;
	}

	public void setAddlCardInformationStgs(List<AddlCardInformationStg> addlCardInformationStgs) {
		this.addlCardInformationStgs = addlCardInformationStgs;
	}

	public AddlCardInformationStg addAddlCardInformationStg(AddlCardInformationStg addlCardInformationStg) {
		List<AddlCardInformationStg> couponList2 = getAddlCardInformationStgs();
		if(couponList2 == null) this.addlCardInformationStgs = new ArrayList<AddlCardInformationStg>();
		getAddlCardInformationStgs().add(addlCardInformationStg);
		return addlCardInformationStg;
	}


	public AddlCardInformationStg removeAddlCardInformationStg(AddlCardInformationStg addlCardInformationStg) {
		getAddlCardInformationStgs().remove(addlCardInformationStg);
		addlCardInformationStg.setTransactionHdrStg(null);

		return addlCardInformationStg;
	}

	public List<AddlInfoFopStg> getAddlInfoFopStgs() {
		return this.addlInfoFopStgs;
	}

	public void setAddlInfoFopStgs(List<AddlInfoFopStg> addlInfoFopStgs) {
		this.addlInfoFopStgs = addlInfoFopStgs;
	}

	public AddlInfoFopStg addAddlInfoFopStg(AddlInfoFopStg addlInfoFopStg) {
		List<AddlInfoFopStg> couponList2 = getAddlInfoFopStgs();
		if(couponList2 == null) this.addlInfoFopStgs = new ArrayList<AddlInfoFopStg>();
		getAddlInfoFopStgs().add(addlInfoFopStg);
		return addlInfoFopStg;
	}
	

	public AddlInfoFopStg removeAddlInfoFopStg(AddlInfoFopStg addlInfoFopStg) {
		getAddlInfoFopStgs().remove(addlInfoFopStg);
		addlInfoFopStg.setTransactionHdrStg(null);

		return addlInfoFopStg;
	}

	public List<AddlInfoPaxStg> getAddlInfoPaxStgs() {
		return this.addlInfoPaxStgs;
	}

	public void setAddlInfoPaxStgs(List<AddlInfoPaxStg> addlInfoPaxStgs) {
		this.addlInfoPaxStgs = addlInfoPaxStgs;
	}

	public AddlInfoPaxStg addAddlInfoPaxStg(AddlInfoPaxStg addlInfoPaxStg) {
		List<AddlInfoPaxStg> couponList2 = getAddlInfoPaxStgs();
		if(couponList2 == null) this.addlInfoPaxStgs = new ArrayList<AddlInfoPaxStg>();
		getAddlInfoPaxStgs().add(addlInfoPaxStg);
		return addlInfoPaxStg;
	}

	public AddlInfoPaxStg removeAddlInfoPaxStg(AddlInfoPaxStg addlInfoPaxStg) {
		getAddlInfoPaxStgs().remove(addlInfoPaxStg);
		addlInfoPaxStg.setTransactionHdrStg(null);

		return addlInfoPaxStg;
	}

	public List<AddlTaxInformtionStg> getAddlTaxInformtionStgs() {
		return this.addlTaxInformtionStgs;
	}

	public void setAddlTaxInformtionStgs(List<AddlTaxInformtionStg> addlTaxInformtionStgs) {
		this.addlTaxInformtionStgs = addlTaxInformtionStgs;
	}

	public AddlTaxInformtionStg addAddlTaxInformtionStg(AddlTaxInformtionStg addlTaxInformtionStg) {
		List<AddlTaxInformtionStg> couponList2 = getAddlTaxInformtionStgs();
		if(couponList2 == null) this.addlTaxInformtionStgs = new ArrayList<AddlTaxInformtionStg>();
		getAddlTaxInformtionStgs().add(addlTaxInformtionStg);
    	return addlTaxInformtionStg;
	}

	public AddlTaxInformtionStg removeAddlTaxInformtionStg(AddlTaxInformtionStg addlTaxInformtionStg) {
		getAddlTaxInformtionStgs().remove(addlTaxInformtionStg);
		addlTaxInformtionStg.setTransactionHdrStg(null);

		return addlTaxInformtionStg;
	}

	public List<Card3dAuthInfoStg> getCard3dAuthInfoStgs() {
		return this.card3dAuthInfoStgs;
	}

	public void setCard3dAuthInfoStgs(List<Card3dAuthInfoStg> card3dAuthInfoStgs) {
		this.card3dAuthInfoStgs = card3dAuthInfoStgs;
	}

	public Card3dAuthInfoStg addCard3dAuthInfoStg(Card3dAuthInfoStg card3dAuthInfoStg) {
		List<Card3dAuthInfoStg> couponList2 = getCard3dAuthInfoStgs();
		if(couponList2 == null) this.card3dAuthInfoStgs = new ArrayList<Card3dAuthInfoStg>();
		getCard3dAuthInfoStgs().add(card3dAuthInfoStg);
		return card3dAuthInfoStg;
	}

	public Card3dAuthInfoStg removeCard3dAuthInfoStg(Card3dAuthInfoStg card3dAuthInfoStg) {
		getCard3dAuthInfoStgs().remove(card3dAuthInfoStg);
		card3dAuthInfoStg.setTransactionHdrStg(null);

		return card3dAuthInfoStg;
	}

	public List<CardAuthInformationStg> getCardAuthInformationStgs() {
		return this.cardAuthInformationStgs;
	}

	public void setCardAuthInformationStgs(List<CardAuthInformationStg> cardAuthInformationStgs) {
		this.cardAuthInformationStgs = cardAuthInformationStgs;
	}

	public CardAuthInformationStg addCardAuthInformationStg(CardAuthInformationStg cardAuthInformationStg) {
		List<CardAuthInformationStg> couponList2 = getCardAuthInformationStgs();
		if(couponList2 == null) this.cardAuthInformationStgs = new ArrayList<CardAuthInformationStg>();
		getCardAuthInformationStgs().add(cardAuthInformationStg);
		return cardAuthInformationStg;
	}

	public CardAuthInformationStg removeCardAuthInformationStg(CardAuthInformationStg cardAuthInformationStg) {
		getCardAuthInformationStgs().remove(cardAuthInformationStg);
		cardAuthInformationStg.setTransactionHdrStg(null);

		return cardAuthInformationStg;
	}

	public List<CommissionRecordStg> getCommissionRecordStgs() {
		return this.commissionRecordStgs;
	}

	public void setCommissionRecordStgs(List<CommissionRecordStg> commissionRecordStgs) {
		this.commissionRecordStgs = commissionRecordStgs;
	}

	public CommissionRecordStg addCommissionRecordStg(CommissionRecordStg commissionRecordStg) {
		List<CommissionRecordStg> couponList2 = getCommissionRecordStgs();
		if(couponList2 == null) this.commissionRecordStgs = new ArrayList<CommissionRecordStg>();
		getCommissionRecordStgs().add(commissionRecordStg);
		return commissionRecordStg;
	}

	public CommissionRecordStg removeCommissionRecordStg(CommissionRecordStg commissionRecordStg) {
		getCommissionRecordStgs().remove(commissionRecordStg);
		commissionRecordStg.setTransactionHdrStg(null);

		return commissionRecordStg;
	}

	public List<CpnTaxInformationStg> getCpnTaxInformationStgs() {
		return this.cpnTaxInformationStgs;
	}

	public void setCpnTaxInformationStgs(List<CpnTaxInformationStg> cpnTaxInformationStgs) {
		this.cpnTaxInformationStgs = cpnTaxInformationStgs;
	}

	public CpnTaxInformationStg addCpnTaxInformationStg(CpnTaxInformationStg cpnTaxInformationStg) {
		List<CpnTaxInformationStg> couponList2 = getCpnTaxInformationStgs();
		if(couponList2 == null) this.cpnTaxInformationStgs = new ArrayList<CpnTaxInformationStg>();
		getCpnTaxInformationStgs().add(cpnTaxInformationStg);
		return cpnTaxInformationStg;
	}

	public CpnTaxInformationStg removeCpnTaxInformationStg(CpnTaxInformationStg cpnTaxInformationStg) {
		getCpnTaxInformationStgs().remove(cpnTaxInformationStg);
		cpnTaxInformationStg.setTransactionHdrStg(null);

		return cpnTaxInformationStg;
	}

	public List<DocumentAmountStg> getDocumentAmountStgs() {
		return this.documentAmountStgs;
	}

	public void setDocumentAmountStgs(List<DocumentAmountStg> documentAmountStgs) {
		this.documentAmountStgs = documentAmountStgs;
	}

	public DocumentAmountStg addDocumentAmountStg(DocumentAmountStg documentAmountStg) {
		List<DocumentAmountStg> couponList2 = getDocumentAmountStgs();
		if(couponList2 == null) this.documentAmountStgs = new ArrayList<DocumentAmountStg>();
		getDocumentAmountStgs().add(documentAmountStg);
		return documentAmountStg;
	}

	public DocumentAmountStg removeDocumentAmountStg(DocumentAmountStg documentAmountStg) {
		getDocumentAmountStgs().remove(documentAmountStg);
		documentAmountStg.setTransactionHdrStg(null);

		return documentAmountStg;
	}

	public List<EmdCpnDetailStg> getEmdCpnDetailStgs() {
		return this.emdCpnDetailStgs;
	}

	public void setEmdCpnDetailStgs(List<EmdCpnDetailStg> emdCpnDetailStgs) {
		this.emdCpnDetailStgs = emdCpnDetailStgs;
	}

	public EmdCpnDetailStg addEmdCpnDetailStg(EmdCpnDetailStg emdCpnDetailStg) {
		List<EmdCpnDetailStg> couponList2 = getEmdCpnDetailStgs();
		if(couponList2 == null) this.emdCpnDetailStgs = new ArrayList<EmdCpnDetailStg>();
		getEmdCpnDetailStgs().add(emdCpnDetailStg);
		return emdCpnDetailStg;
	}

	public EmdCpnDetailStg removeEmdCpnDetailStg(EmdCpnDetailStg emdCpnDetailStg) {
		getEmdCpnDetailStgs().remove(emdCpnDetailStg);
		emdCpnDetailStg.setTransactionHdrStg(null);

		return emdCpnDetailStg;
	}

	public List<EmdRemarksRecStg> getEmdRemarksRecStgs() {
		return this.emdRemarksRecStgs;
	}

	public void setEmdRemarksRecStgs(List<EmdRemarksRecStg> emdRemarksRecStgs) {
		this.emdRemarksRecStgs = emdRemarksRecStgs;
	}

	public EmdRemarksRecStg addEmdRemarksRecStg(EmdRemarksRecStg emdRemarksRecStg) {
		List<EmdRemarksRecStg> couponList2 = getEmdRemarksRecStgs();
		if(couponList2 == null) this.emdRemarksRecStgs = new ArrayList<EmdRemarksRecStg>();
		getEmdRemarksRecStgs().add(emdRemarksRecStg);
		return emdRemarksRecStg;
	}

	public EmdRemarksRecStg removeEmdRemarksRecStg(EmdRemarksRecStg emdRemarksRecStg) {
		getEmdRemarksRecStgs().remove(emdRemarksRecStg);
		emdRemarksRecStg.setTransactionHdrStg(null);

		return emdRemarksRecStg;
	}

	public List<FareCalculationStg> getFareCalculationStgs() {
		return this.fareCalculationStgs;
	}

	public void setFareCalculationStgs(List<FareCalculationStg> fareCalculationStgs) {
		this.fareCalculationStgs = fareCalculationStgs;
	}

	public FareCalculationStg addFareCalculationStg(FareCalculationStg fareCalculationStg) {
		List<FareCalculationStg> couponList2 = getFareCalculationStgs();
		if(couponList2 == null) this.fareCalculationStgs = new ArrayList<FareCalculationStg>();
		getFareCalculationStgs().add(fareCalculationStg);
		return fareCalculationStg;
	}

	public FareCalculationStg removeFareCalculationStg(FareCalculationStg fareCalculationStg) {
		getFareCalculationStgs().remove(fareCalculationStg);
		fareCalculationStg.setTransactionHdrStg(null);

		return fareCalculationStg;
	}

	public List<FormOfPaymentRecStg> getFormOfPaymentRecStgs() {
		return this.formOfPaymentRecStgs;
	}

	public void setFormOfPaymentRecStgs(List<FormOfPaymentRecStg> formOfPaymentRecStgs) {
		this.formOfPaymentRecStgs = formOfPaymentRecStgs;
	}

	public FormOfPaymentRecStg addFormOfPaymentRecStg(FormOfPaymentRecStg formOfPaymentRecStg) {
		List<FormOfPaymentRecStg> couponList2 = getFormOfPaymentRecStgs();
		if(couponList2 == null) this.formOfPaymentRecStgs = new ArrayList<FormOfPaymentRecStg>();
		getFormOfPaymentRecStgs().add(formOfPaymentRecStg);
		return formOfPaymentRecStg;
	}

	public FormOfPaymentRecStg removeFormOfPaymentRecStg(FormOfPaymentRecStg formOfPaymentRecStg) {
		getFormOfPaymentRecStgs().remove(formOfPaymentRecStg);
		formOfPaymentRecStg.setTransactionHdrStg(null);

		return formOfPaymentRecStg;
	}

	public List<ItineraryAddlDataStg> getItineraryAddlDataStgs() {
		return this.itineraryAddlDataStgs;
	}

	public void setItineraryAddlDataStgs(List<ItineraryAddlDataStg> itineraryAddlDataStgs) {
		this.itineraryAddlDataStgs = itineraryAddlDataStgs;
	}

	public ItineraryAddlDataStg addItineraryAddlDataStg(ItineraryAddlDataStg itineraryAddlDataStg) {
		List<ItineraryAddlDataStg> couponList2 = getItineraryAddlDataStgs();
		if(couponList2 == null) this.itineraryAddlDataStgs = new ArrayList<ItineraryAddlDataStg>();
		getItineraryAddlDataStgs().add(itineraryAddlDataStg);
		return itineraryAddlDataStg;
	}

	public ItineraryAddlDataStg removeItineraryAddlDataStg(ItineraryAddlDataStg itineraryAddlDataStg) {
		getItineraryAddlDataStgs().remove(itineraryAddlDataStg);
		itineraryAddlDataStg.setTransactionHdrStg(null);

		return itineraryAddlDataStg;
	}

	public List<ItineraryDataSegmentStg> getItineraryDataSegmentStgs() {
		return this.itineraryDataSegmentStgs;
	}

	public void setItineraryDataSegmentStgs(List<ItineraryDataSegmentStg> itineraryDataSegmentStgs) {
		this.itineraryDataSegmentStgs = itineraryDataSegmentStgs;
	}

	public ItineraryDataSegmentStg addItineraryDataSegmentStg(ItineraryDataSegmentStg itineraryDataSegmentStg) {
		List<ItineraryDataSegmentStg> couponList2 = getItineraryDataSegmentStgs();
		if(couponList2 == null) this.itineraryDataSegmentStgs = new ArrayList<ItineraryDataSegmentStg>();
		getItineraryDataSegmentStgs().add(itineraryDataSegmentStg);
		return itineraryDataSegmentStg;
	}

	public ItineraryDataSegmentStg removeItineraryDataSegmentStg(ItineraryDataSegmentStg itineraryDataSegmentStg) {
		getItineraryDataSegmentStgs().remove(itineraryDataSegmentStg);
		itineraryDataSegmentStg.setTransactionHdrStg(null);

		return itineraryDataSegmentStg;
	}

	public List<NettingValuesStg> getNettingValuesStgs() {
		return this.nettingValuesStgs;
	}

	public void setNettingValuesStgs(List<NettingValuesStg> nettingValuesStgs) {
		this.nettingValuesStgs = nettingValuesStgs;
	}

	public NettingValuesStg addNettingValuesStg(NettingValuesStg nettingValuesStg) {
		List<NettingValuesStg> couponList2 = getNettingValuesStgs();
		if(couponList2 == null) this.nettingValuesStgs = new ArrayList<NettingValuesStg>();
		getNettingValuesStgs().add(nettingValuesStg);
		return nettingValuesStg;
	}

	public NettingValuesStg removeNettingValuesStg(NettingValuesStg nettingValuesStg) {
		getNettingValuesStgs().remove(nettingValuesStg);
		nettingValuesStg.setTransactionHdrStg(null);

		return nettingValuesStg;
	}

	public List<OffSubtotTransCurrStg> getOffSubtotTransCurrStgs() {
		return this.offSubtotTransCurrStgs;
	}

	public void setOffSubtotTransCurrStgs(List<OffSubtotTransCurrStg> offSubtotTransCurrStgs) {
		this.offSubtotTransCurrStgs = offSubtotTransCurrStgs;
	}

	public OffSubtotTransCurrStg addOffSubtotTransCurrStg(OffSubtotTransCurrStg offSubtotTransCurrStg) {
		List<OffSubtotTransCurrStg> couponList2 = getOffSubtotTransCurrStgs();
		if(couponList2 == null) this.offSubtotTransCurrStgs = new ArrayList<OffSubtotTransCurrStg>();
		getOffSubtotTransCurrStgs().add(offSubtotTransCurrStg);
		return offSubtotTransCurrStg;
	}

	public OffSubtotTransCurrStg removeOffSubtotTransCurrStg(OffSubtotTransCurrStg offSubtotTransCurrStg) {
		getOffSubtotTransCurrStgs().remove(offSubtotTransCurrStg);
		offSubtotTransCurrStg.setTransactionHdrStg(null);

		return offSubtotTransCurrStg;
	}

	public List<OffTotalCurrStg> getOffTotalCurrStgs() {
		return this.offTotalCurrStgs;
	}

	public void setOffTotalCurrStgs(List<OffTotalCurrStg> offTotalCurrStgs) {
		this.offTotalCurrStgs = offTotalCurrStgs;
	}

	public OffTotalCurrStg addOffTotalCurrStg(OffTotalCurrStg offTotalCurrStg) {
		List<OffTotalCurrStg> couponList2 = getOffTotalCurrStgs();
		if(couponList2 == null) this.offTotalCurrStgs = new ArrayList<OffTotalCurrStg>();
		getOffTotalCurrStgs().add(offTotalCurrStg);
		return offTotalCurrStg;
	}

	public OffTotalCurrStg removeOffTotalCurrStg(OffTotalCurrStg offTotalCurrStg) {
		getOffTotalCurrStgs().remove(offTotalCurrStg);
		offTotalCurrStg.setTransactionHdrStg(null);

		return offTotalCurrStg;
	}

	public List<StandaredAmountStg> getStandaredAmountStgs() {
		return this.standaredAmountStgs;
	}

	public void setStandaredAmountStgs(List<StandaredAmountStg> standaredAmountStgs) {
		this.standaredAmountStgs = standaredAmountStgs;
	}

	public StandaredAmountStg addStandaredAmountStg(StandaredAmountStg standaredAmountStg) {
		List<StandaredAmountStg> couponList2 = getStandaredAmountStgs();
		if(couponList2 == null) this.standaredAmountStgs = new ArrayList<StandaredAmountStg>();
		getStandaredAmountStgs().add(standaredAmountStg);
      	return standaredAmountStg;
	}

	public StandaredAmountStg removeStandaredAmountStg(StandaredAmountStg standaredAmountStg) {
		getStandaredAmountStgs().remove(standaredAmountStg);
		standaredAmountStg.setTransactionHdrStg(null);

		return standaredAmountStg;
	}

	public List<TaxCommissionStg> getTaxCommissionStgs() {
		return this.taxCommissionStgs;
	}

	public void setTaxCommissionStgs(List<TaxCommissionStg> taxCommissionStgs) {
		this.taxCommissionStgs = taxCommissionStgs;
	}

	public TaxCommissionStg addTaxCommissionStg(TaxCommissionStg taxCommissionStg) {
		List<TaxCommissionStg> couponList2 = getTaxCommissionStgs();
		if(couponList2 == null) this.taxCommissionStgs = new ArrayList<TaxCommissionStg>();
		getTaxCommissionStgs().add(taxCommissionStg);
		return taxCommissionStg;
	}

	public TaxCommissionStg removeTaxCommissionStg(TaxCommissionStg taxCommissionStg) {
		getTaxCommissionStgs().remove(taxCommissionStg);
		taxCommissionStg.setTransactionHdrStg(null);

		return taxCommissionStg;
	}

	public List<TicketIdentificationStg> getTicketIdentificationStgs() {
		return this.ticketIdentificationStgs;
	}

	public void setTicketIdentificationStgs(List<TicketIdentificationStg> ticketIdentificationStgs) {
		this.ticketIdentificationStgs = ticketIdentificationStgs;
	}

	public TicketIdentificationStg addTicketIdentificationStg(TicketIdentificationStg ticketIdentificationStg) {
		List<TicketIdentificationStg> couponList2 = getTicketIdentificationStgs();
		if(couponList2 == null) this.ticketIdentificationStgs = new ArrayList<TicketIdentificationStg>();
		getTicketIdentificationStgs().add(ticketIdentificationStg);
		return ticketIdentificationStg;
	}

	public TicketIdentificationStg removeTicketIdentificationStg(TicketIdentificationStg ticketIdentificationStg) {
		getTicketIdentificationStgs().remove(ticketIdentificationStg);
		ticketIdentificationStg.setTransactionHdrStg(null);

		return ticketIdentificationStg;
	}

	public List<TktDocumentInfoStg> getTktDocumentInfoStgs() {
		return this.tktDocumentInfoStgs;
	}

	public void setTktDocumentInfoStgs(List<TktDocumentInfoStg> tktDocumentInfoStgs) {
		this.tktDocumentInfoStgs = tktDocumentInfoStgs;
	}

	public TktDocumentInfoStg addTktDocumentInfoStg(TktDocumentInfoStg tktDocumentInfoStg) {
		List<TktDocumentInfoStg> couponList2 = getTktDocumentInfoStgs();
		if(couponList2 == null) this.tktDocumentInfoStgs = new ArrayList<TktDocumentInfoStg>();
		getTktDocumentInfoStgs().add(tktDocumentInfoStg);
		return tktDocumentInfoStg;
	}

	public TktDocumentInfoStg removeTktDocumentInfoStg(TktDocumentInfoStg tktDocumentInfoStg) {
		getTktDocumentInfoStgs().remove(tktDocumentInfoStg);
		tktDocumentInfoStg.setTransactionHdrStg(null);

		return tktDocumentInfoStg;
	}

	public SalesFileHeaderStg getSalesFileHeaderStg() {
		return this.salesFileHeaderStg;
	}

	public void setSalesFileHeaderStg(SalesFileHeaderStg salesFileHeaderStg) {
		this.salesFileHeaderStg = salesFileHeaderStg;
	}

	public List<TransactionInfoStg> getTransactionInfoStgs() {
		return this.transactionInfoStgs;
	}

	public void setTransactionInfoStgs(List<TransactionInfoStg> transactionInfoStgs) {
		this.transactionInfoStgs = transactionInfoStgs;
	}

	public TransactionInfoStg addTransactionInfoStg(TransactionInfoStg transactionInfoStg) {
		List<TransactionInfoStg> couponList2 = getTransactionInfoStgs();
		if(couponList2 == null) this.transactionInfoStgs = new ArrayList<TransactionInfoStg>();
		getTransactionInfoStgs().add(transactionInfoStg);
		return transactionInfoStg;
	}

	public TransactionInfoStg removeTransactionInfoStg(TransactionInfoStg transactionInfoStg) {
		getTransactionInfoStgs().remove(transactionInfoStg);
		transactionInfoStg.setTransactionHdrStg(null);

		return transactionInfoStg;
	}

	public List<UnticketedPointInfoStg> getUnticketedPointInfoStgs() {
		return this.unticketedPointInfoStgs;
	}

	public void setUnticketedPointInfoStgs(List<UnticketedPointInfoStg> unticketedPointInfoStgs) {
		this.unticketedPointInfoStgs = unticketedPointInfoStgs;
	}

	public UnticketedPointInfoStg addUnticketedPointInfoStg(UnticketedPointInfoStg unticketedPointInfoStg) {
		List<UnticketedPointInfoStg> couponList2 = getUnticketedPointInfoStgs();
		if(couponList2 == null) this.unticketedPointInfoStgs = new ArrayList<UnticketedPointInfoStg>();
		getUnticketedPointInfoStgs().add(unticketedPointInfoStg);
		return unticketedPointInfoStg;
	}

	public UnticketedPointInfoStg removeUnticketedPointInfoStg(UnticketedPointInfoStg unticketedPointInfoStg) {
		getUnticketedPointInfoStgs().remove(unticketedPointInfoStg);
		unticketedPointInfoStg.setTransactionHdrStg(null);

		return unticketedPointInfoStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	



}