package com.sgl.smartpra.batch.sales.validator.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.sales.validator.app.domain.Card3dAuthInfoStg;

@Repository
public interface Card3DAuthenticationInformationStgRepository  extends JpaRepository<Card3dAuthInfoStg, Integer>{

}