package com.sgl.smartpra.batch.sales.validator.app.master;

import java.util.List;


import com.sgl.smartpra.global.master.model.Currency;

public interface CurrencyMasterClient {

	public List<Currency> getAllcurrencies(String currencyCode, String currencyName);

}