package com.sgl.smartpra.batch.sales.validator.app.domain;


import java.io.Serializable;
import javax.persistence.*;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.fasterxml.jackson.annotation.JsonIgnore;
/*import com.sgl.smartpra.batch.bsp.app.processor.TicketCommissionStgProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.TicketCouponFnfProcessor;*/
/*import com.sgl.smartpra.batch.bsp.app.writer.TicketCommisionstgWriter;
import com.sgl.smartpra.batch.bsp.app.writer.TicketCouponFnfWriter;
*/
import java.sql.Timestamp;


/**
 * The persistent class for the ticket_coupon_fnf database table.
 * 
 */
@Entity
@Table(name="ticket_coupon_fnf")
public class TicketCouponFnf  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="tkt_fnf_dtl_id")
	private int tktFnfDtlId;

	@Column(name="coupon_number")
	private int couponNumber;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="flat_amount")
	private String flatAmount;

	@Column(name="flat_amount_currency")
	private String flatAmountCurrency;

	@Column(name="fnf_agreement_indicator")
	private String fnfAgreementIndicator;

	@Column(name="fnf_curr_adjustment_indicator")
	private String fnfCurrAdjustmentIndicator;

	@Column(name="fnf_currency")
	private String fnfCurrency;

	@Column(name="fnf_handling_fee_amt")
	private String fnfHandlingFeeAmt;

	@Column(name="fnf_handling_fee_base_cur")
	private String fnfHandlingFeeBaseCur;

	@Column(name="fnf_handling_fee_currency")
	private String fnfHandlingFeeCurrency;

	@Column(name="fnf_handling_fee_perc")
	private String fnfHandlingFeePerc;

	@Column(name="fnf_indicator")
	private String fnfIndicator;

	@Column(name="fnf_isc_amount")
	private String fnfIscAmount;

	@Column(name="fnf_isc_currency")
	private String fnfIscCurrency;

	@Column(name="fnf_isc_percentage")
	private String fnfIscPercentage;

	@Column(name="fnf_nfp_reason_code")
	private String fnfNfpReasonCode;

	@Column(name="fnf_pmi")
	private String fnfPmi;

	@Column(name="fnf_proration_date")
	private String fnfProrationDate;

	@Column(name="fnf_proration_type")
	private String fnfProrationType;

	@Column(name="fnf_record50_error")
	private String fnfRecord50Error;

	@Column(name="fnf_sector_value")
	private String fnfSectorValue;

	@Column(name="fnf_tax_amount")
	private String fnfTaxAmount;

	@Column(name="fnf_uatp_discount_typ")
	private String fnfUatpDiscountTyp;

	@Column(name="fnf_uatp_percent")
	private String fnfUatpPercent;

	@Column(name="io_type")
	private String ioType;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="sector_number")
	private int sectorNumber;

	//bi-directional many-to-one association to TicketCouponStg
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="trn_tkt_cpn_id")
	private TicketCouponStg ticketCouponStg;

	public TicketCouponFnf() {
	}

	public int getTktFnfDtlId() {
		return this.tktFnfDtlId;
	}

	public void setTktFnfDtlId(int tktFnfDtlId) {
		this.tktFnfDtlId = tktFnfDtlId;
	}

	public int getCouponNumber() {
		return this.couponNumber;
	}

	public void setCouponNumber(int couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getFlatAmount() {
		return this.flatAmount;
	}

	public void setFlatAmount(String flatAmount) {
		this.flatAmount = flatAmount;
	}

	public String getFlatAmountCurrency() {
		return this.flatAmountCurrency;
	}

	public void setFlatAmountCurrency(String flatAmountCurrency) {
		this.flatAmountCurrency = flatAmountCurrency;
	}

	public String getFnfAgreementIndicator() {
		return this.fnfAgreementIndicator;
	}

	public void setFnfAgreementIndicator(String fnfAgreementIndicator) {
		this.fnfAgreementIndicator = fnfAgreementIndicator;
	}

	public String getFnfCurrAdjustmentIndicator() {
		return this.fnfCurrAdjustmentIndicator;
	}

	public void setFnfCurrAdjustmentIndicator(String fnfCurrAdjustmentIndicator) {
		this.fnfCurrAdjustmentIndicator = fnfCurrAdjustmentIndicator;
	}

	public String getFnfCurrency() {
		return this.fnfCurrency;
	}

	public void setFnfCurrency(String fnfCurrency) {
		this.fnfCurrency = fnfCurrency;
	}

	public String getFnfHandlingFeeAmt() {
		return this.fnfHandlingFeeAmt;
	}

	public void setFnfHandlingFeeAmt(String fnfHandlingFeeAmt) {
		this.fnfHandlingFeeAmt = fnfHandlingFeeAmt;
	}

	public String getFnfHandlingFeeBaseCur() {
		return this.fnfHandlingFeeBaseCur;
	}

	public void setFnfHandlingFeeBaseCur(String fnfHandlingFeeBaseCur) {
		this.fnfHandlingFeeBaseCur = fnfHandlingFeeBaseCur;
	}

	public String getFnfHandlingFeeCurrency() {
		return this.fnfHandlingFeeCurrency;
	}

	public void setFnfHandlingFeeCurrency(String fnfHandlingFeeCurrency) {
		this.fnfHandlingFeeCurrency = fnfHandlingFeeCurrency;
	}

	public String getFnfHandlingFeePerc() {
		return this.fnfHandlingFeePerc;
	}

	public void setFnfHandlingFeePerc(String fnfHandlingFeePerc) {
		this.fnfHandlingFeePerc = fnfHandlingFeePerc;
	}

	public String getFnfIndicator() {
		return this.fnfIndicator;
	}

	public void setFnfIndicator(String fnfIndicator) {
		this.fnfIndicator = fnfIndicator;
	}

	public String getFnfIscAmount() {
		return this.fnfIscAmount;
	}

	public void setFnfIscAmount(String fnfIscAmount) {
		this.fnfIscAmount = fnfIscAmount;
	}

	public String getFnfIscCurrency() {
		return this.fnfIscCurrency;
	}

	public void setFnfIscCurrency(String fnfIscCurrency) {
		this.fnfIscCurrency = fnfIscCurrency;
	}

	public String getFnfIscPercentage() {
		return this.fnfIscPercentage;
	}

	public void setFnfIscPercentage(String fnfIscPercentage) {
		this.fnfIscPercentage = fnfIscPercentage;
	}

	public String getFnfNfpReasonCode() {
		return this.fnfNfpReasonCode;
	}

	public void setFnfNfpReasonCode(String fnfNfpReasonCode) {
		this.fnfNfpReasonCode = fnfNfpReasonCode;
	}

	public String getFnfPmi() {
		return this.fnfPmi;
	}

	public void setFnfPmi(String fnfPmi) {
		this.fnfPmi = fnfPmi;
	}

	public String getFnfProrationDate() {
		return this.fnfProrationDate;
	}

	public void setFnfProrationDate(String fnfProrationDate) {
		this.fnfProrationDate = fnfProrationDate;
	}

	public String getFnfProrationType() {
		return this.fnfProrationType;
	}

	public void setFnfProrationType(String fnfProrationType) {
		this.fnfProrationType = fnfProrationType;
	}

	public String getFnfRecord50Error() {
		return this.fnfRecord50Error;
	}

	public void setFnfRecord50Error(String fnfRecord50Error) {
		this.fnfRecord50Error = fnfRecord50Error;
	}

	public String getFnfSectorValue() {
		return this.fnfSectorValue;
	}

	public void setFnfSectorValue(String fnfSectorValue) {
		this.fnfSectorValue = fnfSectorValue;
	}

	public String getFnfTaxAmount() {
		return this.fnfTaxAmount;
	}

	public void setFnfTaxAmount(String fnfTaxAmount) {
		this.fnfTaxAmount = fnfTaxAmount;
	}

	public String getFnfUatpDiscountTyp() {
		return this.fnfUatpDiscountTyp;
	}

	public void setFnfUatpDiscountTyp(String fnfUatpDiscountTyp) {
		this.fnfUatpDiscountTyp = fnfUatpDiscountTyp;
	}

	public String getFnfUatpPercent() {
		return this.fnfUatpPercent;
	}

	public void setFnfUatpPercent(String fnfUatpPercent) {
		this.fnfUatpPercent = fnfUatpPercent;
	}

	public String getIoType() {
		return this.ioType;
	}

	public void setIoType(String ioType) {
		this.ioType = ioType;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public int getSectorNumber() {
		return this.sectorNumber;
	}

	public void setSectorNumber(int sectorNumber) {
		this.sectorNumber = sectorNumber;
	}

	public TicketCouponStg getTicketCouponStg() {
		return this.ticketCouponStg;
	}

	public void setTicketCouponStg(TicketCouponStg ticketCouponStg) {
		this.ticketCouponStg = ticketCouponStg;
	}
}