package com.sgl.smartpra.batch.sales.validator.app.domain;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the tax_commission_stg database table.
 * 
 */
@Entity
@Table(name="tax_commission_stg")
public class TaxCommissionStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="tax_commission_auto_id")
	private int taxCommissionAutoId;

	@Column(name="check_digit")
	private String checkDigit;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="currency_type")
	private String currencyType;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	private String filler;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="tax_on_commission_amount_1")
	private String taxOnCommissionAmount1;

	@Column(name="tax_on_commission_amount_2")
	private String taxOnCommissionAmount2;

	@Column(name="tax_on_commission_amount_3")
	private String taxOnCommissionAmount3;

	@Column(name="tax_on_commission_amount_4")
	private String taxOnCommissionAmount4;

	@Column(name="tax_on_commission_type_1")
	private String taxOnCommissionType1;

	@Column(name="tax_on_commission_type_2")
	private String taxOnCommissionType2;

	@Column(name="tax_on_commission_type_3")
	private String taxOnCommissionType3;

	@Column(name="tax_on_commission_type_4")
	private String taxOnCommissionType4;

	@Column(name="tkt_doc_number")
	private String tktDocNumber;

	@Column(name="transaction_number")
	private String transactionNumber;

	//bi-directional many-to-one association to TransactionHdrStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="transaction_hdr_id")
	private TransactionHdrStg transactionHdrStg;

	public TaxCommissionStg() {
	}

	public int getTaxCommissionAutoId() {
		return this.taxCommissionAutoId;
	}

	public void setTaxCommissionAutoId(int taxCommissionAutoId) {
		this.taxCommissionAutoId = taxCommissionAutoId;
	}

	public String getCheckDigit() {
		return this.checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrencyType() {
		return this.currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getFiller() {
		return this.filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTaxOnCommissionAmount1() {
		return this.taxOnCommissionAmount1;
	}

	public void setTaxOnCommissionAmount1(String taxOnCommissionAmount1) {
		this.taxOnCommissionAmount1 = taxOnCommissionAmount1;
	}

	public String getTaxOnCommissionAmount2() {
		return this.taxOnCommissionAmount2;
	}

	public void setTaxOnCommissionAmount2(String taxOnCommissionAmount2) {
		this.taxOnCommissionAmount2 = taxOnCommissionAmount2;
	}

	public String getTaxOnCommissionAmount3() {
		return this.taxOnCommissionAmount3;
	}

	public void setTaxOnCommissionAmount3(String taxOnCommissionAmount3) {
		this.taxOnCommissionAmount3 = taxOnCommissionAmount3;
	}

	public String getTaxOnCommissionAmount4() {
		return this.taxOnCommissionAmount4;
	}

	public void setTaxOnCommissionAmount4(String taxOnCommissionAmount4) {
		this.taxOnCommissionAmount4 = taxOnCommissionAmount4;
	}

	public String getTaxOnCommissionType1() {
		return this.taxOnCommissionType1;
	}

	public void setTaxOnCommissionType1(String taxOnCommissionType1) {
		this.taxOnCommissionType1 = taxOnCommissionType1;
	}

	public String getTaxOnCommissionType2() {
		return this.taxOnCommissionType2;
	}

	public void setTaxOnCommissionType2(String taxOnCommissionType2) {
		this.taxOnCommissionType2 = taxOnCommissionType2;
	}

	public String getTaxOnCommissionType3() {
		return this.taxOnCommissionType3;
	}

	public void setTaxOnCommissionType3(String taxOnCommissionType3) {
		this.taxOnCommissionType3 = taxOnCommissionType3;
	}

	public String getTaxOnCommissionType4() {
		return this.taxOnCommissionType4;
	}

	public void setTaxOnCommissionType4(String taxOnCommissionType4) {
		this.taxOnCommissionType4 = taxOnCommissionType4;
	}

	public String getTktDocNumber() {
		return this.tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public TransactionHdrStg getTransactionHdrStg() {
		return this.transactionHdrStg;
	}

	public void setTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		this.transactionHdrStg = transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	


}