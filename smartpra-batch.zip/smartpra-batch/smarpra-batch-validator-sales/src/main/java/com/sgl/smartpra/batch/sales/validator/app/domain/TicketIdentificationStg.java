package com.sgl.smartpra.batch.sales.validator.app.domain;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.fasterxml.jackson.annotation.JsonIgnore;



/**
 * The persistent class for the ticket_identification_stg database table.
 * 
 */
@Entity
@Table(name="ticket_identification_stg")
public class TicketIdentificationStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="tkt_identification_auto_id")
	private int tktIdentificationAutoId;

	@Column(name="agent_numeric_code")
	private String agentNumericCode;

	@Column(name="check_digit")
	private String checkDigit;

	@Column(name="conjuction_ticket_indicator")
	private String conjuctionTicketIndicator;

	@Column(name="cpn_use_indicator")
	private String cpnUseIndicator;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	private String filler5;

	@Column(name="jrny_turnaround_apt_city_code")
	private String jrnyTurnaroundAptCityCode;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="pnr_ref__airline_date")
	private String pnrRefAirlineDate;

	@Column(name="reason_for_reissuance_code")
	private String reasonForReissuanceCode;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="time_of_issue")
	private String timeOfIssue;

	@Column(name="tkt_doc_number")
	private String tktDocNumber;

	@Column(name="tour_code")
	private String tourCode;

	@Column(name="transaction_code")
	private String transactionCode;

	@Column(name="transaction_number")
	private String transactionNumber;

	@Column(name="true_org_dest_city_code")
	private String trueOrgDestCityCode;

	//bi-directional many-to-one association to TransactionHdrStg
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="transaction_hdr_id")
	private TransactionHdrStg transactionHdrStg;

	public TicketIdentificationStg() {
	}

	public int getTktIdentificationAutoId() {
		return this.tktIdentificationAutoId;
	}

	public void setTktIdentificationAutoId(int tktIdentificationAutoId) {
		this.tktIdentificationAutoId = tktIdentificationAutoId;
	}

	public String getAgentNumericCode() {
		return this.agentNumericCode;
	}

	public void setAgentNumericCode(String agentNumericCode) {
		this.agentNumericCode = agentNumericCode;
	}

	public String getCheckDigit() {
		return this.checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getConjuctionTicketIndicator() {
		return this.conjuctionTicketIndicator;
	}

	public void setConjuctionTicketIndicator(String conjuctionTicketIndicator) {
		this.conjuctionTicketIndicator = conjuctionTicketIndicator;
	}

	public String getCpnUseIndicator() {
		return this.cpnUseIndicator;
	}

	public void setCpnUseIndicator(String cpnUseIndicator) {
		this.cpnUseIndicator = cpnUseIndicator;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getFiller5() {
		return this.filler5;
	}

	public void setFiller5(String filler5) {
		this.filler5 = filler5;
	}

	public String getJrnyTurnaroundAptCityCode() {
		return this.jrnyTurnaroundAptCityCode;
	}

	public void setJrnyTurnaroundAptCityCode(String jrnyTurnaroundAptCityCode) {
		this.jrnyTurnaroundAptCityCode = jrnyTurnaroundAptCityCode;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getPnrRefAirlineDate() {
		return this.pnrRefAirlineDate;
	}

	public void setPnrRefAirlineDate(String pnrRefAirlineDate) {
		this.pnrRefAirlineDate = pnrRefAirlineDate;
	}

	public String getReasonForReissuanceCode() {
		return this.reasonForReissuanceCode;
	}

	public void setReasonForReissuanceCode(String reasonForReissuanceCode) {
		this.reasonForReissuanceCode = reasonForReissuanceCode;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTimeOfIssue() {
		return this.timeOfIssue;
	}

	public void setTimeOfIssue(String timeOfIssue) {
		this.timeOfIssue = timeOfIssue;
	}

	public String getTktDocNumber() {
		return this.tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getTourCode() {
		return this.tourCode;
	}

	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}

	public String getTransactionCode() {
		return this.transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTrueOrgDestCityCode() {
		return this.trueOrgDestCityCode;
	}

	public void setTrueOrgDestCityCode(String trueOrgDestCityCode) {
		this.trueOrgDestCityCode = trueOrgDestCityCode;
	}

	public TransactionHdrStg getTransactionHdrStg() {
		return this.transactionHdrStg;
	}

	public void setTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		this.transactionHdrStg = transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	




}