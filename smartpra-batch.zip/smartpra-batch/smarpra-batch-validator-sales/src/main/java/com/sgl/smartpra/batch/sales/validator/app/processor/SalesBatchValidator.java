package com.sgl.smartpra.batch.sales.validator.app.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.sgl.smartpra.batch.sales.validator.app.exception.SalesValidationException;




//@Component
//@StepScope
public class SalesBatchValidator implements Validator{

	@Autowired
	SalesRules salesRules;
	
	
	@Override
	public boolean supports(Class<?> arg0) {
		return true;
	}

	@Override
	public void validate(Object arg0, Errors arg1) throws SalesValidationException{
		
	}

}