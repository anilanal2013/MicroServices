package com.sgl.smartpra.batch.sales.validator.app.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;


import com.sgl.smartpra.batch.sales.validator.app.domain.SalesFileHeaderStg;
import com.sgl.smartpra.batch.sales.validator.app.listener.SalesValidationNotificationListener;
import com.sgl.smartpra.batch.sales.validator.app.processor.SalesValidatorProcessor;
import com.sgl.smartpra.batch.sales.validator.app.repository.SalesFileHeaderStgRepository;

/**
 * 
 * @author prat
 *
 */
@Configuration
@EnableBatchProcessing
public class SalesValidationConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	private SalesFileHeaderStgRepository salesFileHeaderStgRepository;

	@Autowired
	SalesValidatorProcessor salesValidatorProcessor;
	
	@Autowired
	SalesValidationNotificationListener salesValidationNotificationListener;

	@Autowired
	EntityManagerFactory entityManagerFactory;

	@Value("${max-threads}")
	private int maxThreads;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setConcurrencyLimit(maxThreads);
		return taskExecutor;
	}

	@Bean
	@StepScope
	@Transactional
	public ItemReader<SalesFileHeaderStg> getSalesFileHeaderReader() {
		RepositoryItemReader<SalesFileHeaderStg> itemReader = new RepositoryItemReader<>();
		//List<String> arguments = new java.util.ArrayList<>();
		Map<String, Direction> sortOrder = new HashMap<>();
		sortOrder.put("prodStatus", Direction.ASC);
		itemReader.setRepository(salesFileHeaderStgRepository);
		itemReader.setMethodName("findAllByProdStatus");
		//itemReader.setMethodName("findAll");
		//itemReader.setArguments(arguments);
		itemReader.setSort(sortOrder);
		return itemReader;
	}

	@Bean
	public Step readInvalidatedSalesRecordsStep() {
		return ((stepBuilderFactory.get("readInvalidatedSalesRecordsStep")
				.<SalesFileHeaderStg, SalesFileHeaderStg>chunk(10)
				.reader((ItemReader<? extends SalesFileHeaderStg>) getSalesFileHeaderReader())
				/*.faultTolerant()
				.skip(ValidationException.class)
				.skip(IncorrectTokenCountException.class)
				.skipLimit(100000)
				*/.processor(compositeSalesValidationProcessor(salesValidationProcessor())).transactionManager(transactionManager)))
				.taskExecutor(taskExecutor()).throttleLimit(maxThreads).build();
	}
	
	@Bean
	public Job salesValidationJob(SalesValidationNotificationListener listener, Step readInvalidatedSalesRecordsStep) {
		return jobBuilderFactory
				.get("salesValidationJob")
				.incrementer(new RunIdIncrementer())
				.listener((JobExecutionListener) listener)
				.flow(readInvalidatedSalesRecordsStep)
				.end()
				.build();
	}
	
	
	
	 @Bean  
	@StepScope
	public ItemProcessor<? super SalesFileHeaderStg, ? extends SalesFileHeaderStg> compositeSalesValidationProcessor(
			ItemProcessor<?,? extends SalesFileHeaderStg> salesValidatorProcessor) {
		ClassifierCompositeItemProcessor<SalesFileHeaderStg, SalesFileHeaderStg> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor
				.setClassifier(new Classifier<SalesFileHeaderStg, ItemProcessor<?,? extends SalesFileHeaderStg>>() {
					private static final long serialVersionUID = 1586908304088511090L;

					@Override
					public ItemProcessor<?, ? extends SalesFileHeaderStg> classify(SalesFileHeaderStg classifiable) {
						if (classifiable instanceof SalesFileHeaderStg) {
							return salesValidatorProcessor;
						} 
						return null;

					}

				});
		return classifierCompositeItemProcessor;

	}
	 
	 
	 
		@Bean
		@StepScope
		public ItemProcessor<? extends SalesFileHeaderStg, ? extends SalesFileHeaderStg> salesValidationProcessor() {
			return new SalesFileHeaderStg().processor();
		}
}