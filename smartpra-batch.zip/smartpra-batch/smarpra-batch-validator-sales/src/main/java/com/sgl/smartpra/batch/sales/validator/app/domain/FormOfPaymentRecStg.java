package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the form_of_payment_rec_stg database table.
 * 
 */
@Entity
@Table(name="form_of_payment_rec_stg")
public class FormOfPaymentRecStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="fop_rec_id")
	private int fopRecId;

	@Column(name="approval_code")
	private String approvalCode;

	@Column(name="card_verification_value_result")
	private String cardVerificationValueResult;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="currency_type")
	private String currencyType;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	@Column(name="expiry_date")
	private String expiryDate;

	@Column(name="extended_payment_code")
	private String extendedPaymentCode;

	private String filler;

	@Column(name="fop_account_number")
	private String fopAccountNumber;

	@Column(name="fop_amount")
	private String fopAmount;

	@Column(name="fop_type")
	private String fopType;

	@Column(name="invoice_date")
	private String invoiceDate;

	@Column(name="invoice_number")
	private String invoiceNumber;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="remittance_amount")
	private String remittanceAmount;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="transaction_number")
	private String transactionNumber;

	//bi-directional many-to-one association to TransactionHdrStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="transaction_hdr_id")
	private TransactionHdrStg transactionHdrStg;

	public FormOfPaymentRecStg() {
	}

	public int getFopRecId() {
		return this.fopRecId;
	}

	public void setFopRecId(int fopRecId) {
		this.fopRecId = fopRecId;
	}

	public String getApprovalCode() {
		return this.approvalCode;
	}

	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}

	public String getCardVerificationValueResult() {
		return this.cardVerificationValueResult;
	}

	public void setCardVerificationValueResult(String cardVerificationValueResult) {
		this.cardVerificationValueResult = cardVerificationValueResult;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrencyType() {
		return this.currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getExpiryDate() {
		return this.expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getExtendedPaymentCode() {
		return this.extendedPaymentCode;
	}

	public void setExtendedPaymentCode(String extendedPaymentCode) {
		this.extendedPaymentCode = extendedPaymentCode;
	}

	public String getFiller() {
		return this.filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getFopAccountNumber() {
		return this.fopAccountNumber;
	}

	public void setFopAccountNumber(String fopAccountNumber) {
		this.fopAccountNumber = fopAccountNumber;
	}

	public String getFopAmount() {
		return this.fopAmount;
	}

	public void setFopAmount(String fopAmount) {
		this.fopAmount = fopAmount;
	}

	public String getFopType() {
		return this.fopType;
	}

	public void setFopType(String fopType) {
		this.fopType = fopType;
	}

	public String getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceNumber() {
		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getRemittanceAmount() {
		return this.remittanceAmount;
	}

	public void setRemittanceAmount(String remittanceAmount) {
		this.remittanceAmount = remittanceAmount;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public TransactionHdrStg getTransactionHdrStg() {
		return this.transactionHdrStg;
	}

	public void setTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		this.transactionHdrStg = transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
/*	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		FormOfPaymentStgLayout formOfPaymentStgLayout = new FormOfPaymentStgLayout();
		tokenizer.setColumns(formOfPaymentStgLayout.getColumns());
		tokenizer.setNames(formOfPaymentStgLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<BSPRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPRecord>();
		fieldSetMapper.setTargetType(FormOfPaymentRecStg.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BSPRecord, ? extends BSPRecord> processor() {
		return new FormOfPaymentStgProcessor();
	}

	@Override
	public ItemWriter<? super BSPRecord> writer() {
		return new FormOfPaymentStgWriter();
	}
*/
}