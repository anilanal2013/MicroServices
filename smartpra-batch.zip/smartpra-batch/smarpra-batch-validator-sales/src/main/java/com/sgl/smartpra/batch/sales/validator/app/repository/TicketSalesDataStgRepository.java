package com.sgl.smartpra.batch.sales.validator.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sgl.smartpra.batch.sales.validator.app.domain.TicketSalesDataStg;

@Repository
public interface TicketSalesDataStgRepository  extends JpaRepository<TicketSalesDataStg, Integer>{

}