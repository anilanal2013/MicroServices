package com.sgl.smartpra.batch.sales.validator.app.domain;


import java.io.Serializable;
import javax.persistence.*;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.fasterxml.jackson.annotation.JsonIgnore;
/*import com.sgl.smartpra.batch.bsp.app.processor.TicketCouponFnfProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.TicketCouponStgProcessor;*/
/*import com.sgl.smartpra.batch.bsp.app.writer.TicketCouponFnfWriter;
import com.sgl.smartpra.batch.bsp.app.writer.TicketCouponStgWriter;*/

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the ticket_coupon_stg database table.
 * 
 */
@Entity
@Table(name="ticket_coupon_stg")
public class TicketCouponStg  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="trn_tkt_cpn_id")
	private int trnTktCpnId;

	@Column(name="ach_factor")
	private String achFactor;

	@Column(name="ach_high_y_fare_amount")
	private String achHighYFareAmount;

	@Column(name="ach_high_y_fare_currency")
	private String achHighYFareCurrency;

	@Column(name="ach_high_y_fare_details")
	private String achHighYFareDetails;

	@Column(name="additional_commission")
	private String additionalCommission;

	@Column(name="adjusted_value")
	private String adjustedValue;

	@Column(name="alliance_commission")
	private String allianceCommission;

	@Column(name="alliance_discount")
	private String allianceDiscount;

	@Column(name="alliance_request_date")
	private String allianceRequestDate;

	@Column(name="alliancerequest_flag")
	private String alliancerequestFlag;

	@Column(name="alliancesector_value")
	private String alliancesectorValue;

	@Column(name="arrival_date")
	private String arrivalDate;

	@Column(name="arrival_terminal")
	private String arrivalTerminal;

	@Column(name="arrival_time")
	private String arrivalTime;

	@Column(name="atbp_number")
	private String atbpNumber;

	@Column(name="atbp_value")
	private String atbpValue;

	@Column(name="audit_commission")
	private String auditCommission;

	@Column(name="audit_discount")
	private String auditDiscount;

	@Column(name="audit_fare")
	private String auditFare;

	@Column(name="audit_orc")
	private String auditOrc;

	@Column(name="batch_details")
	private String batchDetails;

	@Column(name="booking_status")
	private String bookingStatus;

	@Column(name="class_diff_value")
	private String classDiffValue;

	@Column(name="codeshare_cabin")
	private String codeshareCabin;

	@Column(name="codeshare_rbd")
	private String codeshareRbd;

	@Column(name="commission_amount")
	private String commissionAmount;

	@Column(name="coupon_arrival_day")
	private String couponArrivalDay;

	@Column(name="coupon_number")
	private String couponNumber;

	@Column(name="coupon_reference_number")
	private String couponReferenceNumber;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="departure_terminal")
	private String departureTerminal;

	@Column(name="departure_time")
	private String departureTime;

	@Column(name="discount_amount")
	private String discountAmount;

	@Column(name="divergence_indicator")
	private String divergenceIndicator;

	@Column(name="dr_indicator")
	private String drIndicator;

	@Column(name="emd_attribute_group")
	private String emdAttributeGroup;

	@Column(name="emd_attribute_sub_group")
	private String emdAttributeSubGroup;

	@Column(name="emd_bagg_total_no_in_excs")
	private String emdBaggTotalNoInExcs;

	@Column(name="emd_consumed_at_issuance_ind")
	private String emdConsumedAtIssuanceInd;

	@Column(name="emd_coupon_value")
	private String emdCouponValue;

	@Column(name="emd_currency_type")
	private String emdCurrencyType;

	@Column(name="emd_excess_bagg_currency_code")
	private String emdExcessBaggCurrencyCode;

	@Column(name="emd_excess_bagg_rate_per_unit")
	private String emdExcessBaggRatePerUnit;

	@Column(name="emd_fee_owner_airline_design")
	private String emdFeeOwnerAirlineDesign;

	@Column(name="emd_industry_carrier_indicator")
	private String emdIndustryCarrierIndicator;

	@Column(name="emd_number_of_services")
	private String emdNumberOfServices;

	@Column(name="emd_operating_carrier")
	private String emdOperatingCarrier;

	@Column(name="emd_reason_for_issuance_subcde")
	private String emdReasonForIssuanceSubcde;

	@Column(name="emd_related_coupon_number")
	private String emdRelatedCouponNumber;

	@Column(name="emd_related_ticket_number")
	private String emdRelatedTicketNumber;

	@Column(name="emd_service_type")
	private String emdServiceType;

	@Column(name="emd_xcess_bagg_over_allow_qlfy")
	private String emdXcessBaggOverAllowQlfy;

	@Column(name="endorsement_indicator")
	private String endorsementIndicator;

	@Column(name="exg_rate_frm_atbp_to_base")
	private String exgRateFrmAtbpToBase;

	@Column(name="exg_rate_frm_atbp_to_bus_curr")
	private String exgRateFrmAtbpToBusCurr;

	@Column(name="exg_rate_frm_atbp_to_gbl_curr")
	private String exgRateFrmAtbpToGblCurr;

	@Column(name="exg_rate_frm_sales_to_base")
	private String exgRateFrmSalesToBase;

	@Column(name="exg_rate_frm_sales_to_bus_curr")
	private String exgRateFrmSalesToBusCurr;

	@Column(name="exg_rate_frm_sales_to_gbl_curr")
	private String exgRateFrmSalesToGblCurr;

	@Column(name="fare_basis")
	private String fareBasis;

	@Column(name="fare_component_number")
	private String fareComponentNumber;

	@Column(name="fare_component_value")
	private String fareComponentValue;

	@Column(name="ff_indicator")
	private String ffIndicator;

	@Column(name="ffy_isc_amount")
	private String ffyIscAmount;

	@Column(name="ffy_isc_percent")
	private String ffyIscPercent;

	@Column(name="ffy_mileage_amount")
	private String ffyMileageAmount;

	@Column(name="ffy_mileage_base_currency")
	private String ffyMileageBaseCurrency;

	@Column(name="file_source")
	private String fileSource;

	@Column(name="final_process_month")
	private int finalProcessMonth;

	@Column(name="final_quotient")
	private String finalQuotient;

	@Column(name="frequent_flyer_reference")
	private String frequentFlyerReference;

	@Column(name="from_airport")
	private String fromAirport;

	private String gcm;

	@Column(name="handling_fee_agreement_type")
	private String handlingFeeAgreementType;

	@Column(name="handling_fee_amount")
	private String handlingFeeAmount;

	@Column(name="handling_fee_base_currency")
	private String handlingFeeBaseCurrency;

	@Column(name="handling_fee_master_record")
	private String handlingFeeMasterRecord;

	@Column(name="handling_fee_percentage")
	private String handlingFeePercentage;

	@Column(name="industry_bi_lateral_isc_appld")
	private String industryBiLateralIscAppld;

	@Column(name="industry_cpbc")
	private String industryCpbc;

	@Column(name="industry_isc_percentage")
	private String industryIscPercentage;

	@Column(name="industry_isc_value")
	private String industryIscValue;

	@Column(name="industry_proc")
	private String industryProc;

	@Column(name="industry_prorate_value")
	private String industryProrateValue;

	@Column(name="industry_prot")
	private String industryProt;

	@Column(name="industry_uatp_amount")
	private String industryUatpAmount;

	@Column(name="industry_uatp_percentage")
	private String industryUatpPercentage;

	@Column(name="invol_flag")
	private String involFlag;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="marketing_carrier_alpha_code")
	private String marketingCarrierAlphaCode;

	@Column(name="marketing_carrier_num_code")
	private String marketingCarrierNumCode;

	@Column(name="marketing_flight_date")
	private String marketingFlightDate;

	@Column(name="marketing_flight_number")
	private String marketingFlightNumber;

	@Column(name="mco_coupon_tax_value")
	private String mcoCouponTaxValue;

	@Column(name="mco_coupon_value")
	private String mcoCouponValue;

	@Column(name="mco_service_type")
	private String mcoServiceType;

	@Column(name="mpa_residual")
	private String mpaResidual;

	@Column(name="mpa_wo_own_proviso")
	private String mpaWoOwnProviso;

	@Column(name="mpr_percentage")
	private String mprPercentage;

	@Column(name="not_valid_after")
	private String notValidAfter;

	@Column(name="not_valid_before")
	private String notValidBefore;

	@Column(name="one_world_prorate_flag")
	private String oneWorldProrateFlag;

	@Column(name="one_world_prorate_value")
	private String oneWorldProrateValue;

	@Column(name="operating_carrier_alpha_code")
	private String operatingCarrierAlphaCode;

	@Column(name="operating_carrier_num_code")
	private String operatingCarrierNumCode;

	@Column(name="operating_flight_dept_date")
	private String operatingFlightDeptDate;

	@Column(name="operating_flight_number")
	private String operatingFlightNumber;

	@Column(name="orc_amount")
	private String orcAmount;

	@Column(name="other_differences")
	private String otherDifferences;

	@Column(name="planned_optg_cxr_alpha_code")
	private String plannedOptgCxrAlphaCode;

	@Column(name="planned_optg_cxr_num_code")
	private String plannedOptgCxrNumCode;

	private String pot;

	@Column(name="present_to")
	private String presentTo;

	@Column(name="processing_date_and_time")
	private String processingDateAndTime;

	@Column(name="prorate_factor")
	private String prorateFactor;

	@Column(name="provisional_process_month")
	private int provisionalProcessMonth;

	@Column(name="proviso_value")
	private String provisoValue;

	@Column(name="response_date")
	private String responseDate;

	@Column(name="response_level_type")
	private String responseLevelType;

	@Column(name="sector_fare_amount")
	private String sectorFareAmount;

	@Column(name="sector_number")
	private String sectorNumber;

	@Column(name="settlement_cpbc")
	private String settlementCpbc;

	@Column(name="settlement_isc_percentage")
	private String settlementIscPercentage;

	@Column(name="settlement_isc_value")
	private String settlementIscValue;

	@Column(name="settlement_proc")
	private String settlementProc;

	@Column(name="settlement_prorate_value")
	private String settlementProrateValue;

	@Column(name="settlement_prot")
	private String settlementProt;

	@Column(name="settlement_uatp_amount")
	private String settlementUatpAmount;

	@Column(name="settlement_uatp_percentage")
	private String settlementUatpPercentage;

	@Column(name="side_trip")
	private String sideTrip;

	@Column(name="sirs_rate")
	private String sirsRate;

	@Column(name="spa_residual")
	private String spaResidual;

	@Column(name="spa_value")
	private String spaValue;

	@Column(name="srp_method")
	private String srpMethod;

	@Column(name="srp_value")
	private String srpValue;

	@Column(name="stopover_ind")
	private String stopoverInd;

	@Column(name="super_commission_currency")
	private String superCommissionCurrency;

	@Column(name="super_commission_master_record")
	private String superCommissionMasterRecord;

	@Column(name="super_commission_percentage")
	private String superCommissionPercentage;

	@Column(name="super_commission_type")
	private String superCommissionType;

	@Column(name="super_commission_value")
	private String superCommissionValue;

	@Column(name="surcharge_value")
	private String surchargeValue;

	@Column(name="tax_value")
	private String taxValue;

	@Column(name="thru_change_of_gauge_indicator")
	private String thruChangeOfGaugeIndicator;

	@Column(name="ticketed_cabin")
	private String ticketedCabin;

	@Column(name="ticketed_rbd")
	private String ticketedRbd;

	@Column(name="to_airport")
	private String toAirport;

	private String tpm;

	@Column(name="trans_ocean")
	private String transOcean;

	@Column(name="type_of_isc_clearing_house")
	private String typeOfIscClearingHouse;

	@Column(name="uatp_discount_type")
	private String uatpDiscountType;

	@Column(name="uatp_master_record")
	private String uatpMasterRecord;

	@Column(name="util_type")
	private String utilType;

	@Column(name="yqyr_residual")
	private String yqyrResidual;

	@Column(name="yqyr_tax_as_surcharge")
	private String yqyrTaxAsSurcharge;

	@Column(name="yqyr_tax_in_usd")
	private String yqyrTaxInUsd;

	//bi-directional many-to-one association to TicketCouponFnf
	@OneToMany(mappedBy="ticketCouponStg", cascade = CascadeType.ALL)
	private List<TicketCouponFnf> ticketCouponFnfs;

	//bi-directional many-to-one association to TicketMainStg
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="trn_tkt_id")
	private TicketMainStg ticketMainStg;

	public TicketCouponStg() {
	}

	public int getTrnTktCpnId() {
		return this.trnTktCpnId;
	}

	public void setTrnTktCpnId(int trnTktCpnId) {
		this.trnTktCpnId = trnTktCpnId;
	}

	public String getAchFactor() {
		return this.achFactor;
	}

	public void setAchFactor(String achFactor) {
		this.achFactor = achFactor;
	}

	public String getAchHighYFareAmount() {
		return this.achHighYFareAmount;
	}

	public void setAchHighYFareAmount(String achHighYFareAmount) {
		this.achHighYFareAmount = achHighYFareAmount;
	}

	public String getAchHighYFareCurrency() {
		return this.achHighYFareCurrency;
	}

	public void setAchHighYFareCurrency(String achHighYFareCurrency) {
		this.achHighYFareCurrency = achHighYFareCurrency;
	}

	public String getAchHighYFareDetails() {
		return this.achHighYFareDetails;
	}

	public void setAchHighYFareDetails(String achHighYFareDetails) {
		this.achHighYFareDetails = achHighYFareDetails;
	}

	public String getAdditionalCommission() {
		return this.additionalCommission;
	}

	public void setAdditionalCommission(String additionalCommission) {
		this.additionalCommission = additionalCommission;
	}

	public String getAdjustedValue() {
		return this.adjustedValue;
	}

	public void setAdjustedValue(String adjustedValue) {
		this.adjustedValue = adjustedValue;
	}

	public String getAllianceCommission() {
		return this.allianceCommission;
	}

	public void setAllianceCommission(String allianceCommission) {
		this.allianceCommission = allianceCommission;
	}

	public String getAllianceDiscount() {
		return this.allianceDiscount;
	}

	public void setAllianceDiscount(String allianceDiscount) {
		this.allianceDiscount = allianceDiscount;
	}

	public String getAllianceRequestDate() {
		return this.allianceRequestDate;
	}

	public void setAllianceRequestDate(String allianceRequestDate) {
		this.allianceRequestDate = allianceRequestDate;
	}

	public String getAlliancerequestFlag() {
		return this.alliancerequestFlag;
	}

	public void setAlliancerequestFlag(String alliancerequestFlag) {
		this.alliancerequestFlag = alliancerequestFlag;
	}

	public String getAlliancesectorValue() {
		return this.alliancesectorValue;
	}

	public void setAlliancesectorValue(String alliancesectorValue) {
		this.alliancesectorValue = alliancesectorValue;
	}

	public String getArrivalDate() {
		return this.arrivalDate;
	}

	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public String getArrivalTerminal() {
		return this.arrivalTerminal;
	}

	public void setArrivalTerminal(String arrivalTerminal) {
		this.arrivalTerminal = arrivalTerminal;
	}

	public String getArrivalTime() {
		return this.arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getAtbpNumber() {
		return this.atbpNumber;
	}

	public void setAtbpNumber(String atbpNumber) {
		this.atbpNumber = atbpNumber;
	}

	public String getAtbpValue() {
		return this.atbpValue;
	}

	public void setAtbpValue(String atbpValue) {
		this.atbpValue = atbpValue;
	}

	public String getAuditCommission() {
		return this.auditCommission;
	}

	public void setAuditCommission(String auditCommission) {
		this.auditCommission = auditCommission;
	}

	public String getAuditDiscount() {
		return this.auditDiscount;
	}

	public void setAuditDiscount(String auditDiscount) {
		this.auditDiscount = auditDiscount;
	}

	public String getAuditFare() {
		return this.auditFare;
	}

	public void setAuditFare(String auditFare) {
		this.auditFare = auditFare;
	}

	public String getAuditOrc() {
		return this.auditOrc;
	}

	public void setAuditOrc(String auditOrc) {
		this.auditOrc = auditOrc;
	}

	public String getBatchDetails() {
		return this.batchDetails;
	}

	public void setBatchDetails(String batchDetails) {
		this.batchDetails = batchDetails;
	}

	public String getBookingStatus() {
		return this.bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public String getClassDiffValue() {
		return this.classDiffValue;
	}

	public void setClassDiffValue(String classDiffValue) {
		this.classDiffValue = classDiffValue;
	}

	public String getCodeshareCabin() {
		return this.codeshareCabin;
	}

	public void setCodeshareCabin(String codeshareCabin) {
		this.codeshareCabin = codeshareCabin;
	}

	public String getCodeshareRbd() {
		return this.codeshareRbd;
	}

	public void setCodeshareRbd(String codeshareRbd) {
		this.codeshareRbd = codeshareRbd;
	}

	public String getCommissionAmount() {
		return this.commissionAmount;
	}

	public void setCommissionAmount(String commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	public String getCouponArrivalDay() {
		return this.couponArrivalDay;
	}

	public void setCouponArrivalDay(String couponArrivalDay) {
		this.couponArrivalDay = couponArrivalDay;
	}

	public String getCouponNumber() {
		return this.couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCouponReferenceNumber() {
		return this.couponReferenceNumber;
	}

	public void setCouponReferenceNumber(String couponReferenceNumber) {
		this.couponReferenceNumber = couponReferenceNumber;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDepartureTerminal() {
		return this.departureTerminal;
	}

	public void setDepartureTerminal(String departureTerminal) {
		this.departureTerminal = departureTerminal;
	}

	public String getDepartureTime() {
		return this.departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getDiscountAmount() {
		return this.discountAmount;
	}

	public void setDiscountAmount(String discountAmount) {
		this.discountAmount = discountAmount;
	}

	public String getDivergenceIndicator() {
		return this.divergenceIndicator;
	}

	public void setDivergenceIndicator(String divergenceIndicator) {
		this.divergenceIndicator = divergenceIndicator;
	}

	public String getDrIndicator() {
		return this.drIndicator;
	}

	public void setDrIndicator(String drIndicator) {
		this.drIndicator = drIndicator;
	}

	public String getEmdAttributeGroup() {
		return this.emdAttributeGroup;
	}

	public void setEmdAttributeGroup(String emdAttributeGroup) {
		this.emdAttributeGroup = emdAttributeGroup;
	}

	public String getEmdAttributeSubGroup() {
		return this.emdAttributeSubGroup;
	}

	public void setEmdAttributeSubGroup(String emdAttributeSubGroup) {
		this.emdAttributeSubGroup = emdAttributeSubGroup;
	}

	public String getEmdBaggTotalNoInExcs() {
		return this.emdBaggTotalNoInExcs;
	}

	public void setEmdBaggTotalNoInExcs(String emdBaggTotalNoInExcs) {
		this.emdBaggTotalNoInExcs = emdBaggTotalNoInExcs;
	}

	public String getEmdConsumedAtIssuanceInd() {
		return this.emdConsumedAtIssuanceInd;
	}

	public void setEmdConsumedAtIssuanceInd(String emdConsumedAtIssuanceInd) {
		this.emdConsumedAtIssuanceInd = emdConsumedAtIssuanceInd;
	}

	public String getEmdCouponValue() {
		return this.emdCouponValue;
	}

	public void setEmdCouponValue(String emdCouponValue) {
		this.emdCouponValue = emdCouponValue;
	}

	public String getEmdCurrencyType() {
		return this.emdCurrencyType;
	}

	public void setEmdCurrencyType(String emdCurrencyType) {
		this.emdCurrencyType = emdCurrencyType;
	}

	public String getEmdExcessBaggCurrencyCode() {
		return this.emdExcessBaggCurrencyCode;
	}

	public void setEmdExcessBaggCurrencyCode(String emdExcessBaggCurrencyCode) {
		this.emdExcessBaggCurrencyCode = emdExcessBaggCurrencyCode;
	}

	public String getEmdExcessBaggRatePerUnit() {
		return this.emdExcessBaggRatePerUnit;
	}

	public void setEmdExcessBaggRatePerUnit(String emdExcessBaggRatePerUnit) {
		this.emdExcessBaggRatePerUnit = emdExcessBaggRatePerUnit;
	}

	public String getEmdFeeOwnerAirlineDesign() {
		return this.emdFeeOwnerAirlineDesign;
	}

	public void setEmdFeeOwnerAirlineDesign(String emdFeeOwnerAirlineDesign) {
		this.emdFeeOwnerAirlineDesign = emdFeeOwnerAirlineDesign;
	}

	public String getEmdIndustryCarrierIndicator() {
		return this.emdIndustryCarrierIndicator;
	}

	public void setEmdIndustryCarrierIndicator(String emdIndustryCarrierIndicator) {
		this.emdIndustryCarrierIndicator = emdIndustryCarrierIndicator;
	}

	public String getEmdNumberOfServices() {
		return this.emdNumberOfServices;
	}

	public void setEmdNumberOfServices(String emdNumberOfServices) {
		this.emdNumberOfServices = emdNumberOfServices;
	}

	public String getEmdOperatingCarrier() {
		return this.emdOperatingCarrier;
	}

	public void setEmdOperatingCarrier(String emdOperatingCarrier) {
		this.emdOperatingCarrier = emdOperatingCarrier;
	}

	public String getEmdReasonForIssuanceSubcde() {
		return this.emdReasonForIssuanceSubcde;
	}

	public void setEmdReasonForIssuanceSubcde(String emdReasonForIssuanceSubcde) {
		this.emdReasonForIssuanceSubcde = emdReasonForIssuanceSubcde;
	}

	public String getEmdRelatedCouponNumber() {
		return this.emdRelatedCouponNumber;
	}

	public void setEmdRelatedCouponNumber(String emdRelatedCouponNumber) {
		this.emdRelatedCouponNumber = emdRelatedCouponNumber;
	}

	public String getEmdRelatedTicketNumber() {
		return this.emdRelatedTicketNumber;
	}

	public void setEmdRelatedTicketNumber(String emdRelatedTicketNumber) {
		this.emdRelatedTicketNumber = emdRelatedTicketNumber;
	}

	public String getEmdServiceType() {
		return this.emdServiceType;
	}

	public void setEmdServiceType(String emdServiceType) {
		this.emdServiceType = emdServiceType;
	}

	public String getEmdXcessBaggOverAllowQlfy() {
		return this.emdXcessBaggOverAllowQlfy;
	}

	public void setEmdXcessBaggOverAllowQlfy(String emdXcessBaggOverAllowQlfy) {
		this.emdXcessBaggOverAllowQlfy = emdXcessBaggOverAllowQlfy;
	}

	public String getEndorsementIndicator() {
		return this.endorsementIndicator;
	}

	public void setEndorsementIndicator(String endorsementIndicator) {
		this.endorsementIndicator = endorsementIndicator;
	}

	public String getExgRateFrmAtbpToBase() {
		return this.exgRateFrmAtbpToBase;
	}

	public void setExgRateFrmAtbpToBase(String exgRateFrmAtbpToBase) {
		this.exgRateFrmAtbpToBase = exgRateFrmAtbpToBase;
	}

	public String getExgRateFrmAtbpToBusCurr() {
		return this.exgRateFrmAtbpToBusCurr;
	}

	public void setExgRateFrmAtbpToBusCurr(String exgRateFrmAtbpToBusCurr) {
		this.exgRateFrmAtbpToBusCurr = exgRateFrmAtbpToBusCurr;
	}

	public String getExgRateFrmAtbpToGblCurr() {
		return this.exgRateFrmAtbpToGblCurr;
	}

	public void setExgRateFrmAtbpToGblCurr(String exgRateFrmAtbpToGblCurr) {
		this.exgRateFrmAtbpToGblCurr = exgRateFrmAtbpToGblCurr;
	}

	public String getExgRateFrmSalesToBase() {
		return this.exgRateFrmSalesToBase;
	}

	public void setExgRateFrmSalesToBase(String exgRateFrmSalesToBase) {
		this.exgRateFrmSalesToBase = exgRateFrmSalesToBase;
	}

	public String getExgRateFrmSalesToBusCurr() {
		return this.exgRateFrmSalesToBusCurr;
	}

	public void setExgRateFrmSalesToBusCurr(String exgRateFrmSalesToBusCurr) {
		this.exgRateFrmSalesToBusCurr = exgRateFrmSalesToBusCurr;
	}

	public String getExgRateFrmSalesToGblCurr() {
		return this.exgRateFrmSalesToGblCurr;
	}

	public void setExgRateFrmSalesToGblCurr(String exgRateFrmSalesToGblCurr) {
		this.exgRateFrmSalesToGblCurr = exgRateFrmSalesToGblCurr;
	}

	public String getFareBasis() {
		return this.fareBasis;
	}

	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}

	public String getFareComponentNumber() {
		return this.fareComponentNumber;
	}

	public void setFareComponentNumber(String fareComponentNumber) {
		this.fareComponentNumber = fareComponentNumber;
	}

	public String getFareComponentValue() {
		return this.fareComponentValue;
	}

	public void setFareComponentValue(String fareComponentValue) {
		this.fareComponentValue = fareComponentValue;
	}

	public String getFfIndicator() {
		return this.ffIndicator;
	}

	public void setFfIndicator(String ffIndicator) {
		this.ffIndicator = ffIndicator;
	}

	public String getFfyIscAmount() {
		return this.ffyIscAmount;
	}

	public void setFfyIscAmount(String ffyIscAmount) {
		this.ffyIscAmount = ffyIscAmount;
	}

	public String getFfyIscPercent() {
		return this.ffyIscPercent;
	}

	public void setFfyIscPercent(String ffyIscPercent) {
		this.ffyIscPercent = ffyIscPercent;
	}

	public String getFfyMileageAmount() {
		return this.ffyMileageAmount;
	}

	public void setFfyMileageAmount(String ffyMileageAmount) {
		this.ffyMileageAmount = ffyMileageAmount;
	}

	public String getFfyMileageBaseCurrency() {
		return this.ffyMileageBaseCurrency;
	}

	public void setFfyMileageBaseCurrency(String ffyMileageBaseCurrency) {
		this.ffyMileageBaseCurrency = ffyMileageBaseCurrency;
	}

	public String getFileSource() {
		return this.fileSource;
	}

	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}

	public int getFinalProcessMonth() {
		return this.finalProcessMonth;
	}

	public void setFinalProcessMonth(int finalProcessMonth) {
		this.finalProcessMonth = finalProcessMonth;
	}

	public String getFinalQuotient() {
		return this.finalQuotient;
	}

	public void setFinalQuotient(String finalQuotient) {
		this.finalQuotient = finalQuotient;
	}

	public String getFrequentFlyerReference() {
		return this.frequentFlyerReference;
	}

	public void setFrequentFlyerReference(String frequentFlyerReference) {
		this.frequentFlyerReference = frequentFlyerReference;
	}

	public String getFromAirport() {
		return this.fromAirport;
	}

	public void setFromAirport(String fromAirport) {
		this.fromAirport = fromAirport;
	}

	public String getGcm() {
		return this.gcm;
	}

	public void setGcm(String gcm) {
		this.gcm = gcm;
	}

	public String getHandlingFeeAgreementType() {
		return this.handlingFeeAgreementType;
	}

	public void setHandlingFeeAgreementType(String handlingFeeAgreementType) {
		this.handlingFeeAgreementType = handlingFeeAgreementType;
	}

	public String getHandlingFeeAmount() {
		return this.handlingFeeAmount;
	}

	public void setHandlingFeeAmount(String handlingFeeAmount) {
		this.handlingFeeAmount = handlingFeeAmount;
	}

	public String getHandlingFeeBaseCurrency() {
		return this.handlingFeeBaseCurrency;
	}

	public void setHandlingFeeBaseCurrency(String handlingFeeBaseCurrency) {
		this.handlingFeeBaseCurrency = handlingFeeBaseCurrency;
	}

	public String getHandlingFeeMasterRecord() {
		return this.handlingFeeMasterRecord;
	}

	public void setHandlingFeeMasterRecord(String handlingFeeMasterRecord) {
		this.handlingFeeMasterRecord = handlingFeeMasterRecord;
	}

	public String getHandlingFeePercentage() {
		return this.handlingFeePercentage;
	}

	public void setHandlingFeePercentage(String handlingFeePercentage) {
		this.handlingFeePercentage = handlingFeePercentage;
	}

	public String getIndustryBiLateralIscAppld() {
		return this.industryBiLateralIscAppld;
	}

	public void setIndustryBiLateralIscAppld(String industryBiLateralIscAppld) {
		this.industryBiLateralIscAppld = industryBiLateralIscAppld;
	}

	public String getIndustryCpbc() {
		return this.industryCpbc;
	}

	public void setIndustryCpbc(String industryCpbc) {
		this.industryCpbc = industryCpbc;
	}

	public String getIndustryIscPercentage() {
		return this.industryIscPercentage;
	}

	public void setIndustryIscPercentage(String industryIscPercentage) {
		this.industryIscPercentage = industryIscPercentage;
	}

	public String getIndustryIscValue() {
		return this.industryIscValue;
	}

	public void setIndustryIscValue(String industryIscValue) {
		this.industryIscValue = industryIscValue;
	}

	public String getIndustryProc() {
		return this.industryProc;
	}

	public void setIndustryProc(String industryProc) {
		this.industryProc = industryProc;
	}

	public String getIndustryProrateValue() {
		return this.industryProrateValue;
	}

	public void setIndustryProrateValue(String industryProrateValue) {
		this.industryProrateValue = industryProrateValue;
	}

	public String getIndustryProt() {
		return this.industryProt;
	}

	public void setIndustryProt(String industryProt) {
		this.industryProt = industryProt;
	}

	public String getIndustryUatpAmount() {
		return this.industryUatpAmount;
	}

	public void setIndustryUatpAmount(String industryUatpAmount) {
		this.industryUatpAmount = industryUatpAmount;
	}

	public String getIndustryUatpPercentage() {
		return this.industryUatpPercentage;
	}

	public void setIndustryUatpPercentage(String industryUatpPercentage) {
		this.industryUatpPercentage = industryUatpPercentage;
	}

	public String getInvolFlag() {
		return this.involFlag;
	}

	public void setInvolFlag(String involFlag) {
		this.involFlag = involFlag;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getMarketingCarrierAlphaCode() {
		return this.marketingCarrierAlphaCode;
	}

	public void setMarketingCarrierAlphaCode(String marketingCarrierAlphaCode) {
		this.marketingCarrierAlphaCode = marketingCarrierAlphaCode;
	}

	public String getMarketingCarrierNumCode() {
		return this.marketingCarrierNumCode;
	}

	public void setMarketingCarrierNumCode(String marketingCarrierNumCode) {
		this.marketingCarrierNumCode = marketingCarrierNumCode;
	}

	public String getMarketingFlightDate() {
		return this.marketingFlightDate;
	}

	public void setMarketingFlightDate(String marketingFlightDate) {
		this.marketingFlightDate = marketingFlightDate;
	}

	public String getMarketingFlightNumber() {
		return this.marketingFlightNumber;
	}

	public void setMarketingFlightNumber(String marketingFlightNumber) {
		this.marketingFlightNumber = marketingFlightNumber;
	}

	public String getMcoCouponTaxValue() {
		return this.mcoCouponTaxValue;
	}

	public void setMcoCouponTaxValue(String mcoCouponTaxValue) {
		this.mcoCouponTaxValue = mcoCouponTaxValue;
	}

	public String getMcoCouponValue() {
		return this.mcoCouponValue;
	}

	public void setMcoCouponValue(String mcoCouponValue) {
		this.mcoCouponValue = mcoCouponValue;
	}

	public String getMcoServiceType() {
		return this.mcoServiceType;
	}

	public void setMcoServiceType(String mcoServiceType) {
		this.mcoServiceType = mcoServiceType;
	}

	public String getMpaResidual() {
		return this.mpaResidual;
	}

	public void setMpaResidual(String mpaResidual) {
		this.mpaResidual = mpaResidual;
	}

	public String getMpaWoOwnProviso() {
		return this.mpaWoOwnProviso;
	}

	public void setMpaWoOwnProviso(String mpaWoOwnProviso) {
		this.mpaWoOwnProviso = mpaWoOwnProviso;
	}

	public String getMprPercentage() {
		return this.mprPercentage;
	}

	public void setMprPercentage(String mprPercentage) {
		this.mprPercentage = mprPercentage;
	}

	public String getNotValidAfter() {
		return this.notValidAfter;
	}

	public void setNotValidAfter(String notValidAfter) {
		this.notValidAfter = notValidAfter;
	}

	public String getNotValidBefore() {
		return this.notValidBefore;
	}

	public void setNotValidBefore(String notValidBefore) {
		this.notValidBefore = notValidBefore;
	}

	public String getOneWorldProrateFlag() {
		return this.oneWorldProrateFlag;
	}

	public void setOneWorldProrateFlag(String oneWorldProrateFlag) {
		this.oneWorldProrateFlag = oneWorldProrateFlag;
	}

	public String getOneWorldProrateValue() {
		return this.oneWorldProrateValue;
	}

	public void setOneWorldProrateValue(String oneWorldProrateValue) {
		this.oneWorldProrateValue = oneWorldProrateValue;
	}

	public String getOperatingCarrierAlphaCode() {
		return this.operatingCarrierAlphaCode;
	}

	public void setOperatingCarrierAlphaCode(String operatingCarrierAlphaCode) {
		this.operatingCarrierAlphaCode = operatingCarrierAlphaCode;
	}

	public String getOperatingCarrierNumCode() {
		return this.operatingCarrierNumCode;
	}

	public void setOperatingCarrierNumCode(String operatingCarrierNumCode) {
		this.operatingCarrierNumCode = operatingCarrierNumCode;
	}

	public String getOperatingFlightDeptDate() {
		return this.operatingFlightDeptDate;
	}

	public void setOperatingFlightDeptDate(String operatingFlightDeptDate) {
		this.operatingFlightDeptDate = operatingFlightDeptDate;
	}

	public String getOperatingFlightNumber() {
		return this.operatingFlightNumber;
	}

	public void setOperatingFlightNumber(String operatingFlightNumber) {
		this.operatingFlightNumber = operatingFlightNumber;
	}

	public String getOrcAmount() {
		return this.orcAmount;
	}

	public void setOrcAmount(String orcAmount) {
		this.orcAmount = orcAmount;
	}

	public String getOtherDifferences() {
		return this.otherDifferences;
	}

	public void setOtherDifferences(String otherDifferences) {
		this.otherDifferences = otherDifferences;
	}

	public String getPlannedOptgCxrAlphaCode() {
		return this.plannedOptgCxrAlphaCode;
	}

	public void setPlannedOptgCxrAlphaCode(String plannedOptgCxrAlphaCode) {
		this.plannedOptgCxrAlphaCode = plannedOptgCxrAlphaCode;
	}

	public String getPlannedOptgCxrNumCode() {
		return this.plannedOptgCxrNumCode;
	}

	public void setPlannedOptgCxrNumCode(String plannedOptgCxrNumCode) {
		this.plannedOptgCxrNumCode = plannedOptgCxrNumCode;
	}

	public String getPot() {
		return this.pot;
	}

	public void setPot(String pot) {
		this.pot = pot;
	}

	public String getPresentTo() {
		return this.presentTo;
	}

	public void setPresentTo(String presentTo) {
		this.presentTo = presentTo;
	}

	public String getProcessingDateAndTime() {
		return this.processingDateAndTime;
	}

	public void setProcessingDateAndTime(String processingDateAndTime) {
		this.processingDateAndTime = processingDateAndTime;
	}

	public String getProrateFactor() {
		return this.prorateFactor;
	}

	public void setProrateFactor(String prorateFactor) {
		this.prorateFactor = prorateFactor;
	}

	public int getProvisionalProcessMonth() {
		return this.provisionalProcessMonth;
	}

	public void setProvisionalProcessMonth(int provisionalProcessMonth) {
		this.provisionalProcessMonth = provisionalProcessMonth;
	}

	public String getProvisoValue() {
		return this.provisoValue;
	}

	public void setProvisoValue(String provisoValue) {
		this.provisoValue = provisoValue;
	}

	public String getResponseDate() {
		return this.responseDate;
	}

	public void setResponseDate(String responseDate) {
		this.responseDate = responseDate;
	}

	public String getResponseLevelType() {
		return this.responseLevelType;
	}

	public void setResponseLevelType(String responseLevelType) {
		this.responseLevelType = responseLevelType;
	}

	public String getSectorFareAmount() {
		return this.sectorFareAmount;
	}

	public void setSectorFareAmount(String sectorFareAmount) {
		this.sectorFareAmount = sectorFareAmount;
	}

	public String getSectorNumber() {
		return this.sectorNumber;
	}

	public void setSectorNumber(String sectorNumber) {
		this.sectorNumber = sectorNumber;
	}

	public String getSettlementCpbc() {
		return this.settlementCpbc;
	}

	public void setSettlementCpbc(String settlementCpbc) {
		this.settlementCpbc = settlementCpbc;
	}

	public String getSettlementIscPercentage() {
		return this.settlementIscPercentage;
	}

	public void setSettlementIscPercentage(String settlementIscPercentage) {
		this.settlementIscPercentage = settlementIscPercentage;
	}

	public String getSettlementIscValue() {
		return this.settlementIscValue;
	}

	public void setSettlementIscValue(String settlementIscValue) {
		this.settlementIscValue = settlementIscValue;
	}

	public String getSettlementProc() {
		return this.settlementProc;
	}

	public void setSettlementProc(String settlementProc) {
		this.settlementProc = settlementProc;
	}

	public String getSettlementProrateValue() {
		return this.settlementProrateValue;
	}

	public void setSettlementProrateValue(String settlementProrateValue) {
		this.settlementProrateValue = settlementProrateValue;
	}

	public String getSettlementProt() {
		return this.settlementProt;
	}

	public void setSettlementProt(String settlementProt) {
		this.settlementProt = settlementProt;
	}

	public String getSettlementUatpAmount() {
		return this.settlementUatpAmount;
	}

	public void setSettlementUatpAmount(String settlementUatpAmount) {
		this.settlementUatpAmount = settlementUatpAmount;
	}

	public String getSettlementUatpPercentage() {
		return this.settlementUatpPercentage;
	}

	public void setSettlementUatpPercentage(String settlementUatpPercentage) {
		this.settlementUatpPercentage = settlementUatpPercentage;
	}

	public String getSideTrip() {
		return this.sideTrip;
	}

	public void setSideTrip(String sideTrip) {
		this.sideTrip = sideTrip;
	}

	public String getSirsRate() {
		return this.sirsRate;
	}

	public void setSirsRate(String sirsRate) {
		this.sirsRate = sirsRate;
	}

	public String getSpaResidual() {
		return this.spaResidual;
	}

	public void setSpaResidual(String spaResidual) {
		this.spaResidual = spaResidual;
	}

	public String getSpaValue() {
		return this.spaValue;
	}

	public void setSpaValue(String spaValue) {
		this.spaValue = spaValue;
	}

	public String getSrpMethod() {
		return this.srpMethod;
	}

	public void setSrpMethod(String srpMethod) {
		this.srpMethod = srpMethod;
	}

	public String getSrpValue() {
		return this.srpValue;
	}

	public void setSrpValue(String srpValue) {
		this.srpValue = srpValue;
	}

	public String getStopoverInd() {
		return this.stopoverInd;
	}

	public void setStopoverInd(String stopoverInd) {
		this.stopoverInd = stopoverInd;
	}

	public String getSuperCommissionCurrency() {
		return this.superCommissionCurrency;
	}

	public void setSuperCommissionCurrency(String superCommissionCurrency) {
		this.superCommissionCurrency = superCommissionCurrency;
	}

	public String getSuperCommissionMasterRecord() {
		return this.superCommissionMasterRecord;
	}

	public void setSuperCommissionMasterRecord(String superCommissionMasterRecord) {
		this.superCommissionMasterRecord = superCommissionMasterRecord;
	}

	public String getSuperCommissionPercentage() {
		return this.superCommissionPercentage;
	}

	public void setSuperCommissionPercentage(String superCommissionPercentage) {
		this.superCommissionPercentage = superCommissionPercentage;
	}

	public String getSuperCommissionType() {
		return this.superCommissionType;
	}

	public void setSuperCommissionType(String superCommissionType) {
		this.superCommissionType = superCommissionType;
	}

	public String getSuperCommissionValue() {
		return this.superCommissionValue;
	}

	public void setSuperCommissionValue(String superCommissionValue) {
		this.superCommissionValue = superCommissionValue;
	}

	public String getSurchargeValue() {
		return this.surchargeValue;
	}

	public void setSurchargeValue(String surchargeValue) {
		this.surchargeValue = surchargeValue;
	}

	public String getTaxValue() {
		return this.taxValue;
	}

	public void setTaxValue(String taxValue) {
		this.taxValue = taxValue;
	}

	public String getThruChangeOfGaugeIndicator() {
		return this.thruChangeOfGaugeIndicator;
	}

	public void setThruChangeOfGaugeIndicator(String thruChangeOfGaugeIndicator) {
		this.thruChangeOfGaugeIndicator = thruChangeOfGaugeIndicator;
	}

	public String getTicketedCabin() {
		return this.ticketedCabin;
	}

	public void setTicketedCabin(String ticketedCabin) {
		this.ticketedCabin = ticketedCabin;
	}

	public String getTicketedRbd() {
		return this.ticketedRbd;
	}

	public void setTicketedRbd(String ticketedRbd) {
		this.ticketedRbd = ticketedRbd;
	}

	public String getToAirport() {
		return this.toAirport;
	}

	public void setToAirport(String toAirport) {
		this.toAirport = toAirport;
	}

	public String getTpm() {
		return this.tpm;
	}

	public void setTpm(String tpm) {
		this.tpm = tpm;
	}

	public String getTransOcean() {
		return this.transOcean;
	}

	public void setTransOcean(String transOcean) {
		this.transOcean = transOcean;
	}

	public String getTypeOfIscClearingHouse() {
		return this.typeOfIscClearingHouse;
	}

	public void setTypeOfIscClearingHouse(String typeOfIscClearingHouse) {
		this.typeOfIscClearingHouse = typeOfIscClearingHouse;
	}

	public String getUatpDiscountType() {
		return this.uatpDiscountType;
	}

	public void setUatpDiscountType(String uatpDiscountType) {
		this.uatpDiscountType = uatpDiscountType;
	}

	public String getUatpMasterRecord() {
		return this.uatpMasterRecord;
	}

	public void setUatpMasterRecord(String uatpMasterRecord) {
		this.uatpMasterRecord = uatpMasterRecord;
	}

	public String getUtilType() {
		return this.utilType;
	}

	public void setUtilType(String utilType) {
		this.utilType = utilType;
	}

	public String getYqyrResidual() {
		return this.yqyrResidual;
	}

	public void setYqyrResidual(String yqyrResidual) {
		this.yqyrResidual = yqyrResidual;
	}

	public String getYqyrTaxAsSurcharge() {
		return this.yqyrTaxAsSurcharge;
	}

	public void setYqyrTaxAsSurcharge(String yqyrTaxAsSurcharge) {
		this.yqyrTaxAsSurcharge = yqyrTaxAsSurcharge;
	}

	public String getYqyrTaxInUsd() {
		return this.yqyrTaxInUsd;
	}

	public void setYqyrTaxInUsd(String yqyrTaxInUsd) {
		this.yqyrTaxInUsd = yqyrTaxInUsd;
	}

	public List<TicketCouponFnf> getTicketCouponFnfs() {
		return this.ticketCouponFnfs;
	}

	public void setTicketCouponFnfs(List<TicketCouponFnf> ticketCouponFnfs) {
		this.ticketCouponFnfs = ticketCouponFnfs;
	}

	public TicketCouponFnf addTicketCouponFnf(TicketCouponFnf ticketCouponFnf) {
		List<TicketCouponFnf> couponList2 = getTicketCouponFnfs();
		if(couponList2 == null) this.ticketCouponFnfs = new ArrayList<TicketCouponFnf>();
		getTicketCouponFnfs().add(ticketCouponFnf);
		return ticketCouponFnf;
	}

	public TicketCouponFnf removeTicketCouponFnf(TicketCouponFnf ticketCouponFnf) {
		getTicketCouponFnfs().remove(ticketCouponFnf);
		ticketCouponFnf.setTicketCouponStg(null);

		return ticketCouponFnf;
	}

	public TicketMainStg getTicketMainStg() {
		return this.ticketMainStg;
	}

	public void setTicketMainStg(TicketMainStg ticketMainStg) {
		this.ticketMainStg = ticketMainStg;
	}

}