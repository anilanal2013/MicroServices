package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.fasterxml.jackson.annotation.JsonIgnore;



/**
 * The persistent class for the reporting_office_hdr_stg database table.
 * 
 */
@Entity
@Table(name="reporting_office_hdr_stg")
public class ReportingOfficeHdrStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="office_hdr_auto_id")
	private int officeHdrAutoId;

	@Column(name="agent_numeric_code")
	private String agentNumericCode;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="currency_type")
	private String currencyType;

	private String filler3;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="multi_location_identifier")
	private String multiLocationIdentifier;

	@Column(name="remittance_period_end_date")
	private String remittancePeriodEndDate;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	//bi-directional many-to-one association to SalesFileHeaderStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="file_hdr_id")
	private SalesFileHeaderStg salesFileHeaderStg;

	public ReportingOfficeHdrStg() {
	}

	public int getOfficeHdrAutoId() {
		return this.officeHdrAutoId;
	}

	public void setOfficeHdrAutoId(int officeHdrAutoId) {
		this.officeHdrAutoId = officeHdrAutoId;
	}

	public String getAgentNumericCode() {
		return this.agentNumericCode;
	}

	public void setAgentNumericCode(String agentNumericCode) {
		this.agentNumericCode = agentNumericCode;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrencyType() {
		return this.currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getFiller3() {
		return this.filler3;
	}

	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getMultiLocationIdentifier() {
		return this.multiLocationIdentifier;
	}

	public void setMultiLocationIdentifier(String multiLocationIdentifier) {
		this.multiLocationIdentifier = multiLocationIdentifier;
	}

	public String getRemittancePeriodEndDate() {
		return this.remittancePeriodEndDate;
	}

	public void setRemittancePeriodEndDate(String remittancePeriodEndDate) {
		this.remittancePeriodEndDate = remittancePeriodEndDate;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public SalesFileHeaderStg getSalesFileHeaderStg() {
		return this.salesFileHeaderStg;
	}

	public void setSalesFileHeaderStg(SalesFileHeaderStg salesFileHeaderStg) {
		this.salesFileHeaderStg = salesFileHeaderStg;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}