package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.sql.Timestamp;

import javax.persistence.Column;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.sales.validator.app.processor.SalesValidatorProcessor;

public abstract class BSPRecord {

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;
	

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}



		// TODO Auto-generated method stu

//	public abstract LineTokenizer lineTokenizer();
//
//	public abstract FieldSetMapper<BSPRecord> fieldSetMapper();
//
//	public abstract ItemProcessor<? extends BSPRecord, ? extends BSPRecord> processor();
//
//	public abstract ItemWriter<? super BSPRecord> writer();
	


}