package com.sgl.smartpra.batch.sales.validator.app.master.impl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.sales.validator.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.sales.validator.app.master.AgencyMasterClient;
import com.sgl.smartpra.master.model.AgencyMaster;

@Service
public class AgencyMasterImpl implements AgencyMasterClient {
	
	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	

	
	
	@Override
	public List<AgencyMaster> getAllAgency(String agencyCode, String reportingAgency,String agencyType,String areaOfOperation, String reportingAgencyType){
	
		return	smartpraMasterAppClient.getAllAgency(agencyCode,reportingAgency,agencyType,areaOfOperation,reportingAgencyType);
	}
	


	}
	

