package com.sgl.smartpra.batch.sales.validator.app.domain;


import java.io.Serializable;
import javax.persistence.*;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.fasterxml.jackson.annotation.JsonIgnore;
/*import com.sgl.smartpra.batch.bsp.app.processor.TicketOrginStgProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.TicketPaymentDetailsStgProcessor;*/
/*import com.sgl.smartpra.batch.bsp.app.writer.TicketOriginStgWriter;
import com.sgl.smartpra.batch.bsp.app.writer.TicketPaymentDetailsStgWriter;*/

import java.sql.Timestamp;


/**
 * The persistent class for the ticket_payment_details_stg database table.
 * 
 */
@Entity
@Table(name="ticket_payment_details_stg")
public class TicketPaymentDetailsStg  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="trn_form_paymnt_dtl_id")
	private int trnFormPaymntDtlId;

	@Column(name="[3d_secure_card_auth_info]")
	private String _dSecureCardAuthInfo;

	@Column(name="approval_code")
	private String approvalCode;

	private String attribute1;

	private String attribute2;

	private String attribute3;

	private String attribute4;

	private String attribute5;

	@Column(name="card_authentication_info")
	private String cardAuthenticationInfo;

	@Column(name="card_authentication_seq_no")
	private String cardAuthenticationSeqNo;

	@Column(name="card_verification_value_result")
	private String cardVerificationValueResult;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="expiry_date")
	private String expiryDate;

	@Column(name="extended_payment_code")
	private String extendedPaymentCode;

	@Column(name="fm_of_payment_information")
	private String fmOfPaymentInformation;

	@Column(name="fm_of_payment_sequence_number")
	private String fmOfPaymentSequenceNumber;

	@Column(name="fm_of_payment_trans_identifier")
	private String fmOfPaymentTransIdentifier;

	@Column(name="fop_currency_type")
	private String fopCurrencyType;

	@Column(name="fop_sign")
	private String fopSign;

	@Column(name="form_of_payment_account_number")
	private String formOfPaymentAccountNumber;

	@Column(name="form_of_payment_amount")
	private String formOfPaymentAmount;

	@Column(name="form_of_payment_type")
	private String formOfPaymentType;

	@Column(name="form_of_reported_amount")
	private String formOfReportedAmount;

	@Column(name="invoice_date")
	private String invoiceDate;

	@Column(name="invoice_number")
	private String invoiceNumber;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="remittance_amount")
	private String remittanceAmount;

	@Column(name="sales_key")
	private String salesKey;

	//bi-directional many-to-one association to TicketMainStg
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="trn_tkt_id")
	private TicketMainStg ticketMainStg;

	public TicketPaymentDetailsStg() {
	}

	public int getTrnFormPaymntDtlId() {
		return this.trnFormPaymntDtlId;
	}

	public void setTrnFormPaymntDtlId(int trnFormPaymntDtlId) {
		this.trnFormPaymntDtlId = trnFormPaymntDtlId;
	}

	public String get_dSecureCardAuthInfo() {
		return this._dSecureCardAuthInfo;
	}

	public void set_dSecureCardAuthInfo(String _dSecureCardAuthInfo) {
		this._dSecureCardAuthInfo = _dSecureCardAuthInfo;
	}

	public String getApprovalCode() {
		return this.approvalCode;
	}

	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}

	public String getAttribute1() {
		return this.attribute1;
	}

	public void setAttribute1(String attribute1) {
		this.attribute1 = attribute1;
	}

	public String getAttribute2() {
		return this.attribute2;
	}

	public void setAttribute2(String attribute2) {
		this.attribute2 = attribute2;
	}

	public String getAttribute3() {
		return this.attribute3;
	}

	public void setAttribute3(String attribute3) {
		this.attribute3 = attribute3;
	}

	public String getAttribute4() {
		return this.attribute4;
	}

	public void setAttribute4(String attribute4) {
		this.attribute4 = attribute4;
	}

	public String getAttribute5() {
		return this.attribute5;
	}

	public void setAttribute5(String attribute5) {
		this.attribute5 = attribute5;
	}

	public String getCardAuthenticationInfo() {
		return this.cardAuthenticationInfo;
	}

	public void setCardAuthenticationInfo(String cardAuthenticationInfo) {
		this.cardAuthenticationInfo = cardAuthenticationInfo;
	}

	public String getCardAuthenticationSeqNo() {
		return this.cardAuthenticationSeqNo;
	}

	public void setCardAuthenticationSeqNo(String cardAuthenticationSeqNo) {
		this.cardAuthenticationSeqNo = cardAuthenticationSeqNo;
	}

	public String getCardVerificationValueResult() {
		return this.cardVerificationValueResult;
	}

	public void setCardVerificationValueResult(String cardVerificationValueResult) {
		this.cardVerificationValueResult = cardVerificationValueResult;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getExpiryDate() {
		return this.expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getExtendedPaymentCode() {
		return this.extendedPaymentCode;
	}

	public void setExtendedPaymentCode(String extendedPaymentCode) {
		this.extendedPaymentCode = extendedPaymentCode;
	}

	public String getFmOfPaymentInformation() {
		return this.fmOfPaymentInformation;
	}

	public void setFmOfPaymentInformation(String fmOfPaymentInformation) {
		this.fmOfPaymentInformation = fmOfPaymentInformation;
	}

	public String getFmOfPaymentSequenceNumber() {
		return this.fmOfPaymentSequenceNumber;
	}

	public void setFmOfPaymentSequenceNumber(String fmOfPaymentSequenceNumber) {
		this.fmOfPaymentSequenceNumber = fmOfPaymentSequenceNumber;
	}

	public String getFmOfPaymentTransIdentifier() {
		return this.fmOfPaymentTransIdentifier;
	}

	public void setFmOfPaymentTransIdentifier(String fmOfPaymentTransIdentifier) {
		this.fmOfPaymentTransIdentifier = fmOfPaymentTransIdentifier;
	}

	public String getFopCurrencyType() {
		return this.fopCurrencyType;
	}

	public void setFopCurrencyType(String fopCurrencyType) {
		this.fopCurrencyType = fopCurrencyType;
	}

	public String getFopSign() {
		return this.fopSign;
	}

	public void setFopSign(String fopSign) {
		this.fopSign = fopSign;
	}

	public String getFormOfPaymentAccountNumber() {
		return this.formOfPaymentAccountNumber;
	}

	public void setFormOfPaymentAccountNumber(String formOfPaymentAccountNumber) {
		this.formOfPaymentAccountNumber = formOfPaymentAccountNumber;
	}

	public String getFormOfPaymentAmount() {
		return this.formOfPaymentAmount;
	}

	public void setFormOfPaymentAmount(String formOfPaymentAmount) {
		this.formOfPaymentAmount = formOfPaymentAmount;
	}

	public String getFormOfPaymentType() {
		return this.formOfPaymentType;
	}

	public void setFormOfPaymentType(String formOfPaymentType) {
		this.formOfPaymentType = formOfPaymentType;
	}

	public String getFormOfReportedAmount() {
		return this.formOfReportedAmount;
	}

	public void setFormOfReportedAmount(String formOfReportedAmount) {
		this.formOfReportedAmount = formOfReportedAmount;
	}

	public String getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceNumber() {
		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getRemittanceAmount() {
		return this.remittanceAmount;
	}

	public void setRemittanceAmount(String remittanceAmount) {
		this.remittanceAmount = remittanceAmount;
	}

	public String getSalesKey() {
		return this.salesKey;
	}

	public void setSalesKey(String salesKey) {
		this.salesKey = salesKey;
	}

	public TicketMainStg getTicketMainStg() {
		return this.ticketMainStg;
	}

	public void setTicketMainStg(TicketMainStg ticketMainStg) {
		this.ticketMainStg = ticketMainStg;
	}

}