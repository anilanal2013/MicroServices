package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the cpn_tax_information_stg database table.
 * 
 */
@Entity
@Table(name="cpn_tax_information_stg")
public class CpnTaxInformationStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="cpn_tax_infomation_auto_id")
	private int cpnTaxInfomationAutoId;

	@Column(name="check_digit")
	private String checkDigit;

	@Column(name="cpn_tax_airport_code_1")
	private String cpnTaxAirportCode1;

	@Column(name="cpn_tax_airport_code_2")
	private String cpnTaxAirportCode2;

	@Column(name="cpn_tax_applicable_amount_1")
	private String cpnTaxApplicableAmount1;

	@Column(name="cpn_tax_applicable_amount_2")
	private String cpnTaxApplicableAmount2;

	@Column(name="cpn_tax_code_1")
	private String cpnTaxCode1;

	@Column(name="cpn_tax_code_2")
	private String cpnTaxCode2;

	@Column(name="cpn_tax_currency_type_1")
	private String cpnTaxCurrencyType1;

	@Column(name="cpn_tax_currency_type_2")
	private String cpnTaxCurrencyType2;

	@Column(name="cpn_tax_reported_amount_1")
	private String cpnTaxReportedAmount1;

	@Column(name="cpn_tax_reported_amount_2")
	private String cpnTaxReportedAmount2;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="currency_type")
	private String currencyType;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	private String filler;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="segment_identifier_1")
	private String segmentIdentifier1;

	@Column(name="segment_identifier_2")
	private String segmentIdentifier2;

	@Column(name="segment_tax_airport_code_1")
	private String segmentTaxAirportCode1;

	@Column(name="segment_tax_airport_code_2")
	private String segmentTaxAirportCode2;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="tkt_doc_number")
	private String tktDocNumber;

	@Column(name="transaction_number")
	private String transactionNumber;

	//bi-directional many-to-one association to TransactionHdrStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="transaction_hdr_id")
	private TransactionHdrStg transactionHdrStg;

	public CpnTaxInformationStg() {
	}

	public int getCpnTaxInfomationAutoId() {
		return this.cpnTaxInfomationAutoId;
	}

	public void setCpnTaxInfomationAutoId(int cpnTaxInfomationAutoId) {
		this.cpnTaxInfomationAutoId = cpnTaxInfomationAutoId;
	}

	public String getCheckDigit() {
		return this.checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCpnTaxAirportCode1() {
		return this.cpnTaxAirportCode1;
	}

	public void setCpnTaxAirportCode1(String cpnTaxAirportCode1) {
		this.cpnTaxAirportCode1 = cpnTaxAirportCode1;
	}

	public String getCpnTaxAirportCode2() {
		return this.cpnTaxAirportCode2;
	}

	public void setCpnTaxAirportCode2(String cpnTaxAirportCode2) {
		this.cpnTaxAirportCode2 = cpnTaxAirportCode2;
	}

	public String getCpnTaxApplicableAmount1() {
		return this.cpnTaxApplicableAmount1;
	}

	public void setCpnTaxApplicableAmount1(String cpnTaxApplicableAmount1) {
		this.cpnTaxApplicableAmount1 = cpnTaxApplicableAmount1;
	}

	public String getCpnTaxApplicableAmount2() {
		return this.cpnTaxApplicableAmount2;
	}

	public void setCpnTaxApplicableAmount2(String cpnTaxApplicableAmount2) {
		this.cpnTaxApplicableAmount2 = cpnTaxApplicableAmount2;
	}

	public String getCpnTaxCode1() {
		return this.cpnTaxCode1;
	}

	public void setCpnTaxCode1(String cpnTaxCode1) {
		this.cpnTaxCode1 = cpnTaxCode1;
	}

	public String getCpnTaxCode2() {
		return this.cpnTaxCode2;
	}

	public void setCpnTaxCode2(String cpnTaxCode2) {
		this.cpnTaxCode2 = cpnTaxCode2;
	}

	public String getCpnTaxCurrencyType1() {
		return this.cpnTaxCurrencyType1;
	}

	public void setCpnTaxCurrencyType1(String cpnTaxCurrencyType1) {
		this.cpnTaxCurrencyType1 = cpnTaxCurrencyType1;
	}

	public String getCpnTaxCurrencyType2() {
		return this.cpnTaxCurrencyType2;
	}

	public void setCpnTaxCurrencyType2(String cpnTaxCurrencyType2) {
		this.cpnTaxCurrencyType2 = cpnTaxCurrencyType2;
	}

	public String getCpnTaxReportedAmount1() {
		return this.cpnTaxReportedAmount1;
	}

	public void setCpnTaxReportedAmount1(String cpnTaxReportedAmount1) {
		this.cpnTaxReportedAmount1 = cpnTaxReportedAmount1;
	}

	public String getCpnTaxReportedAmount2() {
		return this.cpnTaxReportedAmount2;
	}

	public void setCpnTaxReportedAmount2(String cpnTaxReportedAmount2) {
		this.cpnTaxReportedAmount2 = cpnTaxReportedAmount2;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrencyType() {
		return this.currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getFiller() {
		return this.filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getSegmentIdentifier1() {
		return this.segmentIdentifier1;
	}

	public void setSegmentIdentifier1(String segmentIdentifier1) {
		this.segmentIdentifier1 = segmentIdentifier1;
	}

	public String getSegmentIdentifier2() {
		return this.segmentIdentifier2;
	}

	public void setSegmentIdentifier2(String segmentIdentifier2) {
		this.segmentIdentifier2 = segmentIdentifier2;
	}

	public String getSegmentTaxAirportCode1() {
		return this.segmentTaxAirportCode1;
	}

	public void setSegmentTaxAirportCode1(String segmentTaxAirportCode1) {
		this.segmentTaxAirportCode1 = segmentTaxAirportCode1;
	}

	public String getSegmentTaxAirportCode2() {
		return this.segmentTaxAirportCode2;
	}

	public void setSegmentTaxAirportCode2(String segmentTaxAirportCode2) {
		this.segmentTaxAirportCode2 = segmentTaxAirportCode2;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTktDocNumber() {
		return this.tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public TransactionHdrStg getTransactionHdrStg() {
		return this.transactionHdrStg;
	}

	public void setTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		this.transactionHdrStg = transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
/*	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		CouponTaxInformationStgLayout couponTaxInformationStgLayout = new CouponTaxInformationStgLayout();
		tokenizer.setColumns(couponTaxInformationStgLayout.getColumns());
		tokenizer.setNames(couponTaxInformationStgLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<BSPRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPRecord>();
		fieldSetMapper.setTargetType(CpnTaxInformationStg.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BSPRecord, ? extends BSPRecord> processor() {
		return new CouponTaxInformationStgProcessor();
	}

	@Override
	public ItemWriter<? super BSPRecord> writer() {
		return new CouponTaxInformationStgWriter();
	}
*/

}