package com.sgl.smartpra.batch.sales.validator.app.master.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sgl.smartpra.batch.sales.validator.app.config.FeignConfiguration.SmartpraGlobalMasterAppClient;
import com.sgl.smartpra.batch.sales.validator.app.master.AirportMasterClient;
import com.sgl.smartpra.global.master.model.Airport;

@Service
public class AirportMasterImpl implements AirportMasterClient {

	@Autowired
	private SmartpraGlobalMasterAppClient smartpraGlobalMasterAppClient;

	@Override
	@HystrixCommand(fallbackMethod = "getAirportByAirportCodeFallback")
	public Airport getAirportByAirportCode(String airportCode) {
		return smartpraGlobalMasterAppClient.getAirportByAirportCode(airportCode);
	}
	
	
	public Airport getAirportByAirportCodeFallback(String airportCode) {
		System.out.println("Inside Fallback");
		return new Airport();
	}
	

	
	
	@Override
	public List<Airport> getAllAirport(String airportCode,String airportName, String cityCode,String cityName,String countryCode){
	return	smartpraGlobalMasterAppClient.getAllAirport(airportCode, airportName, cityCode, cityName, countryCode);

		
	}


}