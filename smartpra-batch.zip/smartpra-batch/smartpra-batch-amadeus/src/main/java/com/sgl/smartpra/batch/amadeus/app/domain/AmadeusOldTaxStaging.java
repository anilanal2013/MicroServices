package com.sgl.smartpra.batch.amadeus.app.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

/**
 * The persistent class for the amadeus_old_tax_stg database table.
 * 
 */
@Entity
@Table(name = "amadeus_old_tax_stg")
@NamedQuery(name = "AmadeusOldTaxStaging.findAll", query = "SELECT a FROM AmadeusOldTaxStaging a")
public class AmadeusOldTaxStaging extends AmadeusBatchRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ame_old_tax_dtl_id")
	private int ameOldTaxDtlId;

	@Column(name = "tax_code")
	private String taxCode;

	@Column(name = "tax_value")
	private String taxValue;

	// bi-directional many-to-one association to AmadeusRecordStg
	@ManyToOne
	@JoinColumn(name = "amadeus_load_id")
	private AmadeusRecordStaging amadeusRecordStg;

	public AmadeusOldTaxStaging() {
	}

	public int getAmeOldTaxDtlId() {
		return this.ameOldTaxDtlId;
	}

	public void setAmeOldTaxDtlId(int ameOldTaxDtlId) {
		this.ameOldTaxDtlId = ameOldTaxDtlId;
	}

	public String getTaxCode() {
		return this.taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public String getTaxValue() {
		return this.taxValue;
	}

	public void setTaxValue(String taxValue) {
		this.taxValue = taxValue;
	}

	public AmadeusRecordStaging getAmadeusRecordStg() {
		return this.amadeusRecordStg;
	}

	public void setAmadeusRecordStg(AmadeusRecordStaging amadeusRecordStg) {
		this.amadeusRecordStg = amadeusRecordStg;
	}

	@Override
	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FieldSetMapper<AmadeusBatchRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> processor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemWriter<? super AmadeusBatchRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}
}