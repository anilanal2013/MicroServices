package com.sgl.smartpra.batch.amadeus.app.processor;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.ExceptionTxnFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.FlownFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdCouponModel;
import com.sgl.smartpra.batch.amadeus.app.domain.RequestFileDetail;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.batch.amadeus.app.repository.RequestFileDetailRepository;
import com.sgl.smartpra.batch.amadeus.app.utils.AmadeusCommonUtils;
import com.sgl.smartpra.common.util.ExceptionCodeConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.domain.FlownEsac;
import com.sgl.smartpra.flown.model.FlightDataDetails;
import com.sgl.smartpra.flown.repository.BsaCouponDetailRepository;
import com.sgl.smartpra.flown.repository.FlownEsacRepository;
import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.master.model.SystemParameter;

@SuppressWarnings("serial")
public class ProdETLCouponProcessor extends AmadeusProcessor
implements ItemProcessor<AmadeusRecordStaging, ProdCouponModel> {

	@Autowired 
	private ETLCouponProcessor etlCouponProcessor;

	@Autowired
	private BsaCouponDetailRepository bsaCouponDetailRepository;

	@Autowired
	private FlownEsacRepository flownEsacRepository;

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private RequestFileDetailRepository requestFileDetailRepository;

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	FlownFeignClient flownFeignClient;

	@Autowired
	private ExceptionTxnFeignClient exceptionTxnFeignClient;

	@Value("#{jobParameters['carrieNumericCode']}")
	public Integer hostCarrNumericCode;

	@Value("#{jobParameters['careerDesignatorCode']}")
	public String hostCarrDesigCode;

	@Value("#{jobParameters['validDtReqOut']}")
	public String validDtReqOut;

	@Value("#{jobParameters['flightNoLen']}")
	public String sysParamFlightLen;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProdETLCouponProcessor.class);

	@Override
	public ProdCouponModel process(AmadeusRecordStaging amadeusRecordStaging) throws Exception {
		
		
		return etlCouponProcessor.process(amadeusRecordStaging);
		
		
		/*

		LOGGER.info("ProdETLCouponProcessor.process -- Start");

		ProdCouponModel prodCouponModel = new ProdCouponModel();
		SimpleDateFormat format = new SimpleDateFormat("ddMMyy");
		SimpleDateFormat allianceDate = new SimpleDateFormat("yyyy-MM-dd");
		ExceptionTransactionModel exceptionTransactionModel;
		List<ExceptionParametersValueModel> parametersValueModelList;
		ExceptionParametersValueModel paramValueModel;
		String numberOfCoupon = null;
		List<CarrierAlliance> carrierAllianceList = null;
		List<SystemParameter> systemParameterList = null;
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("ddMMyy");

		// Unique columns for all ticket / coupon tables
		String issueAirline = amadeusRecordStaging.getIssAirline();
		String documentNo = amadeusRecordStaging.getDocumentNumber();
		String mainDocumentNo = amadeusRecordStaging.getUsageDocNumber().substring(0, 10);
		String documentUniqueId = hostCarrDesigCode + issueAirline + documentNo + amadeusRecordStaging.getIssueDate();
		Integer couponNumber = Integer.parseInt(amadeusRecordStaging.getCouponNumber());
		BigInteger ticketNumber = new BigInteger(documentNo);
		String requestAirlineCode = String.valueOf(hostCarrNumericCode);

		 * List<BookingClassModel> bookingClassModelList = masterFeignClient
		 * .getListOfBookingClassByUtilizationEffectiveDate(null,
		 * amadeusRecordStaging.getSellingClass(), null, null, null, null ,null); if
		 * (bookingClassModelList.isEmpty()) { // Exception logic - start
		 * exceptionTransactionModel =
		 * AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
		 * documentUniqueId); exceptionTransactionModel.setClientId(hostCarrDesigCode);
		 * exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.
		 * ERRORCODE_DOCCLASS); exceptionTransactionModel.
		 * setResolutionRemarks("Cabin details need to be added in Booking Class Master"
		 * ); exceptionTransactionModel.
		 * setExceptionDetails("BookingClass details not found for rbd : " +
		 * amadeusRecordStaging.getSellingClass());
		 * if(amadeusRecordStaging.getCouponNumber() != null)
		 * exceptionTransactionModel.setCouponNumber(Integer.parseInt(
		 * amadeusRecordStaging.getCouponNumber())); parametersValueModelList = new
		 * ArrayList<ExceptionParametersValueModel>();
		 * 
		 * paramValueModel = new ExceptionParametersValueModel();
		 * paramValueModel.setParameterName("Document No.");
		 * paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
		 * parametersValueModelList.add(paramValueModel);
		 * 
		 * paramValueModel = new ExceptionParametersValueModel();
		 * paramValueModel.setParameterName("Carrier Numeric Code");
		 * paramValueModel.setParameterValue(issueAirline);
		 * parametersValueModelList.add(paramValueModel);
		 * 
		 * paramValueModel = new ExceptionParametersValueModel();
		 * paramValueModel.setParameterName("Doc Class");
		 * paramValueModel.setParameterValue(amadeusRecordStaging.getSellingClass());
		 * parametersValueModelList.add(paramValueModel);
		 * 
		 * exceptionTransactionModel.setParametersValueList(parametersValueModelList);
		 * 
		 * exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel) ;
		 * // Exception logic - end
		 * amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
		 * amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging); return
		 * null; }

		try {
			String etlFlightDate = amadeusRecordStaging.getUsageLocalFlightDate();
			LocalDate localDate = LocalDate.parse(etlFlightDate, dtFormatter);

			List<FormCode> formcodeList = masterFeignClient.getAllFormCode(
					amadeusRecordStaging.getDocumentNumber().substring(0, 3), null, numberOfCoupon, null, null);
			if (formcodeList.isEmpty()) {
				// Exception logic - start
				exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
						documentUniqueId);
				exceptionTransactionModel.setClientId(hostCarrDesigCode);
				exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_DOCTYPE);

		 * exceptionTransactionModel.
		 * setResolutionRemarks("Form code details need to be added in formcode master"
		 * ); exceptionTransactionModel.
		 * setExceptionDetails("Formcode details not found for formCode : " +
		 * amadeusRecordStaging.getDocumentNumber().substring(0, 3));

				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Document No.");
				paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
				parametersValueModelList.add(paramValueModel);
				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Carrier Numeric Code");
				paramValueModel.setParameterValue(issueAirline);
				parametersValueModelList.add(paramValueModel);
				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Doc Type");
				paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber().substring(0, 3));
				parametersValueModelList.add(paramValueModel);
				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
				// Exception logic - end
				amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
				amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				return null;
			}
			String derivedFlightNo = SmartPRACommonUtil
					.deriveFlightNo(amadeusRecordStaging.getUsageOperatingFlightNumber(), sysParamFlightLen);

		 * List<FlightDataDetails> flightKeyList =
		 * flownFeignClient.getAllFlightDataDetails(derivedFlightNo,
		 * amadeusRecordStaging.getUsageOriginCode(),
		 * amadeusRecordStaging.getUsageDestinationCode(), null);

			FlightDataDetails flightDataDetails = flownFeignClient.getFlightDataDetails(derivedFlightNo,
					amadeusRecordStaging.getUsageOriginCode(), amadeusRecordStaging.getUsageDestinationCode(),
					localDate, null);
			LOGGER.info("Derived Operating flight number--------" + derivedFlightNo);

			if (flightDataDetails == null || flightDataDetails.equals("")) {
				LOGGER.info("flightDataDetails is empty....");
				LOGGER.info("Actual Operating flight number" + amadeusRecordStaging.getUsageOperatingFlightNumber());
				LOGGER.info("Derived Operating flight number" + derivedFlightNo);

				// Exception logic - start
				exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
						documentUniqueId);
				exceptionTransactionModel.setClientId(hostCarrDesigCode);
				exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_FLIGHTKEYNOTFOUND);

		 * exceptionTransactionModel.
		 * setResolutionRemarks("Flight data details need to be updated..");
		 * exceptionTransactionModel.
		 * setExceptionDetails("Flight data details not found for flight number : " +
		 * derivedFlightNo + ", usage orgincode: " +
		 * amadeusRecordStaging.getUsageOriginCode() + ", usage desgination code: " +
		 * amadeusRecordStaging.getUsageDestinationCode());

				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Document No");
				paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
				parametersValueModelList.add(paramValueModel);

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Coupon No.");
				paramValueModel.setParameterValue("");
				parametersValueModelList.add(paramValueModel);

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Line No.");
				paramValueModel.setParameterValue(derivedFlightNo);
				parametersValueModelList.add(paramValueModel);

				exceptionTransactionModel.setParametersValueList(parametersValueModelList);

				exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
				// Exception logic - end

				amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
				amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				return null;
			}

			// Duplicate record check
			Optional<FlownEsac> flownEsacOpt = flownEsacRepository
					.findByDocumentUniqueIdandCouponNumber(documentUniqueId, couponNumber);

			if (flownEsacOpt.isPresent()) {
				LOGGER.debug("DocumentUniqueId " + documentUniqueId + "couponNumber" + couponNumber
						+ " already exists in ticketMain table for file_id " + flownEsacOpt.get().getFileId());
				LOGGER.info("DocumentUniqueId " + documentUniqueId + "couponNumber" + couponNumber
						+ " already exists in ticketMain table for file_id " + flownEsacOpt.get().getFileId());
				// Log record level errors
				return null;
			} else {
				if (amadeusRecordStaging.getUsageType() != null
						&& amadeusRecordStaging.getUsageType().equals(AppConstants.FLOWN_COUPON_F)
						&& Integer.parseInt(amadeusRecordStaging.getUsageAirline()) == hostCarrNumericCode) {
					LOGGER.info("Flown Reported in File:{}",
							amadeusRecordStaging.getUsageType() + amadeusRecordStaging.getUsageAirline());

		 * BsaCouponDetail bsaCouponDetail = new BsaCouponDetail();
		 * LOGGER.info("Object : {}", amadeusRecordStaging);
		 * bsaCouponDetail.setDocumentUniqueId(documentUniqueId);
		 * bsaCouponDetail.setIssueAirline(issueAirline);
		 * bsaCouponDetail.setDocumentNumber(documentNo);
		 * bsaCouponDetail.setMainDocument(mainDocumentNo);
		 * bsaCouponDetail.setCouponNumber(Integer.parseInt(amadeusRecordStaging.
		 * getCouponNumber()));
		 * bsaCouponDetail.setDestination(amadeusRecordStaging.getUsageDestinationCode()
		 * ); bsaCouponDetail.setOrigin(amadeusRecordStaging.getUsageOriginCode());
		 * bsaCouponDetail.setFileId(amadeusRecordStaging.getFileId());
		 * bsaCouponDetail.setMarketingCarrierDesignator(amadeusRecordStaging.
		 * getUsageMarketingCarrierCode());
		 * bsaCouponDetail.setMarketingCarrierNumCode(amadeusRecordStaging.getIssAirline
		 * ());
		 * bsaCouponDetail.setMarketingFlightDate(format.parse(amadeusRecordStaging.
		 * getSoldLocalDepartDate()));
		 * bsaCouponDetail.setMarketingFlightNumber(derivedFlightNo);
		 * bsaCouponDetail.setOperatingFlightDate(format.parse(amadeusRecordStaging.
		 * getUsageLocalFlightDate()));
		 * bsaCouponDetail.setOperatingFlightNumber(derivedFlightNo);
		 * bsaCouponDetail.setCreatedBy(amadeusRecordStaging.getCreatedBy());
		 * bsaCouponDetail.setCreatedDate(new Timestamp(new Date().getTime()));
		 * bsaCouponDetail.setClientId(hostCarrDesigCode);
		 * bsaCouponDetail.setOperatingCarrierDesignator(amadeusRecordStaging.
		 * getUsageMarketingCarrierCode());
		 * bsaCouponDetail.setOperatingCarrierNumCode(amadeusRecordStaging.getIssAirline
		 * ()); prodCouponModel.setBsaCouponDetail(bsaCouponDetail);


					FlownCoupon flownCoupon = new FlownCoupon();
					LOGGER.info("FlightData:{}",
							amadeusRecordStaging.getFlightNumber() + amadeusRecordStaging.getUsageOriginCode()
									+ amadeusRecordStaging.getUsageDestinationCode());
					flownCoupon.setDocumentUniqueId(documentUniqueId);
					flownCoupon.setIssueAirline(issueAirline);
					flownCoupon.setDocumentNumber(documentNo);
					flownCoupon.setMainDocument(mainDocumentNo);
					flownCoupon.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
					flownCoupon.setFlightDate(format.parse(amadeusRecordStaging.getUsageLocalFlightDate()));
					flownCoupon.setFlightNumber(derivedFlightNo);
					flownCoupon.setFromAirport(amadeusRecordStaging.getUsageOriginCode());
					flownCoupon.setToAirport(amadeusRecordStaging.getUsageDestinationCode());
					flownCoupon.setReportedFlownCabin(amadeusRecordStaging.getUsedCabinClass());
					flownCoupon.setETktIndicator(AppConstants.ETICKET_INDICATOR_DEFAULT);
					String couponType = AppConstants.FLOWN_COUPON_U;

					if (formcodeList != null && !formcodeList.isEmpty()) {
						flownCoupon.setDocumentType(OptionalUtil.getValue(formcodeList.get(0).getDocumentType()));
						LOGGER.info("FORMCODE LIST:{}" + formcodeList.get(0).getDocumentType());
					}
					if (formcodeList.get(0).getNumberOfCoupon().get() != "0") {
						flownCoupon.setDocumentClass(formcodeList.get(0).getDocumentType().get().substring(0, 2)
								+ formcodeList.get(0).getNumberOfCoupon().get());
					} else {
						flownCoupon.setDocumentClass(formcodeList.get(0).getDocumentType().get().substring(0, 2));
					}

					flownCoupon.setPassengerName(amadeusRecordStaging.getPassengerName());
					flownCoupon.setPnr(amadeusRecordStaging.getBookingReference());
					flownCoupon.setCreatedBy(amadeusRecordStaging.getCreatedBy());
					flownCoupon.setCreatedDate(new Timestamp(new Date().getTime()));
					flownCoupon.setClientId(hostCarrDesigCode);

					// Alliance Coupon(Request data Population) Logic
					DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
					if (!issueAirline.equals(hostCarrNumericCode)) {
						LOGGER.info("Alliance Coupon Available------" + issueAirline);
						LOGGER.info("Enterning Alliance Coupon Logic");
						if (validDtReqOut.equals(AppConstants.FLAG_Y)) {

							LOGGER.info("Hosting Carrier Migrated");
							String flightDate = dateFormat.format(flownCoupon.getFlightDate());
							carrierAllianceList = masterFeignClient.search(issueAirline, flightDate);
							LOGGER.info("carrierAllianceList--------->" + carrierAllianceList.size());
							if (carrierAllianceList != null && carrierAllianceList.size() > 0
									&& flownCoupon.getDocumentType().equals(AppConstants.DOCUMENT_TYPE_PAX)
									&& carrierAllianceList.get(0).getAllianceName().get()
											.equals(AppConstants.ALLIANCE_NAME_OWC)) {
								LOGGER.info("Duplicate Records Checking in Request Reository");
								Optional<RequestFileDetail> requestFileDetailOpt = requestFileDetailRepository
										.findDuplicateRecord(ticketNumber, couponNumber, requestAirlineCode,
												issueAirline, couponType);

								if (requestFileDetailOpt.isPresent()) {
									LOGGER.info("Already Data Migrated without  File Id in Request repository");

									// Exception logic - start
									exceptionTransactionModel = AmadeusCommonUtils
											.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueId);
									exceptionTransactionModel.setClientId(hostCarrDesigCode);
									exceptionTransactionModel
											.setExceptionCode(ExceptionCodeConstants.ERRORCODE_REQUEST_DATA_PRESENT);
									parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

									paramValueModel = new ExceptionParametersValueModel();
									paramValueModel.setParameterName("Carrier Numeric Code");
									paramValueModel.setParameterValue(String.valueOf(hostCarrNumericCode));
									parametersValueModelList.add(paramValueModel);

									paramValueModel = new ExceptionParametersValueModel();
									paramValueModel.setParameterName("Document No.");
									paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
									parametersValueModelList.add(paramValueModel);

									paramValueModel = new ExceptionParametersValueModel();
									paramValueModel.setParameterName("Coupon No.");
									paramValueModel.setParameterValue(String.valueOf(flownCoupon.getCouponNumber()));
									parametersValueModelList.add(paramValueModel);

									exceptionTransactionModel.setParametersValueList(parametersValueModelList);

									LOGGER.info("Exception Transaction Model------->" + exceptionTransactionModel.toString());

									exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
									// Exception logic - end

								} else {

									LOGGER.info(" Alliance Request data population starts------");
									RequestFileDetail requestFileDetail = new RequestFileDetail();
									requestFileDetail.setRequestAirLineCode(String.valueOf(hostCarrNumericCode));
									requestFileDetail.setResponseAirLineCode(issueAirline);
									requestFileDetail.setCouponNumber(flownCoupon.getCouponNumber());
									requestFileDetail.setTicketNumber(
											new BigInteger(String.valueOf(flownCoupon.getDocumentNumber())));
									requestFileDetail.setCouponNumber(flownCoupon.getCouponNumber());
									requestFileDetail.setCouponType(AppConstants.COUPON_TYPE);
									requestFileDetail.setRequestDate(new Date());
									requestFileDetail.setRequestType(AppConstants.REQUEST_TYPE_OUT);
									requestFileDetail.setTicketIssuingAirLineCode(String.valueOf(hostCarrNumericCode));
									requestFileDetail.setMultiCouponId(AppConstants.MULTI_COUPON_ID);
									requestFileDetail.setProcessRequiredFlag(AppConstants.PROCESSED_REQUEST_FLAG);
									requestFileDetail.setDataSource(AppConstants.DATA_SOURCE_AUTOMATED);
									requestFileDetail.setCreatedBy(flownCoupon.getCreatedBy());
									requestFileDetail.setCreatedDate(flownCoupon.getCreatedDate());
									requestFileDetailRepository.save(requestFileDetail);
									LOGGER.info("Request Data  population  Ends-------");

								}

							}
						}
					}

					flownCoupon.setDataSource(amadeusRecordStaging.getFileSource());
					if (flightDataDetails != null && !flightDataDetails.equals("")) {
						flownCoupon.setFlightKey((long) flightDataDetails.getFlightKey());
					}

					flownCoupon.setFileId(amadeusRecordStaging.getFileId());
					flownCoupon.setMultiUpliftFlag(AppConstants.MULTI_UPLIFT_FLAG);
					flownCoupon.setCouponStatus(AppConstants.COUPON_STATUS);
					prodCouponModel.setFlownCoupon(flownCoupon);

				}

				FlownEsac flownEsac = new FlownEsac();
				flownEsac.setDocumentUniqueId(documentUniqueId);
				flownEsac.setIssueAirline(issueAirline);
				flownEsac.setDocumentNumber(documentNo);
				flownEsac.setMainDocument(mainDocumentNo);
				flownEsac.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
				flownEsac.setOperatingCarrierNumCode(amadeusRecordStaging.getUsageAirline().substring(1, 4));
				flownEsac.setEsacCode(amadeusRecordStaging.getSettlementAuthorizationCode());
				flownEsac.setUtilizationType(amadeusRecordStaging.getUsageType());
				flownEsac.setFileId(amadeusRecordStaging.getFileId());
				flownEsac.setDataSource(amadeusRecordStaging.getFileSource());
				flownEsac.setCreatedBy(amadeusRecordStaging.getCreatedBy());
				flownEsac.setCreatedDate(new Timestamp(new Date().getTime()));
				flownEsac.setClientId(hostCarrDesigCode);
				prodCouponModel.setFlownEsac(flownEsac);
				// amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_TRANSFERRED);
				amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				LOGGER.info("ProdETLCouponProcessor.process -- End");
				return prodCouponModel;
			}
		} catch (Exception e) {
			LOGGER.error("Exception Thrown for the amadeus Load Id: " + amadeusRecordStaging.getAmadeusLoadId());
			LOGGER.error("Exception" + e);
			exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
					documentUniqueId);
			exceptionTransactionModel.setClientId(hostCarrDesigCode);
			exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.GENERAL_EXCEPTION);

			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			paramValueModel = new ExceptionParametersValueModel();
			paramValueModel.setParameterName("Reference ID");
			paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
			parametersValueModelList.add(paramValueModel);
			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
			// Exception logic - end
			amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
			amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
			return null;
		}
		 */}
}