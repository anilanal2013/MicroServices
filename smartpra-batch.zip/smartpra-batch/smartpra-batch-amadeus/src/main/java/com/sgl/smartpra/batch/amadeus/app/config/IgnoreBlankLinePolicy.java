package com.sgl.smartpra.batch.amadeus.app.config;

import java.util.List;

import org.springframework.batch.item.file.separator.SimpleRecordSeparatorPolicy;

public class IgnoreBlankLinePolicy extends SimpleRecordSeparatorPolicy {

	private List<String> lines;

	public IgnoreBlankLinePolicy(List<String> linesList) {
		if(lines==null) lines = linesList;
	}

	@Override
	public boolean isEndOfRecord(final String line) {
		lines.add(line);
		return line.trim().length() != 0 && super.isEndOfRecord(line);
	}

	@Override
	public String postProcess(final String record) {
		//Check empty lines in between data
		if(record.trim().length()>0) {
			for(String str:lines) {
				if(str==null || str.length()==0) { 
					return super.postProcess("File having empty lines between data lines");
				}
			}
		}
		if (record == null || record.trim().length() == 0) {
			return null;
		}
		return super.postProcess(record);
	}
}
