package com.sgl.smartpra.batch.amadeus.app.domain;

import java.io.Serializable;
import java.util.List;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.amadeus.app.layout.StagingSaberEmdHeader_Layout;
import com.sgl.smartpra.batch.amadeus.app.processor.ProdEMDTicketProcessor;
import com.sgl.smartpra.batch.amadeus.app.processor.ProdETLTicketProcessor;
import com.sgl.smartpra.batch.amadeus.app.writer.ProdTicketDataWriter;
import com.sgl.smartpra.sales.domain.TicketMain;

public class SaberEmdFlightHeader extends AmadeusBatchRecord implements Serializable {

	private String recordType;
	private String flightNumber;
	private String usageEmdDate;
	private String usageOriginCodeEmd;
	private String filler;

	public SaberEmdFlightHeader() {

	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getUsageEmdDate() {
		return usageEmdDate;
	}

	public void setUsageEmdDate(String usageEmdDate) {
		this.usageEmdDate = usageEmdDate;
	}

	public String getUsageOriginCodeEmd() {
		return usageOriginCodeEmd;
	}

	public void setUsageOriginCodeEmd(String usageOriginCodeEmd) {
		this.usageOriginCodeEmd = usageOriginCodeEmd;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		StagingSaberEmdHeader_Layout stagingSaberEmdHeader_Layout = new StagingSaberEmdHeader_Layout();
		tokenizer.setColumns(stagingSaberEmdHeader_Layout.getColumns());
		tokenizer.setNames(stagingSaberEmdHeader_Layout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<AmadeusBatchRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<AmadeusBatchRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<AmadeusBatchRecord>();
		fieldSetMapper.setTargetType(SaberEmdFlightHeader.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> processor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemWriter<? super AmadeusBatchRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toString() {
		return "SaberEmdFlightHeader [recordType=" + recordType + ", flightNumber=" + flightNumber + ", usageEmdDate="
				+ usageEmdDate + ", usageOriginCodeEmd=" + usageOriginCodeEmd + ", filler=" + filler + "]";
	}

}
