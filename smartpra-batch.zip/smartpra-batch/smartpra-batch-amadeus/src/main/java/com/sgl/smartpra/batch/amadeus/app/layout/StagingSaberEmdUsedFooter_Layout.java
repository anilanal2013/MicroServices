package com.sgl.smartpra.batch.amadeus.app.layout;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

import java.util.ArrayList;

public class StagingSaberEmdUsedFooter_Layout extends FixedLengthRecordLayout{

    public StagingSaberEmdUsedFooter_Layout(){
    	
    	 fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType",1,1));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightNumber",2,5));
         //fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("createddate",6,13));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",14,null));

         
         
         
       
    }
}
