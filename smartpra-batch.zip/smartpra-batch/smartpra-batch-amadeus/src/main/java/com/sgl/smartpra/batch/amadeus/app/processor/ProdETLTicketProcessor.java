package com.sgl.smartpra.batch.amadeus.app.processor;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.common.constant.SmartPRAConstant;

@SuppressWarnings("serial")
public class ProdETLTicketProcessor extends AmadeusProcessor
implements ItemProcessor<AmadeusRecordStaging, ProdTicketModel> {

	@Autowired
	ETLTicketProcessor etlTicketProcessor;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Override
	public ProdTicketModel process(AmadeusRecordStaging amadeusRecordStaging) throws Exception {
		ExecutionContext stepContext = this.stepExecution.getExecutionContext();
		stepContext.put("fileId", amadeusRecordStaging.getFileId());
		return etlTicketProcessor.process(SmartPRAConstant.CLIENT_ID, amadeusRecordStaging);
	}		
}
