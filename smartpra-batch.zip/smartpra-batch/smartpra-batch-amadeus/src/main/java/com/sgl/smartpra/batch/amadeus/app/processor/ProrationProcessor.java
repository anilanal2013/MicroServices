package com.sgl.smartpra.batch.amadeus.app.processor;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.SmartpraProrationFeignClient;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@SuppressWarnings("serial")
public class ProrationProcessor extends FlownCoupon
implements ItemProcessor<FlownCoupon, FlownCoupon> {

	@Autowired
	SmartpraProrationFeignClient smartpraProrationFeignClient;

	@Autowired
	TicketMainRepository ticketMainRepository;

	@Value("#{jobParameters['carrieNumericCode']}")
	public String hostCarrierNumCode;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProrationProcessor.class);

	@Override
	public FlownCoupon process(FlownCoupon coupon) throws Exception {
		LOGGER.info("########################################## process - start");
		LOGGER.info("########################################## process - coupon.getDocumentUniqueId() : " + coupon.getDocumentUniqueId());
		if("VV".equals(coupon.getCouponStatus())){
			Optional<TicketMain> ticketMainOpt = ticketMainRepository.findByDocumentUniqueId(coupon.getDocumentUniqueId());
			LOGGER.info("########################################## process - ticketMainOpt is null ? " + ticketMainOpt.isPresent());
			if (ticketMainOpt.isPresent()) {
				LOGGER.info("########################################## ticketMainOpt is present");
				LOGGER.info("########################################## coupon.getIssueAirline() : " + coupon.getIssueAirline());
				LOGGER.info("########################################## hostCarrierNumCode : " + hostCarrierNumCode);
				TicketMain	ticketMain = ticketMainOpt.get();
				if(coupon.getIssueAirline().equals(hostCarrierNumCode)) {
					LOGGER.info("########################################## Self proration process");
					LOGGER.info("########################################## ticketMain.getStatus() : " + ticketMain.getStatus());
					if(ticketMain.getStatus().equals("CC")) {
						LOGGER.info("########################################## coupon status CC");
						coupon.setCouponStatus("CC");
					} else {
						LOGGER.info("################# Proration Self (Document Level) Start : "+coupon.getMainDocument());
						smartpraProrationFeignClient.prorateCoupon(coupon.getMainDocument());
						LOGGER.info("################# Proration Self (Document Level)  End");
					}
					// Flown SELF document end                  
				} else  {
					LOGGER.info("########################################## OAL proration process");
					// Flown OAL document start
					String couponUtilizationList = null;
					couponUtilizationList = coupon.getDocumentNumber()+"@"+coupon.getCouponNumber();
					LOGGER.info("################# Proration OAL (Coupon Level)  Start "+couponUtilizationList);
					smartpraProrationFeignClient.prorateFlownDocument(coupon.getMainDocument(), couponUtilizationList, coupon.getFlightDate(), coupon.getDataSource());
					LOGGER.info("################# Proration OAL (Coupon Level) End");
					// Flown OAL document end  
				}
			}
		}
		LOGGER.info("########################################## process - end");		
		return coupon;
	}
}