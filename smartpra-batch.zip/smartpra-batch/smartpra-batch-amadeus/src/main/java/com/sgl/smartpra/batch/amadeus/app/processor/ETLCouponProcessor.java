package com.sgl.smartpra.batch.amadeus.app.processor;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.AmadeusRecCounts;
import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.ExceptionTxnFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.FlownFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdCouponModel;
import com.sgl.smartpra.batch.amadeus.app.domain.RequestFileDetail;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.batch.amadeus.app.repository.RequestFileDetailRepository;
import com.sgl.smartpra.batch.amadeus.app.utils.AmadeusCommonUtils;
import com.sgl.smartpra.common.util.ExceptionCodeConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.domain.FlownEsac;
import com.sgl.smartpra.flown.model.FlightDataDetails;
import com.sgl.smartpra.flown.repository.FlownEsacRepository;
import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.master.model.SystemParameter;

@Component
@Scope(value = "step")
public class ETLCouponProcessor {

	@Autowired
	private FlownEsacRepository flownEsacRepository;

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private RequestFileDetailRepository requestFileDetailRepository;

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	FlownFeignClient flownFeignClient;

	@Autowired
	private ExceptionTxnFeignClient exceptionTxnFeignClient;

	public Integer hostCarrNumericCode = 157;

	public String hostCarrDesigCode = "QR";

	public String hostCarrDesigCodeForSabre = "WY";

	public String validDtReqOut = "Y";

	public String sysParamFlightLen = "4";

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Value("#{jobParameters['flightCreationFromFlown']}")
	public String flightCreationFromFlownForSabre;

	@Value("#{jobParameters['flightCreationFromFlown']}")
	public String flightCreationFromFlownForAmadeus;

	@Value("#{jobParameters[amadeusVersion]}")
	String amadeusVersion;

	private static final Logger LOGGER = LoggerFactory.getLogger(ETLCouponProcessor.class);

	public ProdCouponModel process(AmadeusRecordStaging amadeusRecordStaging) throws Exception {

		LOGGER.info("ETLCouponProcessor.process -- Start");
		ProdCouponModel prodCouponModel = new ProdCouponModel();
		ExecutionContext stepContext = this.stepExecution.getExecutionContext();
		SimpleDateFormat format = new SimpleDateFormat("ddMMyy");
		SimpleDateFormat allianceDate = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format1 = new SimpleDateFormat("MMddyyyy");
		ExceptionTransactionModel exceptionTransactionModel;
		List<ExceptionParametersValueModel> parametersValueModelList;
		ExceptionParametersValueModel paramValueModel;
		String numberOfCoupon = null;
		List<CarrierAlliance> carrierAllianceList = null;
		List<SystemParameter> systemParameterList = null;
		FlightDataDetails flightDataDetails = null;
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("ddMMyy");
		DateTimeFormatter dtFormatterForSaber = DateTimeFormatter.ofPattern("MMddyyyy");
		DateTimeFormatter dtFormatterForSaberRecord = DateTimeFormatter.ofPattern("ddMMyyyy");
		// Unique columns for all ticket / coupon tables
		String issueAirline = amadeusRecordStaging.getIssAirline();
		String documentNo = amadeusRecordStaging.getDocumentNumber();
		// String mainDocumentNo = amadeusRecordStaging.getUsageDocNumber().substring(0,
		// 10);
		String documentUniqueId = hostCarrDesigCode + issueAirline + documentNo + amadeusRecordStaging.getIssueDate();
		Integer couponNumber = Integer.parseInt(amadeusRecordStaging.getCouponNumber());
		BigInteger ticketNumber = new BigInteger(documentNo);
		String requestAirlineCode = String.valueOf(hostCarrNumericCode);
		LOGGER.info("ETLCouponProcessor.process -- Start");
		try {
			String etlFlightDate = amadeusRecordStaging.getUsageLocalFlightDate();
			// LocalDate localDate = LocalDate.parse(etlFlightDate, dtFormatter);

			List<FormCode> formcodeList = masterFeignClient.getAllFormCode(
					amadeusRecordStaging.getDocumentNumber().substring(0, 3), null, numberOfCoupon, null, null);
			if (formcodeList.isEmpty()) {
				// Exception logic - start
				exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
						documentUniqueId);
				exceptionTransactionModel.setClientId(hostCarrDesigCode);
				exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_DOCTYPE);
				/*
				 * exceptionTransactionModel.
				 * setResolutionRemarks("Form code details need to be added in formcode master"
				 * ); exceptionTransactionModel.
				 * setExceptionDetails("Formcode details not found for formCode : " +
				 * amadeusRecordStaging.getDocumentNumber().substring(0, 3));
				 */
				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Issue Airline");
				paramValueModel.setParameterValue(issueAirline);
				parametersValueModelList.add(paramValueModel);

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Document Number");
				paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
				parametersValueModelList.add(paramValueModel);

				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
				// Exception logic - end
				amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
				// amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				AmadeusRecCounts.incErrorCount();
				return null;
			}
			String derivedFlightNo = SmartPRACommonUtil
					.deriveFlightNo(amadeusRecordStaging.getUsageOperatingFlightNumber(), sysParamFlightLen);

			if (getValidDateFormat(AppConstants.DD_MM_YY_FORMAT, etlFlightDate)
					|| (getValidDateFormat(AppConstants.MM_DD_YYYY_FORMAT,
							amadeusRecordStaging.getUsageLocalFlightDate())
							|| (getValidDateFormat(AppConstants.DD_MM_YYYY_FORMAT,
									amadeusRecordStaging.getUsageLocalFlightDate()))))

			{
				LocalDate localDate = null;

				LOGGER.info("Flight Date from file ---------->" + amadeusRecordStaging.getUsageLocalFlightDate());

				if (getValidDateFormat(AppConstants.DD_MM_YY_FORMAT, etlFlightDate)) {
					localDate = LocalDate.parse(etlFlightDate, dtFormatter);
					LOGGER.info("Inside ddmmyy Format" + localDate);
				} else if (getValidDateFormat(AppConstants.MM_DD_YYYY_FORMAT, etlFlightDate)) {

					localDate = LocalDate.parse(etlFlightDate, dtFormatterForSaber);
					LOGGER.info("Inside mmddyyyy Format" + localDate);
				} else if (getValidDateFormat(AppConstants.DD_MM_YYYY_FORMAT, etlFlightDate)) {

					localDate = LocalDate.parse(etlFlightDate, dtFormatterForSaberRecord);
					LOGGER.info("Inside ddmmyyyy Format" + localDate);
				} else {
					LOGGER.info("Not Able to create Flight due to Wrong Date Format ");
					LOGGER.info(
							"Actual Operating flight number" + amadeusRecordStaging.getUsageOperatingFlightNumber());
					LOGGER.info("Derived Operating flight number" + derivedFlightNo);

					// Exception logic - start exceptionTransactionModel =
					exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
							documentUniqueId);
					exceptionTransactionModel.setClientId(hostCarrDesigCode);
					exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_FLIGHTNOTFOUND);
					parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("Flight Number");
					paramValueModel.setParameterValue(derivedFlightNo);
					parametersValueModelList.add(paramValueModel);

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("From sector");
					paramValueModel.setParameterValue(amadeusRecordStaging.getUsageOriginCode());
					parametersValueModelList.add(paramValueModel);

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("To sector");
					paramValueModel.setParameterValue(amadeusRecordStaging.getUsageDestinationCode());
					parametersValueModelList.add(paramValueModel);

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("Depart date");
					paramValueModel.setParameterValue(amadeusRecordStaging.getUsageLocalFlightDate());
					parametersValueModelList.add(paramValueModel);

					exceptionTransactionModel.setParametersValueList(parametersValueModelList);

					exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
					// Exception logic - end
					amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR); //
					amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
					AmadeusRecCounts.incErrorCount();
					return null;
				}

				if (localDate != null) {
					flightDataDetails = flownFeignClient.getFlightDataDetails(derivedFlightNo,
							amadeusRecordStaging.getUsageOriginCode(), amadeusRecordStaging.getUsageDestinationCode(),
							localDate, null);

				}

				LOGGER.info("Derived Operating flight number--------" + derivedFlightNo);

				// Duplicate record check
				Optional<FlownEsac> flownEsacOpt = flownEsacRepository
						.findByDocumentUniqueIdandCouponNumber(documentUniqueId, couponNumber);

				if (flownEsacOpt.isPresent()) {
					LOGGER.debug("DocumentUniqueId " + documentUniqueId + "couponNumber" + couponNumber
							+ " already exists in ticketMain table for file_id " + flownEsacOpt.get().getFileId());
					LOGGER.info("DocumentUniqueId " + documentUniqueId + "couponNumber" + couponNumber
							+ " already exists in ticketMain table for file_id " + flownEsacOpt.get().getFileId());
					// stepContext.put("fileId", flownEsacOpt.get().getFileId());
					// Log record level errors
					return null;
				} else {
					if (amadeusRecordStaging.getUsageType() != null
							&& amadeusRecordStaging.getUsageType().equals(AppConstants.FLOWN_COUPON_F)) {
						LOGGER.info("Flown Reported in File:{}",
								amadeusRecordStaging.getUsageType() + amadeusRecordStaging.getUsageAirline());

						FlownCoupon flownCoupon = new FlownCoupon();
						LOGGER.info("FlightData:{}",
								amadeusRecordStaging.getFlightNumber() + amadeusRecordStaging.getUsageOriginCode()
										+ amadeusRecordStaging.getUsageDestinationCode());
						flownCoupon.setDocumentUniqueId(documentUniqueId);
						flownCoupon.setIssueAirline(issueAirline);
						flownCoupon.setDocumentNumber(documentNo);
						if (amadeusRecordStaging.getFileSource()
								.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL_SOURCE)) {
							// if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL))
							// {
							String mainDocumentNo = amadeusRecordStaging.getUsageDocNumber().substring(0, 10);
							flownCoupon.setMainDocument(mainDocumentNo);
							flownCoupon.setFlightDate(format.parse(amadeusRecordStaging.getUsageLocalFlightDate()));
							flownCoupon.setClientId(hostCarrDesigCode);
						} else {
							if (amadeusRecordStaging.getFileSource()
									.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABRE_SOURCE)) {
								LOGGER.info("MainDocument Number from Document Number for Saber");
								String mainDocumentNo = amadeusRecordStaging.getDocumentNumber();
								flownCoupon.setMainDocument(mainDocumentNo);
								flownCoupon
										.setFlightDate(format1.parse(amadeusRecordStaging.getUsageLocalFlightDate()));
								flownCoupon.setReportedFlownRbd(amadeusRecordStaging.getClassOfService());
								flownCoupon.setClientId(hostCarrDesigCodeForSabre);
							}

						}
						// flownCoupon.setMainDocument(mainDocumentNo);
						flownCoupon.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
						// flownCoupon.setFlightDate(format.parse(amadeusRecordStaging.getUsageLocalFlightDate()));
						flownCoupon.setFlightNumber(derivedFlightNo);
						flownCoupon.setFromAirport(amadeusRecordStaging.getUsageOriginCode());
						flownCoupon.setToAirport(amadeusRecordStaging.getUsageDestinationCode());
						flownCoupon.setReportedFlownCabin(amadeusRecordStaging.getUsedCabinClass());
						flownCoupon.setEstimationFlag("N");

						flownCoupon.setETktIndicator(AppConstants.ETICKET_INDICATOR_DEFAULT);
						String couponType = AppConstants.FLOWN_COUPON_U;

						if (formcodeList != null && !formcodeList.isEmpty()) {
							flownCoupon.setDocumentType(OptionalUtil.getValue(formcodeList.get(0).getDocumentType()));
							LOGGER.info("FORMCODE LIST:{}" + formcodeList.get(0).getDocumentType());
						}
						if (formcodeList.get(0).getNumberOfCoupon().get() != "0") {
							flownCoupon.setDocumentClass(formcodeList.get(0).getDocumentType().get().substring(0, 2)
									+ formcodeList.get(0).getNumberOfCoupon().get());
						} else {
							if (formcodeList.get(0).getDocumentType() != null)
								flownCoupon
										.setDocumentClass(formcodeList.get(0).getDocumentType().get().substring(0, 2));
						}
						if (amadeusRecordStaging.getPassengerName() != null
								&& !amadeusRecordStaging.getPassengerName().isEmpty()) {
							flownCoupon.setPassengerName(amadeusRecordStaging.getPassengerName());
						}

						if (amadeusRecordStaging.getBookingReference() != null
								&& !amadeusRecordStaging.getBookingReference().isEmpty()) {
							flownCoupon.setPnr(amadeusRecordStaging.getBookingReference());
						}

						flownCoupon.setCreatedBy(amadeusRecordStaging.getCreatedBy());
						flownCoupon.setCreatedDate(new Timestamp(new Date().getTime()));
						if (amadeusRecordStaging.getFileSource()
								.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL_SOURCE)) {
							// if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL))
							// {
							// Alliance Coupon(Request data Population) Logic
							DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
							if (!issueAirline.equals(hostCarrNumericCode)) {
								LOGGER.info("Alliance Coupon Available------" + issueAirline);
								LOGGER.info("Enterning Alliance Coupon Logic");
								if (validDtReqOut.equals(AppConstants.FLAG_Y)) {

									LOGGER.info("Hosting Carrier Migrated");
									String flightDate = dateFormat.format(flownCoupon.getFlightDate());
									carrierAllianceList = masterFeignClient.search(issueAirline, flightDate);
									LOGGER.info("carrierAllianceList--------->" + carrierAllianceList.size());
									if (carrierAllianceList != null && carrierAllianceList.size() > 0
											&& flownCoupon.getDocumentType().equals(AppConstants.DOCUMENT_TYPE_PAX)
											&& carrierAllianceList.get(0).getAllianceName().get()
													.equals(AppConstants.ALLIANCE_NAME_OWC)) {
										LOGGER.info("Duplicate Records Checking in Request Reository");
										Optional<RequestFileDetail> requestFileDetailOpt = requestFileDetailRepository
												.findDuplicateRecord(ticketNumber, couponNumber, requestAirlineCode,
														issueAirline, couponType);

										if (requestFileDetailOpt.isPresent()) {
											LOGGER.info("Already Data Migrated without  File Id in Request repository");

											// Exception logic - start
											exceptionTransactionModel = AmadeusCommonUtils
													.initExceptionTransactionModel(amadeusRecordStaging,
															documentUniqueId);
											exceptionTransactionModel.setClientId(hostCarrDesigCode);
											exceptionTransactionModel.setExceptionCode(
													ExceptionCodeConstants.ERRORCODE_REQUEST_DATA_PRESENT);
											parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

											paramValueModel = new ExceptionParametersValueModel();
											paramValueModel.setParameterName("Carrier Numeric Code");
											paramValueModel.setParameterValue(String.valueOf(hostCarrNumericCode));
											parametersValueModelList.add(paramValueModel);

											paramValueModel = new ExceptionParametersValueModel();
											paramValueModel.setParameterName("Document Number");
											paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
											parametersValueModelList.add(paramValueModel);

											paramValueModel = new ExceptionParametersValueModel();
											paramValueModel.setParameterName("Coupon Number");
											paramValueModel
													.setParameterValue(String.valueOf(flownCoupon.getCouponNumber()));
											parametersValueModelList.add(paramValueModel);

											exceptionTransactionModel.setParametersValueList(parametersValueModelList);

											LOGGER.info("Exception Transaction Model------->"
													+ exceptionTransactionModel.toString());

											exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
											// Exception logic - end

										} else {

											LOGGER.info(" Alliance Request data population starts------");
											RequestFileDetail requestFileDetail = new RequestFileDetail();
											requestFileDetail
													.setRequestAirLineCode(String.valueOf(hostCarrNumericCode));
											requestFileDetail.setResponseAirLineCode(issueAirline);
											requestFileDetail.setCouponNumber(flownCoupon.getCouponNumber());
											requestFileDetail.setTicketNumber(
													new BigInteger(String.valueOf(flownCoupon.getDocumentNumber())));
											requestFileDetail.setCouponNumber(flownCoupon.getCouponNumber());
											requestFileDetail.setCouponType(AppConstants.COUPON_TYPE);
											requestFileDetail.setRequestDate(new Date());
											requestFileDetail.setRequestType(AppConstants.REQUEST_TYPE_OUT);
											requestFileDetail
													.setTicketIssuingAirLineCode(String.valueOf(hostCarrNumericCode));
											requestFileDetail.setMultiCouponId(AppConstants.MULTI_COUPON_ID);
											requestFileDetail
													.setProcessRequiredFlag(AppConstants.PROCESSED_REQUEST_FLAG);
											requestFileDetail.setDataSource(AppConstants.DATA_SOURCE_AUTOMATED);
											requestFileDetail.setCreatedBy(flownCoupon.getCreatedBy());
											requestFileDetail.setCreatedDate(flownCoupon.getCreatedDate());
											requestFileDetailRepository.save(requestFileDetail);
											LOGGER.info("Request Data  population  Ends-------");

										}

									}
								}
							}
						}

						// Flight Creation

						if (flightDataDetails == null ) {
							if ((amadeusRecordStaging.getUsageOriginCode() != null
									&& !amadeusRecordStaging.getUsageOriginCode().isEmpty()
									&& amadeusRecordStaging.getUsageDestinationCode() != null
									&& !amadeusRecordStaging.getUsageDestinationCode().isEmpty()
									&&amadeusRecordStaging.getFileSource()
									.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL_SOURCE)
									&& flightCreationFromFlownForAmadeus.equals("Y")
									&& Integer.parseInt(amadeusRecordStaging.getUsageAirline()) == hostCarrNumericCode
									&& !amadeusRecordStaging.getUsageOperatingFlightNumber().equals("OPEN"))
									|| (amadeusRecordStaging.getFileSource()
											.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABRE_SOURCE)
											&& flightCreationFromFlownForSabre.equals("Y")
											&& amadeusRecordStaging.getUsageOriginCode() != null
													&& !amadeusRecordStaging.getUsageOriginCode().isEmpty()
													&& amadeusRecordStaging.getUsageDestinationCode() != null
													&& !amadeusRecordStaging.getUsageDestinationCode().isEmpty() )) {
								LOGGER.info("Creating Flight Details ");
								FlightDataDetails flightDataDetailscreation = new FlightDataDetails();
								flightDataDetailscreation.setFlightNumber(derivedFlightNo);
								flightDataDetailscreation.setFromAirport(amadeusRecordStaging.getUsageOriginCode());
								flightDataDetailscreation.setToAirport(amadeusRecordStaging.getUsageDestinationCode());
								if (localDate != null) {
									flightDataDetailscreation.setFlightDate(localDate);
								}
								flightDataDetailscreation.setFlightStatus("O");
								flightDataDetailscreation.setDataSource("ML");
								flightDataDetailscreation.setServiceType("A");
								flightDataDetailscreation.setFlightType("A");
								flightDataDetailscreation.setFlightIndicator(1);
								flightDataDetailscreation.setSsimInd("N");
								flightDataDetailscreation.setFileId(amadeusRecordStaging.getFileId());
								flightDataDetailscreation.setCreatedBy(amadeusRecordStaging.getCreatedBy());
								flightDataDetailscreation.setCreatedDate(new Timestamp(new Date().getTime()));
								flightDataDetailscreation.setClientId(hostCarrDesigCode);
								LOGGER.info(" Adhoc Flight Details Creation ");
								FlightDataDetails flightDataDetailsc = flownFeignClient
										.createFlightDataDetails(flightDataDetailscreation);
								if (flightDataDetailsc != null) {
									LOGGER.info("Flight key form Adhoc Flight Creation");
									flownCoupon.setFlightKey((long) flightDataDetailsc.getFlightKey());
								}
							} else {
								LOGGER.info(
										"flightDataDetails is empty and System Parameter is not allowed to create Flight....");
								LOGGER.info("Actual Operating flight number"
										+ amadeusRecordStaging.getUsageOperatingFlightNumber());
								LOGGER.info("Derived Operating flight number" + derivedFlightNo);

								// Exception logic - start exceptionTransactionModel =
								exceptionTransactionModel = AmadeusCommonUtils
										.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueId);
								exceptionTransactionModel.setClientId(hostCarrDesigCode);
								exceptionTransactionModel
										.setExceptionCode(ExceptionCodeConstants.ERRORCODE_FLIGHTKEYNOTFOUND);
								parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Flight Number");
								paramValueModel.setParameterValue(derivedFlightNo);
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("From sector");
								paramValueModel.setParameterValue(amadeusRecordStaging.getUsageOriginCode());
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("To sector");
								paramValueModel.setParameterValue(amadeusRecordStaging.getUsageDestinationCode());
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Depart date");
								paramValueModel.setParameterValue(amadeusRecordStaging.getUsageLocalFlightDate());
								parametersValueModelList.add(paramValueModel);

								exceptionTransactionModel.setParametersValueList(parametersValueModelList);

								exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
								// Exception logic - end
								amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR); //
								amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
								AmadeusRecCounts.incErrorCount();
								return null;

							}

						} else {
							if (flightDataDetails != null && !flightDataDetails.equals(""))
								LOGGER.info("Flight Details Available in Flight Data Details");
							flownCoupon.setFlightKey((long) flightDataDetails.getFlightKey());
						}

						flownCoupon.setDataSource(amadeusRecordStaging.getFileSource());

						flownCoupon.setFileId(amadeusRecordStaging.getFileId());
						// stepContext.put("fileId", flownCoupon.getFileId());
						flownCoupon.setMultiUpliftFlag(AppConstants.MULTI_UPLIFT_FLAG);
						flownCoupon.setCouponStatus(AppConstants.COUPON_STATUS);

						if (amadeusRecordStaging.getFileSource()
								.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL_SOURCE)) {
							// if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL))
							// {
							if (Integer.parseInt(amadeusRecordStaging.getUsageAirline()) == hostCarrNumericCode) {
								prodCouponModel.setFlownCoupon(flownCoupon);
							}
						} else if (amadeusRecordStaging.getFileSource()
								.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
							prodCouponModel.setFlownCoupon(flownCoupon);
						}

					}

					FlownEsac flownEsac = new FlownEsac();
					flownEsac.setDocumentUniqueId(documentUniqueId);
					flownEsac.setIssueAirline(issueAirline);

					flownEsac.setDocumentNumber(documentNo);

					if (amadeusRecordStaging.getFileSource()
							.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL_SOURCE)) {
						// if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL))
						// {
						String mainDocumentNo = amadeusRecordStaging.getUsageDocNumber().substring(0, 10);
						flownEsac.setMainDocument(mainDocumentNo);
						flownEsac.setOperatingCarrierNumCode(amadeusRecordStaging.getUsageAirline().substring(1, 4));
						flownEsac.setClientId(hostCarrDesigCode);
					} else {
						if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
							LOGGER.info("MainDocument Number from Document Number for saber------> ");
							String mainDocumentNo = amadeusRecordStaging.getDocumentNumber();
							flownEsac.setMainDocument(mainDocumentNo);
							flownEsac.setOperatingCarrierNumCode(amadeusRecordStaging.getIssAirline().trim());
							flownEsac.setClientId(hostCarrDesigCodeForSabre);
						}

					}
					flownEsac.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
					flownEsac.setEsacCode(amadeusRecordStaging.getSettlementAuthorizationCode());
					flownEsac.setUtilizationType(amadeusRecordStaging.getUsageType());
					flownEsac.setFileId(amadeusRecordStaging.getFileId());
					// stepContext.put("fileId", flownEsac.getFileId());
					flownEsac.setDataSource(amadeusRecordStaging.getFileSource());
					flownEsac.setCreatedBy(amadeusRecordStaging.getCreatedBy());
					flownEsac.setCreatedDate(new Timestamp(new Date().getTime()));

					prodCouponModel.setFlownEsac(flownEsac);
					// amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_TRANSFERRED);
					// amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
					LOGGER.info("ETLCouponProcessor.process -- End");

				}

			}
			return prodCouponModel;
		} catch (Exception e) {
			LOGGER.error("Exception Thrown for the amadeus Load Id: " + amadeusRecordStaging.getAmadeusLoadId());
			LOGGER.error("Exception" + e);
			exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
					documentUniqueId);
			exceptionTransactionModel.setClientId(hostCarrDesigCode);
			exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.GENERAL_EXCEPTION);

			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			paramValueModel = new ExceptionParametersValueModel();
			paramValueModel.setParameterName("Issue Details");
			paramValueModel.setParameterValue(AmadeusCommonUtils.getExceptionMsg(e));
			parametersValueModelList.add(paramValueModel);

			paramValueModel = new ExceptionParametersValueModel();
			paramValueModel.setParameterName("Issue Airline");
			paramValueModel.setParameterValue(amadeusRecordStaging.getIssAirline());
			parametersValueModelList.add(paramValueModel);

			paramValueModel = new ExceptionParametersValueModel();
			paramValueModel.setParameterName("Document Number");
			paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
			parametersValueModelList.add(paramValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
			// Exception logic - end
			amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
			AmadeusRecCounts.incErrorCount();
			// amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
			return null;
		}

	}

	private static boolean getValidDateFormat(String format, String value) {
		Date date = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			date = sdf.parse(value);
			if (!value.equals(sdf.format(date))) {
				date = null;
			}
		} catch (ParseException ex) {
			ex.printStackTrace();
		}
		return date != null;
	}
}