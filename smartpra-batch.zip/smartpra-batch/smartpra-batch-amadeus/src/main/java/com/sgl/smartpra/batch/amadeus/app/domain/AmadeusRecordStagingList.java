package com.sgl.smartpra.batch.amadeus.app.domain;

import java.io.Serializable;
import java.util.List;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.amadeus.app.processor.StagingSaberEmdProcessor;
import com.sgl.smartpra.batch.amadeus.app.writer.ProdCouponDataWriter;
import com.sgl.smartpra.batch.amadeus.app.writer.StagingSaberEmdWriter;

public class AmadeusRecordStagingList extends AmadeusBatchRecord implements Serializable {

	private List<AmadeusRecordStaging> amadeusRecordStaging;

	public List<AmadeusRecordStaging> getAmadeusRecordStaging() {
		return amadeusRecordStaging;
	}

	public void setAmadeusRecordStaging(List<AmadeusRecordStaging> amadeusRecordStaging) {
		this.amadeusRecordStaging = amadeusRecordStaging;
	}

	@Override
	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FieldSetMapper<AmadeusBatchRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemWriter<? super AmadeusBatchRecord> writer() {
		// TODO Auto-generated method stub
		return new StagingSaberEmdWriter();
	}
	
	

	@Override
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> processor() {
		// TODO Auto-generated method stub
		return new StagingSaberEmdProcessor();
	}

	@Override
	public String toString() {
		return "AmadeusRecordStagingList [amadeusRecordStaging=" + amadeusRecordStaging + "]";
	}
	
	
	
}
