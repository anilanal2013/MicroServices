package com.sgl.smartpra.batch.amadeus.app.layout;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

import java.util.ArrayList;

public class StagingSaberEmdUsedHeader_Layout extends FixedLengthRecordLayout {

	public StagingSaberEmdUsedHeader_Layout() {

		fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType", 1, 1));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 2, null));

	}

}
