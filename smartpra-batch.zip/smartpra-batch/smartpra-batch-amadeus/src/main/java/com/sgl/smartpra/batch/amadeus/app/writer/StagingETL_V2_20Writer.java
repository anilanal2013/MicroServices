package com.sgl.smartpra.batch.amadeus.app.writer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.AmadeusRecCounts;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdCouponModel;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.batch.amadeus.app.processor.ETLCouponProcessor;
import com.sgl.smartpra.batch.amadeus.app.processor.ETLTicketProcessor;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.repository.TicketCouponRepository;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@Component
@Scope(value = "step")
public class StagingETL_V2_20Writer<T extends AmadeusBatchRecord> implements ItemWriter<AmadeusRecordStaging> {

	private static final Logger LOGGER = LoggerFactory.getLogger(StagingETL_V2_20Writer.class);

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private TicketMainRepository ticketMainRepository;

	@Autowired
	private TicketCouponRepository ticketCouponRepository;

	@Autowired
	ProdTicketDataWriter prodTicketDataWriter;

	@Autowired
	ProdCouponDataWriter prodCouponDataWriter;

	@Autowired
	ETLTicketProcessor etlTicketProcessor;

	@Autowired
	ETLCouponProcessor etlCouponProcessor;

	@Value("#{jobParameters[amadeusVersion]}")
	public String amadeusVersion;

	public String hostCarrDesigCode = "QR";

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends AmadeusRecordStaging> amadeusRecordStagingList) throws Exception {
		List<ProdTicketModel> prodTicketModelList = new ArrayList<ProdTicketModel>();
		List<ProdCouponModel> prodCouponModelList = new ArrayList<ProdCouponModel>();
		ProdTicketModel prodTicketModel;
		ProdCouponModel prodCouponModel;
		amadeusRecordStagingRepository.saveAll(amadeusRecordStagingList);
		amadeusRecordStagingRepository.flush();

		for (AmadeusRecordStaging amadeusRecordStaging : amadeusRecordStagingList) {
			if (amadeusRecordStaging.getFileSource().equals("XL")){
				prodTicketModel = etlTicketProcessor.process(hostCarrDesigCode, amadeusRecordStaging);
				if (prodTicketModel != null && prodTicketModel.getTicketMain() != null
						&& prodTicketModel.getTicketMain().size() > 0) {
					AmadeusRecCounts.incDetailCount();
					LOGGER.info("#################################################### STG  - TICKET SAVE");
					prodTicketModelList.add(prodTicketModel);
					prodTicketDataWriter.write(prodTicketModelList);
					LOGGER.info("#################################################### STG  - TICKET SAVE END -- 1");
					AmadeusRecCounts.incTransferCount();
					amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_TRANSFERRED);
					amadeusRecordStagingRepository.save(amadeusRecordStaging);
					LOGGER.info(
							"#################################################### STG  - coupon using prodCouponDataWriter SAVE END");
				} else {
					amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					amadeusRecordStagingRepository.save(amadeusRecordStaging);
				}
			}
			else
			if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)
					|| amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {

				prodTicketModel = etlTicketProcessor.process(hostCarrDesigCode, amadeusRecordStaging);
				if (prodTicketModel != null && prodTicketModel.getTicketMain() != null
						&& prodTicketModel.getTicketMain().size() > 0) {
					AmadeusRecCounts.incDetailCount();
					LOGGER.info("#################################################### STG  - TICKET SAVE");
					prodTicketModelList.add(prodTicketModel);
					prodTicketDataWriter.write(prodTicketModelList);
					LOGGER.info("#################################################### STG  - TICKET SAVE END -- 1");
					prodCouponModel = etlCouponProcessor.process(amadeusRecordStaging);
					LOGGER.info(String.valueOf(prodCouponModel == null));
					LOGGER.info(
							"#################################################### STG  - coupon using prodCouponDataWriter SAVE BEGIN");
					if (prodCouponModel != null
							&& (prodCouponModel.getFlownCoupon() != null || prodCouponModel.getFlownEsac() != null)) {
						LOGGER.info("prodCouponWrite ------- Start");
						LOGGER.info(String.valueOf(prodCouponModel.getFlownCoupon() == null));
						LOGGER.info(String.valueOf(prodCouponModel.getFlownEsac() == null));
						prodCouponModelList.add(prodCouponModel);
						prodCouponDataWriter.write(prodCouponModelList);
						LOGGER.info("prodCouponWrite ------- End");
						AmadeusRecCounts.incTransferCount();
						amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_TRANSFERRED);
						amadeusRecordStagingRepository.save(amadeusRecordStaging);

					}
					LOGGER.info(
							"#################################################### STG  - coupon using prodCouponDataWriter SAVE END");
				} else {
					amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					amadeusRecordStagingRepository.save(amadeusRecordStaging);

				}
			}

			else if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
				String issueAirline = amadeusRecordStaging.getIssAirline();
				String documentNumber = amadeusRecordStaging.getDocumentNumber();

				Optional<TicketMain> ticketMain = ticketMainRepository.findByIssAirlineDocNo(hostCarrDesigCode,
						issueAirline, documentNumber);

				if (ticketMain.isPresent()) {

					List<TicketCoupon> ticketCouponList = ticketMain.get().getTicketCoupons();
					LOGGER.info("Issue Date  is available in Ticket Main table " + ticketMain.get().getDateOfIssue());

					SimpleDateFormat dateFormatter = new SimpleDateFormat("yyMMdd");
					String docUniqueDate = dateFormatter.format(ticketMain.get().getDateOfIssue());
					amadeusRecordStaging.setIssueDate(docUniqueDate);
					LOGGER.info("Issue Date added in Staging Record ----->" + amadeusRecordStaging.getIssueDate());
					for (TicketCoupon ticketCoupon : ticketCouponList) {
						if (ticketCouponList != null) {
							if (ticketCoupon.getDocumentNumber().equals(amadeusRecordStaging.getDocumentNumber())
									&& ticketCoupon.getCouponNumber() == Integer
											.parseInt(amadeusRecordStaging.getCouponNumber())) {

								ticketCoupon.setInvolFlag(amadeusRecordStaging.getInvoluntaryIndicator());
								ticketCoupon
										.setFrequentFlyerReference(amadeusRecordStaging.getFrequentFlyerCustomerCode());

								ticketCouponRepository.save(ticketCoupon);
							}
						}
					}
					AmadeusRecCounts.incDetailCount();
					prodCouponModel = etlCouponProcessor.process(amadeusRecordStaging);
					LOGGER.info(String.valueOf(prodCouponModel == null));
					if (prodCouponModel != null
							&& (prodCouponModel.getFlownCoupon() != null || prodCouponModel.getFlownEsac() != null)) {
						LOGGER.info("prodCouponWrite ------- Start");
						LOGGER.info(String.valueOf(prodCouponModel.getFlownCoupon() == null));
						LOGGER.info(String.valueOf(prodCouponModel.getFlownEsac() == null));
						prodCouponModelList.add(prodCouponModel);
						prodCouponDataWriter.write(prodCouponModelList);
						LOGGER.info("prodCouponWrite ------- End");
						AmadeusRecCounts.incTransferCount();
					}

					LOGGER.info(
							"#################################################### STG  - coupon using prodCouponDataWriter SAVE END for Saber VCR");

				} else {
					LOGGER.info(
							"#################################################### Date of issue is not available in Ticket main table so Records are not moved to production "
									+ amadeusRecordStaging.getDocumentNumber());
					amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					amadeusRecordStagingRepository.save(amadeusRecordStaging);
				}
			}
		}
	}
}
