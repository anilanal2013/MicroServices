package com.sgl.smartpra.batch.amadeus.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class StagingSaberVcrOldVersion_Layout extends FixedLengthRecordLayout{

    public StagingSaberVcrOldVersion_Layout(){
    	
    	 fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType",1,1));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline",2,4));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber",5,14));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit",15,15));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber",16,16));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingFlightNumber",17,20));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightNumber",17,20));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageLocalFlightDate",21,28));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOriginCode",29,33));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDestinationCode",34,38));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usedCabinClass",39,39));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("classOfService",40,41));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareBasis",42,54));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("routing",55,78));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthorizationCode",79,92));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("involuntaryRerouteIndicators",93,94));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingCarrier",95,97));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",98,null));
         
         
         
       
    }
}
