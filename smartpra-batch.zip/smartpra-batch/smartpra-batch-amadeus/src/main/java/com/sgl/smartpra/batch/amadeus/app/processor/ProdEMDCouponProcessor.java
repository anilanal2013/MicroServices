package com.sgl.smartpra.batch.amadeus.app.processor;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.AmadeusRecCounts;
import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.ExceptionTxnFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.FlownFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdCouponModel;
import com.sgl.smartpra.batch.amadeus.app.mapper.EmdQueuemapper;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.batch.amadeus.app.utils.AmadeusCommonUtils;
import com.sgl.smartpra.common.util.ExceptionCodeConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.domain.FlownEsac;
import com.sgl.smartpra.flown.model.EMDQueue;
import com.sgl.smartpra.flown.model.FlightDataDetails;
import com.sgl.smartpra.flown.repository.BsaCouponDetailRepository;
import com.sgl.smartpra.flown.repository.FlownEsacRepository;
import com.sgl.smartpra.master.model.FormCode;

@Component("emdUsed")
@Scope(value = "step")
public class ProdEMDCouponProcessor extends AmadeusProcessor
		implements ItemProcessor<AmadeusRecordStaging, ProdCouponModel> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProdEMDCouponProcessor.class);

	@Autowired
	FlownFeignClient flownFeignClient;

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	private ExceptionTxnFeignClient exceptionTxnFeignClient;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private BsaCouponDetailRepository bsaCouponDetailRepository;

	@Autowired
	private FlownEsacRepository flownEsacRepository;

	@Autowired
	private EmdQueuemapper emdQueuemapper;

	@Value("#{jobParameters['carrieNumericCode']}")
	public Integer hostCarrNumericCode;

	@Value("#{jobParameters['careerDesignatorCode']}")
	public String hostCarrDesigCode;

	@Value("#{jobParameters['flightNoLen']}")
	public String sysParamFlightLen;

	@Value("#{jobParameters[amadeusVersion]}")
	String amadeusVersion;

	@Value("#{jobParameters['careerDesignatorCode']}")
	public String hostCarrDesigCodeForSabre;

	@Value("#{jobParameters['flightCreationFromFlown']}")
	public String flightCreationFromFlownForSabre;

	@Value("#{jobParameters['flightCreationFromFlown']}")
	public String flightCreationFromFlownForAmadeus;

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	private Integer errorCount;
	private Integer transferredCount;

	@Override
	public ProdCouponModel process(AmadeusRecordStaging amadeusRecordStaging) throws Exception {
		JobExecution jobExecution = this.stepExecution.getJobExecution();
		ExecutionContext jobExecutionContext = jobExecution.getExecutionContext();
		// ExecutionContext stepContext = this.stepExecution.getExecutionContext();
		LOGGER.info("ProdEMDCouponProcessor.process -- Start");
		ProdCouponModel prodCouponModel = new ProdCouponModel();
		ExecutionContext stepContext = this.stepExecution.getExecutionContext();
		SimpleDateFormat simpleDateFormatddmmyy = new SimpleDateFormat("ddMMyy");
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("ddMMyy");
		DateTimeFormatter emdDateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
		DateTimeFormatter emdDateFormatter1 = DateTimeFormatter.ofPattern("ddMMyyyy");
		DateTimeFormatter emdDateFormatterForFlight = DateTimeFormatter.ofPattern("MMddyyyy");
		SimpleDateFormat simpleDateFormatyyyymmdd = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat simpleDateFormatyymmdd = new SimpleDateFormat("yyMMdd");
		SimpleDateFormat simpleDateFormatddmmyyyy = new SimpleDateFormat("ddMMyyyy");
		// SimpleDateFormat simpleDateFormatyyyymmdd = new SimpleDateFormat("ddMMyyyy");
		ExceptionTransactionModel exceptionTransactionModel;
		List<ExceptionParametersValueModel> parametersValueModelList;
		FlightDataDetails flightDataDetails = null;
		ExceptionParametersValueModel paramValueModel;
		LOGGER.info("Object : {}", amadeusRecordStaging);

		// Unique columns for all ticket / coupon tables
		String issueAirline = amadeusRecordStaging.getIssAirline();
		String documentNo = amadeusRecordStaging.getDocumentNumber();
		String documentUniqueId = null;
		if (amadeusRecordStaging.getFileSource().contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD_SOURCE)) {
			LOGGER.info("Amadeus EMD File");
			documentUniqueId = hostCarrDesigCode + issueAirline + documentNo
					+ amadeusRecordStaging.getIssueDate().substring(2);
		} else if (amadeusRecordStaging.getFileSource()
				.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABRE_EMD_USED_SOURCE)) {
			LOGGER.info("Saber EMD_USED File");
			documentUniqueId = hostCarrDesigCode + issueAirline + documentNo + amadeusRecordStaging.getIssueDate();
		}

		Integer couponNumber = Integer.parseInt(amadeusRecordStaging.getCouponNumber());
		String numberOfCoupon = null;

		try {
			String emdDate = amadeusRecordStaging.getUsageEmdDate();
			if (amadeusRecordStaging.getUsageEmdDate() != null && !amadeusRecordStaging.getUsageEmdDate().isEmpty()) {

				LOGGER.info("DateString------->" + emdDate);
			}

			Integer count = (Integer) jobExecutionContext.get("errorCount");

			if (count != null) {
				errorCount = count;
			} else {
				jobExecutionContext.put("errorCount", 0);
				errorCount = 0;
			}

			count = (Integer) jobExecutionContext.get("transferredCount");
			LOGGER.info("Transfered Count --->" + jobExecutionContext.get("transferredCount"));

			if (count != null) {
				transferredCount = count;
			} else {
				LOGGER.info("Transfered Count status--->" + jobExecutionContext.get("transferredCount"));
				jobExecutionContext.put("transferredCount", 0);
				transferredCount = 0;
			}

			// Duplicate record check
			Optional<FlownEsac> flownEsacOpt = flownEsacRepository
					.findByDocumentUniqueIdandCouponNumber(documentUniqueId, couponNumber);

			if (flownEsacOpt.isPresent()) {

				LOGGER.debug("DocumentUniqueId " + documentUniqueId + "couponNumber" + couponNumber
						+ " already exists in ticketMain table for file_id " + flownEsacOpt.get().getFileId());
				LOGGER.info("DocumentUniqueId " + documentUniqueId + "couponNumber" + couponNumber
						+ " already exists in ticketMain table for file_id " + flownEsacOpt.get().getFileId());
				jobExecutionContext.put("errorCount", ++errorCount);
				LOGGER.info("Error Count after in formcode master list----------->"
						+ jobExecution.getExecutionContext().get("errorCount"));
				stepContext.put("fileId", flownEsacOpt.get().getFileId());
				amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
				amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				return null;
			} else {
				String derivedFlightNo = SmartPRACommonUtil
						.deriveFlightNo(amadeusRecordStaging.getUsageOperatingFlightNumber(), sysParamFlightLen);

				if (amadeusRecordStaging.getUsageType() != null
						&& amadeusRecordStaging.getUsageType().equals(AppConstants.USAGE_TYPE_F)) {

					LOGGER.info("Entering Flown Details:{}");

					LOGGER.info("Object : {}", amadeusRecordStaging);
					LOGGER.info("Carrier Numeric Code" + hostCarrNumericCode);

					LOGGER.info("Object : {}", amadeusRecordStaging);
					LOGGER.info("FlightNumber : {}",
							amadeusRecordStaging.getUsageOperatingFlightNumber() + "UsageOriginCodeEmd:{}"
									+ amadeusRecordStaging.getUsageOriginCodeEmd() + "UsageDestinationCodeEmd:{}"
									+ amadeusRecordStaging.getUsageDestinationCodeEmd());

					/*
					 * List<FlightDataDetails> flightKeyList =
					 * flownFeignClient.getAllFlightDataDetails(derivedFlightNo,
					 * amadeusRecordStaging.getUsageOriginCodeEmd(),
					 * amadeusRecordStaging.getUsageDestinationCodeEmd(), null);
					 */

					List<FormCode> formcodeList = masterFeignClient.getAllFormCode(
							amadeusRecordStaging.getDocumentNumber().substring(0, 3), null, numberOfCoupon, null, null);
					LOGGER.info("Form Code  Lists are:{}" + formcodeList);
					FlownCoupon flownCoupon = new FlownCoupon();
					flownCoupon.setIssueAirline(issueAirline);

					if (amadeusRecordStaging.getFileSource()
							.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD_SOURCE)) {
						String mainDocumentNo = amadeusRecordStaging.getUsageDocNumber().substring(0, 10);
						flownCoupon.setMainDocument(mainDocumentNo);
						flownCoupon.setClientId(hostCarrDesigCode);
						// flownCoupon.setFlightDate(format.parse(amadeusRecordStaging.getUsageLocalFlightDate()));
					} else {
						if (amadeusRecordStaging.getFileSource()
								.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABRE_EMD_USED_SOURCE)) {
							LOGGER.info("MainDocument Number from Document Number for Saber");
							String mainDocumentNo = amadeusRecordStaging.getDocumentNumber();
							flownCoupon.setMainDocument(mainDocumentNo);
							flownCoupon.setReportedFlownRbd(amadeusRecordStaging.getClassOfService());
							flownCoupon.setClientId(hostCarrDesigCodeForSabre);
						}

					}
					flownCoupon.setDocumentNumber(documentNo);
					// flownCoupon.setMainDocument(mainDocumentNo);
					flownCoupon.setDocumentUniqueId(documentUniqueId);

					if (amadeusRecordStaging.getCouponNumber() != null
							&& !amadeusRecordStaging.getCouponNumber().isEmpty()) {
						flownCoupon.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
					}

					LOGGER.info("Usage Date:{}", amadeusRecordStaging.getUsageEmdDate());

					if (derivedFlightNo != null && !derivedFlightNo.isEmpty()) {
						flownCoupon.setFlightNumber(derivedFlightNo);
					}

					flownCoupon.setFromAirport(amadeusRecordStaging.getUsageOriginCodeEmd());
					flownCoupon.setToAirport(amadeusRecordStaging.getUsageDestinationCodeEmd());
					flownCoupon.setETktIndicator(AppConstants.ETICKET_INDICATOR);
					flownCoupon.setPassengerName(amadeusRecordStaging.getPassengerName());
					flownCoupon.setPnr(amadeusRecordStaging.getBookingReference());
					flownCoupon.setCreatedBy(amadeusRecordStaging.getCreatedBy());
					flownCoupon.setCreatedDate(new Timestamp(new Date().getTime()));
					flownCoupon.setDataSource(amadeusRecordStaging.getFileSource());
					flownCoupon.setEstimationFlag("N");
					flownCoupon.setClientId(hostCarrDesigCode);

					if ((amadeusRecordStaging.getFileSource()
							.equals(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD_SOURCE)
							&& amadeusRecordStaging.getUsageEmdDate() != null
							&& !amadeusRecordStaging.getUsageEmdDate().isEmpty()
							&& flownCoupon.getFlightNumber() != null
							&& flownCoupon.getFlightNumber().trim().length() > 0
							&& amadeusRecordStaging.getUsageAirline() != null
							&& !amadeusRecordStaging.getUsageAirline().trim().isEmpty())
							|| (amadeusRecordStaging.getFileSource()
									.equals(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABRE_EMD_USED_SOURCE)
									&& amadeusRecordStaging.getUsageEmdDate() != null
									&& !amadeusRecordStaging.getUsageEmdDate().isEmpty()
									&& flownCoupon.getFlightNumber() != null
									&& flownCoupon.getFlightNumber().trim().length() > 0)) {

						if (getValidDateFormat(AppConstants.DD_MM_YY_FORMAT, emdDate)
								|| (getValidDateFormat(AppConstants.MM_DD_YYYY_FORMAT, emdDate)
										|| (getValidDateFormat(AppConstants.DD_MM_YYYY_FORMAT, emdDate)
												|| (getValidDateFormat(AppConstants.YYYY_MM_DD_FORMAT, emdDate))))) {

							LocalDate localDate = null;

							if (getValidDateFormat(AppConstants.DD_MM_YY_FORMAT,
									amadeusRecordStaging.getUsageEmdDate())) {
								LOGGER.info("Enter ddmmyy Format:{}");
								localDate = LocalDate.parse(emdDate, dtFormatter);
								flownCoupon.setFlightDate(
										simpleDateFormatddmmyy.parse(amadeusRecordStaging.getUsageEmdDate()));
							} else if (getValidDateFormat(AppConstants.YYYY_MM_DD_FORMAT,
									amadeusRecordStaging.getUsageEmdDate())) {
								LOGGER.info("Enter yyyyddmm Format:{}");
								localDate = LocalDate.parse(emdDate, emdDateFormatter);
								flownCoupon.setFlightDate(
										simpleDateFormatyyyymmdd.parse(amadeusRecordStaging.getUsageEmdDate()));
							} else if (getValidDateFormat(AppConstants.DD_MM_YYYY_FORMAT,
									amadeusRecordStaging.getUsageEmdDate())) {
								LOGGER.info("Enter ddmmyyyy Format:{}");
								localDate = LocalDate.parse(emdDate, emdDateFormatter1);
								flownCoupon.setFlightDate(
										simpleDateFormatddmmyyyy.parse(amadeusRecordStaging.getUsageEmdDate()));

							} else if (getValidDateFormat(AppConstants.MM_DD_YYYY_FORMAT,
									amadeusRecordStaging.getUsageEmdDate())) {
								LOGGER.info("Enter mmddyyyy Format:{}");
								localDate = LocalDate.parse(emdDate, emdDateFormatterForFlight);
								flownCoupon.setFlightDate(
										simpleDateFormatddmmyyyy.parse(amadeusRecordStaging.getUsageEmdDate()));

							} else {
								LOGGER.info("Not Able to create Flight due to Wrong Date Format ");
								LOGGER.info("Actual Operating flight number"
										+ amadeusRecordStaging.getUsageOperatingFlightNumber());
								LOGGER.info("Derived Operating flight number" + derivedFlightNo);

								// Exception logic - start exceptionTransactionModel =
								exceptionTransactionModel = AmadeusCommonUtils
										.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueId);
								exceptionTransactionModel.setClientId(hostCarrDesigCode);
								exceptionTransactionModel
										.setExceptionCode(ExceptionCodeConstants.ERRORCODE_FLIGHTNOTFOUND);
								parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Flight Number");
								paramValueModel.setParameterValue(derivedFlightNo);
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("From sector");
								paramValueModel.setParameterValue(amadeusRecordStaging.getUsageOriginCode());
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("To sector");
								paramValueModel.setParameterValue(amadeusRecordStaging.getUsageDestinationCode());
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Depart date");
								paramValueModel.setParameterValue(amadeusRecordStaging.getUsageEmdDate());
								parametersValueModelList.add(paramValueModel);

								exceptionTransactionModel.setParametersValueList(parametersValueModelList);

								exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
								// Exception logic - end
								amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR); //
								amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
								AmadeusRecCounts.incErrorCount();
								return null;
							}

							if (localDate != null) {
								flightDataDetails = flownFeignClient.getFlightDataDetails(derivedFlightNo,
										amadeusRecordStaging.getUsageOriginCodeEmd(),
										amadeusRecordStaging.getUsageDestinationCodeEmd(), localDate, null);

							}

							if (formcodeList != null && !formcodeList.isEmpty()) {
								flownCoupon
										.setDocumentType(OptionalUtil.getValue(formcodeList.get(0).getDocumentType()));
								LOGGER.info("FORMCODE LIST:{}" + formcodeList.get(0).getDocumentType());
							}
							if (formcodeList.get(0).getNumberOfCoupon().get() != "0") {
								flownCoupon.setDocumentClass(formcodeList.get(0).getDocumentType().get().substring(0, 2)
										+ formcodeList.get(0).getNumberOfCoupon().get());
							} else {
								flownCoupon
										.setDocumentClass(formcodeList.get(0).getDocumentType().get().substring(0, 2));
							}

							flownCoupon.setEmdIndicator(AppConstants.EMD_INDICATOR_DEFAULT);

							flownCoupon.setFileId(amadeusRecordStaging.getFileId());
							// stepContext.put("fileId", flownCoupon.getFileId());
							System.out.println("file_id" + amadeusRecordStaging.getFileId());
							flownCoupon.setCouponStatus(AppConstants.COUPON_STATUS);
							flownCoupon.setMultiUpliftFlag(AppConstants.MULTI_UPLIFT_FLAG);
							flownCoupon.setReportedFlownCabin(amadeusRecordStaging.getUsedCabinClass());

							if (flightDataDetails == null) {
								if ((amadeusRecordStaging.getUsageOriginCodeEmd() != null
										&& !amadeusRecordStaging.getUsageOriginCodeEmd().isEmpty()
										&& amadeusRecordStaging.getUsageDestinationCodeEmd() != null
										&& !amadeusRecordStaging.getUsageDestinationCodeEmd().isEmpty()
										&& amadeusRecordStaging.getFileSource()
												.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD_SOURCE)
										&& flightCreationFromFlownForAmadeus.equals("Y")
										&& Integer
												.parseInt(amadeusRecordStaging.getUsageAirline()) == hostCarrNumericCode
										&& !amadeusRecordStaging.getUsageOperatingFlightNumber().equals("OPEN"))
										|| (amadeusRecordStaging.getFileSource().contains(
												AppConstants.FILETYPE_IDENTIFICATION_STRING_SABRE_EMD_USED_SOURCE)
												&& flightCreationFromFlownForSabre.equals("Y")
												&& amadeusRecordStaging.getUsageOriginCodeEmd() != null
												&& !amadeusRecordStaging.getUsageOriginCodeEmd().isEmpty()
												&& amadeusRecordStaging.getUsageDestinationCodeEmd() != null
												&& !amadeusRecordStaging.getUsageDestinationCodeEmd().isEmpty())) {
									FlightDataDetails flightDataDetailscreation = new FlightDataDetails();
									flightDataDetailscreation.setFlightNumber(derivedFlightNo);
									flightDataDetailscreation
											.setFromAirport(amadeusRecordStaging.getUsageOriginCodeEmd());
									flightDataDetailscreation
											.setToAirport(amadeusRecordStaging.getUsageDestinationCodeEmd());
									if (localDate != null) {
										flightDataDetailscreation.setFlightDate(localDate);
									}
									flightDataDetailscreation.setFlightStatus("O");
									flightDataDetailscreation.setDataSource("ML");
									flightDataDetailscreation.setServiceType("A");
									flightDataDetailscreation.setFlightType("A");
									flightDataDetailscreation.setFlightIndicator(1);
									flightDataDetailscreation.setSsimInd("N");
									flightDataDetailscreation.setFileId(amadeusRecordStaging.getFileId());
									flightDataDetailscreation.setCreatedBy(amadeusRecordStaging.getCreatedBy());
									flightDataDetailscreation.setCreatedDate(new Timestamp(new Date().getTime()));
									flightDataDetailscreation.setClientId(hostCarrDesigCode);
									LOGGER.info("Adhoc Flight Details Creation ");
									FlightDataDetails flightDataDetailsc = flownFeignClient
											.createFlightDataDetails(flightDataDetailscreation);
									if (flightDataDetailsc != null) {
										LOGGER.info("Flight key form Adhoc Flight Creation");
										flownCoupon.setFlightKey((long) flightDataDetailsc.getFlightKey());
										LOGGER.info(
												"Flight key form Adhoc Flight Creation" + flownCoupon.getFlightKey());
									}

								} else {
									LOGGER.info(
											"flightDataDetails is empty and System Parameter is not allowed to create Flight....");
									LOGGER.info("Actual Operating flight number"
											+ amadeusRecordStaging.getUsageOperatingFlightNumber());
									LOGGER.info("Derived Operating flight number" + derivedFlightNo);

									// Exception logic - start exceptionTransactionModel =
									exceptionTransactionModel = AmadeusCommonUtils
											.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueId);
									exceptionTransactionModel.setClientId(hostCarrDesigCode);
									exceptionTransactionModel
											.setExceptionCode(ExceptionCodeConstants.ERRORCODE_FLIGHTKEYNOTFOUND);
									parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

									paramValueModel = new ExceptionParametersValueModel();
									paramValueModel.setParameterName("Flight Number");
									paramValueModel.setParameterValue(derivedFlightNo);
									parametersValueModelList.add(paramValueModel);

									paramValueModel = new ExceptionParametersValueModel();
									paramValueModel.setParameterName("From sector");
									paramValueModel.setParameterValue(amadeusRecordStaging.getUsageOriginCode());
									parametersValueModelList.add(paramValueModel);

									paramValueModel = new ExceptionParametersValueModel();
									paramValueModel.setParameterName("To sector");
									paramValueModel.setParameterValue(amadeusRecordStaging.getUsageDestinationCode());
									parametersValueModelList.add(paramValueModel);

									paramValueModel = new ExceptionParametersValueModel();
									paramValueModel.setParameterName("Depart date");
									paramValueModel.setParameterValue(amadeusRecordStaging.getUsageEmdDate());
									parametersValueModelList.add(paramValueModel);

									exceptionTransactionModel.setParametersValueList(parametersValueModelList);

									exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
									// Exception logic - end
									amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR); //
									amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
									AmadeusRecCounts.incErrorCount();
									return null;

								}
							} else {
								if (flightDataDetails != null && !flightDataDetails.equals(""))
									LOGGER.info("Flight Details Available In Flight Data Details ");
								flownCoupon.setFlightKey((long) flightDataDetails.getFlightKey());
							}
							if (amadeusRecordStaging.getFileSource()
									.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD_SOURCE)) {
								if (Integer.parseInt(amadeusRecordStaging.getUsageAirline()) == hostCarrNumericCode) {
									prodCouponModel.setFlownCoupon(flownCoupon);
								}
							} else if (amadeusRecordStaging.getFileSource()
									.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABRE_EMD_USED_SOURCE)) {
								prodCouponModel.setFlownCoupon(flownCoupon);
							} else {
								return null;
							}

						}
					} else {
						// Emd Queue

						LOGGER.info("Entering Emd Queue Details:{}");

						EMDQueue emdQueue = emdQueuemapper.mapToEmdQueue(flownCoupon);
						LOGGER.info("emdQueue" + emdQueue.toString());
						LOGGER.info("Flown" + flownCoupon.toString());

						if (amadeusRecordStaging.getInConnectionDocNo() != null
								&& !amadeusRecordStaging.getInConnectionDocNo().isEmpty()) {
							emdQueue.setInConnectionAirlineCode(
									Integer.parseInt(amadeusRecordStaging.getInConnectionDocNo().substring(0, 3)));
							emdQueue.setInConnectionTicketNo(
									new BigInteger(amadeusRecordStaging.getInConnectionDocNo().substring(3, 13)));
						}
						if (amadeusRecordStaging.getInConnectionCouponNo() != null
								&& !amadeusRecordStaging.getInConnectionCouponNo().isEmpty()) {
							emdQueue.setInConnectionTicketCouponNumber(
									Integer.parseInt(amadeusRecordStaging.getInConnectionCouponNo()));
						}
						// if
						// (amadeusRecordStaging.getFileSource().contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABRE_EMD_USED_SOURCE))
						// {
						LOGGER.info("Adding Emd Used Default Values");
						emdQueue.seteTktIndicator(AppConstants.ETICKET_INDICATOR);
						emdQueue.setPassengerType(AppConstants.PASSENGER_TYPE_DEFAULT);
						emdQueue.setMultiUpliftFlag(AppConstants.MULTI_UPLIFT_FLAG);
						emdQueue.setEmdIndicator(AppConstants.EMD_INDICATOR_DEFAULT);
						emdQueue.setFileId(amadeusRecordStaging.getFileId());
						// stepContext.put("fileId", emdQueue.getFileId());

						flownFeignClient.loadfromFlownEmd(emdQueue);

					}

				}

				// usage Type and Usage airline Condition removed for flown Esac as per Sme's
				// suggestion

				FlownEsac flownEsac = new FlownEsac();

				LOGGER.info("Object : {}", amadeusRecordStaging);
				LOGGER.info("Inserting Esac Records for this document Number ########" + documentNo);
				flownEsac.setIssueAirline(issueAirline);
				flownEsac.setDocumentNumber(documentNo);
				// flownEsac.setMainDocument(mainDocumentNo);
				if (amadeusRecordStaging.getFileSource()
						.equals(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD_SOURCE)) {
					String mainDocumentNo = amadeusRecordStaging.getUsageDocNumber().substring(0, 10);
					flownEsac.setMainDocument(mainDocumentNo);
					if (amadeusRecordStaging.getUsageAirline() != null
							&& !amadeusRecordStaging.getUsageAirline().isEmpty()) {
						flownEsac.setOperatingCarrierNumCode(amadeusRecordStaging.getUsageAirline().substring(1, 4));
					}
					flownEsac.setClientId(hostCarrDesigCode);
				} else {
					if (amadeusRecordStaging.getFileSource()
							.equals(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABRE_EMD_USED_SOURCE)) {
						LOGGER.info("MainDocument Number from Document Number for Saber");
						String mainDocumentNo = amadeusRecordStaging.getDocumentNumber();
						flownEsac.setMainDocument(mainDocumentNo);
						flownEsac.setOperatingCarrierNumCode(amadeusRecordStaging.getIssAirline().trim());
						flownEsac.setClientId(hostCarrDesigCodeForSabre);
						// flownEsac.setReportedFlownRbd(amadeusRecordStaging.getClassOfService());
					}

				}
				flownEsac.setDocumentUniqueId(documentUniqueId);

				flownEsac.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
				flownEsac.setEsacCode(amadeusRecordStaging.getSettlementAuthorizationCode());
				flownEsac.setUtilizationType(amadeusRecordStaging.getUsageType());
				flownEsac.setFileId(amadeusRecordStaging.getFileId());
				// stepContext.put("fileId", flownEsac.getFileId());
				flownEsac.setDataSource(amadeusRecordStaging.getFileSource());
				flownEsac.setCreatedBy(amadeusRecordStaging.getCreatedBy());
				flownEsac.setCreatedDate(new Timestamp(new Date().getTime()));
				prodCouponModel.setFlownEsac(flownEsac);
				jobExecutionContext.put("transferredCount", ++transferredCount);
				LOGGER.info("Transfered Count-----------" + transferredCount);

				amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_TRANSFERRED);
				amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				LOGGER.info("ProdEMDCouponProcessor.process -- End");
			}
			return prodCouponModel;
		} catch (Exception e) {
			LOGGER.error("Exception Thrown for the amadeus Load Id: " + amadeusRecordStaging.getAmadeusLoadId());
			LOGGER.error("Exception" + e);
			exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
					documentUniqueId);
			exceptionTransactionModel.setClientId(hostCarrDesigCode);
			exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.GENERAL_EXCEPTION);
			// exceptionTransactionModel.setResolutionRemarks("General Exception due to
			// wrong data in file");
			/*
			 * exceptionTransactionModel.setExceptionDetails(
			 * "Exception Thrown for the amadeus load Id : " +
			 * amadeusRecordStaging.getAmadeusLoadId());
			 */
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			paramValueModel = new ExceptionParametersValueModel();
			paramValueModel.setParameterName("Issue Details");
			paramValueModel.setParameterValue(AmadeusCommonUtils.getExceptionMsg(e));
			parametersValueModelList.add(paramValueModel);

			paramValueModel = new ExceptionParametersValueModel();
			paramValueModel.setParameterName("Issue Airline");
			paramValueModel.setParameterValue(amadeusRecordStaging.getIssAirline());
			parametersValueModelList.add(paramValueModel);

			paramValueModel = new ExceptionParametersValueModel();
			paramValueModel.setParameterName("Document Number");
			paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
			parametersValueModelList.add(paramValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
			// Exception logic - end
			amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
			amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
			return null;
		}
	}

	private static boolean getValidDateFormat(String format, String value) {
		Date date = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			date = sdf.parse(value);
			if (!value.equals(sdf.format(date))) {
				date = null;
			}
		} catch (ParseException ex) {
			ex.printStackTrace();
		}
		return date != null;
	}

}
