package com.sgl.smartpra.batch.amadeus.app.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStagingList;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdCouponModel;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.batch.amadeus.app.listener.ProdJobsNotificationListener;
import com.sgl.smartpra.batch.amadeus.app.listener.StgJobNotificationListener;
import com.sgl.smartpra.batch.amadeus.app.processor.FlownServiceProcessor;
import com.sgl.smartpra.batch.amadeus.app.processor.ProrationProcessor;
import com.sgl.smartpra.batch.amadeus.app.reader.SaberEmdAggregateItemReader;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.batch.amadeus.app.writer.ProrationWriter;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.repository.FlownCouponRepository;

@Configuration
@EnableBatchProcessing
public class AmadeusBatchConfiguration {

	private static final Logger LOGGER = LoggerFactory.getLogger(AmadeusBatchConfiguration.class);
	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;

	@Value("${batch.directory.amadeus.input}")
	private String batchInputDir;
	

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private FlownCouponRepository flownCouponRepository;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Autowired
	private SaberEmdAggregateItemReader saberEmdAggregateItemReader;
	
	

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setConcurrencyLimit(10);
		return taskExecutor;
	}

	@Bean
	public Job importAmadeusStgJob(StgJobNotificationListener listener, Step importAmadeusStgData) throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("importAmadeusStgJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(importAmadeusStgData).end().build();
		// @formatter:on

	}

	/*@Bean
	public Job importAmadeusETLProdJob(ProdJobsNotificationListener listener, Step importAmadeusETLTicketData,
			Step importAmadeusETLCouponData) throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("importAmadeusETLProdJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(importAmadeusETLTicketData).next(importAmadeusETLCouponData).end().build();
		// @formatter:on
	}*/

	@Bean
	public Job importAmadeusEMDProdJob(StgJobNotificationListener listener, Step amadeusEMDTicketData,
			Step amadeusEMDCouponData) throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("importAmadeusEMDProdJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(amadeusEMDTicketData).next(amadeusEMDCouponData).end().build();
		// @formatter:on
	}
	
	

	@Bean
	public Job flownServiceJob(Step flownServiceStep) throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("flownServiceJob").incrementer(new RunIdIncrementer()).flow(flownServiceStep).end()
				.build();
		// @formatter:on
	}

	@Bean
	public Job flownProrationJob(Step flownProrationStep, Step flownProrationStatusStep) throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("flownProrationJob").incrementer(new RunIdIncrementer()).flow(flownProrationStep)
				.next(flownProrationStatusStep).end().build();
		// @formatter:on
	}

	@Bean
	public Job importSaberStgJob(StgJobNotificationListener listener, Step importSaberStgData) throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("importSaberStgJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(importSaberStgData).end().build();
		// @formatter:on

	}

	@Bean
	public Job importSaberEmdStgJob(StgJobNotificationListener listener, Step importSaberEmdStgData)
			throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("importSaberEmdStgJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(importSaberEmdStgData).end().build();
		// @formatter:on

	}
	
	@Bean
	public Job importSaberXLStgJob(StgJobNotificationListener listener, Step importSaberXLStgData)
			throws IOException {
		// @formatter:off
		return jobBuilderFactory
				.get("importSaberXLStgJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(importSaberXLStgData)
				.end()
				.build();
		// @formatter:on

	}
	
	@Bean
	public Job amadeusETLResolutionJob(StgJobNotificationListener listener, Step amadeusETLResolutionForTicket,
			Step amadeusETLResolutionForCoupon) throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("amadeusETLResolutionJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(amadeusETLResolutionForTicket).next(amadeusETLResolutionForCoupon).end().build();
		// @formatter:on
	}
	
	@Bean
	public Job amadeusEMDResolutionJob(StgJobNotificationListener listener, Step amadeusEMDResolutionForTicket,
			Step amadeusEMDResolutionForCoupon) throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("amadeusEMDResolutionJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(amadeusEMDResolutionForTicket).next(amadeusEMDResolutionForCoupon).end().build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step importAmadeusStgData() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusStgRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader(stagingCommonItemReader(null, null,null,null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) stagingCommonProcessor())
				.writer((ItemWriter<? super AmadeusBatchRecord>) stagingCommonItemWriter(null, null, null)).faultTolerant()
				.skip(DataIntegrityViolationException.class).noRetry(DataIntegrityViolationException.class)
				.noRollback(DataIntegrityViolationException.class).transactionManager(transactionManager)
				.taskExecutor(taskExecutor()).build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step importSaberStgData() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("SaberStgRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader(stagingCommonItemReader(null, null,null, null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) stagingCommonProcessor())
				.writer((ItemWriter<? super AmadeusBatchRecord>) stagingCommonItemWriter(null, null, null)).faultTolerant()
				.skip(DataIntegrityViolationException.class).noRetry(DataIntegrityViolationException.class)
				// .noRollback(DataIntegrityViolationException.class)
				.transactionManager(transactionManager).taskExecutor(taskExecutor()).build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step importSaberEmdStgData() throws IOException {
		// @formatter:off
		return ((SimpleStepBuilder<AmadeusBatchRecord, AmadeusBatchRecord>) stepBuilderFactory.get("SaberEmdStgRecord")
				.<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1).reader(saberEmdAggregateItemReader)
				// .reader(stagingCommonItemReader(null, null))
				// .processor(
				// (ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>)
				// stagingCommonProcessor())
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) stagingSaberEmdProcessor())
				.writer((ItemWriter<? super AmadeusBatchRecord>) stagingSaberEmdWriter()).faultTolerant()
				.skip(DataIntegrityViolationException.class).noRetry(DataIntegrityViolationException.class)
				// .noRollback(DataIntegrityViolationException.class)
				.transactionManager(transactionManager))
						// .taskExecutor(taskExecutor())
						.build();
		// @formatter:on
	}

	@Bean
	@Scope
	public Step importSaberXLStgData() throws IOException {
		// @formatter:off
		return stepBuilderFactory
				.get("SaberXLStgRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader(stagingCommonItemReader(null, null,null,null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) stagingCommonProcessor())
				.writer((ItemWriter<? super AmadeusBatchRecord>) stagingCommonItemWriter(null, null,null))
				.faultTolerant()
				.skip(DataIntegrityViolationException.class)
				.noRetry(DataIntegrityViolationException.class)
				//.noRollback(DataIntegrityViolationException.class)
				.transactionManager(transactionManager)
				.taskExecutor(taskExecutor())
				.build();
		// @formatter:on
	}
	
	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step amadeusEMDTicketData() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusEMDTicketRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodRepositoryItemReader(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodEMDTicketProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) ticketRepositoryItemWriter())
				.transactionManager(transactionManager)
				// .taskExecutor(taskExecutor())
				.build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step amadeusEMDCouponData() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusEMDCouponRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodRepositoryItemReader(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodEMDCouponProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) couponRepositoryItemWriter())
				.transactionManager(transactionManager)
				// .taskExecutor(taskExecutor())
				.build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step amadeusETLResolutionForTicket() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusETLTicketRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodTicketRepositoryItemReaderForException(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodETLTicketProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) ticketRepositoryItemWriter())
				.transactionManager(transactionManager)
				// .taskExecutor(taskExecutor())
				.build();
		// @formatter:on
	}
	

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step amadeusETLResolutionForCoupon() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusETLCouponRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodTicketRepositoryItemReaderForException(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodETLCouponProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) couponRepositoryItemWriter())
				.transactionManager(transactionManager)
				// .taskExecutor(taskExecutor())
				.build();
		// @formatter:on

	}

	
	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step amadeusEMDResolutionForTicket() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusEmdTicketRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodTicketRepositoryItemReaderForException(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodEMDTicketProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) ticketRepositoryItemWriter())
				.transactionManager(transactionManager)
				// .taskExecutor(taskExecutor())
				.build();
		// @formatter:on
	}
	

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step amadeusEMDResolutionForCoupon() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusEMDCouponRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodTicketRepositoryItemReaderForException(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodEMDCouponProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) couponRepositoryItemWriter())
				.transactionManager(transactionManager)
				// .taskExecutor(taskExecutor())
				.build();
		// @formatter:on

	}
	
	
	
	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step flownServiceStep() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("flownServiceStep").<FlownCoupon, FlownCoupon>chunk(1)
				.reader(flownValidationReader(null))
				.processor((ItemProcessor<? super FlownCoupon, ? extends FlownCoupon>) flownServiceProcessor())
				.transactionManager(transactionManager).taskExecutor(taskExecutor()).throttleLimit(10).build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step flownProrationStep() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("flownProrationStep").<FlownCoupon, FlownCoupon>chunk(1)
				.reader(flownProrationReader(null))
				.processor((ItemProcessor<? super FlownCoupon, ? extends FlownCoupon>) prorationProcessor())
				.transactionManager(transactionManager).taskExecutor(taskExecutor()).throttleLimit(10).build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step flownProrationStatusStep() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("flownProrationStatusStep").<FlownCoupon, FlownCoupon>chunk(1)
				.reader(flownProrationReader(null)).writer(proraraionItemWriter())
				.transactionManager(transactionManager).taskExecutor(taskExecutor()).throttleLimit(10).build();
		// @formatter:on
	}

	@SuppressWarnings("resource")
	@Bean
	@StepScope
	public FlatFileItemReader<AmadeusBatchRecord> stagingCommonItemReader(
			@Value("#{jobParameters[inboundFileName]}") String fileName,
			@Value("#{jobParameters[amadeusVersion]}") String amadeusVersion,
			@Value("#{jobParameters[saberVersion]}") String saberVersionCheck,
			@Value("#{jobParameters[fileType]}") String fileType) throws IOException {
		LOGGER.info("Build Amadeus Item Reader File Name : {}", fileName);
		FlatFileItemReader<AmadeusBatchRecord> reader = new FlatFileItemReader<AmadeusBatchRecord>();
		List<String> linesList = new ArrayList<String>();
		reader.setResource(new FileSystemResource(batchInputDir + "/" + fileName));
		// reader.setSaveState(false);
		LineTokenizer lineTokenizer = null;
		if (fileType.contains(AppConstants.FILE_TYPE_IDENTIFICATION_STRING_SABER_XL)){
			LOGGER.info("Config Using Tokenizer for saber Tokenzier");
			lineTokenizer = (new AmadeusRecordStaging()).saberXLTokenizer();
			reader.setLineMapper(saberXLLineMapper(lineTokenizer));
		}else if (amadeusVersion.contains(AppConstants.EMD_Version_01_01)) {
			LOGGER.info("Config Using Tokenizer for EMD Version 1.01 Tokenzier");
			lineTokenizer = (new AmadeusRecordStaging()).emdV1_01Tokenizer();
			reader.setLineMapper(amadeusLineMapper(lineTokenizer));
		} else if (amadeusVersion.contains(AppConstants.ETL_Version_2_20)) {
			LOGGER.info("Config Using Tokenizer for ETL Version 2.20 Tokenzier");
			lineTokenizer = (new AmadeusRecordStaging()).lineTokenizer();
			reader.setLineMapper(amadeusLineMapper(lineTokenizer));
		} else if (amadeusVersion.contains(AppConstants.EMD_Version_01_03)) {
			LOGGER.info("Config Using Tokenizer for EMD Version 1.03 Tokenzier");
			lineTokenizer = (new AmadeusRecordStaging()).emdV1_03Tokenizer();
			reader.setLineMapper(amadeusLineMapper(lineTokenizer));
		} else if (amadeusVersion.contains(AppConstants.EMD_Version_01_00)) {
			LOGGER.info("Config Using Tokenizer for EMD Version 1.00 Tokenzier");
			lineTokenizer = (new AmadeusRecordStaging()).emdV1_00Tokenizer();
			reader.setLineMapper(amadeusLineMapper(lineTokenizer));
		} else if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
			Integer length=Integer.parseInt(saberVersionCheck);
			if (length <= AppConstants.SABER_VCR_OLD_VERSION_LENGTH) {
				LOGGER.info("Config Using Tokenizer for saber with old Version having total length##########"+length);
				lineTokenizer = (new AmadeusRecordStaging()).saberOldTokenizer();
			} else if (length > AppConstants.SABER_VCR_NEW_VERSION_LENGTH) {
				LOGGER.info("Config Using Tokenizer for saber With Latest Version having total length##########"+length);
				lineTokenizer = (new AmadeusRecordStaging()).saberTokenizer();
			}
			reader.setLineMapper(saberLineMapper(lineTokenizer));
		} else {
			throw new BeanInitializationException("Unsupported File");
		}
		// reader.setLinesToSkip(1);
		// reader.setLineMapper(amadeusLineMapper(lineTokenizer));
		// reader.setRecordSeparatorPolicy(new IgnoreBlankLinePolicy(linesList));
		return reader;
	}

	@Bean
	@StepScope
	public ItemReader<? extends AmadeusBatchRecord> prodTicketRepositoryItemReader(
			@Value("#{jobParameters[inboundFileId]}") Integer fileId) throws IOException {
		RepositoryItemReader<AmadeusRecordStaging> reader = new RepositoryItemReader<AmadeusRecordStaging>();
		ArrayList<Integer> arguments = new ArrayList<Integer>();
		arguments.add(fileId);
		reader.setRepository(amadeusRecordStagingRepository);
		reader.setMethodName("findByFileId");
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("documentNumber", Direction.ASC);
		reader.setSort(map);
		return reader;
	}

	@Bean
	@StepScope
	public ItemReader<? extends FlownCoupon> flownValidationReader(
			@Value("#{jobParameters[inboundFileId]}") Integer fileId) throws IOException {
		RepositoryItemReader<FlownCoupon> reader = new RepositoryItemReader<FlownCoupon>();
		ArrayList<Object> arguments = new ArrayList<Object>();
		// arguments.add("RV");
		arguments.add(fileId);
		reader.setRepository(flownCouponRepository);
		reader.setMethodName("findByFileId");
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("flownCpnId", Direction.ASC);
		reader.setSort(map);
		return reader;
	}

	@Bean
	@StepScope
	public ItemReader<? extends FlownCoupon> flownProrationReader(
			@Value("#{jobParameters[inboundFileId]}") Integer fileId) throws IOException {
		RepositoryItemReader<FlownCoupon> reader = new RepositoryItemReader<FlownCoupon>();
		ArrayList<Object> arguments = new ArrayList<Object>();
		arguments.add(fileId);
		reader.setRepository(flownCouponRepository);
		reader.setMethodName("findCouponForProration");
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("flownCpnId", Direction.ASC);
		reader.setSort(map);
		return reader;
	}

	@Bean
	@StepScope
	public ItemReader<? extends AmadeusBatchRecord> prodRepositoryItemReader(
			@Value("#{jobParameters[inboundFileId]}") Integer fileId) throws IOException {
		RepositoryItemReader<AmadeusRecordStaging> reader = new RepositoryItemReader<AmadeusRecordStaging>();
		ArrayList<Object> arguments = new ArrayList<Object>();
		arguments.add(fileId);
		arguments.add(AppConstants.STG_STATUS_LOADED);
		reader.setRepository(amadeusRecordStagingRepository);
		reader.setMethodName("findByFileIdAndStatus");
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("documentNumber", Direction.ASC);
		reader.setSort(map);
		return reader;
	}
	
	
	

	@Bean
	@StepScope
	public ItemReader<? extends AmadeusBatchRecord> prodTicketRepositoryItemReaderForException(
			@Value("#{jobParameters[amadeusLoadId]}") Integer amadeusLoadId) throws IOException {
		RepositoryItemReader<AmadeusRecordStaging> reader = new RepositoryItemReader<AmadeusRecordStaging>();
		ArrayList<Integer> arguments = new ArrayList<Integer>();
		arguments.add(amadeusLoadId);
		reader.setRepository(amadeusRecordStagingRepository);
		reader.setMethodName("findByAmadeusLoadId");
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("documentNumber", Direction.ASC);
		reader.setSort(map);
		return reader;
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> prodETLTicketProcessor() {
		return new ProdTicketModel().prodProcessor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> prodEMDTicketProcessor() {
		return new ProdTicketModel().prodEmdTicketProcessor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> prodETLCouponProcessor() {
		return new ProdCouponModel().prodETLCouponProcessor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> prodEMDCouponProcessor() {
		return new ProdCouponModel().prodEMDCouponProcessor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends FlownCoupon, ? extends FlownCoupon> flownServiceProcessor() {
		return new FlownServiceProcessor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends FlownCoupon, ? extends FlownCoupon> prorationProcessor() {
		return new ProrationProcessor();
	}

	@Bean
	@StepScope
	ItemWriter<? super AmadeusBatchRecord> ticketRepositoryItemWriter() {
		return new ProdTicketModel().writer();
	}

	@Bean
	@StepScope
	ItemWriter<? super AmadeusBatchRecord> couponRepositoryItemWriter() {
		return new ProdCouponModel().prodETLCouponWriter();
	}

	@Bean
	@StepScope
	ItemWriter<? super FlownCoupon> proraraionItemWriter() {
		return new ProrationWriter();
	}

	@Bean
	@StepScope
	ItemWriter<? super AmadeusBatchRecord> stagingSaberEmdWriter() {
		return new AmadeusRecordStagingList().writer();
	}

	public LineMapper<AmadeusBatchRecord> amadeusLineMapper(LineTokenizer lineTokenizer) {
		LOGGER.info("Build amadeusLineMapper");
		PatternMatchingCompositeLineMapper<AmadeusBatchRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<>();
		tokenizers.put("1*", lineTokenizer);
		tokenizers.put("2*", lineTokenizer);
		tokenizers.put("9*", lineTokenizer);
		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<AmadeusBatchRecord>> mappers = new HashMap<>();
		mappers.put("1*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("2*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("9*", (new AmadeusRecordStaging()).fieldSetMapper());

		mapper.setFieldSetMappers(mappers);
		return mapper;
	}

	public LineMapper<AmadeusBatchRecord> saberLineMapper(LineTokenizer lineTokenizer) {
		LOGGER.info("Build saberLineMapper");
		PatternMatchingCompositeLineMapper<AmadeusBatchRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<>();
		tokenizers.put("A*", lineTokenizer);
		tokenizers.put("B*", lineTokenizer);
		tokenizers.put("C*", lineTokenizer);
		tokenizers.put("D*", lineTokenizer);
		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<AmadeusBatchRecord>> saberMappers = new HashMap<>();
		saberMappers.put("A*", (new AmadeusRecordStaging()).fieldSetMapper());
		saberMappers.put("B*", (new AmadeusRecordStaging()).fieldSetMapper());
		saberMappers.put("C*", (new AmadeusRecordStaging()).fieldSetMapper());
		saberMappers.put("D*", (new AmadeusRecordStaging()).fieldSetMapper());
		mapper.setFieldSetMappers(saberMappers);
		return mapper;
	}
	
	public LineMapper<AmadeusBatchRecord> saberXLLineMapper(LineTokenizer lineTokenizer) {
		LOGGER.info("Build saberXL LineMapper");
		PatternMatchingCompositeLineMapper<AmadeusBatchRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<>();
		tokenizers.put("A*", lineTokenizer);
		tokenizers.put("XL*", lineTokenizer);
		tokenizers.put("Z*", lineTokenizer);
		mapper.setTokenizers(tokenizers);


		Map<String, FieldSetMapper<AmadeusBatchRecord>> saberMappers = new HashMap<>();
		saberMappers.put("A*", (new AmadeusRecordStaging()).fieldSetMapper());
		saberMappers.put("XL*", (new AmadeusRecordStaging()).fieldSetMapper());
		saberMappers.put("Z*", (new AmadeusRecordStaging()).fieldSetMapper());
		mapper.setFieldSetMappers(saberMappers);
		return mapper;
	}

	@SuppressWarnings("unused")
	@Bean
	@StepScope
	public ItemWriter<? super AmadeusBatchRecord> stagingCommonItemWriter(
			@Value("#{jobParameters[inboundFileName]}") String fileName,
			@Value("#{jobParameters[amadeusVersion]}") String amadeusVersion,
			@Value("#{jobParameters[fileType]}") String fileType) throws IOException {
		LOGGER.info("Build Item Writer File Name : {}", fileName);
		if (amadeusVersion.contains(AppConstants.EMD_Version_01_01)) {
			LOGGER.info("Config EMD Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().amadeusEmdV1_01writer();
		} else if (amadeusVersion.contains(AppConstants.ETL_Version_2_20)) {
			LOGGER.info("Config ETL Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().amadeusEtlV2_20writer();
		} else if (amadeusVersion.contains(AppConstants.EMD_Version_01_03)) {
			LOGGER.info("Config ETL Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().amadeusEmdV1_03writer();
		} else if (amadeusVersion.contains(AppConstants.EMD_Version_01_00)) {
			LOGGER.info("Config ETL Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().amadeusEmdV1_00writer();
		} else if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
			LOGGER.info("Config saber Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().saber_01writer();
		}else if (fileType.contains(AppConstants.FILE_TYPE_IDENTIFICATION_STRING_SABER_XL)) {
			LOGGER.info("Config saber XL Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().saber_01writer();
		}
		return null;
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> stagingCommonProcessor() {
		return new AmadeusRecordStaging().processor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> stagingSaberEmdProcessor() {
		return new AmadeusRecordStagingList().processor();
	}

}
