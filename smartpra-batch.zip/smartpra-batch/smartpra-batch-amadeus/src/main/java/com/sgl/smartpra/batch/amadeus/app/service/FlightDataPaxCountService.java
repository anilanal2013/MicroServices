package com.sgl.smartpra.batch.amadeus.app.service;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.flown.repository.FlightDataDetailsRepository;
import com.sgl.smartpra.flown.repository.FlownCouponRepository;

@Service
public class FlightDataPaxCountService {

	@Autowired
	FlownCouponRepository flownCouponRepository;

	@Autowired
	FlightDataDetailsRepository flightDataDetailsRepository;

	public void updateFlightDataDetail(BigInteger fileId, String documentType) {
		Integer flightKey;
		Integer couCount;
		for (Object[] couRec : flownCouponRepository.getFlownCoupon(fileId, documentType)) {
			flightKey = Integer.parseInt(String.valueOf(couRec[0]));
			couCount = Integer.parseInt(String.valueOf(couRec[1]));
			flightDataDetailsRepository.updateFlightDataDetail(flightKey, couCount);

		}
	}

}
