package com.sgl.smartpra.batch.amadeus.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class StagingETLV2_20Layout extends FixedLengthRecordLayout{

    public StagingETLV2_20Layout(){
    	
    	 fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType",1,1));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline",2,4));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber",5,14));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit",15,15));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber",16,16));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("localDepartureDate",17,22));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightNumber",23,27));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usedCabinClass",28,29));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageType",36,36));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageAirline",37,40));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageMarketingFlightNumber",41,45));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageLocalFlightDate",46,51));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldLocalDepartDate",52,57));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldOriginCode",58,62));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldDestinationCode",63,67));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOriginCode",68,72));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDestinationCode",73,77));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reportedFare",78,89));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfReportedFare",90,92));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("equivalentFare",93,104));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("PaymentCurrency",105,107));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("agencyNumber",108,114));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issueDate",116,121));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageUtcFlightDate",128,133));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bookingReference",134,139));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tourCode",140,153));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageMarketingCarrierCode",154,156));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingCarrier",154,156));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("passengerName",157,196));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthorizationCode",197,211));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDocNumber",212,251));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("coupons",252,1243));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareConstruction",1244,1593));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("newTax",1594,2979));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdDocumentAmount", 4366, 4377));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdDocumentAmountCurrency", 4378, 4380));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ticketingModeIndicator",4381,4381));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netRemitIndicator",4382,4382));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commissionRate",4383,4387));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commissionAmount",4388,4399));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfCommissionAmount",4400,4402));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalIssueInformation",4494,4563));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfPayment",4564,4590));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("internationalSaleIndicaor",4726,4729));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("endorsementRestrictionText",4730,5359));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("amountEnteredByAgent",5360,5371));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionTotalAmount",5375,5386));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfTransTotalAmt",5387,5389));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("additionalCollectionTotal",5390,5401));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareCalcModeIndicator",5405,5407));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("approvedCollectionCode",5408,5413));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bankersExchangeRate",5444,5455));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentType",5456,5456));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonEndorsableIndicator",5457,5457));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonRefundableIndicator",5458,5458));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("penaltyRestrictionIndicator",5459,5459));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",5460,null));
         
         
         
       
    }
}
