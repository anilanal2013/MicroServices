package com.sgl.smartpra.batch.amadeus.app.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.amadeus.app.common.AmadeusRecCounts;
import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.common.DocumentIdsReader;
import com.sgl.smartpra.batch.amadeus.app.common.DocumentIdsWriter;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.ExceptionTxnFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.FlownFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.batch.amadeus.app.utils.AmadeusCommonUtils;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.ExceptionCodeConstants;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

@Service
public class AmadeusBatchJobService {
	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	@Qualifier(value = "importAmadeusStgJob")
	Job importAmadeusStgJob;

	/*@Autowired
	@Qualifier(value = "importAmadeusETLProdJob")
	Job importAmadeusETLProdJob;*/

	@Autowired
	@Qualifier(value = "importAmadeusEMDProdJob")
	Job importAmadeusEMDProdJob;
	

	@Autowired
	@Qualifier(value = "flownServiceJob")
	Job flownServiceJob;

	@Autowired
	@Qualifier(value = "flownProrationJob")
	Job flownProrationJob;

	@Autowired
	@Qualifier(value = "importSaberStgJob")
	Job importSaberStgJob;

	@Autowired
	@Qualifier(value = "importSaberEmdStgJob")
	Job importSaberEmdStgJob;

	@Autowired
	@Qualifier(value = "importSaberXLStgJob")
	private Job importSaberXLStgJob;
	
	@Autowired
	@Qualifier(value = "amadeusETLResolutionJob")
	private Job amadeusETLResolutionJob;

	@Autowired
	@Qualifier(value = "amadeusEMDResolutionJob")
	private Job amadeusEMDResolutionJob;
	

	@Value("${batch.directory.amadeus.duplicate}")
	private String batchDuplicateDir;

	@Value("${batch.directory.amadeus.input}")
	private String batchInputDir;

	@Value("${batch.directory.amadeus.failed}")
	private String batchFailedDir;

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	FlownFeignClient flownFeignClient;

	@Autowired
	FlightDataPaxCountService flightDataPaxCountService;

	@Autowired
	private ExceptionTxnFeignClient exceptionTxnFeignClient;

	@Autowired
	AmadeusRecordStagingRepository stgRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(AmadeusBatchJobService.class);

	private SmartpraFileUtility smartpraFileUtility = new SmartpraFileUtility();

	/**
	 * This method is used to invoke the batch job to parse the input flat file and
	 * store it into DB(Staging and then Production for ETL & EMD).
	 * 
	 * @param inboundFileName
	 * @return
	 * @throws Exception
	 */
	public String executeAmadeusBatchLoad(String inboundFileName, String processedBy, String fileType)
			throws Exception {

		String pax = "PAX";
		// File not found while invoking this service from controller.
		if (!smartpraFileUtility.fileExists(batchInputDir + inboundFileName)) {
			return "Batch input file not found (" + batchInputDir + inboundFileName + ")";
		}
		ExceptionTransactionModel exceptionTransactionModel;
		List<ExceptionParametersValueModel> parametersValueModelList;
		ExceptionParametersValueModel paramValueModel;
		String fileFirstLine = smartpraFileUtility.readFirstLine(batchInputDir + "/" + inboundFileName);
		String saberVersionCheck = smartpraFileUtility.readLineForSaber(batchInputDir + "/" + inboundFileName);
		String hostCarrDesigCode = AmadeusCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		String hostCarrDesigCodeForSabre = AmadeusCommonUtils.getHostCarrierDesigCodeForSabre(masterFeignClient);
		String hostCarrierCode = AmadeusCommonUtils.getHostCarrierCode(masterFeignClient);
		String hostCarrierCodeForSabre = AmadeusCommonUtils.getHostCarrierCodeForSabre(masterFeignClient);
		String flightCreationFromFlownForAmadeus = AmadeusCommonUtils
				.getFlightCreationFromFlownForQatar(masterFeignClient);
		String flightCreationFromFlownForSabre = AmadeusCommonUtils
				.getFlightCreationFromFlownForOman(masterFeignClient);
		String flightNoLen = AmadeusCommonUtils.getFlightNumberOption(masterFeignClient);
		String validDtReqOut = AmadeusCommonUtils.validateDtRequestOut(masterFeignClient);
		String dtStr = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		FileLogging fileLogging = AmadeusCommonUtils.initFileLogging();
		fileLogging.setModuleName("FLOWN"); // NEED TO BE DERIVED FROM LOV TABLE
		fileLogging.setClientId(hostCarrDesigCode);
		fileLogging.setFileName(inboundFileName);
		fileLogging.setProcessedBy(processedBy);
		if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)
				|| fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {
			fileLogging.setJobName(importAmadeusStgJob.getName());
		}
		if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
			fileLogging.setJobName(importSaberStgJob.getName());
		}
		if (fileType.contains(AppConstants.FILE_TYPE_IDENTIFICATION_STRING_SABER_XL)) {
			fileLogging.setJobName(importSaberXLStgJob.getName());
		}

		fileLogging.setFileSize(SmartpraFileUtility.getFileSize(batchInputDir + inboundFileName));
		if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_AMADEUS_ETL_IN);
		}
		if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_AMADEUS_EMD_IN);
		}

		if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_SABER_IN);
		}

		if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER_EMD)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_SABER_EMD__IN);
		}
		if (fileType.contains(AppConstants.SABRE_XL)) {
			fileLogging.setFileType(FileLoggingConstants.FILE_LOGGING_FILE_TYPE_SABER_XL_IN);
		}
		FileErrorLog fileErrorLog;
		ArrayList<FileErrorLog> fileErrorLogList;

		// IF file is empty
		if (SmartpraFileUtility.isEmptyFile(batchInputDir + inboundFileName)) {
			String errorMsg = "Input file " + batchInputDir + inboundFileName + " is empty....";
			SmartpraFileUtility.moveFile(batchInputDir + inboundFileName, batchFailedDir + inboundFileName + dtStr);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setRemarks(errorMsg);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("File is empty");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<FileErrorLog>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)
					|| fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {
				fileLogging.setFileType(AppConstants.AMADEUS);
			}
			if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
				fileLogging.setFileType(AppConstants.SABRE);
			}
			if (fileType.contains(AppConstants.FILE_TYPE_IDENTIFICATION_STRING_SABER_XL)) {
				fileLogging.setFileType(AppConstants.SABRE);
			}
			if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER_EMD)) {
				fileLogging.setFileType(AppConstants.SABER_EMD);
			}
			System.out.println("file log values" + fileLogging.toString());
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}
		if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_AMADEUS_ETL_IN);
		} else if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_AMADEUS_EMD_IN);
		} else if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_SABER_IN);
		} else if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_SABER_IN);
		} else if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER_EMD)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_SABER_EMD__IN);
		} else if (fileType.contains(AppConstants.FILE_TYPE_IDENTIFICATION_STRING_SABER_XL)) {
			fileLogging.setFileType(FileLoggingConstants.FILE_LOGGING_FILE_TYPE_SABER_XL_IN);
		}

		else {
			String errorMsg = "Amadeus filetype not identified from the first line (ETL Ref: "
					+ AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL + " or EMD Ref: "
					+ AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD + " or SABER Ref: "
					+ AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER + "or Saber Emd Ref"
					+ AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER_EMD + ")";
			SmartpraFileUtility.moveFile(batchInputDir + inboundFileName, batchFailedDir + inboundFileName + dtStr);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setRemarks(errorMsg);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Amadeus file type not identified (ETL/EMD)");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<FileErrorLog>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)
					|| fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {
				fileLogging.setFileType("AMADEUS");
			}
			if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
				fileLogging.setFileType("SABRE");
			}

			if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER_EMD)) {
				fileLogging.setFileType("SABRE_EMD_USED");
			}
			if (fileType.contains(AppConstants.FILE_TYPE_IDENTIFICATION_STRING_SABER_XL)) {
				fileLogging.setFileType(AppConstants.SABRE);
			}
			System.out.println("fileeee" + fileLogging.toString());
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}
		/*
		 * //File prefix check with host carrier code
		 * if(!fileUtil.isValidFile(hostCarrDesigCode, inboundFileName,
		 * OneWorldConstants.ESAL_FILENAME_CONSTANT)) { String errorMsg = "Input file "+
		 * inboundFileName
		 * +" invalid (file name pattern should be XXESAL2CC_YYYYMMDD_HHMM.txt)" ;
		 * OneWorldFileValidationsUtil.moveFile(batchInputDir + inboundFileName,
		 * batchFailedDir + inboundFileName + dtStr);
		 * fileLogging.setFileStatus(OneWorldConstants.FILELOGGING_FILESTATUS_ERRORED);
		 * fileLogging.setRemarks(errorMsg);
		 * fileLogging.setIsMovedToRelevantFolder("Y"); fileErrorLog = new
		 * FileErrorLog(); fileErrorLog.setFileId(fileLogging.getFileId());
		 * fileErrorLog.setErrorDetail("Invalid File Input");
		 * fileErrorLog.setErrorDescription(errorMsg); fileErrorLogList = new
		 * ArrayList(); fileErrorLogList.add(fileErrorLog);
		 * fileLogging.setFileErrorLog(fileErrorLogList); fileLogging =
		 * batchGlobalFeignClient.createFileLog(fileLogging); return errorMsg; } //File
		 * duplicate check List<FileLogging> fileList =
		 * batchGlobalFeignClient.getFileLogByFileName(inboundFileName); if(fileList
		 * !=null && fileList.size()>0) { String errorMsg = "Input file "+
		 * inboundFileName +" duplicated with fileID " + fileList.get(0).getFileId();
		 * OneWorldFileValidationsUtil.moveFile(batchInputDir + inboundFileName,
		 * batchDuplicateDir + inboundFileName + dtStr);
		 * fileLogging.setFileStatus(OneWorldConstants.FILELOGGING_FILESTATUS_DUPLICATE)
		 * ; fileLogging.setRemarks(errorMsg);
		 * fileLogging.setIsMovedToRelevantFolder("Y"); fileErrorLog = new
		 * FileErrorLog(); fileErrorLog.setFileId(fileLogging.getFileId());
		 * fileErrorLog.setErrorDetail("Invalid File Input");
		 * fileErrorLog.setErrorDescription(errorMsg); fileErrorLogList = new
		 * ArrayList(); fileErrorLogList.add(fileErrorLog);
		 * fileLogging.setFileErrorLog(fileErrorLogList); fileLogging =
		 * batchGlobalFeignClient.createFileLog(fileLogging); return
		 * "Batch ESAL-IN job not started because the file already loaded into the system (Duplicate file loading).."
		 * ; }
		 * 
		 */

		fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
		AmadeusRecCounts.resetCounts();
		DocumentIdsWriter.clear();
		DocumentIdsReader.clear();
		// Loading the data into staging irrespective of E
		// @formatter:off

		if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)
				|| fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {
			if (fileFirstLine.contains(hostCarrDesigCode)) {
				LOGGER.info(
						"Recieved Career Code Is Matches with Host Carreer Code####" + fileFirstLine.substring(1, 3));

				JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
						.addString("inboundFileName", fileLogging.getFileName())
						.addLong("inboundFileId", fileLogging.getFileId().longValue())
						.addString("carrieNumericCode", hostCarrierCode).addString("fileType", fileType)
						.addString("careerDesignatorCode", hostCarrDesigCode).addString("flightNoLen", flightNoLen)
						.addString("flightCreationFromFlown", flightCreationFromFlownForAmadeus)
						.addString("amadeusVersion", fileFirstLine.substring(25)).toJobParameters();
				// @formatter:oN
				JobExecution jobExecution = jobLauncher.run(importAmadeusStgJob, jobParameters);
				if (jobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
					LOGGER.info(
							"Batch Amadeus-IN job for staging completed successfully and Production load job triggered.......");
					if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)) {

						LOGGER.info("Triggering Actual Pax Count Calculation(including flight status)");
						flightDataPaxCountService.updateFlightDataDetail(fileLogging.getFileId(), pax);
//					LOGGER.info("Triggering Flown Coupon Validation start");
//					flownFeignClient.validateCouponsForFileId((fileLogging.getFileId().intValue()));
//					LOGGER.info("Triggering Flown Coupon Validation end");
						return "Batch Amadeus-IN Job invoked and load data into staging and ETL production load completed successfully.... (File Id : "
								+ fileLogging.getFileId().longValue() + ")";

						// @formatter:off

						/*
						 * jobParameters = new JobParametersBuilder().addLong("time",
						 * System.currentTimeMillis()) .addString("inboundFileName",
						 * fileLogging.getFileName()) .addLong("inboundFileId",
						 * fileLogging.getFileId().longValue()) .addString("carrieNumericCode",
						 * hostCarrierCode) .addString("careerDesignatorCode",
						 * hostCarrDesigCode).addString("flightNoLen", flightNoLen)
						 * .addString("validDtReqOut", validDtReqOut) .addString("amadeusVersion",
						 * fileFirstLine.substring(25)).toJobParameters(); // @formatter:oN JobExecution
						 * prodJobExecution = jobLauncher.run(importAmadeusETLProdJob, jobParameters);
						 * if (prodJobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
						 * 
						 * LOGGER.
						 * info("Triggering Actual Pax Count Calculation(including flight status)");
						 * 
						 * flightDataPaxCountService.updateFlightDataDetail(fileLogging.getFileId(),
						 * pax);
						 * 
						 * LOGGER.info("Triggering Flown Coupon Validation start");
						 * 
						 * flownFeignClient.validateCouponsForFileId((fileLogging.getFileId().intValue()
						 * ));
						 * 
						 * LOGGER.info("Triggering Flown Coupon Validation end");
						 * 
						 * return
						 * "Batch Amadeus-IN Job invoked and load data into staging and ETL production load completed successfully...."
						 * ; } else { return
						 * "Batch Amadeus-IN Job invoked and load data into staging completed but ETL production load failed....."
						 * ; }
						 * 
						 */

					} else if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {
						// @formatter:off
						jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
								.addString("inboundFileName", fileLogging.getFileName())
								.addLong("inboundFileId", fileLogging.getFileId().longValue())
								.addString("carrieNumericCode", hostCarrierCode).addString("fileType", fileType)
								.addString("careerDesignatorCode", hostCarrDesigCode)
								.addString("flightNoLen", flightNoLen)
								.addString("flightCreationFromFlown", flightCreationFromFlownForAmadeus)
								.addString("amadeusVersion", fileFirstLine.substring(25)).toJobParameters();
						// @formatter:oN
						JobExecution prodJobExecution = jobLauncher.run(importAmadeusEMDProdJob, jobParameters);
						if (prodJobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
							LOGGER.info("Amadeus load completed successfully");
							//flownFeignClient.validateCouponsForFileId((fileLogging.getFileId().intValue()));
							return "Batch Amadeus-IN Job invoked and load data into staging and EMD production load completed successfully.... (File Id : "
									+ fileLogging.getFileId().longValue() + ")";
						} else {
							return "Batch Amadeus-IN Job invoked and load data into staging completed but EMD production load failed..... (File Id : "
									+ fileLogging.getFileId().longValue() + ")";
						}
					} else {
						return "Batch Amadeus-IN Job invoked and load data into staging completed but loading into production failed due to unidentified filetype..... (File Id : "
								+ fileLogging.getFileId().longValue() + ")";
					}
				}

			} else {
				LOGGER.info("Exception Triggering Because of Wrong Carrer code  Appeared in  Amadeus Recieved File"
						+ fileFirstLine.substring(1, 3));
				exceptionTransactionModel = AmadeusCommonUtils
						.initExceptionTransactionModelForFileIssue(fileFirstLine.substring(25));
				exceptionTransactionModel.setClientId(hostCarrDesigCode);
				exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_WRONG_FILE);

				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Carrier code");
				paramValueModel.setParameterValue(fileFirstLine.substring(1, 3));
				parametersValueModelList.add(paramValueModel);

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("File name");
				paramValueModel.setParameterValue(fileLogging.getFileName());
				parametersValueModelList.add(paramValueModel);

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Carreir code");
				paramValueModel.setParameterValue(hostCarrDesigCode);
				parametersValueModelList.add(paramValueModel);

				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
				// Exception logic - end
				// amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				AmadeusRecCounts.incErrorCount();
				return " Wrong Carrier Code Recieved In AMADEUS ETL/EMD   (Career Code From File : "
						+ fileFirstLine.substring(1, 3) + ")";
			}
		} else if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {
			LOGGER.info("Triggering Saber Loading");
			if (fileFirstLine.contains(hostCarrDesigCodeForSabre)) {
				LOGGER.info(
						"Recieved Career Code Is Matches with Host Carreer Code####" + fileFirstLine.substring(1, 3));
				// @formatter:off
				JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
						.addString("inboundFileName", fileLogging.getFileName())
						.addLong("inboundFileId", fileLogging.getFileId().longValue())
						.addString("carrieNumericCode", hostCarrierCodeForSabre).addString("fileType", fileType)
						.addString("careerDesignatorCode", hostCarrDesigCodeForSabre)
						.addString("flightNoLen", flightNoLen).addString("amadeusVersion", fileFirstLine.substring(25))
						.addString("flightCreationFromFlown", flightCreationFromFlownForSabre)
						.addString("saberVersion", saberVersionCheck).toJobParameters();
				// @formatter:oN
				JobExecution prodJobExecution = jobLauncher.run(importSaberStgJob, jobParameters);
				if (prodJobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
					LOGGER.info("Amadeus load completed successfully");
					// flownFeignClient.validateCouponsForFileId((fileLogging.getFileId().intValue()));
					return "Batch Saber-IN Job invoked and load data into staging and Saber production load completed successfully.... (File Id : "
							+ fileLogging.getFileId().longValue() + ")";
				} else {
					return "Batch Saber-IN Job invoked and load data into staging completed but Saber production load failed..... (File Id : "
							+ fileLogging.getFileId().longValue() + ")";
				}
			} else {
				LOGGER.info("Exception Triggering Because of Wrong Carrer code  Appeared in Sabre   Recieved File"
						+ fileFirstLine.substring(1, 3));
				exceptionTransactionModel = AmadeusCommonUtils
						.initExceptionTransactionModelForFileIssue(fileFirstLine.substring(25));
				exceptionTransactionModel.setClientId(hostCarrDesigCodeForSabre);
				exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_WRONG_FILE);

				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Carrier code");
				paramValueModel.setParameterValue(fileFirstLine.substring(1, 3));
				parametersValueModelList.add(paramValueModel);

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("File name");
				paramValueModel.setParameterValue(fileLogging.getFileName());
				parametersValueModelList.add(paramValueModel);

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Carreir code");
				paramValueModel.setParameterValue(hostCarrDesigCodeForSabre);
				parametersValueModelList.add(paramValueModel);

				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
				// Exception logic - end
				// amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				AmadeusRecCounts.incErrorCount();
				return " Wrong Carrier Code Recieved In Sabre    (Career Code From File : "
						+ fileFirstLine.substring(1, 3) + ")";
			}
		} else if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER_EMD)) {
			LOGGER.info("Triggering Saber EMD_USED Loading");
			if (fileFirstLine.contains(hostCarrDesigCodeForSabre)) {
				LOGGER.info(
						"Recieved Career Code Is Matches with Host Carreer Code####" + fileFirstLine.substring(1, 3));
				// @formatter:off
				JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
						.addString("inboundFileName", fileLogging.getFileName())
						.addLong("inboundFileId", fileLogging.getFileId().longValue())
						.addString("carrieNumericCode", hostCarrierCodeForSabre)
						.addString("careerDesignatorCode", hostCarrDesigCodeForSabre)
						.addString("flightNoLen", flightNoLen).addString("fileType", fileType)
						.addString("flightCreationFromFlown", flightCreationFromFlownForSabre)
						.addString("amadeusVersion", fileFirstLine.substring(13)).toJobParameters();
				LOGGER.info("amadeus version------------>" + fileFirstLine.substring(13));
				// @formatter:oN
				JobExecution prodJobExecution = jobLauncher.run(importSaberEmdStgJob, jobParameters);
				if (prodJobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
					LOGGER.info("Triggering Flown Coupon Validation");
					// flownFeignClient.validateCouponsForFileId((fileLogging.getFileId().intValue()));
					return "Batch Saber-IN Job invoked and load data into staging and Saber production load completed successfully....(File Id : "
							+ fileLogging.getFileId().longValue() + ")";
				} else {
					return "Batch Saber-IN Job invoked and load data into staging completed but Saber production load failed.....(File Id : "
							+ fileLogging.getFileId().longValue() + ")";
				}
			} else {
				LOGGER.info(
						"Exception Triggering Because of Wrong Carrer code  Appeared in Sabre EMD_USED Recieved File"
								+ fileFirstLine.substring(1, 3));
				exceptionTransactionModel = AmadeusCommonUtils
						.initExceptionTransactionModelForFileIssue(fileFirstLine.substring(13));
				exceptionTransactionModel.setClientId(hostCarrDesigCodeForSabre);
				exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_WRONG_FILE);

				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Carrier code");
				paramValueModel.setParameterValue(fileFirstLine.substring(1, 3));
				parametersValueModelList.add(paramValueModel);

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("File name");
				paramValueModel.setParameterValue(fileLogging.getFileName());
				parametersValueModelList.add(paramValueModel);

				paramValueModel = new ExceptionParametersValueModel();
				paramValueModel.setParameterName("Carreir code");
				paramValueModel.setParameterValue(hostCarrDesigCodeForSabre);
				parametersValueModelList.add(paramValueModel);

				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
				// Exception logic - end
				// amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				AmadeusRecCounts.incErrorCount();
				return " Wrong Carrier Code Recieved In Sabre EMD_USED   (Career Code From File : "
						+ fileFirstLine.substring(1, 3) + ")";
			}

		} else if (fileType.contains(AppConstants.FILE_TYPE_IDENTIFICATION_STRING_SABER_XL)) {
			LOGGER.info("Triggering Saber XL Loading");
			// @formatter:of
			JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
					.addString("inboundFileName", fileLogging.getFileName())
					.addLong("inboundFileId", fileLogging.getFileId().longValue())
					.addString("carrieNumericCode", hostCarrierCode)
					.addString("careerDesignatorCode", hostCarrDesigCode).addString("flightNoLen", flightNoLen)
					.addString("fileType", fileType).addString("amadeusVersion", fileFirstLine.substring(25))
					.toJobParameters();
			// @formatter:oN
			JobExecution prodJobExecution = jobLauncher.run(importSaberXLStgJob, jobParameters);
			if (prodJobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
				LOGGER.info("Saber XL load completed successfully");
				// flownFeignClient.validateCouponsForFileId((fileLogging.getFileId().intValue()));
				return "Batch SaberXL-IN Job invoked and load data into staging and Saber XL production load completed successfully....";
			} else {
				return "Batch SaberXL-IN Job invoked and load data into staging completed but Saber production load failed.....";
			}
		}

		return "Batch Amadeus-IN/Saber-In job has been invoked and execution failed";
	}

	public String executeService(Integer fileId, String serviceName) throws Exception {
		String respMsg;
		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addLong("inboundFileId", Long.valueOf(fileId)).addString("serviceName", serviceName).toJobParameters();
		// @formatter:oN
		JobExecution jobExecution = jobLauncher.run(flownServiceJob, jobParameters);
		if (jobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
			respMsg = serviceName + " service call job executed successfully........";
		} else {
			respMsg = serviceName + " service call job execution failed........";
		}
		return respMsg;
	}

	public String runProration(Integer fileId) throws Exception {
		String respMsg;
		String hostCarrierCode = AmadeusCommonUtils.getHostCarrierCode(masterFeignClient);
		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addLong("inboundFileId", Long.valueOf(fileId)).addString("carrieNumericCode", hostCarrierCode)
				.toJobParameters();
		// @formatter:oN
		JobExecution jobExecution = jobLauncher.run(flownProrationJob, jobParameters);
		if (jobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
			respMsg = "Proration call job executed successfully........";
		} else {
			respMsg = "Proration call job execution failed........";
		}
		return respMsg;
	}

	public Boolean transferTicket(Integer amadeusLoadId, String serviceName) throws Exception {
		//String respMsg;
		String hostCarrierCode = AmadeusCommonUtils.getHostCarrierCode(masterFeignClient);
		String hostCarrDesigCode = AmadeusCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		String flightCreationFromFlownForAmadeus = AmadeusCommonUtils
				.getFlightCreationFromFlownForQatar(masterFeignClient);
		String flightCreationFromFlownForSabre = AmadeusCommonUtils
				.getFlightCreationFromFlownForOman(masterFeignClient);
		String flightNoLen = AmadeusCommonUtils.getFlightNumberOption(masterFeignClient);
		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addLong("amadeusLoadId", Long.valueOf(amadeusLoadId)).addString("carrieNumericCode", hostCarrierCode)
				.addString("careerDesignatorCode", hostCarrDesigCode)
				.addString("flightNoLen", flightNoLen)
				.addString("flightCreationFromFlown", flightCreationFromFlownForAmadeus).toJobParameters();
		// @formatter:oN

		// amadeusRecordStaging = stgRepository.findByAmadeusId(amadeusLoadId);
		Optional<AmadeusRecordStaging> amadeusRecordStaging = stgRepository.findByAmadeusId(amadeusLoadId);
		JobExecution jobExecution = null;
		if (amadeusRecordStaging.get().getFileSource().equals(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL_SOURCE)) {
			LOGGER.info("Amadeus ETL Resoltion  Service Starts");

			jobExecution = jobLauncher.run(amadeusETLResolutionJob, jobParameters);
			LOGGER.info("Amadeus ETL Resoltion  Service Ends");
		} else {
			if (amadeusRecordStaging.get().getFileSource().equals(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD_SOURCE)) {
				LOGGER.info("Amadeus EMD Resoltion  Service Starts");
				jobExecution = jobLauncher.run(amadeusEMDResolutionJob, jobParameters);
				LOGGER.info("Amadeus EMD Resoltion  Service Ends");
			}
		}

		if (jobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
			
		//	respMsg = "Exception resolution completed for the given amadeusLoadID........" +amadeusLoadId;
			return true;
		} else {
			//respMsg = "Exception resolution execution failed for the given amadeusLoadID........" +amadeusLoadId;
			return false;
		}
		
	}

}