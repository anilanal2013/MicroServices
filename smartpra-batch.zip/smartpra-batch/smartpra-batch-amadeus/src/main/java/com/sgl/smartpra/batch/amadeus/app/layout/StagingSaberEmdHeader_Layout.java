package com.sgl.smartpra.batch.amadeus.app.layout;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

import java.util.ArrayList;

public class StagingSaberEmdHeader_Layout extends FixedLengthRecordLayout{

    public StagingSaberEmdHeader_Layout(){
    	
    	 fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType",1,1));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightNumber",2,5));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageEmdDate",6,13));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOriginCodeEmd",14,17));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",18,null));

         
         
         
       
    }
}
