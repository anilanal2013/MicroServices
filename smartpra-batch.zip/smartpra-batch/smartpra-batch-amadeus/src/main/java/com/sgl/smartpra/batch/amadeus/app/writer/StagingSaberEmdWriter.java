package com.sgl.smartpra.batch.amadeus.app.writer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.AmadeusRecCounts;
import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStagingList;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdCouponModel;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.batch.amadeus.app.processor.ETLCouponProcessor;
import com.sgl.smartpra.batch.amadeus.app.processor.ETLTicketProcessor;
import com.sgl.smartpra.batch.amadeus.app.processor.ProdEMDCouponProcessor;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.repository.TicketCouponRepository;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@Component
@Scope(value = "step")
public class StagingSaberEmdWriter<T extends AmadeusBatchRecord> implements ItemWriter<AmadeusRecordStagingList> {

	private static final Logger LOGGER = LoggerFactory.getLogger(StagingSaberEmdWriter.class);

	@Autowired
	@Qualifier("emdUsed")
	ProdEMDCouponProcessor prodProcessor;

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private TicketMainRepository ticketMainRepository;

	@Autowired
	private TicketCouponRepository ticketCouponRepository;

	@Autowired
	ProdTicketDataWriter prodTicketDataWriter;

	@Autowired
	ProdCouponDataWriter prodCouponDataWriter;

	@Autowired
	ETLTicketProcessor etlTicketProcessor;

	@Autowired
	ETLCouponProcessor etlCouponProcessor;

	@Value("#{jobParameters[amadeusVersion]}")
	public String amadeusVersion;

	public String hostCarrDesigCode = "QR";

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends AmadeusRecordStagingList> amadeusRecordStagingList) throws Exception {
		//List<ProdTicketModel> prodTicketModelList = new ArrayList<ProdTicketModel>();
		List<ProdCouponModel> prodCouponModelList = new ArrayList<ProdCouponModel>();
		//ProdTicketModel prodTicketModel;
		ProdCouponModel prodCouponModel;

		for (AmadeusRecordStagingList amadeusRecordStagingListObject : amadeusRecordStagingList) {

			for (AmadeusRecordStaging amadeusRecordStagingListValues : amadeusRecordStagingListObject
					.getAmadeusRecordStaging()) {
				amadeusRecordStagingRepository.save(amadeusRecordStagingListValues);

				if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER_EMD)) {

					String issueAirline = amadeusRecordStagingListValues.getIssAirline();
					System.out.println("iis--" + issueAirline);
					String documentNumber = amadeusRecordStagingListValues.getDocumentNumber();
					System.out.println("iis--" + documentNumber);
					Optional<TicketMain> ticketMain = ticketMainRepository.findByIssAirlineDocNo(hostCarrDesigCode,
							issueAirline, documentNumber);

					if (ticketMain.isPresent()) {

						List<TicketCoupon> ticketCouponList = ticketMain.get().getTicketCoupons();
						LOGGER.info(
								"Issue Date  is available in Ticket Main table " + ticketMain.get().getDateOfIssue());

						SimpleDateFormat dateFormatter = new SimpleDateFormat("yyMMdd");
						String docUniqueDate = dateFormatter.format(ticketMain.get().getDateOfIssue());
						amadeusRecordStagingListValues.setIssueDate(docUniqueDate);
						LOGGER.info("Issue Date added in Staging Record ----->"
								+ amadeusRecordStagingListValues.getIssueDate());
						for (TicketCoupon ticketCoupon : ticketCouponList) {
							if (ticketCouponList != null) {
								if (ticketCoupon.getDocumentNumber()
										.equals(amadeusRecordStagingListValues.getDocumentNumber())
										&& ticketCoupon.getCouponNumber() == Integer
												.parseInt(amadeusRecordStagingListValues.getCouponNumber())) {

									ticketCoupon.setInvolFlag(amadeusRecordStagingListValues.getInvoluntaryIndicator());
									ticketCoupon.setFrequentFlyerReference(
											amadeusRecordStagingListValues.getFrequentFlyerCustomerCode());

									ticketCouponRepository.save(ticketCoupon);
								}
							}
						}
						AmadeusRecCounts.incDetailCount();
						prodCouponModel = prodProcessor.process(amadeusRecordStagingListValues);
						// prodCouponModel=prodSaberEMDCouponProcessor.process(amadeusRecordStagingList1);
						LOGGER.info(String.valueOf(prodCouponModel == null));
						if (prodCouponModel != null && (prodCouponModel.getFlownCoupon() != null
								|| prodCouponModel.getFlownEsac() != null)) {
							LOGGER.info("prodCouponWrite ------- Start");
							LOGGER.info(String.valueOf(prodCouponModel.getFlownCoupon() == null));
							LOGGER.info(String.valueOf(prodCouponModel.getFlownEsac() == null));
							prodCouponModelList.add(prodCouponModel);
							prodCouponDataWriter.write(prodCouponModelList);
							LOGGER.info("prodCouponWrite ------- End");
							AmadeusRecCounts.incTransferCount();
						}

						LOGGER.info(
								"#################################################### STG  - coupon using prodCouponDataWriter SAVE END for Saber VCR");

					} else {
						LOGGER.info(
								"#################################################### Date of issue is not available in Ticket main table so Records are not moved to production "
										+ amadeusRecordStagingListValues.getDocumentNumber());
						amadeusRecordStagingListValues.setStatus(AppConstants.STG_STATUS_ERROR);
						amadeusRecordStagingRepository.save(amadeusRecordStagingListValues);
					}
				}

			}

		}

	}

	
}
