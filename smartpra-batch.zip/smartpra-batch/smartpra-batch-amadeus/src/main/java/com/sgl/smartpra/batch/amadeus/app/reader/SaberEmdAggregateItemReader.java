package com.sgl.smartpra.batch.amadeus.app.reader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.SingleItemPeekableItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStagingList;
import com.sgl.smartpra.batch.amadeus.app.domain.SaberEmdFlightHeader;
import com.sgl.smartpra.batch.amadeus.app.domain.SaberEmdUsedFooter;
import com.sgl.smartpra.batch.amadeus.app.domain.SaberEmdUsedHeader;


@Component
@StepScope
public class SaberEmdAggregateItemReader<T> implements ItemStreamReader<T> {

	private SingleItemPeekableItemReader<AmadeusBatchRecord> delegate;

	private static final Logger LOGGER = LoggerFactory.getLogger(SaberEmdAggregateItemReader.class);

	@Value("${batch.directory.amadeus.input}")
	private String batchInputDir;

	@Value("#{jobParameters[inboundFileName]}")
	String fileName;

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		FlatFileItemReader<AmadeusBatchRecord> reader = new FlatFileItemReader<AmadeusBatchRecord>();
		reader.setResource(new FileSystemResource(batchInputDir + "/" + fileName));
		LOGGER.info("Config Using Tokenizer for saber Emd Tokenzier");
		reader.setLineMapper(saberEmdLineMapper());
		delegate = new SingleItemPeekableItemReader<AmadeusBatchRecord>();
		delegate.setDelegate(reader);
	}
	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {
		delegate.open(executionContext);
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {
		delegate.update(executionContext);
	}

	@Override
	public void close() throws ItemStreamException {
		delegate.close();
	}

	@Override
	public T read() throws Exception  {
		AmadeusBatchRecord amadeusBatchRecord = null;
		AmadeusRecordStagingList amadeusRecordStagingList = null;
		List<AmadeusRecordStaging> amadeusRecordStagingLst = null;
		AmadeusRecordStaging amadeusRecordStaging = null;
		SaberEmdFlightHeader saberEmdFlightHeader = null;
		LOGGER.info("####################################################################################### aggregateitem reader - Begin");
		while ((amadeusBatchRecord = (AmadeusBatchRecord) delegate.read()) != null) {
			LOGGER.info("########################## delete.read record ");
			LOGGER.info(amadeusBatchRecord.toString());
			if (amadeusBatchRecord instanceof SaberEmdFlightHeader) {
				LOGGER.info("########################## SaberEmdFlightHeader ");	
				amadeusRecordStagingList = new AmadeusRecordStagingList();
				amadeusRecordStagingLst = new ArrayList<AmadeusRecordStaging>();
				saberEmdFlightHeader = (SaberEmdFlightHeader) amadeusBatchRecord;
			} else if (amadeusBatchRecord instanceof AmadeusRecordStaging) {
				LOGGER.info("########################## AmadeusRecordStaging ");
				amadeusRecordStaging = (AmadeusRecordStaging) amadeusBatchRecord;
				amadeusRecordStaging.setUsageOperatingFlightNumber(saberEmdFlightHeader.getFlightNumber());
				amadeusRecordStaging.setUsageEmdDate(saberEmdFlightHeader.getUsageEmdDate());
				amadeusRecordStagingLst.add(amadeusRecordStaging);
			}
			if((!(amadeusBatchRecord instanceof SaberEmdUsedHeader)) && isEndOfGroupOrFile()) {
				amadeusRecordStagingList.setAmadeusRecordStaging(amadeusRecordStagingLst);
				LOGGER.info("####################################################################################### aggregateitem reader - End - I");
				return (T) amadeusRecordStagingList;
			}
		}
		LOGGER.info("####################################################################################### aggregateitem reader - End - II");
		return (T) amadeusRecordStagingList;
	}

	private boolean isEndOfGroupOrFile() throws Exception {
		// peek what is coming next
		AmadeusBatchRecord amadeusBatchRecord = (AmadeusBatchRecord) delegate.peek();

		if (amadeusBatchRecord == null) {
			LOGGER.info("########################## END OF FILE ");	
			return true;
		}

		if (amadeusBatchRecord instanceof SaberEmdFlightHeader) {
			LOGGER.info("########################## END OF GROUP ### SaberEmdFlightHeader ");	
			return true;
		}
		return false;
	}

	public LineMapper<AmadeusBatchRecord> saberEmdLineMapper() {
		LOGGER.info("Build saberEmdLineMapper");
		PatternMatchingCompositeLineMapper<AmadeusBatchRecord> mapper = new PatternMatchingCompositeLineMapper<>();
		AmadeusRecordStaging amadeusRecordStaging = new AmadeusRecordStaging();
		SaberEmdFlightHeader saberEmdFlightHeader = new SaberEmdFlightHeader();
		SaberEmdUsedHeader saberEmdUsedHeader = new SaberEmdUsedHeader();
		SaberEmdUsedFooter saberEmdUsedFooter = new SaberEmdUsedFooter();
		Map<String, LineTokenizer> tokenizers = new HashMap<>();
		tokenizers.put("A*", saberEmdUsedHeader.lineTokenizer());
		tokenizers.put("B*", saberEmdFlightHeader.lineTokenizer());
		tokenizers.put("C*", amadeusRecordStaging.saberEmdCouponTokenizer());
		tokenizers.put("D*", saberEmdUsedFooter.lineTokenizer());
		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<AmadeusBatchRecord>> saberMappers = new HashMap<>();
		saberMappers.put("A*", (new SaberEmdUsedHeader()).fieldSetMapper());
		saberMappers.put("B*", (new SaberEmdFlightHeader()).fieldSetMapper());
		saberMappers.put("C*", (new AmadeusRecordStaging()).fieldSetMapper());
		saberMappers.put("D*", (new SaberEmdUsedFooter()).fieldSetMapper());
		mapper.setFieldSetMappers(saberMappers);
		return mapper;
	}

}
