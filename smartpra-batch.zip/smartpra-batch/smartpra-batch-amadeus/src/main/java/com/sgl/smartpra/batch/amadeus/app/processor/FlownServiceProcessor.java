package com.sgl.smartpra.batch.amadeus.app.processor;

import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.server.ResponseStatusException;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.FlownFeignClient;
import com.sgl.smartpra.flown.domain.FlownCoupon;

@SuppressWarnings("serial")
public class FlownServiceProcessor extends FlownCoupon
implements ItemProcessor<FlownCoupon, FlownCoupon> {

	@Autowired
	FlownFeignClient flownFeignClient;
	
	@Value("#{jobParameters[serviceName]}")
	public String serviceName;

	private static final Logger LOGGER = LoggerFactory.getLogger(FlownServiceProcessor.class);

	@Override
	public FlownCoupon process(FlownCoupon flownCoupon) throws Exception {
		Thread currentThread = Thread.currentThread();
		LOGGER.info("########################################## process - start");
		Integer resCount=0;
		LOGGER.info(currentThread.getId() + " : " +  flownCoupon.getDocumentUniqueId() + " -- " + flownCoupon.getCouponNumber());
		//this check is not necessary if we add "RV" in the reader query but it is skipping the records those status updated by the validation service.
		LOGGER.info("serviceName======>" + serviceName==null?"NULL":serviceName);
		if(AppConstants.SERVICENAME_VALIDATION.equals(serviceName) && "RV".equals(flownCoupon.getCouponStatus())) { 
			try {
				LOGGER.info("########################################## validation process - start");
				resCount = flownFeignClient.validateCoupon(flownCoupon);
				LOGGER.info("########################################## validation process - end");
			} catch (ResponseStatusException ex) {
				LOGGER.info("####################################################################### ResponseStatusException thrown : " + ex.getStatus());
			}
		} else if(AppConstants.SERVICENAME_REVENUE.equals(serviceName) && "CC".equals(flownCoupon.getCouponStatus())) { 
			try {
				LOGGER.info("########################################## revenue process - start");
				 flownFeignClient.generateRevForACoupon(flownCoupon);
				 LOGGER.info("########################################## revenue process - end");
			} catch (ResponseStatusException ex) {
				LOGGER.info("####################################################################### ResponseStatusException thrown : " + ex.getStatus());
			}
		} else if(AppConstants.SERVICENAME_ESTIMATE.equals(serviceName) && 
				Stream.of("ER", "EP", "EC","EV").anyMatch(x -> x.equals(flownCoupon.getCouponStatus())) && 
				"PAX".equals(flownCoupon.getDocumentType())) { 
			try {
				LOGGER.info("########################################## estimation process - start");
				 flownFeignClient.estimateFlownCoupon(flownCoupon);
				 LOGGER.info("########################################## estimation process - end");
			} catch (ResponseStatusException ex) {
				LOGGER.info("####################################################################### ResponseStatusException thrown : " + ex.getStatus());
			}
		}
		LOGGER.info("####################################################################### response count : " + resCount);
		LOGGER.info("########################################## process - end");		
		return null;
	}
}