package com.sgl.smartpra.batch.amadeus.app.layout;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

import java.util.ArrayList;

public class StagingSaberEmdCoupon_Layout extends FixedLengthRecordLayout{

    public StagingSaberEmdCoupon_Layout(){
    	
    	 fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType",1,1));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline",2,4));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber",5,14));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit",15,15));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber",16,16));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForIssuanceCode",17,17));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForIssuanceSubCode",18,20));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdRouting",21,28));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOriginCodeEmd",23,25));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDestinationCodeEmd",26,28));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",29,30));
         //fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponCurrency",31,34));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponValue", 36, 46));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",47,48));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareConstruction",49,135));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",136,137));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",2019,2020));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("classOfService",2021,2022));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthorizationCode",2023,2035));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",2036,2037));
        // fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber",2038,2051));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",2052,2053));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingCarrier",2054,2056));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingFlightNumber",2057,2060));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("passengerName",2061,2109));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("frequentFlyerCustomerCode",2110,2132));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",2133,2140));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",2141,2142));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("involuntaryRerouteIndicators",2143,2144));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("involuntaryCarrierCode",2145,2147));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",2148,null));






         
         
       
    }
}
