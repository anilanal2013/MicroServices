package com.sgl.smartpra.batch.amadeus.app.writer;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.DocumentIdsWriter;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.repository.FlownCouponRepository;
import com.sgl.smartpra.flown.utils.FlownConstants;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@Component
@Scope(value = "step")
public class ProrationWriter<T extends FlownCoupon> implements ItemWriter<FlownCoupon> {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProrationWriter.class);

	@Autowired
	private TicketMainRepository ticketMainRepository;

	@Autowired
	private FlownCouponRepository flownCouponRepository;

	@Override
	public void write(List<? extends FlownCoupon> items) throws Exception {
		LOGGER.info("ProrationWriter.write -- Start");
		Optional<TicketMain> optional;
		TicketMain ticketMain;
		for(FlownCoupon coupon:items) {
			LOGGER.info("########################################## coupon.getDocumentUniqueId() : " + coupon.getDocumentUniqueId());
			optional = ticketMainRepository.findByDocumentUniqueId(coupon.getDocumentUniqueId());
			LOGGER.info("########################################## process - ticketMainOpt is null ? " + optional.isPresent());
			if (optional.isPresent()) {
				ticketMain = optional.get();
				LOGGER.info("########################################## ticketMain.getStatus() : " + ticketMain.getStatus());
				if(ticketMain.getStatus().equals(FlownConstants.TICKET_MAIN_STATUS_CC)) {
					LOGGER.info("ProrationWriter.write -- ticket status is CC");
					coupon.setCouponStatus(FlownConstants.FLOWN_COUPON_STATUS_CC);
					flownCouponRepository.save(coupon);
				} else if(ticketMain.getStatus().equals(FlownConstants.TICKET_MAIN_STATUS_EC)) {
					LOGGER.info("ProrationWriter.write -- ticket status is EC");
					coupon.setCouponStatus(FlownConstants.FLOWN_COUPON_STATUS_EC);
					flownCouponRepository.save(coupon);
				} 
				LOGGER.info("########################################## ticketMain.getStatus() : " + ticketMain.getStatus());
			}

			LOGGER.info("ProrationWriter.write -- End");
		}
	}
}
