package com.sgl.smartpra.batch.amadeus.app.writer;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.domain.ProdCouponModel;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.repository.FlownCouponRepository;
import com.sgl.smartpra.flown.repository.FlownEsacRepository;

@Component
@Scope(value = "step")
public class ProdCouponDataWriter<T extends AmadeusBatchRecord> implements ItemWriter<ProdCouponModel> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProdCouponDataWriter.class);

	@Value("#{jobParameters['carrieNumericCode']}")
	public String hostCarrNumericCode;

	@Value("#{jobParameters['careerDesignatorCode']}")
	public String hostCarrDesigCode;

	@Autowired
	private FlownCouponRepository flownCouponRepository;

	@Autowired
	private FlownEsacRepository flownEsacRepository;

	@Override
	public void write(List<? extends ProdCouponModel> items) throws Exception {
		LOGGER.info("################# ProdCouponDataWriter.write - Start .....");
		FlownCoupon flowncoupon = null;
		for (ProdCouponModel prodCouponModel : items) {
			LOGGER.info("Adding Flown Values" + prodCouponModel.getFlownEsac());
			if (prodCouponModel.getFlownCoupon() != null) {
				flowncoupon = prodCouponModel.getFlownCoupon();
				flownCouponRepository.save(flowncoupon);
			}
			flownEsacRepository.save(prodCouponModel.getFlownEsac());
		}
		flownCouponRepository.flush();
		flownEsacRepository.flush();
		LOGGER.info("################# ProdCouponDataWriter.write - End .....");
	}

}
