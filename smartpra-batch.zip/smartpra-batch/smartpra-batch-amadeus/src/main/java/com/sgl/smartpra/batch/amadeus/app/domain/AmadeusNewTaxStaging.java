package com.sgl.smartpra.batch.amadeus.app.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.amadeus.app.layout.StagingETLV2_20Layout;
import com.sgl.smartpra.batch.amadeus.app.processor.StagingCommonProcessor;

/**
 * The persistent class for the amadeus_old_tax_stg database table.
 * 
 */
@Entity
@Table(name = "amadeus_new_tax_stg")
@NamedQuery(name = "AmadeusNewTaxStaging.findAll", query = "SELECT a FROM AmadeusNewTaxStaging a")
public class AmadeusNewTaxStaging extends AmadeusBatchRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "amadeus_new_tax_id")
	private int amadeus_new_tax_id;

	@Column(name = "new_tax_code")
	private String newTaxCode;

	@Column(name = "new_tax_value")
	private String newTaxValue;

	// bi-directional many-to-one association to AmadeusRecordStg
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "amadeus_load_id", referencedColumnName = "amadeus_load_id")
	private AmadeusRecordStaging amadeusRecordStg;

	public AmadeusNewTaxStaging() {
	}

	public int getAmadeus_new_tax_id() {
		return amadeus_new_tax_id;
	}

	public void setAmadeus_new_tax_id(int amadeus_new_tax_id) {
		this.amadeus_new_tax_id = amadeus_new_tax_id;
	}

	public String getNewTaxCode() {
		return newTaxCode;
	}

	public void setNewTaxCode(String newTaxCode) {
		this.newTaxCode = newTaxCode;
	}

	public String getNewTaxValue() {
		return newTaxValue;
	}

	public void setNewTaxValue(String newTaxValue) {
		this.newTaxValue = newTaxValue;
	}

	public AmadeusRecordStaging getAmadeusRecordStg() {
		return amadeusRecordStg;
	}

	public void setAmadeusRecordStg(AmadeusRecordStaging amadeusRecordStg) {
		this.amadeusRecordStg = amadeusRecordStg;
	}

	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		StagingETLV2_20Layout stagingETLV2_20Layout = new StagingETLV2_20Layout();
		tokenizer.setColumns(stagingETLV2_20Layout.getColumns());
		tokenizer.setNames(stagingETLV2_20Layout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<AmadeusBatchRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<AmadeusBatchRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<AmadeusBatchRecord>();
		fieldSetMapper.setTargetType(AmadeusNewTaxStaging.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> processor() {
		return new StagingCommonProcessor();
	}

	@Override
	public ItemWriter<? super AmadeusBatchRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}
}