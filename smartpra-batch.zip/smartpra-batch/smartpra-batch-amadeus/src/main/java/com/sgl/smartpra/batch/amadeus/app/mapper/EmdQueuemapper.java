package com.sgl.smartpra.batch.amadeus.app.mapper;

import org.mapstruct.Mapper;
import com.sgl.smartpra.flown.model.EMDQueue;

import com.sgl.smartpra.flown.domain.FlownCoupon;


@Mapper
public interface EmdQueuemapper {
	
	EMDQueue mapToEmdQueue(FlownCoupon flownCoupon);

}
