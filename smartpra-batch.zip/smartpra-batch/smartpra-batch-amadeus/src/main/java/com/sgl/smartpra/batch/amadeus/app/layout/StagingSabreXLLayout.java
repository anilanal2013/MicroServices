package com.sgl.smartpra.batch.amadeus.app.layout;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

import java.util.ArrayList;

public class StagingSabreXLLayout extends FixedLengthRecordLayout {

    public StagingSabreXLLayout() {

        fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType",1,1));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageMarketingCarrierCode", 37, 38));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingCarrier", 37, 38));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline", 39, 41));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber", 42, 51));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDocNumber",42,51));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 52, 52));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("internationalDomesticInd", 53, 53));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentType", 54, 54));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("agencyNumber", 57, 64));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthorizationCode", 65, 78));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bookingReference", 79, 91));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("passengerName", 92, 141));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareConstruction", 142, 396));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reportedFare", 397, 404));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfReportedFare", 405, 407));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("equivalentFare", 408, 415));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("paymentCurrency", 416, 418));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issueDate", 450, 456));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfPayment", 457, 458));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalIssueInformation", 730, 766));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tourCode", 769, 783));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("endorsementRestrictionText", 784, 903));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalIssueInformation",926,943));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("coupons", 3129, 4096));


    }
}
