package com.sgl.smartpra.batch.amadeus.app.processor;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusNewTaxStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class XLTCNProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(XLTCNProcessor.class);

    public static List<AmadeusNewTaxStaging> getAmadeusNewTaxStagingList(AmadeusRecordStaging amadeusRecordStaging) {
        String taxDetailStr=amadeusRecordStaging.getNewTax();
        return IntStream.range(0, taxDetailStr.length() / 14).parallel()
                .mapToObj(k -> mapToAmadeusNewTaxStaging(amadeusRecordStaging, taxDetailStr, k))
                .collect(Collectors.toList());
    }

    public static AmadeusRecordStaging mapToAmadeusRecordStaging(AmadeusRecordStaging amadeusRecordStaging, Integer couponSize, String fileType) {
        LOGGER.info("Enter into processXLTCN method");
        String couponDetailStr = amadeusRecordStaging.getCoupons();
        int couponCount = couponDetailStr.length() / couponSize;
        if (couponDetailStr.length() % couponSize > 0)
            couponCount++; //count added to fix issue for layout trimming the suffix space
        LOGGER.info("Coupon count=" + couponCount);
        amadeusRecordStaging.setAmadeusRecordDetailStgs(getAmadeusRecordStagingList(amadeusRecordStaging, couponSize, fileType, couponDetailStr, couponCount));
        amadeusRecordStaging.setFileSource(fileType);
        amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_LOADED);
        return amadeusRecordStaging;
    }

    private static List<AmadeusRecordDetailStaging> getAmadeusRecordStagingList(AmadeusRecordStaging amadeusRecordStaging, Integer couponSize, String fileType, String couponDetailStr, int couponCount) {
        return IntStream.range(0, couponCount).parallel()
                .filter(i -> couSubStr(couponDetailStr, (i * couponSize), (i * couponSize) + 1).trim().length() > 0)
                .mapToObj(i -> applyBasedOnFileType(i, amadeusRecordStaging, couponSize, fileType))
                .collect(Collectors.toList());
    }

    private static AmadeusRecordDetailStaging applyBasedOnFileType(int i, AmadeusRecordStaging amadeusRecordStaging, Integer couponSize, String fileType) {
        if (fileType.equals("XL")) {
            return mapToRecordDetailStagingForXL(i, amadeusRecordStaging, couponSize);
        }
        return mapToRecordDetailStagingForETL(i, amadeusRecordStaging, couponSize);
    }

    private static AmadeusRecordDetailStaging mapToRecordDetailStagingForETL(int i, AmadeusRecordStaging amadeusRecordStaging, Integer couponSize) {
        LOGGER.info("Enter into mapToRecordDetailStagingForETL method");
        AmadeusRecordDetailStaging amadeusRecordDetailStaging = new AmadeusRecordDetailStaging();
        String couponDetailStr = amadeusRecordStaging.getCoupons();
        amadeusRecordDetailStaging.setCouponNumber(amadeusRecordStaging.getCouponNumber());
        amadeusRecordDetailStaging.setSaleCouponNumber(couSubStr(couponDetailStr, (i * couponSize), (i * couponSize) + 2));
        amadeusRecordDetailStaging.setOrigin(couSubStr(couponDetailStr, (i * couponSize) + 2, (i * couponSize) + 7));
        amadeusRecordDetailStaging.setDestination(couSubStr(couponDetailStr, (i * couponSize) + 7, (i * couponSize) + 12));
        amadeusRecordDetailStaging.setAirlineCode(couSubStr(couponDetailStr, (i * couponSize) + 12, (i * couponSize) + 15));
        amadeusRecordDetailStaging
                .setSaleFlightNumber(couSubStr(couponDetailStr, (i * couponSize) + 15, (i * couponSize) + 20));
        amadeusRecordDetailStaging
                .setSaleLocalFlightDate(couSubStr(couponDetailStr, (i * couponSize) + 20, (i * couponSize) + 26));

        amadeusRecordDetailStaging.setSellingClass(couSubStr(couponDetailStr, (i * couponSize) + 26, (i * couponSize) + 28));

        amadeusRecordDetailStaging.setFareBasis(couSubStr(couponDetailStr, (i * couponSize) + 28, (i * couponSize) + 43));
        amadeusRecordDetailStaging
                .setReservationStatus(couSubStr(couponDetailStr, (i * couponSize) + 43, (i * couponSize) + 45));
        amadeusRecordDetailStaging
                .setFreeBaggageAllowance(couSubStr(couponDetailStr, (i * couponSize) + 45, (i * couponSize) + 48));
        amadeusRecordDetailStaging
                .setInvoluntaryIndicator(couSubStr(couponDetailStr, (i * couponSize) + 48, (i * couponSize) + 49));
        amadeusRecordDetailStaging.setStopOverCode(couSubStr(couponDetailStr, (i * couponSize) + 49, (i * couponSize) + 50));
        amadeusRecordDetailStaging
                .setNotValidBeforeDate(couSubStr(couponDetailStr, (i * couponSize) + 50, (i * couponSize) + 56));
        amadeusRecordDetailStaging
                .setNotValidAfterDate(couSubStr(couponDetailStr, (i * couponSize) + 56, (i * couponSize) + couponSize));
        amadeusRecordDetailStaging.setCreatedBy(AppConstants.CREATED_BY);
        // amadeusRecordDetailStaging.setFileSource(AppConstants.FILE_SOURCE_ETL);
        amadeusRecordDetailStaging.setCreatedDate(new Timestamp(new Date().getTime()));
        // amadeusRecordDetailStaging.setStatus(AppConstants.STATUS);
        amadeusRecordDetailStaging.setAmadeusRecordStg(amadeusRecordStaging);
        return amadeusRecordDetailStaging;

    }

    private static AmadeusRecordDetailStaging mapToRecordDetailStagingForXL(int i, AmadeusRecordStaging amadeusRecordStaging, Integer couponSize) {
        LOGGER.info("Enter into mapToRecordDetailStagingForXL method");
        AmadeusRecordDetailStaging amadeusRecordDetailStaging = new AmadeusRecordDetailStaging();
        // amadeusRecordDetailStaging.setCouponNumber(amadeusRecordStaging.getCouponNumber());
        String coupons = amadeusRecordStaging.getCoupons();
        amadeusRecordDetailStaging.setSaleCouponNumber(couSubStr(coupons, (i * couponSize), (i * couponSize) + 1));
        // needs to check XL_CSA_SAC_1 ---1-15
        amadeusRecordDetailStaging.setOrigin(couSubStr(coupons, (i * couponSize) + 15, (i * couponSize) + 20));
        amadeusRecordDetailStaging.setDestination(couSubStr(coupons, (i * couponSize) + 20, (i * couponSize) + 25));
        amadeusRecordDetailStaging.setAirlineCode(couSubStr(coupons, (i * couponSize) + 25, (i * couponSize) + 28));
        amadeusRecordDetailStaging
                .setSaleFlightNumber(couSubStr(coupons, (i * couponSize) + 28, (i * couponSize) + 33));
        //needs to check XL_CBD_BOOKING_DES_1(staging column name)33-35
        amadeusRecordDetailStaging
                .setSaleLocalFlightDate(couSubStr(coupons, (i * couponSize) + 35, (i * couponSize) + 40));

        // amadeusRecordDetailStaging.setSellingClass(couSubStr(coupons, (i * AppConstants.COUPON_LENGTH) + 26, (i * AppConstants.COUPON_LENGTH) + 28));
        //needs to check XL_CFT_FLIGHT_TIME_1(added with InvlFlightDepartTime)
        amadeusRecordDetailStaging.setInvlFlightDepartTime(couSubStr(coupons, (i * couponSize) + 40, (i * couponSize + 45)));

        //needs to check XL_CST_COUPON_STATUS_1(staging column name) 45-47

        amadeusRecordDetailStaging.setFareBasis(couSubStr(coupons, (i * couponSize) + 47, (i * couponSize) + 60));
        //amadeusRecordDetailStaging.setReservationStatus(couSubStr(coupons, (i * AppConstants.COUPON_LENGTH) + 43, (i * AppConstants.COUPON_LENGTH) + 45));

        amadeusRecordDetailStaging
                .setNotValidBeforeDate(couSubStr(coupons, (i * couponSize) + 60, (i * couponSize) + 65));
        amadeusRecordDetailStaging
                .setNotValidAfterDate(couSubStr(coupons, (i * couponSize) + 65, (i * couponSize) + 70));
        amadeusRecordDetailStaging.setStopOverCode(couSubStr(coupons, (i * couponSize) + 70, (i * couponSize) + 71));

        // needs to check XL_CIV_CURR_INVOL_IND_1 ---71-72
        // needs to check XL_OIV_ORIG_INVOL_IND_1 ---72-73
        // needs to check XL_CCI_INVOL_CARR_1 ---73-75
        // needs to check XL_CSS_SPARE_1 ---75-76
        // needs to check XL_DII_INVOL_PARS_DATE_1 ---76-81
        // needs to check XL_CSP_SPARES_1 -----81-114
        // needs to check XL_NC1_FLWN_FLIGHT_1 ---114-119
        // needs to check XL_NC2_FLWN_DATE_1 --119-124
        // needs to check XL_NC3_BOARD_CITY_1 ---124-129
        // needs to check XL_NC4_OFF_CITY_1 ---129-134
        // needs to check XL_NC5_FLWN_CABIN_1 --134-137
        // needs to check XL_NC6_ORIG_DATE_1 --137-142
        // needs to check XL_IND_CPN_LVL_IND_1 --142-143
        // needs to check XL_NCS_SPARES_1 --143-242

        //amadeusRecordDetailStaging.setFreeBaggageAllowance(couSubStr(coupons, (i * AppConstants.COUPON_LENGTH) + 45, (i * AppConstants.COUPON_LENGTH) + 48));
        //amadeusRecordDetailStaging.setInvoluntaryIndicator(couSubStr(coupons, (i * AppConstants.COUPON_LENGTH) + 48, (i * AppConstants.COUPON_LENGTH) + 49));

        amadeusRecordDetailStaging.setCreatedBy(AppConstants.CREATED_BY_XL_TCN);
        // amadeusRecordDetailStaging.setFileSource(AppConstants.FILE_SOURCE_ETL);
        amadeusRecordDetailStaging.setCreatedDate(new Timestamp(new Date().getTime()));
        // amadeusRecordDetailStaging.setStatus(AppConstants.STATUS);
        amadeusRecordDetailStaging.setAmadeusRecordStg(amadeusRecordStaging);
        return amadeusRecordDetailStaging;
    }

    private static AmadeusNewTaxStaging mapToAmadeusNewTaxStaging(AmadeusRecordStaging amadeusRecordStaging, String taxDetailStr, int k) {
        AmadeusNewTaxStaging amadeusNewTaxStaging = new AmadeusNewTaxStaging();
        amadeusNewTaxStaging.setNewTaxCode(taxDetailStr.substring((k * 14), (k * 14) + 2));
        amadeusNewTaxStaging.setNewTaxValue(taxDetailStr.substring((k * 14) + 2, (k * 14) + 14));
        amadeusNewTaxStaging.setCreatedBy(AppConstants.CREATED_BY);
        amadeusNewTaxStaging.setCreatedDate(new Timestamp(new Date().getTime()));
        amadeusNewTaxStaging.setAmadeusRecordStg(amadeusRecordStaging);
        return amadeusNewTaxStaging;
    }

    public static String couSubStr(String couponStr, int stPosition, int edPosition) {
        String retStr = "";
        if (couponStr.length() >= edPosition) {
            retStr = couponStr.substring(stPosition, edPosition);
        }
        return retStr;
    }
}
