package com.sgl.smartpra.batch.amadeus.app.repository;

import java.math.BigInteger;
import java.util.Date;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.amadeus.app.domain.RequestFileDetail;


@Repository
public interface RequestFileDetailRepository  extends JpaRepository<RequestFileDetail, BigInteger>{
	
	final static String FETCH_REQUEST_OUT_DETAILS = "SELECT R FROM RequestFileDetail R "
			+ " WHERE R.requestType ='O' AND R.requestAirLineCode = :hostCarrierCode "
			+ " AND (R.ticketIssuingAirLineCode = :carrierCode OR :carrierCode IS NULL OR :carrierCode='') AND R.fileId IS NULL AND R.requestSeqNumber IS NULL"; 

	@Query(value =  "SELECT R FROM RequestFileDetail R "
			+ " WHERE R.requestType ='O' AND R.requestAirLineCode = :hostCarrierCode "
			+ " AND R.ticketIssuingAirLineCode = :carrierCode AND R.fileId IS NULL AND R.requestSeqNumber IS NULL")
	public Page<RequestFileDetail> findByHostCarrier(@Param("hostCarrierCode") String hostCarrierCode, @Param("carrierCode")String carrierCode, Pageable pageable);
	
	@Query("select a from RequestFileDetail a  where a.ticketNumber = :ticketNumber and a.couponNumber = :couponNumber")
	public Optional<RequestFileDetail> findByTicketNumberandCouponNumber(@Param("ticketNumber") BigInteger ticketNumber, @Param("couponNumber") Integer couponNumber);
	
	
	@Query("select a from RequestFileDetail a  where a.ticketNumber = :ticketNumber and a.couponNumber = :couponNumber and a.requestAirLineCode =:requestAirLineCode and a.responseAirLineCode=:responseAirLineCode and a.couponType=:couponType and a.fileId IS NULL")
	public Optional<RequestFileDetail> findDuplicateRecord(@Param("ticketNumber") BigInteger ticketNumber, @Param("couponNumber") Integer couponNumber,  @Param("requestAirLineCode") String requestAirLineCode, @Param("responseAirLineCode") String responseAirLineCode,@Param("couponType") String couponType);
	


}
