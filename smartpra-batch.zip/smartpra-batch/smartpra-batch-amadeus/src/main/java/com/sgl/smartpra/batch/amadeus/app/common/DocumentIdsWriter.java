package com.sgl.smartpra.batch.amadeus.app.common;

import java.util.ArrayList;
import java.util.List;

public class DocumentIdsWriter {

	private static DocumentIdsWriter instanceWriter;
	private static List<String> wDocumentUniqueIds = new ArrayList<String>();

	private DocumentIdsWriter() {

	}
	  { 
		    // static block to initialize instanceWriter 
		    instanceWriter = new DocumentIdsWriter(); 
		  } 
	synchronized public static DocumentIdsWriter getInstance()  
	{ 
		return instanceWriter; 
	} 

	synchronized public static void addDocUniqueId(String documentUniqueId) {
		wDocumentUniqueIds.add(documentUniqueId);
	}
	synchronized public static String findDocUniqueId(String documentUniqueId) {
		return wDocumentUniqueIds.stream()
				.filter(str -> documentUniqueId.equals(str))
				.findAny()
				.orElse(null);
	}
	synchronized public static int getSize() {
		return wDocumentUniqueIds.size();
	}
	synchronized public static void clear() {
		wDocumentUniqueIds.clear();
	}
}
