package com.sgl.smartpra.batch.amadeus.app.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.AmadeusRecCounts;
import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;

@SuppressWarnings("serial")
@Component
@Scope(value = "Prototype")
public class StagingCommonProcessor extends AmadeusProcessor
implements ItemProcessor<AmadeusRecordStaging, AmadeusRecordStaging> {

	@Value("#{jobParameters['inboundFileId']}")
	public Integer inboundFileId;

	@Value("#{jobParameters[amadeusVersion]}")
	public String amadeusVersion;

	@Value("#{jobParameters['fileType']}")
	public String fileType;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;
	private static final Logger LOGGER = LoggerFactory.getLogger(StagingCommonProcessor.class);

	@Override
	public AmadeusRecordStaging process(AmadeusRecordStaging amadeusRecordStaging) throws Exception {
		super.process(amadeusRecordStaging);
		amadeusRecordStaging.setFileId(inboundFileId);
		JobExecution jobExecution = this.stepExecution.getJobExecution();
		ExecutionContext jobExecutionContext = jobExecution.getExecutionContext();
		AmadeusRecCounts.incTotalCount();
		if (amadeusRecordStaging.getRecordType().equals("1")) {
			jobExecutionContext.put("headerFlag", true);
			return null;
		} else if (amadeusRecordStaging.getRecordType().equals("9")) {
			jobExecutionContext.put("footerFlag", true);
			return null;
		} else if (amadeusRecordStaging.getRecordType().equals("A")) {
			jobExecutionContext.put("headerFlag", true);
			return null;
		} else if (amadeusRecordStaging.getRecordType().equals("B")) {
			jobExecutionContext.put("flightheaderFlag", true);
			return null;
		} else if (amadeusRecordStaging.getRecordType().equals("D")) {
			jobExecutionContext.put("footerFlag", true);
			return null;
		} else if (amadeusRecordStaging.getRecordType().equals("Z")) {
			jobExecutionContext.put("footerFlag", true);
			return null;
		}

		if (fileType.contains(AppConstants.FILE_TYPE_IDENTIFICATION_STRING_SABER_XL)){
			return XLTCNProcessor.mapToAmadeusRecordStaging(amadeusRecordStaging,AppConstants.SABRE_XL_TCN_COUPON_LENGTH,fileType);
		}

		if (amadeusVersion.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER)) {

			LOGGER.info("Entering Saber Records");
			amadeusRecordStaging.setUsageType(AppConstants.FLOWN_COUPON_F);
			//amadeusRecordStaging.setUsageAirline("157");
			amadeusRecordStaging.setFileSource(AppConstants.FILETYPE_IDENTIFICATION_STRING_SABER);
			amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_LOADED);
			amadeusRecordStaging.setCreatedBy(AppConstants.SABRE);
			return amadeusRecordStaging;

		}

		amadeusRecordStaging.setAmadeusNewTaxStgs(XLTCNProcessor.getAmadeusNewTaxStagingList(amadeusRecordStaging));
		return XLTCNProcessor.mapToAmadeusRecordStaging(amadeusRecordStaging,AppConstants.COUPON_LENGTH,AppConstants.FILE_SOURCE_ETL);
	}



	/*ArrayList<AmadeusRecordDetailStaging> amadeusRecordDetailStagingList;
    ArrayList<AmadeusNewTaxStaging> amadeusNewTaxStagingList;
    String couponNumber;
    AmadeusRecordDetailStaging amadeusRecordDetailStaging;
    AmadeusNewTaxStaging amadeusNewTaxStaging;
    amadeusNewTaxStagingList = new ArrayList<AmadeusNewTaxStaging>();
    String taxDetailStr = amadeusRecordStaging.getNewTax();
    int taxCount = taxDetailStr.length() / 14;

    for (int k = 0; k < taxCount; k++) {

        amadeusNewTaxStaging = new AmadeusNewTaxStaging();
        amadeusNewTaxStaging.setNewTaxCode(taxDetailStr.substring((k * 14), (k * 14) + 2));
        amadeusNewTaxStaging.setNewTaxValue(taxDetailStr.substring((k * 14) + 2, (k * 14) + 14));
        amadeusNewTaxStaging.setCreatedBy(AppConstants.CREATED_BY);
        amadeusNewTaxStaging.setCreatedDate(new Timestamp(new Date().getTime()));
        amadeusNewTaxStaging.setAmadeusRecordStg(amadeusRecordStaging);
        amadeusNewTaxStagingList.add(amadeusNewTaxStaging);

    }
    amadeusRecordDetailStagingList = new ArrayList<AmadeusRecordDetailStaging>();
    String couponDetailStr = amadeusRecordStaging.getCoupons();
    int couponCount = couponDetailStr.length() / AppConstants.COUPON_LENGTH;
    if(couponDetailStr.length() % AppConstants.COUPON_LENGTH > 0) couponCount++; //count added to fix issue for layout trimming the suffic space
    for (int i = 0; i < couponCount; i++) {
        LOGGER.info("Enter into Amadeus Etl");
        couponNumber = couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH), (i * AppConstants.COUPON_LENGTH) + 2);
        if (couponNumber != null && couponNumber.length() > 0) {
            amadeusRecordDetailStaging = new AmadeusRecordDetailStaging();
            amadeusRecordDetailStaging.setCouponNumber(amadeusRecordStaging.getCouponNumber());
            amadeusRecordDetailStaging.setSaleCouponNumber(couponNumber);
            amadeusRecordDetailStaging.setOrigin(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 2, (i * AppConstants.COUPON_LENGTH) + 7));
            amadeusRecordDetailStaging.setDestination(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 7, (i * AppConstants.COUPON_LENGTH) + 12));
            amadeusRecordDetailStaging.setAirlineCode(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 12, (i * AppConstants.COUPON_LENGTH) + 15));
            amadeusRecordDetailStaging
            .setSaleFlightNumber(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 15, (i * AppConstants.COUPON_LENGTH) + 20));
            amadeusRecordDetailStaging
            .setSaleLocalFlightDate(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 20, (i * AppConstants.COUPON_LENGTH) + 26));

            amadeusRecordDetailStaging.setSellingClass(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 26, (i * AppConstants.COUPON_LENGTH) + 28));

            amadeusRecordDetailStaging.setFareBasis(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 28, (i * AppConstants.COUPON_LENGTH) + 43));
            amadeusRecordDetailStaging
            .setReservationStatus(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 43, (i * AppConstants.COUPON_LENGTH) + 45));
            amadeusRecordDetailStaging
            .setFreeBaggageAllowance(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 45, (i * AppConstants.COUPON_LENGTH) + 48));
            amadeusRecordDetailStaging
            .setInvoluntaryIndicator(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 48, (i * AppConstants.COUPON_LENGTH) + 49));
            amadeusRecordDetailStaging.setStopOverCode(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 49, (i * AppConstants.COUPON_LENGTH) + 50));
            amadeusRecordDetailStaging
            .setNotValidBeforeDate(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 50, (i * AppConstants.COUPON_LENGTH) + 56));
            amadeusRecordDetailStaging
            .setNotValidAfterDate(couSubStr(couponDetailStr, (i * AppConstants.COUPON_LENGTH) + 56, (i * AppConstants.COUPON_LENGTH) + AppConstants.COUPON_LENGTH));
            amadeusRecordDetailStaging.setCreatedBy(AppConstants.CREATED_BY);
            // amadeusRecordDetailStaging.setFileSource(AppConstants.FILE_SOURCE_ETL);
            amadeusRecordDetailStaging.setCreatedDate(new Timestamp(new Date().getTime()));
            // amadeusRecordDetailStaging.setStatus(AppConstants.STATUS);
            amadeusRecordDetailStaging.setAmadeusRecordStg(amadeusRecordStaging);
            amadeusRecordDetailStagingList.add(amadeusRecordDetailStaging);
        } else {
            break;
        }

    }

    amadeusRecordStaging.setAmadeusRecordDetailStgs(amadeusRecordDetailStagingList);
    amadeusRecordStaging.setAmadeusNewTaxStgs(amadeusNewTaxStagingList);
    amadeusRecordStaging.setFileSource(AppConstants.FILE_SOURCE_ETL);
    amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_LOADED);



    return amadeusRecordStaging;
}*/


}
