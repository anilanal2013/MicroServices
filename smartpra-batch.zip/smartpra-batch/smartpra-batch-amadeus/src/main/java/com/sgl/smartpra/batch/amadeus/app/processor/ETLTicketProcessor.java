package com.sgl.smartpra.batch.amadeus.app.processor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.common.DocumentIdsReader;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.PaxFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.ValidationFeignClient;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusNewTaxStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.batch.amadeus.app.utils.AmadeusCommonUtils;
import com.sgl.smartpra.common.constant.Month;
import com.sgl.smartpra.common.constant.SmartPRAConstant;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.exception.txn.enums.EnvironmentEnum;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.TicketTax;
import com.sgl.smartpra.sales.model.PAXTypeModel;
import com.sgl.smartpra.sales.repository.TicketMainRepository;
import com.sgl.smartpra.validation.model.RefDataValidationReqDTO;
import com.sgl.smartpra.validation.model.RefDataValidationRespDTO;

@Component
@Scope(value = "step")
public class ETLTicketProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(ETLTicketProcessor.class);

	private static final String MODULE = SmartPRAConstant.VALIDATION_MODULE_FLOWN;

	private static final String SOURCE = SmartPRAConstant.VALIDATION_MODULE_NONUI;

	@Autowired
	PaxFeignClient paxTypeFeignClient;

	@Autowired
	ValidationFeignClient validationFeignClient;

	@Autowired
	private TicketMainRepository ticketMainRepository;

	public String sysParamFlightLen="4";

	public ProdTicketModel process(String clientId, AmadeusRecordStaging amadeusRecordStaging) throws Exception {
		ProdTicketModel validatedProdTicketModel = null;
		List<TicketMain> ticketMainList = null;
		RefDataValidationReqDTO refDataValidationReqDTO = null;
		RefDataValidationRespDTO refDataValidationRespDTO = null;
		LOGGER.info("###################################### ETLTicketProcessor - process - Start");
		ExceptionTransactionModel exceptionTransactionModel = null; 
		ProdTicketModel prodTicketModel = createProdTicketModel(clientId, amadeusRecordStaging);
		if(prodTicketModel != null && prodTicketModel.getTicketMain().size() > 0) {
			LOGGER.info("###################################### ETLTicketProcessor - prodTicketModel not null & no of tickets : " + prodTicketModel.getTicketMain().size());
			validatedProdTicketModel = new ProdTicketModel();
			ticketMainList = new ArrayList<TicketMain>();
			for(TicketMain ticketMain:prodTicketModel.getTicketMain()) {
				refDataValidationReqDTO = new RefDataValidationReqDTO();
				refDataValidationReqDTO.setClientId(clientId);
				refDataValidationReqDTO.setTicketMain(ticketMain);
				exceptionTransactionModel = createExceptionTxnModel(clientId, amadeusRecordStaging.getCouponNumber(), ticketMain);
				refDataValidationReqDTO.setExceptionTransactionModel(exceptionTransactionModel);
				try {
					refDataValidationRespDTO = validationFeignClient.refDataValidation(refDataValidationReqDTO, MODULE, SOURCE);
					if(refDataValidationRespDTO.getOveralValidationStatus()) {
						if(SmartPRACommonUtil.isNullOrTrimEmpty(ticketMain.getDocType())) ticketMain.setDocType(refDataValidationRespDTO.getDocType());
						if(SmartPRACommonUtil.isNullOrTrimEmpty(ticketMain.getDocClass())) ticketMain.setDocClass(refDataValidationRespDTO.getDocClass());
						if(SmartPRACommonUtil.isNullOrTrimEmpty(ticketMain.getReportingAgentCode())) ticketMain.setReportingAgentCode(refDataValidationRespDTO.getReportingAgentCode());
						if(SmartPRACommonUtil.isNullOrTrimEmpty(ticketMain.getPlaceOfIssue())) ticketMain.setPlaceOfIssue(refDataValidationRespDTO.getPlaceOfIssue());
						if(SmartPRACommonUtil.isNullOrTrimEmpty(ticketMain.getPlaceOfSale())) ticketMain.setPlaceOfSale(refDataValidationRespDTO.getPlaceOfSale());
						for(TicketCoupon ticketCoupon:ticketMain.getTicketCoupons()) {
							ticketCoupon.setMarketingCarrierNumCode(refDataValidationRespDTO.getMarketingCarrierNumCodesMap().get(ticketCoupon.getCouponNumber()));
						}
						ticketMainList.add(ticketMain);
					}
				} catch(ResponseStatusException respStatException) {
					LOGGER.error("validationFeignClient.refDataValidation() throws exception : " + respStatException.getMessage()); 
				} 
			}
			validatedProdTicketModel.setTicketMain(ticketMainList);
		}
		LOGGER.info("###################################### ETLTicketProcessor - process - End");
		return validatedProdTicketModel;
	}	
	public ProdTicketModel createProdTicketModel(String clientId, AmadeusRecordStaging amadeusRecordStaging) throws Exception {
		ProdTicketModel prodTicketModel = new ProdTicketModel();
		LOGGER.info("###################################### ETLTicketProcessor - createProdTicketModel - Start");
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("ddMMyy");
		SimpleDateFormat sDtFormat_DDMMMYY = new SimpleDateFormat("ddMMMyy");
		List<TicketMain> ticketMainList = new ArrayList<TicketMain>();
		int j = 0;
		DocumentIdsReader savedDocUniqueIds = DocumentIdsReader.getInstance();
		// Unique columns for all ticket / coupon tables
		String issueAirline = amadeusRecordStaging.getIssAirline();
		String mainDocumentNo = amadeusRecordStaging.getUsageDocNumber().substring(0, 10);
		String documentNumberstr = amadeusRecordStaging.getUsageDocNumber();
		String documentUniqueid = null;
		String updatedDocNumber = null;
		String originalDocumentUniqueid = null;
		Date originalIssueDate = null;
		TicketMain ticketMain = null;
		int documentCount = documentNumberstr.length() / 10;
		List<String> documentNumberList = new ArrayList<String>();
		for (int k = 0; k < documentCount; k++) {
			updatedDocNumber = documentNumberstr.substring((k * 10), (k * 10) + 10);
			documentNumberList.add(updatedDocNumber);
			documentUniqueid = clientId + issueAirline + updatedDocNumber
					+ amadeusRecordStaging.getIssueDate();
			if(savedDocUniqueIds.findDocUniqueId(documentUniqueid) != null) {
				LOGGER.error("Document id already loaded inthis file : &" + Thread.currentThread().getId() + "- size=" + savedDocUniqueIds.getSize() + "&"+ documentUniqueid);
				//return null;
			} else { 
				savedDocUniqueIds.addDocUniqueId(documentUniqueid);
				// Duplicate record check
				Optional<TicketMain> ticketMainOpt = ticketMainRepository.getByDocumentUniqueIdNativeQuery(documentUniqueid);
				if(ticketMainOpt.isPresent()) {
					LOGGER.debug("DocumentUniqueId " + documentUniqueid
							+ " already exists in ticketMain table or multiple flown coupon's found in the current file");
				} else {
					/////// integreation reference data check here

					ticketMain = new TicketMain();

					// Original document unique id
					String OriginalIssueAirline = null;
					String originalDocumentNumber = null;

					ticketMain.setIssueAirline(amadeusRecordStaging.getIssAirline());
					ticketMain.setDocumentNumber(updatedDocNumber);

					LOGGER.info("Reported Fare   :{}", amadeusRecordStaging.getReportedFare());
					if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BL)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BT)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_IT)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_NO_FARE)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BULK)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else {
						ticketMain.setGrossFare(new BigDecimal(amadeusRecordStaging.getReportedFare()));
					}
					ticketMain.setCurrencyOfSale(amadeusRecordStaging.getCurrencyOfReportedFare());

					ticketMain.setTicketingModeIndicator(amadeusRecordStaging.getTicketingModeIndicator());
					ticketMain.setIsValidated(AppConstants.IS_VALIDATED);
					ticketMain.setFareCalcModeIndicator(amadeusRecordStaging.getFareCalcModeIndicator());
					ticketMain.setSalesProcessIndicator(AppConstants.SALES_PROCESS_INDICATOR_N);
					ticketMain.setEquivalentCurrencyOfSale(amadeusRecordStaging.getPaymentCurrency());
					if (amadeusRecordStaging.getIssueDate() != null && !amadeusRecordStaging.getIssueDate().isEmpty()) {
						LOGGER.info("Issue Date   :{}", amadeusRecordStaging.getIssueDate());
						ticketMain.setDateOfIssue(AmadeusCommonUtils.getDateOfIssue(amadeusRecordStaging.getIssueDate(), amadeusRecordStaging.getFileSource()));
						LOGGER.info("Date of issue   :{}", amadeusRecordStaging.getIssueDate());
					}
					if (amadeusRecordStaging.getBookingReference() != null
							&& !amadeusRecordStaging.getIssueDate().isEmpty()) {
						ticketMain.setPnr(amadeusRecordStaging.getBookingReference());
					}
					LOGGER.info("TourCode :{}" + amadeusRecordStaging.getTourCode());
					if (amadeusRecordStaging.getTourCode() != null && !amadeusRecordStaging.getTourCode().isEmpty()) {
						ticketMain.setTourCode(amadeusRecordStaging.getTourCode());
					}
					ticketMain.setFca(amadeusRecordStaging.getFareConstruction());
					ticketMain.setPassengerName(amadeusRecordStaging.getPassengerName());
					ticketMain.setNetRemitIndicator(amadeusRecordStaging.getNetRemitIndicator());
					ticketMain.setCreatedBy(amadeusRecordStaging.getCreatedBy());
					ticketMain.setCreatedDate(new Timestamp(new Date().getTime()));
					ticketMain.setClientId(clientId);
					ticketMain.setFileId(amadeusRecordStaging.getFileId());
					ticketMain.setMainDocument(mainDocumentNo);
					if (amadeusRecordStaging.getEquivalentFare().matches("\\d*\\.?\\d+")) {
						ticketMain.setEquivalentFare(new BigDecimal(amadeusRecordStaging.getEquivalentFare()));
					} else if (amadeusRecordStaging.getEquivalentFare() == null
							|| amadeusRecordStaging.getEquivalentFare().length() == 0) {
						amadeusRecordStaging.setEquivalentFare("0");
					} else {
						amadeusRecordStaging.setEquivalentFare("0");
					}

					LOGGER.info("Document Number Derived from Original Issue Information   :{}",
							amadeusRecordStaging.getOriginalIssueInformation());
					if (amadeusRecordStaging.getOriginalIssueInformation() != null
							&& !amadeusRecordStaging.getOriginalIssueInformation().isEmpty()) {
						String originalIssueInformation = amadeusRecordStaging.getOriginalIssueInformation()
								.replaceAll("\\s+", "");
						if (originalIssueInformation.length() == 31 || originalIssueInformation.length() == 30) {
							LOGGER.info("Original Issue Information having length 30 / 31 :{}");
							OriginalIssueAirline = originalIssueInformation.substring(0, 3);
							originalDocumentNumber = originalIssueInformation.substring(3, 13);
							ticketMain.setOriginalIssueAirline(OriginalIssueAirline);
							ticketMain.setOriginalDocumentNumber(originalDocumentNumber);
							ticketMain.setOriginalPlaceOfIssue(originalIssueInformation.substring(13, 16));
							ticketMain
							.setOriginalDateOfIssue(sDtFormat_DDMMMYY.parse(originalIssueInformation.substring(16, 23)));
							ticketMain.setOriginalAgentCode(originalIssueInformation.substring(23, 30));
							originalIssueDate = sDtFormat_DDMMMYY.parse(originalIssueInformation.substring(16, 23));
							originalDocumentUniqueid = clientId + OriginalIssueAirline + originalDocumentNumber
									+ originalIssueInformation.substring(16, 23);
							ticketMain.setOriginalDocumentUniqueId(originalDocumentUniqueid);
							LOGGER.info("original Document Id" + originalDocumentUniqueid);

						} else if (originalIssueInformation.length() == 28) {
							// agencyMasterListfor originalIssueInformation
							LOGGER.info("Original Issue Information having length 28 :{}");
							OriginalIssueAirline = originalIssueInformation.substring(0, 3);
							originalDocumentNumber = originalIssueInformation.substring(3, 13);
							originalIssueDate = sDtFormat_DDMMMYY.parse(originalIssueInformation.substring(13, 20));
							ticketMain.setOriginalIssueAirline(OriginalIssueAirline);
							ticketMain.setOriginalDocumentNumber(originalDocumentNumber);
							ticketMain.setOriginalDateOfIssue(originalIssueDate);
							ticketMain.setOriginalAgentCode(originalIssueInformation.substring(20, 27));
							originalDocumentUniqueid = clientId + OriginalIssueAirline + originalDocumentNumber
									+ originalIssueInformation.substring(13, 20);
							ticketMain.setOriginalDocumentUniqueId(originalDocumentUniqueid);
							LOGGER.info("original Document Id" + originalDocumentUniqueid);

						} else if (originalIssueInformation.length() == 22 && originalIssueInformation.contains("XX")) {

							LOGGER.info("Original Issue Information having length 22 :{}");
							OriginalIssueAirline = originalIssueInformation.substring(0, 3);
							originalIssueDate = sDtFormat_DDMMMYY.parse(originalIssueInformation.substring(8, 15));
							ticketMain.setOriginalIssueAirline(OriginalIssueAirline);
							ticketMain.setOriginalDocumentNumber(originalDocumentNumber);
							ticketMain.setOriginalPlaceOfIssue(originalIssueInformation.substring(5, 8));
							ticketMain.setOriginalDateOfIssue(originalIssueDate);
							ticketMain.setOriginalAgentCode(originalIssueInformation.substring(15, 22));
							ticketMain.setOriginalDocumentUniqueId(originalDocumentUniqueid);

						}

						else {
							LOGGER.info("Error in Original Issue Information having length greater than 31 :{}");
						}

						ticketMain.setPrimeReissue(AppConstants.PRIME_REISSUE_R);
					} else {
						ticketMain.setPrimeReissue(AppConstants.PRIME_REISSUE_P);
					}
					ticketMain.setEndorsements(amadeusRecordStaging.getEndorsementRestrictionText());
					ticketMain.setEticketInd(AppConstants.ETICKET_INDICATOR_DEFAULT);
					ticketMain.setFfyIndicator(AppConstants.FF_INDICATOR_DEFAULT);
					ticketMain.setCodeShareIndicator(AppConstants.CODE_SHARE_INDICATOR_DEFAULT);
					ticketMain.setReportedDate(new Timestamp(new Date().getTime()));
					ticketMain.setFirstTimeProcessed(AppConstants.FIRST_TIME_PROCESSED_DEFAULT);
					ticketMain.setRevenueFlag(AppConstants.REVENUE_FLAG_DEFAULT);
					ticketMain.setProrationMethod(AppConstants.PRORATION_METHOD_DEFAULT);

					if (amadeusRecordStaging.getUsageDocNumber().length() > 10) {
						LOGGER.info(
								"Conjuction Ticket is available :{}" + amadeusRecordStaging.getUsageDocNumber().length()
								+ amadeusRecordStaging.getUsageDocNumber());

						if (ticketMain.getDocumentNumber().equals(ticketMain.getMainDocument())) {
							ticketMain.setConjTicketIndicator(AppConstants.CONJ_TICKET_INDICATOR_NO);
						} else {
							ticketMain.setConjTicketIndicator(AppConstants.CONJ_TICKET_INDICATOR_YES);
						}

					} else {
						LOGGER.info("Conjuction Ticket not available :{}"
								+ amadeusRecordStaging.getUsageDocNumber().length()
								+ amadeusRecordStaging.getUsageDocNumber());
						ticketMain.setConjTicketIndicator(AppConstants.CONJ_TICKET_INDICATOR_NO);
					}

					ticketMain.setMigratedTicket(AppConstants.MIGRATED_TICKET_DEFAULT);
					if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BL)) {
						ticketMain.setBtItIndicator(amadeusRecordStaging.getReportedFare());
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BT)) {
						ticketMain.setBtItIndicator(amadeusRecordStaging.getReportedFare());
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_IT)) {
						ticketMain.setBtItIndicator(amadeusRecordStaging.getReportedFare());
					}
					ticketMain.setCouponUseIndicator(amadeusRecordStaging.getUsageType());
					ticketMain.setFileSource(amadeusRecordStaging.getFileSource());
					ticketMain.setDataSource(amadeusRecordStaging.getFileSource());
					ticketMain.setStatus(AppConstants.STATUS_PRODUCTION);
					if (amadeusRecordStaging.getAmadeusRecordDetailStgs().get(0) != null) {
						if (amadeusRecordStaging.getAmadeusRecordDetailStgs().get(0)
								.getInvoluntaryIndicator() != null) {
							ticketMain.setInvolIndicator(
									amadeusRecordStaging.getAmadeusRecordDetailStgs().get(0).getInvoluntaryIndicator());
						}

					}
					ticketMain.setAgentCode(amadeusRecordStaging.getAgencyNumber());
					ticketMain.setDocumentUniqueId(documentUniqueid);

					List<TicketCoupon> ticketCouponList = new ArrayList<TicketCoupon>();
					TicketCoupon ticketCoupon;

					for (AmadeusRecordDetailStaging recordDetailStaging : amadeusRecordStaging
							.getAmadeusRecordDetailStgs()) {
						Integer saleCoupon = Integer.parseInt(recordDetailStaging.getSaleCouponNumber());
						if (saleCoupon > (k * 4) && saleCoupon < ((k * 4) + 5)) {
							ticketCoupon = new TicketCoupon();
							ticketCoupon.setDocumentUniqueId(documentUniqueid);
							ticketCoupon.setIssueAirline(issueAirline);
							ticketCoupon.setDocumentNumber(updatedDocNumber);
							ticketCoupon.setMainDocument(mainDocumentNo);
							if (recordDetailStaging.getSaleCouponNumber() != null
									&& !recordDetailStaging.getSaleCouponNumber().isEmpty()) {

								if (saleCoupon % 4 == 0) {
									ticketCoupon.setCouponNumber(AppConstants.COUPON_NUMBER);
								} else {
									ticketCoupon.setCouponNumber(saleCoupon % AppConstants.COUPON_NUMBER);
								}

							}
							if (recordDetailStaging.getOrigin() != null && !recordDetailStaging.getOrigin().isEmpty()) {
								ticketCoupon.setFromAirport(recordDetailStaging.getOrigin());
							}

							if (recordDetailStaging.getDestination() != null
									&& !recordDetailStaging.getDestination().isEmpty()) {
								ticketCoupon.setToAirport(recordDetailStaging.getDestination());
							}

							if (recordDetailStaging.getSaleFlightNumber() != null
									&& !recordDetailStaging.getSaleFlightNumber().isEmpty()) {
								if (recordDetailStaging.getSaleFlightNumber().equals(AppConstants.REPORTED_FARE_BL)) {
									ticketCoupon.setMarketingFlightNumber(AppConstants.MARKETING_FLIGHT_NUMBER_DEFAULT);
								} else if (recordDetailStaging.getSaleFlightNumber()
										.equals(AppConstants.REPORTED_FARE_BT)) {
									ticketCoupon.setMarketingFlightNumber(AppConstants.MARKETING_FLIGHT_NUMBER_DEFAULT);
								} else if (recordDetailStaging.getSaleFlightNumber()
										.equals(AppConstants.REPORTED_FARE_IT)) {
									ticketCoupon.setMarketingFlightNumber(AppConstants.MARKETING_FLIGHT_NUMBER_DEFAULT);
								} else if (recordDetailStaging.getSaleFlightNumber().contains(AppConstants.OPEN)) {
									LOGGER.info("Flight Number Open---------->"
											+ recordDetailStaging.getSaleFlightNumber());
									ticketCoupon.setMarketingFlightNumber(AppConstants.OPEN);

								} else {
									ticketCoupon.setMarketingFlightNumber(SmartPRACommonUtil.deriveFlightNo(
											recordDetailStaging.getSaleFlightNumber(), sysParamFlightLen));
								}

							}
							ticketCoupon.setMarketingCarrierAlphaCode(recordDetailStaging.getAirlineCode().trim());
							if (recordDetailStaging.getSaleLocalFlightDate() != null) {
								if (recordDetailStaging.getSaleLocalFlightDate().trim()
										.equals(AppConstants.FLIGHT_DATE_OPEN)) {
									LOGGER.info("Flight Date Open-->"
											+ recordDetailStaging.getSaleLocalFlightDate().trim());
									ticketCoupon.setMarketingFlightDate(null);
								} else {
									if (amadeusRecordStaging.getFileSource().equalsIgnoreCase("XL")){
										ticketCoupon.setMarketingFlightDate(ticketCouponList.size()==0 ?
												getFlightDateUsingIssueDate(recordDetailStaging.getSaleLocalFlightDate(), SmartPRACommonUtil.convertToLocalDate(ticketMain.getDateOfIssue())) :
													getFlightDateUsingIssueDate(recordDetailStaging.getSaleLocalFlightDate(),ticketCouponList.get(ticketCouponList.size()-1).getMarketingFlightDate()));
									}else {
										ticketCoupon.setMarketingFlightDate(
												LocalDate.parse(recordDetailStaging.getSaleLocalFlightDate(), dtFormatter));
									}
								}
							}

							ticketCoupon.setTicketedRbd(recordDetailStaging.getSellingClass());
							ticketCoupon.setFareBasis(recordDetailStaging.getFareBasis());
							ticketCoupon.setBookingStatus(recordDetailStaging.getReservationStatus());
							ticketCoupon.setSectorNumber(String.valueOf(saleCoupon));
							LOGGER.info("Sector Number-->" + saleCoupon);
							ticketCoupon.setNotValidBefore(recordDetailStaging.getNotValidBeforeDate());
							ticketCoupon.setNotValidAfter(recordDetailStaging.getNotValidAfterDate());
							ticketCoupon.setCreatedBy(recordDetailStaging.getCreatedBy());
							ticketCoupon.setCreatedDate(new Timestamp(new Date().getTime()));
							ticketCoupon.setFileId(amadeusRecordStaging.getFileId());
							ticketCoupon.setTicketMain(ticketMain);
							ticketCouponList.add(ticketCoupon);
							LOGGER.info("ETLTicketProcessor.process -- End");
						}
					}
					// Surface sector - begin
					Map<Integer, String[]> couponMap = new HashMap<Integer, String[]>();
					String[] airportStr = null;
					Integer maxCouponNo = 0;
					for (AmadeusRecordDetailStaging recordDetailStaging : amadeusRecordStaging
							.getAmadeusRecordDetailStgs()) {
						Integer saleCoupon = Integer.parseInt(recordDetailStaging.getSaleCouponNumber());
						airportStr = new String[2];
						airportStr[0] = recordDetailStaging.getOrigin();
						airportStr[1] = recordDetailStaging.getDestination();
						couponMap.put(saleCoupon, airportStr);
						if (maxCouponNo < saleCoupon) {
							maxCouponNo = saleCoupon;
						}
					}
					Integer[] flagArr = new Integer[maxCouponNo];
					for (int nbr = 1; nbr < maxCouponNo + 1; nbr++) {
						if (((String[]) couponMap.get(nbr)) == null) {
							if (nbr > (k * 4) && nbr < ((k * 4) + 5)) {
								String[] prefRec = couponMap.get(nbr - 1);
								String[] afteRec = couponMap.get(nbr + 1);
								TicketCoupon tktCoupon = new TicketCoupon();

								tktCoupon.setFromAirport(prefRec[1]);
								tktCoupon.setToAirport(afteRec[0]);
								tktCoupon.setMarketingCarrierAlphaCode(AppConstants.SURSECTOR_MARKETTING_CARRIER);
								tktCoupon.setDocumentUniqueId(documentUniqueid);
								tktCoupon.setIssueAirline(issueAirline);
								tktCoupon.setDocumentNumber(updatedDocNumber);
								tktCoupon.setMainDocument(mainDocumentNo);
								tktCoupon.setFileId(ticketMain.getFileId());
								if (nbr % 4 == 0) {
									tktCoupon.setCouponNumber(AppConstants.COUPON_NUMBER);
								} else {
									tktCoupon.setCouponNumber(nbr % AppConstants.COUPON_NUMBER);
								}
								tktCoupon.setSectorNumber(String.valueOf(nbr));
								tktCoupon.setCreatedBy(ticketMain.getCreatedBy());
								tktCoupon.setCreatedDate(new Timestamp(new Date().getTime()));
								tktCoupon.setTicketMain(ticketMain);
								ticketCouponList.add(tktCoupon);
							}

							LOGGER.info("ETLTicketProcessor.process -- End");
						}
					}
					// Surface sector - end
					ticketMain.setTicketCoupons(ticketCouponList);
					if (amadeusRecordStaging.getAmadeusNewTaxStgs() !=null && !amadeusRecordStaging.getAmadeusNewTaxStgs().isEmpty()){
						if (updatedDocNumber.equals(mainDocumentNo)) {
							List<TicketTax> ticketTaxList = new ArrayList<TicketTax>();
							TicketTax ticketTax;
							for (AmadeusNewTaxStaging newTaxStaging : amadeusRecordStaging.getAmadeusNewTaxStgs()) {
								ticketTax = new TicketTax();
								ticketTax.setDocumentUniqueId(documentUniqueid);
								ticketTax.setIssueAirline(issueAirline);
								ticketTax.setDocumentNumber(updatedDocNumber);
								ticketTax.setMainDocument(mainDocumentNo);

								ticketTax.setTaxCode(newTaxStaging.getNewTaxCode());
								BigDecimal txAmt = new BigDecimal(0);
								if (newTaxStaging.getNewTaxValue() != null && !newTaxStaging.getNewTaxValue().isEmpty()) {
									String newTax = newTaxStaging.getNewTaxValue().trim();
									txAmt = new BigDecimal(newTax);
									ticketTax.setTaxAmount(txAmt);
								}
								ticketTax.setSerialNo(++j);
								LOGGER.info("Serial Number fox Tax-->" + j);

								ticketTax.setTaxCurrency(amadeusRecordStaging.getCurrencyOfReportedFare());
								ticketTax.setCreatedBy(amadeusRecordStaging.getCreatedBy());
								ticketTax.setCreatedDate(new Timestamp(new Date().getTime()));
								ticketTax.setTicketMain(ticketMain);
								ticketTaxList.add(ticketTax);
							}
							ticketMain.setTicketTaxs(ticketTaxList);
						}
					}

					// pax type integeration
					PAXTypeModel paxTypeModel = new PAXTypeModel();
					paxTypeModel.setBookingStatus(ticketMain.getTicketCoupons().get(0).getBookingStatus());
					paxTypeModel.setPassengerName(ticketMain.getPassengerName());
					paxTypeModel.setPast(ticketMain.getPaxTypeReceived());
					paxTypeModel.setPassengerDob(ticketMain.getPassengerDob());

					ticketMain.setPaxType(paxTypeFeignClient.getPaxTypeFromTicketMain(paxTypeModel));
					LOGGER.info("PAX TYPE Derivation-----------" + ticketMain.getPaxType());
					ticketMainList.add(ticketMain);
					//docUniqueIdsLoaded.add(documentUniqueid);
				}
			}
		}
		prodTicketModel.setTicketMain(ticketMainList);
		LOGGER.info("###################################### ETLTicketProcessor - createProdTicketModel - End");
		return prodTicketModel;
	}

	private static LocalDate getFlightDateUsingIssueDate(String date, LocalDate localDate) {
		int year = localDate.getYear();
		int month = Month.valueOf(date.substring(2, 5).toUpperCase()).getMonthValue();
		int day = Integer.parseInt(date.substring(0, 2));
		if (localDate.getMonthValue() == month && localDate.getDayOfMonth() > day || localDate.getMonthValue() > month) {
			year = year + 1;
		}
		return LocalDate.of(year, month, day);
	}

	private static ExceptionTransactionModel createExceptionTxnModel(String clientId, String couponNumber, TicketMain ticketMain) {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setClientId(clientId);
		exceptionTransactionModel.setOrderId(String.valueOf(2));// for future use
		exceptionTransactionModel.setCreatedBy(ticketMain.getCreatedBy());
		exceptionTransactionModel.setEnvironment(EnvironmentEnum.STAGING.toString());
		exceptionTransactionModel.setIssuedCarrier(ticketMain.getIssueAirline());
		exceptionTransactionModel.setDocumentUniqueId(ticketMain.getDocumentUniqueId());
		exceptionTransactionModel.setMainDocument(ticketMain.getMainDocument());
		exceptionTransactionModel.setDocumentNumber(ticketMain.getDocumentNumber());
		exceptionTransactionModel.setDateOfIssue(SmartPRACommonUtil.convertToLocalDate(ticketMain.getDateOfIssue()));
		exceptionTransactionModel.setOriginalDocument(ticketMain.getOriginalDocumentNumber());
		if (couponNumber != null && couponNumber.trim().length() > 0) {
			exceptionTransactionModel.setCouponNumber(Integer.parseInt(couponNumber));
		}
		if(ticketMain.getFileId() != null) {
			exceptionTransactionModel.setFileId((long) ticketMain.getFileId());
		}
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setPnr(ticketMain.getPnr());
		return exceptionTransactionModel;
	}
}
