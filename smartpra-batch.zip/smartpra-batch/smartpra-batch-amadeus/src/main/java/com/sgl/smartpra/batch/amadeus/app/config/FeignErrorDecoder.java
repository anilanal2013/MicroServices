package com.sgl.smartpra.batch.amadeus.app.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import feign.codec.ErrorDecoder;

public class FeignErrorDecoder implements ErrorDecoder {

    Logger LOGGER = LoggerFactory.getLogger(this.getClass());
    
    @Override
    public Exception decode(String methodKey, feign.Response response) {
 
    	LOGGER.error("Feign exception thrown with http status : " + response.status() + ", methodKey : " + methodKey );
    	return new ResponseStatusException(HttpStatus.valueOf(response.status())); 
    }      
 }
