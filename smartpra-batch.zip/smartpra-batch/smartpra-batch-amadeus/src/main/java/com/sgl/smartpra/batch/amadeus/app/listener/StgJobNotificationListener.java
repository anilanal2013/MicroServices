package com.sgl.smartpra.batch.amadeus.app.listener;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.AmadeusRecCounts;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;

@Component
public class StgJobNotificationListener extends JobExecutionListenerSupport {

	private static final Logger LOGGER = LoggerFactory.getLogger(StgJobNotificationListener.class);

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Value("${batch.directory.amadeus.input}")
	private String batchInputDir;

	@Value("${batch.directory.amadeus.processed}")
	private String batchProcessedDir;

	@Value("${batch.directory.amadeus.failed}")
	private String batchFailedDir;


	@Override
	public void afterJob(JobExecution jobExecution) {
		LOGGER.info("JobEXecution status : " + jobExecution.getStatus());
		
		StepExecution stepExecution = jobExecution.getStepExecutions().stream().findAny().get();
		if(!jobExecution.getExecutionContext().isEmpty()) {
			Integer headerCount = 0;
			int errorCount = AmadeusRecCounts.getErrorCount();

			long fileId = jobExecution.getJobParameters().getLong("inboundFileId");
			if (fileId == 0 && stepExecution.getExecutionContext().get("fileId") != null) {
				fileId = (Integer) stepExecution.getExecutionContext().get("fileId");
			}
			FileLogging  fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileId));
			String fileName = jobExecution.getJobParameters().getString("inboundFileName");

			Boolean headerFlag = (Boolean) jobExecution.getExecutionContext().get("headerFlag");
			Boolean footerFlag = (Boolean) jobExecution.getExecutionContext().get("footerFlag");
			if(headerFlag != null && headerFlag) headerCount++;
			if(footerFlag != null && footerFlag) headerCount++;
			fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
			if(jobExecution.getStatus() == BatchStatus.COMPLETED) {
				if(errorCount == 0) {
					fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
				} else {
					fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_PARTTRANSFERRED);
					fileLogging.setRemarks("Due to errors in the file only partial records transferred.");
				}
				SmartpraFileUtility.moveFile(batchInputDir + fileName, batchProcessedDir + fileName);
				fileLogging.setIsMovedToRelevantFolder("Y");
				LOGGER.info("!!! JOB FINISHED Successfully !");
			} else {
				String dtStr = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
				fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
				String remarks = (String) jobExecution.getExecutionContext().get("errorRemarks");
				if(remarks != null && remarks.length()>0) {
					fileLogging.setRemarks(remarks); 
				} 
				else {
					fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK); 
				}
				SmartpraFileUtility.moveFile(batchInputDir + fileName, batchFailedDir + fileName + dtStr);
				fileLogging.setIsMovedToRelevantFolder("Y");
				LOGGER.info("!!! JOB FINISHED -FAILED !");
			}
			fileLogging.setErrorCounts(errorCount);
			fileLogging.setTransferredCounts(AmadeusRecCounts.getTransferCount());
			fileLogging.setTotalCounts(AmadeusRecCounts.getTotalCount());
			fileLogging.setDetailCounts(AmadeusRecCounts.getDetailCount());
			fileLogging.setHeaderCounts(headerCount);
			fileLogging = batchGlobalFeignClient.updateFileLog(BigInteger.valueOf(fileId), fileLogging);
		}
	}
}