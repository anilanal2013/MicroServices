package com.sgl.smartpra.batch.amadeus.app.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.ExceptionTxnFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.batch.amadeus.app.utils.AmadeusCommonUtils;
import com.sgl.smartpra.common.constant.CommonExceptionConstants;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.flown.repository.FlownCouponRepository;
import com.sgl.smartpra.sales.repository.TicketCouponRepository;
import com.sgl.smartpra.flown.utils.FlownConstants;
import com.sgl.smartpra.integration.model.DualUtilizationIn;

@Service
@Transactional
public class UtilizationUpdateService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UtilizationUpdateService.class);

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	FlownCouponRepository flownCouponRepository;

	@Autowired
	TicketCouponRepository ticketCouponRepository;

	@Autowired
	private ExceptionTxnFeignClient exceptionTransIntgAppClient;

	@Autowired
	AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	Optional<TicketCoupon> ticketCouponOpt;
	TicketCoupon ticketCoupon;
	String hostCarrierAlphaCode;
	String hostCarrierNumCode;

	public void updateUtilization(Integer fileId) {
		hostCarrierAlphaCode = AmadeusCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		hostCarrierNumCode = AmadeusCommonUtils.getHostCarrierCode(masterFeignClient);
		LOGGER.info("################################# updateUtilization - Start");
		List<FlownCoupon> couponsList = flownCouponRepository
				.findByCouponStatusAndFileId(FlownConstants.FLOWN_COUPON_STATUS_RV, fileId);
		if (couponsList != null) {
			couponsList.parallelStream().forEach(flownCoupon -> {
				updateTicketCoupon(flownCoupon);
			});
			ticketCouponRepository.flush();
		}
		LOGGER.info("################################# updateUtilization - End");
	}

	private void updateTicketCoupon(FlownCoupon flownCoupon) {
		Optional<TicketCoupon> ticketCouponOpt = ticketCouponRepository.findByDocumentUniqueIdAndCouponNumber(
				flownCoupon.getDocumentUniqueId(), flownCoupon.getCouponNumber());
		LOGGER.info("################################# updateTicketCoupon - Start");
		LOGGER.info(flownCoupon.getDocumentUniqueId() + "-" + flownCoupon.getCouponNumber());
		if (ticketCouponOpt.isPresent()) {
			LOGGER.info("Ticket Coupon found........");
			ticketCoupon = ticketCouponOpt.get();
			SimpleDateFormat utilDate = new SimpleDateFormat("yyyy-MM-dd");
			String flightDate = utilDate.format(flownCoupon.getFlightDate());
			String createDate = utilDate.format(flownCoupon.getCreatedDate());
			LOGGER.info("Triggering Dual Utilization Service Starts&&&&&&&&&&&&&");
			System.out.println("date pattern coming as" + flightDate);
			DualUtilizationIn dualUtilizationIn = new DualUtilizationIn();
			dualUtilizationIn.setCouponNumber(Optional.of(flownCoupon.getCouponNumber()));
			dualUtilizationIn.setDocumentNumber(Optional.of(flownCoupon.getDocumentNumber()));
			dualUtilizationIn.setDocumentUniqueId(Optional.of(flownCoupon.getDocumentUniqueId()));
			dualUtilizationIn.setIssueAirline(Optional.of(flownCoupon.getIssueAirline()));
			dualUtilizationIn.setUtilizationDate(Optional.of(flightDate));
			dualUtilizationIn.setUtilizationType(Optional.of(AppConstants.FLOWN_COUPON_U));
			dualUtilizationIn.setBatchKey1(Optional.of(flownCoupon.getFlightNumber()));
			dualUtilizationIn.setBatchKey2(Optional.of(flownCoupon.getFromAirport()));
			dualUtilizationIn.setBatchKey3(Optional.of(flownCoupon.getToAirport()));
			dualUtilizationIn.setBatchKey5(Optional.of(flightDate));
			dualUtilizationIn.setBatchKey6(Optional.of(createDate));
			Boolean utilizationFlag = exceptionTransIntgAppClient.crateDualUtilization(dualUtilizationIn);
			LOGGER.info("Dual Utilization Service Returns &&&&&&&&&&&&" + utilizationFlag);
			if (ticketCoupon.getUtilType() == null && !utilizationFlag) {
				LOGGER.info("Updating Util Type due to Dual Utilization returns false ........");
				ticketCoupon.setUtilType(FlownConstants.FLOWN_UTILIZATION_TYPE);
				ticketCoupon.setOperatingCarrierAlphaCode(hostCarrierAlphaCode);
				ticketCoupon.setOperatingCarrierNumCode(hostCarrierNumCode);
				ticketCoupon.setOperatingFlightDeptDate(flownCoupon.getFlightDate());
				ticketCoupon.setOperatingFlightNumber(flownCoupon.getFlightNumber());
				ticketCouponRepository.save(ticketCoupon);
			}
		}
		LOGGER.info("################################# updateTicketCoupon - End");
	}

	public TicketMain getAmadeusReferenceObject(Integer referenceId) {

		LOGGER.info("################################# Getting Amadeus Reference Object  - Start");
		Optional<AmadeusRecordStaging> amadeusRecordStagingOpt = amadeusRecordStagingRepository
				.findByAmadeusId(referenceId);
		List<TicketCoupon> ticketCouponList = new ArrayList<TicketCoupon>();
		AmadeusRecordStaging amadeusRecordStaging= null;
		TicketMain ticketMain = new TicketMain();
		TicketCoupon ticketCoupon = null;
		if (amadeusRecordStagingOpt.isPresent()) {
			amadeusRecordStaging = amadeusRecordStagingOpt.get();
			ticketMain.setDocumentNumber(amadeusRecordStaging.getDocumentNumber());
			ticketMain.setIssueAirline(amadeusRecordStaging.getIssAirline());
			ticketMain.setDateOfIssue(AmadeusCommonUtils.getDateOfIssue(amadeusRecordStaging.getIssueDate(), amadeusRecordStaging.getFileSource()));
			ticketMain.setAgentCode(amadeusRecordStaging.getAgencyNumber());
			for (AmadeusRecordDetailStaging recordDetailStaging : amadeusRecordStaging.getAmadeusRecordDetailStgs()) {
				ticketCoupon = new TicketCoupon();
				ticketCoupon.setMarketingCarrierAlphaCode(recordDetailStaging.getAirlineCode().trim());
				ticketCouponList.add(ticketCoupon);
			}
			ticketMain.setTicketCoupons(ticketCouponList);
		}
		LOGGER.info("################################# Getting Amadeus Reference Object - End");
		return ticketMain;
	}

}
