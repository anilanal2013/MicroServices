package com.sgl.smartpra.batch.arc.app.processor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.arc.app.util.ARCUtil;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CommissionStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.sales.domain.TicketCommission;
import com.sgl.smartpra.sales.repository.TicketCommissionRepository;

@Component
public class TicketCommissionProcessor {
	
	@Autowired
	TicketCommissionRepository ticketCommissionRepository;
	
	@Autowired
	JdbcTemplate jdbcTemplate;

//	List<String> traansCodeCheck = Arrays.asList("ADM", "ACM", "RCS", "SPD", "SSA", "TAA", "RFN");

	public Map<String, List<TicketCommission>> process(String user,TicketDocumentIdentificationStg ticketDocumentIdentificationStg,
					TransactionHeaderStg transactionHeaderStg, Map<String, String> ticketDoc, Integer decimalPrecision,Integer fileId, Map<String, String> ticktCommisionGMap,Integer salesKey) {

		List<TicketCommission> ticketCommissions = new LinkedList<>();

		Map<String, List<TicketCommission>> ticketCommissionMap = new HashMap<>();
		List<TicketCommission> ticketCommissionTicket = new ArrayList<>();
		List<TicketCommission> ticketCommissioneNonTicket = new ArrayList<>();
		Long docNum = Long.parseLong(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));

		List<CommissionStg> commissionRecordStgs = transactionHeaderStg.getCommissionStg();

//		if (!traansCodeCheck.contains(ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3))) {
			if (!commissionRecordStgs.isEmpty()) {

				int ticketCommissionCount = 0;
				for (int i = 0; i < commissionRecordStgs.size(); i++) {

					if (!commissionRecordStgs.isEmpty() && docNum == Long.parseLong(commissionRecordStgs.get(i).getTktDocNumber().substring(3, 13))) {

						TicketCommission ticketCommission = new TicketCommission();
//TODO ENABLE THIS FOR BSP 
//						String apbcValue = commissionRecordStgs.get(i).getAmountPaidByCustomer();
//						if (!apbcValue.isEmpty() && apbcValue != null) {
//							String apbcSign = BSPUtil.getSignedFieldValue(apbcValue);
//							String apbcString = BSPUtil.getSignedFieldStringValue(apbcSign, decimalPrecision);
//							BigDecimal apbc = BSPUtil.getvalidatedBigDecimal(apbcString);
//							ticketCommission.setApbc(apbc);
//						}
						String efcoValue = commissionRecordStgs.get(i).getEffectiveCommissionAmount();
						if (!efcoValue.isEmpty() && efcoValue != null) {
							String efcoSign = ARCUtil.getSignedFieldValue(efcoValue);
							String efcoString = ARCUtil.getSignedFieldStringValue(efcoSign, decimalPrecision);
							BigDecimal efco = ARCUtil.getvalidatedBigDecimal(efcoString);
							ticketCommission.setEfco(efco);
						}
						ticketCommission.setEfrt(Integer.parseInt(commissionRecordStgs.get(i).getEffectiveCommissionRate()));

						String coamValue = commissionRecordStgs.get(i).getCommissionAmount();
						if (!coamValue.isEmpty() && coamValue != null) {
							String coamSign = ARCUtil.getSignedFieldValue(coamValue);
							String coamString = ARCUtil.getSignedFieldStringValue(coamSign, decimalPrecision);
							BigDecimal coam = ARCUtil.getvalidatedBigDecimal(coamString);
							ticketCommission.setCoam(coam);
						}
						ticketCommission.setCort(Integer.parseInt(commissionRecordStgs.get(i).getCommissionRate()));
						//TODO ENABLE THIS FOR BSP 
//						String spamValue = commissionRecordStgs.get(i).getSupplementaryAmount();
//						if (!spamValue.isEmpty() && spamValue != null) {
//							String spamSign = BSPUtil.getSignedFieldValue(spamValue);
//							String spamString = BSPUtil.getSignedFieldStringValue(spamSign, decimalPrecision);
//							BigDecimal spam = BSPUtil.getvalidatedBigDecimal(spamString);
//							ticketCommission.setSpam(spam);
//						}
//						ticketCommission.setSptp(commissionRecordStgs.get(i).getSupplementaryType());
//						ticketCommission.setSprt(Integer.parseInt(commissionRecordStgs.get(i).getSupplementaryRate()));
//						ticketCommission.setCcai(commissionRecordStgs.get(i).getCommCtrlAdjustmentIndicator());
						ticketCommission.setSerialNo(++ticketCommissionCount);
						ticketCommission.setMainDocument(ticketDoc.get("mainDocument"));
						ticketCommission.setDocumentNo(ticketDoc.get("documentNumber"));
						ticketCommission.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
						ticketCommission.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
						ticketCommission.setCreatedBy(user);
						ticketCommission.setCreatedDate(new Timestamp(new Date().getTime()));
						ticketCommission.setFileId(fileId);
						
					String sql = "SELECT  ticketcomm0_.tkt_comm_dtl_id  FROM smartprasales.ticket_commission ticketcomm0_  WHERE ticketcomm0_.document_unique_id = '"
							+ ticketCommission.getDocumentUniqueId() + "'  AND ticketcomm0_.serial_no = "
							+ ticketCommission.getSerialNo();

					String ticketCommisonKey = ticketCommission.getDocumentUniqueId() + ticketCommission.getSerialNo();
					if (jdbcTemplate.queryForList(sql).isEmpty()) {

						if (!ticktCommisionGMap.containsKey(ticketCommisonKey)) {
							ticktCommisionGMap.put(ticketCommisonKey, ticketCommisonKey);
							ticketCommissionTicket.add(ticketCommission);
						}
					}

				}

				}
			}
//		}
		ticketCommissionMap.put("ticketCommissionTicket", ticketCommissionTicket);
		ticketCommissionMap.put("ticketCommissioneNonTicket", ticketCommissionTicket);
		return ticketCommissionMap;
	}
	

}
