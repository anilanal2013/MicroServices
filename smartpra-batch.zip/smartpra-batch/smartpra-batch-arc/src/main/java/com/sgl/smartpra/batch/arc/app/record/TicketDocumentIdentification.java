package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class TicketDocumentIdentification extends ARCBaseRecord {
	
	public TicketDocumentIdentification() {
	}
	
	
	private String line;
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String reserved;
	private String checkDigitDocNo;
	private String systemProviderIndicator;
	private String filler;
	private String ticketingModeIndicator;
	private String cpnUseIndicator;
	private String conjuctionTicketIndicator;
	private String ticketingCarrierCode;
	private String checkDigitCarrierCode;
	private String electronicTktIndicator;
	private String internationalSaleIndicator;
	private String modifiedDataIndicator;
	private String autoRepricingIndicator;
	private String tourCode;
	private String transactionCode;
	private String ticketDocumentAmtExchange;
	private String trueOrgDestCityCode;
	private String supportDocumentIndicator;
	private String miscFopIndicator;
	private String docType;
	private String pnrRefAirlineDate;
	private String errorCode;
	private String tktCarrierCode;
	private String processingDate;
	private String agentNumericCode;
	private String timeOfIssue;
	private String jrnyTurnaroundAptCityCode;

	@Override
	public String getRecordType() {
		return ARCRecordType.TICKET_DOCUMENT_IDENTIFICATION;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public TicketDocumentIdentification(Map<String, String> recordMap) {
		super(recordMap);
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getReserved() {
		return reserved;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}

	public String getCheckDigitDocNo() {
		return checkDigitDocNo;
	}

	public void setCheckDigitDocNo(String checkDigitDocNo) {
		this.checkDigitDocNo = checkDigitDocNo;
	}

	public String getSystemProviderIndicator() {
		return systemProviderIndicator;
	}

	public void setSystemProviderIndicator(String systemProviderIndicator) {
		this.systemProviderIndicator = systemProviderIndicator;
	}

	public String getTicketingModeIndicator() {
		return ticketingModeIndicator;
	}

	public void setTicketingModeIndicator(String ticketingModeIndicator) {
		this.ticketingModeIndicator = ticketingModeIndicator;
	}


	public String getCpnUseIndicator() {
		return cpnUseIndicator;
	}

	public void setCpnUseIndicator(String cpnUseIndicator) {
		this.cpnUseIndicator = cpnUseIndicator;
	}

	public String getConjuctionTicketIndicator() {
		return conjuctionTicketIndicator;
	}

	public void setConjuctionTicketIndicator(String conjuctionTicketIndicator) {
		this.conjuctionTicketIndicator = conjuctionTicketIndicator;
	}

	public String getTicketingCarrierCode() {
		return ticketingCarrierCode;
	}

	public void setTicketingCarrierCode(String ticketingCarrierCode) {
		this.ticketingCarrierCode = ticketingCarrierCode;
	}

	public String getCheckDigitCarrierCode() {
		return checkDigitCarrierCode;
	}

	public void setCheckDigitCarrierCode(String checkDigitCarrierCode) {
		this.checkDigitCarrierCode = checkDigitCarrierCode;
	}

	public String getElectronicTktIndicator() {
		return electronicTktIndicator;
	}

	public void setElectronicTktIndicator(String electronicTktIndicator) {
		this.electronicTktIndicator = electronicTktIndicator;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getInternationalSaleIndicator() {
		return internationalSaleIndicator;
	}

	public void setInternationalSaleIndicator(String internationalSaleIndicator) {
		this.internationalSaleIndicator = internationalSaleIndicator;
	}

	public String getModifiedDataIndicator() {
		return modifiedDataIndicator;
	}

	public void setModifiedDataIndicator(String modifiedDataIndicator) {
		this.modifiedDataIndicator = modifiedDataIndicator;
	}

	public String getAutoRepricingIndicator() {
		return autoRepricingIndicator;
	}

	public void setAutoRepricingIndicator(String autoRepricingIndicator) {
		this.autoRepricingIndicator = autoRepricingIndicator;
	}

	public String getTourCode() {
		return tourCode;
	}

	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getTicketDocumentAmtExchange() {
		return ticketDocumentAmtExchange;
	}

	public void setTicketDocumentAmtExchange(String ticketDocumentAmtExchange) {
		this.ticketDocumentAmtExchange = ticketDocumentAmtExchange;
	}

	public String getTrueOrgDestCityCode() {
		return trueOrgDestCityCode;
	}

	public void setTrueOrgDestCityCode(String trueOriginDestn) {
		this.trueOrgDestCityCode = trueOriginDestn;
	}

	public String getSupportDocumentIndicator() {
		return supportDocumentIndicator;
	}

	public void setSupportDocumentIndicator(String supportDocumentIndicator) {
		this.supportDocumentIndicator = supportDocumentIndicator;
	}

	public String getMiscFopIndicator() {
		return miscFopIndicator;
	}

	public void setMiscFopIndicator(String miscFopIndicator) {
		this.miscFopIndicator = miscFopIndicator;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getPnrRefAirlineDate() {
		return pnrRefAirlineDate;
	}

	public void setPnrRefAirlineDate(String pnrRef) {
		this.pnrRefAirlineDate = pnrRef;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getTktCarrierCode() {
		return tktCarrierCode;
	}

	public void setTktCarrierCode(String tktCarrierCode) {
		this.tktCarrierCode = tktCarrierCode;
	}

	public String getProcessingDate() {
		return processingDate;
	}

	public void setProcessingDate(String processingDate) {
		this.processingDate = processingDate;
	}

	public String getAgentNumericCode() {
		return agentNumericCode;
	}

	public void setAgentNumericCode(String agentNumericCode) {
		this.agentNumericCode = agentNumericCode;
	}

	public String getTimeOfIssue() {
		return timeOfIssue;
	}

	public void setTimeOfIssue(String timeOfIssue) {
		this.timeOfIssue = timeOfIssue;
	}

	public String getJrnyTurnaroundAptCityCode() {
		return jrnyTurnaroundAptCityCode;
	}

	public void setJrnyTurnaroundAptCityCode(String jrnyTurnaroundAptCityCode) {
		this.jrnyTurnaroundAptCityCode = jrnyTurnaroundAptCityCode;
	}
	
}