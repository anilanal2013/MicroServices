package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

public class FileHeader extends ARCBaseRecord {
	
	@Override
	public String getRecordType() {
		return ARCRecordType.FILE_HEADER;
	}
	
	public FileHeader(Map<String, String> recordMap) {
		super(recordMap);
	}
	
	public FileHeader() {
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}
	
	// variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String bspIdentifier;
	private String tktAirlineCodeNumber;
	private String handbookRevisionNumber;
	private String prodStatus;
	private String processingDate;
	private String processingTime;
	private String isoCityCode;
	private String fileSeqNumber;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getBspIdentifier() {
		return bspIdentifier;
	}

	public void setBspIdentifier(String bspIdentifier) {
		this.bspIdentifier = bspIdentifier;
	}

	public String getTktAirlineCodeNumber() {
		return tktAirlineCodeNumber;
	}

	public void setTktAirlineCodeNumber(String tktAirlineCodeNumber) {
		this.tktAirlineCodeNumber = tktAirlineCodeNumber;
	}

	public String getHandbookRevisionNumber() {
		return handbookRevisionNumber;
	}

	public void setHandbookRevisionNumber(String handbookRevisionNumber) {
		this.handbookRevisionNumber = handbookRevisionNumber;
	}

	public String getProdStatus() {
		return prodStatus;
	}

	public void setProdStatus(String prodStatus) {
		this.prodStatus = prodStatus;
	}

	public String getProcessingDate() {
		return processingDate;
	}

	public void setProcessingDate(String processingDate) {
		this.processingDate = processingDate;
	}

	public String getProcessingTime() {
		return processingTime;
	}

	public void setProcessingTime(String processingTime) {
		this.processingTime = processingTime;
	}

	

	public String getIsoCityCode() {
		return isoCityCode;
	}

	public void setIsoCityCode(String isoCityCode) {
		this.isoCityCode = isoCityCode;
	}

	public String getFileSeqNumber() {
		return fileSeqNumber;
	}

	public void setFileSeqNumber(String fileSeqNumber) {
		this.fileSeqNumber = fileSeqNumber;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}
