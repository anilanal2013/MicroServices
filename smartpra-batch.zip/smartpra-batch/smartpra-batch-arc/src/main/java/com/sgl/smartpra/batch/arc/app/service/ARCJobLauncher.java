package com.sgl.smartpra.batch.arc.app.service;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class ARCJobLauncher {

	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	@Qualifier("loadARCFileDataToStagingJob")
	Job loadARCFileDataToStagingJob;

	@Autowired
	@Qualifier("loadARCFromStagingToProdJob")
	Job loadARCFromStagingToProdJob;

	public String launchARCStagingLoadJob(String fileName, String user, String clientId)
			throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException,
			JobParametersInvalidException {

		// @formatter:off
		
		JobParameters jobParameters = new JobParametersBuilder()
				.addLong("time", System.currentTimeMillis())
				.addString("fileName", fileName)
				.addString("user", user)
				.addString("clientId", clientId)
				.toJobParameters();
		
		JobExecution stagingJobExecution = jobLauncher.run(loadARCFileDataToStagingJob, jobParameters);
		
		// @formatter:on
		if (stagingJobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
			return "ARC Staging Load is completed successfully and initiated Production load....";
		} else {
			return "ARC Staging Load is  failed.....";
		} 
	}

	public void launchARCProdLoadJob(Long fileId, String user) throws JobExecutionAlreadyRunningException,
			JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {

		// @formatter:off
		
		JobParameters jobParameters = new JobParametersBuilder()
				.addLong("time", System.currentTimeMillis())
				.addLong("fileId", fileId)
				.addString("user", user)
				.toJobParameters();
		
		// @formatter:on

		jobLauncher.run(loadARCFromStagingToProdJob, jobParameters);
	}

}