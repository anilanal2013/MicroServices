package com.sgl.smartpra.batch.arc.app.service;

import java.math.BigInteger;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.arc.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.global.model.FileLogging;

@Service
public class FileLoggingDetailTasklet implements Tasklet{

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		BigInteger fileId = new BigInteger(chunkContext.getStepContext().getJobParameters().get("fileId").toString());
		FileLogging fileLogging = batchGlobalFeignClient.getFileLogByFileId(fileId);

		if (fileLogging == null) {
			// TODO handle exception
			throw new Exception("File ID not found");
		}

		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().putString("clientId",
				fileLogging.getClientId());
		
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().putString("fileName",
				fileLogging.getFileName());
		
		return RepeatStatus.FINISHED;
	}

}
