package com.sgl.smartpra.batch.arc.app.mapper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.hazelcast.util.StringUtil;
import com.sgl.smartpra.batch.arc.app.config.FeignConfiguration.CarrierMasterFeignClient;
import com.sgl.smartpra.batch.arc.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.arc.app.record.ARCRecordType;
import com.sgl.smartpra.batch.arc.app.record.OfficeHeader;
import com.sgl.smartpra.batch.arc.app.record.TicketDocumentIdentification;
import com.sgl.smartpra.batch.arc.app.util.ARCConstants;
import com.sgl.smartpra.batch.arc.app.util.ARCUtil;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AgentRegisterStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderWrapperStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeSubtotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionRecordStg;


public class OfficeHeaderMapper {
	
	public static  OfficeHeaderWrapperStg mapOfficeHeaderRecord(OfficeHeader officeHeader, String stationCode,
			String effectiveDateIF ,SmartpraMasterAppClient smartpraMasterAppClient, CarrierMasterFeignClient carrierMasterFeignClient
			,String clientId) {
		
		
		if (officeHeader == null) {
			return null;
		}

		OfficeHeaderWrapperStg officeHeaderWrapperStg = new OfficeHeaderWrapperStg();
		mapOfficeHeader(officeHeaderWrapperStg, officeHeader);
		mapTransactionRecordList(officeHeaderWrapperStg, officeHeader);
		mapOfficeSubtotalsList(officeHeaderWrapperStg, officeHeader);

		int precision = 0;

		try {
			if (!StringUtil.isNullOrEmpty(officeHeader.getCurrencyType())
					&& officeHeader.getCurrencyType().length() > 3) {
				// precision = Integer.parseInt(officeHeader.getCurrencyType().substring(3, 4));
				ARCUtil arcUtil = new ARCUtil();
//				String clientId = stepExecution.getJobExecution().getExecutionContext().getString("clientId");
//				String clientId = "QR";
				String decimalUnitValue = officeHeader.getCurrencyType().substring(3, 4);
				String currencyCode = officeHeader.getCurrencyType().substring(0, 3);
				String effectiveDategiven = officeHeader.getRemittancePeriodEndDate();
				String effectiveDate = null;
				String effectiveDateForIF = null;
				try {
					effectiveDate = arcUtil.getFormattedDate(effectiveDategiven, "yyMMdd", "yyyy-MM-dd");
					effectiveDateForIF = arcUtil.getFormattedDate(effectiveDateIF, "yyMMdd", "yyyy-MM-dd");
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// to get from BSPUtil once the method is fixed
//				precision = 2;
				precision = arcUtil.getDecimalPrecision(smartpraMasterAppClient, Optional.of(stationCode),
						carrierMasterFeignClient, decimalUnitValue, currencyCode, Optional.of(effectiveDate),
						Optional.of(clientId), Optional.of(effectiveDateForIF));
			}
		} catch (NumberFormatException nfe) {
			// fall back method below will be used
		}

		mapAgentRegisterList(officeHeaderWrapperStg, precision);

		return officeHeaderWrapperStg;
	}

	private static void mapOfficeHeader(OfficeHeaderWrapperStg officeHeaderWrapperStg, OfficeHeader officeHeader) {

		OfficeHeaderStg officeHeaderStg = ARCRecordMapper.INSTANCE.mapOfficeHeaderRecord(officeHeader);

		officeHeaderWrapperStg.setOfficeHeaderStg(officeHeaderStg);
	}

	private static void mapTransactionRecordList(OfficeHeaderWrapperStg officeHeaderWrapperStg,
			OfficeHeader officeHeader) {
		if (officeHeader.getTransactionRecordList() == null) {
			return;
		}

		ArrayList<TransactionRecordStg> transactionRecordStgList = new ArrayList<TransactionRecordStg>();

		officeHeader.getTransactionRecordList().forEach(item -> {
			TransactionRecordStg transactionRecordStg = TransactionRecordMapper.mapTransactionRecord(item);
			transactionRecordStgList.add(transactionRecordStg);
		});

		if (transactionRecordStgList.size() > 0) {
			officeHeaderWrapperStg.setTransactionRecordStgList(transactionRecordStgList);
		}
	}

	private static void mapOfficeSubtotalsList(OfficeHeaderWrapperStg officeHeaderWrapperStg,
			OfficeHeader officeHeader) {
		if (officeHeader.getOfficeSubtotalsList() == null) {
			return;
		}

		ArrayList<OfficeSubtotalsStg> officeSubtotalsStgList = new ArrayList<OfficeSubtotalsStg>();

		officeHeader.getOfficeSubtotalsList().forEach(item -> {
			OfficeSubtotalsStg officeSubtotalsStg = ARCRecordMapper.INSTANCE.mapOfficeSubtotalsRecord(item);
			officeSubtotalsStgList.add(officeSubtotalsStg);
		});

		if (officeSubtotalsStgList.size() > 0) {
			officeHeaderWrapperStg.setOfficeSubtotalsStgList(officeSubtotalsStgList);
		}
	}

	private static void mapAgentRegisterList(OfficeHeaderWrapperStg officeHeaderWrapperStg, int finalPrecisionValue) {
		if (officeHeaderWrapperStg.getOfficeSubtotalsStgList() == null || officeHeaderWrapperStg.getTransactionRecordStgList() == null) {
			return;
		}
		final String agentNumericCode = officeHeaderWrapperStg.getOfficeHeaderStg().getAgentNumericCode();
		ArrayList<AgentRegisterStg> agentRegisterList = new ArrayList<AgentRegisterStg>();
		Map<String, Set<String>> agentTranTypeMap = new HashMap<String, Set<String>>();
		Set<String> tranTypeSet = new HashSet<String>();
		officeHeaderWrapperStg.getTransactionRecordStgList().forEach(transactionRecord -> {
			List<FormOfPaymentStg> fopList = transactionRecord.getFormOfPaymentStgList();
			List<TicketDocumentIdentificationStg> tdiStgList = transactionRecord.getTicketDocumentIdentificationStgList();
			tdiStgList.forEach(tdi -> {
				FormOfPaymentStg fopStg = fopList.stream()
						.filter(fop -> fop.getTransactionNumber().equals(tdi.getTransactionNumber())).findFirst()
						.orElse(null);
				String cpnUseIndicator = tdi.getCpnUseIndicator();
				if (cpnUseIndicator != null) {
					if (cpnUseIndicator.startsWith("F") && fopStg != null && fopStg.getFopType().startsWith("EX")) {
						tranTypeSet.add("AS");
					} else if (cpnUseIndicator.contains("R")) {
						tranTypeSet.add("AR");
					} else if (cpnUseIndicator.startsWith("F")) {
						tranTypeSet.add("AS");
					} else if (ARCRecordType.DOCTTYPECLIST.contains(tdi.getDocType())){
						tranTypeSet.add("AC");
					} else if (ARCRecordType.DOCTTYPEDLIST.contains(tdi.getDocType())){
						tranTypeSet.add("AD");
					} else {
						tranTypeSet.add("AS");
					}
				}
				
			});
		});
		agentTranTypeMap.put(agentNumericCode, tranTypeSet);
		agentTranTypeMap.forEach((agentCode, tranTypes) -> {
			// Only one agency is under process
			OfficeSubtotalsStg officeSubtotalsStg = officeHeaderWrapperStg.getOfficeSubtotalsStgList().get(0); 
			tranTypes.forEach(tranType -> {
				AgentRegisterStg agentRegisterStg = new AgentRegisterStg();
				agentRegisterStg.setTransactionType(tranType.trim());
				agentRegisterStg.setAgentNumericCode(ARCUtil
						.getSignedFieldValue(agentNumericCode));
				agentRegisterStg.setRemittancePeriodEndDate(
						ARCUtil.getSignedFieldValue(officeSubtotalsStg.getRemittancePeriodEndDate()));
				agentRegisterStg.setCurrencyType(officeSubtotalsStg.getCurrencyType());

				agentRegisterStg.setGrossValueAmt(ARCUtil
						.getSignedFieldStringValue(officeSubtotalsStg.getGrossValueAmt(), finalPrecisionValue));
				agentRegisterStg.setTotalRemittanceAmount(ARCUtil.getSignedFieldStringValue(
						officeSubtotalsStg.getTotalRemittanceAmount(), finalPrecisionValue));
				agentRegisterStg.setTotalCommissionValueAmt(ARCUtil.getSignedFieldStringValue(
						officeSubtotalsStg.getTotalCommissionValueAmt(), finalPrecisionValue));
				agentRegisterStg.setTotalTaxMiscFeeAmt(ARCUtil.getSignedFieldStringValue(
						officeSubtotalsStg.getTotalTaxMiscFeeAmt(), finalPrecisionValue));
				agentRegisterStg.setTotalTaxOnCommissionAmt(ARCUtil.getSignedFieldStringValue(
						officeSubtotalsStg.getTotalTaxOnCommissionAmt(), finalPrecisionValue));
				agentRegisterList.add(agentRegisterStg);
			});
		});
		
//		Map<String, AgentRegisterStg> agentRegisterMap = new HashMap<String, AgentRegisterStg>();
//
//			officeHeaderWrapperStg.getOfficeSubtotalsStgList().forEach(officeSubtotalsStg -> {
//			String transactionType = officeSubtotalsStg.getTransactionType();
//			String currencyType = officeSubtotalsStg.getCurrencyType();
//			String key = transactionType + ":" + currencyType;
//			
//
//			if (agentRegisterMap.containsKey(key)) {
//				AgentRegisterStg agentRegisterStg = agentRegisterMap.get(key);
//				agentRegisterStg.addGrossValueAmt(
//						BSPUtil.getSignedFieldStringValue(officeSubtotalsStg.getGrossValueAmt(), finalPrecisionValue));
//				agentRegisterStg.addTotalRemittanceAmount(BSPUtil
//						.getSignedFieldStringValue(officeSubtotalsStg.getTotalRemittanceAmount(), finalPrecisionValue));
//				agentRegisterStg.addTotalCommissionValueAmt(BSPUtil.getSignedFieldStringValue(
//						officeSubtotalsStg.getTotalCommissionValueAmt(), finalPrecisionValue));
//				agentRegisterStg.addTotalTaxMiscFeeAmt(BSPUtil
//						.getSignedFieldStringValue(officeSubtotalsStg.getTotalTaxMiscFeeAmt(), finalPrecisionValue));
//				agentRegisterStg.addTotalTaxOnCommissionAmt(BSPUtil.getSignedFieldStringValue(
//						officeSubtotalsStg.getTotalTaxOnCommissionAmt(), finalPrecisionValue));
//				agentRegisterMap.replace(key, agentRegisterStg);
//
//			} else {
//				AgentRegisterStg agentRegisterStg = new AgentRegisterStg();
//				TicketDocumentIdentificationStg ticketDocId  = officeHeaderWrapperStg.getTransactionRecordStgList().get(0).getTicketDocumentIdentificationStgList().get(0);
//				if (BSPRecordType.TRANTYPEMAP.containsKey(ticketDocId.getTransactionCode())) {
//					agentRegisterStg.setTransactionType(BSPRecordType.TRANTYPEMAP.get(ticketDocId.getTransactionCode()));
//				} else {
//					agentRegisterStg.setTransactionType("AS");
//				}
//				//transactionHeaderStg.getTicketDocumentIdentificationStg().get(0).getTransactionCode();
//				agentRegisterStg
//						.setAgentNumericCode(BSPUtil.getSignedFieldValue(officeSubtotalsStg.getAgentNumericCode()));
//				agentRegisterStg.setRemittancePeriodEndDate(
//						BSPUtil.getSignedFieldValue(officeSubtotalsStg.getRemittancePeriodEndDate()));
//				agentRegisterStg.setCurrencyType(officeSubtotalsStg.getCurrencyType());
//				
//				agentRegisterStg.setGrossValueAmt(
//						BSPUtil.getSignedFieldStringValue(officeSubtotalsStg.getGrossValueAmt(), finalPrecisionValue));
//				agentRegisterStg.setTotalRemittanceAmount(BSPUtil
//						.getSignedFieldStringValue(officeSubtotalsStg.getTotalRemittanceAmount(), finalPrecisionValue));
//				agentRegisterStg.setTotalCommissionValueAmt(BSPUtil.getSignedFieldStringValue(
//						officeSubtotalsStg.getTotalCommissionValueAmt(), finalPrecisionValue));
//				agentRegisterStg.setTotalTaxMiscFeeAmt(BSPUtil
//						.getSignedFieldStringValue(officeSubtotalsStg.getTotalTaxMiscFeeAmt(), finalPrecisionValue));
//				agentRegisterStg.setTotalTaxOnCommissionAmt(BSPUtil.getSignedFieldStringValue(
//						officeSubtotalsStg.getTotalTaxOnCommissionAmt(), finalPrecisionValue));
//				agentRegisterMap.put(key, agentRegisterStg);
//
//			}
//		});

		officeHeaderWrapperStg.setAgentRegisterStgList(agentRegisterList);
	}

}
