package com.sgl.smartpra.batch.arc.app.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.arc.app.config.FeignConfiguration.BatchBSPFeignClient;

@Component
public class ARCProductionLoadDelegationListener implements ApplicationListener<ARCProdLoadingEvent> {

	@Autowired
	BatchBSPFeignClient batchBSPFeignClient;
	
	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	@Async
	public void onApplicationEvent(ARCProdLoadingEvent event) {
		try {
			logger.info("Prod Load Triggered");
			batchBSPFeignClient.moveStagingToProd(event.getFileId(), "ARCAdmin", "QR");
		} catch (Exception e) {
			logger.error("Exception occured during prod load", e.getMessage());
		}

	}

}
