package com.sgl.smartpra.batch.arc.app.record;

import java.util.ArrayList;

import com.sgl.smartpra.sales.model.TicketTransactionExtract;

import lombok.NoArgsConstructor;

/**
 * This class represents the logical transaction records
 */
@NoArgsConstructor
public class TransactionRecord  {

	public String getRecordType() {
		return ARCRecordType.TRANSACTION_RECORD;
	}
	
	
	private ArrayList<String> record;
	private TransactionHeader transactionHeader;
	private ArrayList<TicketDocumentIdentification> ticketDocumentIdentificationList;
	private ArrayList<StdDocumentAmounts> stdDocumentAmountsList;
	private ArrayList<Commission> commissionList;
	private ArrayList<RelatedTicketDocumentInfo> relatedTicketDocumentInfoList;
	private ArrayList<WaiverCode> waiverCodeList;
	private ArrayList<QualIssueInfo> qualIssueInfoList;
	private ArrayList<ItineraryDataSegment> itineraryDataSegmentList;
	private AddlInfoPassenger addlInfoPassenger;
	private ArrayList<EMDCouponDetail> emdCouponDetailList;
	private ArrayList<EMDRemarks> emdRemarksList;
	private ArrayList<FareCalculation> fareCalculationList;
	private ArrayList<FormOfPayment> formOfPaymentList;
	private ArrayList<EMDReasonForIssuance> tmp64List;
	private ArrayList<EMDCouponFeeOwner> tmp65List;
	private ArrayList<EMDCouponValue> tmp66List;
	private TicketTransactionExtract ticketTransactionExtract;
	private ArrayList<SRDTicketDocumentId> srdTktDocIdentificationList;

	public ArrayList<String> getRecord() {
		return record;
	}

	public void setRecord(ArrayList<String> record) {
		this.record = record;
	}

	public void addLine(String line) {
		if (this.record == null) {
			this.record = new ArrayList<String>();
		}

		this.record.add(line);
	}

	public TransactionHeader getTransactionHeader() {
		return transactionHeader;
	}

	public void setTransactionHeader(TransactionHeader transactionHeader) {
		this.transactionHeader = transactionHeader;
	}

	public ArrayList<TicketDocumentIdentification> getTicketDocumentIdentificationList() {
		return ticketDocumentIdentificationList;
	}

	public void setTicketDocumentIdentificationList(
			ArrayList<TicketDocumentIdentification> ticketDocumentIdentificationList) {
		this.ticketDocumentIdentificationList = ticketDocumentIdentificationList;
	}

	public void addTicketDocumentIdentification(TicketDocumentIdentification ticketDocumentIdentification) {
		if (this.ticketDocumentIdentificationList == null) {
			this.ticketDocumentIdentificationList = new ArrayList<TicketDocumentIdentification>();
		}

		this.ticketDocumentIdentificationList.add(ticketDocumentIdentification);
	}

	public ArrayList<StdDocumentAmounts> getStdDocumentAmountsList() {
		return stdDocumentAmountsList;
	}

	public void setStdDocumentAmountsList(ArrayList<StdDocumentAmounts> stdDocumentAmountsList) {
		this.stdDocumentAmountsList = stdDocumentAmountsList;
	}

	public void addStdDocumentAmounts(StdDocumentAmounts stdDocumentAmounts) {
		if (this.stdDocumentAmountsList == null) {
			this.stdDocumentAmountsList = new ArrayList<StdDocumentAmounts>();
		}

		this.stdDocumentAmountsList.add(stdDocumentAmounts);
	}

	public ArrayList<Commission> getCommissionList() {
		return commissionList;
	}

	public void setCommissionList(ArrayList<Commission> commissionList) {
		this.commissionList = commissionList;
	}

	public void addCommission(Commission commission) {
		if (this.commissionList == null) {
			this.commissionList = new ArrayList<Commission>();
		}

		this.commissionList.add(commission);
	}


	public ArrayList<RelatedTicketDocumentInfo> getRelatedTicketDocumentInfoList() {
		return relatedTicketDocumentInfoList;
	}

	public void setRelatedTicketDocumentInfoList(ArrayList<RelatedTicketDocumentInfo> relatedTicketDocumentInfoList) {
		this.relatedTicketDocumentInfoList = relatedTicketDocumentInfoList;
	}

	public void addRelatedTicketDocumentInfo(RelatedTicketDocumentInfo relatedTicketDocumentInfo) {
		if (this.relatedTicketDocumentInfoList == null) {
			this.relatedTicketDocumentInfoList = new ArrayList<RelatedTicketDocumentInfo>();
		}

		this.relatedTicketDocumentInfoList.add(relatedTicketDocumentInfo);
	}

	public ArrayList<QualIssueInfo> getQualIssueInfoList() {
		return qualIssueInfoList;
	}

	public void setQualIssueInfoList(ArrayList<QualIssueInfo> qualIssueInfoList) {
		this.qualIssueInfoList = qualIssueInfoList;
	}

	public void addQualIssueInfo(QualIssueInfo qualIssueInfo) {
		if (this.qualIssueInfoList == null) {
			this.qualIssueInfoList = new ArrayList<QualIssueInfo>();
		}

		this.qualIssueInfoList.add(qualIssueInfo);
	}

	public ArrayList<ItineraryDataSegment> getItineraryDataSegmentList() {
		return itineraryDataSegmentList;
	}

	public void setItineraryDataSegmentList(ArrayList<ItineraryDataSegment> itineraryDataSegmentList) {
		this.itineraryDataSegmentList = itineraryDataSegmentList;
	}

	public void addItineraryDataSegment(ItineraryDataSegment itineraryDataSegment) {
		if (this.itineraryDataSegmentList == null) {
			this.itineraryDataSegmentList = new ArrayList<ItineraryDataSegment>();
		}

		this.itineraryDataSegmentList.add(itineraryDataSegment);
	}

	public AddlInfoPassenger getAddlInfoPassenger() {
		return addlInfoPassenger;
	}

	public void setAddlInfoPassenger(AddlInfoPassenger addlInfoPassenger) {
		this.addlInfoPassenger = addlInfoPassenger;
	}

	public ArrayList<EMDCouponDetail> getEmdCouponDetailList() {
		return emdCouponDetailList;
	}

	public void setEmdCouponDetailList(ArrayList<EMDCouponDetail> emdCouponDetailList) {
		this.emdCouponDetailList = emdCouponDetailList;
	}

	public void addEMDCouponDetail(EMDCouponDetail emdCouponDetail) {
		if (this.emdCouponDetailList == null) {
			this.emdCouponDetailList = new ArrayList<EMDCouponDetail>();
		}

		this.emdCouponDetailList.add(emdCouponDetail);
	}

	public ArrayList<EMDRemarks> getEmdRemarksList() {
		return emdRemarksList;
	}

	public void setEmdRemarksList(ArrayList<EMDRemarks> emdRemarksList) {
		this.emdRemarksList = emdRemarksList;
	}

	public void addEMDRemarks(EMDRemarks emdRemarks) {
		if (this.emdRemarksList == null) {
			this.emdRemarksList = new ArrayList<EMDRemarks>();
		}

		this.emdRemarksList.add(emdRemarks);
	}

	public ArrayList<FareCalculation> getFareCalculationList() {
		return fareCalculationList;
	}

	public void setFareCalculationList(ArrayList<FareCalculation> fareCalculationList) {
		this.fareCalculationList = fareCalculationList;
	}

	public void addFareCalculation(FareCalculation fareCalculation) {
		if (this.fareCalculationList == null) {
			this.fareCalculationList = new ArrayList<FareCalculation>();
		}

		this.fareCalculationList.add(fareCalculation);
	}

	public ArrayList<FormOfPayment> getFormOfPaymentList() {
		return formOfPaymentList;
	}

	public void setFormOfPaymentList(ArrayList<FormOfPayment> formOfPaymentList) {
		this.formOfPaymentList = formOfPaymentList;
	}

	public void addFormOfPayment(FormOfPayment formOfPayment) {
		if (this.formOfPaymentList == null) {
			this.formOfPaymentList = new ArrayList<FormOfPayment>();
		}

		this.formOfPaymentList.add(formOfPayment);
	}

	public ArrayList<EMDReasonForIssuance> getTmp64List() {
		return tmp64List;
	}

	public void setTmp64List(ArrayList<EMDReasonForIssuance> tmp64List) {
		this.tmp64List = tmp64List;
	}

	public ArrayList<EMDCouponFeeOwner> getTmp65List() {
		return tmp65List;
	}

	public void setTmp65List(ArrayList<EMDCouponFeeOwner> tmp65List) {
		this.tmp65List = tmp65List;
	}

	public ArrayList<EMDCouponValue> getTmp66List() {
		return tmp66List;
	}

	public void setTmp66List(ArrayList<EMDCouponValue> tmp66List) {
		this.tmp66List = tmp66List;
	}

	public void addTMP64(EMDReasonForIssuance eMDReasonForIssuance) {
		if (this.tmp64List == null) {
			tmp64List = new ArrayList<>();
			tmp64List.add(eMDReasonForIssuance);
		} else {
			tmp64List.add(eMDReasonForIssuance);
		}
	}
	
	public void addTMP65(EMDCouponFeeOwner eMDCouponFeeOwner) {
		if (this.tmp65List == null) {
			tmp65List = new ArrayList<>();
			tmp65List.add(eMDCouponFeeOwner);
		} else {
			tmp65List.add(eMDCouponFeeOwner);
		}
	}
	
	public void addTMP66(EMDCouponValue eMDCouponValue) {
		if (this.tmp66List == null) {
			tmp66List = new ArrayList<>();
			tmp66List.add(eMDCouponValue);
		} else {
			tmp66List.add(eMDCouponValue);
		}
	}
	
	public void addWaiverCode(WaiverCode waiverCode) {
		if (this.waiverCodeList == null) {
			waiverCodeList = new ArrayList<>();
			waiverCodeList.add(waiverCode);
		} else {
			waiverCodeList.add(waiverCode);
		}
	}

	public TicketTransactionExtract getTicketTransactionExtract() {
		return ticketTransactionExtract;
	}

	public void setTicketTransactionExtract(TicketTransactionExtract ticketTransactionExtract) {
		this.ticketTransactionExtract = ticketTransactionExtract;
	}

	public ArrayList<WaiverCode> getWaiverCodeList() {
		return waiverCodeList;
	}

	public void setWaiverCodeList(ArrayList<WaiverCode> waiverCodeList) {
		this.waiverCodeList = waiverCodeList;
	}

	public ArrayList<SRDTicketDocumentId> getSrdTktDocIdentificationList() {
		return srdTktDocIdentificationList;
	}

	public void setSrdTktDocIdentificationList(ArrayList<SRDTicketDocumentId> srdTktDocIdentificationList) {
		this.srdTktDocIdentificationList = srdTktDocIdentificationList;
	}
	
	public void addSrdTktDocIdentification(SRDTicketDocumentId srdTicketDocumentId) {
		if (this.getSrdTktDocIdentificationList()  == null) {
			srdTktDocIdentificationList = new ArrayList<>();
			srdTktDocIdentificationList.add(srdTicketDocumentId);
		} else {
			srdTktDocIdentificationList.add(srdTicketDocumentId);
		}
	}
}