package com.sgl.smartpra.batch.arc.app.reader;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.SingleItemPeekableItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.arc.app.record.ARCBaseRecord;
import com.sgl.smartpra.batch.arc.app.record.ARCRecordType;
import com.sgl.smartpra.batch.arc.app.record.AddlInfoPassenger;
import com.sgl.smartpra.batch.arc.app.record.Commission;
import com.sgl.smartpra.batch.arc.app.record.EMDCouponDetail;
import com.sgl.smartpra.batch.arc.app.record.EMDRemarks;
import com.sgl.smartpra.batch.arc.app.record.FareCalculation;
import com.sgl.smartpra.batch.arc.app.record.FormOfPayment;
import com.sgl.smartpra.batch.arc.app.record.ItineraryDataSegment;
import com.sgl.smartpra.batch.arc.app.record.OfficeHeader;
import com.sgl.smartpra.batch.arc.app.record.OfficeSubtotals;
import com.sgl.smartpra.batch.arc.app.record.QualIssueInfo;
import com.sgl.smartpra.batch.arc.app.record.RelatedTicketDocumentInfo;
import com.sgl.smartpra.batch.arc.app.record.SRDTicketDocumentId;
import com.sgl.smartpra.batch.arc.app.record.StdDocumentAmounts;
import com.sgl.smartpra.batch.arc.app.record.TicketDocumentIdentification;
import com.sgl.smartpra.batch.arc.app.record.TransactionHeader;
import com.sgl.smartpra.batch.arc.app.record.TransactionRecord;
import com.sgl.smartpra.batch.arc.app.record.WaiverCode;

@Component
@StepScope
public class ARCItemReader implements ItemStreamReader<ARCBaseRecord> {
	
	@Autowired
	private Environment env;

	private SingleItemPeekableItemReader<ARCBaseRecord> delegate;

	@Value("${batch.directory.arc.input}")
	private String batchInputDir;

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		FlatFileItemReader<ARCBaseRecord> fileReader = new FlatFileItemReader<ARCBaseRecord>();
		fileReader.setResource(new FileSystemResource(
				batchInputDir + File.separator + stepExecution.getJobParameters().getString("fileName")));
		// get the version number
		String handbookRevisionNumber = stepExecution.getJobExecution().getExecutionContext()
				.getString("handbookRevisionNumber");
		fileReader.setLineMapper(arcLineMapperDynamic(handbookRevisionNumber));
		delegate = new SingleItemPeekableItemReader<ARCBaseRecord>();
		delegate.setDelegate(fileReader);
	}

	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {
		delegate.open(executionContext);
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {
		delegate.update(executionContext);
	}

	@Override
	public void close() throws ItemStreamException {
		delegate.close();

	}

	@Override
	public ARCBaseRecord read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

		TransactionRecord transaction = null;
		ARCBaseRecord arcBaseRecord = null;
		OfficeHeader officeHeader = null;
		String agentNumericCode = "";
		
//		System.out.println("Called Read method");

		while ((arcBaseRecord = (ARCBaseRecord) delegate.read()) != null) {
			
//			System.out.println("Record TYpe :: " + arcBaseRecord.getRecordType());
//			System.out.println("Record  :: " + arcBaseRecord.getLine());
//			if (officeHeader != null) {
//				System.out.println("OfficeHeader is not null");
//			} else {
//				System.out.println("OfficeHeader isnull");
//			}
//			
			switch (arcBaseRecord.getRecordType()) {
			

			case ARCRecordType.OFFICE_HEADER:
				officeHeader = (OfficeHeader) arcBaseRecord;
				agentNumericCode = officeHeader.getAgentNumericCode();
				if (isEndOfOfficeHeader()) {
					return officeHeader;
				}
				break;

			case ARCRecordType.TRANSACTION_HEADER:
				if (officeHeader == null) {
					String errorMessage = "Transaction Header Record (" + ARCRecordType.TRANSACTION_HEADER
							+ ") found without corresponding Office Header Record (" + ARCRecordType.OFFICE_HEADER
							+ ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}

				transaction = new TransactionRecord();
				transaction.setTransactionHeader((TransactionHeader) arcBaseRecord);
				transaction.addLine(((TransactionHeader) arcBaseRecord).getLine());
				//System.out.println("Line TRANSACTION_HEADER :: " + transaction.getRecord().get(transaction.getRecord().size() - 1));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.TICKET_DOCUMENT_IDENTIFICATION:
				if (transaction == null) {
					String errorMessage = "Ticket/Document Identification Record ("
							+ ARCRecordType.TICKET_DOCUMENT_IDENTIFICATION
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				TicketDocumentIdentification tdi = (TicketDocumentIdentification) arcBaseRecord;
				if (StringUtils.isNotEmpty(agentNumericCode)) {
					tdi.setAgentNumericCode(agentNumericCode);
				}
				transaction.addTicketDocumentIdentification(tdi);
				transaction.addLine(((TicketDocumentIdentification) arcBaseRecord).getLine());
				//System.out.println("Line TICKET_DOCUMENT_IDENTIFICATION :: " + transaction.getRecord().get(transaction.getRecord().size() - 1));
				if (isEndOfTransaction()) {
					System.out.println("End Of Transaction in TDI");
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.STD_DOCUMENT_AMOUNTS:
				if (transaction == null) {
					if (transaction == null) {
						String errorMessage = "STD/Document Amounts Record (" + ARCRecordType.STD_DOCUMENT_AMOUNTS
								+ ") found without corresponding Transaction Header Record ("
								+ ARCRecordType.TRANSACTION_HEADER + ")";
						throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
					}
				}
//				System.out.println("Line:: " + arcBaseRecord.getLine());
				transaction.addStdDocumentAmounts((StdDocumentAmounts) arcBaseRecord);
				
				transaction.addLine(((StdDocumentAmounts) arcBaseRecord).getLine());
				//System.out.println("Line STDDocAmount :: " + transaction.getRecord().get(transaction.getRecord().size() - 1));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.COMMISSION:
				if (transaction == null) {
					String errorMessage = "Commission Record (" + ARCRecordType.COMMISSION
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				transaction.addCommission((Commission) arcBaseRecord);
				transaction.addLine(((Commission) arcBaseRecord).getLine());
				//System.out.println("COMMISSION :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.RELATED_TICKET_DOCUMENT_INFO:
				if (transaction == null) {
					String errorMessage = "Related Ticket/Document Information Record ("
							+ ARCRecordType.RELATED_TICKET_DOCUMENT_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
//				transaction.addRelatedTicketDocumentInfo((RelatedTicketDocumentInfo) arcBaseRecord);
				transaction.addLine(((RelatedTicketDocumentInfo) arcBaseRecord).getLine());
				//System.out.println("RELATED_TICKET_DOCUMENT_INFO :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;
			case ARCRecordType.WAIVER_CODE:
				if (transaction == null) {
					String errorMessage = "Waiver Code ("
							+ ARCRecordType.WAIVER_CODE
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				transaction.addWaiverCode((WaiverCode) arcBaseRecord);
				transaction.addLine(((WaiverCode) arcBaseRecord).getLine());
				//System.out.println("RELATED_TICKET_DOCUMENT_INFO :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.QUAL_ISSUE_INFO:
				if (transaction == null) {
					String errorMessage = "Qualifying Issue Information for Sales Transactions Record ("
							+ ARCRecordType.QUAL_ISSUE_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				transaction.addQualIssueInfo((QualIssueInfo) arcBaseRecord);
				transaction.addLine(((QualIssueInfo) arcBaseRecord).getLine());
				//System.out.println("QUAL_ISSUE_INFO :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.ITINERARY_DATA_SEGMENT:
				if (transaction == null) {
					String errorMessage = "Itinerary Data Segment Record (" + ARCRecordType.ITINERARY_DATA_SEGMENT
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				transaction.addItineraryDataSegment((ItineraryDataSegment) arcBaseRecord);
				transaction.addLine(((ItineraryDataSegment) arcBaseRecord).getLine());
				//System.out.println("ITINERARY_DATA_SEGMENT :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.ADDITIONAL_INFO_PASSENGER:
				if (transaction == null) {
					String errorMessage = "Additional Information–Passenger Record ("
							+ ARCRecordType.ADDITIONAL_INFO_PASSENGER
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				transaction.setAddlInfoPassenger((AddlInfoPassenger) arcBaseRecord);
				transaction.addLine(((AddlInfoPassenger) arcBaseRecord).getLine());
				//System.out.println("ADDITIONAL_INFO_PASSENGER :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.EMD_COUPON_DETAIL:
				if (transaction == null) {
					String errorMessage = "Electronic Miscellaneous Document Coupon Detail Record ("
							+ ARCRecordType.EMD_COUPON_DETAIL
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				transaction.addEMDCouponDetail((EMDCouponDetail) arcBaseRecord);
				transaction.addLine(((EMDCouponDetail) arcBaseRecord).getLine());
				//System.out.println("EMD_COUPON_DETAIL :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.EMD_REMARKS:
				if (transaction == null) {
					String errorMessage = "Electronic Miscellaneous Document Remarks Record ("
							+ ARCRecordType.EMD_REMARKS + ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				transaction.addEMDRemarks((EMDRemarks) arcBaseRecord);
				transaction.addLine(((EMDRemarks) arcBaseRecord).getLine());
				//System.out.println("EMD_REMARKS :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.FARE_CALCULATION:
				if (transaction == null) {
					String errorMessage = "Fare Calculation Record (" + ARCRecordType.FARE_CALCULATION
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				transaction.addFareCalculation((FareCalculation) arcBaseRecord);
				transaction.addLine(((FareCalculation) arcBaseRecord).getLine());
				//System.out.println("FARE_CALCULATION :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.FORM_OF_PAYMENT:
				if (transaction == null) {
					String errorMessage = "Form of Payment Record (" + ARCRecordType.FORM_OF_PAYMENT
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				
				
				transaction.addFormOfPayment((FormOfPayment) arcBaseRecord);
				transaction.addLine(((FormOfPayment) arcBaseRecord).getLine());
				//System.out.println("FORM_OF_PAYMENT :: " + transaction.getRecord().get(transaction.getRecord().size() -1 ));
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case ARCRecordType.OFFICE_SUBTOTALS_PER_TRANCODE_CURRTYPE:
//				System.out.println(arcBaseRecord.getLine());
//				System.out.println("OfficeHeader in subtotals "+ officeHeader);
				if (officeHeader == null) {
					String errorMessage = "Office Subtotals per Transaction Code and Currency Type Record ("
							+ ARCRecordType.OFFICE_SUBTOTALS_PER_TRANCODE_CURRTYPE + ") found without corresponding Office Header Record ("
							+ ARCRecordType.OFFICE_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				} else {
					officeHeader.addOfficeSubtotals((OfficeSubtotals) arcBaseRecord);	
				}
				return officeHeader;
			case ARCRecordType.EMD_REASON_ISSUANCE:
				break;
			case ARCRecordType.EMD_FEE_OWNER:
				break;
			case ARCRecordType.EMD_CPN_VALUE:
				break;
			case ARCRecordType.SRD_TKTDOCUMENT_IDENTIFICATION:
				if (transaction == null) {
					String errorMessage = "SRD TKT Document Identification (" + ARCRecordType.SRD_TKTDOCUMENT_IDENTIFICATION
							+ ") found without corresponding Transaction Header Record ("
							+ ARCRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());
				}
				transaction.addSrdTktDocIdentification((SRDTicketDocumentId) arcBaseRecord);
				transaction.addLine(((SRDTicketDocumentId) arcBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;
			case ARCRecordType.SRD_ENDORSEMENTS:
				break;
			case ARCRecordType.SRD_FARE_CALCULATION:
				break;
			case ARCRecordType.SRD_FORM_OF_PAYMENT:
				if (isEndOfSRD()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;	
				}
				break;
			case ARCRecordType.SRD_ITENARY_DATA_SEGMENT:
				break;
			case ARCRecordType.SRD_PSNGR_INFO:
				break;
			case ARCRecordType.SRD_TAX_AMOUNTS:
				break;
			case ARCRecordType.CERTIFICATE_RECORD:
				break;
			case ARCRecordType.XCHG_FORM_PAYMENT_BRKDWN:
				break;
			case ARCRecordType.XCHG_NEW_AUDITORAMT:
				break;
			case ARCRecordType.MISC_COUPON_VALUE:
				break;
			case ARCRecordType.MISC_COUPON_INFO:
				break;
			case ARCRecordType.MISC_COUPON_PRINTLINE:
				break;
			case ARCRecordType.MISC_REASON_FOR_ISSUANCE:
				break;
			case ARCRecordType.MISC_ADDITION_INFO:
				break;
			case ARCRecordType.BILLING_CYCLE_TOTALS_PER_CURRTYPE:
				break;
			case ARCRecordType.DISBURSEMENT_TOTALS:
				break;
			case ARCRecordType.FILE_TOTALS_PER_CURRTYPE:
				return officeHeader;
			default:
				if (officeHeader != null) {
					String errorMessage = "Office Header Record (" + ARCRecordType.OFFICE_HEADER
							+ ") not completed properly.";
					throw new FlatFileParseException(errorMessage, arcBaseRecord.getLine());

				}
//				System.out.println("Default Case Record  :: " + arcBaseRecord.getLine());
				return arcBaseRecord;

			}
		}

		return arcBaseRecord;

	}

	private boolean isEndOfOfficeHeader() throws UnexpectedInputException, ParseException, Exception {
		// peek what is coming next
		ARCBaseRecord nextRecord = (ARCBaseRecord) delegate.peek();
		
		if (nextRecord.getRecordType().equals(ARCRecordType.OFFICE_SUBTOTALS_PER_TRANCODE_CURRTYPE)) {
			return true;
		}
		
		return false;
	}
	
	private boolean isEndOfSRD() throws UnexpectedInputException, ParseException, Exception {
		ARCBaseRecord nextRecord = (ARCBaseRecord) delegate.peek();
		boolean isEndOfSRD = true;
		if (nextRecord == null) {
			return true;
		}

		if (nextRecord.getRecordType().equalsIgnoreCase(ARCRecordType.SRD_TKTDOCUMENT_IDENTIFICATION)) {
			isEndOfSRD = false;
		}
		return isEndOfSRD;
	}
	
	private boolean isEndOfTransaction() throws UnexpectedInputException, ParseException, Exception {
		// peek what is coming next
		ARCBaseRecord nextRecord = (ARCBaseRecord) delegate.peek();

		if (nextRecord == null) {
			return true;
		}

		String nextRecordType = nextRecord.getRecordType();

		switch (nextRecordType) {

		case ARCRecordType.TICKET_DOCUMENT_IDENTIFICATION:
		case ARCRecordType.STD_DOCUMENT_AMOUNTS:
		case ARCRecordType.COMMISSION:
		case ARCRecordType.RELATED_TICKET_DOCUMENT_INFO:
		case ARCRecordType.QUAL_ISSUE_INFO:
		case ARCRecordType.ITINERARY_DATA_SEGMENT:
		case ARCRecordType.ADDITIONAL_INFO_PASSENGER:
		case ARCRecordType.EMD_COUPON_DETAIL:
		case ARCRecordType.EMD_REMARKS:
		case ARCRecordType.FARE_CALCULATION:
		case ARCRecordType.FORM_OF_PAYMENT:
		// Newly added
		case ARCRecordType.EMD_REASON_ISSUANCE:
		case ARCRecordType.EMD_FEE_OWNER:
		case ARCRecordType.EMD_CPN_VALUE:
		case ARCRecordType.WAIVER_CODE:
		case ARCRecordType.XCHG_FORM_PAYMENT_BRKDWN:
		case ARCRecordType.MISC_COUPON_VALUE:
		case ARCRecordType.MISC_COUPON_INFO:
		case ARCRecordType.MISC_COUPON_PRINTLINE:
		case ARCRecordType.MISC_REASON_FOR_ISSUANCE:
		case ARCRecordType.MISC_ADDITION_INFO:
		case ARCRecordType.XCHG_NEW_AUDITORAMT:
		case ARCRecordType.SRD_TKTDOCUMENT_IDENTIFICATION:
		case ARCRecordType.SRD_ENDORSEMENTS:
		case ARCRecordType.SRD_TAX_AMOUNTS:
		case ARCRecordType.SRD_PSNGR_INFO:
		case ARCRecordType.SRD_FARE_CALCULATION:
		case ARCRecordType.SRD_ITENARY_DATA_SEGMENT:
			return false;
		case ARCRecordType.SRD_FORM_OF_PAYMENT:
			return true;
		default:
			return true;
		}
	}
	
	public LineMapper<ARCBaseRecord> arcLineMapperDynamic(String handBookRevisionNo) {
		PatternMatchingCompositeLineMapper<ARCBaseRecord> mapper = new PatternMatchingCompositeLineMapper<>();
		Map<String, FieldSetMapper<ARCBaseRecord>> mappers = new HashMap<String, FieldSetMapper<ARCBaseRecord>>();
		List<String> recordList = Arrays.asList(env.getProperty("arc_records").split(",")); 
		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(100);
		recordList.forEach(e -> {
			String[] mapperDetails = env.getProperty(e).split(",");
//			System.out.println("Pattern :: " + mapperDetails[0]);
//			System.out.println("Class Name :: " + mapperDetails[1]);
			String clazzName = env.getProperty("basepackage").concat(".").concat(mapperDetails[1]);
			try {
				Class<?> clazz = Class.forName(clazzName);
				ARCBaseRecord obj;
				HashMap<String,String> fieldIndexMap = new HashMap<String,String> ();
				List<String> fieldDetailsList = Arrays.asList(env.getProperty("arc_".concat(e).concat("_fields")).split(";"));
				fieldDetailsList.forEach( f -> {
					String[] fieldAndIndex = f.split("#");
					fieldIndexMap.put(fieldAndIndex[0], fieldAndIndex[1]);
				});
				Constructor<?> cons = clazz.getConstructor(Map.class);
				obj = (ARCBaseRecord) cons.newInstance(new Object[] { fieldIndexMap });
				mappers.put(mapperDetails[0], obj.fieldSetMapper());
				tokenizers.put(mapperDetails[0], obj.lineTokenizer(handBookRevisionNo));				
			} catch (Exception e1) {
				e1.printStackTrace();
				throw new RuntimeException("Please verify the Config file");
			}
//			System.out.println("mappers :: "+ mappers.size());
			mapper.setFieldSetMappers(mappers);
			mapper.setTokenizers(tokenizers);
		});
		return mapper;
	}
}
