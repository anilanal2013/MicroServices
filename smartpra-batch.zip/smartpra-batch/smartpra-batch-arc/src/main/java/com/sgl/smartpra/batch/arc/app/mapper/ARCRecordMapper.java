package com.sgl.smartpra.batch.arc.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.sgl.smartpra.batch.arc.app.record.AddlInfoPassenger;
import com.sgl.smartpra.batch.arc.app.record.BillingCycleHeader;
import com.sgl.smartpra.batch.arc.app.record.BillingCycleTotals;
import com.sgl.smartpra.batch.arc.app.record.Commission;
import com.sgl.smartpra.batch.arc.app.record.EMDCouponDetail;
import com.sgl.smartpra.batch.arc.app.record.EMDRemarks;
import com.sgl.smartpra.batch.arc.app.record.FareCalculation;
import com.sgl.smartpra.batch.arc.app.record.FileHeader;
import com.sgl.smartpra.batch.arc.app.record.FileTotals;
import com.sgl.smartpra.batch.arc.app.record.FormOfPayment;
import com.sgl.smartpra.batch.arc.app.record.ItineraryDataSegment;
import com.sgl.smartpra.batch.arc.app.record.OfficeHeader;
import com.sgl.smartpra.batch.arc.app.record.OfficeSubtotals;
import com.sgl.smartpra.batch.arc.app.record.QualIssueInfo;
import com.sgl.smartpra.batch.arc.app.record.RelatedTicketDocumentInfo;
import com.sgl.smartpra.batch.arc.app.record.SRDTicketDocumentId;
import com.sgl.smartpra.batch.arc.app.record.StdDocumentAmounts;
import com.sgl.smartpra.batch.arc.app.record.TicketDocumentIdentification;
import com.sgl.smartpra.batch.arc.app.record.TransactionHeader;
import com.sgl.smartpra.batch.arc.app.record.WaiverCode;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoPassengerStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleTotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CommissionStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDCouponDetailStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDRemarksStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FareCalculationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileTotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.ItineraryDataSegmentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeSubtotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.QualIssueInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.RelatedTicketDocumentInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.StdDocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketTransactionExtractStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.sales.model.TicketTransactionExtract;

@Mapper(componentModel = "Spring")
public interface ARCRecordMapper {

	ARCRecordMapper INSTANCE = Mappers.getMapper(ARCRecordMapper.class);

	FileHeaderStg mapFileHeaderRecord(FileHeader fileHeader);

	BillingCycleHeaderStg mapBillingCycleHeaderRecord(BillingCycleHeader billingCycleHeader);

	OfficeHeaderStg mapOfficeHeaderRecord(OfficeHeader officeHeader);

	OfficeSubtotalsStg mapOfficeSubtotalsRecord(OfficeSubtotals officeSubtotals);

	BillingCycleTotalsStg mapBillingCycleTotalsRecord(BillingCycleTotals billingCycleTotals);

	FileTotalsStg mapFileTotalsRecord(FileTotals fileTotals);

	TransactionHeaderStg mapTransactionHeaderRecord(TransactionHeader transactionHeader);

	TicketDocumentIdentificationStg mapTicketDocumentIdentificationRecord(
			TicketDocumentIdentification ticketDocumentIdentification);

	StdDocumentAmountsStg mapStdDocumentAmountsRecord(StdDocumentAmounts stdDocumentAmounts);

	CommissionStg mapCommissionRecord(Commission commission);


	RelatedTicketDocumentInfoStg mapRelatedTicketDocumentInfoRecord(
			RelatedTicketDocumentInfo relatedTicketDocumentInfo);

	QualIssueInfoStg mapQualIssueInfoRecord(QualIssueInfo qualIssueInfo);

	ItineraryDataSegmentStg mapItineraryDataSegmentRecord(ItineraryDataSegment itineraryDataSegment);

	AddlInfoPassengerStg mapAddlInfoPassengerRecord(AddlInfoPassenger addlInfoPassenger);

	EMDCouponDetailStg mapEMDCouponDetailRecord(EMDCouponDetail emdCouponDetail);

	EMDRemarksStg mapEMDRemarksRecord(EMDRemarks emdRemarks);

	FareCalculationStg mapFareCalculationRecord(FareCalculation fareCalculation);
	
	RelatedTicketDocumentInfoStg mapRelatedTicketDocumentInfoRecord(WaiverCode WaiverCode);
	
	RelatedTicketDocumentInfoStg mapRelatedTicketDocumentInfoRecord(SRDTicketDocumentId srdDocument);

	FormOfPaymentStg mapFormOfPaymentRecord(FormOfPayment formOfPayment);
	
	default TicketTransactionExtractStg mapTicketDataRecord(TicketTransactionExtract ticketTransactionExtract) {
		TicketTransactionExtractStg ticketExtractStage = null;
		if (ticketTransactionExtract != null ) {
			ticketExtractStage = new TicketTransactionExtractStg();
			ticketExtractStage.setTicketExtractId(ticketTransactionExtract.getTicketExtractId());
			ticketExtractStage.setClientId(ticketTransactionExtract.getClientId().get());
			ticketExtractStage.setDocumentUniqueId(ticketTransactionExtract.getDocumentUniqueId().get());
			ticketExtractStage.setFileId(ticketTransactionExtract.getFileId());
			ticketExtractStage.setFileSource(ticketTransactionExtract.getFileSource().get());
			ticketExtractStage.setMainDocumemnt(ticketTransactionExtract.getMainDocument().get());
			ticketExtractStage.setRefundNo(ticketTransactionExtract.getRefundNo().get());
			ticketExtractStage.setTransactionHdrId(ticketTransactionExtract.getTransactionHdrId());
			ticketExtractStage.setTransactionInfoId(ticketTransactionExtract.getTransactionInfoId());
		}
		return ticketExtractStage;
	}

}
