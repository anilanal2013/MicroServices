package com.sgl.smartpra.batch.arc.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EntityScan({ "com.sgl.smartpra.sales.*", "com.sgl.smartpra.batch.bsp.app.*",
		"com.sgl.smartpra.batch.arc.app.controller" })
@EnableJpaRepositories({ "com.sgl.smartpra.sales.*", "com.sgl.smartpra.batch.arc.app.*" , "com.sgl.smartpra.batch.bsp.*" })
@EnableAsync
@EnableFeignClients
public class ARCBatchApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(ARCBatchApplication.class, args);
	}
}
