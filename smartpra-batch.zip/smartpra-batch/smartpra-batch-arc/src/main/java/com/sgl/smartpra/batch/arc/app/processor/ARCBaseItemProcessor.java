package com.sgl.smartpra.batch.arc.app.processor;

import org.springframework.batch.item.ItemProcessor;

import com.sgl.smartpra.batch.arc.app.record.ARCBaseRecord;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;

public abstract class ARCBaseItemProcessor implements ItemProcessor<ARCBaseRecord, BSPStagingDomainObject> {

}
