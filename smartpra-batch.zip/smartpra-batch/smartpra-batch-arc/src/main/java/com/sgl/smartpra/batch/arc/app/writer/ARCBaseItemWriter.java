package com.sgl.smartpra.batch.arc.app.writer;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;

public abstract class ARCBaseItemWriter implements ItemWriter<BSPStagingDomainObject> {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	public void setCreateAuditValues(BSPStagingDomainObject bspStagingDomainObject) {
		bspStagingDomainObject.setCreatedBy(stepExecution.getJobParameters().getString("user"));
		bspStagingDomainObject.setCreatedDate(new Timestamp(new Date().getTime()));
	}

}
