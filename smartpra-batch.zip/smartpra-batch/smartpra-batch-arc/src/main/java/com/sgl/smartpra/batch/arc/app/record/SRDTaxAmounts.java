package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

public class SRDTaxAmounts extends ARCBaseRecord {
	
	
	public SRDTaxAmounts() {
	}
	
	private String line;
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String filler;
	private String transactionNumber;
	private String tktCarrierCode;
	private String tktDocNumber;
	private String reservedSpace;
	private String checkDigit;
	private String tktDocAmount;
	private String fareAmount;
	private String miscFeeType;
	private String miscFeeSubCode;
	private String miscFeeAmount;
	private String miscFeeTypeTwo;
	private String miscFeeSubCodeTwo;
	private String miscFeeAmountTwo;
	private String intlFareAmount;
	private String currencyTypeIntlFare;
	private String decimalPlacesCurrencyIntlFare;
	private String fillerTwo;
	
	@Override
	public String getRecordType() {
		return ARCRecordType.SRD_TAX_AMOUNTS;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public SRDTaxAmounts(Map<String, String> recordMap) {
		super(recordMap);
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktCarrierCode() {
		return tktCarrierCode;
	}

	public void setTktCarrierCode(String tktCarrierCode) {
		this.tktCarrierCode = tktCarrierCode;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getReservedSpace() {
		return reservedSpace;
	}

	public void setReservedSpace(String reservedSpace) {
		this.reservedSpace = reservedSpace;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getTktDocAmount() {
		return tktDocAmount;
	}

	public void setTktDocAmount(String tktDocAmount) {
		this.tktDocAmount = tktDocAmount;
	}

	public String getFareAmount() {
		return fareAmount;
	}

	public void setFareAmount(String fareAmount) {
		this.fareAmount = fareAmount;
	}

	public String getMiscFeeType() {
		return miscFeeType;
	}

	public void setMiscFeeType(String miscFeeType) {
		this.miscFeeType = miscFeeType;
	}

	public String getMiscFeeSubCode() {
		return miscFeeSubCode;
	}

	public void setMiscFeeSubCode(String miscFeeSubCode) {
		this.miscFeeSubCode = miscFeeSubCode;
	}

	public String getMiscFeeAmount() {
		return miscFeeAmount;
	}

	public void setMiscFeeAmount(String miscFeeAmount) {
		this.miscFeeAmount = miscFeeAmount;
	}

	public String getMiscFeeTypeTwo() {
		return miscFeeTypeTwo;
	}

	public void setMiscFeeTypeTwo(String miscFeeTypeTwo) {
		this.miscFeeTypeTwo = miscFeeTypeTwo;
	}

	public String getMiscFeeSubCodeTwo() {
		return miscFeeSubCodeTwo;
	}

	public void setMiscFeeSubCodeTwo(String miscFeeSubCodeTwo) {
		this.miscFeeSubCodeTwo = miscFeeSubCodeTwo;
	}

	public String getMiscFeeAmountTwo() {
		return miscFeeAmountTwo;
	}

	public void setMiscFeeAmountTwo(String miscFeeAmountTwo) {
		this.miscFeeAmountTwo = miscFeeAmountTwo;
	}

	public String getIntlFareAmount() {
		return intlFareAmount;
	}

	public void setIntlFareAmount(String intlFareAmount) {
		this.intlFareAmount = intlFareAmount;
	}

	public String getCurrencyTypeIntlFare() {
		return currencyTypeIntlFare;
	}

	public void setCurrencyTypeIntlFare(String currencyTypeIntlFare) {
		this.currencyTypeIntlFare = currencyTypeIntlFare;
	}

	public String getDecimalPlacesCurrencyIntlFare() {
		return decimalPlacesCurrencyIntlFare;
	}

	public void setDecimalPlacesCurrencyIntlFare(String decimalPlacesCurrencyIntlFare) {
		this.decimalPlacesCurrencyIntlFare = decimalPlacesCurrencyIntlFare;
	}

	public String getFillerTwo() {
		return fillerTwo;
	}

	public void setFillerTwo(String fillerTwo) {
		this.fillerTwo = fillerTwo;
	}

}
