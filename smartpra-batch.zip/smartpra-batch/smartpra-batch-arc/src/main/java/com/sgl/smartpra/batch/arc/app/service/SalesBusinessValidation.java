package com.sgl.smartpra.batch.arc.app.service;

import org.springframework.stereotype.Service;

@Service
public class SalesBusinessValidation {

	
}
