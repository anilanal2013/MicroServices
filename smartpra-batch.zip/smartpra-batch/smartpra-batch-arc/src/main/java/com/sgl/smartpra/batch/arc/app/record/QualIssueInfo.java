package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class QualIssueInfo extends ARCBaseRecord {

	@Override
	public String getRecordType() {
		return ARCRecordType.QUAL_ISSUE_INFO;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}
	
	public QualIssueInfo() {
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public QualIssueInfo(Map<String, String> recordMap) {
		super(recordMap);
	}
	
	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String originalIssueDocTktNumber;
	private String originalIssueLocCityCode;
	private String originalIssueDate;
	private String originalIssueAgentCode;
	private String endorsementRestriction;
	private String filler;
	private String tktCarrierCode;
	private String originalIssueInfo;
	private String reserved;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getOriginalIssueDocTktNumber() {
		return originalIssueDocTktNumber;
	}

	public void setOriginalIssueDocTktNumber(String originalIssueDocTktNumber) {
		this.originalIssueDocTktNumber = originalIssueDocTktNumber;
	}

	public String getOriginalIssueLocCityCode() {
		return originalIssueLocCityCode;
	}

	public void setOriginalIssueLocCityCode(String originalIssueLocCityCode) {
		this.originalIssueLocCityCode = originalIssueLocCityCode;
	}

	public String getOriginalIssueDate() {
		return originalIssueDate;
	}

	public void setOriginalIssueDate(String originalIssueDate) {
		this.originalIssueDate = originalIssueDate;
	}

	public String getOriginalIssueAgentCode() {
		return originalIssueAgentCode;
	}

	public void setOriginalIssueAgentCode(String originalIssueAgentCode) {
		this.originalIssueAgentCode = originalIssueAgentCode;
	}

	public String getEndorsementRestriction() {
		return endorsementRestriction;
	}

	public void setEndorsementRestriction(String endorsementRestriction) {
		this.endorsementRestriction = endorsementRestriction;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getTktCarrierCode() {
		return tktCarrierCode;
	}

	public void setTktCarrierCode(String tktCarrierCode) {
		this.tktCarrierCode = tktCarrierCode;
	}

	public String getOriginalIssueInfo() {
		return originalIssueInfo;
	}

	public void setOriginalIssueInfo(String originalIssueInfo) {
		this.originalIssueInfo = originalIssueInfo;
	}

	public String getReserved() {
		return reserved;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}
}