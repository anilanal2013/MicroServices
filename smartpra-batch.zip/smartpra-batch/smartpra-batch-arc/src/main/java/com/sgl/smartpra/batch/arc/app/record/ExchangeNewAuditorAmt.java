package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

public class ExchangeNewAuditorAmt extends ARCBaseRecord {
	
	public ExchangeNewAuditorAmt() {
	}
	
	private String line;

	@Override
	public String getRecordType() {
		// TODO Auto-generated method stub
		return ARCRecordType.XCHG_NEW_AUDITORAMT;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}
	
	public ExchangeNewAuditorAmt(Map<String, String> recordMap) {
		super(recordMap);
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getLine() {
		return line;
	}

}
