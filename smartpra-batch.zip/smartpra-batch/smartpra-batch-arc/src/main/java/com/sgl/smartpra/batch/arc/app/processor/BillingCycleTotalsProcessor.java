package com.sgl.smartpra.batch.arc.app.processor;

import com.sgl.smartpra.batch.arc.app.mapper.ARCRecordMapper;
import com.sgl.smartpra.batch.arc.app.record.ARCBaseRecord;
import com.sgl.smartpra.batch.arc.app.record.BillingCycleTotals;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleTotalsStg;

public class BillingCycleTotalsProcessor extends ARCBaseItemProcessor {

	@Override
	public BSPStagingDomainObject process(ARCBaseRecord bspBaseRecord) throws Exception {

		BillingCycleTotalsStg billingCycleTotalsStg = ARCRecordMapper.INSTANCE
				.mapBillingCycleTotalsRecord((BillingCycleTotals) bspBaseRecord);
		return billingCycleTotalsStg;
	}
}
