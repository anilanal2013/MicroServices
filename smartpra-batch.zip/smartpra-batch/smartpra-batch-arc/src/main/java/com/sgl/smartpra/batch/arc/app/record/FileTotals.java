package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class FileTotals extends ARCBaseRecord {

	@Override
	public String getRecordType() {
		return ARCRecordType.FILE_TOTALS_PER_CURRTYPE;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}
	
	public FileTotals() {
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public FileTotals(Map<String, String> recordMap) {
		super(recordMap);
	}
	
	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String processCodeIdentifier;
	private String transactionCount;
	private String grossValueAmt;
	private String totalRemittanceAmt;
	private String totalCommissionValueAmt;
	private String totalTaxMiscFeeAmt;
	private String totalTaxOnCommissionAmt;
	private String reservedSpace;
	private String currencyType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getProcessCodeIdentifier() {
		return processCodeIdentifier;
	}

	public void setProcessCodeIdentifier(String bspIdentifier) {
		this.processCodeIdentifier = bspIdentifier;
	}

	public String getTransactionCount() {
		return transactionCount;
	}

	public void setTransactionCount(String officeCount) {
		this.transactionCount = officeCount;
	}

	public String getGrossValueAmt() {
		return grossValueAmt;
	}

	public void setGrossValueAmt(String grossValueAmt) {
		this.grossValueAmt = grossValueAmt;
	}

	public String getTotalRemittanceAmt() {
		return totalRemittanceAmt;
	}

	public void setTotalRemittanceAmt(String totalRemittanceAmt) {
		this.totalRemittanceAmt = totalRemittanceAmt;
	}

	public String getTotalCommissionValueAmt() {
		return totalCommissionValueAmt;
	}

	public void setTotalCommissionValueAmt(String totalCommissionValueAmt) {
		this.totalCommissionValueAmt = totalCommissionValueAmt;
	}

	public String getTotalTaxMiscFeeAmt() {
		return totalTaxMiscFeeAmt;
	}

	public void setTotalTaxMiscFeeAmt(String totalTaxMiscFeeAmt) {
		this.totalTaxMiscFeeAmt = totalTaxMiscFeeAmt;
	}

	public String getTotalTaxOnCommissionAmt() {
		return totalTaxOnCommissionAmt;
	}

	public void setTotalTaxOnCommissionAmt(String totalTaxOnCommissionAmt) {
		this.totalTaxOnCommissionAmt = totalTaxOnCommissionAmt;
	}

	public String getReservedSpace() {
		return reservedSpace;
	}

	public void setReservedSpace(String reservedSpace) {
		this.reservedSpace = reservedSpace;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
}