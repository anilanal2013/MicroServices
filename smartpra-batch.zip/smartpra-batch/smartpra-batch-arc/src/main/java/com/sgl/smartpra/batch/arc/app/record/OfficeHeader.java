package com.sgl.smartpra.batch.arc.app.record;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class OfficeHeader extends ARCBaseRecord  {

	public OfficeHeader(Map<String, String> recordMap) {
		super(recordMap);
	}

	@Override
	public String getRecordType() {
		return ARCRecordType.OFFICE_HEADER;
	}
	
	public OfficeHeader() {
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}
	
	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String agentNumericCode;
	private String remittancePeriodEndDate;
	private String currencyType;
	private String multiLocationIdentifier;
	private String filler;
	private String refNo;
	private String boxNo;
	private String reportPeriod;
	private String processingPeriod;
	private String processingDate;
	private String bspIdentifier;
	private String tktAirlineCodeNumber;
	private String handbookRevisionNumber;
	private HashMap<String, HashSet<String>> agentTransactionTypeMap = new HashMap<String, HashSet<String>> ();
	

	// let us plug all the transaction of Office Header inside it
	private ArrayList<TransactionRecord> transactionRecordList;

	// let us plug all the Office Subtotals of Office Header inside it
	private ArrayList<OfficeSubtotals> officeSubtotalsList;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getAgentNumericCode() {
		return agentNumericCode;
	}

	public void setAgentNumericCode(String agentNumericCode) {
		this.agentNumericCode = agentNumericCode;
	}

	public String getRemittancePeriodEndDate() {
		return remittancePeriodEndDate;
	}

	public void setRemittancePeriodEndDate(String remittancePeriodEndDate) {
		this.remittancePeriodEndDate = remittancePeriodEndDate;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getMultiLocationIdentifier() {
		return multiLocationIdentifier;
	}

	public void setMultiLocationIdentifier(String multiLocationIdentifier) {
		this.multiLocationIdentifier = multiLocationIdentifier;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public ArrayList<TransactionRecord> getTransactionRecordList() {
		return transactionRecordList;
	}

	public void setTransactionRecordList(ArrayList<TransactionRecord> transactionRecordList) {
		this.transactionRecordList = transactionRecordList;
	}

	public void addTransactionRecord(TransactionRecord transactionRecord) {
		if (this.transactionRecordList == null) {
			this.transactionRecordList = new ArrayList<TransactionRecord>();
		}

		this.transactionRecordList.add(transactionRecord);
	}

	public ArrayList<OfficeSubtotals> getOfficeSubtotalsList() {
		return officeSubtotalsList;
	}

	public void setOfficeSubtotalsList(ArrayList<OfficeSubtotals> officeSubtotalsList) {
		this.officeSubtotalsList = officeSubtotalsList;
	}

	public void addOfficeSubtotals(OfficeSubtotals officeSubtotals) {
		if (this.officeSubtotalsList == null) {
			this.officeSubtotalsList = new ArrayList<OfficeSubtotals>();
		}

		this.officeSubtotalsList.add(officeSubtotals);
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getBoxNo() {
		return boxNo;
	}

	public void setBoxNo(String boxNo) {
		this.boxNo = boxNo;
	}

	public String getReportPeriod() {
		return reportPeriod;
	}

	public void setReportPeriod(String reportPeriod) {
		this.reportPeriod = reportPeriod;
	}

	public String getProcessingPeriod() {
		return processingPeriod;
	}

	public void setProcessingPeriod(String processingPeriod) {
		this.processingPeriod = processingPeriod;
	}

	public String getProcessingDate() {
		return processingDate;
	}

	public void setProcessingDate(String processingDate) {
		this.processingDate = processingDate;
	}

	public String getBspIdentifier() {
		return bspIdentifier;
	}

	public void setBspIdentifier(String bspIdentifier) {
		this.bspIdentifier = bspIdentifier;
	}

	public String getTktAirlineCodeNumber() {
		return tktAirlineCodeNumber;
	}

	public void setTktAirlineCodeNumber(String tktAirlineCodeNumber) {
		this.tktAirlineCodeNumber = tktAirlineCodeNumber;
	}

	public String getHandbookRevisionNumber() {
		return handbookRevisionNumber;
	}

	public void setHandbookRevisionNumber(String handbookRevisionNumber) {
		this.handbookRevisionNumber = handbookRevisionNumber;
	}


	public void addTransactionTypeToAgent(String agentCode, String transactionCode) {
		HashSet<String> agentMap = new HashSet<String> ();
		if (agentTransactionTypeMap.containsKey(agentCode)) {
			agentMap = agentTransactionTypeMap.get(agentCode);
			agentMap.add(transactionCode);
			agentTransactionTypeMap.put(agentCode, agentMap);
		} else {
			agentMap.add(transactionCode);
			agentTransactionTypeMap.put(agentCode, agentMap);
		}
	}
}
