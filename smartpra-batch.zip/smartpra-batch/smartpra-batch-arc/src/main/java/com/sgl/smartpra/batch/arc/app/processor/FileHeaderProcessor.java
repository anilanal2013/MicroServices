package com.sgl.smartpra.batch.arc.app.processor;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.arc.app.mapper.ARCRecordMapper;
import com.sgl.smartpra.batch.arc.app.record.ARCBaseRecord;
import com.sgl.smartpra.batch.arc.app.record.FileHeader;
import com.sgl.smartpra.batch.arc.app.util.ARCConstants;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileHeaderStg;

public class FileHeaderProcessor extends ARCBaseItemProcessor {
	
	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Override
	public BSPStagingDomainObject process(ARCBaseRecord arcBaseRecord) throws Exception {

		FileHeaderStg fileHeaderStg = ARCRecordMapper.INSTANCE.mapFileHeaderRecord((FileHeader) arcBaseRecord);
		stepExecution.getJobExecution().getExecutionContext().put(ARCConstants.PROCESSING_PERIOD_ENDDATE, fileHeaderStg.getProcessingDate());
		return fileHeaderStg;

	}
}
