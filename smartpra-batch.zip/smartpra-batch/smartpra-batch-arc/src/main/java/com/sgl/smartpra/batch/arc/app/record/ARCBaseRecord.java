package com.sgl.smartpra.batch.arc.app.record;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.file.transform.Range;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;

public abstract class ARCBaseRecord {
	
	ArrayList<FixedLengthFieldLayout> fixedLengthFieldLayoutList;

	private String line;

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public abstract LineTokenizer lineTokenizer(String handbookRevisionNumber);

	public abstract FieldSetMapper<ARCBaseRecord> fieldSetMapper();

	public abstract String getRecordType();
	
	public ARCBaseRecord() { 
	}
	
	public ARCBaseRecord(Map<String, String> recordMap) { 
		try {
			fixedLengthFieldLayoutList  = new ArrayList<FixedLengthFieldLayout>();
			recordMap.forEach((k, v) -> {
				String[] indexArray = v.split(",");
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout(k, Integer.parseInt(indexArray[0]), Integer.parseInt(indexArray[1])));
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public Range[] getColumns(List<FixedLengthFieldLayout> fixedLengthFieldLayoutList) {

		Range[] rangeArray = new Range[fixedLengthFieldLayoutList.size()];
		int index = 0;
		for (FixedLengthFieldLayout fixedLengthFieldLayout : fixedLengthFieldLayoutList)
			if (fixedLengthFieldLayout.getEndPosition() == null) {
				rangeArray[index] = new Range(fixedLengthFieldLayout.getStartPosition());
			} else {
				rangeArray[index] = new Range(fixedLengthFieldLayout.getStartPosition(),
						fixedLengthFieldLayout.getEndPosition());
				index++;
			}
		return rangeArray;
	}

	public String[] getNames(List<FixedLengthFieldLayout> fixedLengthFieldLayoutList) {

		String[] columNameArray = new String[fixedLengthFieldLayoutList.size()];
		int index = 0;
		for (FixedLengthFieldLayout fixedLengthFieldNameLayout : fixedLengthFieldLayoutList) {
			columNameArray[index] = fixedLengthFieldNameLayout.getFieldname();
			index++;
		}

		return columNameArray;

	}

}
