package com.sgl.smartpra.batch.arc.app.listener;

import org.springframework.context.ApplicationEvent;

public class ARCProdLoadingEvent extends ApplicationEvent {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String userName;

	private long fileId;

	/**
	 * @param userName
	 * @param fileId
	 */
	public ARCProdLoadingEvent(String userName, long fileId) {
		super(fileId);
		this.userName = userName;
		this.fileId = fileId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}
}
