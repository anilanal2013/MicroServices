package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class ItineraryDataSegment extends ARCBaseRecord {

	@Override
	public String getRecordType() {
		return ARCRecordType.ITINERARY_DATA_SEGMENT;
	}
	
	public ItineraryDataSegment() {
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public ItineraryDataSegment(Map<String, String> recordMap) {
		super(recordMap);
	}


	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String segmentIdentifier;
	private String stopoverCode;
	private String notValidBeforeDate;
	private String notValidAfterDate;
	private String orginAirportCityCode;
	private String destAirportCityCode;
	private String carrier;
	private String soldPassengerCabin;
	private String flightNumber;
	private String reservationBookingDesignator;
	private String flightDate;
	private String flightDepartTime;
	private String flightBookingStatus;
	private String baggageAllowance;
	private String fareBasisTktDesignator;
	private String frequentFlyerReference;
	private String fareComProcesPassTypeCode;
	private String changeOfGuageIndicator;
	private String equipmentCode;
	private String filler;
	private String marketingFlightDate;
	private String couponNumber;
	private String tktCarrierCode;
	private String reserved;
	
	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getSegmentIdentifier() {
		return segmentIdentifier;
	}

	public void setSegmentIdentifier(String segmentIdentifier) {
		this.segmentIdentifier = segmentIdentifier;
	}

	public String getStopoverCode() {
		return stopoverCode;
	}

	public void setStopoverCode(String stopoverCode) {
		this.stopoverCode = stopoverCode;
	}

	public String getNotValidBeforeDate() {
		return notValidBeforeDate;
	}

	public void setNotValidBeforeDate(String notValidBeforeDate) {
		this.notValidBeforeDate = notValidBeforeDate;
	}

	public String getNotValidAfterDate() {
		return notValidAfterDate;
	}

	public void setNotValidAfterDate(String notValidAfterDate) {
		this.notValidAfterDate = notValidAfterDate;
	}

	public String getOrginAirportCityCode() {
		return orginAirportCityCode;
	}

	public void setOrginAirportCityCode(String orginAirportCityCode) {
		this.orginAirportCityCode = orginAirportCityCode;
	}

	public String getDestAirportCityCode() {
		return destAirportCityCode;
	}

	public void setDestAirportCityCode(String destAirportCityCode) {
		this.destAirportCityCode = destAirportCityCode;
	}

	public String getCarrier() {
		return carrier;
	}

	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public String getSoldPassengerCabin() {
		return soldPassengerCabin;
	}

	public void setSoldPassengerCabin(String soldPassengerCabin) {
		this.soldPassengerCabin = soldPassengerCabin;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getReservationBookingDesignator() {
		return reservationBookingDesignator;
	}

	public void setReservationBookingDesignator(String reservationBookingDesignator) {
		this.reservationBookingDesignator = reservationBookingDesignator;
	}

	public String getFlightDate() {
		return flightDate;
	}

	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	public String getFlightDepartTime() {
		return flightDepartTime;
	}

	public void setFlightDepartTime(String flightDepartTime) {
		this.flightDepartTime = flightDepartTime;
	}

	public String getFlightBookingStatus() {
		return flightBookingStatus;
	}

	public void setFlightBookingStatus(String flightBookingStatus) {
		this.flightBookingStatus = flightBookingStatus;
	}

	public String getBaggageAllowance() {
		return baggageAllowance;
	}

	public void setBaggageAllowance(String baggageAllowance) {
		this.baggageAllowance = baggageAllowance;
	}

	public String getFareBasisTktDesignator() {
		return fareBasisTktDesignator;
	}

	public void setFareBasisTktDesignator(String fareBasisTktDesignator) {
		this.fareBasisTktDesignator = fareBasisTktDesignator;
	}

	public String getFrequentFlyerReference() {
		return frequentFlyerReference;
	}

	public void setFrequentFlyerReference(String frequentFlyerReference) {
		this.frequentFlyerReference = frequentFlyerReference;
	}

	public String getFareComProcesPassTypeCode() {
		return fareComProcesPassTypeCode;
	}

	public void setFareComProcesPassTypeCode(String fareComProcesPassTypeCode) {
		this.fareComProcesPassTypeCode = fareComProcesPassTypeCode;
	}

	public String getChangeOfGuageIndicator() {
		return changeOfGuageIndicator;
	}

	public void setChangeOfGuageIndicator(String changeOfGuageIndicator) {
		this.changeOfGuageIndicator = changeOfGuageIndicator;
	}

	public String getEquipmentCode() {
		return equipmentCode;
	}

	public void setEquipmentCode(String equipmentCode) {
		this.equipmentCode = equipmentCode;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getMarketingFlightDate() {
		return marketingFlightDate;
	}

	public void setMarketingFlightDate(String marketingFlightDate) {
		this.marketingFlightDate = marketingFlightDate;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getTktCarrierCode() {
		return tktCarrierCode;
	}

	public void setTktCarrierCode(String tktCarrierCode) {
		this.tktCarrierCode = tktCarrierCode;
	}

	public String getReserved() {
		return reserved;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}
}