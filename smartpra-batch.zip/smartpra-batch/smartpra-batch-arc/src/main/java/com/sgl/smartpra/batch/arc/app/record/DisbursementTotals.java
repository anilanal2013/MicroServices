package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class DisbursementTotals extends ARCBaseRecord {
	
	private String line;
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String netCashValueAmount;
	private String disbursementDate;
	private String disbursementCode;
	private String netCashValueAmountTwo;
	private String disbursementDateTwo;
	private String disbursementCodeTwo;
	private String netCashValueAmountThree;
	private String disbursementCodeThree;
	private String disbursementDateThree;
	private String netCashValueAmountFour;
	private String disbursementDateFour;
	private String disbursementCodeFour;
	private String currencyType;
	private String decimalPlacesCurrency;
	private String filler;
	
	
	@Override
	public String getRecordType() {
		return ARCRecordType.DISBURSEMENT_TOTALS;
	}
	
	public DisbursementTotals() {
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public DisbursementTotals(Map<String, String> recordMap) {
		super(recordMap);
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getNetCashValueAmount() {
		return netCashValueAmount;
	}

	public void setNetCashValueAmount(String netCashValueAmount) {
		this.netCashValueAmount = netCashValueAmount;
	}

	public String getDisbursementDate() {
		return disbursementDate;
	}

	public void setDisbursementDate(String disbursementDate) {
		this.disbursementDate = disbursementDate;
	}

	public String getDisbursementCode() {
		return disbursementCode;
	}

	public void setDisbursementCode(String disbursementCode) {
		this.disbursementCode = disbursementCode;
	}

	public String getNetCashValueAmountTwo() {
		return netCashValueAmountTwo;
	}

	public void setNetCashValueAmountTwo(String netCashValueAmountTwo) {
		this.netCashValueAmountTwo = netCashValueAmountTwo;
	}

	public String getDisbursementDateTwo() {
		return disbursementDateTwo;
	}

	public void setDisbursementDateTwo(String disbursementDateTwo) {
		this.disbursementDateTwo = disbursementDateTwo;
	}

	public String getDisbursementCodeTwo() {
		return disbursementCodeTwo;
	}

	public void setDisbursementCodeTwo(String disbursementCodeTwo) {
		this.disbursementCodeTwo = disbursementCodeTwo;
	}

	public String getNetCashValueAmountThree() {
		return netCashValueAmountThree;
	}

	public void setNetCashValueAmountThree(String netCashValueAmountThree) {
		this.netCashValueAmountThree = netCashValueAmountThree;
	}

	public String getDisbursementCodeThree() {
		return disbursementCodeThree;
	}

	public void setDisbursementCodeThree(String disbursementCodeThree) {
		this.disbursementCodeThree = disbursementCodeThree;
	}

	public String getDisbursementDateThree() {
		return disbursementDateThree;
	}

	public void setDisbursementDateThree(String disbursementDateThree) {
		this.disbursementDateThree = disbursementDateThree;
	}

	public String getNetCashValueAmountFour() {
		return netCashValueAmountFour;
	}

	public void setNetCashValueAmountFour(String netCashValueAmountFour) {
		this.netCashValueAmountFour = netCashValueAmountFour;
	}

	public String getDisbursementDateFour() {
		return disbursementDateFour;
	}

	public void setDisbursementDateFour(String disbursementDateFour) {
		this.disbursementDateFour = disbursementDateFour;
	}

	public String getDisbursementCodeFour() {
		return disbursementCodeFour;
	}

	public void setDisbursementCodeFour(String disbursementCodeFour) {
		this.disbursementCodeFour = disbursementCodeFour;
	}

	public String getDecimalPlacesCurrency() {
		return decimalPlacesCurrency;
	}

	public void setDecimalPlacesCurrency(String decimalPlacesCurrency) {
		this.decimalPlacesCurrency = decimalPlacesCurrency;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

}
