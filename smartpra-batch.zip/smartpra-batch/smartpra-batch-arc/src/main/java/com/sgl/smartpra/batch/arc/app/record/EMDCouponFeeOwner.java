package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class EMDCouponFeeOwner extends ARCBaseRecord {
	
	public EMDCouponFeeOwner() {
	}
	
	private String rfisc;
	private String emdFeeOwnerAirlineDesignator;
	private String reasonForIssuanceSubCode;
	private String line;

	@Override
	public String getRecordType() {
		// TODO Auto-generated method stub
		return ARCRecordType.EMD_FEE_OWNER;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public EMDCouponFeeOwner(Map<String, String> recordMap) {
		super(recordMap);
	}

	public String getRfisc() {
		return rfisc;
	}

	public void setRfisc(String rfisc) {
		this.rfisc = rfisc;
	}

	public String getEmdFeeOwnerAirlineDesignator() {
		return emdFeeOwnerAirlineDesignator;
	}

	public void setEmdFeeOwnerAirlineDesignator(String emdFeeOwnerAirlineDesignator) {
		this.emdFeeOwnerAirlineDesignator = emdFeeOwnerAirlineDesignator;
	}

	public String getReasonForIssuanceSubCode() {
		return reasonForIssuanceSubCode;
	}

	public void setReasonForIssuanceSubCode(String reasonForIssuanceSubCode) {
		this.reasonForIssuanceSubCode = reasonForIssuanceSubCode;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

}
