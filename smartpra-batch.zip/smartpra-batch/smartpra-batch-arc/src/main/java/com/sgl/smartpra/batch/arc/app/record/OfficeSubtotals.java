package com.sgl.smartpra.batch.arc.app.record;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.arc.app.util.ARCConstants;

import lombok.NoArgsConstructor;

public class OfficeSubtotals extends ARCBaseRecord {

	@Override
	public String getRecordType() {
		return ARCRecordType.OFFICE_SUBTOTALS_PER_TRANCODE_CURRTYPE;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}
	
	public OfficeSubtotals() {
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public OfficeSubtotals(Map<String, String> recordMap) {
		super(recordMap);
	}

	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQualifier;
	private String agentNumericCode;
	private String remittancePeriodEndDate;
	private String grossValueAmt;
	private String totalRemittanceAmount;
	private String totalCommissionValueAmt;
	private String totalTaxMiscFeeAmt;
	private String transactionCode;
	private String totalTaxOnCommissionAmt;
	private String filler;
	private String currencyType;
	// this is a derived value based on transactionCode
	private String transactionType;
	private String line;
	private String stdNumericQuaifier;
	private String agencyCode;
	private String reportPeriod;
	private String transactionCount;
	private String grossValueAmount;
	private String totalCommissionAmount;
	private String miscFeeAmount;
	private String totalAdjustAmount;
	private String decimalPlacesCurrency;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQualifier() {
		return stdNumericQualifier;
	}

	public void setStdNumericQualifier(String stdNumericQualifier) {
		this.stdNumericQualifier = stdNumericQualifier;
	}

	public String getAgentNumericCode() {
		return agentNumericCode;
	}

	public void setAgentNumericCode(String agentNumericCode) {
		this.agentNumericCode = agentNumericCode;
	}

	public String getRemittancePeriodEndDate() {
		return remittancePeriodEndDate;
	}

	public void setRemittancePeriodEndDate(String remittancePeriodEndDate) {
		this.remittancePeriodEndDate = remittancePeriodEndDate;
	}

	public String getGrossValueAmt() {
		return grossValueAmt;
	}

	public void setGrossValueAmt(String grossValueAmt) {
		this.grossValueAmt = grossValueAmt;
	}

	public String getTotalRemittanceAmount() {
		return totalRemittanceAmount;
	}

	public void setTotalRemittanceAmount(String totalRemittanceAmount) {
		this.totalRemittanceAmount = totalRemittanceAmount;
	}

	public String getTotalCommissionValueAmt() {
		return totalCommissionValueAmt;
	}

	public void setTotalCommissionValueAmt(String totalCommissionValueAmt) {
		this.totalCommissionValueAmt = totalCommissionValueAmt;
	}

	public String getTotalTaxMiscFeeAmt() {
		return totalTaxMiscFeeAmt;
	}

	public void setTotalTaxMiscFeeAmt(String totalTaxMiscFeeAmt) {
		this.totalTaxMiscFeeAmt = totalTaxMiscFeeAmt;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;

		// set the transaction type based on transaction code
		setTransactionTypeForTransactionCode(transactionCode);
	}

	public String getTotalTaxOnCommissionAmt() {
		return totalTaxOnCommissionAmt;
	}

	public void setTotalTaxOnCommissionAmt(String totalTaxOnCommissionAmt) {
		this.totalTaxOnCommissionAmt = totalTaxOnCommissionAmt;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	private void setTransactionTypeForTransactionCode(String transactionCode) {

		List <String> acmCheck = Arrays.asList(ARCConstants.TRANSACTION_TYPE_ACM,ARCConstants.TRANSACTION_TYPE_SPC, ARCConstants.TRANSACTION_TYPE_SSAC);
		List <String> admCheck = Arrays.asList(ARCConstants.TRANSACTION_TYPE_ADM,ARCConstants.TRANSACTION_TYPE_RCS,ARCConstants.TRANSACTION_TYPE_SSAD,
				ARCConstants.TRANSACTION_TYPE_TAA);
		
		if (transactionCode.contentEquals("RFND")) {
			setTransactionType("AR");
		}else if(acmCheck.contains(transactionCode)) {
			setTransactionType("AC");
		}else if(admCheck.contains(transactionCode)) {
			setTransactionType("AD");
		}else {
			setTransactionType("AS");
		}
//		switch (transactionCode) {
//		case "TKTT":
//		case "EMDS":
//			setTransactionType("AS");
//			break;
//		case "RFND":
//			setTransactionType("AR");
//			break;
//		case "ADMA":
//		case "SPDR":
//			setTransactionType("AD");
//			break;
//		case "ACMA":
//		case "SPCR":
//			setTransactionType("AC");
//			break;
//		}
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getReportPeriod() {
		return reportPeriod;
	}

	public void setReportPeriod(String reportPeriod) {
		this.reportPeriod = reportPeriod;
	}

	public String getTransactionCount() {
		return transactionCount;
	}

	public void setTransactionCount(String transactionCount) {
		this.transactionCount = transactionCount;
	}

	public String getGrossValueAmount() {
		return grossValueAmount;
	}

	public void setGrossValueAmount(String grossValueAmount) {
		this.grossValueAmount = grossValueAmount;
	}

	public String getTotalCommissionAmount() {
		return totalCommissionAmount;
	}

	public void setTotalCommissionAmount(String totalCommissionAmount) {
		this.totalCommissionAmount = totalCommissionAmount;
	}

	public String getMiscFeeAmount() {
		return miscFeeAmount;
	}

	public void setMiscFeeAmount(String miscFeeAmount) {
		this.miscFeeAmount = miscFeeAmount;
	}

	public String getTotalAdjustAmount() {
		return totalAdjustAmount;
	}

	public void setTotalAdjustAmount(String totalAdjustAmount) {
		this.totalAdjustAmount = totalAdjustAmount;
	}

	public String getDecimalPlacesCurrency() {
		return decimalPlacesCurrency;
	}

	public void setDecimalPlacesCurrency(String decimalPlacesCurrency) {
		this.decimalPlacesCurrency = decimalPlacesCurrency;
	}

}