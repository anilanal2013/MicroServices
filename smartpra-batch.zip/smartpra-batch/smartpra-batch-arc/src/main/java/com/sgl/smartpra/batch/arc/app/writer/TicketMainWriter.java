package com.sgl.smartpra.batch.arc.app.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

public class TicketMainWriter implements ItemWriter<List<TicketMain>> {

	@Autowired
	private TicketMainRepository ticketMainRepository;

	@Override
	public void write(List<? extends List<TicketMain>> items) throws Exception {
		items.forEach(item -> {
			ticketMainRepository.saveAll(item);
		});
	}

}
