package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class TransactionHeader extends ARCBaseRecord {

	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String transactionNumber;
	private String netReportingIndicator;
	private String transRecordCounter;
	private String tktAirlineCodeNumber;
	private String commAgreementRef;
	private String customerFileRef;
	private String reportingSystemIdentifier;
	private String settlementAuthCode;
	private String dataInputStatusIndicator;
	private String netReportingMethodIndicator;
	private String netReportingCalculationType;
	private String autoRepricingEngIndicator;
	private String filler;
	private String referenceNumber;
	private String box;
	private String boxNo;
	private String invoiceSeqNumber;
	private String transactionRecordCounter;
	private String auditStatusIndicator;
	private String carrierCode;
	private String reserved;
	private String systemProviderIndicator;
	private String tktModeIndicator;
	private String tranDateTime;
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}
	

	@Override
	public String getRecordType() {
		return ARCRecordType.TRANSACTION_HEADER;
	}

	public TransactionHeader(Map<String, String> recordMap) {
		super(recordMap);
	}
	
	public TransactionHeader() {
	}


	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getNetReportingIndicator() {
		return netReportingIndicator;
	}

	public void setNetReportingIndicator(String netReportingIndicator) {
		this.netReportingIndicator = netReportingIndicator;
	}

	public String getTransRecordCounter() {
		return transRecordCounter;
	}

	public void setTransRecordCounter(String transRecordCounter) {
		this.transRecordCounter = transRecordCounter;
	}

	public String getTktAirlineCodeNumber() {
		return tktAirlineCodeNumber;
	}

	public void setTktAirlineCodeNumber(String tktAirlineCodeNumber) {
		this.tktAirlineCodeNumber = tktAirlineCodeNumber;
	}

	public String getCommAgreementRef() {
		return commAgreementRef;
	}

	public void setCommAgreementRef(String commAgreementRef) {
		this.commAgreementRef = commAgreementRef;
	}

	public String getCustomerFileRef() {
		return customerFileRef;
	}

	public void setCustomerFileRef(String customerFileRef) {
		this.customerFileRef = customerFileRef;
	}

	public String getReportingSystemIdentifier() {
		return reportingSystemIdentifier;
	}

	public void setReportingSystemIdentifier(String reportingSystemIdentifier) {
		this.reportingSystemIdentifier = reportingSystemIdentifier;
	}

	public String getSettlementAuthCode() {
		return settlementAuthCode;
	}

	public void setSettlementAuthCode(String settlementAuthCode) {
		this.settlementAuthCode = settlementAuthCode;
	}

	public String getDataInputStatusIndicator() {
		return dataInputStatusIndicator;
	}

	public void setDataInputStatusIndicator(String dataInputStatusIndicator) {
		this.dataInputStatusIndicator = dataInputStatusIndicator;
	}

	public String getNetReportingMethodIndicator() {
		return netReportingMethodIndicator;
	}

	public void setNetReportingMethodIndicator(String netReportingMethodIndicator) {
		this.netReportingMethodIndicator = netReportingMethodIndicator;
	}

	public String getNetReportingCalculationType() {
		return netReportingCalculationType;
	}

	public void setNetReportingCalculationType(String netReportingCalculationType) {
		this.netReportingCalculationType = netReportingCalculationType;
	}

	public String getAutoRepricingEngIndicator() {
		return autoRepricingEngIndicator;
	}

	public void setAutoRepricingEngIndicator(String autoRepricingEngIndicator) {
		this.autoRepricingEngIndicator = autoRepricingEngIndicator;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getBox() {
		return box;
	}

	public void setBox(String box) {
		this.box = box;
	}

	public String getBoxNo() {
		return boxNo;
	}

	public void setBoxNo(String boxNo) {
		this.boxNo = boxNo;
	}

	public String getInvoiceSeqNumber() {
		return invoiceSeqNumber;
	}

	public void setInvoiceSeqNumber(String invoiceSeqNumber) {
		this.invoiceSeqNumber = invoiceSeqNumber;
	}

	public String getTransactionRecordCounter() {
		return transactionRecordCounter;
	}

	public void setTransactionRecordCounter(String transactionRecordCounter) {
		this.transactionRecordCounter = transactionRecordCounter;
	}

	public String getAuditStatusIndicator() {
		return auditStatusIndicator;
	}

	public void setAuditStatusIndicator(String auditStatusIndicator) {
		this.auditStatusIndicator = auditStatusIndicator;
	}

	public String getCarrierCode() {
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}

	public String getReserved() {
		return reserved;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}

	public String getSystemProviderIndicator() {
		return systemProviderIndicator;
	}

	public void setSystemProviderIndicator(String systemProviderIndicator) {
		this.systemProviderIndicator = systemProviderIndicator;
	}

	public String getTktModeIndicator() {
		return tktModeIndicator;
	}

	public void setTktModeIndicator(String tktModeIndicator) {
		this.tktModeIndicator = tktModeIndicator;
	}

	public String getTranDateTime() {
		return tranDateTime;
	}

	public void setTranDateTime(String tranDateTime) {
		this.tranDateTime = tranDateTime;
	}
}