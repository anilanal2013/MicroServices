package com.sgl.smartpra.batch.arc.app.writer;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileHeaderStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.FileHeaderStgRepository;


@Component
@Scope(value="step")
public class FileHeaderWriter extends ARCBaseItemWriter {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private FileHeaderStgRepository fileHeaderStgRepository;

	@Override
	public void write(List<? extends BSPStagingDomainObject> items) throws Exception {

		// Ideally there should be only one File Header
		if (items != null && items.size() > 0) {
			FileHeaderStg fileHeaderStg = (FileHeaderStg) items.get(0);
			fileHeaderStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			fileHeaderStg.setIsoCityCode(fileHeaderStg.getIsoCityCode());
			super.setCreateAuditValues(fileHeaderStg);
			fileHeaderStg = fileHeaderStgRepository.save(fileHeaderStg);

			// store file header id for other records
			stepExecution.getJobExecution().getExecutionContext().putInt("fileHeaderId", fileHeaderStg.getFileHdrId());
			stepExecution.getExecutionContext().put("salesFileHeaderStgCount", items.size());
		}
	}
}
