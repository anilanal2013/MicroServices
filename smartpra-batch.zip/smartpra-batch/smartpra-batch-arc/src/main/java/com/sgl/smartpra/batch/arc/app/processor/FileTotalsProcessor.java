package com.sgl.smartpra.batch.arc.app.processor;

import com.sgl.smartpra.batch.arc.app.mapper.ARCRecordMapper;
import com.sgl.smartpra.batch.arc.app.record.ARCBaseRecord;
import com.sgl.smartpra.batch.arc.app.record.FileTotals;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileTotalsStg;

public class FileTotalsProcessor extends ARCBaseItemProcessor {

	@Override
	public BSPStagingDomainObject process(ARCBaseRecord bspBaseRecord) throws Exception {

		FileTotalsStg fileTotalsStg = ARCRecordMapper.INSTANCE.mapFileTotalsRecord((FileTotals) bspBaseRecord);
		return fileTotalsStg;
	}
}
