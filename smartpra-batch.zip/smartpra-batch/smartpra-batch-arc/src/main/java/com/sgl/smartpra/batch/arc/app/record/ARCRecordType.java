package com.sgl.smartpra.batch.arc.app.record;

import java.util.ArrayList;
import java.util.HashMap;


public class ARCRecordType {

	// Header Records
	public static final String FILE_HEADER = "TTH01";
	public static final String BILLING_CYCLE_HEADER = "TCH02";
	public static final String OFFICE_HEADER = "TOH03";

	// Transaction Records
	public static final String TRANSACTION_HEADER = "TKT06";
	public static final String TICKET_DOCUMENT_IDENTIFICATION = "TKS24";
	public static final String STD_DOCUMENT_AMOUNTS = "TKS30";
	public static final String COMMISSION = "TKS39";
	public static final String RELATED_TICKET_DOCUMENT_INFO = "TKS45";
	public static final String QUAL_ISSUE_INFO = "TKS46";
	public static final String ITINERARY_DATA_SEGMENT = "TKI63";
	public static final String ADDITIONAL_INFO_PASSENGER = "TKS48";
	public static final String EMD_COUPON_DETAIL = "TMP67";
	public static final String EMD_REMARKS = "BMD76";
	public static final String FARE_CALCULATION = "TKF81"; 
	public static final String FORM_OF_PAYMENT = "TKP84";

	// Total Records
	public static final String OFFICE_SUBTOTALS_PER_TRANCODE_CURRTYPE = "TOT94";
	public static final String OFFICE_TOTALS_PER_CURRTYPE = "TOT94";
	public static final String BILLING_CYCLE_TOTALS_PER_CURRTYPE = "TCT95";
	public static final String FILE_TOTALS_PER_CURRTYPE = "TTT99";

	// Transaction record - logical grouping of records that forms a transaction
	public static final String TRANSACTION_RECORD = "ARC_TRAN";
	
	//ADDED FOR ARC
	public static final String EMD_REASON_ISSUANCE= "TMP64";
	public static final String EMD_FEE_OWNER= "TMP65";
	public static final String EMD_CPN_VALUE= "TMP66";
	public static final String WAIVER_CODE= "TKS47";
	public static final String SALES_REPORT_TRAILER= "TOT94";
	public static final String DISBURSEMENT_TOTALS= "TTT98";
	public static final String SRD_TKTDOCUMENT_IDENTIFICATION= "SRD86";
	public static final String SRD_TAX_AMOUNTS= "SRD87";
	public static final String SRD_ENDORSEMENTS= "SRD88";
	public static final String SRD_PSNGR_INFO= "SRD89";
	public static final String SRD_ITENARY_DATA_SEGMENT= "SRD90";
	public static final String SRD_FARE_CALCULATION= "SRD91";
	public static final String SRD_FORM_OF_PAYMENT= "SRD92";
	public static final String CERTIFICATE_RECORD= "TKP85";
	public static final String XCHG_FORM_PAYMENT_BRKDWN = "EXT83";
	public static final String XCHG_NEW_AUDITORAMT = "TKS31";
	public static final String MISC_COUPON_VALUE = "TMP75";
	public static final String MISC_COUPON_INFO = "TMP76";
	public static final String MISC_COUPON_PRINTLINE = "TMP77";
	public static final String MISC_REASON_FOR_ISSUANCE = "TMP70";
	public static final String MISC_ADDITION_INFO = "TMP71";
	public static final ArrayList<String> DOCTTYPECLIST = new ArrayList<String>(){{
		add("ACMA");
		add("ACMD");
		add("ACMS");
		add("ACNT");
		add("SPCR");
		add("SSAC");
		add("TAAD");
		add("RCSM");
	}};
	public static final ArrayList<String> DOCTTYPEDLIST = new ArrayList<String>(){{
		add("ADMA");
		add("ADMD");
		add("ADNT");
		add("ADMS");
		add("RCSM");
		add("SPDR");
		add("SSAD");
	}};
	public static final ArrayList<String> DOCTTYPEVOIDLIST = new ArrayList<String>(){{
		add("CANN");
		add("CANR");
		add("CANX");
	}};
	
	public static final HashMap<String,String> TRANTYPEMAP = new HashMap<String, String>() {{
		put("TKTT", "AS");
		put("RFND", "AR");
		put("ACMA", "AC");
		put("ADMA", "AD");
	}};
	
}
