package com.sgl.smartpra.batch.arc.app.processor;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.arc.app.util.ARCConstants;
import com.sgl.smartpra.batch.arc.app.util.ARCUtil;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.sales.domain.TicketSale;
import com.sgl.smartpra.sales.repository.TicketSaleRepository;

@Component
public class TicketSaleProcessor {

	@Autowired
	TicketSaleRepository saleRepository;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	List<String> traansCodeCheck = Arrays.asList("ADM", "ACM", "RCS", "SPD", "SSA", "TAA", "RFN");
	
	public Map<String, List<TicketSale>> process(String user,String clientId, TicketDocumentIdentificationStg ticketDocumentIdentificationStg,
			TransactionHeaderStg transactionHeaderStg, Map<String, String> ticketDoc, Integer salesKey,Map<String, String> ticketSalesGMap,boolean ticketRefundData,Integer fileId) {
		Map<String, List<TicketSale>> ticketSaleMap = new HashMap<>();
		List<TicketSale> ticketSaleTicket = new ArrayList<>();
		List<TicketSale> ticketSaleNonTicket = new ArrayList<>();

		List<TicketSale> ticketSales = new ArrayList<TicketSale>();
		if (!"Y".equalsIgnoreCase(ticketDoc.get("conjTicketIndicator")) || (ticketDocumentIdentificationStg.getTransactionCode() != null
				&& traansCodeCheck.contains(ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)))) {

		/*	List<FormCode> formcodeList = smartpraMasterAppClient
					.getAllFormCode(object.getTktDocNumber().substring(3, 6), null, null, null, null);
			if (CollectionUtils.isEmpty(formcodeList)) {
				formcodeList = smartpraMasterAppClient.getAllFormCode(object.getTktDocNumber().substring(3, 5), null,
						null, null, null);
			}*/

			TicketSale ticketSale = new TicketSale();

			Date d = new Date();

			ticketSale.setMainDocument(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
			ticketSale.setDocumentNo(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
			ticketSale.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
			String docId = clientId + ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3) + ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)
					+ ticketDocumentIdentificationStg.getDateOfIssue().substring(0, 6);
			ticketSale.setDocumentUniqueId(docId);
			ticketSale.setPnr(ticketDocumentIdentificationStg.getPnrRefAirlineDate());
			ticketSale.setSalesKey(salesKey);
			/*if (formcodeList != null && !formcodeList.isEmpty()) {
				ticketSale.setDocType(formcodeList.get(0).getDocumentType().get());
			} else {
				ticketSale.setDocType("PAX");
			}*/
			
			String docType = ticketDoc.get("docType");
			
			
			if (docType != null && !docType.isEmpty()) {
				ticketSale.setDocType(docType);
			} else {
				ticketSale.setDocType("PAX");
			}
			
			String transactionTypeActual = ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3);
			String transType = ticketDocumentIdentificationStg.getTransactionCode();
			boolean formOfPaymentRecType = false;
			if (!transactionHeaderStg.getFormOfPaymentStg().isEmpty()) {
				for (FormOfPaymentStg ofPaymentStg : transactionHeaderStg.getFormOfPaymentStg()) {					
					if (ofPaymentStg.getFopType().substring(0, 2).contentEquals("EX")) {
						formOfPaymentRecType = true;
						ticketSale.setTransactionCode("PE");
					} 
				}				
			}
			 if (formOfPaymentRecType==false) {
				ticketSale.setTransactionCode(ARCUtil.getTransactionCode(transactionTypeActual));
			} else if (transType.contentEquals("SSAC")) {
				ticketSale.setTransactionCode("AC");
				ticketSale.setDocType("ACM");
			} else if (transType.contentEquals("SSAD")) {
				ticketSale.setTransactionCode("AD");
				ticketSale.setDocType("ADM");
			} else if ("PAX".equals(ticketSale.getDocType())
					&& "CAN".contentEquals(transactionTypeActual.substring(0, 3))) {
				ticketSale.setTransactionCode("PV");
			}

			// void sector changes - based on coupon use indicator and doc type PAX
			if (ticketDocumentIdentificationStg.getCpnUseIndicator() != null && !ticketDocumentIdentificationStg.getCpnUseIndicator().isEmpty()) {
				if ("PAX".equals(ticketSale.getDocType()) && "VVVV".equals(ticketDocumentIdentificationStg.getCpnUseIndicator())) {
					ticketSale.setTransactionCode("PV");
				}
			}
			ticketSale.setTransactionType(ticketSale.getTransactionCode().substring(1, 2));
			ticketSale.setProcessStatus("RV");
			ticketSale.setProcessDate(d);
			ticketSale.setMonthClosedDate(d);
			ticketSale.setSource(ticketDoc.get(ARCConstants.SOURCE));
			// ticketSale.setBilledFlag("N");
			ticketSale.setUnprocessStatus("N");
			ticketSale.setCreatedBy(user);
			ticketSale.setFileId(fileId);
			ticketSale.setCreatedDate(new Timestamp(new Date().getTime()));
			if(!StringUtils.equalsAnyIgnoreCase(ticketDocumentIdentificationStg.getTransactionCode() , ARCConstants.TRANSACTION_TYPE_REFUND)) {
				/*Optional<TicketSale> ticketSaleLive = saleRepository
						.findOneByDocumentUniqueId(ticketSale.getDocumentUniqueId());*/
				
				String sql="SELECT document_unique_id from SmartPRASales.ticket_sales where document_unique_id = "+"'"+ticketDoc.get("documentUniqueId")+"'";
				
				if (jdbcTemplate.queryForList(sql).isEmpty()) {
					if (!ticketSalesGMap.containsKey(ticketSale.getDocumentUniqueId())) {
						ticketSaleTicket.add(ticketSale);
						ticketSalesGMap.put(ticketSale.getDocumentUniqueId(), ticketSale.getDocumentUniqueId());
					} else {
						/*System.out.println("This is duplicate of ticket sales ======1==========="
								+ ticketSale.getDocumentUniqueId());*/
					}
				} else {
					/*System.out.println(
							"This is duplicate of ticket sales =========2========" + ticketSale.getDocumentUniqueId());*/
				}

			}else{
				String documentUniqueIdRefund = ticketDoc.get("documentUniqueIdRefund");
				if(documentUniqueIdRefund != null && !documentUniqueIdRefund.isEmpty()) {
				/*Optional<TicketSale> ticketSaleLive = saleRepository
						.findOneByDocumentUniqueId(documentUniqueIdRefund);*/
					String sql="SELECT document_unique_id from SmartPRASales.ticket_sales where document_unique_id = "+"'"+documentUniqueIdRefund+"'";
					
				if (jdbcTemplate.queryForList(sql).isEmpty()) {
					ticketSale.setDocumentUniqueId(documentUniqueIdRefund);
					
					if (!ticketSalesGMap.containsKey(ticketSale.getDocumentUniqueId())) {
						ticketSaleTicket.add(ticketSale);
						ticketSalesGMap.put(ticketSale.getDocumentUniqueId(), ticketSale.getDocumentUniqueId());
					} else {
						/*System.out.println("This is duplicate of ticket sales ======1==========="
								+ ticketSale.getDocumentUniqueId());*/
					}
				} else {
					/*System.out.println(
							"This is duplicate of ticket sales =========2========" + ticketSale.getDocumentUniqueId());*/
				}
				}
			}
		}
		ticketSaleMap.put("ticketSaleTicket", ticketSaleTicket);
		ticketSaleMap.put("ticketSaleNonTicket", ticketSaleTicket);
		return ticketSaleMap;
	}

}
