package com.sgl.smartpra.batch.arc.app.processor;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import com.hazelcast.util.StringUtil;
import com.sgl.smartpra.batch.arc.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.arc.app.util.ARCConstants;
import com.sgl.smartpra.batch.arc.app.util.ARCUtil;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AgentRegisterStg;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.model.AgencyDetailsModel;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.sales.domain.AgentRegister;
import com.sgl.smartpra.sales.repository.AgentRegisterRepository;

@StepScope
public class AgentRegisterProcessor implements ItemProcessor<AgentRegisterStg, AgentRegister> {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	private AgentRegisterRepository agentRegisterRepository;

	@Override
	public AgentRegister process(AgentRegisterStg agentRegisterStg) throws Exception {

		String clientId = stepExecution.getJobExecution().getExecutionContext().getString("clientId");
		
		
		JobParameter fileIdValue =  stepExecution.getJobExecution().getJobParameters().getParameters().get("fileId");
		
		Long fileId = (Long) fileIdValue.getValue();

		Map<String, AgentRegister> agentRegisterMap = (Map<String, AgentRegister>) stepExecution.getJobExecution()
				.getExecutionContext().get("salesKey");

		Map<String, String> agentCodeMap = (Map<String, String>) stepExecution.getJobExecution().getExecutionContext()
				.get("agentCode");
		
		//Extract unique keys 
		String agentNumericCode = agentRegisterStg.getAgentNumericCode();
		String transactionType = agentRegisterStg.getTransactionType();
		String currencyType = agentRegisterStg.getCurrencyType().substring(0, 3);
		Date effectiveFromDate = new SimpleDateFormat("yyMMdd").parse(agentRegisterStg.getOfficeHeaderStg()
				.getBillingCycleHeaderStg().getHotReportingEndDate());
		String effectiveFromDateString = agentRegisterStg.getOfficeHeaderStg()
				.getBillingCycleHeaderStg().getHotReportingEndDate();
		Date effectiveTodate = new SimpleDateFormat("yyMMdd").parse(agentRegisterStg.getOfficeHeaderStg()
				.getBillingCycleHeaderStg().getBillingAnalysisEndingDate());
		String effectiveTodateString = agentRegisterStg.getOfficeHeaderStg()
				.getBillingCycleHeaderStg().getBillingAnalysisEndingDate();

		
		
		if (!agentCodeMap.containsKey(agentRegisterStg.getAgentNumericCode())) {
			agentCodeMap.put(agentRegisterStg.getAgentNumericCode(), agentRegisterStg.getAgentNumericCode());
		}

		//Adding new Agency master
		boolean createNewAgency = false;
		String agencyCode = agentRegisterStg.getAgentNumericCode();
		AgencyMaster agencymaster = null;
		try {
			 agencymaster = smartpraMasterAppClient.getAgencyByAgencyCode(agencyCode, clientId);
		}
		catch(ResponseStatusException ex) {
			if(ex.getStatus().equals(HttpStatus.NOT_FOUND)) {
				createNewAgency = true;
			}
		} catch(Exception ex) {
			
		}
	
		
		String autoCreation = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient
				.getSystemParameterByparameterName(ARCConstants.PAR_AUTO_CREATE_AGENT);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			autoCreation = OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());
		}
		if(createNewAgency && autoCreation.contentEquals("Y")) {
			//Agency Creation Logic
			
			AgencyMaster agencyMaster = new AgencyMaster();
			agencyMaster.setAgencyCode(Optional.of(agencyCode));
			agencyMaster.setClientId(Optional.of(clientId));
			agencyMaster.setReportingAgency(Optional.of("9999999"));
			agencyMaster.setCreatedBy(Optional.of("ARCFile"));
			LocalDateTime date = LocalDateTime.now();  
			agencyMaster.setCreatedDate(date);
			try {
				AgencyMaster agencyMasterCreate = smartpraMasterAppClient.createAgencyMaster(agencyMaster);
				if(agencyMasterCreate != null) {
//					System.out.println("Agency master created successfully=================>"+agencyMaster.getAgencyCode());
				}
			}
			catch (ResponseStatusException e) {
//				System.out.println("Agency master creation fails or already present=================>"+e.getStatus());
			} catch(Exception ex) {
				
			}

//			AgencyDetails Creation Logic 
			Optional<String> agencyType1 = null;
			Optional<String> areaOfOperationCreate= null;
			Optional<String> reportingAgencyTypeCreate = null;
			Optional<String> reportingAgencyCreate = null;
			Optional<Boolean> activate = null;
			List<AgencyMaster> agencyMasterforDetails = smartpraMasterAppClient.getAllAgency(
					agencyCode, reportingAgencyCreate, agencyType1,
					areaOfOperationCreate, reportingAgencyTypeCreate,activate);
//			System.out.println(agencyMasterforDetails); 
			Integer agencyId = agencyMasterforDetails.get(0).getAgencyId(); 

		String transactionTypeAD = "";
		
		if(StringUtils.isNotEmpty(transactionType)){
			if(transactionType.contentEquals("ADMA")) {
				transactionTypeAD = "D";
			}
			else if(transactionType.contentEquals("ACMA")) {
				transactionTypeAD = "C";
			}
			else if(transactionType.contentEquals("RFND")) {
				transactionTypeAD = "R";
			}
			else {
				transactionTypeAD = "S";
			}
			}
		String transCurrAD= null;
		if(StringUtils.isNotEmpty(currencyType)){
			 transCurrAD = currencyType;
			}

		
		DateTime dt1 = new DateTime(effectiveFromDate);
		DateTime dt2 = new DateTime(effectiveTodate);
		
		Integer reqFreqActual = Days.daysBetween(dt1, dt2).getDays();
		String reqFreqString = reqFreqActual.toString();
		
		

		String repFreqAD = null;
		if(!StringUtil.isNullOrEmpty(reqFreqString)) {
			if(reqFreqActual<=1) {
				repFreqAD = "D";
			}else if(reqFreqActual==7) {
				repFreqAD = "W";
			}else if(reqFreqActual==15) {
				repFreqAD = "F";
			}else if(reqFreqActual==30) {
				repFreqAD = "M";
			}
			repFreqAD = "W";
		}

		ARCUtil arcUtil = new ARCUtil();
		String effectiveFrDate = arcUtil.getFormattedDate(effectiveFromDateString,"yyMMdd", "yyyy-MM-dd");
		String effectiveToDate = arcUtil.getFormattedDate(effectiveTodateString,"yyMMdd", "yyyy-MM-dd");
		String commissionFlagAD = "N";
		String commPercentAD = "0";
		String otaIndicatiorAD = "Y";
		
		String eff = "500101";		
		String effectiveToDateRequired = arcUtil.getFormattedDate(eff,"yyMMdd", "yyyy-MM-dd");
		String effFinalToDate = "2050-01-01";
		
		
		AgencyDetailsModel agencyDetailsModel = new AgencyDetailsModel();
		agencyDetailsModel.setClientId(Optional.of(clientId));
		agencyDetailsModel.setAgencyCode(Optional.of(agencyCode));
		agencyDetailsModel.setTransactionType(Optional.of(transactionTypeAD));
		agencyDetailsModel.setTransactionCurrency(Optional.of(transCurrAD));
		agencyDetailsModel.setReportingFrequency(Optional.of(repFreqAD));
		agencyDetailsModel.setEffectiveFromDate(Optional.of(effectiveFrDate));
		agencyDetailsModel.setEffectiveToDate(Optional.of(effFinalToDate));
		agencyDetailsModel.setCommissionFlag(Optional.of(commissionFlagAD));
		agencyDetailsModel.setCommissionPercentage(Optional.of(commPercentAD));
		agencyDetailsModel.setOtaindicator(Optional.of(otaIndicatiorAD));
		agencyDetailsModel.setCreatedBy(Optional.of("ARCFile"));
		
		try {
		AgencyDetailsModel agencyDetailsModelCreate = smartpraMasterAppClient.
				createAgencyDetails(agencyId,agencyDetailsModel);
		if(agencyDetailsModelCreate != null) {
//			System.out.println("AgencyDetails master created successfully=================>"+agencyMaster.getAgencyCode());
		}
		}catch (ResponseStatusException e) {
//			System.out.println("AgencyDetails master creation fails=================>"+e.getStatus());
		} catch(Exception ex) {
			
		}
		
			}


		Optional<AgentRegister> agentRegisterLive = agentRegisterRepository
				.findOneByClientIdAndReportingAgencyAndAgencyCodeAndTransactionTypeAndTransactionCurrencyAndEffectiveFromDateAndEffectiveToDate(
						clientId, "9999999", agentRegisterStg.getAgentNumericCode(),
						agentRegisterStg.getTransactionType(), agentRegisterStg.getCurrencyType().substring(0, 3),
						new SimpleDateFormat("yyMMdd").parse(agentRegisterStg.getOfficeHeaderStg()
								.getBillingCycleHeaderStg().getHotReportingEndDate()),
						new SimpleDateFormat("yyMMdd").parse(agentRegisterStg.getOfficeHeaderStg()
								.getBillingCycleHeaderStg().getBillingAnalysisEndingDate())); 
	
		
		if (!agentRegisterLive.isPresent()) { 
			AgentRegister agentRegister = new AgentRegister();

			agentRegister.setAgencyCode(agentRegisterStg.getAgentNumericCode());
			agentRegister.setClientId(clientId);
			agentRegister.setTransactionCurrency(agentRegisterStg.getCurrencyType().substring(0, 3));
			agentRegister.setEffectiveFromDate(new SimpleDateFormat("yyMMdd")
					.parse(agentRegisterStg.getOfficeHeaderStg().getBillingCycleHeaderStg().getHotReportingEndDate()));
			agentRegister.setEffectiveToDate(new SimpleDateFormat("yyMMdd").parse(
					agentRegisterStg.getOfficeHeaderStg().getBillingCycleHeaderStg().getBillingAnalysisEndingDate()));
			// TODO move to Enum or Static Constant
			agentRegister.setStatus("O");
			if (agentRegisterStg.getGrossValueAmt() != null) {
				agentRegister.setGrossValue(new BigDecimal(agentRegisterStg.getGrossValueAmt()));
			}
			if (agentRegisterStg.getTotalCommissionValueAmt() != null) {
				agentRegister.setTotalCommissionValue(new BigDecimal(agentRegisterStg.getTotalCommissionValueAmt()));
			}
			if (agentRegisterStg.getTotalTaxMiscFeeAmt() != null) {
				agentRegister.setTotalTaxMiscFee(new BigDecimal(agentRegisterStg.getTotalTaxMiscFeeAmt()));
			}

			if (agentRegisterStg.getTotalTaxOnCommissionAmt() != null) {
				agentRegister.setTotalTaxOnCommission(new BigDecimal(agentRegisterStg.getTotalTaxOnCommissionAmt()));
			}

			if (agentRegisterStg.getTotalRemittanceAmount() != null) {
				agentRegister.setTotalRemittance(new BigDecimal(agentRegisterStg.getTotalRemittanceAmount()));
			}

			if (agentRegisterStg.getTransactionType() != null) {
				agentRegister.setTransactionType(agentRegisterStg.getTransactionType());
			}
			
			agentRegister.setReportingAgency("9999999");
			if(fileId != null) {
			agentRegister.setFileId(fileId.intValue());
			}
			agentRegisterMap.put(agentNumericCode+currencyType+effectiveFromDate.getDate()+effectiveTodate.getDate(), agentRegister);
			return agentRegister;
		} else {

			agentRegisterMap.put(agentNumericCode+currencyType+effectiveFromDate.getDate()+effectiveTodate.getDate(), agentRegisterLive.get());
			return null;

		}

	}
}