package com.sgl.smartpra.batch.arc.app.listener;

import java.io.FileNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.orm.jpa.JpaSystemException;

public class ARCProdLoadSkipPolicy implements SkipPolicy {

	private static final Logger logger = LoggerFactory.getLogger(ARCProdLoadSkipPolicy.class);
	@Override
	public boolean shouldSkip(Throwable exception, int skipCount) throws SkipLimitExceededException {
		 if (exception instanceof FileNotFoundException) {
	            return false;
	        } else if (exception instanceof org.springframework.dao.OptimisticLockingFailureException && skipCount <= 5) {
	        	OptimisticLockingFailureException ffpe = (OptimisticLockingFailureException) exception;
	            StringBuilder errorMessage = new StringBuilder();
	            errorMessage.append("An error occured while loading staging to production " + ffpe.getMessage());
	            logger.error("{}", errorMessage.toString());
	            return true;
	        }  else if (exception instanceof org.springframework.orm.jpa.JpaSystemException && skipCount <= 5) {
	        	JpaSystemException ffpe = (JpaSystemException) exception;
	            StringBuilder errorMessage = new StringBuilder();
	            errorMessage.append("An error occured while loading staging to production " + ffpe.getCause());
	            logger.error("{}", errorMessage.toString());
	            return true;
	        }
	        else {
	            return false;
	        }
	}

}
