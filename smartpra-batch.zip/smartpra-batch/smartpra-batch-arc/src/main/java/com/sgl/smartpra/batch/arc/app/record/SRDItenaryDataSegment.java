package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class SRDItenaryDataSegment extends ARCBaseRecord {
	
	public SRDItenaryDataSegment() {
	}
	
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktCarrierCode;
	private String reservedSpace;
	private String tktDocNumber;
	private String checkDigit;
	private String segmentIdentifier;
	private String stopoverCode;
	private String fillerTwo;
	private String fillerThree;
	private String orginAirportCityCode;
	private String destAirportCityCode;
	private String carrierCode;
	private String soldPassengerCabin;
	private String flightNumber;
	private String reservationBkngDesignation;
	private String flightDate;
	private String flightDepartTime;
	private String fareBasis;
	private String filler;
	private String couponNumber;
	

	@Override
	public String getRecordType() {
		return ARCRecordType.SRD_ITENARY_DATA_SEGMENT;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public SRDItenaryDataSegment(Map<String, String> recordMap) {
		super(recordMap);
	}


	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getSegmentIdentifier() {
		return segmentIdentifier;
	}

	public void setSegmentIdentifier(String segmentIdentifier) {
		this.segmentIdentifier = segmentIdentifier;
	}

	public String getStopoverCode() {
		return stopoverCode;
	}

	public void setStopoverCode(String stopoverCode) {
		this.stopoverCode = stopoverCode;
	}

	public String getOrginAirportCityCode() {
		return orginAirportCityCode;
	}

	public void setOrginAirportCityCode(String orginAirportCityCode) {
		this.orginAirportCityCode = orginAirportCityCode;
	}

	public String getDestAirportCityCode() {
		return destAirportCityCode;
	}

	public void setDestAirportCityCode(String destAirportCityCode) {
		this.destAirportCityCode = destAirportCityCode;
	}

	public String getSoldPassengerCabin() {
		return soldPassengerCabin;
	}

	public void setSoldPassengerCabin(String soldPassengerCabin) {
		this.soldPassengerCabin = soldPassengerCabin;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}


	public String getFlightDate() {
		return flightDate;
	}

	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	public String getFlightDepartTime() {
		return flightDepartTime;
	}

	public void setFlightDepartTime(String flightDepartTime) {
		this.flightDepartTime = flightDepartTime;
	}


	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getFillerTwo() {
		return fillerTwo;
	}

	public void setFillerTwo(String fillerTwo) {
		this.fillerTwo = fillerTwo;
	}

	public String getFillerThree() {
		return fillerThree;
	}

	public void setFillerThree(String fillerThree) {
		this.fillerThree = fillerThree;
	}

	public String getCarrierCode() {
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}

	public String getReservationBkngDesignation() {
		return reservationBkngDesignation;
	}

	public void setReservationBkngDesignation(String reservationBkngDesignation) {
		this.reservationBkngDesignation = reservationBkngDesignation;
	}

	public String getFareBasis() {
		return fareBasis;
	}

	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}

	public String getTktCarrierCode() {
		return tktCarrierCode;
	}

	public void setTktCarrierCode(String tktCarrierCode) {
		this.tktCarrierCode = tktCarrierCode;
	}

	public String getReservedSpace() {
		return reservedSpace;
	}

	public void setReservedSpace(String reservedSpace) {
		this.reservedSpace = reservedSpace;
	}
	
}
