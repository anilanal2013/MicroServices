package com.sgl.smartpra.batch.arc.app.processor;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.arc.app.mapper.ARCRecordMapper;
import com.sgl.smartpra.batch.arc.app.record.ARCBaseRecord;
import com.sgl.smartpra.batch.arc.app.record.BillingCycleHeader;
import com.sgl.smartpra.batch.arc.app.util.ARCConstants;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleHeaderStg;

public class BillingCycleHeaderProcessor extends ARCBaseItemProcessor {
	
	@Value("#{stepExecution}")
	private StepExecution stepExecution;
	
	@Override
	public BSPStagingDomainObject process(ARCBaseRecord arcBaseRecord) throws Exception {
		Date effectiveFromDate = null;
		String effectiveFromDateString = null;	
		Date effectiveTodate = null;
		BillingCycleHeaderStg billingCycleHeaderStg = ARCRecordMapper.INSTANCE
				.mapBillingCycleHeaderRecord((BillingCycleHeader) arcBaseRecord);
		String ppId = billingCycleHeaderStg.getProcessingDateIdentifier();
		String pped = stepExecution.getJobExecution().getExecutionContext()
				.get(ARCConstants.PROCESSING_PERIOD_ENDDATE).toString();
		effectiveTodate = new SimpleDateFormat("yyMMdd").parse(pped);
		int lastDigit = Integer.parseInt(ppId);
		effectiveFromDate = DateUtils.addDays(effectiveTodate, 0 - lastDigit - 7);
		effectiveFromDateString = new SimpleDateFormat("yyMMdd").format(effectiveFromDate);
		billingCycleHeaderStg.setHotReportingEndDate(effectiveFromDateString);
		billingCycleHeaderStg.setBillingAnalysisEndingDate(pped);
		return billingCycleHeaderStg;

	}
}
