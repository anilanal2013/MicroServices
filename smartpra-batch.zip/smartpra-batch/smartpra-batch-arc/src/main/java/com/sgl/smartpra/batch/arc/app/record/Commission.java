package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class Commission extends ARCBaseRecord {

	@Override
	public String getRecordType() {
		return ARCRecordType.COMMISSION;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}
	
	public Commission() {
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public Commission(Map<String, String> recordMap) {
		super(recordMap);
	}

	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String statisticalCode;
	private String commissionType;
	private String commissionRate;
	private String commissionAmount;
	private String supplementaryType;
	private String supplementaryRate;
	private String supplementaryAmount;
	private String effectiveCommissionRate;
	private String effectiveCommissionAmount;
	private String amountPaidByCustomer;
	private String routingDomInterIndicator;
	private String commCtrlAdjustmentIndicator;
	private String filler;
	private String currencyType;
	private String bookingAgentIdentification;
	private String electronicSettleAuth;
	private String remittanceAmount;
	private String commissionTypeTwo;
	private String commissionRateTwo;
	private String commissionAmountTwo;
	private String reserved;
	private String tktCarrierCode;
	private String statCode;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getStatisticalCode() {
		return statisticalCode;
	}

	public void setStatisticalCode(String statisticalCode) {
		this.statisticalCode = statisticalCode;
	}

	public String getCommissionType() {
		return commissionType;
	}

	public void setCommissionType(String commissionType) {
		this.commissionType = commissionType;
	}

	public String getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(String commissionRate) {
		this.commissionRate = commissionRate;
	}

	public String getCommissionAmount() {
		return commissionAmount;
	}

	public void setCommissionAmount(String commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	public String getSupplementaryType() {
		return supplementaryType;
	}

	public void setSupplementaryType(String supplementaryType) {
		this.supplementaryType = supplementaryType;
	}

	public String getSupplementaryRate() {
		return supplementaryRate;
	}

	public void setSupplementaryRate(String supplementaryRate) {
		this.supplementaryRate = supplementaryRate;
	}

	public String getSupplementaryAmount() {
		return supplementaryAmount;
	}

	public void setSupplementaryAmount(String supplementaryAmount) {
		this.supplementaryAmount = supplementaryAmount;
	}

	public String getEffectiveCommissionRate() {
		return effectiveCommissionRate;
	}

	public void setEffectiveCommissionRate(String effectiveCommissionRate) {
		this.effectiveCommissionRate = effectiveCommissionRate;
	}

	public String getEffectiveCommissionAmount() {
		return effectiveCommissionAmount;
	}

	public void setEffectiveCommissionAmount(String effectiveCommissionAmount) {
		this.effectiveCommissionAmount = effectiveCommissionAmount;
	}

	public String getAmountPaidByCustomer() {
		return amountPaidByCustomer;
	}

	public void setAmountPaidByCustomer(String amountPaidByCustomer) {
		this.amountPaidByCustomer = amountPaidByCustomer;
	}

	public String getRoutingDomInterIndicator() {
		return routingDomInterIndicator;
	}

	public void setRoutingDomInterIndicator(String routingDomInterIndicator) {
		this.routingDomInterIndicator = routingDomInterIndicator;
	}

	public String getCommCtrlAdjustmentIndicator() {
		return commCtrlAdjustmentIndicator;
	}

	public void setCommCtrlAdjustmentIndicator(String commCtrlAdjustmentIndicator) {
		this.commCtrlAdjustmentIndicator = commCtrlAdjustmentIndicator;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getBookingAgentIdentification() {
		return bookingAgentIdentification;
	}

	public void setBookingAgentIdentification(String bookingAgentIdentification) {
		this.bookingAgentIdentification = bookingAgentIdentification;
	}

	public String getElectronicSettleAuth() {
		return electronicSettleAuth;
	}

	public void setElectronicSettleAuth(String electronicSettleAuth) {
		this.electronicSettleAuth = electronicSettleAuth;
	}

	public String getRemittanceAmount() {
		return remittanceAmount;
	}

	public void setRemittanceAmount(String remittanceAmount) {
		this.remittanceAmount = remittanceAmount;
	}

	public String getCommissionTypeTwo() {
		return commissionTypeTwo;
	}

	public void setCommissionTypeTwo(String commissionTypeTwo) {
		this.commissionTypeTwo = commissionTypeTwo;
	}

	public String getCommissionRateTwo() {
		return commissionRateTwo;
	}

	public void setCommissionRateTwo(String commissionRateTwo) {
		this.commissionRateTwo = commissionRateTwo;
	}

	public String getCommissionAmountTwo() {
		return commissionAmountTwo;
	}

	public void setCommissionAmountTwo(String commissionAmountTwo) {
		this.commissionAmountTwo = commissionAmountTwo;
	}

	public String getReserved() {
		return reserved;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}

	public String getTktCarrierCode() {
		return tktCarrierCode;
	}

	public void setTktCarrierCode(String tktCarrierCode) {
		this.tktCarrierCode = tktCarrierCode;
	}

	public String getStatCode() {
		return statCode;
	}

	public void setStatCode(String statCode) {
		this.statCode = statCode;
	}
}
