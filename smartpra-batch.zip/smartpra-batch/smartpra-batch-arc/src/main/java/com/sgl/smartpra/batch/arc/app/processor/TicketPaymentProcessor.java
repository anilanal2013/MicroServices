package com.sgl.smartpra.batch.arc.app.processor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.arc.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.arc.app.util.ARCConstants;
import com.sgl.smartpra.batch.arc.app.util.ARCUtil;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.StdDocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.master.model.FOPMapping;
import com.sgl.smartpra.sales.domain.TicketPaymentDetail;
import com.sgl.smartpra.sales.repository.TicketPaymentDetailRepository;

@Component
public class TicketPaymentProcessor {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	TicketPaymentDetailRepository paymentDetailRepository;
	
	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	List<String> traansCodeCheck = Arrays.asList("ADM", "ACM", "RCS", "SPD", "SSA", "TAA", "RFN");
	
	List <String> formOfPayment = Arrays.asList("GF","CO","DI","TX");
	
	List <String> acmCheck = Arrays.asList(ARCConstants.TRANSACTION_TYPE_SPC, ARCConstants.TRANSACTION_TYPE_SSAC);
	List <String> admCheck = Arrays.asList(ARCConstants.TRANSACTION_TYPE_RCS,ARCConstants.TRANSACTION_TYPE_SSAD,
			ARCConstants.TRANSACTION_TYPE_TAA, ARCConstants.TRANSACTION_TYPE_SPD);
	
	public Map<String, List<TicketPaymentDetail>> process(String user,TicketDocumentIdentificationStg ticketDocumentIdentificationStg,
			TransactionHeaderStg transactionHeaderStg, Map<String, String> ticketDoc, int decimalPrecision, Integer salesKey,Map<String, String> ticketPaymentGMap,boolean ticketRefundData,Integer fileId) {
		Map<String, List<TicketPaymentDetail>> ticketPaymentDetailMap = new HashMap<>();
		List<TicketPaymentDetail> ticketPaymentTicket = new ArrayList<>();
		List<TicketPaymentDetail> ticketPaymentNonTicket = new ArrayList<>();
		String currencyType = transactionHeaderStg.getOfficeHeaderStg().getCurrencyType().substring(0,3);
		Optional<String> stationCode = null;
		Optional<String> effectiveFromDate = null;
		Optional<String> effectiveToDate = null;
		Optional<String> source = null;
		BigDecimal taxAmountBKS = new BigDecimal(0);
		BigDecimal txTotal = new BigDecimal(0);
		
		// To Calculate the total tax amount 
		List<StdDocumentAmountsStg> standaredAmountStg1s = transactionHeaderStg.getStdDocumentAmountsStg();
		
		if (transactionHeaderStg.getFormOfPaymentStg() != null && !transactionHeaderStg.getFormOfPaymentStg().isEmpty()) {
			int i = 1;
			for (FormOfPaymentStg formOfPaymentStg : transactionHeaderStg.getFormOfPaymentStg()) {
//				System.out.println("FOP " + formOfPaymentStg.getTransactionHdrId());
				TicketPaymentDetail ticketPaymentDetail = new TicketPaymentDetail();
				//for adm and acm formOfPaymentType is from DocumentAmountsStg
				if(ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3).contains(ARCConstants.TRANSACTION_TYPE_ACM) ||
						acmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())) {
				ticketPaymentDetail.setFormOfPaymentType("CM");
				}
				else if(ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3).contains(ARCConstants.TRANSACTION_TYPE_ADM) ||
						admCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())){
					ticketPaymentDetail.setFormOfPaymentType("DM");
				}
				else {
					ticketPaymentDetail.setFormOfPaymentType(formOfPaymentStg.getFopType().substring(0, 2));
				}
				ticketPaymentDetail.setBilledFlag(ARCConstants.INDICATOR_NO);
				ticketPaymentDetail.setMainDocument(ticketDoc.get("mainDocument"));
				ticketPaymentDetail.setDocumentNo(ticketDoc.get("documentNumber"));
				ticketPaymentDetail.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
				ticketPaymentDetail.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
				ticketPaymentDetail.setCreatedBy(user);
				ticketPaymentDetail.setCreatedDate(formOfPaymentStg.getCreatedDate());
				ticketPaymentDetail.setFileId(fileId);
				ticketPaymentDetail.setFmOfPaymentSequenceNumber(i++);
				if(salesKey != null) {
				ticketPaymentDetail.setSalesKey(salesKey.toString());
				}
				
				String remAmountValue = formOfPaymentStg.getRemittanceAmount();
				if (!remAmountValue.isEmpty() && remAmountValue != null) {
					String remittanceAmountSign = ARCUtil.getSignedFieldValue(remAmountValue);
					String remittanceAmountString = ARCUtil.getSignedFieldStringValue(remittanceAmountSign,
							decimalPrecision);
					BigDecimal remittanceAmount = ARCUtil.getvalidatedBigDecimal(remittanceAmountString);
					ticketPaymentDetail.setRemittanceAmount(remittanceAmount);
				}
				
				//for adm and acm formOfPaymentAmount is from DocumentAmountsStg
				try {
					if (ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
							.contains(ARCConstants.TRANSACTION_TYPE_ACM)
							|| acmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())
							|| admCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())
							|| ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
									.contains(ARCConstants.TRANSACTION_TYPE_ADM)) {

						String fopaValueOfAdmACm = "";
						if (transactionHeaderStg.getDocumentAmountsStgs() != null
								&& !transactionHeaderStg.getDocumentAmountsStgs().isEmpty()) {
							if (transactionHeaderStg.getDocumentAmountsStgs().get(0) != null) {
								fopaValueOfAdmACm = transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare();
							}
						}
						if (!fopaValueOfAdmACm.isEmpty() && fopaValueOfAdmACm != null) {
							String fopAmountSign = ARCUtil.getSignedFieldValue(fopaValueOfAdmACm);
							String fopAmountString = ARCUtil.getSignedFieldStringValue(fopAmountSign, decimalPrecision);
							BigDecimal fopAmount = ARCUtil.getvalidatedBigDecimal(fopAmountString);
							ticketPaymentDetail.setFormOfPaymentAmount(fopAmount);

						}
					}
				} catch (Exception e) {
				}
				if (ticketPaymentDetail.getFormOfPaymentType().contentEquals(ARCConstants.FOP_TYPE_CA)
						&& formOfPaymentStg.getRemittanceAmount()!= null && !formOfPaymentStg.getRemittanceAmount().isEmpty()) {
					ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getRemittanceAmount());
				} else {
					String fopaValue1 = formOfPaymentStg.getFopAmount();
					if (!fopaValue1.isEmpty() && fopaValue1 != null) {
						String fopAmountSign = ARCUtil.getSignedFieldValue(fopaValue1);
						String fopAmountString = ARCUtil.getSignedFieldStringValue(fopAmountSign, decimalPrecision);
						BigDecimal fopAmount = ARCUtil.getvalidatedBigDecimal(fopAmountString);
						ticketPaymentDetail.setFormOfPaymentAmount(fopAmount);
					}
				}
				//SALE1405_FopMapping
				// Start Transfer taxes from BKS30/31

				if (ticketDocumentIdentificationStg.getStdMessageIdentifier().equals("TKS")
						&& formOfPaymentStg.getFopType() != null && !formOfPaymentStg.getFopType().isEmpty()) {
					List<FOPMapping> fopMapping = smartpraMasterAppClient.search(stationCode, effectiveFromDate,
							effectiveToDate, source, Optional.of(formOfPaymentStg.getFopType()));
					if (fopMapping != null && !fopMapping.isEmpty() && fopMapping.get(0).getMappedTo() != null
							&& formOfPaymentStg.getFopType().equals(fopMapping.get(0).getMappedTo())) {
						ticketPaymentDetail.setFormOfPaymentType(fopMapping.get(0).getMappedTo().get());
						ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getRemittanceAmount());
						ticketPaymentDetail.setFopCurrencyType(currencyType);
					}
				} else {
					if (!standaredAmountStg1s.isEmpty()) {
						for (int stdAmount = 0; stdAmount < standaredAmountStg1s.size(); stdAmount++) {
							if ((!standaredAmountStg1s.isEmpty()
									&& ticketPaymentDetail.getDocumentNo() == standaredAmountStg1s.get(i)
											.getTktDocNumber().substring(3, 13))) {
								String taxAmtBKS = standaredAmountStg1s.get(i).getTaxMiscFeeAmount1();
								if (!taxAmtBKS.isEmpty() && taxAmtBKS != null) {
									String taxAmountBKSSign = ARCUtil.getSignedFieldValue(taxAmtBKS);
									String taxAmountBKSString = ARCUtil.getSignedFieldStringValue(taxAmountBKSSign,
											decimalPrecision);
									taxAmountBKS = ARCUtil.getvalidatedBigDecimal(taxAmountBKSString);
								}
								txTotal.add(taxAmountBKS);
								ticketPaymentDetail.setFormOfPaymentAmount(txTotal);
								ticketPaymentDetail.setFormOfPaymentType("TX");
								ticketPaymentDetail
										.setFopCurrencyType(currencyType);
							}
						}
					}

				}
				// End Transfer taxes from BKS30/31	
				
				// Start CA reported with negative fare - BKP84
				
				String fopRemittanceAmountSign = ARCUtil.getSignedFieldValue(formOfPaymentStg.getRemittanceAmount());
				String fopRemittanceAmountString = ARCUtil.getSignedFieldStringValue(fopRemittanceAmountSign,
						decimalPrecision);
				BigDecimal fopRemittanceAmount = ARCUtil.getvalidatedBigDecimal(fopRemittanceAmountString);
				if (formOfPaymentStg.getStdMessageIdentifier().equals("TKP")
						&& formOfPaymentStg.getFopType().equals("CA")
						&& formOfPaymentStg.getFopAmount().equals("0000000000{")
						&& (fopRemittanceAmount.signum() < 0)) {
					// CA should be checked to mas_fop_mapping
					List<FOPMapping> fopMapping = smartpraMasterAppClient.search(stationCode, effectiveFromDate,
							effectiveToDate, source, Optional.of(formOfPaymentStg.getFopType()));
					if (fopMapping != null && !fopMapping.isEmpty() && fopMapping.get(0).getMappedTo() != null
							&& formOfPaymentStg.getFopType().equals(fopMapping.get(0).getMappedTo())) {
						ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getRemittanceAmount());
					}
				}
				// End CA reported with negative fare - BKP84
				
				//End SALE1405_FopMapping
				
				if(ticketPaymentDetail.getFormOfPaymentAmount().compareTo(BigDecimal.ZERO) > 0) {
				ticketPaymentDetail.setFopSign(ARCConstants.FOP_TYPE_P);
				}else {
					ticketPaymentDetail.setFopSign(ARCConstants.FOP_TYPE_N);
				}
				ticketPaymentDetail.setFormOfPaymentAccountNumber(formOfPaymentStg.getFopAccountNumber());
				ticketPaymentDetail.setExpiryDate(formOfPaymentStg.getExpiryDate());
				ticketPaymentDetail.setExtendedPaymentCode(formOfPaymentStg.getExtendedPaymentCode());
				ticketPaymentDetail.setApprovalCode(formOfPaymentStg.getApprovalCode());
				ticketPaymentDetail.setInvoiceNumber(formOfPaymentStg.getInvoiceNumber());
				String invoiceDate = formOfPaymentStg.getInvoiceDate();
				Date invoiceDateFinal = ARCUtil.getFormattedDate(invoiceDate, "yyMMdd");
				if(invoiceDateFinal!=null && invoiceDate!="000000") {
				ticketPaymentDetail.setInvoiceDate(invoiceDateFinal);
				}
				ticketPaymentDetail.setCardVerificationValueResult(formOfPaymentStg.getCardVerificationValueResult());
				ticketPaymentDetail.setFopCurrencyType(currencyType);

				
				//Duplicate check start
				if (!StringUtils.equalsAnyIgnoreCase(ticketDocumentIdentificationStg.getTransactionCode(),
						ARCConstants.TRANSACTION_TYPE_REFUND)) {
					/*Optional<TicketPaymentDetail> ticketPaymentDetailLive = paymentDetailRepository
							.findOneByDocumentUniqueIdAndFormOfPaymentTypeAndFmOfPaymentSequenceNumber(
									ticketPaymentDetail.getDocumentUniqueId(),
									ticketPaymentDetail.getFormOfPaymentType(),
									ticketPaymentDetail.getFmOfPaymentSequenceNumber());*/
					String sql = "select document_unique_id from SmartPRASales.ticket_payment_details where document_unique_id = '"
							+ ticketPaymentDetail.getDocumentUniqueId() + "' and form_of_payment_type = '"
							+ ticketPaymentDetail.getFormOfPaymentType() + "' and fm_of_payment_sequence_number = "
							+ ticketPaymentDetail.getFmOfPaymentSequenceNumber();
					if (jdbcTemplate.queryForList(sql).isEmpty()) {

						String paymentKey = ticketPaymentDetail.getDocumentUniqueId()
								+ ticketPaymentDetail.getFormOfPaymentType()
								+ ticketPaymentDetail.getFmOfPaymentSequenceNumber();

						if (!ticketPaymentGMap.containsKey(paymentKey)) {
							ticketPaymentTicket.add(ticketPaymentDetail);
							ticketPaymentGMap.put(paymentKey, paymentKey);
						} else {
							/*
							 * System.out.
							 * println("this is duplicate of payment details ======================>" +
							 * ticketPaymentDetail.getDocumentUniqueId());
							 */
						}
					}
				}else {
					String documentUniqueIdRefund = ticketDoc.get("documentUniqueIdRefund");
					if(documentUniqueIdRefund != null && !documentUniqueIdRefund.isEmpty()) {
						/*Optional<TicketPaymentDetail> ticketPaymentDetailLive = paymentDetailRepository
								.findOneByDocumentUniqueIdAndFormOfPaymentTypeAndFmOfPaymentSequenceNumber(
										documentUniqueIdRefund,
										ticketPaymentDetail.getFormOfPaymentType(),
										ticketPaymentDetail.getFmOfPaymentSequenceNumber());*/
						
						String sql = "select document_unique_id from SmartPRASales.ticket_payment_details where document_unique_id = '"
								+ documentUniqueIdRefund + "' and form_of_payment_type = '"
								+ ticketPaymentDetail.getFormOfPaymentType() + "' and fm_of_payment_sequence_number = "
								+ ticketPaymentDetail.getFmOfPaymentSequenceNumber();
						
						if (jdbcTemplate.queryForList(sql).isEmpty()) {

							String paymentKey = documentUniqueIdRefund
									+ ticketPaymentDetail.getFormOfPaymentType()
									+ ticketPaymentDetail.getFmOfPaymentSequenceNumber();

							if (!ticketPaymentGMap.containsKey(paymentKey)) {
								ticketPaymentDetail.setDocumentUniqueId(documentUniqueIdRefund);
								ticketPaymentTicket.add(ticketPaymentDetail);
								ticketPaymentGMap.put(paymentKey, paymentKey);
							} else {
								/*System.out.println("this is duplicate of payment details ======================>"
										+ ticketPaymentDetail.getDocumentUniqueId());*/
							}
						}
					}
				}
				
				//Duplicate check ends
				
			}
		}
	
		ticketPaymentDetailMap.put("ticketPaymentTicket", ticketPaymentTicket);
		ticketPaymentDetailMap.put("ticketPaymentNonTicket", ticketPaymentTicket);
		return ticketPaymentDetailMap;
	}

}
