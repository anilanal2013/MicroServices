package com.sgl.smartpra.batch.arc.app.processor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hazelcast.util.StringUtil;
import com.sgl.smartpra.batch.arc.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.arc.app.util.ARCConstants;
import com.sgl.smartpra.batch.arc.app.util.ARCUtil;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AdditionalItineraryDataStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDCouponDetailStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.ItineraryDataSegmentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.TicketDocumentIdentificationStgRepository;
import com.sgl.smartpra.master.model.ReportingSystemIdentifier;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketCouponFnf;
import com.sgl.smartpra.sales.domain.TicketMain;

@Component
public class TicketCouponProcessor {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	TicketDocumentIdentificationStgRepository ticketDocumentIdentificationStgRepository;


	List<String> traansCodeCheck = Arrays.asList("ADM", "ACM", "RCS", "SPD", "SSA", "TAA", "RFN");

	public List<TicketCoupon> process(String user,String clientId, TicketDocumentIdentificationStg ticketDocumentIdentificationStg,
					TransactionHeaderStg transactionHeaderStg, Map<String, String> ticketDoc, TicketMain ticketMain, int decimalPrecision,Integer fileId) {

		List<TicketCoupon> ticketCoupons = new LinkedList<>();
		int ticketCouponCount = 0;
		Map<Integer, TicketCoupon> couponMap = new Hashtable<>();
		if (!traansCodeCheck.contains(ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3))) {

			for (ItineraryDataSegmentStg itineraryDataSegmentStg : transactionHeaderStg.getItineraryDataSegmentStg()) {

				if (Long.parseLong(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)) == Long
								.parseLong(itineraryDataSegmentStg.getTktDocNumber().substring(3, 13))) {

					TicketCoupon ticketCoupon = new TicketCoupon();
					ticketCoupon.setCouponNumber(Integer.valueOf(itineraryDataSegmentStg.getSegmentIdentifier()));

					String systemProvider = null;
					String stopOverLogic = null;
					ReportingSystemIdentifier reportingSystemIdentifier = null;
					
					try {
						reportingSystemIdentifier = smartpraMasterAppClient
										.getRpsiCodeByClientIdAndRpsiCode(Optional.of(ticketDoc.get("rpsi")), Optional.of(clientId));
					}catch(Exception e) {
						//TODO handle 404 exception
					}
					
					if (reportingSystemIdentifier != null && reportingSystemIdentifier.getStopOverLogic().isPresent()) {
						stopOverLogic = reportingSystemIdentifier.getStopOverLogic().get();
						// StopOverLogic Derived
						if ((stopOverLogic.contentEquals("D") || stopOverLogic.contentEquals("O")) && ticketCoupon.getCouponNumber().toString().contains("1")
										&& transactionHeaderStg.getItineraryDataSegmentStg().get(0).getStopoverCode().contentEquals("O")) {
							// it indicates stopover is at destination
							ticketCoupon.setStopoverInd("X");
						}
						if (ticketCoupon.getCouponNumber().toString().contains("2")) {
							// TODO nedd to check the logic
//									ticketCoupon.setStopoverInd(itineraryDataSegmentStgs.get(i - 1).getStopoverCode());

							ticketCoupon.setStopoverInd(itineraryDataSegmentStg.getStopoverCode());
						}

						if (!(ticketCoupon.getCouponNumber().toString().contains("1") || ticketCoupon.getCouponNumber().toString().contains("2"))) {
							ticketCoupon.setStopoverInd(itineraryDataSegmentStg.getStopoverCode());
						}
					}

					else {
						ticketCoupon.setStopoverInd(itineraryDataSegmentStg.getStopoverCode());
					}

					ticketCoupon.setStopoverInd(itineraryDataSegmentStg.getStopoverCode());

					ticketCoupon.setFromAirport(itineraryDataSegmentStg.getOrginAirportCityCode());
					ticketCoupon.setToAirport(itineraryDataSegmentStg.getDestAirportCityCode());
					ticketCoupon.setMarketingCarrierAlphaCode(itineraryDataSegmentStg.getCarrier());
					ticketCoupon.setMarketingFlightNumber(itineraryDataSegmentStg.getFlightNumber());
					String sDate3 = itineraryDataSegmentStg.getFlightDate();
					if (!StringUtil.isNullOrEmpty(itineraryDataSegmentStg.getFlightDate()) && itineraryDataSegmentStg.getFlightDate().length() <= 5) {

						String dateRequired = sDate3 + "2019";

						DateTimeFormatter dTF = new DateTimeFormatterBuilder().parseCaseInsensitive().appendPattern("ddMMMyyyy").toFormatter();
						try {
							ticketCoupon.setMarketingFlightDate(LocalDate.parse(dateRequired, dTF));
						} catch (Exception ex) {
						}

					} else if (itineraryDataSegmentStg.getFlightDate().length() > 5) {
						DateTimeFormatter dTF1 = new DateTimeFormatterBuilder().parseCaseInsensitive().appendPattern("yyMMdd").toFormatter();
						ticketCoupon.setMarketingFlightDate(LocalDate.parse(sDate3, dTF1));
					}
					ticketCoupon.setBookingStatus(itineraryDataSegmentStg.getFlightBookingStatus());
					ticketCoupon.setTicketedRbd(itineraryDataSegmentStg.getReservationBookingDesignator());
					ticketCoupon.setFareBasis(itineraryDataSegmentStg.getFareBasisTktDesignator());
					ticketCoupon.setThruChangeOfGaugeIndicator(itineraryDataSegmentStg.getChangeOfGuageIndicator());
					ticketCoupon.setFrequentFlyerReference(itineraryDataSegmentStg.getFrequentFlyerReference());
					String carrierCode = null;
					String carrierName1 = null;
					String carrierName2 = null;
					String carrierDesignatorCode = null;
					if (!StringUtil.isNullOrEmpty(itineraryDataSegmentStg.getCarrier())) {
						carrierDesignatorCode = itineraryDataSegmentStg.getCarrier();
					}

					/*
					 * List<Carrier> carrierMasterList =
					 * carrierMasterFeignClient.getAllCarrier(carrierCode, carrierDesignatorCode,
					 * carrierName1, carrierName2); if (carrierMasterList != null &&
					 * !carrierMasterList.isEmpty()) { ticketCoupon.setMarketingCarrierNumCode(
					 * OptionalUtil.getValue(carrierMasterList.get(0).getCarrierCode())); }
					 */

					String carrierCodeString = null;
					// String carrierCodeString =
					// carrierMasterFeignClient.getCarrrierCodeByCarrierDesignatorCode(carrierDesignatorCode);

					if (carrierCodeString != null) {
						ticketCoupon.setMarketingCarrierNumCode(carrierCodeString);
					}

					String codeShareclientId = clientId;
					String marketingCXR = null;
					if (StringUtils.isNotEmpty(ticketCoupon.getMarketingCarrierNumCode())) {
						marketingCXR = ticketCoupon.getMarketingCarrierNumCode();
					}
					String marketedRBDList = null;
					if (StringUtils.isNotEmpty(ticketCoupon.getTicketedRbd())) {
						marketedRBDList = ticketCoupon.getTicketedRbd();
					}
					LocalDate effectiveTravelDate = null;
					String finalresult = null;
					if (ticketCoupon.getMarketingFlightDate() != null) {
						effectiveTravelDate = ticketCoupon.getMarketingFlightDate();

						DateTimeFormatter out = new DateTimeFormatterBuilder().parseCaseInsensitive().appendPattern("yyyy-MM-dd").toFormatter();

						// SimpleDateFormat out = new SimpleDateFormat("yyyy-MM-dd");
						String result = out.format(effectiveTravelDate);
						if (StringUtils.isNotEmpty(result)) {
							finalresult = result;
						}
					}

					/*
					 * List<CodeShare> codeShareList =
					 * smartpraMasterAppClient.getCodeShareByEffectiveDateBSP( codeShareclientId,
					 * marketingCXR, marketedRBDList, finalresult);
					 * 
					 * if (codeShareList != null && !codeShareList.isEmpty()) {
					 * ticketCoupon.setPlannedOptgCxrAlphaCode(
					 * OptionalUtil.getValue(codeShareList.get(0).getOperatingCXR()));
					 * 
					 * List<Carrier> carrierMasterList1 =
					 * carrierMasterFeignClient.getAllCarrier(carrierCode,
					 * ticketCoupon.getPlannedOptgCxrAlphaCode(), carrierName1, carrierName2);
					 * 
					 * if (carrierMasterList1 != null && !carrierMasterList1.isEmpty()) {
					 * ticketCoupon.setPlannedOptgCxrNumCode(
					 * OptionalUtil.getValue(carrierMasterList1.get(0).getCarrierCode())); } }
					 */
					
					if (ticketDoc.get("conjTicketIndicator").equals(ARCConstants.INDICATOR_YES)) {
						try {
							Optional<TicketDocumentIdentificationStg> live = ticketDocumentIdentificationStgRepository
									.findOneByFileHdrIdAndTransactionHdrIdAndConjuctionTicketIndicatorLike(
											ticketDocumentIdentificationStg.getFileHdrId(),
											ticketDocumentIdentificationStg.getTransactionHdrId(), "");

							if (live.isPresent()) {
								ticketCoupon.setMainDocument(live.get().getTktDocNumber().substring(3, 13).trim());
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						ticketCoupon.setMainDocument(ticketDoc.get("mainDocument"));
					}
					
					ticketCoupon.setDocumentNumber(ticketMain.getDocumentNumber());
					ticketCoupon.setIssueAirline(ticketMain.getIssueAirline());
					ticketCoupon.setDocumentUniqueId(ticketMain.getDocumentUniqueId());
					ticketCoupon.setAdditionalCommission(new BigDecimal(0));
					Date d = new Date();
					ticketCoupon.setAllianceRequestDate(d);
					ticketCoupon.setSaleCommission(new BigDecimal(0));
					ticketCoupon.setSaleDiscount(new BigDecimal(0));
					ticketCoupon.setSaleFare(new BigDecimal(0));
					ticketCoupon.setSaleOrc(new BigDecimal(0));
					ticketCoupon.setEndorsementIndicator("");
					ticketCoupon.setProcessingDateAndTime(d);
					ticketCoupon.setBatchDetails("");
					ticketCoupon.setSectorFareAmount(new BigDecimal(0));
					ticketCoupon.setDiscountAmount(new BigDecimal(0));
					ticketCoupon.setCommissionAmount(new BigDecimal(0));
					ticketCoupon.setOrcAmount(new BigDecimal(0));
					ticketCoupon.setMcoCouponValue(new BigDecimal(0));
					ticketCoupon.setInvolFlag("N");
					ticketCoupon.setSectorNumber(String.valueOf(++ticketCouponCount));
					ticketCoupon.setNotValidBefore(itineraryDataSegmentStg.getNotValidBeforeDate());
					ticketCoupon.setNotValidAfter(itineraryDataSegmentStg.getNotValidAfterDate());
					ticketCoupon.setCreatedBy(ticketMain.getCreatedBy());
					ticketCoupon.setCreatedDate(ticketMain.getCreatedDate());
					ticketCoupon.setFileId(fileId);
					ticketCoupons.add(ticketCoupon);
					couponMap.put(ticketCoupon.getCouponNumber(), ticketCoupon);

				}

				List<AdditionalItineraryDataStg> itineraryAddlDataStgs = transactionHeaderStg.getAdditionalItineraryDataStgs();
				for (int i = 0; i < ticketCoupons.size(); i++) {
					int currentRecord = i;
					if (i < itineraryAddlDataStgs.size()) {
						if (!itineraryAddlDataStgs.isEmpty() && Long.parseLong(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)) == Long
										.parseLong(itineraryAddlDataStgs.get(i).getTktDocNumber().substring(3, 13))) {

							TicketCoupon ticketCoupon = ticketCoupons.get(currentRecord);

							ticketCoupon.setDepartureTerminal(itineraryAddlDataStgs.get(i).getFlightDepartTerminal());
							String sDate4 = itineraryAddlDataStgs.get(i).getFlightArrivalDate();
							ticketCoupon.setArrivalDate(ARCUtil.getFormattedDate(sDate4, "ddMMMyy"));
							ticketCoupon.setArrivalTime(itineraryAddlDataStgs.get(i).getFlightArrivalTime());
							ticketCoupon.setArrivalTerminal(itineraryAddlDataStgs.get(i).getFlightArrivalTerminal());
							ticketCoupon.setDepartureTime(itineraryAddlDataStgs.get(i).getFlightDepartTime());
							ticketCoupons.set(currentRecord, ticketCoupon);

						}
					}
				}

				List<EMDCouponDetailStg> eMDCouponDetailStgs = transactionHeaderStg.getEmdCouponDetailStgs();
				for (int i = 0; i < ticketCoupons.size(); i++) {
					int currentRecord = i;
					if (i < eMDCouponDetailStgs.size()) {
						for (EMDCouponDetailStg emdCouponDetail : eMDCouponDetailStgs)
							if (!eMDCouponDetailStgs.isEmpty() && Long.parseLong(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)) == Long
											.parseLong(emdCouponDetail.getTktDocNumber().substring(3, 13))) {

								TicketCoupon ticketCoupon = ticketCoupons.get(currentRecord);

								String rawValue = emdCouponDetail.getEmdCpnValue();
								if (!rawValue.isEmpty() && rawValue != null) {

									String emdCpnValueSign = ARCUtil.getSignedFieldValue(rawValue);
									String emdCpnValueString = ARCUtil.getSignedFieldStringValue(emdCpnValueSign, decimalPrecision);
									BigDecimal emdCpnValue = ARCUtil.getvalidatedBigDecimal(emdCpnValueString);
									ticketCoupon.setEmdCouponValue(emdCpnValue);
								}
								ticketCoupon.setEmdCurrencyType(emdCouponDetail.getCurrencyType().substring(0, 3));
								ticketCoupon.setEmdFeeOwnerAirlineDesign(emdCouponDetail.getEmdFeeOwnerAirlineDesigt());
								ticketCoupon.setEmdRelatedTicketNumber(emdCouponDetail.getEmdTktDocNumber());
								ticketCoupon.setEmdRelatedCouponNumber(Integer.valueOf(emdCouponDetail.getEmdCpnNumber()));
								ticketCoupon.setEmdServiceType(emdCouponDetail.getEmdServiceType());
								ticketCoupon.setEmdReasonForIssuanceSubcde(emdCouponDetail.getEmdReasonIssuanceSubcode());
								ticketCoupon.setEmdXcessBaggOverAllowQlfy(emdCouponDetail.getEmdEbdOverAllowQualifier());
								ticketCoupon.setEmdExcessBaggCurrencyCode(emdCouponDetail.getEmdExcessBaggageCurrCode());
								ticketCoupon.setEmdExcessBaggRatePerUnit(emdCouponDetail.getEmdEbtRatePerUnit());
								ticketCoupon.setEmdBaggTotalNoInExcs(emdCouponDetail.getEmdEbtTotalNoExcess());
								ticketCoupon.setEmdConsumedAtIssuanceInd(emdCouponDetail.getEmdEbtConsumedIssueInd());
								ticketCoupon.setEmdNumberOfServices(Integer.valueOf(emdCouponDetail.getEmdNoOfServices()));
								ticketCoupon.setEmdOperatingCarrier(emdCouponDetail.getEmdOperatingCarrier());
								ticketCoupon.setEmdAttributeGroup(emdCouponDetail.getEmdAttributeGroup());
								ticketCoupon.setEmdAttributeSubGroup(emdCouponDetail.getEmdAttributeSubgroup());
								ticketCoupon.setEmdIndustryCarrierIndicator(emdCouponDetail.getEmdIndustryCarrierIndicator());
								ticketCoupon.setTicketMain(ticketMain);
								ticketCoupons.set(currentRecord, ticketCoupon);
								ticketMain.setTicketCoupons(ticketCoupons);

							}
					}
				}
			}

			if (!transactionHeaderStg.getItineraryDataSegmentStg().isEmpty()) {
				for (int i = 0; i < ticketCoupons.size(); i++) {

					List<TicketCouponFnf> ticketCouponFnfs = new LinkedList<>();
					TicketCoupon ticketCoupon = ticketCoupons.get(i);
					TicketCouponFnf ticketCouponFnf = new TicketCouponFnf();

					ticketCouponFnf.setCouponNumber(Integer.parseInt(transactionHeaderStg.getItineraryDataSegmentStg().get(i).getSegmentIdentifier()));
					ticketCouponFnf.setSectorNumber(String.valueOf(ticketCoupon.getSectorNumber()));
					ticketCouponFnf.setMainDocument(ticketDoc.get("mainDocument"));
					ticketCouponFnf.setDocumentNo(ticketMain.getDocumentNumber());
					ticketCouponFnf.setIssAirline(ticketMain.getIssueAirline());
					ticketCouponFnf.setDocumentUniqueId(ticketMain.getDocumentUniqueId());
					ticketCouponFnf.setCreatedBy(ticketMain.getCreatedBy());
					ticketCouponFnf.setCreatedDate(ticketMain.getCreatedDate());
					ticketCouponFnf.setTicketCoupon(ticketCoupon);
					ticketCouponFnf.setFileId(fileId);
					ticketCouponFnfs.add(ticketCouponFnf);
					ticketCoupon.setTicketCouponFnfs(ticketCouponFnfs);
					
					ticketCoupons.set(i, ticketCoupon);

				}
			}

		}
		try {
			if(ticketDoc.get("couponUsageIndicator").contains("S")) {
			TicketCoupon ticketCouponSurface = buildSurface(ticketDoc.get("couponUsageIndicator"), couponMap, ticketDocumentIdentificationStg,ticketMain);
			if(ticketCouponSurface != null) {
				ticketCouponSurface.setFileId(fileId);
				ticketCoupons.add(ticketCouponSurface);
			}
			}
		} catch (Exception e) {
		}
		return ticketCoupons;
	}

	
	private TicketCoupon buildSurface(String couponUseIndc, Map<Integer, TicketCoupon> couponMap,
			TicketDocumentIdentificationStg ticketDocumentIdentificationStg,TicketMain ticketMain) {
//		System.out.println("=========buildSurface================1============="+couponUseIndc);
		int position = couponUseIndc.indexOf("S");
//		System.out.println("=========position================1============="+position);
		position = position + 1;
		TicketCoupon ticketCouponSurface = null;
//		System.out.println("=========position================2============="+position);
//		System.out.println("=========buildSurface================2============="+position);
	
		if (position == 2) {
//			System.out.println("=========buildSurface================3=============");
			TicketCoupon ticketCouponPrev = couponMap.get(position - 1);
			TicketCoupon ticketCouponNext = couponMap.get(position + 1);
			ticketCouponSurface = new TicketCoupon(); 
			ticketCouponSurface.setCouponNumber(position);
			ticketCouponSurface.setSectorNumber(position + 1 + "");
			ticketCouponSurface.setFromAirport(ticketCouponPrev.getToAirport());
			ticketCouponSurface.setToAirport(ticketCouponNext.getFromAirport());
			ticketCouponSurface.setMarketingCarrierAlphaCode("/-");
			ticketCouponSurface.setDocumentUniqueId(ticketCouponPrev.getDocumentUniqueId());
			ticketCouponSurface.setMainDocument(ticketCouponPrev.getMainDocument());
			ticketCouponSurface.setDocumentNumber(ticketCouponPrev.getDocumentNumber());
			ticketCouponSurface.setIssueAirline(ticketMain.getIssueAirline());
			ticketCouponSurface.setCreatedBy(ticketMain.getCreatedBy());
			ticketCouponSurface.setCreatedDate(ticketMain.getCreatedDate());
			ticketCouponSurface.setIssueAirline(ticketMain.getIssueAirline());
//			logger.info("Missed coupon======2====================" + ticketCouponSurface.toString());

		} else

		if (position == 3) {
//			System.out.println("=========buildSurface===============4=============");
			TicketCoupon ticketCouponPrev = couponMap.get(position - 1);
			TicketCoupon ticketCouponNext = couponMap.get(position + 1);
			ticketCouponSurface = new TicketCoupon();
			ticketCouponSurface.setCouponNumber(position);
			ticketCouponSurface.setSectorNumber(position + 1 + "");
			ticketCouponSurface.setFromAirport(ticketCouponPrev.getToAirport());
			ticketCouponSurface.setToAirport(ticketCouponNext.getFromAirport());
			ticketCouponSurface.setMarketingCarrierAlphaCode("/-");
			ticketCouponSurface.setDocumentUniqueId(ticketCouponPrev.getDocumentUniqueId());
			ticketCouponSurface.setMainDocument(ticketCouponPrev.getMainDocument());
			ticketCouponSurface.setDocumentNumber(ticketCouponPrev.getDocumentNumber());
			ticketCouponSurface.setIssueAirline(ticketMain.getIssueAirline());
			ticketCouponSurface.setCreatedBy(ticketMain.getCreatedBy());
			ticketCouponSurface.setCreatedDate(ticketMain.getCreatedDate());
			ticketCouponSurface.setIssueAirline(ticketMain.getIssueAirline());
//			logger.info("Missed coupon======3====================" + ticketCouponSurface.toString());
		} else

		if (position == 4) {
//			System.out.println("=========buildSurface================5============");
			List<TicketDocumentIdentificationStg> listOfConj = ticketDocumentIdentificationStgRepository
					.findAllByFileHdrIdAndTransactionHdrIdAndConjuctionTicketIndicatorLike(
							ticketDocumentIdentificationStg.getFileHdrId(),
							ticketDocumentIdentificationStg.getTransactionHdrId(), "CNJ");
			ItineraryDataSegmentStg itineraryDataSegmentStg = null;

			if (!listOfConj.isEmpty()) {
				TicketDocumentIdentificationStg identificationStg = listOfConj.get(0);
				List<ItineraryDataSegmentStg> list = identificationStg.getTransactionHeaderStg().getItineraryDataSegmentStg();
				for(ItineraryDataSegmentStg itn : list) {
					if (Integer.valueOf(itn.getSegmentIdentifier() )== 1) {
						itineraryDataSegmentStg = itn;
					}
				}

//				logger.info("size of the list==================>" + listOfConj.size());
			}
			TicketCoupon ticketCouponPrev = couponMap.get(position - 1);
			ticketCouponSurface = new TicketCoupon();
			ticketCouponSurface.setCouponNumber(position);
			ticketCouponSurface.setSectorNumber(position + 1 + "");
			ticketCouponSurface.setFromAirport(ticketCouponPrev.getToAirport());
			if (itineraryDataSegmentStg != null) {
				ticketCouponSurface.setToAirport(itineraryDataSegmentStg.getOrginAirportCityCode());
			}
			ticketCouponSurface.setMarketingCarrierAlphaCode("/-");
			ticketCouponSurface.setDocumentUniqueId(ticketCouponPrev.getDocumentUniqueId());
			ticketCouponSurface.setMainDocument(ticketCouponPrev.getMainDocument());
			ticketCouponSurface.setDocumentNumber(ticketCouponPrev.getDocumentNumber());
			ticketCouponSurface.setCreatedBy(ticketMain.getCreatedBy());
			ticketCouponSurface.setIssueAirline(ticketMain.getIssueAirline());
			ticketCouponSurface.setCreatedDate(ticketMain.getCreatedDate());
//			logger.info("Missed coupon======4====================" + ticketCouponSurface.toString());
		}

		return ticketCouponSurface;

	}

}
