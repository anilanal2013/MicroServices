package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

public class BillingCycleHeader extends ARCBaseRecord {

	@Override
	public String getRecordType() {
		return ARCRecordType.BILLING_CYCLE_HEADER;
	}

	public BillingCycleHeader(Map<String, String> recordMap) {
		super(recordMap);
	}
	
	public BillingCycleHeader() {
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String processingDateIdentifier;
	private String processingCycleIdentifier;
	private String billingAnalysisEndingDate;
	private String dynamicRunIdentifier;
	private String hotReportingEndDate;
	private String filler2;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getProcessingDateIdentifier() {
		return processingDateIdentifier;
	}

	public void setProcessingDateIdentifier(String processingDateIdentifier) {
		this.processingDateIdentifier = processingDateIdentifier;
	}

	public String getProcessingCycleIdentifier() {
		return processingCycleIdentifier;
	}

	public void setProcessingCycleIdentifier(String processingCycleIdentifier) {
		this.processingCycleIdentifier = processingCycleIdentifier;
	}

	public String getBillingAnalysisEndingDate() {
		return billingAnalysisEndingDate;
	}

	public void setBillingAnalysisEndingDate(String billingAnalysisEndingDate) {
		this.billingAnalysisEndingDate = billingAnalysisEndingDate;
	}

	public String getDynamicRunIdentifier() {
		return dynamicRunIdentifier;
	}

	public void setDynamicRunIdentifier(String dynamicRunIdentifier) {
		this.dynamicRunIdentifier = dynamicRunIdentifier;
	}

	public String getHotReportingEndDate() {
		return hotReportingEndDate;
	}

	public void setHotReportingEndDate(String hotReportingEndDate) {
		this.hotReportingEndDate = hotReportingEndDate;
	}

	public String getFiller2() {
		return filler2;
	}

	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}
}
