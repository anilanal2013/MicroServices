package com.sgl.smartpra.batch.arc.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.arc.app.service.ARCJobLauncher;

@RestController
public class ARCBatchController {

	@Autowired
	ARCJobLauncher arcJobLauncher;

	@RequestMapping("/arc/processFile")
	public String  processFile(@RequestParam("inboundFileName") String inboundFileName, @RequestParam("user") String user,
			@RequestParam("clientId") String clientId) throws Exception {
		return arcJobLauncher.launchARCStagingLoadJob(inboundFileName, user, clientId);
	}

	@RequestMapping("/arc/moveStagingToProd")
	public void moveStagingToProd(@RequestParam("fileId") Long fileId, @RequestParam("user") String user)
			throws Exception {
		arcJobLauncher.launchARCProdLoadJob(fileId, user);
	}
	
	@RequestMapping("/arc/businessValidations")
	public void executeSalesBusinessValidation(@RequestParam("fileId") Long fileId) {
		
	}

}
