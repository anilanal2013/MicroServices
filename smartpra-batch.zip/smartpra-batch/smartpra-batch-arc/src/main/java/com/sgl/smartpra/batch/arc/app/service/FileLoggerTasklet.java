package com.sgl.smartpra.batch.arc.app.service;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.arc.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.arc.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.arc.app.util.ARCUtil;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;

@Service
public class FileLoggerTasklet implements Tasklet {

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		String clientId = chunkContext.getStepContext().getJobParameters().get("clientId").toString();

		FileLogging fileLogging = ARCUtil.initFileLogging(chunkContext.getStepContext().getJobParameters().get("user").toString());

		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_INPUT);
		fileLogging.setFileName(chunkContext.getStepContext().getJobParameters().get("fileName").toString());
		fileLogging.setProcessedBy(chunkContext.getStepContext().getJobParameters().get("user").toString());
		fileLogging.setFileType("ARC_IN");
		fileLogging.setClientId(clientId);
		fileLogging.setJobName(chunkContext.getStepContext().getJobName());

		fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);

		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().putInt("fileId",
				fileLogging.getFileId().intValue());

		return RepeatStatus.FINISHED;
	}
}
