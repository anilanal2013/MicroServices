package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class BillingCycleTotals extends ARCBaseRecord {

	@Override
	public String getRecordType() {
		return ARCRecordType.BILLING_CYCLE_TOTALS_PER_CURRTYPE;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}
	
	public BillingCycleTotals() {
	}

	public BillingCycleTotals(Map<String, String> recordMap) {
		super(recordMap);
	} 
	
	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String processingDateIdentifier;
	private String processingCycleIdentifier;
	private String officeCount;
	private String grossValueAmt;
	private String totalRemittanceAmt;
	private String totalCommissionValue;
	private String totalTaxMiscFeeAmt;
	private String totalTaxOnCommissionAmt;
	private String filler;
	private String currencyType;
	private String line;
	private String transactionCount;
	private String numberOfReports;
	private String totalRemittanceAmount;
	private String totalAdjustAmount;
	private String netCashValueAmount;
	private String decimalPlacesCurrency;
	private String totalCommissionAmount;
	private String miscFeeAmount;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getProcessingDateIdentifier() {
		return processingDateIdentifier;
	}

	public void setProcessingDateIdentifier(String processingDateIdentifier) {
		this.processingDateIdentifier = processingDateIdentifier;
	}

	public String getProcessingCycleIdentifier() {
		return processingCycleIdentifier;
	}

	public void setProcessingCycleIdentifier(String processingCycleIdentifier) {
		this.processingCycleIdentifier = processingCycleIdentifier;
	}

	public String getOfficeCount() {
		return officeCount;
	}

	public void setOfficeCount(String officeCount) {
		this.officeCount = officeCount;
	}

	public String getGrossValueAmt() {
		return grossValueAmt;
	}

	public void setGrossValueAmt(String grossValueAmt) {
		this.grossValueAmt = grossValueAmt;
	}

	public String getTotalRemittanceAmt() {
		return totalRemittanceAmt;
	}

	public void setTotalRemittanceAmt(String totalRemittanceAmt) {
		this.totalRemittanceAmt = totalRemittanceAmt;
	}

	public String getTotalCommissionValue() {
		return totalCommissionValue;
	}

	public void setTotalCommissionValue(String totalCommissionValue) {
		this.totalCommissionValue = totalCommissionValue;
	}

	public String getTotalTaxMiscFeeAmt() {
		return totalTaxMiscFeeAmt;
	}

	public void setTotalTaxMiscFeeAmt(String totalTaxMiscFeeAmt) {
		this.totalTaxMiscFeeAmt = totalTaxMiscFeeAmt;
	}

	public String getTotalTaxOnCommissionAmt() {
		return totalTaxOnCommissionAmt;
	}

	public void setTotalTaxOnCommissionAmt(String totalTaxOnCommissionAmt) {
		this.totalTaxOnCommissionAmt = totalTaxOnCommissionAmt;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getTransactionCount() {
		return transactionCount;
	}

	public void setTransactionCount(String transactionCount) {
		this.transactionCount = transactionCount;
	}

	public String getNumberOfReports() {
		return numberOfReports;
	}

	public void setNumberOfReports(String numberOfReports) {
		this.numberOfReports = numberOfReports;
	}


	public String getTotalRemittanceAmount() {
		return totalRemittanceAmount;
	}

	public void setTotalRemittanceAmount(String totalRemittanceAmount) {
		this.totalRemittanceAmount = totalRemittanceAmount;
	}

	public String getTotalAdjustAmount() {
		return totalAdjustAmount;
	}

	public void setTotalAdjustAmount(String totalAdjustAmount) {
		this.totalAdjustAmount = totalAdjustAmount;
	}

	public String getNetCashValueAmount() {
		return netCashValueAmount;
	}

	public void setNetCashValueAmount(String netCashValueAmount) {
		this.netCashValueAmount = netCashValueAmount;
	}

	public String getDecimalPlacesCurrency() {
		return decimalPlacesCurrency;
	}

	public void setDecimalPlacesCurrency(String decimalPlacesCurrency) {
		this.decimalPlacesCurrency = decimalPlacesCurrency;
	}

	public String getTotalCommissionAmount() {
		return totalCommissionAmount;
	}

	public void setTotalCommissionAmount(String totalCommissionAmount) {
		this.totalCommissionAmount = totalCommissionAmount;
	}

	public String getMiscFeeAmount() {
		return miscFeeAmount;
	}

	public void setMiscFeeAmount(String miscFeeAmount) {
		this.miscFeeAmount = miscFeeAmount;
	}
}
