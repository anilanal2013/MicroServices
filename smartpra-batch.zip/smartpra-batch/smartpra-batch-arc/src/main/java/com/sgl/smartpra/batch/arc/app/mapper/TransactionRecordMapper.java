package com.sgl.smartpra.batch.arc.app.mapper;

import java.util.ArrayList;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;

import com.sgl.smartpra.batch.arc.app.record.TransactionRecord;
import com.sgl.smartpra.batch.arc.app.record.WaiverCode;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoPassengerStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CommissionStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDCouponDetailStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDRemarksStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FareCalculationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.ItineraryDataSegmentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.QualIssueInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.RelatedTicketDocumentInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.StdDocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketTransactionExtractStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionRecordStg;
import com.sgl.smartpra.sales.model.TicketTransactionExtract;

public class TransactionRecordMapper {

	public static TransactionRecordStg mapTransactionRecord(TransactionRecord transactionRecord) {

		if (transactionRecord == null) {
			return null;
		}

		TransactionRecordStg transactionRecordStg = new TransactionRecordStg();

		mapTransactionHeader(transactionRecordStg, transactionRecord);
		mapDocumentIdentification(transactionRecordStg, transactionRecord);
		mapStdDocumentAmounts(transactionRecordStg, transactionRecord);
		mapCommission(transactionRecordStg, transactionRecord);
		mapQualIssueInfo(transactionRecordStg, transactionRecord);
		mapItineraryDataSegment(transactionRecordStg, transactionRecord);
		mapAddlInfoPassenger(transactionRecordStg, transactionRecord);
		mapEMDCouponDetail(transactionRecordStg, transactionRecord);
		mapEMDRemarks(transactionRecordStg, transactionRecord);
		mapFareCalculation(transactionRecordStg, transactionRecord);
		mapFormOfPayment(transactionRecordStg, transactionRecord);
		mapRelatedTicketDocumentInfo(transactionRecordStg, transactionRecord);
//		mapExtractData(transactionRecordStg, transactionRecord);
		return transactionRecordStg;
	}

	private static void mapTransactionHeader(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {

		// Transaction Header
		if (transactionRecord.getTransactionHeader() == null) {
			return;
		}

		TransactionHeaderStg transactionHeaderStg = ARCRecordMapper.INSTANCE
				.mapTransactionHeaderRecord(transactionRecord.getTransactionHeader());
		transactionRecordStg.setTransactionHeaderStg(transactionHeaderStg);

	}

	private static void mapDocumentIdentification(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Ticket / Document Identification
		if (transactionRecord.getTicketDocumentIdentificationList() == null) {
			return;
		}

		ArrayList<TicketDocumentIdentificationStg> ticketDocumentIdentificationStgList = new ArrayList<TicketDocumentIdentificationStg>();
		transactionRecord.getTicketDocumentIdentificationList().forEach(item -> {
			TicketDocumentIdentificationStg ticketDocumentIdentificationStg = ARCRecordMapper.INSTANCE
					.mapTicketDocumentIdentificationRecord(item);
			ticketDocumentIdentificationStg.setDocType(item.getDocType());
			if (item.getCpnUseIndicator().contains("R")) {
				ticketDocumentIdentificationStg.setTransactionCode("RFND");
			}
			if (item.getConjuctionTicketIndicator().equalsIgnoreCase("CJN")) {
				ticketDocumentIdentificationStg.setConjuctionTicketIndicator("CNJ");
			}
			ticketDocumentIdentificationStgList.add(ticketDocumentIdentificationStg);
		});

		if (ticketDocumentIdentificationStgList.size() > 0) {
			transactionRecordStg.setTicketDocumentIdentificationStgList(ticketDocumentIdentificationStgList);
		}
	}

	private static void mapStdDocumentAmounts(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Standard Document Amounts
		if (transactionRecord.getStdDocumentAmountsList() == null) {
			return;
		}

		ArrayList<StdDocumentAmountsStg> stdDocumentAmountsStgList = new ArrayList<StdDocumentAmountsStg>();
		transactionRecord.getStdDocumentAmountsList().forEach(item -> {
			StdDocumentAmountsStg stdDocumentAmountsStg = ARCRecordMapper.INSTANCE.mapStdDocumentAmountsRecord(item);
			stdDocumentAmountsStgList.add(stdDocumentAmountsStg);
		});

		if (stdDocumentAmountsStgList.size() > 0) {
			transactionRecordStg.setStdDocumentAmountsStgList(stdDocumentAmountsStgList);
		}
	}

	private static void mapCommission(TransactionRecordStg transactionRecordStg, TransactionRecord transactionRecord) {
		// Commission
		if (transactionRecord.getCommissionList() == null) {
			return;
		}

		ArrayList<CommissionStg> commissionStgList = new ArrayList<CommissionStg>();
		transactionRecord.getCommissionList().forEach(item -> {
			CommissionStg commissionStg = ARCRecordMapper.INSTANCE.mapCommissionRecord(item);
			commissionStgList.add(commissionStg);
		});

		if (commissionStgList.size() > 0) {
			transactionRecordStg.setCommissionStgList(commissionStgList);
		}
	}


	private static void mapQualIssueInfo(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Qual Issue Info
		if (transactionRecord.getQualIssueInfoList() == null) {
			return;
		}

		ArrayList<QualIssueInfoStg> qualIssueInfoStgList = new ArrayList<QualIssueInfoStg>();
		transactionRecord.getQualIssueInfoList().forEach(item -> {
			QualIssueInfoStg qualIssueInfoStg = ARCRecordMapper.INSTANCE.mapQualIssueInfoRecord(item);
			qualIssueInfoStgList.add(qualIssueInfoStg);
		});

		if (qualIssueInfoStgList.size() > 0) {
			transactionRecordStg.setQualIssueInfoStgList(qualIssueInfoStgList);
		}
	}


	private static void mapItineraryDataSegment(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Itinerary Data Segment
		if (transactionRecord.getItineraryDataSegmentList() == null) {
			return;
		}

		ArrayList<ItineraryDataSegmentStg> itineraryDataSegmentStgList = new ArrayList<ItineraryDataSegmentStg>();
		transactionRecord.getItineraryDataSegmentList().forEach(item -> {
			ItineraryDataSegmentStg itineraryDataSegmentStg = ARCRecordMapper.INSTANCE
					.mapItineraryDataSegmentRecord(item);
			itineraryDataSegmentStgList.add(itineraryDataSegmentStg);
		});

		if (itineraryDataSegmentStgList.size() > 0) {
			transactionRecordStg.setItineraryDataSegmentStgList(itineraryDataSegmentStgList);
		}

	}

	private static void mapAddlInfoPassenger(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Additional Info Passenger
		if (transactionRecord.getAddlInfoPassenger() == null) {
			return;
		}

		AddlInfoPassengerStg addlInfoPassengerStg = ARCRecordMapper.INSTANCE
				.mapAddlInfoPassengerRecord(transactionRecord.getAddlInfoPassenger());
		transactionRecordStg.setAddlInfoPassengerStg(addlInfoPassengerStg);
	}



	private static void mapEMDCouponDetail(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// EMD Coupon Detail
		if (transactionRecord.getEmdCouponDetailList() == null) {
			return;
		}

		ArrayList<EMDCouponDetailStg> emdCouponDetailStgList = new ArrayList<EMDCouponDetailStg>();
		transactionRecord.getEmdCouponDetailList().forEach(item -> {
			EMDCouponDetailStg emdCouponDetailStg = ARCRecordMapper.INSTANCE.mapEMDCouponDetailRecord(item);
			emdCouponDetailStgList.add(emdCouponDetailStg);
		});

		if (emdCouponDetailStgList.size() > 0) {
			transactionRecordStg.setEmdCouponDetailStgList(emdCouponDetailStgList);
		}
	}

	private static void mapEMDRemarks(TransactionRecordStg transactionRecordStg, TransactionRecord transactionRecord) {
		// EMD Remarks
		if (transactionRecord.getEmdRemarksList() == null) {
			return;
		}

		ArrayList<EMDRemarksStg> emdRemarksStgList = new ArrayList<EMDRemarksStg>();
		transactionRecord.getEmdRemarksList().forEach(item -> {
			EMDRemarksStg emdRemarksStg = ARCRecordMapper.INSTANCE.mapEMDRemarksRecord(item);
			emdRemarksStgList.add(emdRemarksStg);
		});

		if (emdRemarksStgList.size() > 0) {
			transactionRecordStg.setEmdRemarksStgList(emdRemarksStgList);
		}
	}

	private static void mapFareCalculation(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Fare Calculation
		if (transactionRecord.getFareCalculationList() == null) {
			return;
		}

		ArrayList<FareCalculationStg> fareCalculationStgList = new ArrayList<FareCalculationStg>();
		transactionRecord.getFareCalculationList().forEach(item -> {
			FareCalculationStg fareCalculationStg = ARCRecordMapper.INSTANCE.mapFareCalculationRecord(item);
			fareCalculationStgList.add(fareCalculationStg);
		});

		if (fareCalculationStgList.size() > 0) {
			transactionRecordStg.setFareCalculationStgList(fareCalculationStgList);
		}
	}


	private static void mapFormOfPayment(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Form Of Payment
		if (transactionRecord.getFormOfPaymentList() == null) {
			return;
		}
		ArrayList<FormOfPaymentStg> formOfPaymentStgList = new ArrayList<FormOfPaymentStg>();
		transactionRecord.getFormOfPaymentList().forEach(item -> {
			FormOfPaymentStg formOfPaymentStg = ARCRecordMapper.INSTANCE.mapFormOfPaymentRecord(item);
			formOfPaymentStgList.add(formOfPaymentStg);
		});

		if (formOfPaymentStgList.size() > 0) {
			transactionRecordStg.setFormOfPaymentStgList(formOfPaymentStgList);
		}
	}
	
	private static void mapExtractData(TransactionRecordStg transactionRecordStg, TransactionRecord transactionRecord) {

		if (transactionRecord.getRecord() == null) {
			return;
		}

		TicketTransactionExtract transactionExtract = new TicketTransactionExtract();
		transactionRecord.setRecord(transactionRecord.getRecord());
		StringBuffer buffer = new StringBuffer();
		for (String line : transactionRecord.getRecord()) {
			buffer.append(line);
			buffer.append("\n");
		}
		if(buffer != null) {
		transactionExtract.setTransactionInfo(Optional.of(buffer.toString()));
		TicketTransactionExtractStg transactionExtractStg = ARCRecordMapper.INSTANCE
				.mapTicketDataRecord(transactionExtract);

		if (transactionExtractStg != null) {
			transactionRecordStg.setTicketTransactionExtractStg(transactionExtractStg);
		}
		
		}

	}
	
	private static void mapRelatedTicketDocumentInfo(TransactionRecordStg transactionRecordStg, TransactionRecord transactionRecord) {
		// SRD Document
		if (transactionRecord.getSrdTktDocIdentificationList() == null) {
//			System.out.println("srd lIST EMPTY");
			return;
		}
		ArrayList<RelatedTicketDocumentInfoStg> relatedTktDocInfoList = new ArrayList<RelatedTicketDocumentInfoStg>();
		transactionRecord.getSrdTktDocIdentificationList().forEach(item -> {
			String waiverCode = "";
			if (CollectionUtils.isNotEmpty(transactionRecord.getWaiverCodeList())) {
				Optional<WaiverCode> waiverCodeObj = transactionRecord.getWaiverCodeList().stream()
						.filter(waverStream -> (waverStream.getTransactionNumber().equals(item.getTransactionNumber())))
						.findFirst();
				waiverCode = waiverCodeObj.get().getWaiverCode();
			}
			RelatedTicketDocumentInfoStg relatedDocumentStg = ARCRecordMapper.INSTANCE.mapRelatedTicketDocumentInfoRecord(item);
			relatedDocumentStg.setWaiverCode(waiverCode);
			relatedDocumentStg.setRelatedTktDocCpnIdentifier(getNoOfCoupons(item.getRelatedTktDocCpnIdentifier(), 'F'));
			relatedTktDocInfoList.add(relatedDocumentStg);
		});

		if (relatedTktDocInfoList.size() > 0) {
			transactionRecordStg.setRelatedTicketDocumentInfoStgList(relatedTktDocInfoList);
		}
	}
	
	public static String getNoOfCoupons(String cpnUseIndicator, char cpnIndicator) {
		StringBuilder sb = new StringBuilder();
		int i = 1;
		char[] cpnUseIndicatorArr = cpnUseIndicator.toCharArray();
		for (char s : cpnUseIndicatorArr) {
			if (s == cpnIndicator) {
				sb.append(i);
			} else {
				sb.append(0);
			}
			i = i + 1;
		}
		return sb.toString();
	}
}
