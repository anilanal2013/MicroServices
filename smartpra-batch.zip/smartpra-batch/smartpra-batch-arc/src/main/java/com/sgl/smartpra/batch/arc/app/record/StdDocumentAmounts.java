package com.sgl.smartpra.batch.arc.app.record;

import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import lombok.NoArgsConstructor;

public class StdDocumentAmounts extends ARCBaseRecord {
	
	
	public StdDocumentAmounts() {
	}
	
	private String line;

	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktCarrierCode;
	private String tktDocNumber;
	private String reservedSpace;
	private String checkDigit;
	private String fareAmt;
	private String currencyType;
	private String decimalPlaces;
	private String miscFeeType;
	private String miscFeeSubCode;
	private String miscFeeAmount;
	private String miscFeeTypeTwo;
	private String miscFeeSubCodeTwo;
	private String miscFeeAmountTwo;
	private String sourceOfTotalAmount;
	private String sourceOfTaxBreakDown;
	private String currencyTypeIntlFare;
	private String decimalPlacesCurrencyIntlFare;
	private String ptaMultiPerson;
	private String penaltyRestrictionIndicator;
	private String filler;
	private String netFareAmount;
	private String tktDocAmount;
	private String taxMiscFeeType1;
	private String taxMiscFeeAmount1;
	private String taxMiscFeeType2;
	private String taxMiscFeeAmount2;

	@Override
	public String getRecordType() {
		return ARCRecordType.STD_DOCUMENT_AMOUNTS;
	}
	
	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(getColumns(fixedLengthFieldLayoutList));
		tokenizer.setNames(getNames(fixedLengthFieldLayoutList));
		return tokenizer;
	}

	@Override
	public FieldSetMapper<ARCBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<ARCBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<ARCBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	public StdDocumentAmounts(Map<String, String> recordMap) {
		super(recordMap);
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktCarrierCode() {
		return tktCarrierCode;
	}

	public void setTktCarrierCode(String tktCarrierCode) {
		this.tktCarrierCode = tktCarrierCode;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getReservedSpace() {
		return reservedSpace;
	}

	public void setReservedSpace(String reservedSpace) {
		this.reservedSpace = reservedSpace;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getFareAmt() {
		return fareAmt;
	}

	public void setFareAmt(String fareAmt) {
		this.fareAmt = fareAmt;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getDecimalPlaces() {
		return decimalPlaces;
	}

	public void setDecimalPlaces(String decimalPlaces) {
		this.decimalPlaces = decimalPlaces;
	}

	public String getMiscFeeType() {
		return miscFeeType;
	}

	public void setMiscFeeType(String miscFeeType) {
		this.miscFeeType = miscFeeType;
	}

	public String getMiscFeeSubCode() {
		return miscFeeSubCode;
	}

	public void setMiscFeeSubCode(String miscFeeSubCode) {
		this.miscFeeSubCode = miscFeeSubCode;
	}

	public String getMiscFeeAmount() {
		return miscFeeAmount;
	}

	public void setMiscFeeAmount(String miscFeeAmount) {
		this.miscFeeAmount = miscFeeAmount;
	}

	public String getMiscFeeTypeTwo() {
		return miscFeeTypeTwo;
	}

	public void setMiscFeeTypeTwo(String miscFeeTypeTwo) {
		this.miscFeeTypeTwo = miscFeeTypeTwo;
	}

	public String getMiscFeeSubCodeTwo() {
		return miscFeeSubCodeTwo;
	}

	public void setMiscFeeSubCodeTwo(String miscFeeSubCodeTwo) {
		this.miscFeeSubCodeTwo = miscFeeSubCodeTwo;
	}

	public String getMiscFeeAmountTwo() {
		return miscFeeAmountTwo;
	}

	public void setMiscFeeAmountTwo(String miscFeeAmountTwo) {
		this.miscFeeAmountTwo = miscFeeAmountTwo;
	}

	public String getSourceOfTotalAmount() {
		return sourceOfTotalAmount;
	}

	public void setSourceOfTotalAmount(String sourceOfTotalAmount) {
		this.sourceOfTotalAmount = sourceOfTotalAmount;
	}

	public String getSourceOfTaxBreakDown() {
		return sourceOfTaxBreakDown;
	}

	public void setSourceOfTaxBreakDown(String sourceOfTaxBreakDown) {
		this.sourceOfTaxBreakDown = sourceOfTaxBreakDown;
	}

	public String getCurrencyTypeIntlFare() {
		return currencyTypeIntlFare;
	}

	public void setCurrencyTypeIntlFare(String currencyTypeIntlFare) {
		this.currencyTypeIntlFare = currencyTypeIntlFare;
	}

	public String getDecimalPlacesCurrencyIntlFare() {
		return decimalPlacesCurrencyIntlFare;
	}

	public void setDecimalPlacesCurrencyIntlFare(String decimalPlacesCurrencyIntlFare) {
		this.decimalPlacesCurrencyIntlFare = decimalPlacesCurrencyIntlFare;
	}

	public String getPtaMultiPerson() {
		return ptaMultiPerson;
	}

	public void setPtaMultiPerson(String ptaMultiPerson) {
		this.ptaMultiPerson = ptaMultiPerson;
	}

	public String getPenaltyRestrictionIndicator() {
		return penaltyRestrictionIndicator;
	}

	public void setPenaltyRestrictionIndicator(String penaltyRestrictionIndicator) {
		this.penaltyRestrictionIndicator = penaltyRestrictionIndicator;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getNetFareAmount() {
		return netFareAmount;
	}

	public void setNetFareAmount(String intlFareAmt) {
		this.netFareAmount = intlFareAmt;
	}

	public String getTktDocAmount() {
		return tktDocAmount;
	}

	public void setTktDocAmount(String tktDocAmount) {
		this.tktDocAmount = tktDocAmount;
	}

	public String getTaxMiscFeeType1() {
		return taxMiscFeeType1;
	}

	public void setTaxMiscFeeType1(String taxMiscFeeType1) {
		this.taxMiscFeeType1 = taxMiscFeeType1;
	}

	public String getTaxMiscFeeAmount1() {
		return taxMiscFeeAmount1;
	}

	public void setTaxMiscFeeAmount1(String taxMiscFeeAmount1) {
		this.taxMiscFeeAmount1 = taxMiscFeeAmount1;
	}

	public String getTaxMiscFeeType2() {
		return taxMiscFeeType2;
	}

	public void setTaxMiscFeeType2(String taxMiscFeeType2) {
		this.taxMiscFeeType2 = taxMiscFeeType2;
	}

	public String getTaxMiscFeeAmount2() {
		return taxMiscFeeAmount2;
	}

	public void setTaxMiscFeeAmount2(String taxMiscFeeAmount2) {
		this.taxMiscFeeAmount2 = taxMiscFeeAmount2;
	}


//	// Variables to hold record values
//	private String stdMessageIdentifier;
//	private String seqNumber;
//	private String stdNumericQuaifier;
//	private String dateOfIssue;
//	private String transactionNumber;
//	private String tktDocNumber;
//	private String checkDigit;
//	private String commissionableAmount;
//	private String netFareAmount;
//	private String taxMiscFeeType1;
//	private String taxMiscFeeAmount1;
//	private String taxMiscFeeType2;
//	private String taxMiscFeeAmount2;
//	private String taxMiscFeeType3;
//	private String taxMiscFeeAmount3;
//	private String tktDocAmount;
//	private String filler;
//	private String currencyType;
//	private String taxCode;
//	private String firstTax;
//	private String secondTax;

}