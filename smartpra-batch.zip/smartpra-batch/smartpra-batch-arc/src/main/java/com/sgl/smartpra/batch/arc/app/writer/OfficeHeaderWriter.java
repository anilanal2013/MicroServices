package com.sgl.smartpra.batch.arc.app.writer;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.OfficeHeaderStgRepository;

public class OfficeHeaderWriter extends ARCBaseItemWriter {
	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private OfficeHeaderStgRepository officeHeaderStgRepository;

	@Override
	public void write(List<? extends BSPStagingDomainObject> items) throws Exception {
		// we can't process this record in bulk
		if (items != null && items.size() > 0) {
			OfficeHeaderStg officeHeaderStg = (OfficeHeaderStg) items.get(0);
			officeHeaderStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			officeHeaderStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			officeHeaderStg.setBillingCycleId(stepExecution.getExecutionContext().getInt("billingCycleId"));
			super.setCreateAuditValues(officeHeaderStg);
			officeHeaderStg = officeHeaderStgRepository.save(officeHeaderStg);

			// store office header id for other records
			stepExecution.getExecutionContext().putInt("officeHeaderId", officeHeaderStg.getOfficeHdrId());
		}
	}
}
