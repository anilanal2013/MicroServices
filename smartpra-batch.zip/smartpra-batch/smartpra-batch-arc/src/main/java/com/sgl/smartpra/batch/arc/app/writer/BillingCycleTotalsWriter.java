package com.sgl.smartpra.batch.arc.app.writer;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleTotalsStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.BillingCycleTotalsStgRepository;

public class BillingCycleTotalsWriter extends ARCBaseItemWriter {
	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private BillingCycleTotalsStgRepository billingCycleTotalsStgRepository;

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends BSPStagingDomainObject> items) throws Exception {
		items.forEach(item -> {

			((BillingCycleTotalsStg) item)
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			((BillingCycleTotalsStg) item)
					.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			super.setCreateAuditValues(item);

		});

		billingCycleTotalsStgRepository.saveAll((Iterable<BillingCycleTotalsStg>) items);
	}

}
