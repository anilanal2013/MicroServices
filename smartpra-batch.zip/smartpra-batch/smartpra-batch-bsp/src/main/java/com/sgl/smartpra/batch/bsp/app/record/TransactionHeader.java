package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class TransactionHeader extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.TRANSACTION_HEADER;
	}

	// Layout of BSP Transaction Header Record
	class TransactionHeaderLayout extends FixedLengthRecordLayout {
		public TransactionHeaderLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netReportingIndicator", 20, 21));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transRecordCounter", 22, 24));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktAirlineCodeNumber", 25, 27));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commAgreementRef", 28, 37));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("customerFileRef", 38, 64));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reportingSystemIdentifier", 65, 68));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthCode", 69, 82));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dataInputStatusIndicator", 83, 83));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netReportingMethodIndicator", 84, 84));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netReportingCalculationType", 85, 85));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("autoRepricingEngIndicator", 86, 86));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler4", 87, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		TransactionHeaderLayout transactionHeaderLayout = new TransactionHeaderLayout();
		tokenizer.setColumns(transactionHeaderLayout.getColumns());
		tokenizer.setNames(transactionHeaderLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String transactionNumber;
	private String netReportingIndicator;
	private String transRecordCounter;
	private String tktAirlineCodeNumber;
	private String commAgreementRef;
	private String customerFileRef;
	private String reportingSystemIdentifier;
	private String settlementAuthCode;
	private String dataInputStatusIndicator;
	private String netReportingMethodIndicator;
	private String netReportingCalculationType;
	private String autoRepricingEngIndicator;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getNetReportingIndicator() {
		return netReportingIndicator;
	}

	public void setNetReportingIndicator(String netReportingIndicator) {
		this.netReportingIndicator = netReportingIndicator;
	}

	public String getTransRecordCounter() {
		return transRecordCounter;
	}

	public void setTransRecordCounter(String transRecordCounter) {
		this.transRecordCounter = transRecordCounter;
	}

	public String getTktAirlineCodeNumber() {
		return tktAirlineCodeNumber;
	}

	public void setTktAirlineCodeNumber(String tktAirlineCodeNumber) {
		this.tktAirlineCodeNumber = tktAirlineCodeNumber;
	}

	public String getCommAgreementRef() {
		return commAgreementRef;
	}

	public void setCommAgreementRef(String commAgreementRef) {
		this.commAgreementRef = commAgreementRef;
	}

	public String getCustomerFileRef() {
		return customerFileRef;
	}

	public void setCustomerFileRef(String customerFileRef) {
		this.customerFileRef = customerFileRef;
	}

	public String getReportingSystemIdentifier() {
		return reportingSystemIdentifier;
	}

	public void setReportingSystemIdentifier(String reportingSystemIdentifier) {
		this.reportingSystemIdentifier = reportingSystemIdentifier;
	}

	public String getSettlementAuthCode() {
		return settlementAuthCode;
	}

	public void setSettlementAuthCode(String settlementAuthCode) {
		this.settlementAuthCode = settlementAuthCode;
	}

	public String getDataInputStatusIndicator() {
		return dataInputStatusIndicator;
	}

	public void setDataInputStatusIndicator(String dataInputStatusIndicator) {
		this.dataInputStatusIndicator = dataInputStatusIndicator;
	}

	public String getNetReportingMethodIndicator() {
		return netReportingMethodIndicator;
	}

	public void setNetReportingMethodIndicator(String netReportingMethodIndicator) {
		this.netReportingMethodIndicator = netReportingMethodIndicator;
	}

	public String getNetReportingCalculationType() {
		return netReportingCalculationType;
	}

	public void setNetReportingCalculationType(String netReportingCalculationType) {
		this.netReportingCalculationType = netReportingCalculationType;
	}

	public String getAutoRepricingEngIndicator() {
		return autoRepricingEngIndicator;
	}

	public void setAutoRepricingEngIndicator(String autoRepricingEngIndicator) {
		this.autoRepricingEngIndicator = autoRepricingEngIndicator;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}