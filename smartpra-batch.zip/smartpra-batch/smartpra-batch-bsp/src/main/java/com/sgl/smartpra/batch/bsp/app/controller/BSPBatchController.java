package com.sgl.smartpra.batch.bsp.app.controller;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.TicketDocumentIdentificationStgRepository;
import com.sgl.smartpra.batch.bsp.app.service.BSPJobLauncher;

@RestController
public class BSPBatchController {

	@Autowired
	BSPJobLauncher bspJobLauncher;
	
	@Autowired
	TicketDocumentIdentificationStgRepository ticketDocumentIdentificationStgRepository;

	@RequestMapping("/bsp/processFile")
	public String processFile(@RequestParam("inboundFileName") String inboundFileName, @RequestParam("user") String user,
			@RequestParam("clientId") String clientId) throws Exception {
		return bspJobLauncher.launchBSPStagingLoadJob(inboundFileName, user, clientId);
	}

	@RequestMapping("/bsp/moveStagingToProd")
	public String moveStagingToProd(@RequestParam("fileId") Long fileId, @RequestParam("user") String user)
			throws Exception {
		return bspJobLauncher.launchBSPProdLoadJob(fileId, user);
	}
	
	@RequestMapping("/bsp/businessValidations")
	public void executeSalesBusinessValidation(@RequestParam("fileId") Long fileId) {
		
	}
	
	/**
	 * This service API will be used to transfer the failed record from staging to production through exception work flow
	 * @param exceptionMap its contains exception code as key and staging reference id as value
	 * @return exceptionMap its contains exception code as key and validation status as value (either true or false)
	 */
	
	@RequestMapping("/bsp/validateAndTransfer")
	public Map<String, String> validateAndTransferStagToProduction(@RequestParam("exceptionMap") Map<String, String> exceptionMap) {
		if (exceptionMap != null && !exceptionMap.isEmpty()) {
			for (Map.Entry<String, String> entry : exceptionMap.entrySet()) {
				System.out.println(entry.getKey() + ":" + entry.getValue());
				Integer ticketId =  Integer.parseInt(entry.getValue());
				Optional<TicketDocumentIdentificationStg> ticketDocument  = ticketDocumentIdentificationStgRepository.findById(ticketId);
				if(ticketDocument.isPresent()) {
					
				}
			}
		}
		return exceptionMap;

	}

}
