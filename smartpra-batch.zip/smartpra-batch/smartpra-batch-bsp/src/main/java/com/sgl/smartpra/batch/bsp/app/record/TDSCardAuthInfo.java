package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class TDSCardAuthInfo extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.TDS_CARD_AUTH_INFO;
	}

	// Layout of TDS Card Authentication Informatin record
	class TDSCardAuthInfoLayout extends FixedLengthRecordLayout {
		public TDSCardAuthInfoLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fopType", 26, 35));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cardAuthSeqNumber", 36, 37));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("secure3dCardAuthInfo", 38, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		TDSCardAuthInfoLayout tdsCardAuthInfoLayout = new TDSCardAuthInfoLayout();
		tokenizer.setColumns(tdsCardAuthInfoLayout.getColumns());
		tokenizer.setNames(tdsCardAuthInfoLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String fopType;
	private String cardAuthSeqNumber;
	private String secure3dCardAuthInfo;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getFopType() {
		return fopType;
	}

	public void setFopType(String fopType) {
		this.fopType = fopType;
	}

	public String getCardAuthSeqNumber() {
		return cardAuthSeqNumber;
	}

	public void setCardAuthSeqNumber(String cardAuthSeqNumber) {
		this.cardAuthSeqNumber = cardAuthSeqNumber;
	}

	public String getSecure3dCardAuthInfo() {
		return secure3dCardAuthInfo;
	}

	public void setSecure3dCardAuthInfo(String secure3dCardAuthInfo) {
		this.secure3dCardAuthInfo = secure3dCardAuthInfo;
	}
}