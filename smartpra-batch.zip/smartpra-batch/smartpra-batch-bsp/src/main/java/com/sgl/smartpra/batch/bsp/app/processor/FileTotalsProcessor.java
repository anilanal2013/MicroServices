package com.sgl.smartpra.batch.bsp.app.processor;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileTotalsStg;
import com.sgl.smartpra.batch.bsp.app.mapper.BSPRecordMapper;
import com.sgl.smartpra.batch.bsp.app.record.BSPBaseRecord;
import com.sgl.smartpra.batch.bsp.app.record.FileTotals;

public class FileTotalsProcessor extends BSPBaseItemProcessor {

	@Override
	public BSPStagingDomainObject process(BSPBaseRecord bspBaseRecord) throws Exception {

		FileTotalsStg fileTotalsStg = BSPRecordMapper.INSTANCE.mapFileTotalsRecord((FileTotals) bspBaseRecord);
		return fileTotalsStg;
	}
}
