package com.sgl.smartpra.batch.bsp.app.listener;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.ExceptionTxnFeignClient;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bsp.app.enums.ErrorCode;
import com.sgl.smartpra.batch.bsp.app.util.BSPConstants;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

@Component
public class StepErrorLoggingListener implements StepExecutionListener {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	ExceptionTxnFeignClient exceptionTxnFeignClient;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// do nothing.
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		List<Throwable> throwableList = stepExecution.getFailureExceptions();
		if (throwableList.isEmpty()) {
			return ExitStatus.COMPLETED;
		}

		throwableList.forEach(throwable -> {
			handleException(throwable);
		});

		return ExitStatus.FAILED;
	}

	private void handleException(Throwable throwable) {
		if (throwable.getCause() instanceof FlatFileParseException) {
			FlatFileParseException flatFileParseException = (FlatFileParseException) throwable.getCause();

			// Exception framework integration
			String clientId = stepExecution.getJobExecution().getExecutionContext().getString("clientId");
			ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
			exceptionTransactionModel.setClientId(clientId);
			exceptionTransactionModel
					.setFileId(Long.valueOf(stepExecution.getJobExecution().getExecutionContext().getInt("fileId")));
			exceptionTransactionModel.setEnvironment(FileLoggingConstants.STAGING_ENVIRONMENT);
			exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
			exceptionTransactionModel.setExceptionCode(ErrorCode.SALE3001.getValue());
			exceptionTransactionModel.setCreatedBy(stepExecution.getJobParameters().getString("user"));

			List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
			ExceptionParametersValueModel parametersValueModel1 = new ExceptionParametersValueModel();
			parametersValueModel1.setParameterName(BSPConstants.LINE_NUMBER);
			parametersValueModel1.setParameterValue(String.valueOf(flatFileParseException.getLineNumber()));
			parametersValueModelList.add(parametersValueModel1);

			ExceptionParametersValueModel parametersValueModel2 = new ExceptionParametersValueModel();
			parametersValueModel2.setParameterName(BSPConstants.FIELD);
			parametersValueModel2.setParameterValue(flatFileParseException.getInput().substring(0, 23));
			parametersValueModelList.add(parametersValueModel2);

			ExceptionParametersValueModel parametersValueModel3 = new ExceptionParametersValueModel();
			parametersValueModel3.setParameterName(BSPConstants.MESSAGE);
			parametersValueModel3.setParameterValue(flatFileParseException.getMessage().substring(0, 23));
			parametersValueModelList.add(parametersValueModel3);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTxnFeignClient.initExceptionMessage(exceptionTransactionModel);
			return;

		}

	}
}
