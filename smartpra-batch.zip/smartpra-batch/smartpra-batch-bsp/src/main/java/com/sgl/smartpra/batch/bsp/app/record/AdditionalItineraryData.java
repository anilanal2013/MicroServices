package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class AdditionalItineraryData extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.ADDITIONAL_ITINERARY_DATA;
	}

	// Layout of Additional Itinerary Data Record
	class AdditionalItineraryDataLayout extends FixedLengthRecordLayout {
		public AdditionalItineraryDataLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("segmentIdentifier", 41, 41));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originAirportCityCode", 42, 46));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightDepartDate", 47, 53));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightDepartTime", 54, 58));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightDepartTerminal", 59, 63));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("destAirportCityCode", 64, 68));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightArrivalDate", 69, 75));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightArrivalTime", 76, 80));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightArrivalTerminal", 81, 85));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 86, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		AdditionalItineraryDataLayout additionalItineraryDataLayout = new AdditionalItineraryDataLayout();
		tokenizer.setColumns(additionalItineraryDataLayout.getColumns());
		tokenizer.setNames(additionalItineraryDataLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String segmentIdentifier;
	private String originAirportCityCode;
	private String flightDepartDate;
	private String flightDepartTime;
	private String flightDepartTerminal;
	private String destAirportCityCode;
	private String flightArrivalDate;
	private String flightArrivalTime;
	private String flightArrivalTerminal;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getSegmentIdentifier() {
		return segmentIdentifier;
	}

	public void setSegmentIdentifier(String segmentIdentifier) {
		this.segmentIdentifier = segmentIdentifier;
	}

	public String getOriginAirportCityCode() {
		return originAirportCityCode;
	}

	public void setOriginAirportCityCode(String originAirportCityCode) {
		this.originAirportCityCode = originAirportCityCode;
	}

	public String getFlightDepartDate() {
		return flightDepartDate;
	}

	public void setFlightDepartDate(String flightDepartDate) {
		this.flightDepartDate = flightDepartDate;
	}

	public String getFlightDepartTime() {
		return flightDepartTime;
	}

	public void setFlightDepartTime(String flightDepartTime) {
		this.flightDepartTime = flightDepartTime;
	}

	public String getFlightDepartTerminal() {
		return flightDepartTerminal;
	}

	public void setFlightDepartTerminal(String flightDepartTerminal) {
		this.flightDepartTerminal = flightDepartTerminal;
	}

	public String getDestAirportCityCode() {
		return destAirportCityCode;
	}

	public void setDestAirportCityCode(String destAirportCityCode) {
		this.destAirportCityCode = destAirportCityCode;
	}

	public String getFlightArrivalDate() {
		return flightArrivalDate;
	}

	public void setFlightArrivalDate(String flightArrivalDate) {
		this.flightArrivalDate = flightArrivalDate;
	}

	public String getFlightArrivalTime() {
		return flightArrivalTime;
	}

	public void setFlightArrivalTime(String flightArrivalTime) {
		this.flightArrivalTime = flightArrivalTime;
	}

	public String getFlightArrivalTerminal() {
		return flightArrivalTerminal;
	}

	public void setFlightArrivalTerminal(String flightArrivalTerminal) {
		this.flightArrivalTerminal = flightArrivalTerminal;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}
