package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class AddlInfoPassenger extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.ADDITIONAL_INFO_PASSENGER;
	}

	// Layout of Additional Info Passenger Record
	class AddlInfoPassengerLayout extends FixedLengthRecordLayout {
		public AddlInfoPassengerLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("passengerName", 41, 89));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("passengerSpecificData", 90, 118));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfBirth", 119, 125));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("passengerTypeCode", 126, 128));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 129, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		AddlInfoPassengerLayout addlInfoPassengerLayout = new AddlInfoPassengerLayout();
		tokenizer.setColumns(addlInfoPassengerLayout.getColumns());
		tokenizer.setNames(addlInfoPassengerLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String passengerName;
	private String passengerSpecificData;
	private String dateOfBirth;
	private String passengerTypeCode;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getPassengerSpecificData() {
		return passengerSpecificData;
	}

	public void setPassengerSpecificData(String passengerSpecificData) {
		this.passengerSpecificData = passengerSpecificData;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPassengerTypeCode() {
		return passengerTypeCode;
	}

	public void setPassengerTypeCode(String passengerTypeCode) {
		this.passengerTypeCode = passengerTypeCode;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}
