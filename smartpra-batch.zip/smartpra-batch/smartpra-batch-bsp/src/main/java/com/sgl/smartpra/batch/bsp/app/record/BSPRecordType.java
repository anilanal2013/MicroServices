package com.sgl.smartpra.batch.bsp.app.record;

public class BSPRecordType {

	// Header Records
	public static final String FILE_HEADER = "BFH01";
	public static final String BILLING_CYCLE_HEADER = "BCH02";
	public static final String OFFICE_HEADER = "BOH03";

	// Transaction Records
	public static final String TRANSACTION_HEADER = "BKT06";
	public static final String TICKET_DOCUMENT_IDENTIFICATION = "BKS24";
	public static final String STD_DOCUMENT_AMOUNTS = "BKS30";
	public static final String COUPON_TAX_INFO = "BKS31";
	public static final String COMMISSION = "BKS39";
	public static final String TAX_ON_COMMISSION = "BKS42";
	public static final String RELATED_TICKET_DOCUMENT_INFO = "BKS45";
	public static final String QUAL_ISSUE_INFO = "BKS46";
	public static final String NETTING_VALUES = "BKS47";
	public static final String UNTICKETED_POINT_INFO = "BKI61";
	public static final String ADDITIONAL_ITINERARY_DATA = "BKI62";
	public static final String ITINERARY_DATA_SEGMENT = "BKI63";
	public static final String DOCUMENT_AMOUNTS = "BAR64";
	public static final String ADDITIONAL_INFO_PASSENGER = "BAR65";
	public static final String ADDITIONAL_INFO_FORM_OF_PAYMENT = "BAR66";
	public static final String ADDITIONAL_TAX_INFO = "BAR67";
	public static final String EMD_COUPON_DETAIL = "BMD75";
	public static final String EMD_REMARKS = "BMD76";
	public static final String FARE_CALCULATION = "BKF81";
	public static final String ADDITIONAL_CARD_INFO = "BCC82";
	public static final String CARD_AUTH_INFO = "BCC83";
	public static final String TDS_CARD_AUTH_INFO = "BCX83";
	public static final String FORM_OF_PAYMENT = "BKP84";

	// Total Records
	public static final String OFFICE_SUBTOTALS_PER_TRANCODE_CURRTYPE = "BOT93";
	public static final String OFFICE_TOTALS_PER_CURRTYPE = "BOT94";
	public static final String BILLING_CYCLE_TOTALS_PER_CURRTYPE = "BCT95";
	public static final String FILE_TOTALS_PER_CURRTYPE = "BFT99";

	// Transaction record - logical grouping of records that forms a transaction
	public static final String TRANSACTION_RECORD = "BSP_TRAN";
}
