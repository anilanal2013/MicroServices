package com.sgl.smartpra.batch.bsp.app.processor;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileHeaderStg;
import com.sgl.smartpra.batch.bsp.app.mapper.BSPRecordMapper;
import com.sgl.smartpra.batch.bsp.app.record.BSPBaseRecord;
import com.sgl.smartpra.batch.bsp.app.record.FileHeader;

public class FileHeaderProcessor extends BSPBaseItemProcessor {

	@Override
	public BSPStagingDomainObject process(BSPBaseRecord bspBaseRecord) throws Exception {

		FileHeaderStg fileHeaderStg = BSPRecordMapper.INSTANCE.mapFileHeaderRecord((FileHeader) bspBaseRecord);
		return fileHeaderStg;

	}
}
