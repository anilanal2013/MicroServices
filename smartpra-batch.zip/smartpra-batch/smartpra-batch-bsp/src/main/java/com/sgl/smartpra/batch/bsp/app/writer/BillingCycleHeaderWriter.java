package com.sgl.smartpra.batch.bsp.app.writer;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleHeaderStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.BillingCycleHeaderStgRepository;

@Component
@Scope(value = "step")
public class BillingCycleHeaderWriter extends BSPBaseItemWriter {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private BillingCycleHeaderStgRepository billingCycleHeaderStgRepository;

	@Override
	public void write(List<? extends BSPStagingDomainObject> items) throws Exception {
		// there will be only one Billing Cycle Id
		items.forEach(item -> {

			BillingCycleHeaderStg billingCycleHeaderStg = ((BillingCycleHeaderStg) item);

			billingCycleHeaderStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			billingCycleHeaderStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			super.setCreateAuditValues(billingCycleHeaderStg);

			billingCycleHeaderStg = billingCycleHeaderStgRepository.save(billingCycleHeaderStg);

			// store office header id for other records
			stepExecution.getExecutionContext().putInt("billingCycleId", billingCycleHeaderStg.getBillingCycleId());
			stepExecution.getExecutionContext().put("billingAnalysisHeaderCount", items.size());
		});

	}
}
