package com.sgl.smartpra.batch.bsp.app.writer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketModel;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.TicketTax;
import com.sgl.smartpra.sales.repository.ReportedTaxRepository;
import com.sgl.smartpra.sales.repository.TicketAcmAdmRepository;
import com.sgl.smartpra.sales.repository.TicketCommissionRepository;
import com.sgl.smartpra.sales.repository.TicketMainRepository;
import com.sgl.smartpra.sales.repository.TicketOrginRepository;
import com.sgl.smartpra.sales.repository.TicketPaymentDetailRepository;
import com.sgl.smartpra.sales.repository.TicketSaleRepository;
import com.sgl.smartpra.sales.repository.TicketTaxRepository;
import com.sgl.smartpra.sales.domain.TicketAcmAdm;
@Component
@Transactional
public class TicketModelWriter<T extends TicketModel> implements ItemWriter<List<TicketModel>> {

	@Autowired
	private TicketMainRepository ticketMainRepository;

	@Autowired
	private TicketSaleRepository ticketSaleRepository;

	@Autowired
	private TicketPaymentDetailRepository ticketPaymentDetailRepository;

	@Autowired
	private TicketOrginRepository ticketOriginRepository;

	@Autowired
	private TicketAcmAdmRepository ticketAcmAdmRepository;

	@Autowired
	private ReportedTaxRepository reportedTaxRepository;

	@Autowired
	private TicketCommissionRepository ticketCommissionRepository;


	@Autowired
	JdbcTemplate jdbcTemplate;


	@Override
	public void write(List<? extends List<TicketModel>> items) throws Exception {
		items.forEach(item -> {
			item.forEach(ticketModel -> {
				;
				if (ticketModel.getTicketMain() != null) {
					try {
//						Optional<TicketMain> ticketMainLive = ticketMainRepository
//								.findByDocumentUniqueId(ticketModel.getTicketMain().getDocumentUniqueId()); 
//
//					    if (!ticketMainLive.isPresent()) {

						String sql="SELECT document_unique_id from SmartPRASales.ticket_main where document_unique_id = "+"'"+ticketModel.getTicketMain().getDocumentUniqueId()+"'";
						List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);

						if(result.isEmpty()) {

							ticketMainRepository.save(ticketModel.getTicketMain());
						}
					} catch (Exception e) {
						System.out.println("============================================================="+ticketModel.getTicketMain().getDocumentUniqueId());
					}
				}else if(ticketModel.getTicketAcmAdms() != null) {
					ticketAcmAdmRepository.saveAll(ticketModel.getTicketAcmAdms());
				}
				if (ticketModel.getTicketOrginNonTkt() != null && !ticketModel.getTicketOrginNonTkt().isEmpty()) {
					try {
						ticketOriginRepository.saveAll(ticketModel.getTicketOrginNonTkt());
					} catch (Exception e) {
					}
				}
				if(ticketModel.getTicketPaymentDetailNonTkt() != null && !ticketModel.getTicketPaymentDetailNonTkt().isEmpty()) {
					try {
						ticketPaymentDetailRepository.saveAll(ticketModel.getTicketPaymentDetailNonTkt());
					} catch (Exception e) {
					}
				}
				if(ticketModel.getTicketSaleNonTkt() != null && !ticketModel.getTicketSaleNonTkt().isEmpty()) {
					try {
						ticketSaleRepository.saveAll(ticketModel.getTicketSaleNonTkt());
					} catch (Exception e) {
					}
				}
				if (ticketModel.getReportedTaxNonTkt() != null && !ticketModel.getReportedTaxNonTkt().isEmpty()) {
					String documentUniq = null;
					try {
						/*for (TicketTax ticketTax : ticketModel.getTicketTaxNonTkt()) {
							String sql = "select document_unique_id from SmartPRASales.ticket_tax where document_unique_id = '"
									+ ticketTax.getDocumentUniqueId() + "' and tax_code = '" + ticketTax.getTaxCode()
									+ "' and serial_no = " + ticketTax.getSerialNo();
							documentUniq = ticketTax.getDocumentUniqueId();
							if (jdbcTemplate.queryForList(sql).isEmpty()) {
								ticketTaxRepository.save(ticketTax);
							}
						}*/

						reportedTaxRepository.saveAll(ticketModel.getReportedTaxNonTkt());

					} catch (Exception e) {
						System.out.println("Duplicate in Reported tax =========================>"+documentUniq);
					}
				}
				if(ticketModel.getTicketCommisonNonTkt() != null && !ticketModel.getTicketCommisonNonTkt().isEmpty()) {
					try {

						ticketCommissionRepository.saveAll(ticketModel.getTicketCommisonNonTkt());
					} catch (Exception e) {

					}
				}
			});

		});
	}

}

//	public void write(List items) throws Exception {

//	System.out.println("inside writer =================>"+items);	
//		try {
//			/*
//			 * Object al = items; ArrayList list = (ArrayList) al; //
//			 * System.out.println("list>>>>>>>>>>"+list.get(0)); List<TicketModel>
//			 * ticketModels = (List<TicketModel>)list.get(0); TicketModel icketModel =
//			 * ticketModels.get(0);
//			 * 
//			 * System.out.println("=============writer=="+ticketModels.size());
//			 */
//
//			Iterator<List> itemsListIterator = items.iterator();
//			while (itemsListIterator.hasNext()) {
//				ArrayList<TicketModel> ticketModels = (ArrayList) itemsListIterator.next();
//				ticketMainRepository.save(ticketModels.get(0).getTicketMain());
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

//	}

/*
 * @Override public void write(List<? extends TicketModel> items) throws
 * Exception { List<String> traansCodeCheck = Arrays.asList("R", "D", "C"); for
 * (TicketModel ticketModel : items) { List<TicketMain> ticketMainList =
 * ticketModel.getTicketMains(); List<AgentRegister> agentRegisterList =
 * ticketModel.getAgentRegister(); List<TicketOrgin> ticketOriginsList =
 * ticketModel.getTicketOrginNonTkt(); List<TicketSale> ticketSaleList =
 * ticketModel.getTicketSale(); List<TicketPaymentDetail>
 * ticketPaymentDetailsList = ticketModel.getTicketPaymentDetailTkt();
 *
 * agentRegisterList.stream().forEach(agentRegisterObj -> {
 *
 * // Sales Key in Ticket Sale ticketSaleList.stream().forEach(ticketSaleObj ->
 * { int indexValue = ticketSaleList.indexOf(ticketSaleObj);
 * System.out.println("indexValue========1>>"+indexValue); if
 * (traansCodeCheck.contains(ticketSaleObj.getTransactionType())) { if
 * (agentRegisterObj.getAgencyType().substring(1, 2)
 * .contentEquals(ticketSaleObj.getTransactionType())) {
 * ticketSaleObj.setSalesKey(agentRegisterObj.getSalesUniqueKey());
 * ticketSaleList.set(indexValue, ticketSaleObj); } } });
 *
 * // Sales Key in Ticket Origin
 * ticketOriginsList.stream().forEach(ticketOriginObj -> { int indexValue =
 * ticketOriginsList.indexOf(ticketOriginObj);
 * System.out.println("indexValue========2>>"+indexValue);
 * ticketSaleList.stream().forEach(ticketSaleObj -> { // TODO need to rework on
 * filters instead of if loop if
 * (traansCodeCheck.contains(ticketSaleObj.getTransactionType())) { if
 * (agentRegisterObj.getAgencyType().substring(1, 2)
 * .contentEquals(ticketSaleObj.getTransactionType())) {
 * ticketOriginObj.setSalesKey(agentRegisterObj.getSalesUniqueKey());
 * ticketOriginsList.set(indexValue, ticketOriginObj); } } }); });
 *
 * // Sales Key in Ticket Payment
 * ticketPaymentDetailsList.stream().forEach(ticketPaymentDetailsObj -> { int
 * indexValue = ticketPaymentDetailsList.indexOf(ticketPaymentDetailsObj);
 * System.out.println("indexValue========3>>"+indexValue);
 * ticketSaleList.stream().forEach(ticketSaleObj -> { if
 * (traansCodeCheck.contains(ticketSaleObj.getTransactionType())) { if
 * (agentRegisterObj.getAgencyType().substring(1, 2)
 * .contentEquals(ticketSaleObj.getTransactionType())) { ticketPaymentDetailsObj
 * .setSalesKey(String.valueOf(agentRegisterObj.getSalesUniqueKey()));
 * ticketPaymentDetailsList.set(indexValue, ticketPaymentDetailsObj); } } });
 * });
 *
 * });
 *
 * ticketSaleRepository.saveAll(ticketModel.getTicketSale());
 * ticketPaymentDetailRepository.saveAll(ticketModel.getTicketPaymentDetailTkt()
 * ); ticketOriginRepository.saveAll(ticketModel.getTicketOrginTkt());
 *
 * // Based on ticket main
 *
 * ticketMainList.stream().forEach(ticketMainObj -> { List<TicketSale>
 * mainTicketSaleList = ticketMainObj.getTicketSales();
 * List<TicketPaymentDetail> mainTicketPaymentDetailList =
 * ticketMainObj.getTicketPaymentDetails(); List<TicketOrgin>
 * mainTicketOrginList = ticketMainObj.getTicketOrgins();
 * agentRegisterList.stream().forEach(agentRegisterObj -> {
 *
 * if
 * (ticketMainObj.getAgentCode().contentEquals(agentRegisterObj.getAgencyCode())
 * ) {
 *
 * mainTicketSaleList.stream().forEach(mainTicketSaleObj -> { int indexValue =
 * mainTicketSaleList.indexOf(mainTicketSaleObj);
 * System.out.println("indexValue========4>>"+indexValue); if
 * (agentRegisterObj.getAgencyType().substring(1, 2)
 * .contentEquals(mainTicketSaleObj.getTransactionType())) {
 * mainTicketSaleObj.setSalesKey(agentRegisterObj.getSalesUniqueKey()); }
 *
 * mainTicketSaleList.set(indexValue, mainTicketSaleObj);
 * ticketMainObj.setTicketSales(mainTicketSaleList); });
 *
 * //TODO set TicketOrigin in TicketMain
 *
 * if (mainTicketOrginList != null && !mainTicketOrginList.isEmpty()) { for (int
 * l = 0; l < mainTicketOrginList.size(); l++) { TicketOrgin ticketOrgin =
 * (TicketOrgin) mainTicketOrginList.get(l); if (mainTicketSaleList != null &&
 * !mainTicketSaleList.isEmpty()) { for (int l1 = 0; l1 <
 * mainTicketSaleList.size(); l1++) { TicketSale ticketSale = (TicketSale)
 * mainTicketSaleList.get(l1); if (ticketOrgin.getDocumentUniqueId()
 * .contentEquals(ticketSale.getDocumentUniqueId())) { if
 * (agentRegisterObj.getAgencyType().substring(1, 2)
 * .contentEquals(ticketSale.getTransactionType())) {
 * ticketOrgin.setSalesKey(agentRegisterObj.getSalesUniqueKey());
 * mainTicketOrginList.set(l, ticketOrgin);
 * ticketMainObj.setTicketOrgins(mainTicketOrginList); } } } }
 *
 * } }
 *
 * // TODO - Need to rework the above code with lambdas
 *
 * mainTicketOrginList.stream().forEach(mainTicketOriginObj -> {
 * mainTicketSaleList.stream(). forEach(mainTicketSaleObj -> { // TODO need to
 * rework on filters instead of if loop if
 * (mainTicketOriginObj.getDocumentUniqueId().contentEquals(cs)) { if
 * (agentRegisterObj.getAgencyType().substring(1, 2)
 * .contentEquals(mainTicketSaleObj.getTransactionType())) {
 * mainTicketOriginObj.setSalesKey(agentRegisterObj.getSalesUniqueKey()); //
 * TODO -- with index we need to set in list // ticketOriginsList.set(index,
 * ticketOriginObj); } } }); });
 *
 *
 * if (mainTicketPaymentDetailList != null &&
 * !mainTicketPaymentDetailList.isEmpty()) { for (int l = 0; l <
 * mainTicketPaymentDetailList.size(); l++) { TicketPaymentDetail
 * ticketPaymentDetail = (TicketPaymentDetail) mainTicketPaymentDetailList
 * .get(l); if (mainTicketSaleList != null && !mainTicketSaleList.isEmpty()) {
 * for (int l1 = 0; l1 < mainTicketSaleList.size(); l1++) { TicketSale
 * ticketSale = (TicketSale) mainTicketSaleList.get(l1); if
 * (ticketPaymentDetail.getDocumentUniqueId()
 * .contentEquals(ticketSale.getDocumentUniqueId())) { if
 * (agentRegisterObj.getAgencyType().substring(1, 2)
 * .contentEquals(ticketSale.getTransactionType())) {
 * ticketPaymentDetail.setSalesKey(
 * String.valueOf(agentRegisterObj.getSalesUniqueKey()));
 * mainTicketPaymentDetailList.set(l1, ticketPaymentDetail);
 * ticketMainObj.setTicketPaymentDetails(mainTicketPaymentDetailList); } } } }
 *
 * } }
 *
 *
 * //TODO Need to rework the above code with lambdas
 *
 *
 * mainTicketPaymentDetailList.stream().forEach(mainTicketPaymentDetailObj -> {
 * mainTicketSaleList.stream().forEach(mainTicketSaleObj -> {
 * if(mainTicketPaymentDetailObj.getDocumentUniqueId().equals(mainTicketSaleObj.
 * )) { if (agentRegisterObj.getAgencyType().substring(1, 2)
 * .contentEquals(mainTicketSaleObj.getTransactionType())) {
 * mainTicketPaymentDetailObj
 * .setSalesKey(String.valueOf(agentRegisterObj.getSalesUniqueKey())); } }
 *
 * }); });
 *
 *
 * } }); });
 *
 * if (ticketModel.getTicketMain() != null) {
 * ticketMainRepository.saveAll(ticketModel.getTicketMains()); } }
 *
 * }
 */

//}
