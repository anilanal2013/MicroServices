package com.sgl.smartpra.batch.bsp.app.processor;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.domain.staging.RelatedTicketDocumentInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.util.BSPConstants;
import com.sgl.smartpra.batch.bsp.app.util.BSPUtil;
import com.sgl.smartpra.sales.domain.AgentRegister;
import com.sgl.smartpra.sales.domain.TicketAcmAdm;

@Component
public class ACMADMProcessor {

	public List<TicketAcmAdm> process(String clientId,
			TicketDocumentIdentificationStg ticketDocumentIdentificationStg /* BKS24 */ ,
			TransactionHeaderStg transactionHeaderStg /* BKT06 */, AgentRegister agentRegister, String user,Integer fileId) {

		List<String> acmCheck = Arrays.asList(BSPConstants.TRANSACTION_TYPE_SPC, BSPConstants.TRANSACTION_TYPE_SSAC);
		List<String> admCheck = Arrays.asList(BSPConstants.TRANSACTION_TYPE_RCS, BSPConstants.TRANSACTION_TYPE_SSAD,
				BSPConstants.TRANSACTION_TYPE_TAA, BSPConstants.TRANSACTION_TYPE_SPD);

		

		List<TicketAcmAdm> ticketAcmAdms = new ArrayList<TicketAcmAdm>();
		
		transactionHeaderStg.getRelatedTicketDocumentInfoStg();

		if (transactionHeaderStg.getRelatedTicketDocumentInfoStg() != null
				&& !transactionHeaderStg.getRelatedTicketDocumentInfoStg().isEmpty()) {
			
			
			
			//System.out.println("Inside TicketAcmAdm process==========================1=============>");
			
			for (RelatedTicketDocumentInfoStg relatedTicketDocumentInfoStg : transactionHeaderStg
					.getRelatedTicketDocumentInfoStg()) {
				
				TicketAcmAdm ticketAcmAdm = new TicketAcmAdm();
				//System.out.println("Inside TicketAcmAdm process==========================2=============>");

				ticketAcmAdm.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
				ticketAcmAdm.setAcmAdmNo(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
				ticketAcmAdm.setClientId(clientId);

				if (ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
						.contains(BSPConstants.TRANSACTION_TYPE_ADM)
						|| admCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())) {
					ticketAcmAdm.setTransactionType("D");
				} else if (ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
						.contains(BSPConstants.TRANSACTION_TYPE_ACM)
						|| acmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())) {
					ticketAcmAdm.setTransactionType("C");
				}

				//System.out.println("Inside TicketAcmAdm process==========================3============>");
				ticketAcmAdm.setCreatedBy(user);
				if (ticketAcmAdm.getTransactionType() == null) {
					ticketAcmAdm.setTransactionType("D");
				}
				ticketAcmAdm.setCreatedDate(new Timestamp(new Date().getTime()));
				ticketAcmAdm.setTransactionIndicator("S");

				String dateOfIss = relatedTicketDocumentInfoStg.getDateOfIssue();
				ticketAcmAdm.setSettlemnetDate(BSPUtil.getFormattedDate(dateOfIss, "yyMMdd"));
				ticketAcmAdm.setRelatedIssueAirline(relatedTicketDocumentInfoStg.getTktDocNumber().substring(0, 3));
				ticketAcmAdm.setRelatedTicketNumber(relatedTicketDocumentInfoStg.getTktDocNumber().substring(3, 13));
				ticketAcmAdm.setReasonForMemoIssCode(relatedTicketDocumentInfoStg.getReasonForMemoIssuanceCode());
				String issReDate = relatedTicketDocumentInfoStg.getDateOfIssueRelatedDocument();
				Date dateOfIssDoc = BSPUtil.getFormattedDate(issReDate, "yyMMdd");
				if(dateOfIssDoc!=null ) {
					if(!issReDate.equals("000000")) {
				ticketAcmAdm.setDateOfIssueRelatedDocs(dateOfIssDoc);
					}
				}
				
				ticketAcmAdm.setTransactionIndicator("S");
				//System.out.println("Inside TicketAcmAdm process==========================4=============>");
				ticketAcmAdm.setAgentRegister(agentRegister);
				ticketAcmAdm.setFileId(fileId);
				
				ticketAcmAdms.add(ticketAcmAdm);
			}

		} else {
			
			TicketAcmAdm ticketAcmAdm = new TicketAcmAdm();
			
			//System.out.println("Inside TicketAcmAdm process==========================5=============>");
			String dateOfIssFromTicketDocIdentification = ticketDocumentIdentificationStg.getDateOfIssue();
			ticketAcmAdm.setSettlemnetDate(BSPUtil.getFormattedDate(dateOfIssFromTicketDocIdentification, "yyMMdd"));
			ticketAcmAdm.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
			ticketAcmAdm.setAcmAdmNo(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
			ticketAcmAdm.setClientId(clientId);
			//System.out.println("Inside TicketAcmAdm process==========================6=============>");
			if (ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
					.contains(BSPConstants.TRANSACTION_TYPE_ADM)
					|| admCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())) {
				ticketAcmAdm.setTransactionType("D");
			} else if (ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
					.contains(BSPConstants.TRANSACTION_TYPE_ACM)
					|| acmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())) {
				ticketAcmAdm.setTransactionType("C");
			}
			//System.out.println("Inside TicketAcmAdm process==========================7=============>");

			ticketAcmAdm.setCreatedBy(user);
			if (ticketAcmAdm.getTransactionType() == null) {
				ticketAcmAdm.setTransactionType("D");
			}
			ticketAcmAdm.setCreatedDate(new Timestamp(new Date().getTime()));
			ticketAcmAdm.setTransactionIndicator("S");
			String dateOfIss = ticketDocumentIdentificationStg.getDateOfIssue();
			ticketAcmAdm.setSettlemnetDate(BSPUtil.getFormattedDate(dateOfIss, "yyMMdd"));
			ticketAcmAdm.setAgentRegister(agentRegister);
			//System.out.println("Inside TicketAcmAdm process==========================8=============>");
			ticketAcmAdm.setFileId(fileId);
			ticketAcmAdms.add(ticketAcmAdm);

		}
		return ticketAcmAdms;
	}

}
