package com.sgl.smartpra.batch.bsp.app.processor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AdditionalCardInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoFormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CardAuthInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.StdDocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TDSCardAuthInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.util.BSPConstants;
import com.sgl.smartpra.batch.bsp.app.util.BSPUtil;
import com.sgl.smartpra.batch.global.SalesFileHeader;
import com.sgl.smartpra.master.model.FOP;
import com.sgl.smartpra.master.model.FOPMapping;
import com.sgl.smartpra.sales.domain.TicketPaymentDetail;
import com.sgl.smartpra.sales.repository.TicketPaymentDetailRepository;

@Component
public class TicketPaymentProcessor {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	TicketPaymentDetailRepository paymentDetailRepository;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	List<String> traansCodeCheck = Arrays.asList("ADM", "ACM", "RCS", "SPD", "SSA", "TAA", "RFN");

	List<String> formOfPayment = Arrays.asList("GF", "CO", "DI", "TX","RG","AG");

	List<String> acmCheck = Arrays.asList(BSPConstants.TRANSACTION_TYPE_SPC, BSPConstants.TRANSACTION_TYPE_SSAC,BSPConstants.TRANSACTION_TYPE_RCS);
	List<String> admCheck = Arrays.asList(BSPConstants.TRANSACTION_TYPE_SSAD,
			BSPConstants.TRANSACTION_TYPE_TAA, BSPConstants.TRANSACTION_TYPE_SPD);
	List<String> saleTransactionCodeCheck = Arrays.asList(BSPConstants.TRANSACTION_TYPE_TKT,BSPConstants.TRANSACTION_TYPE_EMD,BSPConstants.TRANSACTION_TYPE_MDNN,
			BSPConstants.TRANSACTION_TYPE_MPNN,BSPConstants.TRANSACTION_TYPE_MCOM,BSPConstants.TRANSACTION_TYPE_PTAM,BSPConstants.TRANSACTION_TYPE_TORM);

	public Map<String, List<TicketPaymentDetail>> process(String user,
			TicketDocumentIdentificationStg ticketDocumentIdentificationStg, TransactionHeaderStg transactionHeaderStg,
			Map<String, String> ticketDoc, int decimalPrecision, Integer salesKey,
			Map<String, String> ticketPaymentGMap, boolean ticketRefundData, Integer fileId) {
		Map<String, List<TicketPaymentDetail>> ticketPaymentDetailMap = new HashMap<>();
		List<TicketPaymentDetail> ticketPaymentTicket = new ArrayList<>();
		List<TicketPaymentDetail> ticketPaymentNonTicket = new ArrayList<>();
		Optional<String> stationCode = null;
		Optional<String> effectiveFromDate = null;
		Optional<String> effectiveToDate = null;
		Optional<String> source = null;
		BigDecimal taxAmountBKS = new BigDecimal(0);
		BigDecimal taxAmountBKS1 = new BigDecimal(0);
		BigDecimal taxAmountBKS2 = new BigDecimal(0);
		BigDecimal cpAmountBKSTotal = new BigDecimal(0);
		BigDecimal cpAmountBKS = new BigDecimal(0);
		BigDecimal cpAmountBKS1 = new BigDecimal(0);
		BigDecimal cpAmountBKS2 = new BigDecimal(0);
		BigDecimal caAmount = new BigDecimal(0);
		BigDecimal txTotal = new BigDecimal(0);
		BigDecimal cpTotal = new BigDecimal(0);
		BigDecimal otherAmountBKSTotal = new BigDecimal(0);
		BigDecimal otherAmountBKS = new BigDecimal(0);
		BigDecimal otherAmountBKS1 = new BigDecimal(0);
		BigDecimal otherAmountBKS2 = new BigDecimal(0);
		Boolean cpFlag = false;
		List<String> bkp84List = Arrays.asList("CA", "CC", "MILES", "LP", "YP","EX");
		String fopIdentifier = null;
		String fopIdentifierForReissue = null;

		// To Calculate the total tax amount
		List<StdDocumentAmountsStg> standaredAmountStg1s = transactionHeaderStg.getStdDocumentAmountsStg();
		List<String> fopTypeList = new ArrayList<String>();
		Map<String, List<String>> fopMap = new HashMap<String, List<String>>();
		if (transactionHeaderStg.getFormOfPaymentStg() != null
				&& !transactionHeaderStg.getFormOfPaymentStg().isEmpty()) {
			int i = 1;
			for (FormOfPaymentStg formOfPaymentStg : transactionHeaderStg.getFormOfPaymentStg()) {
				fopTypeList.add(formOfPaymentStg.getFopType());
				fopMap.put(ticketDoc.get("documentNumber"),fopTypeList);
				TicketPaymentDetail ticketPaymentDetail = new TicketPaymentDetail();
				ticketPaymentDetail.setBilledFlag(BSPConstants.INDICATOR_NO);
				ticketPaymentDetail.setFopSign("P");

				// for adm and acm formOfPaymentType is from DocumentAmountsStg
				if (ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
						.contains(BSPConstants.TRANSACTION_TYPE_ACM)
						|| acmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())) {
					ticketPaymentDetail.setFormOfPaymentType("AC");
				} else if (ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
						.contains(BSPConstants.TRANSACTION_TYPE_ADM)
						|| admCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())) {
					ticketPaymentDetail.setFormOfPaymentType("AD");
				} else {
					ticketPaymentDetail.setFormOfPaymentType(formOfPaymentStg.getFopType().substring(0, 2));
				}
				if(formOfPaymentStg.getFopType().length()>2 ) {
					ticketPaymentDetail.setCcCompanyCode(formOfPaymentStg.getFopType().substring(2, 4));
				}
			//	System.out.println("ticketPaymentDetail.getFormOfPaymentType()=================="+ticketPaymentDetail.getFormOfPaymentType());
				String remAmountValue = formOfPaymentStg.getRemittanceAmount();
				String fopAmountValue = formOfPaymentStg.getFopAmount();

				if (remAmountValue != null && !remAmountValue.isEmpty()) {
					String remittanceAmountSign = BSPUtil.getSignedFieldValue(remAmountValue);
					String remittanceAmountString = BSPUtil.getSignedFieldStringValue(remittanceAmountSign,
							decimalPrecision);
					BigDecimal remittanceAmount = BSPUtil.getvalidatedBigDecimal(remittanceAmountString);
					ticketPaymentDetail.setRemittanceAmount(remittanceAmount);
				}

				if(fopAmountValue !=null && !fopAmountValue.isEmpty()){
					String fopAmountSign = BSPUtil.getSignedFieldValue(fopAmountValue);
					String fopAmountString = BSPUtil.getSignedFieldStringValue(fopAmountSign, decimalPrecision);
					BigDecimal fopAmount =  BSPUtil.getvalidatedBigDecimal(fopAmountString);
					ticketPaymentDetail.setFormOfPaymentAmount(fopAmount);
				}

				if (ticketPaymentDetail.getFormOfPaymentType().contentEquals(BSPConstants.FOP_TYPE_CA)
						&& !formOfPaymentStg.getFopAmount().isEmpty()) {
					System.out.println("getfopamount===>"+formOfPaymentStg.getFopAmount());
					System.out.println("doc no=========>"+ticketDoc.get("documentNumber"));
					String caSign = BSPUtil.getSignedFieldValue(formOfPaymentStg.getFopAmount());
					String caAmountString = BSPUtil.getSignedFieldStringValue(caSign,decimalPrecision);
					caAmount = BSPUtil.getvalidatedBigDecimal(caAmountString);

					if(caAmount.compareTo(BigDecimal.ZERO) == 0){
						System.out.println("ca is negative so assigning remittance amount=========");
						ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getRemittanceAmount());
					}else{
						System.out.println("ca is positive so assigning fop amount==============");
						ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getFormOfPaymentAmount());
					}
				}else if(ticketPaymentDetail.getFormOfPaymentType().contentEquals(BSPConstants.FOP_TYPE_LP)
						&& !formOfPaymentStg.getFopAmount().isEmpty()){
					ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getFormOfPaymentAmount());
				}else if(ticketPaymentDetail.getFormOfPaymentType().contentEquals(BSPConstants.FOP_TYPE_YP)
						&& !formOfPaymentStg.getFopAmount().isEmpty()){
					ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getFormOfPaymentAmount());
				}else if(ticketPaymentDetail.getFormOfPaymentType().contentEquals(BSPConstants.FOP_TYPE_MILES)
						&& !formOfPaymentStg.getFopAmount().isEmpty()){
					ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getFormOfPaymentAmount());
				}else if(ticketPaymentDetail.getFormOfPaymentType().contentEquals(BSPConstants.FOP_TYPE_EXCHANGE)){
					String commissionableAmount = transactionHeaderStg.getStdDocumentAmountsStg().get(0)
							.getCommissionableAmount();
					//System.out.println("exchange ======================="+commissionableAmount);
					ticketPaymentDetail.setFormOfPaymentType("AG");
					if (commissionableAmount != null && !commissionableAmount.isEmpty()) {
						String commissionableAmountSign = BSPUtil.getSignedFieldValue(commissionableAmount);
						String commissionableAmountString = BSPUtil.getSignedFieldStringValue(commissionableAmountSign,
								decimalPrecision);
						BigDecimal commissionableAmountActual = BSPUtil
								.getvalidatedBigDecimal(commissionableAmountString);
						//System.out.println("exchannge commissionableAmountActual===="+commissionableAmountActual);
						ticketPaymentDetail.setFormOfPaymentAmount(commissionableAmountActual);
						ticketPaymentDetail.setBilledFlag("N");
						/*if (commissionableAmountActual.toString().equals("0.00")) {
							ticketPaymentDetail = null;
						}*/
						System.out.println("RG commissionable amount==========="+commissionableAmount.isEmpty());
						if(commissionableAmount.isEmpty()){
							ticketPaymentDetail = null;
						}
						if(ticketPaymentDetail.getFormOfPaymentAmount()!=null){
							if (ticketPaymentDetail.getFormOfPaymentAmount().compareTo(BigDecimal.ZERO) > 0) {
								ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_P);
							} else {
								ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_N);
							}
						}
					}
				//	ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getFormOfPaymentAmount());
				}
				else {
					String fopaValue1 = formOfPaymentStg.getFopAmount();
					if (!fopaValue1.isEmpty() && fopaValue1 != null) {
						String fopAmountSign = BSPUtil.getSignedFieldValue(fopaValue1);
						String fopAmountString = BSPUtil.getSignedFieldStringValue(fopAmountSign, decimalPrecision);
						BigDecimal fopAmount = BSPUtil.getvalidatedBigDecimal(fopAmountString);
						ticketPaymentDetail.setFormOfPaymentAmount(fopAmount);
					}
				}
				
				if (SalesFileHeader.valueOf(ticketDoc.get(BSPConstants.SOURCE)) == SalesFileHeader.ARC) {
					String fopaValue1 = formOfPaymentStg.getFopAmount();
					if (fopaValue1 != null && !fopaValue1.isEmpty()) {
						String fopAmountSign = BSPUtil.getSignedFieldValue(fopaValue1);
						String fopAmountString = BSPUtil.getSignedFieldStringValue(fopAmountSign, decimalPrecision);
						BigDecimal fopAmount = BSPUtil.getvalidatedBigDecimal(fopAmountString);
						ticketPaymentDetail.setFormOfPaymentAmount(fopAmount);
					}
				}
				if(formOfPaymentStg.getFopAccountNumber()!=null){
					ticketPaymentDetail.setFormOfPaymentAccountNumber(formOfPaymentStg.getFopAccountNumber());
				}
				ticketPaymentDetail.setExpiryDate(formOfPaymentStg.getExpiryDate());
				ticketPaymentDetail.setExtendedPaymentCode(formOfPaymentStg.getExtendedPaymentCode());
				ticketPaymentDetail.setApprovalCode(formOfPaymentStg.getApprovalCode());
				ticketPaymentDetail.setInvoiceNumber(formOfPaymentStg.getInvoiceNumber());
				String invoiceDate1 = formOfPaymentStg.getInvoiceDate();
				Date invoiceDateFinal1 = BSPUtil.getFormattedDate(invoiceDate1, "yyMMdd");
				if (invoiceDateFinal1 != null) {
					if (!invoiceDate1.equals("000000")) {
						ticketPaymentDetail.setInvoiceDate(invoiceDateFinal1);
					}
				}
				ticketPaymentDetail.setCardVerificationValueResult(formOfPaymentStg.getCardVerificationValueResult());
				if (SalesFileHeader.valueOf(ticketDoc.get(BSPConstants.SOURCE)) == SalesFileHeader.ARC) {
					ticketPaymentDetail.setFopCurrencyType(ticketDoc.get(BSPConstants.CURRENCY_TYPE));
				} else {
					ticketPaymentDetail.setFopCurrencyType(formOfPaymentStg.getCurrencyType().substring(0, 3));
				}
				ticketPaymentDetail.setMainDocument(ticketDoc.get("mainDocument"));
				ticketPaymentDetail.setDocumentNo(ticketDoc.get("documentNumber"));
				ticketPaymentDetail.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
				ticketPaymentDetail.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
				ticketPaymentDetail.setCreatedBy(user);
				ticketPaymentDetail.setCreatedDate(new Timestamp(new Date().getTime()));
				ticketPaymentDetail.setFileId(fileId);
				ticketPaymentDetail.setFmOfPaymentSequenceNumber(i++);
				if (salesKey != null) {
					ticketPaymentDetail.setSalesKey(salesKey.toString());
				}

				// for adm and acm formOfPaymentAmount is from DocumentAmountsStg
				try {
					if (ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
							.contains(BSPConstants.TRANSACTION_TYPE_ACM)
							|| acmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())
							|| admCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())
							|| ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
									.contains(BSPConstants.TRANSACTION_TYPE_ADM)) {

						String fopaValueOfAdmACm = "";
						if (transactionHeaderStg.getDocumentAmountsStgs() != null
								&& !transactionHeaderStg.getDocumentAmountsStgs().isEmpty()) {
							if (transactionHeaderStg.getDocumentAmountsStgs().get(0) != null) {
								fopaValueOfAdmACm = transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare();
							}
						}
						if (fopaValueOfAdmACm != null && !fopaValueOfAdmACm.isEmpty()) {
							String fopAmountSign = BSPUtil.getSignedFieldValue(fopaValueOfAdmACm);
							String fopAmountString = BSPUtil.getSignedFieldStringValue(fopAmountSign, decimalPrecision);
							BigDecimal fopAmount = BSPUtil.getvalidatedBigDecimal(fopAmountString);
							ticketPaymentDetail.setFormOfPaymentAmount(fopAmount);

						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				List<AdditionalCardInfoStg> additionalCardInfoStg = transactionHeaderStg.getAdditionalCardInfoStgs();

				if (additionalCardInfoStg != null && !additionalCardInfoStg.isEmpty()) {
					ticketPaymentDetail
							.setFmOfPaymentTransIdentifier(additionalCardInfoStg.get(0).getFopTransactionIdentifier());
				}
				List<AddlInfoFormOfPaymentStg> addlInfoFopStgs = transactionHeaderStg.getAddlInfoFormOfPaymentStg();

				if (addlInfoFopStgs != null && !addlInfoFopStgs.isEmpty()) {
					ticketPaymentDetail
							.setFmOfPaymentSequenceNumber(Integer.parseInt(addlInfoFopStgs.get(0).getFopSeqNumber()));
					ticketPaymentDetail.setFmOfPaymentInformation(addlInfoFopStgs.get(0).getFopInformation());
				}
				List<CardAuthInfoStg> cardAuthInformationStgs = transactionHeaderStg.getCardAuthInfoStg();
				if (cardAuthInformationStgs != null && !cardAuthInformationStgs.isEmpty()) {
					ticketPaymentDetail.setCardAuthenticationSeqNo(
							Integer.parseInt(cardAuthInformationStgs.get(0).getCardAuthSeqNumber()));
					ticketPaymentDetail
							.setCardAuthenticationInfo(cardAuthInformationStgs.get(0).getCardAuthInformation());
				}
				List<TDSCardAuthInfoStg> card3dAuthInfoStgs = transactionHeaderStg.gettDSCardAuthInfoStg();
				if (card3dAuthInfoStgs != null && !card3dAuthInfoStgs.isEmpty()) {
					ticketPaymentDetail.set_dSecureCardAuthInfo(card3dAuthInfoStgs.get(0).getSecure3dCardAuthInfo());
				}

				// SALE1405_FopMapping
				// Start Transfer taxes from BKS30/31

				if (formOfPaymentStg.getFopType() != null && !formOfPaymentStg.getFopType().isEmpty()) {
					List<FOPMapping> fopMapping = smartpraMasterAppClient.search(stationCode, effectiveFromDate,
							effectiveToDate, source, Optional.of(formOfPaymentStg.getFopType()));
					if (fopMapping != null && !fopMapping.isEmpty() && fopMapping.get(0).getMappedTo() != null
							&& formOfPaymentStg.getFopType().equals(fopMapping.get(0).getMappedTo())) {
						ticketPaymentDetail.setFormOfPaymentType(fopMapping.get(0).getMappedTo().get());
						ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getRemittanceAmount());
						if (SalesFileHeader.valueOf(ticketDoc.get(BSPConstants.SOURCE)) == SalesFileHeader.ARC) {
							ticketPaymentDetail.setFopCurrencyType(ticketDoc.get(BSPConstants.CURRENCY_TYPE));
							ticketPaymentDetail.setFormOfPaymentAmount(ticketPaymentDetail.getFormOfPaymentAmount());
						} else {
							ticketPaymentDetail.setFopCurrencyType(formOfPaymentStg.getCurrencyType().substring(0, 3));
						}
					}
				} else {
					if (!standaredAmountStg1s.isEmpty()) {
						for (int stdAmount = 0; stdAmount < standaredAmountStg1s.size(); stdAmount++) {
							if ((!standaredAmountStg1s.isEmpty()
									&& ticketPaymentDetail.getDocumentNo() == standaredAmountStg1s.get(i)
											.getTktDocNumber().substring(3, 13))) {
								String taxAmtBKS = standaredAmountStg1s.get(i).getTaxMiscFeeAmount1();
								if (taxAmtBKS != null && !taxAmtBKS.isEmpty()) {
									String taxAmountBKSSign = BSPUtil.getSignedFieldValue(taxAmtBKS);
									String taxAmountBKSString = BSPUtil.getSignedFieldStringValue(taxAmountBKSSign,
											decimalPrecision);
									taxAmountBKS = BSPUtil.getvalidatedBigDecimal(taxAmountBKSString);
								}
								txTotal.add(taxAmountBKS);
								ticketPaymentDetail.setFormOfPaymentAmount(txTotal);
								ticketPaymentDetail.setFormOfPaymentType("TX");
//								System.out.println("assigning currency code for tax===="+formOfPaymentStg.getCurrencyType().substring(0, 3));
								if (SalesFileHeader.valueOf(ticketDoc.get(BSPConstants.SOURCE)) == SalesFileHeader.ARC) {
									ticketPaymentDetail.setFopCurrencyType(ticketDoc.get(BSPConstants.CURRENCY_TYPE));
								} else {
									ticketPaymentDetail.setFopCurrencyType(formOfPaymentStg.getCurrencyType().substring(0, 3));	
								}
							}
						}
					}

				}
				// End Transfer taxes from BKS30/31
				
				if (ticketPaymentDetail != null) {
					if (ticketPaymentDetail.getFormOfPaymentAmount() != null) {
						if (ticketPaymentDetail.getFormOfPaymentAmount().compareTo(BigDecimal.ZERO) > 0) {
							ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_P);
						} else {
							ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_N);
						}
					}
					ticketPaymentDetail.setFormOfPaymentAccountNumber(formOfPaymentStg.getFopAccountNumber());
					ticketPaymentDetail.setExpiryDate(formOfPaymentStg.getExpiryDate());
					ticketPaymentDetail.setExtendedPaymentCode(formOfPaymentStg.getExtendedPaymentCode());
					ticketPaymentDetail.setApprovalCode(formOfPaymentStg.getApprovalCode());
					ticketPaymentDetail.setInvoiceNumber(formOfPaymentStg.getInvoiceNumber());
					String invoiceDate = formOfPaymentStg.getInvoiceDate();
					Date invoiceDateFinal = BSPUtil.getFormattedDate(invoiceDate, "yyMMdd");
					if (invoiceDateFinal != null) {
						if (!invoiceDate.equals("000000")) {
							ticketPaymentDetail.setInvoiceDate(invoiceDateFinal);
						}
					}
					ticketPaymentDetail
							.setCardVerificationValueResult(formOfPaymentStg.getCardVerificationValueResult());
					if (SalesFileHeader.valueOf(ticketDoc.get(BSPConstants.SOURCE)) == SalesFileHeader.ARC) {
						ticketPaymentDetail.setFopCurrencyType(ticketDoc.get(BSPConstants.CURRENCY_TYPE));
					} else {
						ticketPaymentDetail.setFopCurrencyType(formOfPaymentStg.getCurrencyType().substring(0, 3));
					}
					ticketPaymentTicket = duplicateCheck(ticketPaymentTicket, ticketDocumentIdentificationStg,
							ticketPaymentDetail, ticketPaymentGMap, ticketDoc);
				}else {
				}
				// ticketPaymentTicket.add(ticketPaymentDetail);
			}
			fopIdentifier = "B";
			List<FOP> bks30ListValue = getFopCode(fopIdentifier, "S");
			List<String> bksFopCodeList = bks30ListValue.stream().map(FOP::getFopCode).map(Optional::get).collect(Collectors.toList());
			// Reissue
			List<FOP> bks30ListForReissue = getFopCode(fopIdentifier,"E");
			List<String> bksFopCodeReissueList = bks30ListForReissue.stream().map(FOP::getFopCode).map(Optional::get).collect(Collectors.toList());
			//Refund
			List<FOP> bks30ListForRefund = getFopCode(fopIdentifier,"R");
			List<String> bksFopCodeRefundList = bks30ListForRefund.stream().map(FOP::getFopCode).map(Optional::get).collect(Collectors.toList());
			//CP
			List<FOP> bks30CPListValue = new ArrayList<FOP>();
			List<FOP> otherFeeListValue = new ArrayList<FOP>();
			List<String> formOfPayList = fopMap.get(ticketDoc.get("documentNumber"));
			if(formOfPayList.contains("EX") && ticketDocumentIdentificationStg.getTransactionCode().equals("TKTT")){
				System.out.println("exchange fop=====================");
				otherFeeListValue = getFopCode("C", "E");
			}else if(ticketDocumentIdentificationStg.getTransactionCode().equals("RFND")){
				System.out.println("rfnd fop===================");
				otherFeeListValue = getFopCode("C", "R");
			}else if(ticketDocumentIdentificationStg.getTransactionCode().equals("TKTT")){
				System.out.println("tktt fop======================");
				otherFeeListValue = getFopCode("C", "S");
			}else{
				System.out.println("default===================");
				otherFeeListValue = getFopCode("C", "R");
			}

			// standard loop to get all other fee component
			if (!standaredAmountStg1s.isEmpty()) {
				List<String> standaredAmountStgList = new ArrayList<String>();
				TicketPaymentDetail ticketPaymentDetail = new TicketPaymentDetail();
				if (!standaredAmountStg1s.isEmpty()) {
				for (int stdAmount = 0; stdAmount < standaredAmountStg1s.size(); stdAmount++) {
						String taxCodeBKS1 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeAmount1();
						String taxCodeBKS2 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeAmount2();
						String taxCodeBKS3 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeAmount3();
						String taxCode1 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeType1();
						String taxCode2 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeType2();
						String taxCode3 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeType3();
						//if(ticketDocumentIdentificationStg.getTransactionCode().equals("RFND")) {
							if (!taxCodeBKS1.isEmpty() && taxCodeBKS1 != null) {
								if (!otherFeeListValue.isEmpty() && otherFeeListValue != null) {
									for (int refundFop = 0; refundFop < otherFeeListValue.size(); refundFop++) {
										if (otherFeeListValue.get(refundFop).getFopCode().get().contains(taxCode1)
												&& otherFeeListValue.get(refundFop).getNegativeFopFlag().get().equals("P")) {
											String otherAmountSign = BSPUtil.getSignedFieldValue(taxCodeBKS1);
											String otherAmountString = BSPUtil.getSignedFieldStringValue(otherAmountSign, decimalPrecision);
											cpAmountBKS = BSPUtil.getvalidatedBigDecimal(otherAmountString);
											cpTotal = cpTotal.add(cpAmountBKS);
											if (taxCode1.isEmpty()) {
												ticketPaymentDetail.setFormOfPaymentType(ticketPaymentDetail.getFormOfPaymentType());
											} else {
												ticketPaymentDetail.setFormOfPaymentType(taxCode1);
											}
										}
									}
								}
							}
							if (!taxCodeBKS2.isEmpty() && taxCodeBKS2 != null) {
								if (!otherFeeListValue.isEmpty() && otherFeeListValue != null) {
									for (int refundFop = 0; refundFop < otherFeeListValue.size(); refundFop++) {
										if (otherFeeListValue.get(refundFop).getFopCode().get().contains(taxCode2)
												&& otherFeeListValue.get(refundFop).getNegativeFopFlag().get().equals("P")) {
											String otherAmountSign = BSPUtil.getSignedFieldValue(taxCodeBKS2);
											String otherAmountString = BSPUtil.getSignedFieldStringValue(otherAmountSign, decimalPrecision);
											cpAmountBKS1 = BSPUtil.getvalidatedBigDecimal(otherAmountString);
											cpTotal = cpTotal.add(cpAmountBKS1);
											if (taxCode2.isEmpty()) {
												ticketPaymentDetail.setFormOfPaymentType(ticketPaymentDetail.getFormOfPaymentType());
											} else {
												ticketPaymentDetail.setFormOfPaymentType(taxCode2);
											}
										}
									}
								}
							}
							if (taxCodeBKS3 != null && !taxCodeBKS3.isEmpty()) {
								if(!otherFeeListValue.isEmpty() && otherFeeListValue != null) {
									for (int refundFop = 0; refundFop < otherFeeListValue.size(); refundFop++) {
								if (otherFeeListValue.get(refundFop).getFopCode().get().contains(taxCode3)
										&& otherFeeListValue.get(refundFop).getNegativeFopFlag().get().equals("P")) {
									String otherAmountSign = BSPUtil.getSignedFieldValue(taxCodeBKS3);
									String otherAmountString = BSPUtil.getSignedFieldStringValue(otherAmountSign, decimalPrecision);
									cpAmountBKS2 = BSPUtil.getvalidatedBigDecimal(otherAmountString);
									cpTotal = cpTotal.add(cpAmountBKS2);
									if (taxCode3.isEmpty()) {
										ticketPaymentDetail.setFormOfPaymentType(ticketPaymentDetail.getFormOfPaymentType());
									} else {
										ticketPaymentDetail.setFormOfPaymentType(taxCode3);
									}
								}
									}
								}
							}
							ticketPaymentDetail.setFormOfPaymentAmount(cpTotal);
						//}
					}
				}

				if (ticketPaymentDetail != null) {
					ticketPaymentDetail.setBilledFlag(BSPConstants.INDICATOR_NO);
					ticketPaymentDetail.setMainDocument(ticketDoc.get("mainDocument"));
					ticketPaymentDetail.setDocumentNo(ticketDoc.get("documentNumber"));
					ticketPaymentDetail
							.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
					ticketPaymentDetail.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
					ticketPaymentDetail.setCreatedBy(user);
					ticketPaymentDetail.setCreatedDate(new Timestamp(new Date().getTime()));
					ticketPaymentDetail.setFileId(fileId);
					ticketPaymentDetail.setFmOfPaymentSequenceNumber(i++);
					if (salesKey != null) {
						ticketPaymentDetail.setSalesKey(salesKey.toString());
					}
					ticketPaymentTicket = duplicateCheck(ticketPaymentTicket, ticketDocumentIdentificationStg,
							ticketPaymentDetail, ticketPaymentGMap, ticketDoc);
				}
			}


			for (String objFormOfPayment : formOfPayment) {
				TicketPaymentDetail ticketPaymentDetail = new TicketPaymentDetail();
				ticketPaymentDetail.setFormOfPaymentType(objFormOfPayment);
				String commissionableAmount = transactionHeaderStg.getStdDocumentAmountsStg().get(0)
						.getCommissionableAmount();

				if (ticketDocumentIdentificationStg.getTransactionCode()!=null &&
						ticketDocumentIdentificationStg.getTransactionCode().equals("TKTT") &&
						objFormOfPayment.contentEquals(BSPConstants.FOP_TYPE_GF) && bksFopCodeList.contains(BSPConstants.FOP_TYPE_GF) && !fopTypeList.contains("EX")) {
					//System.out.println("TKTT GF=========");
					ticketPaymentDetail.setFormOfPaymentType("GF");
					if (commissionableAmount != null && !commissionableAmount.isEmpty()) {
						String commissionableAmountSign = BSPUtil.getSignedFieldValue(commissionableAmount);
						String commissionableAmountString = BSPUtil.getSignedFieldStringValue(commissionableAmountSign,
								decimalPrecision);
						BigDecimal commissionableAmountActual = BSPUtil
								.getvalidatedBigDecimal(commissionableAmountString);
						ticketPaymentDetail.setFormOfPaymentAmount(commissionableAmountActual);
						ticketPaymentDetail.setBilledFlag("N");
						/*if (commissionableAmountActual.toString().equals("0.00")) {
							ticketPaymentDetail = null;
						}*/
						if(commissionableAmount.isEmpty()){
							ticketPaymentDetail = null;
						}

						if(ticketPaymentDetail.getFormOfPaymentAmount()!=null){
							if (ticketPaymentDetail.getFormOfPaymentAmount().compareTo(BigDecimal.ZERO) > 0) {
								ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_P);
							} else {
								ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_N);
							}
						}
					}
				}else if(ticketDocumentIdentificationStg.getTransactionCode()!=null &&
						ticketDocumentIdentificationStg.getTransactionCode().equals("RFND") &&
						objFormOfPayment.contentEquals(BSPConstants.FOP_TYPE_RG) && bksFopCodeRefundList.contains(BSPConstants.FOP_TYPE_RG)){
					//Refund
					ticketPaymentDetail.setFormOfPaymentType("RG");
					if (commissionableAmount != null && !commissionableAmount.isEmpty()) {
						String commissionableAmountSign = BSPUtil.getSignedFieldValue(commissionableAmount);
						String commissionableAmountString = BSPUtil.getSignedFieldStringValue(commissionableAmountSign,
								decimalPrecision);
						BigDecimal commissionableAmountActual = BSPUtil
								.getvalidatedBigDecimal(commissionableAmountString);
						ticketPaymentDetail.setFormOfPaymentAmount(commissionableAmountActual);
						ticketPaymentDetail.setBilledFlag("N");
						if (commissionableAmountActual.toString().equals("0.00")) {
							ticketPaymentDetail = null;
						}
					}
					if(ticketPaymentDetail!=null)
					{
					if(ticketPaymentDetail.getFormOfPaymentAmount()!=null){
						if (ticketPaymentDetail.getFormOfPaymentAmount().compareTo(BigDecimal.ZERO) > 0) {
							ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_P);
						} else {
							ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_N);
						}
					}
				}
				}
				else if (objFormOfPayment.contentEquals(BSPConstants.FOP_TYPE_DI) && bksFopCodeList.contains(BSPConstants.FOP_TYPE_DI)) {
					ticketPaymentDetail.setFormOfPaymentAmount(new BigDecimal(0));
					ticketPaymentDetail.setBilledFlag("N");

					if (new BigDecimal(0).toString().equals("0")) {
						ticketPaymentDetail = null;
					}
				}else if (objFormOfPayment.contentEquals(BSPConstants.FOP_TYPE_CO)) {
					String fopAmount39 = transactionHeaderStg.getCommissionStg().get(0).getCommissionAmount();
					if (fopAmount39 != null && !fopAmount39.isEmpty()) {
						String fopAmount39Sign = BSPUtil.getSignedFieldValue(fopAmount39);
						String fopAmount39String = BSPUtil.getSignedFieldStringValue(fopAmount39Sign, decimalPrecision);
						BigDecimal fopAmount39Actual = BSPUtil.getvalidatedBigDecimal(fopAmount39String);
						ticketPaymentDetail.setFormOfPaymentAmount(fopAmount39Actual);
						ticketPaymentDetail.setBilledFlag("N");
						if(ticketPaymentDetail.getFormOfPaymentAmount()!=null){
							if (ticketPaymentDetail.getFormOfPaymentAmount().compareTo(BigDecimal.ZERO) > 0) {
								ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_P);
							} else {
								ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_N);
							}
						}
						if (SalesFileHeader.valueOf(ticketDoc.get(BSPConstants.SOURCE)) == SalesFileHeader.ARC) { 
							ticketPaymentDetail.setFopCurrencyType(ticketDoc.get(BSPConstants.CURRENCY_TYPE));
						} else {
							ticketPaymentDetail.setFopCurrencyType(transactionHeaderStg.getCommissionStg().get(0).getCurrencyType().substring(0,3));
						}
						if (fopAmount39Actual.toString().equals("0.00")) {
							ticketPaymentDetail = null;
						}
					}
				} else if (objFormOfPayment.contentEquals(BSPConstants.FOP_TYPE_TX)
						&& bksFopCodeList.contains(BSPConstants.FOP_TYPE_TX)) {
					ticketPaymentDetail.setDocumentNo(ticketDoc.get("documentNumber"));
					if (!standaredAmountStg1s.isEmpty()) {
						for (int stdAmount = 0; stdAmount < standaredAmountStg1s.size(); stdAmount++) {
							if (!standaredAmountStg1s.isEmpty()) {
								String taxAmtBKS = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeAmount1();
								String taxAmtBKS1 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeAmount2();
								String taxAmtBKS2 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeAmount3();
								String taxCodeBKS = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeType1();
								String taxCodeBKS1 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeType2();
								String taxCodeBKS2 = standaredAmountStg1s.get(stdAmount).getTaxMiscFeeType3();
								if (taxAmtBKS != null && !taxAmtBKS.isEmpty()) {
									if(taxCodeBKS.equals(BSPConstants.FOP_TYPE_CP)){
										String cpAmountBKSSign = BSPUtil.getSignedFieldValue(taxAmtBKS);
										String cpAmountBKSString = BSPUtil.getSignedFieldStringValue(cpAmountBKSSign,decimalPrecision);
										cpAmountBKS = BSPUtil.getvalidatedBigDecimal(cpAmountBKSString);
										if(cpAmountBKS.signum()<0 && ticketDocumentIdentificationStg.getTransactionCode()!=null &&
												ticketDocumentIdentificationStg.getTransactionCode().equals("RFND")){
											 bks30CPListValue = getFopCode("R", "R");
										}
									}else {
										String taxAmountBKSSign = BSPUtil.getSignedFieldValue(taxAmtBKS);
										String taxAmountBKSString = BSPUtil.getSignedFieldStringValue(taxAmountBKSSign,
												decimalPrecision);
										taxAmountBKS = BSPUtil.getvalidatedBigDecimal(taxAmountBKSString);
										txTotal = txTotal.add(taxAmountBKS);
									}
									if(bks30CPListValue!=null && !bks30CPListValue.isEmpty() && !(bks30CPListValue.get(0).getNegativeFopFlag().get().equals("N"))){
										txTotal = txTotal.add(cpAmountBKS);
									}else if(bks30CPListValue.isEmpty() && cpAmountBKS.signum()<0){
										txTotal = txTotal.add(cpAmountBKS);
									}else{
										txTotal = txTotal;
									}
								}
								if(taxAmtBKS1 != null && !taxAmtBKS1.isEmpty()){
									if(taxCodeBKS1.equals(BSPConstants.FOP_TYPE_CP)){
										String cpAmountBKSSign1 = BSPUtil.getSignedFieldValue(taxAmtBKS1);
										String cpAmountBKSString1 = BSPUtil.getSignedFieldStringValue(cpAmountBKSSign1,decimalPrecision);
										cpAmountBKS1 = BSPUtil.getvalidatedBigDecimal(cpAmountBKSString1);
										if(cpAmountBKS1.signum()<0 && ticketDocumentIdentificationStg.getTransactionCode()!=null &&
												ticketDocumentIdentificationStg.getTransactionCode().equals("RFND")){
											bks30CPListValue = getFopCode("R", "R");
										}
									}else {
										String taxAmountBKSSign1 = BSPUtil.getSignedFieldValue(taxAmtBKS1);
										String taxAmountBKSString1 = BSPUtil.getSignedFieldStringValue(taxAmountBKSSign1,
												decimalPrecision);
										taxAmountBKS1 = BSPUtil.getvalidatedBigDecimal(taxAmountBKSString1);
										txTotal = txTotal.add(taxAmountBKS1);
									}
									if( bks30CPListValue!=null && !bks30CPListValue.isEmpty() && !(bks30CPListValue.get(0).getNegativeFopFlag().get().equals("N"))){
										txTotal = txTotal.add(cpAmountBKS1);
									}else if(bks30CPListValue.isEmpty() && cpAmountBKS1.signum()<0){
										txTotal = txTotal.add(cpAmountBKS1);
									}else{
										txTotal = txTotal;
									}
								}
								if(taxAmtBKS2 != null && !taxAmtBKS2.isEmpty()){
									if(taxCodeBKS2.equals(BSPConstants.FOP_TYPE_CP)){
										String cpAmountBKSSign2 = BSPUtil.getSignedFieldValue(taxAmtBKS2);
										String cpAmountBKSString2 = BSPUtil.getSignedFieldStringValue(cpAmountBKSSign2,decimalPrecision);
										cpAmountBKS2 = BSPUtil.getvalidatedBigDecimal(cpAmountBKSString2);
										if(cpAmountBKS2.signum()<0 && ticketDocumentIdentificationStg.getTransactionCode()!=null &&
												ticketDocumentIdentificationStg.getTransactionCode().equals("RFND")){
											bks30CPListValue = getFopCode("R", "R");
										}
									}else {
										String taxAmountBKSSign2 = BSPUtil.getSignedFieldValue(taxAmtBKS2);
										String taxAmountBKSString2 = BSPUtil.getSignedFieldStringValue(taxAmountBKSSign2,
												decimalPrecision);
										taxAmountBKS2 = BSPUtil.getvalidatedBigDecimal(taxAmountBKSString2);
										txTotal = txTotal.add(taxAmountBKS2);
									}
									if(bks30CPListValue!=null && !bks30CPListValue.isEmpty() && !(bks30CPListValue.get(0).getNegativeFopFlag().get().equals("N"))){
										txTotal = txTotal.add(cpAmountBKS2);
									}else if(bks30CPListValue.isEmpty() && cpAmountBKS2.signum()<0){
										txTotal = txTotal.add(cpAmountBKS2);
									}else{
										txTotal = txTotal;
									}
								}

                                //txTotal = txTotal.add(taxAmountBKS).add(taxAmountBKS1).add(taxAmountBKS2);
								ticketPaymentDetail.setFormOfPaymentAmount(txTotal);
								ticketPaymentDetail.setFormOfPaymentType("TX");
								if(ticketPaymentDetail.getFormOfPaymentAmount()!=null){
									if (ticketPaymentDetail.getFormOfPaymentAmount().compareTo(BigDecimal.ZERO) > 0) {
										ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_P);
									} else {
										ticketPaymentDetail.setFopSign(BSPConstants.FOP_TYPE_N);
									}
								}
							}
						}
					}
				}else{}


				if (ticketPaymentDetail != null) {
					ticketPaymentDetail.setBilledFlag(BSPConstants.INDICATOR_NO);
					ticketPaymentDetail.setMainDocument(ticketDoc.get("mainDocument"));
					ticketPaymentDetail.setDocumentNo(ticketDoc.get("documentNumber"));
					ticketPaymentDetail
							.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
					ticketPaymentDetail.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
					ticketPaymentDetail.setCreatedBy(user);
					ticketPaymentDetail.setCreatedDate(new Timestamp(new Date().getTime()));
					ticketPaymentDetail.setFileId(fileId);
					ticketPaymentDetail.setFmOfPaymentSequenceNumber(i++);
					if (salesKey != null) {
						ticketPaymentDetail.setSalesKey(salesKey.toString());
					}
					try {
						if (ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
								.contains(BSPConstants.TRANSACTION_TYPE_ACM)
								|| acmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())
								|| admCheck.contains(ticketDocumentIdentificationStg.getTransactionCode())
								|| ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)
										.contains(BSPConstants.TRANSACTION_TYPE_ADM)) {

							String fopaValueOfAdmACm = "";
							if (transactionHeaderStg.getDocumentAmountsStgs() != null
									&& !transactionHeaderStg.getDocumentAmountsStgs().isEmpty()) {
								if (transactionHeaderStg.getDocumentAmountsStgs().get(0) != null) {
									fopaValueOfAdmACm = transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare();
								}
							}
							if (fopaValueOfAdmACm != null && !fopaValueOfAdmACm.isEmpty()) {
								String fopAmountSign = BSPUtil.getSignedFieldValue(fopaValueOfAdmACm);
								String fopAmountString = BSPUtil.getSignedFieldStringValue(fopAmountSign,
										decimalPrecision);
								BigDecimal fopAmount = BSPUtil.getvalidatedBigDecimal(fopAmountString);
								ticketPaymentDetail.setFormOfPaymentAmount(fopAmount);

							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}

					// ticketPaymentTicket.add(ticketPaymentDetail);
					ticketPaymentTicket = duplicateCheck(ticketPaymentTicket, ticketDocumentIdentificationStg,
							ticketPaymentDetail, ticketPaymentGMap, ticketDoc);
				}

			}

			// Duplicate check ends

		}
		ticketPaymentDetailMap.put("ticketPaymentTicket", ticketPaymentTicket);
		ticketPaymentDetailMap.put("ticketPaymentNonTicket", ticketPaymentTicket);
		return ticketPaymentDetailMap;
	}

	private Date getFormattedDate(String date, String givenDateFormat) throws java.text.ParseException {
		if (date != null && !date.isEmpty()) {
			return new SimpleDateFormat(givenDateFormat, Locale.ENGLISH).parse(date);
		} else {
			return null;
		}
	}

	private List<TicketPaymentDetail> duplicateCheck(List<TicketPaymentDetail> ticketPaymentTicket,
			TicketDocumentIdentificationStg ticketDocumentIdentificationStg, TicketPaymentDetail ticketPaymentDetail,
			Map<String, String> ticketPaymentGMap, Map<String, String> ticketDoc) {
		// Duplicate check start
		if (!StringUtils.equalsAnyIgnoreCase(ticketDocumentIdentificationStg.getTransactionCode(),
				BSPConstants.TRANSACTION_TYPE_REFUND)) {
			String sql = "select document_unique_id from SmartPRASales.ticket_payment_details where document_unique_id = '"
					+ ticketPaymentDetail.getDocumentUniqueId() + "' and form_of_payment_type = '"
					+ ticketPaymentDetail.getFormOfPaymentType() + "' and fm_of_payment_sequence_number = "
					+ ticketPaymentDetail.getFmOfPaymentSequenceNumber();
			if (jdbcTemplate.queryForList(sql).isEmpty()) {

				String paymentKey = ticketPaymentDetail.getDocumentUniqueId()
						+ ticketPaymentDetail.getFormOfPaymentType()
						+ ticketPaymentDetail.getFmOfPaymentSequenceNumber();

				if (!ticketPaymentGMap.containsKey(paymentKey)) {
					ticketPaymentTicket.add(ticketPaymentDetail);
					ticketPaymentGMap.put(paymentKey, paymentKey);
				} else {

//					System.out.println("this is duplicate of payment details ======================>"
//							+ ticketPaymentDetail.getDocumentUniqueId());

				}
			}
		} else {
			String documentUniqueIdRefund = ticketDoc.get("documentUniqueIdRefund");
			if (documentUniqueIdRefund != null && !documentUniqueIdRefund.isEmpty()) {

				String sql = "select document_unique_id from SmartPRASales.ticket_payment_details where document_unique_id = '"
						+ documentUniqueIdRefund + "' and form_of_payment_type = '"
						+ ticketPaymentDetail.getFormOfPaymentType() + "' and fm_of_payment_sequence_number = "
						+ ticketPaymentDetail.getFmOfPaymentSequenceNumber();

				if (jdbcTemplate.queryForList(sql).isEmpty()) {

					String paymentKey = documentUniqueIdRefund + ticketPaymentDetail.getFormOfPaymentType()
							+ ticketPaymentDetail.getFmOfPaymentSequenceNumber();

					if (!ticketPaymentGMap.containsKey(paymentKey)) {
						ticketPaymentDetail.setDocumentUniqueId(documentUniqueIdRefund);
						ticketPaymentTicket.add(ticketPaymentDetail);
						ticketPaymentGMap.put(paymentKey, paymentKey);
					} else {
//						System.out.println("this is duplicate of payment details ======================>"
//								+ ticketPaymentDetail.getDocumentUniqueId());
					}
				}
			}
		}
		return ticketPaymentTicket;
	}

	private List<FOP> getFopCode(String fopIdentifier, String transactionType) {
		List<FOP> fopList = new ArrayList<FOP>();
		if (transactionType != null && fopIdentifier != null) {
			fopList = smartpraMasterAppClient.getListOfFOPByTransactionType(fopIdentifier, transactionType);
		}
		return fopList;
	}

	private List<FOP> getFopCode(String fopIdentifier){
	    List<FOP> fopListOfFopIdentifiers = new ArrayList<FOP>();
	    if(fopIdentifier!=null){
            fopListOfFopIdentifiers = smartpraMasterAppClient.getListOfFOPByFopIdentifier(fopIdentifier);
        }
	    return fopListOfFopIdentifiers;
    }

}
