package com.sgl.smartpra.batch.bsp.app.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Years;
import org.springframework.beans.factory.annotation.Autowired;

import com.hazelcast.util.StringUtil;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.CarrierMasterFeignClient;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.model.CurrencyDetail;
import com.sgl.smartpra.master.model.InterfaceReference;
import com.sgl.smartpra.master.model.SystemParameter;

public class BSPUtil {

	@Autowired
	SmartpraMasterAppClient masterAppClient;

	private static HashMap<String, String> signFieldMap = new HashMap<String, String>();

	static {
		signFieldMap.put("A", "1");
		signFieldMap.put("B", "2");
		signFieldMap.put("C", "3");
		signFieldMap.put("D", "4");
		signFieldMap.put("E", "5");
		signFieldMap.put("F", "6");
		signFieldMap.put("G", "7");
		signFieldMap.put("H", "8");
		signFieldMap.put("I", "9");
		signFieldMap.put("{", "0");
		signFieldMap.put("J", "-1");
		signFieldMap.put("K", "-2");
		signFieldMap.put("L", "-3");
		signFieldMap.put("M", "-4");
		signFieldMap.put("N", "-5");
		signFieldMap.put("O", "-6");
		signFieldMap.put("P", "-7");
		signFieldMap.put("Q", "-8");
		signFieldMap.put("R", "-9");
		signFieldMap.put("}", "-0");

	}

	/**
	 * This method will initialize the filelogging object with basic data.
	 * 
	 * @return
	 */
	public static FileLogging initFileLogging(String user) {
		FileLogging fileLogging = new FileLogging();

		fileLogging.setFileCategory(FileLoggingConstants.FILELOGGING_FILECATEGORY_TEXT);
		fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setModuleName(FileLoggingConstants.MODULE_SALES);
		fileLogging.setModuleId(FileLoggingConstants.FILELOGGING_MODULEID_BSP);
		fileLogging.setSource(FileLoggingConstants.FILELOGGING_SOURCE_BSP);
		fileLogging.setCreatedBy(user);
		fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));

		return fileLogging;
	}

	public static String getSignedFieldValue(String inStr) {
		String outStr = inStr;
		String signChar;
		String signKeyValue;

		if (inStr != null && inStr.length() > 1) {
			signChar = inStr.substring(inStr.length() - 1);
			if (signFieldMap.containsKey(signChar)) {
				signKeyValue = signFieldMap.get(signChar);
				if (signKeyValue.length() > 1) {
					outStr = "-" + inStr.substring(0, inStr.length() - 1)
							+ signKeyValue.substring(signKeyValue.length() - 1);
				} else {
					outStr = inStr.substring(0, inStr.length() - 1) + signKeyValue;
				}

			}
		}
		return outStr;
	}

	public static String getSignedFieldStringValue(String actualValue, int decimalPrecision) {
		String convertedValue = getSignedFieldValue(actualValue);
		if (decimalPrecision == 0) {
			return convertedValue;
		}

		StringBuffer temp = new StringBuffer();
		if (convertedValue != null && !convertedValue.isEmpty()) {
			int length = convertedValue.length();
			temp = new StringBuffer(convertedValue);
			temp.insert(length - decimalPrecision, ".");
		}

		return temp.toString();

	}

	// TODO are we using this method?
	public static String getTransactionCode(String inpTransCode) {
		String outTransCode = inpTransCode;
		String transCodeChar;
		String transCodeValue;
		HashMap<String, String> transCodeMap = new HashMap<String, String>();
		transCodeMap.put("CAN", "PV");
		transCodeMap.put("RFN", "PR");
		transCodeMap.put("ACM", "AC");
		transCodeMap.put("ADM", "AD");
		transCodeMap.put("DRF", "PD");
		transCodeMap.put("TKT", "PS");
		transCodeMap.put("EMD", "PS");
		transCodeMap.put("MD", "PS");
		transCodeMap.put("MP", "PS");
		transCodeMap.put("MCO", "PS");
		transCodeMap.put("PTA", "PS");
		transCodeMap.put("TOR", "PS");
		transCodeMap.put("RCS", "AC");
		transCodeMap.put("SPC", "AC");
		transCodeMap.put("SPD", "AD");
//		transCodeMap.put("SSAC", "AC");
//		transCodeMap.put("SSAD", "AD");
		transCodeMap.put("TAA", "AD");

		if (inpTransCode != null) {
			transCodeChar = inpTransCode;
			if (transCodeMap.containsKey(transCodeChar)) {
				transCodeValue = transCodeMap.get(transCodeChar);
				outTransCode = transCodeValue;
			} else if (transCodeMap.containsKey(transCodeChar.substring(0,2))) {
				transCodeValue = transCodeMap.get(transCodeChar.substring(0,2));
				outTransCode = transCodeValue;
			}
		}

		return outTransCode;
	}

	public int getDecimalPrecision(SmartpraMasterAppClient smartpraMasterAppClient, Optional<String> stationCode,
			CarrierMasterFeignClient carrierMasterFeignClient, String decimalUnitValue, String currencyCode,
			Optional<String> effectiveDate, Optional<String> clientId, Optional<String> effectiveDateForIF) {

		int decimalPrecision = 0;
		String decimalReference = null;

		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient
				.getSystemParameterByparameterName(BSPConstants.PAR_DECIMAL_PRECISION);

		if (systemParameterList != null && !systemParameterList.isEmpty()
				&& OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom()) != "0"
				&& (OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom()) != null
						? Integer
								.parseInt(OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom())) > 0
						: false)) {

			decimalPrecision = Integer
					.valueOf(OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom()));
			return decimalPrecision;

		} else if (systemParameterList != null && !systemParameterList.isEmpty() && StringUtil
				.isNullOrEmpty(OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom()))) {
			int decimalRef = 0;
			ArrayList<SystemParameter> systemParameterList11 = (ArrayList<SystemParameter>) smartpraMasterAppClient
					.getSystemParameterByparameterName(BSPConstants.PAR_DECIMAL_REFERENCE);
			{
				if (systemParameterList11 != null && !systemParameterList11.isEmpty()) {
					decimalReference = OptionalUtil.getValue(systemParameterList11.get(0).getParameterRangeFrom());

					if (decimalReference.contentEquals("F")) {
						decimalRef = Integer.parseInt(decimalUnitValue);
					} else if (decimalReference.contentEquals("C")) {
						decimalRef = getCarrierDetailDecPrecision(carrierMasterFeignClient, currencyCode,
								effectiveDate);
					}

				}
			}
			return decimalRef;
		} else if (systemParameterList != null && !systemParameterList.isEmpty()
				&& OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom()).contentEquals("0")) {

			if (getInterfaceReferenceDecPrecision(smartpraMasterAppClient, stationCode, clientId,
					effectiveDateForIF) != 0) {
				decimalPrecision = getInterfaceReferenceDecPrecision(smartpraMasterAppClient, stationCode, clientId,
						effectiveDateForIF);
			} else if (Integer.parseInt(decimalUnitValue) != 0) {
				decimalPrecision = Integer.parseInt(decimalUnitValue);
			} else if (getCarrierDetailDecPrecision(carrierMasterFeignClient, currencyCode, effectiveDate) != 0) {
				decimalPrecision = getCarrierDetailDecPrecision(carrierMasterFeignClient, currencyCode, effectiveDate);
			} else {
				return 0;
			}
		}
		return 0;
	}

	public int getCarrierDetailDecPrecision(CarrierMasterFeignClient carrierMasterFeignClient, String currencyCode,
			Optional<String> effectiveDate) {

		ArrayList<CurrencyDetail> currencyDetailList = (ArrayList<CurrencyDetail>) carrierMasterFeignClient
				.getListOfCurrencyDetails(currencyCode, effectiveDate);
		if (currencyDetailList != null && !currencyDetailList.isEmpty()) {
			int decimalRef = Integer.parseInt(OptionalUtil.getValue(currencyDetailList.get(0).getDecimalUnit()));
			return decimalRef;
		} else {
			return 0;
		}

	}

	public int getInterfaceReferenceDecPrecision(SmartpraMasterAppClient smartpraMasterAppClient,
			Optional<String> stationCode, Optional<String> clientId, Optional<String> effectiveDateForIF) {

		Optional<String> dataSource = Optional.of(FileLoggingConstants.FILELOGGING_SOURCE_BSP);
		int decimalPrecision = 0;

		InterfaceReference interfaceReferenceValue = smartpraMasterAppClient
				.getInterfaceReferenceByDataSourceAndStationCodeWithEffectiveDate(clientId, dataSource, stationCode,
						effectiveDateForIF);

		if (!StringUtil.isNullOrEmpty(interfaceReferenceValue.getDecimalPrecision().get())) {
			decimalPrecision = Integer.parseInt(interfaceReferenceValue.getDecimalPrecision().get());
			return decimalPrecision;
		} else {
			return 0;
		}
	}

	public static final String PARAM_AGE_RANGE_FOR_CHILD = "AGE_RANGE_FOR_CHILD";
	public static final String PARAM_AGE_RANGE_FOR_INFANT = "AGE_RANGE_FOR_INFANT";
	String getBookingStatus = null;
	String getPassengerName = null;
	String getPast = null;
	Date getPassengerDob = null;

	public String derivePAXType(SmartpraMasterAppClient smartpraMasterAppClient, String getPassengerName,
			Date getPassengerDob) {

		String paxType = null;
		String childRegex = "[C|c](\\d{2})";

		if (getPassengerName != null) {

			String passengerName = getPassengerName;

			Pattern pattern = Pattern.compile(childRegex); // the pattern to search for
			Matcher match = pattern.matcher(passengerName);
			Boolean childMatch = match.find();

			if (passengerName.contains("INF") || passengerName.contains("INFANT")) {
				paxType = "I";
			} else if (passengerName.contains("CHD") || passengerName.contains("CNN") || passengerName.contains("MSTR")
					|| passengerName.contains("CHILD") || childMatch) {
				paxType = "C";
			}

		}

		if (paxType == null && getPassengerDob != null) {

			Date paxDOB = getPassengerDob;
			DateTime start = new DateTime(paxDOB);
			DateTime end = new DateTime();

			Years diffinYears = Years.yearsBetween(start, end);
			// TODO : need to update the optimum master call

			// String infantRange = getInfantRange(smartpraMasterAppClient);
			// String childRange = getChildRange(smartpraMasterAppClient);

			String infantRange = "2";
			String childRange = "6";

			if (StringUtils.isNotEmpty(infantRange) && diffinYears.getYears() <= Integer.parseInt(infantRange)) {
				paxType = "I";
			} else if (StringUtils.isNotEmpty(childRange) && diffinYears.getYears() <= Integer.parseInt(childRange)) {
				paxType = "C";
			} else {
				paxType = "A";
			}

		}

		if (paxType == null && getBookingStatus != null && getBookingStatus.contains("NS")) {
			paxType = "I";
		}

		if (paxType == null && getPast != null) {
			String past = getPast;
			if (past.equals("INF")) {
				paxType = "I";
			} else if (past.equals("CHD")) {
				paxType = "C";
			} else if (past.equals("YTH") || past.equals("ADT") || past.equals("STU") || past.equals("SCx")) {
				paxType = "A";
			}

		} else if (paxType == null) {
			paxType = "A";
		}

		// Proration - fare type information refer discount code

		return paxType;
	}

	private String getInfantRange(SmartpraMasterAppClient smartpraMasterAppClient) {
		String infantFromRange = null;
		String infantToRange = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient
				.getSystemParameterByparameterName(PARAM_AGE_RANGE_FOR_INFANT);

		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			// infantFromRange =
			// OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());

		}

		return infantToRange;
	}

	private String getChildRange(SmartpraMasterAppClient smartpraMasterAppClient) {
		String childFromRange = null;
		String childToRange = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient
				.getSystemParameterByparameterName(PARAM_AGE_RANGE_FOR_CHILD);

		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			// childFromRange =
			// OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());

		}

		return childToRange;
	}

	public static String getBspFileVersion(String fileName) {
		BufferedReader bufferedReader = null;
		String firstLine = null;
		try {
			bufferedReader = new BufferedReader(new FileReader(fileName));
			firstLine = bufferedReader.readLine();
		} catch (IOException e) {
			// log.error(e.getMessage());

		}

		return firstLine != null ? firstLine.substring(19, 22) : null;
	}

	public static String getFileSequence(String fileName) {
		BufferedReader bufferedReader = null;
		String firstLine = null;
		try {
			bufferedReader = new BufferedReader(new FileReader(fileName));
			firstLine = bufferedReader.readLine();
		} catch (IOException e) {
			// log.error(e.getMessage());

		}

		return firstLine != null ? firstLine.substring(38, 44) : null;
	}

	public static String getFormattedDate(String date, String givenDateFormat, String requiredDateFormat)
			throws java.text.ParseException {
		return new SimpleDateFormat(requiredDateFormat, Locale.ENGLISH)
				.format(new SimpleDateFormat(givenDateFormat, Locale.ENGLISH).parse(date));
	}

	public static Date getFormattedDate(String date, String givenDateFormat) {
		Date formattedDate = null;
		if (date != null && !date.isEmpty()) {
			try {
				formattedDate = new SimpleDateFormat(givenDateFormat, Locale.ENGLISH).parse(date);
			} catch (ParseException e) {
			}
		}
		return formattedDate;
	}

	public static BigDecimal getvalidatedBigDecimal(String value) {
		try {
			if (value != null && !value.isEmpty()) {
				return new BigDecimal(value);

			} else {
				return new BigDecimal(0);
			}
		} catch (Exception e) {
			return BigDecimal.ZERO;
		}
	}

}