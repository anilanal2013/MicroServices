package com.sgl.smartpra.batch.bsp.app.writer;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.sales.domain.AgentRegister;
import com.sgl.smartpra.sales.repository.AgentRegisterRepository;

public class AgentRegisterWriter implements ItemWriter<AgentRegister> {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private AgentRegisterRepository agentRegisterRepository;

	@Override
	public void write(List<? extends AgentRegister> items) throws Exception {

		items.forEach(item -> {
			item.setCreatedBy(stepExecution.getJobParameters().getString("user"));
			item.setCreatedDate(new Timestamp(new Date().getTime()));
		});

		agentRegisterRepository.saveAll(items);
	}
}
