package com.sgl.smartpra.batch.bsp.app.record;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

public abstract class BSPBaseRecord {

	private String line;

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public abstract LineTokenizer lineTokenizer(String handbookRevisionNumber);

	public abstract FieldSetMapper<BSPBaseRecord> fieldSetMapper();

	public abstract String getRecordType();
}
