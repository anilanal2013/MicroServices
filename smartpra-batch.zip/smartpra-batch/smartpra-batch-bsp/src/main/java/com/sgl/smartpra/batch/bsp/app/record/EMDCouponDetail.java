package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class EMDCouponDetail extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.EMD_COUPON_DETAIL;
	}

	// Layout of EMD Coupon Detail Record
	public class EMDCouponDetailLayout extends FixedLengthRecordLayout {
		public EMDCouponDetailLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdCpnNumber", 41, 41));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdCpnValue", 42, 52));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdTktDocNumber", 53, 66));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdRelatedCpnNumber", 67, 67));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdServiceType", 68, 68));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdReasonIssuanceSubcode", 69, 71));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdFeeOwnerAirlineDesigt", 72, 74));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdEbdOverAllowQualifier", 75, 75));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdExcessBaggageCurrCode", 76, 78));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdEbtRatePerUnit", 79, 90));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdEbtTotalNoExcess", 91, 102));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdEbtConsumedIssueInd", 103, 103));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdNoOfServices", 104, 106));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdOperatingCarrier", 107, 109));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdAttributeGroup", 110, 112));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdAttributeSubgroup", 113, 115));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdIndustryCarrierIndicator", 116, 116));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 117, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 133, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		EMDCouponDetailLayout emdCouponDetailLayout = new EMDCouponDetailLayout();
		tokenizer.setColumns(emdCouponDetailLayout.getColumns());
		tokenizer.setNames(emdCouponDetailLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String emdCpnNumber;
	private String emdCpnValue;
	private String emdTktDocNumber;
	private String emdRelatedCpnNumber;
	private String emdServiceType;
	private String emdReasonIssuanceSubcode;
	private String emdFeeOwnerAirlineDesigt;
	private String emdEbdOverAllowQualifier;
	private String emdExcessBaggageCurrCode;
	private String emdEbtRatePerUnit;
	private String emdEbtTotalNoExcess;
	private String emdEbtConsumedIssueInd;
	private String emdNoOfServices;
	private String emdOperatingCarrier;
	private String emdAttributeGroup;
	private String emdAttributeSubgroup;
	private String emdIndustryCarrierIndicator;
	private String filler;
	private String currencyType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getEmdCpnNumber() {
		return emdCpnNumber;
	}

	public void setEmdCpnNumber(String emdCpnNumber) {
		this.emdCpnNumber = emdCpnNumber;
	}

	public String getEmdCpnValue() {
		return emdCpnValue;
	}

	public void setEmdCpnValue(String emdCpnValue) {
		this.emdCpnValue = emdCpnValue;
	}

	public String getEmdTktDocNumber() {
		return emdTktDocNumber;
	}

	public void setEmdTktDocNumber(String emdTktDocNumber) {
		this.emdTktDocNumber = emdTktDocNumber;
	}

	public String getEmdRelatedCpnNumber() {
		return emdRelatedCpnNumber;
	}

	public void setEmdRelatedCpnNumber(String emdRelatedCpnNumber) {
		this.emdRelatedCpnNumber = emdRelatedCpnNumber;
	}

	public String getEmdServiceType() {
		return emdServiceType;
	}

	public void setEmdServiceType(String emdServiceType) {
		this.emdServiceType = emdServiceType;
	}

	public String getEmdReasonIssuanceSubcode() {
		return emdReasonIssuanceSubcode;
	}

	public void setEmdReasonIssuanceSubcode(String emdReasonIssuanceSubcode) {
		this.emdReasonIssuanceSubcode = emdReasonIssuanceSubcode;
	}

	public String getEmdFeeOwnerAirlineDesigt() {
		return emdFeeOwnerAirlineDesigt;
	}

	public void setEmdFeeOwnerAirlineDesigt(String emdFeeOwnerAirlineDesigt) {
		this.emdFeeOwnerAirlineDesigt = emdFeeOwnerAirlineDesigt;
	}

	public String getEmdEbdOverAllowQualifier() {
		return emdEbdOverAllowQualifier;
	}

	public void setEmdEbdOverAllowQualifier(String emdEbdOverAllowQualifier) {
		this.emdEbdOverAllowQualifier = emdEbdOverAllowQualifier;
	}

	public String getEmdExcessBaggageCurrCode() {
		return emdExcessBaggageCurrCode;
	}

	public void setEmdExcessBaggageCurrCode(String emdExcessBaggageCurrCode) {
		this.emdExcessBaggageCurrCode = emdExcessBaggageCurrCode;
	}

	public String getEmdEbtRatePerUnit() {
		return emdEbtRatePerUnit;
	}

	public void setEmdEbtRatePerUnit(String emdEbtRatePerUnit) {
		this.emdEbtRatePerUnit = emdEbtRatePerUnit;
	}

	public String getEmdEbtTotalNoExcess() {
		return emdEbtTotalNoExcess;
	}

	public void setEmdEbtTotalNoExcess(String emdEbtTotalNoExcess) {
		this.emdEbtTotalNoExcess = emdEbtTotalNoExcess;
	}

	public String getEmdEbtConsumedIssueInd() {
		return emdEbtConsumedIssueInd;
	}

	public void setEmdEbtConsumedIssueInd(String emdEbtConsumedIssueInd) {
		this.emdEbtConsumedIssueInd = emdEbtConsumedIssueInd;
	}

	public String getEmdNoOfServices() {
		return emdNoOfServices;
	}

	public void setEmdNoOfServices(String emdNoOfServices) {
		this.emdNoOfServices = emdNoOfServices;
	}

	public String getEmdOperatingCarrier() {
		return emdOperatingCarrier;
	}

	public void setEmdOperatingCarrier(String emdOperatingCarrier) {
		this.emdOperatingCarrier = emdOperatingCarrier;
	}

	public String getEmdAttributeGroup() {
		return emdAttributeGroup;
	}

	public void setEmdAttributeGroup(String emdAttributeGroup) {
		this.emdAttributeGroup = emdAttributeGroup;
	}

	public String getEmdAttributeSubgroup() {
		return emdAttributeSubgroup;
	}

	public void setEmdAttributeSubgroup(String emdAttributeSubgroup) {
		this.emdAttributeSubgroup = emdAttributeSubgroup;
	}

	public String getEmdIndustryCarrierIndicator() {
		return emdIndustryCarrierIndicator;
	}

	public void setEmdIndustryCarrierIndicator(String emdIndustryCarrierIndicator) {
		this.emdIndustryCarrierIndicator = emdIndustryCarrierIndicator;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
}
