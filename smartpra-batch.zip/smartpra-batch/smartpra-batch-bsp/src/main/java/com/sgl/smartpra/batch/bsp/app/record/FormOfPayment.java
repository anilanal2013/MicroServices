package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class FormOfPayment extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.FORM_OF_PAYMENT;
	}

	// Layout of Form Of Payment Recprd
	public class FormOfPaymentLayout extends FixedLengthRecordLayout {
		public FormOfPaymentLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fopType", 26, 35));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fopAmount", 36, 46));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fopAccountNumber", 47, 65));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("expiryDate", 66, 69));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("extendedPaymentCode", 70, 71));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("approvalCode", 72, 77));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("invoiceNumber", 78, 91));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("invoiceDate", 92, 97));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("remittanceAmount", 98, 108));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cardVerificationValueResult", 109, 109));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 110, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 133, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		FormOfPaymentLayout formOfPaymentLayout = new FormOfPaymentLayout();
		tokenizer.setColumns(formOfPaymentLayout.getColumns());
		tokenizer.setNames(formOfPaymentLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold the values of record
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String fopType;
	private String fopAmount;
	private String fopAccountNumber;
	private String expiryDate;
	private String extendedPaymentCode;
	private String approvalCode;
	private String invoiceNumber;
	private String invoiceDate;
	private String remittanceAmount;
	private String cardVerificationValueResult;
	private String filler;
	private String currencyType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getFopType() {
		return fopType;
	}

	public void setFopType(String fopType) {
		this.fopType = fopType;
	}

	public String getFopAmount() {
		return fopAmount;
	}

	public void setFopAmount(String fopAmount) {
		this.fopAmount = fopAmount;
	}

	public String getFopAccountNumber() {
		return fopAccountNumber;
	}

	public void setFopAccountNumber(String fopAccountNumber) {
		this.fopAccountNumber = fopAccountNumber;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getExtendedPaymentCode() {
		return extendedPaymentCode;
	}

	public void setExtendedPaymentCode(String extendedPaymentCode) {
		this.extendedPaymentCode = extendedPaymentCode;
	}

	public String getApprovalCode() {
		return approvalCode;
	}

	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getRemittanceAmount() {
		return remittanceAmount;
	}

	public void setRemittanceAmount(String remittanceAmount) {
		this.remittanceAmount = remittanceAmount;
	}

	public String getCardVerificationValueResult() {
		return cardVerificationValueResult;
	}

	public void setCardVerificationValueResult(String cardVerificationValueResult) {
		this.cardVerificationValueResult = cardVerificationValueResult;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
}