package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class DocumentAmounts extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.DOCUMENT_AMOUNTS;
	}

	// Layout of Document Amounts Record
	public class DocumentAmountsLayout extends FixedLengthRecordLayout {
		public DocumentAmountsLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fare", 41, 52));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktModeIndicator", 53, 53));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("equivalentFarePaid", 54, 65));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("total", 66, 77));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("airlineProviderIdentifier", 78, 81));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareCalcModeIndicator", 82, 82));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bookingAgentIdentification", 83, 88));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bookingEntityOutletType", 89, 89));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareCalcPricingIndicator", 90, 90));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("airlineIssuingAgent", 91, 98));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 99, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		DocumentAmountsLayout documentAmountsLayout = new DocumentAmountsLayout();
		tokenizer.setColumns(documentAmountsLayout.getColumns());
		tokenizer.setNames(documentAmountsLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String fare;
	private String tktModeIndicator;
	private String equivalentFarePaid;
	private String total;
	private String airlineProviderIdentifier;
	private String fareCalcModeIndicator;
	private String bookingAgentIdentification;
	private String bookingEntityOutletType;
	private String fareCalcPricingIndicator;
	private String airlineIssuingAgent;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getFare() {
		return fare;
	}

	public void setFare(String fare) {
		this.fare = fare;
	}

	public String getTktModeIndicator() {
		return tktModeIndicator;
	}

	public void setTktModeIndicator(String tktModeIndicator) {
		this.tktModeIndicator = tktModeIndicator;
	}

	public String getEquivalentFarePaid() {
		return equivalentFarePaid;
	}

	public void setEquivalentFarePaid(String equivalentFarePaid) {
		this.equivalentFarePaid = equivalentFarePaid;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getAirlineProviderIdentifier() {
		return airlineProviderIdentifier;
	}

	public void setAirlineProviderIdentifier(String airlineProviderIdentifier) {
		this.airlineProviderIdentifier = airlineProviderIdentifier;
	}

	public String getFareCalcModeIndicator() {
		return fareCalcModeIndicator;
	}

	public void setFareCalcModeIndicator(String fareCalcModeIndicator) {
		this.fareCalcModeIndicator = fareCalcModeIndicator;
	}

	public String getBookingAgentIdentification() {
		return bookingAgentIdentification;
	}

	public void setBookingAgentIdentification(String bookingAgentIdentification) {
		this.bookingAgentIdentification = bookingAgentIdentification;
	}

	public String getBookingEntityOutletType() {
		return bookingEntityOutletType;
	}

	public void setBookingEntityOutletType(String bookingEntityOutletType) {
		this.bookingEntityOutletType = bookingEntityOutletType;
	}

	public String getFareCalcPricingIndicator() {
		return fareCalcPricingIndicator;
	}

	public void setFareCalcPricingIndicator(String fareCalcPricingIndicator) {
		this.fareCalcPricingIndicator = fareCalcPricingIndicator;
	}

	public String getAirlineIssuingAgent() {
		return airlineIssuingAgent;
	}

	public void setAirlineIssuingAgent(String airlineIssuingAgent) {
		this.airlineIssuingAgent = airlineIssuingAgent;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}
