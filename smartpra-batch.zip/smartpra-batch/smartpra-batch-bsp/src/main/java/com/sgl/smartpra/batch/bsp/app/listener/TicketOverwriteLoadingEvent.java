package com.sgl.smartpra.batch.bsp.app.listener;

import java.util.List;

import org.springframework.context.ApplicationEvent;

import com.sgl.smartpra.sales.domain.TicketCommission;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketCpnTax;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.TicketOrgin;
import com.sgl.smartpra.sales.domain.TicketPaymentDetail;

@SuppressWarnings("serial")
public class TicketOverwriteLoadingEvent extends ApplicationEvent {
	
	private TicketMain ticketMain;
	
	private TicketOrgin ticketOrgin;
	
	private TicketCommission ticketCommission;
	
	private TicketPaymentDetail ticketPaymentDetail;

	private TicketCpnTax ticketCpnTax;

	private TicketCoupon ticketCoupon;


	public TicketOverwriteLoadingEvent(TicketMain ticketMain) {
		super(ticketMain);
		this.setTicketMain(ticketMain);
	}
	
	public TicketOverwriteLoadingEvent(TicketCommission ticketCommission) {
		super(ticketCommission);
		this.setTicketCommission(ticketCommission);
	}
	
	public TicketOverwriteLoadingEvent(TicketPaymentDetail ticketPaymentDetail) {
		super(ticketPaymentDetail);
		this.setTicketPaymentDetail(ticketPaymentDetail);
	}
	

	public TicketOverwriteLoadingEvent(TicketCpnTax ticketCpnTax) {
		super(ticketCpnTax);
		this.setTicketCpnTax(ticketCpnTax);
	}
	
	public TicketOverwriteLoadingEvent(TicketCoupon ticketCoupon) {
		super(ticketCoupon);
		this.setTicketCoupon(ticketCoupon);
	}
	
	public TicketOverwriteLoadingEvent(TicketOrgin ticketOrgin) {
		super(ticketOrgin);
		this.setTicketOrgin(ticketOrgin);
	}
	
	public TicketMain getTicketMain() {
		return ticketMain;
	}

	public void setTicketMain(TicketMain ticketMain) {
		this.ticketMain = ticketMain;
	}

	public TicketOrgin getTicketOrgin() {
		return ticketOrgin;
	}

	public void setTicketOrgin(TicketOrgin ticketOrgin) {
		this.ticketOrgin = ticketOrgin;
	}

	public TicketCommission getTicketCommission() {
		return ticketCommission;
	}

	public void setTicketCommission(TicketCommission ticketCommission) {
		this.ticketCommission = ticketCommission;
	}

	public TicketPaymentDetail getTicketPaymentDetail() {
		return ticketPaymentDetail;
	}

	public void setTicketPaymentDetail(TicketPaymentDetail ticketPaymentDetail) {
		this.ticketPaymentDetail = ticketPaymentDetail;
	}

	public TicketCpnTax getTicketCpnTax() {
		return ticketCpnTax;
	}

	public void setTicketCpnTax(TicketCpnTax ticketCpnTax) {
		this.ticketCpnTax = ticketCpnTax;
	}

	public TicketCoupon getTicketCoupon() {
		return ticketCoupon;
	}

	public void setTicketCoupon(TicketCoupon ticketCoupon) {
		this.ticketCoupon = ticketCoupon;
	}
	


}
