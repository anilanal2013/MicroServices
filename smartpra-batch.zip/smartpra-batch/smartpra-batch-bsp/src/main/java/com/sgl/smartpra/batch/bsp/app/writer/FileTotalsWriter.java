package com.sgl.smartpra.batch.bsp.app.writer;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileTotalsStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.FileTotalsStgRepository;

public class FileTotalsWriter extends BSPBaseItemWriter {
	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private FileTotalsStgRepository fileTotalsStgRepository;

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends BSPStagingDomainObject> items) throws Exception {
		items.forEach(item -> {

			((FileTotalsStg) item)
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			((FileTotalsStg) item).setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			super.setCreateAuditValues(item);

		});

		fileTotalsStgRepository.saveAll((Iterable<FileTotalsStg>) items);
	}

}
