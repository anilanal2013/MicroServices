package com.sgl.smartpra.batch.bsp.app.processor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.StdDocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.util.BSPConstants;
import com.sgl.smartpra.batch.bsp.app.util.BSPUtil;
import com.sgl.smartpra.batch.global.SalesFileHeader;
import com.sgl.smartpra.sales.domain.ReportedTax;

@Component
public class ReportedTaxProcessor {
	
	List<String> traansCodeCheck = Arrays.asList("ADM", "ACM", "RCS", "SPD", "SSA", "TAA", "RFN");

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public Map<String, List<ReportedTax>> process(String user,TicketDocumentIdentificationStg ticketDocumentIdentificationStg, TransactionHeaderStg transactionHeaderStg,
			Map<String, String> ticketDoc ,Map<String, String> reportedTaxGMap,boolean ticketRefundData,Integer decimalPrecision,Integer fileId) {
		List<ReportedTax> reportedTaxs = new LinkedList<>();
		
		Long docNum = Long.parseLong(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));

		Map<String, List<ReportedTax>> reportedTaxMap = new HashMap<>();
		List<ReportedTax> reportedTaxTicket = new ArrayList<>();
		List<ReportedTax> reportedTaxNonTicket = new ArrayList<>();

		List<StdDocumentAmountsStg> standaredAmountStg2s = transactionHeaderStg.getStdDocumentAmountsStg();
		if ((!"Y".equalsIgnoreCase(ticketDoc.get("conjTicketIndicator")))
				|| !traansCodeCheck.contains(ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3))) {
			if (!standaredAmountStg2s.isEmpty()) {
				int count = 0;
				for (int i = 0; i < standaredAmountStg2s.size(); i++) {

					ReportedTax reportedTax = new ReportedTax();

					if (!standaredAmountStg2s.get(i).getTaxMiscFeeType1().isEmpty()) {
						reportedTax = new ReportedTax();
						reportedTax.setSerialNo(++count);

						String taxCode = standaredAmountStg2s.get(i).getTaxMiscFeeType1();
						for (int h = 0; h < taxCode.length() - 1; h++) {
							if (taxCode.charAt(h) > 64 && taxCode.charAt(h) <= 90) {
								char main = taxCode.charAt(h);
								char end = taxCode.charAt(h + 1);
								taxCode = main + "" + end;
								reportedTax.setTaxCode(taxCode);
							}
						}

						int taxCurrency = 0;
						if (standaredAmountStg2s.get(i).getCurrencyType().length() > 0) {
							if (standaredAmountStg2s.get(i).getCurrencyType().length() > 0
									&& standaredAmountStg2s.get(i).getCurrencyType().length() <= 3) {
								taxCurrency = standaredAmountStg2s.get(i).getCurrencyType().length();
								reportedTax.setTaxCurrency(
										standaredAmountStg2s.get(i).getCurrencyType().substring(0, taxCurrency));

							} else if (standaredAmountStg2s.get(i).getCurrencyType().length() > 3) {
								reportedTax
										.setTaxCurrency(standaredAmountStg2s.get(i).getCurrencyType().substring(0, 3));
							}
						}
						
						
						String docType = ticketDoc.get("docType");
						
						
						/*if (docType != null && !docType.isEmpty()) {
							ticketSale.setDocType(docType);
						} else {
							ticketSale.setDocType("PAX");
						}*/
						
						String transType = "";
						try {
							transType = getTransType(ticketDocumentIdentificationStg, transactionHeaderStg, ticketDoc);
						} catch (Exception e) {
						
						}

						reportedTax.setTransactionType(ticketDoc.get("transactionType"));
						
						try {
							String taxAmountValue = standaredAmountStg2s.get(i).getTaxMiscFeeAmount1();
							if (!taxAmountValue.isEmpty() && taxAmountValue != null) {
								String taxAmountSign = BSPUtil.getSignedFieldValue(taxAmountValue);
								String taxAmountString = BSPUtil.getSignedFieldStringValue(taxAmountSign, decimalPrecision);
								BigDecimal taxAmount = BSPUtil.getvalidatedBigDecimal(taxAmountString);
								reportedTax.setTaxAmount(taxAmount);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						reportedTax.setPnr(ticketDocumentIdentificationStg.getPnrRefAirlineDate());
						reportedTax.setSourceData(ticketDoc.get(BSPConstants.SOURCE));
						reportedTax.setMainDocument(ticketDoc.get("mainDocument"));
						reportedTax.setIssAirline(standaredAmountStg2s.get(i).getTktDocNumber().substring(0, 3));
						reportedTax.setDocumentNo(standaredAmountStg2s.get(i).getTktDocNumber().substring(3, 13));
						String sDate7 = standaredAmountStg2s.get(i).getDateOfIssue();
						reportedTax.setDateOfIssue(BSPUtil.getFormattedDate(sDate7, "yyMMdd"));
						reportedTax.setTransactionType(ticketDoc.get("transactionType"));
						reportedTax.setCreatedBy(user);
						reportedTax.setCreatedDate(new Timestamp(new Date().getTime()));
						reportedTax.setFileId(fileId);
						reportedTax.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
//						if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
//
//							String documentUniqueIdRefund = ticketDoc.get("documentUniqueIdRefund");
//							if (documentUniqueIdRefund == null && !documentUniqueIdRefund.isEmpty()) {
//
//								reportedTax.setDocumentUniqueId(documentUniqueIdRefund);
//							}
//						} else {
//							reportedTax.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
//						}
						
						
						if (!ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if (!checkDuplicate(reportedTax,reportedTaxGMap)) {
								reportedTaxTicket.add(reportedTax);
							}
						}
						if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if(!ticketDoc.get("documentUniqueIdRefund").isEmpty()) {
								reportedTax.setDocumentUniqueId(ticketDoc.get("documentUniqueIdRefund"));
							}
							if (!checkDuplicate(reportedTax,reportedTaxGMap)) {
								reportedTaxNonTicket.add(reportedTax);
							}
						}
					}

					if (!standaredAmountStg2s.get(i).getTaxMiscFeeType2().isEmpty()) {
						reportedTax = new ReportedTax();
						reportedTax.setSerialNo(++count);
						String taxCode = standaredAmountStg2s.get(i).getTaxMiscFeeType2();
						for (int h = 0; h < taxCode.length() - 1; h++) {
							if (taxCode.charAt(h) > 64 && taxCode.charAt(h) <= 90) {
								char main = taxCode.charAt(h);
								char end = taxCode.charAt(h + 1);
								taxCode = main + "" + end;
								reportedTax.setTaxCode(taxCode);
							}
						}
						int taxCurrency = 0;
						if (standaredAmountStg2s.get(i).getCurrencyType().length() > 0) {
							if (standaredAmountStg2s.get(i).getCurrencyType().length() > 0
									&& standaredAmountStg2s.get(i).getCurrencyType().length() <= 3) {
								taxCurrency = standaredAmountStg2s.get(i).getCurrencyType().length();
								reportedTax.setTaxCurrency(
										standaredAmountStg2s.get(i).getCurrencyType().substring(0, taxCurrency));

							} else if (standaredAmountStg2s.get(i).getCurrencyType().length() > 3) {
								reportedTax
										.setTaxCurrency(standaredAmountStg2s.get(i).getCurrencyType().substring(0, 3));
							}
						}
						String transType = "";
						try {
							transType = getTransType(ticketDocumentIdentificationStg, transactionHeaderStg, ticketDoc);
						} catch (Exception e) {
						
						}

						try {
							String taxAmountValue = standaredAmountStg2s.get(i).getTaxMiscFeeAmount2();
							if (!taxAmountValue.isEmpty() && taxAmountValue != null) {
								String taxAmountSign = BSPUtil.getSignedFieldValue(taxAmountValue);
								String taxAmountString = BSPUtil.getSignedFieldStringValue(taxAmountSign, decimalPrecision);
								BigDecimal taxAmount = BSPUtil.getvalidatedBigDecimal(taxAmountString);
								reportedTax.setTaxAmount(taxAmount);
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
						}
						reportedTax.setPnr(ticketDocumentIdentificationStg.getPnrRefAirlineDate());
						reportedTax.setSourceData("BSP");
						reportedTax.setTransactionType(ticketDoc.get("transactionType"));
						reportedTax.setMainDocument(ticketDoc.get("mainDocument"));
						reportedTax.setIssAirline(standaredAmountStg2s.get(i).getTktDocNumber().substring(0, 3));
						reportedTax.setDocumentNo(standaredAmountStg2s.get(i).getTktDocNumber().substring(3, 13));
						String sDate7 = standaredAmountStg2s.get(i).getDateOfIssue();
						reportedTax.setDateOfIssue(BSPUtil.getFormattedDate(sDate7, "yyMMdd"));
						reportedTax.setTransactionType(ticketDoc.get("transactionType"));
						reportedTax.setCreatedBy(user);
						reportedTax.setCreatedDate(new Timestamp(new Date().getTime()));
						reportedTax.setFileId(fileId);
						reportedTax.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
//						if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
//
//							String documentUniqueIdRefund = ticketDoc.get("documentUniqueIdRefund");
//							if (documentUniqueIdRefund == null && !documentUniqueIdRefund.isEmpty()) {
//
//								reportedTax.setDocumentUniqueId(documentUniqueIdRefund);
//							}
//						} else {
//							reportedTax.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
//						}
//
//						reportedTaxs.add(reportedTax);
						if (!ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if (!checkDuplicate(reportedTax,reportedTaxGMap)) {
								reportedTaxTicket.add(reportedTax);
							}
						}
						if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if(!ticketDoc.get("documentUniqueIdRefund").isEmpty()) {
								reportedTax.setDocumentUniqueId(ticketDoc.get("documentUniqueIdRefund"));
							}
							if (!checkDuplicate(reportedTax,reportedTaxGMap)) {
								reportedTaxNonTicket.add(reportedTax);
							}
						}

					}

					if (standaredAmountStg2s.get(i).getTaxMiscFeeType3()!=null && !standaredAmountStg2s.get(i).getTaxMiscFeeType3().isEmpty()) {
						reportedTax = new ReportedTax();
						reportedTax.setSerialNo(++count);
						String taxCode = standaredAmountStg2s.get(i).getTaxMiscFeeType3();
						for (int h = 0; h < taxCode.length() - 1; h++) {
							if (taxCode.charAt(h) > 64 && taxCode.charAt(h) <= 90) {
								char main = taxCode.charAt(h);
								char end = taxCode.charAt(h + 1);
								taxCode = main + "" + end;
								reportedTax.setTaxCode(taxCode);
							}
						}
						int taxCurrency = 0;
						if (standaredAmountStg2s.get(i).getCurrencyType().length() > 0) {
							if (standaredAmountStg2s.get(i).getCurrencyType().length() > 0
									&& standaredAmountStg2s.get(i).getCurrencyType().length() <= 3) {
								taxCurrency = standaredAmountStg2s.get(i).getCurrencyType().length();
								reportedTax.setTaxCurrency(
										standaredAmountStg2s.get(i).getCurrencyType().substring(0, taxCurrency));

							} else if (standaredAmountStg2s.get(i).getCurrencyType().length() > 3) {
								reportedTax
										.setTaxCurrency(standaredAmountStg2s.get(i).getCurrencyType().substring(0, 3));
							}
						}
						String transType = "";
						try {
							transType = getTransType(ticketDocumentIdentificationStg, transactionHeaderStg, ticketDoc);
						} catch (Exception e) {
						
						}

						reportedTax.setTransactionType(ticketDoc.get("transactionType"));
						
						try {
							String taxAmountValue = standaredAmountStg2s.get(i).getTaxMiscFeeAmount3();
							if (!taxAmountValue.isEmpty() && taxAmountValue != null) {
								String taxAmountSign = BSPUtil.getSignedFieldValue(taxAmountValue);
								String taxAmountString = BSPUtil.getSignedFieldStringValue(taxAmountSign, decimalPrecision);
								BigDecimal taxAmount = BSPUtil.getvalidatedBigDecimal(taxAmountString);
								reportedTax.setTaxAmount(taxAmount);
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
						}
						reportedTax.setPnr(ticketDocumentIdentificationStg.getPnrRefAirlineDate());
						reportedTax.setSourceData("BSP");
						reportedTax.setMainDocument(ticketDoc.get("mainDocument"));
						reportedTax.setIssAirline(standaredAmountStg2s.get(i).getTktDocNumber().substring(0, 3));
						reportedTax.setDocumentNo(standaredAmountStg2s.get(i).getTktDocNumber().substring(3, 13));
						String sDate7 = standaredAmountStg2s.get(i).getDateOfIssue();
						reportedTax.setDateOfIssue(BSPUtil.getFormattedDate(sDate7, "yyMMdd"));
						reportedTax.setTransactionType(ticketDoc.get("transactionType"));
						reportedTax.setCreatedBy(user);
						reportedTax.setCreatedDate(new Timestamp(new Date().getTime()));
						reportedTax.setFileId(fileId);
						reportedTax.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
//						if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
//
//							String documentUniqueIdRefund = ticketDoc.get("documentUniqueIdRefund");
//							if (documentUniqueIdRefund == null && !documentUniqueIdRefund.isEmpty()) {
//
//								reportedTax.setDocumentUniqueId(documentUniqueIdRefund);
//							}
//						} else {
//							reportedTax.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
//						}
//						
//						reportedTaxs.add(reportedTax);
						if (!ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if (!checkDuplicate(reportedTax,reportedTaxGMap)) {
								reportedTaxTicket.add(reportedTax);
							}
						}
						if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if(!ticketDoc.get("documentUniqueIdRefund").isEmpty()) {
								reportedTax.setDocumentUniqueId(ticketDoc.get("documentUniqueIdRefund"));
							}
							if (!checkDuplicate(reportedTax,reportedTaxGMap)) {
								reportedTaxNonTicket.add(reportedTax);
							}
						}

					}

				}
			}
		}
		reportedTaxMap.put("reportedTaxTicket", reportedTaxTicket);
		reportedTaxMap.put("reportedTaxNonTicket", reportedTaxNonTicket);
		return reportedTaxMap;
	}
	private boolean checkDuplicate(ReportedTax reportedTax, Map<String,String> reportedTaxGmap){
		
		String sql = "select document_unique_id from SmartPRASales.reported_tax where document_unique_id = '"+reportedTax.getDocumentUniqueId()+"' and tax_code = '"+reportedTax.getTaxCode()+"' and serial_no = "+reportedTax.getSerialNo();
		
		boolean isPresentsInDb =   jdbcTemplate.queryForList(sql).isEmpty();
		
		//boolean isPresentsInDb = taxRepository.findOneByDocumentUniqueIdAndTaxCodeAndSerialNo(ticketTax.getDocumentUniqueId(), ticketTax.getTaxCode(), ticketTax.getSerialNo()).isPresent();
		String taxKey = reportedTax.getDocumentUniqueId()+reportedTax.getTaxCode()+reportedTax.getSerialNo();
		boolean isPresentsInCurrentJob = reportedTaxGmap.containsKey(taxKey);
		if(!isPresentsInCurrentJob) {
			reportedTaxGmap.put(taxKey, taxKey);
		}else {
			System.out.println("Duplicate in ReportedTax==============>"+taxKey);
		}
		
		return (isPresentsInCurrentJob || !isPresentsInDb) ;
	}
	
	private String getTransType(TicketDocumentIdentificationStg ticketDocumentIdentificationStg,TransactionHeaderStg transactionHeaderStg,
			Map<String, String> ticketDoc) {
		String transCode = "";
		String tansType ="";
		String transactionTypeActual = ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3);
		String transType = ticketDocumentIdentificationStg.getTransactionCode();
		boolean formOfPaymentRecType = false;
		if (!transactionHeaderStg.getFormOfPaymentStg().isEmpty()) {
			for (FormOfPaymentStg ofPaymentStg : transactionHeaderStg.getFormOfPaymentStg()) {					
				if (ofPaymentStg.getFopType().substring(0, 2).contentEquals("EX")) {
					formOfPaymentRecType = true;
					transCode = "PE";
				} 
			}				
		}
		 if (formOfPaymentRecType==false) {
			 transCode = (BSPUtil.getTransactionCode(transactionTypeActual));
		} else if (transType.contentEquals("SSAC")) {
			 transCode = "AC";
		} else if (transType.contentEquals("SSAD")) {
			 transCode = "AD";
		} else if ("PAX".equals(ticketDoc.get("docType"))
				&& "CAN".contentEquals(transactionTypeActual.substring(0, 3))) {
			transCode ="PV";
		}

		// void sector changes - based on coupon use indicator and doc type PAX
		if (ticketDocumentIdentificationStg.getCpnUseIndicator() != null && !ticketDocumentIdentificationStg.getCpnUseIndicator().isEmpty()) {
			if ("PAX".equals(ticketDoc.get("docType")) && "VVVV".equals(ticketDocumentIdentificationStg.getCpnUseIndicator())) {
				transCode = "PV";
			}
		}
		if(!transCode.isEmpty()) {
			tansType = transCode.substring(1, 2);
		}
		if (SalesFileHeader.valueOf(ticketDoc.get(BSPConstants.SOURCE)) == SalesFileHeader.ARC) {
			tansType = ticketDocumentIdentificationStg.getCpnUseIndicator();
		}
		return transType;
		
	}
	
	

}
