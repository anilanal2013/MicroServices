package com.sgl.smartpra.batch.bsp.app.processor;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeTotalsStg;
import com.sgl.smartpra.batch.bsp.app.mapper.BSPRecordMapper;
import com.sgl.smartpra.batch.bsp.app.record.BSPBaseRecord;
import com.sgl.smartpra.batch.bsp.app.record.OfficeTotals;

public class OfficeTotalsProcessor extends BSPBaseItemProcessor {

	@Override
	public BSPStagingDomainObject process(BSPBaseRecord bspBaseRecord) throws Exception {

		OfficeTotalsStg officeTotalsStg = BSPRecordMapper.INSTANCE.mapOfficeTotalsRecord((OfficeTotals) bspBaseRecord);
		return officeTotalsStg;
	}
}
