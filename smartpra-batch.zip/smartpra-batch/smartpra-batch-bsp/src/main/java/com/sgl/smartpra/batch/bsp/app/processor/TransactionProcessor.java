package com.sgl.smartpra.batch.bsp.app.processor;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.server.ResponseStatusException;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.CarrierMasterFeignClient;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SalesFeignClient;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SalesValidationFeignClient;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketModel;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.listener.BSPProdLoadingEvent;
import com.sgl.smartpra.batch.bsp.app.listener.TicketOverwriteLoadingEvent;
import com.sgl.smartpra.batch.bsp.app.repository.staging.OfficeHeaderStgRepository;
import com.sgl.smartpra.batch.bsp.app.util.BSPConstants;
import com.sgl.smartpra.batch.bsp.app.util.BSPUtil;
import com.sgl.smartpra.batch.global.SalesFileHeader;
import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.sales.domain.AgentRegister;
import com.sgl.smartpra.sales.domain.ReportedTax;
import com.sgl.smartpra.sales.domain.TicketAcmAdm;
import com.sgl.smartpra.sales.domain.TicketCommission;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.TicketOrgin;
import com.sgl.smartpra.sales.domain.TicketPaymentDetail;
import com.sgl.smartpra.sales.domain.TicketSale;
import com.sgl.smartpra.sales.domain.TicketTax;
import com.sgl.smartpra.sales.model.TicketMainValidationDTO;
import com.sgl.smartpra.sales.repository.AgentRegisterRepository;
import com.sgl.smartpra.sales.repository.TicketAcmAdmRepository;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

public class TransactionProcessor implements ItemProcessor<TransactionHeaderStg, List<TicketModel>> {

	 Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	CarrierMasterFeignClient carrierMasterFeignClient;
	
	@Autowired
	SalesValidationFeignClient salesValidationFeignClient;
	
	@Autowired
	TicketMainRepository ticketMainRepository;

	@Autowired
	TicketMainProcessor ticketMainProcessor;

	@Autowired
	ACMADMProcessor acmAdmProcessor;

	@Autowired
	TicketOriginProcessor ticketOriginProcessor;

	@Autowired
	TicketSaleProcessor ticketSaleProcessor;

	@Autowired
	TicketPaymentProcessor ticketPaymentProcessor;

	@Autowired
	TicketCouponProcessor ticketCouponProcessor;

	@Autowired
	ReportedTaxProcessor reportedTaxProcessor;

	@Autowired
	TicketCommissionProcessor ticketCommissionProcessor;

	@Autowired
	TicketTaxProcessor ticketTaxProcessor;

	@Autowired
	OfficeHeaderStgRepository officeHeaderStgRepository;

	@Autowired
	AgentRegisterRepository agentRegisterRepository;
	
	@Autowired
	TicketAcmAdmRepository ticketAcmAdmRepository;
	
	
	@Autowired
	private ApplicationEventPublisher eventPublisher;

	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	public List<TicketModel> process(TransactionHeaderStg transactionHeaderStg) throws Exception {

		String clientId = stepExecution.getJobExecution().getExecutionContext().getString("clientId");
		
		
		ExecutionContext stepContext = this.stepExecution.getExecutionContext();
		
		JobParameter fileIdValue =  stepExecution.getJobExecution().getJobParameters().getParameters().get("fileId");
		
		
		
		
		Long fileId = (Long) fileIdValue.getValue();
		
		
		
		//This maps initialized in before job step, it will be used to avoid duplicates in the same file. 
		Map<String, String> ticketPaymentGMap = (Map<String, String>) stepExecution.getJobExecution().getExecutionContext().get("ticketPaymentGMap");
		Map<String, String> ticketSalesGMap = (Map<String, String>) stepExecution.getJobExecution().getExecutionContext().get("ticketSalesGMap");
		Map<String, String> reportedTaxGMap = (Map<String, String>) stepExecution.getJobExecution().getExecutionContext().get("reportedTaxGMap");
		Map<String, String> ticketOriginGMap = (Map<String, String>) stepExecution.getJobExecution().getExecutionContext().get("ticketOriginGMap");
		Map<String, String> ticketTaxGMap = (Map<String, String>) stepExecution.getJobExecution().getExecutionContext().get("ticketTaxGMap");
		Map<String, String> ticktCommisionGMap = (Map<String, String>) stepExecution.getJobExecution().getExecutionContext().get("ticktCommisionGMap");

		
		Map<String, String> ticketDoc = new HashMap<>();
		String agentNumericCode = transactionHeaderStg.getOfficeHeaderStg().getAgentNumericCode();
		String currencyType = transactionHeaderStg.getOfficeHeaderStg().getCurrencyType().substring(0,3);
		Date effectiveFromDate = new SimpleDateFormat("yyMMdd").parse((transactionHeaderStg.getOfficeHeaderStg().getBillingCycleHeaderStg().getHotReportingEndDate()));
		Date effectiveTodate = new SimpleDateFormat("yyMMdd").parse((transactionHeaderStg.getOfficeHeaderStg().getBillingCycleHeaderStg().getBillingAnalysisEndingDate()));
		String source = stepExecution.getJobExecution().getExecutionContext().getString(BSPConstants.SOURCE);
		SalesFileHeader file = SalesFileHeader.valueOf(source);
		String user = stepExecution.getJobExecution().getJobParameters().getString("user");

		Map<String, AgentRegister> agentRegisterMap = (Map<String, AgentRegister>) stepExecution.getJobExecution().getExecutionContext().get("salesKey");

//		AgentRegister agentRegister = agentRegisterMap.get(agentNumericCode+currencyType+effectiveFromDate.getDate()+effectiveTodate.getDate());

		List<TicketModel> ticketModels = new ArrayList<TicketModel>();

		// Iterating single ticket details
		transactionHeaderStg.getTicketDocumentIdentificationStg().forEach(ticketDocumentIdentificationStg -> {
			
			if(ticketDocumentIdentificationStg.getTktDocNumber().length() >= 13){ 
				
			String transType = null;
			String transactionType = ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3);
			String transCodeDerived = BSPUtil.getTransactionCode(transactionType);
		    transType = transCodeDerived;

			if(ticketDocumentIdentificationStg.getTransactionCode().contentEquals("SSAC")) {
				transType = "AC";
			}
			else if(ticketDocumentIdentificationStg.getTransactionCode().contentEquals("SSAD")) {
				transType = "AD";
			}
			logger.info("DocumentNumber======>"
					+ ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)
					+ "======Transaction Code======>" + ticketDocumentIdentificationStg.getTransactionCode()
					+ "======DocumentUniqueId======>" + clientId
					+ ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3)
					+ ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)
					+ ticketDocumentIdentificationStg.getDateOfIssue().substring(0, 6));
//			String key = agentNumericCode+currencyType+transType.substring(1, 2)+effectiveFromDate.getDate()+effectiveTodate.getDate();
//			System.out.println("Agent Key in TransactionProcessor "+ key);
			AgentRegister agentRegister = agentRegisterMap.get(agentNumericCode+currencyType+transType.substring(1, 2)+effectiveFromDate.getDate()+effectiveTodate.getDate());
			
			if(Objects.isNull(agentRegister)) {
				if(Objects.nonNull(ticketDocumentIdentificationStg.getTransactionCode())&& 
						ticketDocumentIdentificationStg.getTransactionCode().contentEquals(BSPConstants.TRANSACTION_TYPE_CANX)) {
						transType = "PS";
						agentRegister = agentRegisterMap.get(agentNumericCode+currencyType+transType.substring(1, 2)+effectiveFromDate.getDate()+effectiveTodate.getDate());
				}
			}			
			
if(agentRegister != null) {
			TicketModel ticketModel = new TicketModel();

			// TODO to get decimal precision
//			int decimalPrecision = 2;
			String effectiveDate = null;
			int decimalPrecision = 0;
			BSPUtil bspUtil = new BSPUtil();
			String decimalUnitValue = "";
			
			if (file == SalesFileHeader.ARC) {
				decimalUnitValue = transactionHeaderStg.getStdDocumentAmountsStg().get(0)
						.getCurrencyType().substring(3, 4);
			} else {
				decimalUnitValue = transactionHeaderStg.getOfficeHeaderStg().getCurrencyType()
						.substring(3, 4);
			}
			String currencyCode = transactionHeaderStg.getOfficeHeaderStg().getCurrencyType().substring(0, 3);
			String effectiveDateGiven = transactionHeaderStg.getOfficeHeaderStg().getRemittancePeriodEndDate();
			Optional<String> stationCode = Optional
					.of(transactionHeaderStg.getOfficeHeaderStg().getFileHeaderStg().getBspIdentifier());
			String effectiveDateGivenForIF = transactionHeaderStg.getOfficeHeaderStg().getFileHeaderStg()
					.getProcessingDate();
			String effectiveDateForIF = null;
			
			
				try {
					effectiveDate = bspUtil.getFormattedDate(effectiveDateGiven, "yyMMdd", "yyyy-MM-dd");
				} catch (java.text.ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					effectiveDateForIF = bspUtil.getFormattedDate(effectiveDateGivenForIF, "yyMMdd", "yyyy-MM-dd");
				} catch (java.text.ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			// to get decimal precision from BSPUtil
			decimalPrecision = bspUtil.getDecimalPrecision(smartpraMasterAppClient, stationCode,
					carrierMasterFeignClient, decimalUnitValue, currencyCode, Optional.of(effectiveDate),
					Optional.of(clientId), Optional.of(effectiveDateForIF));
			
			
			
			ticketDoc.put(BSPConstants.SOURCE, source);
			ticketDoc.put(BSPConstants.CURRENCY_TYPE, currencyType);
			
			ticketDoc.put("mainDocument", ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
			ticketDoc.put("documentNumber", ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
			ticketDoc.put("documentUniqueId", clientId + ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3)
					+ ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)
					+ ticketDocumentIdentificationStg.getDateOfIssue().substring(0, 6));
			if (ticketDocumentIdentificationStg.getConjuctionTicketIndicator() != null
					&& ticketDocumentIdentificationStg.getConjuctionTicketIndicator().contentEquals(BSPConstants.TICKET_TYPE_CNJ)) {
				
				ticketDoc.put("conjTicketIndicator", BSPConstants.INDICATOR_YES);
			} else {
				ticketDoc.put("conjTicketIndicator",  BSPConstants.INDICATOR_NO);
			}
			ticketDoc.put("placeOfIssue", ticketDocumentIdentificationStg.getTrueOrgDestCityCode().trim());

			// Constructing Ticket Main / Ticket ACM ADM
			TicketMain ticketMain = null;
			TicketMain ticketMainDuplicate = null;

			List<TicketAcmAdm> ticketAcmAdms = null;
			boolean ticketRefundData = false;
			boolean isValidationRequired = false;
            boolean ticketDuplicate= false;


			List <String> acmCheck = Arrays.asList(BSPConstants.TRANSACTION_TYPE_SPC, BSPConstants.TRANSACTION_TYPE_SSAC);
			List <String> admCheck = Arrays.asList(BSPConstants.TRANSACTION_TYPE_RCS,BSPConstants.TRANSACTION_TYPE_SSAD,
					BSPConstants.TRANSACTION_TYPE_TAA , BSPConstants.TRANSACTION_TYPE_SPD);
			
			if(StringUtils.equalsAnyIgnoreCase(ticketDocumentIdentificationStg.getTransactionCode(), BSPConstants.TRANSACTION_TYPE_TKT)) {

				String sql="SELECT document_unique_id from SmartPRASales.ticket_main where document_unique_id = "+"'"+ticketDoc.get("documentUniqueId")+"'";

			    //if (!ticketMainLive.isPresent()) {
				if (jdbcTemplate.queryForList(sql).isEmpty()) {
			        ticketMain = ticketMainProcessor.process(user, clientId, ticketDocumentIdentificationStg, transactionHeaderStg, decimalPrecision, fileId.intValue(),source);
			                                    /*try {
			                                    ResponseEntity<TicketMain> validationResponse = salesValidationFeignClient.validateTicketMain(ticketMain, "sales", "file");
			                                           String validationResult = validationResponse.getHeaders().get("overalValidationStatus").toString();
			                                    System.out.println("========================validationResult======================================"+validationResult);
			                                   } catch (Exception e) {
			                                           e.printStackTrace();
			                                    }*/
			        ticketDoc.put("docType", ticketMain.getDocType());
			        ticketDoc.put("rfic", ticketMain.getRfic());
			        ticketDoc.put("rpsi", ticketMain.getRpsi());
			        ticketDoc.put("couponUsageIndicator", ticketMain.getCouponUseIndicator());
			        isValidationRequired = true;
//			        ticketModel.setTicketMain(ticketMain);
			    }else {
			    	 ticketDoc.put("docType", getDocType(ticketDocumentIdentificationStg));
//			    	System.out.println("++++ Duplicate Record ++++++"+ ticketDoc.get("documentUniqueId"));
			    	stepContext.put("duplicateRecord", "Yes");
			    	ticketMainDuplicate = ticketMainProcessor.process(user, clientId, ticketDocumentIdentificationStg, transactionHeaderStg, decimalPrecision, fileId.intValue(),source);
			    	boolean ticketOverwrite=carrierMasterFeignClient.validateTicketOverwrite(ticketMainDuplicate.getFileSource(), ticketMainDuplicate.getFileSource(), ticketMainDuplicate.getStatus(), ticketMainDuplicate.getTransactionCodeReceived());
			    	if(ticketOverwrite)
			    	{
			    	ticketDuplicate=true;
			    	}
			    	if(ticketDuplicate)
			    	{
//			        eventPublisher.publishEvent(new TicketOverwriteLoadingEvent(ticketMainDuplicate));
			       
			    	}
			    }
			}
			else if (acmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode()) || 
					ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3).contains(BSPConstants.TRANSACTION_TYPE_ACM)){
				ticketDoc.put("docType", getDocType(ticketDocumentIdentificationStg));
			        Optional<TicketAcmAdm> ticketAcmLive = ticketAcmAdmRepository
			                .findOneByClientIdAndIssAirlineAndAcmAdmNoAndRelatedIssueAirlineAndRelatedTicketNumberAndRelatedCouponNumber(
			                        clientId, ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3),
			                        ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13), null, null, null);
			        if (!ticketAcmLive.isPresent()) {
			            ticketAcmAdms = acmAdmProcessor.process(clientId, ticketDocumentIdentificationStg,transactionHeaderStg, agentRegister, user, fileId.intValue());
			            ticketModel.setTicketAcmAdms(ticketAcmAdms);
			        }
			    }
			else if(admCheck.contains(ticketDocumentIdentificationStg.getTransactionCode()) ||
					ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3).contains(BSPConstants.TRANSACTION_TYPE_ADM))  {
				ticketDoc.put("docType", getDocType(ticketDocumentIdentificationStg));
			        Optional<TicketAcmAdm> ticketAdmLive = ticketAcmAdmRepository
			                .findOneByClientIdAndIssAirlineAndAcmAdmNoAndRelatedIssueAirlineAndRelatedTicketNumberAndRelatedCouponNumber(
			                        clientId, ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3),
			                        ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13), null, null, null);
			        if (!ticketAdmLive.isPresent()) {
			        	ticketAcmAdms = acmAdmProcessor.process(clientId, ticketDocumentIdentificationStg,transactionHeaderStg, agentRegister, user, fileId.intValue());
			        }
			        ticketModel.setTicketAcmAdms(ticketAcmAdms);
			    }
			else if(StringUtils.equalsAnyIgnoreCase(ticketDocumentIdentificationStg.getTransactionCode() , BSPConstants.TRANSACTION_TYPE_REFUND)) {
				ticketDoc.put("docType", getDocType(ticketDocumentIdentificationStg));
			    ticketRefundData = true;
			}
			else {
				 ticketDoc.put("docType", getDocType(ticketDocumentIdentificationStg));
			    ticketMain = ticketMainProcessor.process(user, clientId, ticketDocumentIdentificationStg, transactionHeaderStg, decimalPrecision, fileId.intValue(), source);
			    ticketModel.setTicketMain(ticketMain);
			}

			
			// Ticket Origin
			List<TicketOrgin> ticketOrginsTkt = null;
			List<TicketOrgin> ticketOrginsNonTkt = null;
			Map<String, List<TicketOrgin>> ticketOriginMap = null;
			ticketOriginMap = ticketOriginProcessor.process(ticketDocumentIdentificationStg, 
					transactionHeaderStg, ticketDoc, user, clientId, ticketOriginGMap,
					agentRegister.getSalesUniqueKey(), fileId.intValue(),decimalPrecision);

			ticketOrginsTkt = ticketOriginMap.get("ticketOrginsTicket");
			ticketOrginsNonTkt = ticketOriginMap.get("ticketOrginsNonTicket");
			if(ticketDuplicate)
			{
			String sql="SELECT document_unique_id from SmartPRASales.ticket_orgin where document_unique_id = "+"'"+ticketDoc.get("documentUniqueId")+"'";
			if (!jdbcTemplate.queryForList(sql).isEmpty()) {
				ticketOrginsTkt.forEach(s->
		        eventPublisher.publishEvent(new TicketOverwriteLoadingEvent(s)));
			}
			}
			if (ticketMain != null) {
				
				if (!ticketOrginsTkt.isEmpty()) {
					for (TicketOrgin ticketOrgin : ticketOrginsTkt) {
						ticketOrgin.setTicketMain(ticketMain);
					}
					ticketMain.setTicketOrgins(ticketOrginsTkt);
					ticketOrginsTkt = new ArrayList<>();
				}
			}else if(ticketRefundData && !ticketOrginsNonTkt.isEmpty()) {
				ticketModel.setTicketOrginNonTkt(ticketOrginsNonTkt);
				ticketOrginsNonTkt = new ArrayList<>();
			}

			// Ticket Sales
			Map<String, List<TicketSale>> ticketSaleMap = ticketSaleProcessor.process(user,clientId, ticketDocumentIdentificationStg, transactionHeaderStg, ticketDoc, agentRegister.getSalesUniqueKey(),ticketSalesGMap,ticketRefundData, fileId.intValue());
			
			List<TicketSale> ticketSaleNonTkt = ticketSaleMap.get("ticketSaleNonTicket");
			List<TicketSale> ticketSaleTkt = ticketSaleMap.get("ticketSaleTicket");

			if (!ticketSaleTkt.isEmpty()) {
				if (ticketMain != null) {
					for (TicketSale ticketSale : ticketSaleTkt) {
						ticketSale.setTicketMain(ticketMain);
					}
					ticketMain.setTicketSales(ticketSaleTkt);
					ticketSaleTkt = new ArrayList<>();

				} else if (ticketAcmAdms != null && !ticketAcmAdms.isEmpty()) {
					for (TicketSale ticketSale : ticketSaleTkt) {
						ticketSale.setTicketAcmAdm(ticketAcmAdms.get(0));
					}
					ticketAcmAdms.get(0).setTicketSales(ticketSaleTkt);
					ticketSaleTkt = new ArrayList<>();
				}
			}
			if(ticketRefundData && !ticketSaleNonTkt.isEmpty()) {
				ticketModel.setTicketSaleNonTkt(ticketSaleNonTkt);
				ticketSaleNonTkt = new ArrayList<>();
			}

			// Ticket PaymentDetails
			Map<String, List<TicketPaymentDetail>> ticketPaymentDetailsMap = ticketPaymentProcessor.process(user,ticketDocumentIdentificationStg, transactionHeaderStg, ticketDoc, decimalPrecision,
							agentRegister.getSalesUniqueKey(),ticketPaymentGMap,ticketRefundData, fileId.intValue());

			List<TicketPaymentDetail> ticketPaymentDetailsTkt = ticketPaymentDetailsMap.get("ticketPaymentTicket");
			List<TicketPaymentDetail> ticketPaymentDetailsNonTkt = ticketPaymentDetailsMap.get("ticketPaymentNonTicket");
			if(ticketDuplicate)
			{
				String sqlpayment="SELECT document_unique_id from SmartPRASales.ticket_payment_details where document_unique_id = "+"'"+ticketDoc.get("documentUniqueId")+"'";
				if (!jdbcTemplate.queryForList(sqlpayment).isEmpty()) {
					ticketPaymentDetailsTkt.forEach(s->eventPublisher.publishEvent(new TicketOverwriteLoadingEvent(s)));
				}
			}
			if (!ticketPaymentDetailsTkt.isEmpty()) {

				if (ticketMain != null) {
					for (TicketPaymentDetail ticketPaymentDetail : ticketPaymentDetailsTkt) {
						ticketPaymentDetail.setTicketMain(ticketMain);
//						System.out.println("ticketPaymentDetail=============================>"+ticketPaymentDetail);
					}
					ticketMain.setTicketPaymentDetails(ticketPaymentDetailsTkt);
					ticketPaymentDetailsTkt = new ArrayList<>();

				} else if (ticketAcmAdms != null  && !ticketAcmAdms.isEmpty()) {
					for (TicketPaymentDetail ticketPaymentDetail : ticketPaymentDetailsTkt) {
						ticketPaymentDetail.setTicketAcmAdm(ticketAcmAdms.get(0));
					}
					ticketAcmAdms.get(0).setTicketPaymentDetails(ticketPaymentDetailsTkt);
					ticketPaymentDetailsTkt = new ArrayList<>();
				}
			} 
			if(ticketRefundData && !ticketPaymentDetailsNonTkt.isEmpty()) {
				ticketModel.setTicketPaymentDetailNonTkt(ticketPaymentDetailsNonTkt);
				ticketPaymentDetailsNonTkt = new ArrayList<>();
			}

			String travelType = "";
			// Ticket coupons
			if (ticketMain != null) {
				List<TicketCoupon> ticketCoupons = ticketCouponProcessor.process(user,clientId, ticketDocumentIdentificationStg, transactionHeaderStg, ticketDoc, ticketMain, decimalPrecision, fileId.intValue());
				Set<String> airpotSet = new HashSet<>();
				if(ticketDuplicate)
				{
					String sqlcoupon="SELECT document_unique_id from SmartPRASales.ticket_coupon where document_unique_id = "+"'"+ticketDoc.get("documentUniqueId")+"'";
					if (!jdbcTemplate.queryForList(sqlcoupon).isEmpty()) {
						ticketCoupons.forEach(s->eventPublisher.publishEvent(new TicketOverwriteLoadingEvent(s)));
					}
				}
				if (!ticketCoupons.isEmpty()) {
					for (TicketCoupon ticketCoupon : ticketCoupons) {
						airpotSet.add(ticketCoupon.getFromAirport());
						airpotSet.add(ticketCoupon.getToAirport());
						if(ticketMain.getCouponUseIndicator().contains("S")) {
							ticketCoupon.setSectorNumber(ticketCoupon.getCouponNumber()+"");
						}
						ticketCoupon.setTicketMain(ticketMain);
					}
					ticketMain.setTicketCoupons(ticketCoupons);
					ticketCoupons = new ArrayList<>();
				}
				if (!airpotSet.isEmpty()) {
					try {
						List<String> airportList = new ArrayList<>();
						airportList.addAll(airpotSet);
						String type = carrierMasterFeignClient.getTicketTravelDetail(airportList);
						if (type.equalsIgnoreCase(BSPConstants.TRAVEL_TYPE_INTERNATIONALDESC)) {
							travelType = BSPConstants.TRAVEL_TYPE_INTERNATIONAL;
						} else if (type.equalsIgnoreCase(BSPConstants.TRAVEL_TYPE_DOMESTIC_DESC)) {
							travelType = BSPConstants.TRAVEL_TYPE_DOMESTIC;
						}
					} catch (Exception e) {
					}
				}
			}
			
			if(!travelType.isEmpty() && ticketMain != null) {
				ticketMain.setDomIntIndicator(travelType);
			}

			// Reported tax
			List<ReportedTax> reportedTaxTkt = null;
			
			Map<String, List<ReportedTax>> reportedTaxMap = reportedTaxProcessor.process(user,ticketDocumentIdentificationStg, transactionHeaderStg, ticketDoc, reportedTaxGMap,ticketRefundData,decimalPrecision,fileId.intValue());
			reportedTaxTkt = reportedTaxMap.get("reportedTaxTicket");
			List<ReportedTax> reportedTaxNonTkt = reportedTaxMap.get("reportedTaxNonTicket");

			if (ticketMain != null) {
				
				if (!reportedTaxTkt.isEmpty()) {
					for (ReportedTax reportedTax : reportedTaxTkt) {
						reportedTax.setTicketMain(ticketMain);
					}
					ticketMain.setReportedTaxs(reportedTaxTkt);
					reportedTaxTkt = new ArrayList<>();
				}
			}else if(ticketRefundData && !reportedTaxNonTkt.isEmpty()) {
			
				ticketModel.setReportedTaxNonTkt(reportedTaxNonTkt);
				reportedTaxNonTkt = new ArrayList<>();
			}

			// Ticket Commission
			
			Map<String, List<TicketCommission>> ticketCommissionMap = ticketCommissionProcessor.process(user,ticketDocumentIdentificationStg, transactionHeaderStg, ticketDoc, decimalPrecision, fileId.intValue(),ticktCommisionGMap,agentRegister.getSalesUniqueKey());

			List<TicketCommission> ticketCommissionTkt = ticketCommissionMap.get("ticketCommissionTicket");
			List<TicketCommission> ticketCommissionNonTkt = ticketCommissionMap.get("ticketCommissioneNonTicket");
			if(ticketDuplicate)
			{
				String sqlcoupon="SELECT document_unique_id from SmartPRASales.ticket_commission where document_unique_id = "+"'"+ticketDoc.get("documentUniqueId")+"'";
				if (!jdbcTemplate.queryForList(sqlcoupon).isEmpty()) {
					ticketCommissionTkt.forEach(s->eventPublisher.publishEvent(new TicketOverwriteLoadingEvent(s)));

				}
			}
			if (ticketMain != null) {
				if (!ticketCommissionTkt.isEmpty()) {
					for (TicketCommission ticketCommission : ticketCommissionTkt) {
						ticketCommission.setTicketMain(ticketMain);

					}
					ticketMain.setTicketCommissions(ticketCommissionTkt);
					ticketCommissionTkt = new ArrayList<>();
				}
			}

			if ((ticketRefundData && !ticketCommissionNonTkt.isEmpty())
					|| ((ticketAcmAdms != null && !ticketAcmAdms.isEmpty()) && !ticketCommissionNonTkt.isEmpty())) {
				ticketModel.setTicketCommisonNonTkt(ticketCommissionNonTkt);
				ticketCommissionNonTkt = new ArrayList<>();
			}

			// Ticket Tax
			List<TicketTax> ticketTaxTkt = null;
			
			Map<String, List<TicketTax>> ticketTaxMap = ticketTaxProcessor.process(user,clientId, ticketDocumentIdentificationStg, transactionHeaderStg, ticketDoc, decimalPrecision,ticketTaxGMap,ticketRefundData, fileId.intValue());
			ticketTaxTkt = ticketTaxMap.get("ticketTaxTicket");
			List<TicketTax> ticketTaxNonTkt = ticketTaxMap.get("ticketTaxNonTicket");

			if (ticketMain != null) {
				
				if (!ticketTaxTkt.isEmpty()) {
					for (TicketTax ticketTax : ticketTaxTkt) {
						ticketTax.setTicketMain(ticketMain);
					}
					ticketMain.setTicketTaxs(ticketTaxTkt);
					ticketTaxTkt = new ArrayList<>();
				}
			}
//			else if(ticketRefundData && !ticketTaxNonTkt.isEmpty()) {
//			
//				ticketModel.setTicketTaxNonTkt(ticketTaxNonTkt);
//				ticketTaxNonTkt = new ArrayList<>();
//			}
			
		
			if(isValidationRequired && ticketMain != null) {
				TicketMain originalObj = ticketMain;
				try {
					ticketMain.setAgentRegister(agentRegister);
					TicketMainValidationDTO validationResponse = salesValidationFeignClient
							.validateTicketMain(ticketMain, "sales", "file",ticketDocumentIdentificationStg.getTktIdentificationId());
					
					String validationResult = validationResponse.getOverAllRefDataValidationStatus();
					
					
					
					if (validationResult.equalsIgnoreCase("pass")) {
						System.out.println(validationResponse.getTicketMainDTO().getDocumentUniqueId()+"===================================validationResult============"+validationResult);
						ticketModel.setTicketMain(originalObj);
					}else if (validationResult.equalsIgnoreCase("fail")){
						System.out.println(validationResponse.getTicketMainDTO().getDocumentUniqueId()+"===================================validationResult============"+validationResult);
						int count = (Integer)stepExecution.getJobExecution().getExecutionContext().get("errorCount");
						count = count+1;
						stepExecution.getJobExecution().getExecutionContext().put("errorCount",count);
					}
				} catch (Exception e) {
				}
			}

			ticketModels.add(ticketModel);
            } else {
            	System.out.println("***Agent Key Not found in TransactionProcessor ******");
            }
}
		
		});

		return ticketModels;
	}
	
	
	private String getDocType(TicketDocumentIdentificationStg ticketDocumentIdentificationStg) {
		// Driving doc class and type using form code master
		String docType = "";
		String docClass = "";
		FormCode formCode = null;
		FormCode formCode1 = null;
		String formCodeIssueDate = null;
		try {
			formCodeIssueDate = BSPUtil.getFormattedDate(ticketDocumentIdentificationStg.getDateOfIssue().substring(0, 6), 
					"yyMMdd","yyyy-MM-dd");
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();   
		}
		String formCodeIssueDateOptional = formCodeIssueDate;
		String formCode3Digit = ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 6);
		String formCode2Digit = ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 5);
		
		try {
			formCode = smartpraMasterAppClient.getFormCodeByfromCodeAndEffectiveDate(
					formCode3Digit,formCodeIssueDateOptional);
			} catch (ResponseStatusException ex) {
				if (ex.getStatus() == HttpStatus.NOT_FOUND) {
//					logger.error("form code is not presents for {}",ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 6));
				}

			}catch(Exception ex) {
				ex.printStackTrace();
			}       

		try {
			formCode1 = smartpraMasterAppClient.getFormCodeByfromCodeAndEffectiveDate(
					formCode2Digit,formCodeIssueDateOptional);
		}catch (ResponseStatusException ex) {
			if (ex.getStatus() == HttpStatus.NOT_FOUND) {
//				logger.error("form code is not presents for {}",ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 5));
			}

		}catch(Exception ex) {
			ex.printStackTrace();
		}

		if (formCode != null) {
			docType = formCode.getDocumentType().get();

			if (formCode.getNumberOfCoupon().get() != "0") {
				
				docClass = formCode.getDocumentType().get().substring(0, 2) + formCode.getNumberOfCoupon().get();
			} else {
				docClass = formCode.getDocumentType().get().substring(0, 2);
			}
		}
		else if (formCode1 != null) {
			docType = formCode1.getDocumentType().get();

			if (formCode1.getNumberOfCoupon().get() != "0") {
				docClass = formCode1.getDocumentType().get().substring(0, 2) + formCode1.getNumberOfCoupon().get();
			} else {
				docClass = formCode1.getDocumentType().get().substring(0, 2);
			}
		}
		return docType;
	}
}
