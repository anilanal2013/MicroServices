package com.sgl.smartpra.batch.bsp.app.config;

import java.math.BigInteger;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.sgl.smartpra.master.model.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.global.model.InboundFileLog;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.CurrencyDetail;
import com.sgl.smartpra.sales.domain.TicketCommission;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketCpnTax;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.TicketOrgin;
import com.sgl.smartpra.sales.domain.TicketPaymentDetail;
import com.sgl.smartpra.sales.model.TicketMainValidationDTO;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-batch-global-app")
	public interface BatchGlobalFeignClient {

		@PostMapping("/inboundFileLogs")
		public InboundFileLog createInboundFileLog(@Valid @RequestBody InboundFileLog inboundFileLog);

		@PostMapping("/filelog")
		public FileLogging createFileLog(@Valid @RequestBody FileLogging fileLog);

		@GetMapping("/filelogs/filename/{fileName}")
		public List<FileLogging> getFileLogByFileName(@PathVariable(value = "fileName") String fileName);

		@GetMapping("/filelog/{fileId}")
		public FileLogging getFileLogByFileId(@PathVariable(value = "fileId") BigInteger fileId);

		@PutMapping("/filelog/{fileId}")
		public FileLogging updateFileLog(@PathVariable(value = "fileId") BigInteger fileId,
				@Valid @RequestBody FileLogging fileLog);
		
	

	}

	@FeignClient(value = "smartpra-master-app" ,configuration=FeignDecoderConfiguration.class)
	public interface SmartpraMasterAppClient {

		@GetMapping("/form-code")
		public List<FormCode> getAllFormCode(@RequestParam(value = "formCode", required = false) String formCode,
				@RequestParam(value = "documentType", required = false) String documentType,
				@RequestParam(value = "numberOfCoupon", required = false) String numberOfCoupon,
				@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
				@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate);

		// newly added for fetching FormCodeByfromCodeId
		@GetMapping("/form-code/{formCodeId}")
		public FormCode getFormCodeByfromCodeId(@PathVariable(value = "formCodeId") Integer formCodeId);
		
		@GetMapping("/form-code/formcode-date-search")
		public FormCode getFormCodeByfromCodeAndEffectiveDate(
				@RequestParam(value = "formCode", required = true) String formCode,
				@RequestParam(value = "effectiveDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") String effectiveDate);

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(
				@PathVariable(value = "parameterName") String parameterName);

		// Agency Code check
		@GetMapping("/agency-master/agencyCode/{agencyCode}/{clientId}")
		public AgencyMaster getAgencyByAgencyCode(@PathVariable(value = "agencyCode") String agencyCode,
				@PathVariable(value = "clientId") String clientId);

		@PostMapping("/agency-master")
		@ResponseStatus(value = HttpStatus.CREATED)
		public AgencyMaster createAgencyMaster(@Validated(Create.class) @RequestBody AgencyMaster agencyMaster);
		
		@GetMapping("/agency-master")
		public List<AgencyMaster> getAllAgency(
				@RequestParam(value = "agencyCode", required = false) String agencyCode,
				@RequestParam(value = "reportingAgency", required = false) Optional<String> reportingAgency,
				@RequestParam(value = "agencyType", required = false) Optional<String> agencyType,
				@RequestParam(value = "areaOfOperation", required = false) Optional<String> areaOfOperation,
				@RequestParam(value = "reportingAgencyType", required = false) Optional<String> reportingAgencyType,
				@RequestParam(value = "activate", required = false) Optional<Boolean> activate); 

		@GetMapping("/rpsi/rpsi-with-clientId/{rpsiCode}/clientId/{clientId}")
		public ReportingSystemIdentifier getRpsiCodeByClientIdAndRpsiCode(
				@PathVariable(value = "rpsiCode") Optional<String> rpsiCode,
				@PathVariable(value = "clientId") Optional<String> clientId);

		@GetMapping("/rpsi")
		public List<ReportingSystemIdentifier> getAllRpsi(
				@RequestParam(value = "rpsiCode", required = false) String rpsiCode,
				@RequestParam(value = "systemProvider", required = false) String systemProvider,
				@RequestParam(value = "isActive", required = false) Boolean isActive);

		@GetMapping("/code-shares/bsp")
		public List<CodeShare> getCodeShareByEffectiveDateBSP(
				@RequestParam(value = "clientId", required = false) String clientId,
				@RequestParam(value = "marketingCXR", required = false) String marketingCXR,
				@RequestParam(value = "marketedRBDList", required = false) String marketedRBDList,
				@RequestParam(value = "effectiveTravelDate", required = false) String effectiveTravelDate);

		@GetMapping("/agency-detail")
		public List<AgencyDetailsModel> getAgencyDetailsByEffectiveDate(
				@RequestParam(value = "agencyCode", required = false) String agencyCode,
				@RequestParam(value = "clientId", required = false) String clientId,
				@RequestParam(value = "transactionType", required = false) String transactionType,
				@RequestParam(value = "reportingFrequency", required = false) String reportingFrequency,
				@RequestParam(value = "transactionCurrency", required = false) String transactionCurrency,
				@RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate effectiveDate,
				@RequestParam(value = "activate", required = false) Boolean activate);

		@PostMapping("/agency/{agencyId}/agency-details")
		public AgencyDetailsModel createAgencyDetails(@PathVariable(value = "agencyId") Integer agencyId,
				@Validated(Create.class) @RequestBody AgencyDetailsModel agencyDetailsModel);

		@GetMapping("/interface-reference/interface-reference-with-date/{clientId}/{dataSource}/{stationCode}/{effectiveDate}")
		public InterfaceReference getInterfaceReferenceByDataSourceAndStationCodeWithEffectiveDate(
				@PathVariable(value = "clientId") Optional<String> clientId,
				@PathVariable(value = "dataSource") Optional<String> dataSource,
				@PathVariable(value = "stationCode") Optional<String> stationCode,
				@PathVariable(value = "effectiveDate") @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate);
		
		@GetMapping("/fop-mapping/search")
		public List<FOPMapping> search(@RequestParam(name = "stationCode", required = false) Optional<String> stationCode,
				@RequestParam(name = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
				@RequestParam(name = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
				@RequestParam(name = "source", required = false) Optional<String> source,
				@RequestParam(name = "fopCode", required = false) Optional<String> fopCode);

		@GetMapping("/fop/searchByTransactionType")
		public List<FOP> getListOfFOPByTransactionType(@RequestParam(value="fopIdentifier", required = true) String fopIdentifier,
													   @RequestParam(value="transactionType", required = true) String transactionType);

		@GetMapping("/fop/searchByFopIdentifier")
		public List<FOP> getListOfFOPByFopIdentifier(@RequestParam(value="fopIdentifier", required = true) String fopIdentifier);

	}

	@FeignClient(value = "smartpra-sales-service")
	public interface SalesFeignClient {

		@GetMapping("/paxtype/documentuniqueid/{documentUniqueId}")
		String derivePAXType(@PathVariable(value = "documentUniqueId") String documentUniqueId);
		
		@PutMapping("/api/overwriteTicketMain")
	    public ResponseEntity<TicketMain> overwriteTicketMain(@RequestBody TicketMain ticketMain);
	   
		@PutMapping("/api/overwriteTicketCoupon")
	    public ResponseEntity<TicketCoupon> overwriteTicketCoupon(@RequestBody TicketCoupon ticketCoupon);
		
		@PutMapping("/api/overwriteTicketPayment")
	    public ResponseEntity<TicketPaymentDetail> overwriteTicketPayment(@RequestBody TicketPaymentDetail ticketPaymentDetail);
	
		@PutMapping("/api/overwriteTicketCommission")
	    public ResponseEntity<TicketCommission> overwriteTicketCommission(@RequestBody TicketCommission ticketCommission);
	
		@PutMapping("/api/overwriteTicketCpnTax")
	    public ResponseEntity<TicketCpnTax> overwriteTicketCpnTax(@RequestBody TicketCpnTax ticketCpnTax);
	
		@PutMapping("/api/overwriteTicketOrgin")
	    public ResponseEntity<TicketOrgin> overwriteTicketOrgin(@RequestBody TicketOrgin ticketOrgin);
	}

	@FeignClient(value = "smartpra-global-master-app")
	public interface CarrierMasterFeignClient {
		@GetMapping("/carriers")
		public List<Carrier> getAllCarrier(
				@RequestParam(value = "carrierCode", required = false) @Valid String carrierCode,
				@RequestParam(value = "carrierDesignatorCode", required = false) String carrierDesignatorCode,
				@RequestParam(value = "carrierName1", required = false) String carrierName1,
				@RequestParam(value = "carrierName2", required = false) String carrierName2);

		@GetMapping("/airports")
		public List<Airport> getAllAirport(@RequestParam(name = "airportCode", required = false) String airportCode,
				@RequestParam(name = "airportName", required = false) String airportName,
				@RequestParam(name = "cityCode", required = false) String cityCode,
				@RequestParam(name = "cityName", required = false) String cityName,
				@RequestParam(name = "countryCode", required = false) String countryCode);

		@GetMapping("/carriers/{carrierCode}")
		public Carrier getCarrierByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode);

		@GetMapping("/carriers/getCarrierCode/{carrierDesignatorCode}")
		public String getCarrrierCodeByCarrierDesignatorCode(
				@PathVariable(value = "carrierDesignatorCode") String carrierDesignatorCode);

		@GetMapping("/airports/{airportCode}")
		public Airport getAirportByAirportCode(@PathVariable(value = "airportCode") String airportCode);

		@GetMapping("/currencies/{currencyCode}/details")
		public List<CurrencyDetail> getListOfCurrencyDetails(@PathVariable(value = "currencyCode") String currencyCode,
				@RequestParam(value = "effectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate);
		
		@GetMapping("/airports/aiport-list")
		public String getTicketTravelDetail(@RequestParam(name = "airportCodes", required=true) List<String> airportCodes);
	
	    @GetMapping("/validateTicketOverwrite")
		public boolean validateTicketOverwrite(@RequestParam(value = "source1", required = false) String source1,
                @RequestParam(value = "source2", required = false) String source2,
                @RequestParam(value = "processStatus", required = false) String processStatus,
                @RequestParam(value = "transationCode", required = false) String transationCode);
	}

	@FeignClient(value = "smartpra-validations-app")
	public interface SalesValidationFeignClient {
		@PostMapping("/ticketMain/{module}/{source}/{stagingId}")
		/*public ResponseEntity<TicketMain> validateTicketMain(@RequestBody TicketMain ticketMain,
				@PathVariable(value = "module") String module, @PathVariable(value = "source") String source);*/
		public TicketMainValidationDTO validateTicketMain(@RequestBody TicketMain ticketMain,
				@PathVariable(value = "module") String module, @PathVariable(value = "source") String source,@PathVariable(value = "stagingId") long stagingId);
		
		 @GetMapping("/salesBusiness/{module}/{source}/{fileId}")
		 public List<TicketMainValidationDTO> salesBusinessValidationByFileId(@PathVariable(value = "module") String module, @PathVariable(value = "source") String source,@PathVariable(value = "fileId") String fileId) throws ParseException;
		   
	}

	@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface ExceptionTxnFeignClient {
		@PostMapping("/api/init-exceptionmessage")
		public void initExceptionMessage(@RequestBody ExceptionTransactionModel exceptionTransactionModel);
	}
}