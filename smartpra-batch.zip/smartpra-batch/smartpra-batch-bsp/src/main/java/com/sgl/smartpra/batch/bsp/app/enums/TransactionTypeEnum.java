package com.sgl.smartpra.batch.bsp.app.enums;

public enum TransactionTypeEnum {

    CANX("V"),CANR("V"),RFND("R"),RFNC("R"),ACMA("C"),ADMA("D"),DRFND("G"),TKTT("S"), TKTTE("E"), EMD("S"),EMDA("S"),
    EMDS("S"),MDnn("S"),MPnn("S"),MCOM("S"),PTAM("S"),TORM("S"),RCSM("C"),SPCR("C"),SPDR("D"),SSAC("C"),SSAD("D"),TAAD("D"),
    CA("CA"),CC("CC"),MILES("Miles"),LP("LP"),YP("YP"),COMMISSIONS("CO"),DISCOUNT("DI"),Charges("Charges"),
    ADMS("D"), ACMS("S"), MD50("S"),  MD("S");

    String transactionType;

    public String getTransactionType() {
        return transactionType;
    }

    private TransactionTypeEnum(String transactionType) {
        this.transactionType = transactionType;
    }
}
