package com.sgl.smartpra.batch.bsp.app.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SalesFeignClient;
import com.sgl.smartpra.sales.domain.TicketCommission;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketCpnTax;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.TicketOrgin;
import com.sgl.smartpra.sales.domain.TicketPaymentDetail;

@Component
public class TicketOverwriteJobExecutionListener implements ApplicationListener<TicketOverwriteLoadingEvent>
{
	@Autowired
	SalesFeignClient salesFeignClient;
	
	@Override
	@Async
	public void onApplicationEvent(TicketOverwriteLoadingEvent event) {
	  try
	  {	
		if(event.getTicketMain() instanceof TicketMain)
		{
		salesFeignClient.overwriteTicketMain(event.getTicketMain());
		}
		if(event.getTicketCommission() instanceof TicketCommission)
		{
		salesFeignClient.overwriteTicketCommission(event.getTicketCommission());
		}
		if(event.getTicketCoupon() instanceof TicketCoupon)
		{
		salesFeignClient.overwriteTicketCoupon(event.getTicketCoupon());
		}
		if(event.getTicketCpnTax() instanceof TicketCpnTax)
		{
		salesFeignClient.overwriteTicketCpnTax(event.getTicketCpnTax());
		}
		if(event.getTicketOrgin() instanceof TicketOrgin)
		{
		salesFeignClient.overwriteTicketOrgin(event.getTicketOrgin());
		}
		if(event.getTicketPaymentDetail() instanceof TicketPaymentDetail)
		{
		salesFeignClient.overwriteTicketPayment(event.getTicketPaymentDetail());
		}
	  } 
	  catch(Exception e)
	  {
	  }
		
	}

	
}
