package com.sgl.smartpra.batch.bsp.app.listener;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SalesValidationFeignClient;

@Component
public class BSPBusinessValidationDelecationListener implements ApplicationListener<BSPBusinessValidationEvent> {

	@Autowired
	SalesValidationFeignClient salesValidationFeignClient;

	@Override
	@Async
	public void onApplicationEvent(BSPBusinessValidationEvent event) {

			try {
				salesValidationFeignClient.salesBusinessValidationByFileId("Sales", "file", event.getFileId()+"");
			} catch (Exception e) {

			}
		
	}

}
