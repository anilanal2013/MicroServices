package com.sgl.smartpra.batch.bsp.app.writer;

import java.util.List;
import java.util.Optional;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.master.model.AgencyMaster;
@StepScope
public class AgencyMasterWriter implements ItemWriter<AgencyMaster> {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;


	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	
	@Override
	public void write(List<? extends AgencyMaster> items) throws Exception {

		items.forEach(item -> {
			item.setCreatedBy(Optional.of(stepExecution.getJobParameters().getString("user"))); 
			smartpraMasterAppClient.createAgencyMaster(item);
		});

		
	}
}
