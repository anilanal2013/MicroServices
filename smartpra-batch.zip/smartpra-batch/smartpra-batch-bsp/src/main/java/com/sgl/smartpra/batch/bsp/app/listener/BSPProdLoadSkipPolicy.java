package com.sgl.smartpra.batch.bsp.app.listener;

import java.io.FileNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.step.FatalStepExecutionException;
import org.springframework.batch.core.step.item.FaultTolerantChunkProcessor;
import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.orm.jpa.JpaSystemException;

public class BSPProdLoadSkipPolicy implements SkipPolicy {

	private static final Logger logger = LoggerFactory.getLogger(BSPProdLoadSkipPolicy.class);
	@Override
	public boolean shouldSkip(Throwable exception, int skipCount) throws SkipLimitExceededException {
		 if (exception instanceof FileNotFoundException) {
	            return false;
	        } else if (exception instanceof org.springframework.dao.OptimisticLockingFailureException && skipCount <= 1000) {
	        	OptimisticLockingFailureException ffpe = (OptimisticLockingFailureException) exception;
	            StringBuilder errorMessage = new StringBuilder();
	            errorMessage.append("An error occured while loading staging to production " + ffpe.getMessage());
	            logger.error("{}", errorMessage.toString());
	            return true;
	        }  else if (exception instanceof org.springframework.orm.jpa.JpaSystemException && skipCount <= 1000) {
	        	JpaSystemException ffpe = (JpaSystemException) exception;
	            StringBuilder errorMessage = new StringBuilder();
	            errorMessage.append("An error occured while loading staging to production " + ffpe.getCause());
	            logger.error("{}", errorMessage.toString());
	            return true;
	        }else if (exception instanceof FatalStepExecutionException && skipCount <= 1000) {
	        	FatalStepExecutionException ffpe = (FatalStepExecutionException) exception;
	            StringBuilder errorMessage = new StringBuilder();
	            errorMessage.append("An error occured while loading staging to production " + ffpe.getMessage());
	            logger.error("{}", errorMessage.toString());
	            return true;
	        }else if (exception instanceof  org.springframework.dao.CannotAcquireLockException && skipCount <= 1000) {
	        	CannotAcquireLockException ffpe = (CannotAcquireLockException) exception;
	            StringBuilder errorMessage = new StringBuilder();
	            errorMessage.append("An error occured while loading staging to production " + ffpe.getMessage());
	            logger.error("{}", errorMessage.toString());
	            return true;
	        }
	        else {
	            return false;
	        }
	}

}
