package com.sgl.smartpra.batch.bsp.app.processor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import com.hazelcast.util.StringUtil;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoPassengerStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.DocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDCouponDetailStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.FileHeaderStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.TicketDocumentIdentificationStgRepository;
import com.sgl.smartpra.batch.bsp.app.util.BSPConstants;
import com.sgl.smartpra.batch.bsp.app.util.BSPUtil;
import com.sgl.smartpra.batch.global.SalesFileHeader;
import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.sales.domain.TicketMain;

@Component
public class TicketMainProcessor {
	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	FileHeaderStgRepository fileHeaderStgRepository;
	
	@Autowired
	TicketDocumentIdentificationStgRepository ticketDocumentIdentificationStgRepository;
	
	public TicketMain process(String user ,String clientId, TicketDocumentIdentificationStg ticketDocumentIdentificationStg,
			TransactionHeaderStg transactionHeaderStg, int finalDecimalPrecision,int fileId, String fileSource) {
		
		 Logger logger = LoggerFactory.getLogger(this.getClass());

		TicketMain ticketMain = new TicketMain();
		SalesFileHeader salesFile = SalesFileHeader.valueOf(fileSource);
		ticketMain.setClientId(clientId);
		ticketMain.setDocumentUniqueId(clientId + ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3)
				+ ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)
				+ ticketDocumentIdentificationStg.getDateOfIssue().substring(0, 6));
		ticketMain.setIssueAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
		ticketMain.setDocumentNumber(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13).trim());
		ticketMain.setMainDocument(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13).trim());
		ticketMain.setPnr(ticketDocumentIdentificationStg.getPnrRefAirlineDate());
		
//		DocumentAmountsStg documentAmountsStg =null;
		try {
			if(transactionHeaderStg.getDocumentAmountsStgs() != null && !transactionHeaderStg.getDocumentAmountsStgs().isEmpty() )    {
			DocumentAmountsStg documentAmountsStg = transactionHeaderStg.getDocumentAmountsStgs().get(0);
			ticketMain.setFcmi(documentAmountsStg.getFareCalcModeIndicator());
			ticketMain.setFcpi(documentAmountsStg.getFareCalcPricingIndicator());
			}
		} catch (Exception e2) {
			
		}
		
		try {
			EMDCouponDetailStg emdCouponDetailStg = null;
			if(transactionHeaderStg.getEmdCouponDetailStgs() != null  && !transactionHeaderStg.getEmdCouponDetailStgs().isEmpty())    {
			if(transactionHeaderStg.getEmdCouponDetailStgs().get(0)!=null) {
			emdCouponDetailStg = transactionHeaderStg.getEmdCouponDetailStgs().get(0);
			ticketMain.setRfisc(emdCouponDetailStg.getEmdReasonIssuanceSubcode());
			}
			}
		} catch (Exception e2) {
			
		}
		// Driving doc class and type using form code master
		FormCode formCode = null;
		FormCode formCode1 = null;
		String formCodeIssueDate = null;
		try {
			formCodeIssueDate = BSPUtil.getFormattedDate(ticketDocumentIdentificationStg.getDateOfIssue().substring(0, 6), 
					"yyMMdd","yyyy-MM-dd");
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();   
		}
		String formCodeIssueDateOptional = formCodeIssueDate;
		String formCode3Digit = ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 6);
		String formCode2Digit = ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 5);
		
		try {
			formCode = smartpraMasterAppClient.getFormCodeByfromCodeAndEffectiveDate(
					formCode3Digit,formCodeIssueDateOptional);
			} catch (ResponseStatusException ex) {
				if (ex.getStatus() == HttpStatus.NOT_FOUND) {
//					logger.error("form code is not presents for {}",ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 6));
				}

			}catch(Exception ex) {
				
			}       

		try {
			formCode1 = smartpraMasterAppClient.getFormCodeByfromCodeAndEffectiveDate(
					formCode2Digit,formCodeIssueDateOptional);
		}catch (ResponseStatusException ex) {
			if (ex.getStatus() == HttpStatus.NOT_FOUND) {
//				logger.error("form code is not presents for {}",ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 5));
			}

		}catch(Exception ex) {
			
		}

		if (formCode != null) {
			ticketMain.setDocType(formCode.getDocumentType().get());

			if (formCode.getNumberOfCoupon().get() != "0") {
				ticketMain.setDocClass(
						formCode.getDocumentType().get().substring(0, 2) + formCode.getNumberOfCoupon().get());
			} else {
				ticketMain.setDocClass(formCode.getDocumentType().get().substring(0, 2));
			}
		}
		else if (formCode1 != null) {
			ticketMain.setDocType(formCode1.getDocumentType().get());

			if (formCode1.getNumberOfCoupon().get() != "0") {
				ticketMain.setDocClass(
						formCode1.getDocumentType().get().substring(0, 2) + formCode1.getNumberOfCoupon().get());
			} else {
				ticketMain.setDocClass(formCode1.getDocumentType().get().substring(0, 2));
			}
		}

		// Define EMD and Eticket indicators
		if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals(BSPConstants.EMD_ASSOCIATE)) {
			ticketMain.setEmdIndicator(BSPConstants.EMD_INDICATOR_ASSOCIATE);
			ticketMain.setEticketInd(BSPConstants.INDICATOR_YES);
		} else if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals(BSPConstants.EMD_STANDALONE)) {
			ticketMain.setEmdIndicator(BSPConstants.EMD_INDICATOR_STANDALONE);
			ticketMain.setEticketInd(BSPConstants.INDICATOR_NO);
		} else {
			ticketMain.setEticketInd(BSPConstants.ELECTRONIC_TICKET_INDICATOR);
		}
		
		ticketMain.setRfic(ticketDocumentIdentificationStg.getReasonForReissuanceCode());
		
		ticketMain.setDateOfIssue(BSPUtil.getFormattedDate(ticketDocumentIdentificationStg.getDateOfIssue(), "yyMMdd"));

		// Define Passenger details

		if (transactionHeaderStg.getAddlInfoPassengerStgs() != null
				&& !transactionHeaderStg.getAddlInfoPassengerStgs().isEmpty()) {

			AddlInfoPassengerStg addlInfoPassengerStg = transactionHeaderStg.getAddlInfoPassengerStgs().get(0);
			String sDate2 = addlInfoPassengerStg.getDateOfBirth();
			ticketMain.setPassengerName(addlInfoPassengerStg.getPassengerName());
			ticketMain.setPassengerDob(BSPUtil.getFormattedDate(sDate2, "ddMMMyy"));

			BSPUtil bspUtils = new BSPUtil();
			ticketMain.setPaxType(bspUtils.derivePAXType(smartpraMasterAppClient,
					addlInfoPassengerStg.getPassengerName(), BSPUtil.getFormattedDate(sDate2, "ddMMMyy")));

			String paxType = bspUtils.derivePAXType(smartpraMasterAppClient, addlInfoPassengerStg.getPassengerName(),
					BSPUtil.getFormattedDate(sDate2, "ddMMMyy"));

			if (paxType != null && !paxType.isEmpty()) {
				if (paxType == BSPConstants.INDICATOR_I) {
					ticketMain.setRevenueFlag(BSPConstants.INDICATOR_NO);
				} else {
					ticketMain.setRevenueFlag(BSPConstants.INDICATOR_YES);
				}
			} else {
				ticketMain.setRevenueFlag(BSPConstants.INDICATOR_NO);
			}
		}

		// Define agent related details

		String placeOfIssue = null;
		if(ticketDocumentIdentificationStg.getTrueOrgDestCityCode() != null && !ticketDocumentIdentificationStg.getTrueOrgDestCityCode().isEmpty()) {
			try {
				placeOfIssue = ticketDocumentIdentificationStg.getTrueOrgDestCityCode().trim().substring(0,3);
			} catch (IndexOutOfBoundsException e) {
			}
		}
		if(placeOfIssue != null && !placeOfIssue.isEmpty()) {
		 ticketMain.setPlaceOfIssue(placeOfIssue);
		 ticketMain.setPlaceOfSale(placeOfIssue);
		}
		ticketMain.setReportingAgentCode(BSPConstants.REPORTING_AGENCY);
		ticketMain.setBookingAgent(ticketDocumentIdentificationStg.getAgentNumericCode());
		ticketMain.setAgentCode(ticketDocumentIdentificationStg.getAgentNumericCode());

		// Define fare calculations
		if (!transactionHeaderStg.getFareCalculationStgs().isEmpty()) {
			StringBuilder fca = new StringBuilder();
			for (int i = 0; i < transactionHeaderStg.getFareCalculationStgs().size(); i++) {
				fca = fca.append(transactionHeaderStg.getFareCalculationStgs().get(i).getFareCalcArea());
			}
			ticketMain.setFca(fca.toString());
		}

		// Define TDAM, NetFareAmount, NetFareCurrency, GrossFare
		if (transactionHeaderStg.getStdDocumentAmountsStg() != null
				&& !transactionHeaderStg.getStdDocumentAmountsStg().isEmpty()) {
			String tdamValue = transactionHeaderStg.getStdDocumentAmountsStg().get(0).getTktDocAmount();
			if (!tdamValue.isEmpty() && tdamValue != null) {

				String tdamSign = BSPUtil.getSignedFieldValue(tdamValue);
				String tdamString = BSPUtil.getSignedFieldStringValue(tdamSign, finalDecimalPrecision);
				BigDecimal tdam = BSPUtil.getvalidatedBigDecimal(tdamString);
				ticketMain.setTdam(tdam);
			}
			
			String netFareAmountValue = transactionHeaderStg.getStdDocumentAmountsStg().get(0).getNetFareAmount();
			if (!netFareAmountValue.isEmpty() && netFareAmountValue != null) {
				String netAmountSign = BSPUtil.getSignedFieldValue(netFareAmountValue);
				String netAmountString = BSPUtil.getSignedFieldStringValue(netAmountSign, finalDecimalPrecision);
				BigDecimal netAmount = BSPUtil.getvalidatedBigDecimal(netAmountString);
				ticketMain.setNetFareAmount(netAmount);
			}
			
			if (transactionHeaderStg.getStdDocumentAmountsStg().get(0).getCurrencyType().length() > 0) {
				int netFareCurrency = 0;
				if (transactionHeaderStg.getStdDocumentAmountsStg().get(0).getCurrencyType().length() > 0
						&& transactionHeaderStg.getStdDocumentAmountsStg().get(0).getCurrencyType().length() <= 3) {
					netFareCurrency = transactionHeaderStg.getStdDocumentAmountsStg().get(0).getCurrencyType().length();
					ticketMain.setNetFareCurrency(transactionHeaderStg.getStdDocumentAmountsStg().get(0)
							.getCurrencyType().substring(0, netFareCurrency));
				} else {
					ticketMain.setNetFareCurrency(
							transactionHeaderStg.getStdDocumentAmountsStg().get(0).getCurrencyType().substring(0, 3));
				}
			}
			
			if (!StringUtil.isNullOrEmpty(ticketMain.getBtItIndicator())) {
				if ((ticketMain.getBtItIndicator().contentEquals(BSPConstants.INDICATOR_I)
						|| ticketMain.getBtItIndicator().contentEquals(BSPConstants.INDICATOR_B))
						&& !StringUtil.isNullOrEmpty(ticketMain.getNetFareCurrency())) {
					ticketMain.setCurrencyOfSale(ticketMain.getNetFareCurrency());
					String commissionableAmount = transactionHeaderStg.getStdDocumentAmountsStg().get(0)
							.getCommissionableAmount();

					if (!commissionableAmount.isEmpty() && commissionableAmount != null) {
						String commissionableAmountSign = BSPUtil.getSignedFieldValue(commissionableAmount);
						String commissionableAmountString = BSPUtil.getSignedFieldStringValue(commissionableAmountSign,
								finalDecimalPrecision);
						BigDecimal commissionableAmountActual = BSPUtil
								.getvalidatedBigDecimal(commissionableAmountString);
						ticketMain.setGrossFare(commissionableAmountActual);

					}

				}
			}

		}
		
		// Define prime or reissue
		boolean setPrimeReissueValue = false;
		if (transactionHeaderStg.getFormOfPaymentStg() != null
				&& !transactionHeaderStg.getFormOfPaymentStg().isEmpty()) {
			for (int i = 0; i < transactionHeaderStg.getFormOfPaymentStg().size(); i++) {
				if (transactionHeaderStg.getFormOfPaymentStg().get(i).getFopType().substring(0, 2)
						.contentEquals(BSPConstants.FOP_TYPE_EXCHANGE)) {
					setPrimeReissueValue = true;
					;
					ticketMain.setPrimeReissue(BSPConstants.TICKET_TYPE_REISSUE);
				} else if (!setPrimeReissueValue) {
					ticketMain.setPrimeReissue(BSPConstants.TICKET_TYPE_PRIME);
				}
				if (transactionHeaderStg.getFormOfPaymentStg().get(i).getFopType().substring(0, 2)
						.contentEquals(BSPConstants.FOP_TYPE_TP)) {
					ticketMain.setUatpFlag(BSPConstants.INDICATOR_YES);
				} else {
					ticketMain.setUatpFlag(BSPConstants.INDICATOR_NO);
				}
			}
		} else {
			ticketMain.setPrimeReissue(BSPConstants.TICKET_TYPE_PRIME);
			ticketMain.setUatpFlag(BSPConstants.INDICATOR_NO);
		}

		// Define Conjunction Ticket or not
		
		
		if (ticketDocumentIdentificationStg.getConjuctionTicketIndicator() != null && (ticketDocumentIdentificationStg
				.getConjuctionTicketIndicator().contentEquals(BSPConstants.TICKET_TYPE_CNJ))) {
			//Setting original document's main document number as conj's main document number
			Optional<TicketDocumentIdentificationStg> ticketDocumentIdentificationStgLive = ticketDocumentIdentificationStgRepository
					.findOneByFileHdrIdAndTransactionHdrIdAndConjuctionTicketIndicatorLike(
							ticketDocumentIdentificationStg.getFileHdrId(),
							ticketDocumentIdentificationStg.getTransactionHdrId(), "");
			if (ticketDocumentIdentificationStgLive.isPresent()) {
				ticketMain.setMainDocument(
						ticketDocumentIdentificationStgLive.get().getTktDocNumber().substring(3, 13).trim());
			}
			ticketMain.setConjTicketIndicator(BSPConstants.INDICATOR_YES);
		} else {

			ticketMain.setConjTicketIndicator(BSPConstants.INDICATOR_NO);
		}

		// Define all original details
		if (transactionHeaderStg.getQualIssueInfoStgs() != null
				&& !transactionHeaderStg.getQualIssueInfoStgs().isEmpty()) {
			int originalIssueAirlineLength = 0;
			int originalDocumentNumberLength = 0;
			if (transactionHeaderStg.getQualIssueInfoStgs().get(0).getOriginalIssueDocTktNumber().length() > 0) {
				if (transactionHeaderStg.getQualIssueInfoStgs().get(0).getOriginalIssueDocTktNumber().length() > 0
						&& transactionHeaderStg.getQualIssueInfoStgs().get(0).getOriginalIssueDocTktNumber()
								.length() <= 3) {
					originalIssueAirlineLength = transactionHeaderStg.getQualIssueInfoStgs().get(0)
							.getOriginalIssueDocTktNumber().length();
					ticketMain.setOriginalIssueAirline(transactionHeaderStg.getQualIssueInfoStgs().get(0)
							.getOriginalIssueDocTktNumber().substring(0, originalIssueAirlineLength));
				} else {
					ticketMain.setOriginalIssueAirline(transactionHeaderStg.getQualIssueInfoStgs().get(0)
							.getOriginalIssueDocTktNumber().substring(0, 3));

				}
				if (transactionHeaderStg.getQualIssueInfoStgs().get(0).getOriginalIssueDocTktNumber().length() > 3
						&& transactionHeaderStg.getQualIssueInfoStgs().get(0).getOriginalIssueDocTktNumber()
								.length() <= 13) {
					originalDocumentNumberLength = transactionHeaderStg.getQualIssueInfoStgs().get(0)
							.getOriginalIssueDocTktNumber().length();
					ticketMain.setOriginalDocumentNumber(transactionHeaderStg.getQualIssueInfoStgs().get(0)
							.getOriginalIssueDocTktNumber().substring(3, originalDocumentNumberLength));
	
					FormCode formCodeOrg = null;
					FormCode formCode1Org = null;
					String formCodeIssueDate1 = null;
					try {
						if (salesFile.getFileType().equals("ARC")) {
							formCodeIssueDate1 = BSPUtil.getFormattedDate(transactionHeaderStg.getQualIssueInfoStgs().get(0).getDateOfIssue(), 
									"yyMMdd","yyyy-MM-dd");
						} else {
							formCodeIssueDate1 = BSPUtil.getFormattedDate(transactionHeaderStg.getQualIssueInfoStgs().get(0).getOriginalIssueDate(), 
									"yyMMMdd","yyyy-MM-dd");
						}
						
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();   
					}
					String formCodeIssueDateOptional1 = formCodeIssueDate1;
					String formCode3Digit1 = transactionHeaderStg.getQualIssueInfoStgs().get(0)
							.getOriginalIssueDocTktNumber().substring(3, 6);
					String formCode2Digit1 = transactionHeaderStg.getQualIssueInfoStgs().get(0)
							.getOriginalIssueDocTktNumber().substring(3, 5);
					
					try {
						formCodeOrg = smartpraMasterAppClient.getFormCodeByfromCodeAndEffectiveDate(
								formCode3Digit1,formCodeIssueDateOptional1);
						} catch (ResponseStatusException ex) {
							if (ex.getStatus() == HttpStatus.NOT_FOUND) {
//								logger.error("form code is not presents for {}",ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 6));
							}

						}catch(Exception ex) {
							
						}       

					try {
						formCode1Org = smartpraMasterAppClient.getFormCodeByfromCodeAndEffectiveDate(
								formCode2Digit1,formCodeIssueDateOptional1);
					}catch (ResponseStatusException ex) {
						if (ex.getStatus() == HttpStatus.NOT_FOUND) {
//							logger.error("form code is not presents for {}",ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 5));
						}

					}catch(Exception ex) {
						
					}

					if (formCodeOrg != null) {
						ticketMain.setOriginalDocType(formCodeOrg.getDocumentType().get());

						if (formCodeOrg.getNumberOfCoupon().get() != "0") {
							ticketMain.setOriginalDocClass(
									formCodeOrg.getDocumentType().get().substring(0, 2) + formCodeOrg.getNumberOfCoupon().get());
						} else {
							ticketMain.setOriginalDocClass(formCodeOrg.getDocumentType().get().substring(0, 2));
						}
					}
					else if (formCode1Org != null) {
						ticketMain.setOriginalDocType(formCode1Org.getDocumentType().get());

						if (formCode1Org.getNumberOfCoupon().get() != "0") {
							ticketMain.setOriginalDocClass(
									formCode1Org.getDocumentType().get().substring(0, 2) + formCode1Org.getNumberOfCoupon().get());
						} else {
							ticketMain.setOriginalDocClass(formCode1Org.getDocumentType().get().substring(0, 2));
						}
					}
				}
			}
			String sDate2 = transactionHeaderStg.getQualIssueInfoStgs().get(0).getOriginalIssueDate();
			ticketMain.setOriginalDateOfIssue(BSPUtil.getFormattedDate(sDate2, "ddMMMyy"));
			ticketMain.setOriginalPlaceOfIssue(
					transactionHeaderStg.getQualIssueInfoStgs().get(0).getOriginalIssueLocCityCode());
			
			String orgAgentCode = transactionHeaderStg.getQualIssueInfoStgs().get(0).getOriginalIssueAgentCode();
			if(orgAgentCode!=null && !orgAgentCode.contentEquals("00000000")) {
			ticketMain.setOriginalAgentCode(orgAgentCode);
			}

			StringBuilder endorsements = new StringBuilder();
			for (int i = 0; i < transactionHeaderStg.getQualIssueInfoStgs().size(); i++) {
				endorsements = endorsements
						.append(transactionHeaderStg.getQualIssueInfoStgs().get(i).getEndorsementRestriction());
			}
			ticketMain.setEndorsements(endorsements.toString());
		}

		// Define currency and amounts
		if (transactionHeaderStg.getDocumentAmountsStgs() != null
				&& !transactionHeaderStg.getDocumentAmountsStgs().isEmpty()) {
			if (!transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare().isEmpty()
					&& transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare().length() > 3) {
				int grossFareLength = 0;
				grossFareLength = transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare().length();

				Pattern p = Pattern.compile("[a-zA-Z]"); // the pattern to search for
				Matcher m = p.matcher(transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare()
						.substring(3, grossFareLength).trim());
				Boolean b1 = m.find();

				if (!b1) {
					ticketMain.setGrossFare(BSPUtil.getvalidatedBigDecimal(transactionHeaderStg.getDocumentAmountsStgs()
							.get(0).getFare().substring(3, grossFareLength).trim()));
				}
			} else {
				ticketMain.setGrossFare(new BigDecimal(0));
			}

			if (transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare().length() > 0
					&& transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare().length() <= 3) {
				int currencyOfSaleLength = 0;
				currencyOfSaleLength = transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare().length();
				ticketMain.setCurrencyOfSale(transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare().substring(0,
						currencyOfSaleLength));
			} else {
				ticketMain.setCurrencyOfSale(
						transactionHeaderStg.getDocumentAmountsStgs().get(0).getFare().substring(0, 3));
			}

			if (ticketMain.getCurrencyOfSale().contains(BSPConstants.BT_INDICATOR_I)) {
				ticketMain.setBtItIndicator(BSPConstants.INDICATOR_I);
				ticketMain.setCurrencyOfSale(transactionHeaderStg.getStdDocumentAmountsStg().get(0).getCurrencyType().substring(0, 3));
				ticketMain.setGrossFare(ticketMain.getNetFareAmount());
			} else if (ticketMain.getCurrencyOfSale().contains(BSPConstants.BT_INDICATOR_B)) {
				ticketMain.setBtItIndicator(BSPConstants.INDICATOR_B);
				ticketMain.setCurrencyOfSale(transactionHeaderStg.getStdDocumentAmountsStg().get(0).getCurrencyType().substring(0, 3));
				ticketMain.setGrossFare(ticketMain.getNetFareAmount());
			} else {
				ticketMain.setBtItIndicator(BSPConstants.INDICATOR_NO);
			}

			if (transactionHeaderStg.getDocumentAmountsStgs().get(0).getEquivalentFarePaid().length() > 0) {
				ticketMain.setEquivalentCurrencyOfSale(
						transactionHeaderStg.getDocumentAmountsStgs().get(0).getEquivalentFarePaid().substring(0, 3));
			}

			if (!transactionHeaderStg.getDocumentAmountsStgs().get(0).getEquivalentFarePaid().isEmpty()
					&& transactionHeaderStg.getDocumentAmountsStgs().get(0).getEquivalentFarePaid().length() > 3) {
				int equivalentFareLength = 0;
				equivalentFareLength = transactionHeaderStg.getDocumentAmountsStgs().get(0).getEquivalentFarePaid()
						.length();

				Pattern p = Pattern.compile("[a-zA-Z]"); // the pattern to search for
				Matcher m = p.matcher(transactionHeaderStg.getDocumentAmountsStgs().get(0).getEquivalentFarePaid()
						.substring(3, equivalentFareLength).trim());
				Boolean b = m.find();

				if (!b) {
					ticketMain.setEquivalentFare(
							BSPUtil.getvalidatedBigDecimal(transactionHeaderStg.getDocumentAmountsStgs().get(0)
									.getEquivalentFarePaid().substring(3, equivalentFareLength).trim()));
				}
			} else {
				ticketMain.setEquivalentFare(new BigDecimal(0));
			}

			ticketMain.setAirlineIssuingAgent(
					transactionHeaderStg.getDocumentAmountsStgs().get(0).getAirlineIssuingAgent());
		}

		ticketMain.setRfic(ticketDocumentIdentificationStg.getReasonForReissuanceCode());
	    ticketMain.setTourCode(ticketDocumentIdentificationStg.getTourCode());
		ticketMain.setTransactionCodeReceived(ticketDocumentIdentificationStg.getTransactionCode());
		ticketMain.setTimeOfIssue(ticketDocumentIdentificationStg.getTimeOfIssue());
		ticketMain.setCodeShareIndicator(BSPConstants.INDICATOR_NO);
		ticketMain.setFfyIndicator(BSPConstants.INDICATOR_NO);
		ticketMain.setFirstTimeProcessed(BSPConstants.INDICATOR_YES);
		ticketMain.setRevenueFlag(BSPConstants.INDICATOR_NO);

		String reportedDate = "";
		Timestamp timeStampDate = null;
		try {
			Optional<FileHeaderStg> fileHeaderStg = fileHeaderStgRepository
					.findById(ticketDocumentIdentificationStg.getFileHdrId());

			if (fileHeaderStg.isPresent()) {
				reportedDate = fileHeaderStg.get().getProcessingDate();
			}

			if (!reportedDate.isEmpty()) {
				Date effectiveFromDate;
				try {
					effectiveFromDate = new SimpleDateFormat("yyMMdd").parse(reportedDate);
					timeStampDate = new Timestamp(effectiveFromDate.getTime());
				} catch (Exception e) {

				}

			}
		} catch (Exception e) {

		}
		if (timeStampDate != null) {
			ticketMain.setReportedDate(timeStampDate);
		} else {
			ticketMain.setReportedDate(new Timestamp(0));
		}
		
		ticketMain.setInvolIndicator(BSPConstants.INDICATOR_NO);
		ticketMain.setIgnoreFca(BSPConstants.INDICATOR_NO);
		ticketMain.setFileId(transactionHeaderStg.getFileHdrId());
		
		ticketMain.setProrationMethod(BSPConstants.INDICATOR_NO);
		ticketMain.setFileSource(fileSource);
		ticketMain.setDataSource(fileSource);
		ticketMain.setFreeAwardTicketIndicator(BSPConstants.INDICATOR_NO);
		ticketMain.setSalesProcessIndicator(BSPConstants.INDICATOR_NO);
		ticketMain.setTaxProcessIndicator(BSPConstants.INDICATOR_NO);
		if (SalesFileHeader.valueOf(fileSource) == SalesFileHeader.BSP) {
			ticketMain.setNrid(transactionHeaderStg.getNetReportingIndicator().trim());
		}
		ticketMain.setRpsi(transactionHeaderStg.getReportingSystemIdentifier());
		ticketMain.setCouponUseIndicator(ticketDocumentIdentificationStg.getCpnUseIndicator());
		if (ticketDocumentIdentificationStg.getTrueOrgDestCityCode() != null
				&& !ticketDocumentIdentificationStg.getTrueOrgDestCityCode().isEmpty()) {
			ticketMain.setTrueOrigin(ticketDocumentIdentificationStg.getTrueOrgDestCityCode().substring(0, 3));
			if (ticketDocumentIdentificationStg.getTrueOrgDestCityCode().length() > 3) {
				int orgDesLength = ticketDocumentIdentificationStg.getTrueOrgDestCityCode().length();
				ticketMain.setTrueDestination(
						ticketDocumentIdentificationStg.getTrueOrgDestCityCode().substring(3, orgDesLength));
			}

		}

		if (transactionHeaderStg.getEmdCouponDetailStgs() != null
				&& !transactionHeaderStg.getEmdCouponDetailStgs().isEmpty()) {
			ticketMain.setPieceWeightIndicator(
					transactionHeaderStg.getEmdCouponDetailStgs().get(0).getEmdEbdOverAllowQualifier());
			ticketMain.setExcessWeight(transactionHeaderStg.getEmdCouponDetailStgs().get(0).getEmdEbtTotalNoExcess());
		}
		
		ticketMain.setFileId(fileId);
		ticketMain.setStatus(BSPConstants.TICKET_STATUS_READY_FOR_VALIDATION);

		// Define table level audit columns
//		ticketMain.setLastUpdatedBy(user);
		ticketMain.setCreatedBy(user);
//		ticketMain.setLastUpdatedDate(new Timestamp(new Date().getTime()));
		ticketMain.setCreatedDate(new Timestamp(new Date().getTime()));
		return ticketMain;
	}
}
