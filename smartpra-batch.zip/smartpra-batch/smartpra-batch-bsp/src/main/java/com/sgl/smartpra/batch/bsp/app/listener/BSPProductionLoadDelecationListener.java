package com.sgl.smartpra.batch.bsp.app.listener;

import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.service.BSPJobLauncher;
@Component
public class BSPProductionLoadDelecationListener implements ApplicationListener<BSPProdLoadingEvent> {

	@Autowired
	BSPJobLauncher bSPJobLauncher;

	@Override
	@Async
	public void onApplicationEvent(BSPProdLoadingEvent event) {
		try {
			bSPJobLauncher.launchBSPProdLoadJob(event.getFileId(), event.getUserName());
		} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
				| JobParametersInvalidException e) {
			
		}
	}

}
