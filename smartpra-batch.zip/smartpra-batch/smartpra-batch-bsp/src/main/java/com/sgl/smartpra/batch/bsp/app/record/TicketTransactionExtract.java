package com.sgl.smartpra.batch.bsp.app.record;

import java.io.Serializable;
import java.util.ArrayList;

public class TicketTransactionExtract implements Serializable{
	

	private int ticketExtractId;

	private String acmAdmNo;

	private String clientId;

	private String documentUniqueId;

	private int fileId;

	private String fileSource;

	private String mainDocumemnt;

	private String refundNo;

	private int transactionHdrId;

	private String transactionInfo;

	private int transactionInfoId;
	
	private ArrayList<String> record;

	/**
	 * @return the record
	 */
	public ArrayList<String> getRecord() {
		return record;
	}

	/**
	 * @param record the record to set
	 */
	public void setRecord(ArrayList<String> record) {
		this.record = record;
	}

	/**
	 * @return the ticketExtractId
	 */
	public int getTicketExtractId() {
		return ticketExtractId;
	}

	/**
	 * @param ticketExtractId the ticketExtractId to set
	 */
	public void setTicketExtractId(int ticketExtractId) {
		this.ticketExtractId = ticketExtractId;
	}

	/**
	 * @return the acmAdmNo
	 */
	public String getAcmAdmNo() {
		return acmAdmNo;
	}

	/**
	 * @param acmAdmNo the acmAdmNo to set
	 */
	public void setAcmAdmNo(String acmAdmNo) {
		this.acmAdmNo = acmAdmNo;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the documentUniqueId
	 */
	public String getDocumentUniqueId() {
		return documentUniqueId;
	}

	/**
	 * @param documentUniqueId the documentUniqueId to set
	 */
	public void setDocumentUniqueId(String documentUniqueId) {
		this.documentUniqueId = documentUniqueId;
	}

	/**
	 * @return the fileId
	 */
	public int getFileId() {
		return fileId;
	}

	/**
	 * @param fileId the fileId to set
	 */
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	/**
	 * @return the fileSource
	 */
	public String getFileSource() {
		return fileSource;
	}

	/**
	 * @param fileSource the fileSource to set
	 */
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}

	/**
	 * @return the mainDocumemnt
	 */
	public String getMainDocumemnt() {
		return mainDocumemnt;
	}

	/**
	 * @param mainDocumemnt the mainDocumemnt to set
	 */
	public void setMainDocumemnt(String mainDocumemnt) {
		this.mainDocumemnt = mainDocumemnt;
	}

	/**
	 * @return the refundNo
	 */
	public String getRefundNo() {
		return refundNo;
	}

	/**
	 * @param refundNo the refundNo to set
	 */
	public void setRefundNo(String refundNo) {
		this.refundNo = refundNo;
	}

	/**
	 * @return the transactionHdrId
	 */
	public int getTransactionHdrId() {
		return transactionHdrId;
	}

	/**
	 * @param transactionHdrId the transactionHdrId to set
	 */
	public void setTransactionHdrId(int transactionHdrId) {
		this.transactionHdrId = transactionHdrId;
	}

	/**
	 * @return the transactionInfo
	 */
	public String getTransactionInfo() {
		return transactionInfo;
	}

	/**
	 * @param transactionInfo the transactionInfo to set
	 */
	public void setTransactionInfo(String transactionInfo) {
		this.transactionInfo = transactionInfo;
	}

	/**
	 * @return the transactionInfoId
	 */
	public int getTransactionInfoId() {
		return transactionInfoId;
	}

	/**
	 * @param transactionInfoId the transactionInfoId to set
	 */
	public void setTransactionInfoId(int transactionInfoId) {
		this.transactionInfoId = transactionInfoId;
	}



}
