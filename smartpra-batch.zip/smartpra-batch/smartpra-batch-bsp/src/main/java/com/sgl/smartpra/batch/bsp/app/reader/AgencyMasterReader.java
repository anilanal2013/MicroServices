package com.sgl.smartpra.batch.bsp.app.reader;

import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bsp.app.util.BSPConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.master.model.SystemParameter;

@StepScope
public class AgencyMasterReader implements ItemReader<AgencyMaster> {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Override
	public AgencyMaster read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

		String clientId = stepExecution.getJobExecution().getExecutionContext().getString("clientId");

		Map<String, String> agentCodeMap = (Map<String, String>) stepExecution.getJobExecution().getExecutionContext()
				.get("agentCode");

		String autoCreation = "";

		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient
				.getSystemParameterByparameterName(BSPConstants.PAR_AUTO_CREATE_AGENT);

		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			autoCreation = OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());
		}
		Set<String> agencyCodeSet = agentCodeMap.keySet();

	
		AgencyMaster agencyMaster  = null;

		if (autoCreation.contentEquals("Y")) {
			for (String agencyCode : agencyCodeSet) {
				
				boolean createNew = false;
				try {
					smartpraMasterAppClient.getAgencyByAgencyCode(agencyCode, clientId);
				} catch (ResponseStatusException ex) {
					if (ex.getStatus() == HttpStatus.NOT_FOUND) {
						createNew = true;
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
				if (createNew) {

					agencyMaster  = new AgencyMaster();
					agencyMaster.setAgencyCode(Optional.of(agencyCode));
					agencyMaster.setClientId(Optional.of(clientId));
					agencyMaster.setReportingAgency(Optional.of(BSPConstants.REPORTING_AGENCY));
					agencyMaster.setReportingAgencyType(Optional.of(BSPConstants.REPORTING_AGENCY_TYPE));

				} 
			}
		}
		return agencyMaster;
	}

}
