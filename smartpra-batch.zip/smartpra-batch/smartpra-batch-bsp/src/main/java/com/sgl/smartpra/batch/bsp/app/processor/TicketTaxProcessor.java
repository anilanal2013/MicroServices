package com.sgl.smartpra.batch.bsp.app.processor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.domain.staging.StdDocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.util.BSPConstants;
import com.sgl.smartpra.batch.bsp.app.util.BSPUtil;
import com.sgl.smartpra.batch.global.SalesFileHeader;
import com.sgl.smartpra.sales.domain.TicketTax;
import com.sgl.smartpra.sales.repository.TicketTaxRepository;

@Component
public class TicketTaxProcessor {
	List<String> admAcmCheck = Arrays.asList("ADM", "ACM", "RCS", "SPD", "SSA", "TAA");
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	TicketTaxRepository taxRepository;

	public Map<String, List<TicketTax>> process(String user,String clientId, TicketDocumentIdentificationStg ticketDocumentIdentificationStg,
			TransactionHeaderStg transactionHeaderStg, Map<String, String> ticketDoc, Integer decimalPrecision,Map<String, String> ticketTaxGMap,boolean ticketRefundData,Integer fileId) {
		List<TicketTax> ticketTaxs = new LinkedList<>();
		Long docNum = Long.parseLong(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));

		Map<String, List<TicketTax>> ticketTaxMap = new HashMap<>();
		List<TicketTax> ticketTaxTicket = new ArrayList<>();
		List<TicketTax> ticketTaxNonTicket = new ArrayList<>();

		List<StdDocumentAmountsStg> standaredAmountStg1s = transactionHeaderStg.getStdDocumentAmountsStg();
		if (!standaredAmountStg1s.isEmpty()) {
			int count1 = 0;
			for (int i = 0; i < standaredAmountStg1s.size(); i++) {
				

				if ((!standaredAmountStg1s.isEmpty()
						&& docNum == Long.parseLong(standaredAmountStg1s.get(i).getTktDocNumber().substring(3, 13)))
						|| (!ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")
								&& !admAcmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)))) {

					TicketTax ticketTax = new TicketTax();

					if (!standaredAmountStg1s.get(i).getTaxMiscFeeType1().isEmpty()) {
						ticketTax = new TicketTax();
						ticketTax.setSerialNo(++count1);

						String taxCode = standaredAmountStg1s.get(i).getTaxMiscFeeType1();
						for (int h = 0; h < taxCode.length() - 1; h++) {
							if (taxCode.charAt(h) > 64 && taxCode.charAt(h) <= 90) {
								char main = taxCode.charAt(h);
								char end = taxCode.charAt(h + 1);
								taxCode = main + "" + end;
								ticketTax.setTaxCode(taxCode);
							} else {
								ticketTax.setTaxCode(standaredAmountStg1s.get(i).getTaxMiscFeeType1());
							}
						}

						String taxAmountValue = standaredAmountStg1s.get(i).getTaxMiscFeeAmount1();
						if (!taxAmountValue.isEmpty() && taxAmountValue != null) {
							String taxAmountSign = BSPUtil.getSignedFieldValue(taxAmountValue);
							String taxAmountString = BSPUtil.getSignedFieldStringValue(taxAmountSign, decimalPrecision);
							BigDecimal taxAmount = BSPUtil.getvalidatedBigDecimal(taxAmountString);
							ticketTax.setTaxAmount(taxAmount);
						}
						if (standaredAmountStg1s.get(i).getCurrencyType().length() > 0) {
							int taxCurrency = 0;
							if (standaredAmountStg1s.get(i).getCurrencyType().length() > 0
									&& standaredAmountStg1s.get(i).getCurrencyType().length() <= 3) {
								taxCurrency = standaredAmountStg1s.get(i).getCurrencyType().length();
								ticketTax.setTaxCurrency(
										standaredAmountStg1s.get(i).getCurrencyType().substring(0, taxCurrency));
							} else if (standaredAmountStg1s.get(i).getCurrencyType().length() > 3) {
								ticketTax.setTaxCurrency(standaredAmountStg1s.get(i).getCurrencyType().substring(0, 3));
							}
						}
						ticketTax.setMainDocument(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
						ticketTax.setDocumentNumber(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
						ticketTax.setIssueAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
						String docId = clientId + ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3)
								+ ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13) + ticketDocumentIdentificationStg.getDateOfIssue().substring(0, 6);
						ticketTax.setDocumentUniqueId(docId);
						ticketTax.setCreatedBy(user);
						ticketTax.setCreatedDate(new Timestamp(new Date().getTime()));
						ticketTax.setFileId(fileId);
//						if (!ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if (!checkDuplicate(ticketTax,ticketTaxGMap)) {
								ticketTaxTicket.add(ticketTax);
							}
//						}
					/*	if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if(!ticketDoc.get("documentUniqueIdRefund").isEmpty()) {
								ticketTax.setDocumentUniqueId(ticketDoc.get("documentUniqueIdRefund"));
							}
							if (!checkDuplicate(ticketTax,ticketTaxGMap)) {
								ticketTaxNonTicket.add(ticketTax);
							}
						}
					*/}

					if (!standaredAmountStg1s.get(i).getTaxMiscFeeType2().isEmpty()) {
						ticketTax = new TicketTax();
						ticketTax.setSerialNo(++count1);
						String taxCode = standaredAmountStg1s.get(i).getTaxMiscFeeType2();
						for (int h = 0; h < taxCode.length() - 1; h++) {
							if (taxCode.charAt(h) > 64 && taxCode.charAt(h) <= 90) {
								char main = taxCode.charAt(h);
								char end = taxCode.charAt(h + 1);
								taxCode = main + "" + end;
								ticketTax.setTaxCode(taxCode);
							} else {
								ticketTax.setTaxCode(standaredAmountStg1s.get(i).getTaxMiscFeeType2());
							}
						}

						String taxAmount2Value = standaredAmountStg1s.get(i).getTaxMiscFeeAmount2();
						if (!taxAmount2Value.isEmpty() && taxAmount2Value != null) {
							String taxAmount2Sign = BSPUtil.getSignedFieldValue(taxAmount2Value);
							String taxAmount2String = BSPUtil.getSignedFieldStringValue(taxAmount2Sign, decimalPrecision);
							BigDecimal taxAmount2 = BSPUtil.getvalidatedBigDecimal(taxAmount2String);
							ticketTax.setTaxAmount(taxAmount2);
						}
						if (standaredAmountStg1s.get(i).getCurrencyType().length() > 0) {
							int taxCurrency = 0;
							if (standaredAmountStg1s.get(i).getCurrencyType().length() > 0
									&& standaredAmountStg1s.get(i).getCurrencyType().length() <= 3) {
								taxCurrency = standaredAmountStg1s.get(i).getCurrencyType().length();
								ticketTax.setTaxCurrency(
										standaredAmountStg1s.get(i).getCurrencyType().substring(0, taxCurrency));
							} else if (standaredAmountStg1s.get(i).getCurrencyType().length() > 3) {
								ticketTax.setTaxCurrency(standaredAmountStg1s.get(i).getCurrencyType().substring(0, 3));
							}
						}
						ticketTax.setMainDocument(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
						ticketTax.setDocumentNumber(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
						ticketTax.setIssueAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
						String docId = clientId + ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3)
								+ ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13) + ticketDocumentIdentificationStg.getDateOfIssue().substring(0, 6);
						ticketTax.setDocumentUniqueId(docId);
						ticketTax.setCreatedBy(user);
						ticketTax.setFileId(fileId);
						ticketTax.setCreatedDate(new Timestamp(new Date().getTime()));
//						if (!ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if (!checkDuplicate(ticketTax,ticketTaxGMap)) {
								ticketTaxTicket.add(ticketTax);
							}
//						}
					/*	if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							if(!ticketDoc.get("documentUniqueIdRefund").isEmpty()) {
								ticketTax.setDocumentUniqueId(ticketDoc.get("documentUniqueIdRefund"));
							}
							if (!checkDuplicate(ticketTax,ticketTaxGMap)) {
								ticketTaxNonTicket.add(ticketTax);
							}
						}*/

					}
					
					if (SalesFileHeader.valueOf(ticketDoc.get(BSPConstants.SOURCE)) == SalesFileHeader.BSP) { 
						if (!standaredAmountStg1s.get(i).getTaxMiscFeeType3().isEmpty()) {
							ticketTax = new TicketTax();
							ticketTax.setSerialNo(++count1);
							String taxCode = standaredAmountStg1s.get(i).getTaxMiscFeeType3();
							for (int h = 0; h < taxCode.length() - 1; h++) {
								if (taxCode.charAt(h) > 64 && taxCode.charAt(h) <= 90) {
									char main = taxCode.charAt(h);
									char end = taxCode.charAt(h + 1);
									taxCode = main + "" + end;
									ticketTax.setTaxCode(taxCode);
								} else {
									ticketTax.setTaxCode(standaredAmountStg1s.get(i).getTaxMiscFeeType3());
								}

								String taxAmount3Value = standaredAmountStg1s.get(i).getTaxMiscFeeAmount3();
								if (!taxAmount3Value.isEmpty() && taxAmount3Value != null) {
									String taxAmount3Sign = BSPUtil.getSignedFieldValue(taxAmount3Value);
									String taxAmount3String = BSPUtil.getSignedFieldStringValue(taxAmount3Sign,
											decimalPrecision);
									BigDecimal taxAmount3 = BSPUtil.getvalidatedBigDecimal(taxAmount3String);
									ticketTax.setTaxAmount(taxAmount3);
								}
								if (standaredAmountStg1s.get(i).getCurrencyType().length() > 0) {
									int taxCurrency = 0;
									if (standaredAmountStg1s.get(i).getCurrencyType().length() > 0
											&& standaredAmountStg1s.get(i).getCurrencyType().length() <= 3) {
										taxCurrency = standaredAmountStg1s.get(i).getCurrencyType().length();
										ticketTax.setTaxCurrency(
												standaredAmountStg1s.get(i).getCurrencyType().substring(0, taxCurrency));
									} else if (standaredAmountStg1s.get(i).getCurrencyType().length() > 3) {
										ticketTax.setTaxCurrency(
												standaredAmountStg1s.get(i).getCurrencyType().substring(0, 3));
									}

								}
								ticketTax.setMainDocument(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
								ticketTax.setDocumentNumber(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
								ticketTax.setIssueAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
								String docId = clientId + ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3)
										+ ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)
										+ ticketDocumentIdentificationStg.getDateOfIssue().substring(0, 6);
								ticketTax.setDocumentUniqueId(docId);
								ticketTax.setCreatedBy(user);
								ticketTax.setFileId(fileId);
								ticketTax.setCreatedDate(new Timestamp(new Date().getTime()));
//								if (!ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
									if (!checkDuplicate(ticketTax,ticketTaxGMap)) {
										ticketTaxTicket.add(ticketTax);
									}
//								}
								/*if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
									if(!ticketDoc.get("documentUniqueIdRefund").isEmpty()) {
										ticketTax.setDocumentUniqueId(ticketDoc.get("documentUniqueIdRefund"));
									}
									if (!checkDuplicate(ticketTax,ticketTaxGMap)) {
										ticketTaxNonTicket.add(ticketTax);
									}
								}*/

							}

						}
					}
				}
			}
		}
		ticketTaxMap.put("ticketTaxTicket", ticketTaxTicket);
		ticketTaxMap.put("ticketTaxNonTicket", ticketTaxNonTicket);
		return ticketTaxMap;
	}
	
	private boolean checkDuplicate(TicketTax ticketTax,Map<String,String> ticketTaxGmap){
		
		String sql = "select document_unique_id from SmartPRASales.ticket_tax where document_unique_id = '"+ticketTax.getDocumentUniqueId()+"' and tax_code = '"+ticketTax.getTaxCode()+"' and serial_no = "+ticketTax.getSerialNo();
		
		boolean isPresentsInDb =   jdbcTemplate.queryForList(sql).isEmpty();
		
		//boolean isPresentsInDb = taxRepository.findOneByDocumentUniqueIdAndTaxCodeAndSerialNo(ticketTax.getDocumentUniqueId(), ticketTax.getTaxCode(), ticketTax.getSerialNo()).isPresent();
		String taxKey = ticketTax.getDocumentUniqueId()+ticketTax.getTaxCode()+ticketTax.getSerialNo();
		boolean isPresentsInCurrentJob = ticketTaxGmap.containsKey(taxKey);
		if(!isPresentsInCurrentJob) {
			ticketTaxGmap.put(taxKey, taxKey);
		}else {
			System.out.println("Duplicate in tax==============>"+taxKey);
		}
		
		return (isPresentsInCurrentJob || !isPresentsInDb) ;
	}

}
