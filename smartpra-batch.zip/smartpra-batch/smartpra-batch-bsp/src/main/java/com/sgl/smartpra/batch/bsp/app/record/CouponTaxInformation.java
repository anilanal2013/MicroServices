package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class CouponTaxInformation extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.COUPON_TAX_INFO;
	}

	// Layout of Coupon Tax Information Record
	public class CouponTaxInformationLayout extends FixedLengthRecordLayout {
		public CouponTaxInformationLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("segmentIdentifier1", 41, 41));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxAirportCode1", 42, 46));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("segmentTaxAirportCode1", 47, 52));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxCode1", 53, 57));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxReportedAmount1", 58, 68));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxCurrencyType1", 69, 72));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxApplicableAmount1", 73, 83));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("segmentIdentifier2", 84, 84));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxAirportCode2", 85, 89));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("segmentTaxAirportCode2", 90, 95));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxCode2", 96, 100));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxReportedAmount2", 101, 111));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxCurrencyType2", 112, 115));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnTaxApplicableAmount2", 116, 126));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 127, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 133, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		CouponTaxInformationLayout couponTaxInformationLayout = new CouponTaxInformationLayout();
		tokenizer.setColumns(couponTaxInformationLayout.getColumns());
		tokenizer.setNames(couponTaxInformationLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String segmentIdentifier1;
	private String cpnTaxAirportCode1;
	private String segmentTaxAirportCode1;
	private String cpnTaxCode1;
	private String cpnTaxReportedAmount1;
	private String cpnTaxCurrencyType1;
	private String cpnTaxApplicableAmount1;
	private String segmentIdentifier2;
	private String cpnTaxAirportCode2;
	private String segmentTaxAirportCode2;
	private String cpnTaxCode2;
	private String cpnTaxReportedAmount2;
	private String cpnTaxCurrencyType2;
	private String cpnTaxApplicableAmount2;
	private String filler;
	private String currencyType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getSegmentIdentifier1() {
		return segmentIdentifier1;
	}

	public void setSegmentIdentifier1(String segmentIdentifier1) {
		this.segmentIdentifier1 = segmentIdentifier1;
	}

	public String getCpnTaxAirportCode1() {
		return cpnTaxAirportCode1;
	}

	public void setCpnTaxAirportCode1(String cpnTaxAirportCode1) {
		this.cpnTaxAirportCode1 = cpnTaxAirportCode1;
	}

	public String getSegmentTaxAirportCode1() {
		return segmentTaxAirportCode1;
	}

	public void setSegmentTaxAirportCode1(String segmentTaxAirportCode1) {
		this.segmentTaxAirportCode1 = segmentTaxAirportCode1;
	}

	public String getCpnTaxCode1() {
		return cpnTaxCode1;
	}

	public void setCpnTaxCode1(String cpnTaxCode1) {
		this.cpnTaxCode1 = cpnTaxCode1;
	}

	public String getCpnTaxReportedAmount1() {
		return cpnTaxReportedAmount1;
	}

	public void setCpnTaxReportedAmount1(String cpnTaxReportedAmount1) {
		this.cpnTaxReportedAmount1 = cpnTaxReportedAmount1;
	}

	public String getCpnTaxCurrencyType1() {
		return cpnTaxCurrencyType1;
	}

	public void setCpnTaxCurrencyType1(String cpnTaxCurrencyType1) {
		this.cpnTaxCurrencyType1 = cpnTaxCurrencyType1;
	}

	public String getCpnTaxApplicableAmount1() {
		return cpnTaxApplicableAmount1;
	}

	public void setCpnTaxApplicableAmount1(String cpnTaxApplicableAmount1) {
		this.cpnTaxApplicableAmount1 = cpnTaxApplicableAmount1;
	}

	public String getSegmentIdentifier2() {
		return segmentIdentifier2;
	}

	public void setSegmentIdentifier2(String segmentIdentifier2) {
		this.segmentIdentifier2 = segmentIdentifier2;
	}

	public String getCpnTaxAirportCode2() {
		return cpnTaxAirportCode2;
	}

	public void setCpnTaxAirportCode2(String cpnTaxAirportCode2) {
		this.cpnTaxAirportCode2 = cpnTaxAirportCode2;
	}

	public String getSegmentTaxAirportCode2() {
		return segmentTaxAirportCode2;
	}

	public void setSegmentTaxAirportCode2(String segmentTaxAirportCode2) {
		this.segmentTaxAirportCode2 = segmentTaxAirportCode2;
	}

	public String getCpnTaxCode2() {
		return cpnTaxCode2;
	}

	public void setCpnTaxCode2(String cpnTaxCode2) {
		this.cpnTaxCode2 = cpnTaxCode2;
	}

	public String getCpnTaxReportedAmount2() {
		return cpnTaxReportedAmount2;
	}

	public void setCpnTaxReportedAmount2(String cpnTaxReportedAmount2) {
		this.cpnTaxReportedAmount2 = cpnTaxReportedAmount2;
	}

	public String getCpnTaxCurrencyType2() {
		return cpnTaxCurrencyType2;
	}

	public void setCpnTaxCurrencyType2(String cpnTaxCurrencyType2) {
		this.cpnTaxCurrencyType2 = cpnTaxCurrencyType2;
	}

	public String getCpnTaxApplicableAmount2() {
		return cpnTaxApplicableAmount2;
	}

	public void setCpnTaxApplicableAmount2(String cpnTaxApplicableAmount2) {
		this.cpnTaxApplicableAmount2 = cpnTaxApplicableAmount2;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
}
