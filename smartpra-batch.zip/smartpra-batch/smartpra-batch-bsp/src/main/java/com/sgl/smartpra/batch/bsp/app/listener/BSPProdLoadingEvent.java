package com.sgl.smartpra.batch.bsp.app.listener;

import org.springframework.context.ApplicationEvent;

@SuppressWarnings("serial")
public class BSPProdLoadingEvent extends ApplicationEvent {

	private String userName;
	
	private long fileId;

	/**
	 * @param userName
	 * @param fileId
	 */
	public BSPProdLoadingEvent(String userName, long fileId) {
		super(fileId);
		this.userName = userName;
		this.fileId = fileId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}
	
	

}
