package com.sgl.smartpra.batch.global.app.dao.result;

import java.io.Serializable;

import lombok.Data;

@Data
public class MultiRecordExceptionsResult implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer fileLogId;

	private Integer recordNumber;

	private String cause;

	private String errorDescription;

	private String action;

	private String complexity;

	private Integer resolutionEffort;

	public MultiRecordExceptionsResult(Integer fileLogId, Integer recordNumber, String cause, String errorDescription,
			String action, String complexity, Integer resolutionEffort) {
		super();
		this.fileLogId = fileLogId;
		this.recordNumber = recordNumber;
		this.cause = cause;
		this.errorDescription = errorDescription;
		this.action = action;
		this.complexity = complexity;
		this.resolutionEffort = resolutionEffort;
	}

}
