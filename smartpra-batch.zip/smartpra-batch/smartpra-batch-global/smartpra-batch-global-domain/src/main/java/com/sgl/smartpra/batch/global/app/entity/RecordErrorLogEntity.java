package com.sgl.smartpra.batch.global.app.entity;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "record_error_log")
public class RecordErrorLogEntity extends BaseEntity implements Serializable{

	private static final long serialVersionUID = -6851208332867282340L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "record_error_id", unique = true, nullable = false)
	private BigInteger recordErrorId;
	
	@Column(name = "record_number")
	private Integer recordNumber;
	
	@Column(name = "record_value")
	private String recordValue;
	
	@Column(name = "record_status")
	private String recordStatus;
	
	@Column(name = "exception_code", nullable=false)
	private String exceptionCode;
	
	@Column(name = "error_description")
	private String errorDescription;
	
	@Column(name = "error_detail")
	private String errorDetail;
	
	@ManyToOne(targetEntity = FileLoggingEntity.class)
	@JoinColumn(name = "file_id", referencedColumnName = "file_id", nullable = false)
	private FileLoggingEntity fileLoggingEntity;
		

	public BigInteger getRecordErrorId() {
		return recordErrorId;
	}

	public void setRecordErrorId(BigInteger recordErrorId) {
		this.recordErrorId = recordErrorId;
	}
	
	public Integer getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(Integer recordNumber) {
		this.recordNumber = recordNumber;
	}

	public String getRecordValue() {
		return recordValue;
	}

	public void setRecordValue(String recordValue) {
		this.recordValue = recordValue;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getErrorDetail() {
		return errorDetail;
	}

	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}

	@JsonBackReference
	public FileLoggingEntity getFileLoggingEntity() {
		return fileLoggingEntity;
	}

	public void setFileLoggingEntity(FileLoggingEntity fileLoggingEntity) {
		this.fileLoggingEntity = fileLoggingEntity;
	}
	
	
}
