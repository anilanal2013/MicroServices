package com.sgl.smartpra.batch.global.app.entity;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name="field_error_log")
public class FieldErrorLogEntity extends BaseEntity implements Serializable {
	
	private static final long serialVersionUID = -1302530196955611889L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "field_error_id",unique = true, nullable = false)
	private BigInteger fieldErrorId;
	
	@Column(name = "record_number")
	private Integer recordNumber;
	
	@Column(name = "field_name")
	private String fieldName;
	
	@Column(name = "field_value")
	private String fieldValue;
	
	@Column(name = "error_description")
	private String errorDescription;
	
	@Column(name = "error_detail")
	private String errorDetail;
	
	@Column(name = "status")
	private String status;
	
	@ManyToOne(targetEntity = FileLoggingEntity.class)
	@JoinColumn(name = "file_id", referencedColumnName = "file_id", nullable = false)
	private FileLoggingEntity fileLoggingEntity;
	

	public BigInteger getFieldErrorId() {
		return fieldErrorId;
	}

	public void setFieldErrorId(BigInteger fieldErrorId) {
		this.fieldErrorId = fieldErrorId;
	}


	public Integer getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(Integer recordNumber) {
		this.recordNumber = recordNumber;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getErrorDetail() {
		return errorDetail;
	}

	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@JsonBackReference
	public FileLoggingEntity getFileLoggingEntity() {
		return fileLoggingEntity;
	}

	public void setFileLoggingEntity(FileLoggingEntity fileLoggingEntity) {
		this.fileLoggingEntity = fileLoggingEntity;
	}
	
}
