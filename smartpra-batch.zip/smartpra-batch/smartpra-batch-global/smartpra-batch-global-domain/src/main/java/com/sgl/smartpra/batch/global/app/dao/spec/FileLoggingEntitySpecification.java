package com.sgl.smartpra.batch.global.app.dao.spec;

import java.time.LocalDate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.batch.global.app.entity.FileLoggingEntity;

public final class FileLoggingEntitySpecification {

	private FileLoggingEntitySpecification() {
	}

	public static Specification<FileLoggingEntity> betweenFromAndToDate(LocalDate fromDate, LocalDate toDate) {
		return (fileLoggingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				fileLoggingEntity.get("createdDate"), criteriaBuilder.literal(fromDate),
				criteriaBuilder.literal(toDate));
	}

	public static Specification<FileLoggingEntity> equalsLovModuleId(Integer moduleId) {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierAllianceEntity.get("moduleId"), moduleId);
	}

	public static Specification<FileLoggingEntity> equalsFileStatus(String fileStatus) {
		return (carrierAllianceEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierAllianceEntity.get("fileStatus"), fileStatus);
	}

}
