package com.sgl.smartpra.batch.global.app.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "ticket_audit")
@Data
public class TicketAuditEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ticket_audit_id")
	private long ticketAuditId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "coupon_no")
	private int couponNo;

	@Column(name = "document_number")
	private String documentNumber;

	@Column(name = "document_unique_id")
	private String documentUniqueId;

	@Column(name = "event_type")
	private String eventType;

	@Column(name = "issuing_airline")
	private String issuingAirline;

	@Column(name = "network_login")
	private String networkLogin;

	@Column(name = "new_value")
	private String newValue;

	@Column(name = "old_value")
	private String oldValue;

	@Column(name = "order_id")
	private String orderId;

	@Column(name = "resource_name")
	private String resourceName;

	@Column(name = "update_date")
	private LocalDateTime updateDate;

	@Column(name = "user_ip")
	private String userIp;

	@Column(name = "user_machine_name")
	private String userMachineName;

	@Column(name = "user_name")
	private String userName;

}
