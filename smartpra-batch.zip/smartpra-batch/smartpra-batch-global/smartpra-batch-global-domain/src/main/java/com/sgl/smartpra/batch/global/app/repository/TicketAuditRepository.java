package com.sgl.smartpra.batch.global.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.global.app.entity.TicketAuditEntity;

@Repository
public interface TicketAuditRepository
		extends JpaRepository<TicketAuditEntity, Long>, JpaSpecificationExecutor<TicketAuditEntity> {

}
