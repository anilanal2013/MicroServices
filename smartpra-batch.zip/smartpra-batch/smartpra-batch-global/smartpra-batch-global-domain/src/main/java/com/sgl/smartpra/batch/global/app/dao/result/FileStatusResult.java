package com.sgl.smartpra.batch.global.app.dao.result;

import java.io.Serializable;

import lombok.Data;

@Data
public class FileStatusResult implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer statusCount;

	private Integer lovModuleId;

	private String fieldShortDesc;

	private String statusType;

	public FileStatusResult(Integer statusCount, Integer lovModuleId, String fieldShortDesc, String statusType) {
		super();
		this.statusCount = statusCount;
		this.lovModuleId = lovModuleId;
		this.fieldShortDesc = fieldShortDesc;
		this.statusType = statusType;
	}

}
