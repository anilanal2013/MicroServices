package com.sgl.smartpra.batch.global.app.entity;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "file_error_log")
public class FileErrorLogEntity extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 3265342022967117667L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "file_error_id", unique = true, nullable = false)
	private BigInteger fileErrorId;
	
	@Column(name = "exception_code", nullable=false)
	private String exceptionCode;
	
	@Column(name = "error_detail")
	private String errorDetail;

	@Column(name = "error_description")
	private String errorDescription;

	@ManyToOne(targetEntity = FileLoggingEntity.class)
	@JoinColumn(name = "file_id", referencedColumnName = "file_id", nullable = false)
	private FileLoggingEntity fileLoggingEntity;
	
	public BigInteger getFileErrorId() {
		return fileErrorId;
	}

	public void setFileErrorId(BigInteger fileErrorId) {
		this.fileErrorId = fileErrorId;
	}

	public String getErrorDetail() {
		return errorDetail;
	}

	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	@JsonBackReference
	public FileLoggingEntity getFileLoggingEntity() {
		return fileLoggingEntity;
	}

	public void setFileLoggingEntity(FileLoggingEntity fileLoggingEntity) {
		this.fileLoggingEntity = fileLoggingEntity;
	}

}
