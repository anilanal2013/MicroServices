package com.sgl.smartpra.batch.global.app.dao.spec;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.batch.global.app.entity.MasterAuditEntity;

public class MasterAuditEntitySpecification {

	public static Specification<MasterAuditEntity> search(String resourceName) {

		return (masterAuditEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (resourceName != null) {
				predicates.add(criteriaBuilder.like(masterAuditEntity.get("resourceName"), resourceName + "%"));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
