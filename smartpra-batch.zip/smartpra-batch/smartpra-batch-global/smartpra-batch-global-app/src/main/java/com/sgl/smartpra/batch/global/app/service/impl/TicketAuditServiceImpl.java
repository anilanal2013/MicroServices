package com.sgl.smartpra.batch.global.app.service.impl;

import java.net.InetAddress;
import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.global.app.dao.TicketAuditDao;
import com.sgl.smartpra.batch.global.app.mapper.TicketAuditMapper;
import com.sgl.smartpra.batch.global.app.service.TicketAuditService;
import com.sgl.smartpra.batch.global.model.TicketAudit;

@Service
@Transactional
public class TicketAuditServiceImpl implements TicketAuditService {

	@Autowired
	private TicketAuditDao ticketAuditDao;

	@Autowired
	private TicketAuditMapper ticketAuditMapper;

	InetAddress ip = null;

	@Override
	public List<TicketAudit> getAllTicketAudit(String documentNumber, String documentUniqueId, String issuingAirline) {

		return ticketAuditMapper
				.mapToModel(ticketAuditDao.getAllTicketAudit(documentNumber, documentUniqueId, issuingAirline));
	}

	@Override
	public TicketAudit updateTicketAudit(TicketAudit ticketAudit) {

		try {
			ip = InetAddress.getLocalHost();
		} catch (Exception e) {
			//log.error("Conext: " + e.getMessage());
		}
		ticketAudit.setUserIp(ip.getHostAddress());
		ticketAudit.setNetworkLogin(ip.getHostAddress());
		ticketAudit.setUserMachineName(ip.getHostName());
		ticketAudit.setUpdateDate(LocalDateTime.now());
		ticketAudit.setUserName("SmartPraAdmin");

		return ticketAuditMapper
				.mapToModel(ticketAuditDao.updateTicketAudit(ticketAuditMapper.mapToEntity(ticketAudit)));

	}
}
