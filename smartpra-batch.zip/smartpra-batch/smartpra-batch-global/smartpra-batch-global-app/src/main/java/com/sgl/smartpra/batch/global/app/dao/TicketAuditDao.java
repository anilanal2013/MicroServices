package com.sgl.smartpra.batch.global.app.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.global.app.entity.TicketAuditEntity;

@Repository
public interface TicketAuditDao {

	public List<TicketAuditEntity> getAllTicketAudit(String documentNumber, String documentUniqueId,
			String issuingAirline);

	public TicketAuditEntity updateTicketAudit(TicketAuditEntity ticketAuditEntity);

}
