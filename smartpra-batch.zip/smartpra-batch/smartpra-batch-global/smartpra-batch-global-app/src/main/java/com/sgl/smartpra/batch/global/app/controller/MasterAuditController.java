package com.sgl.smartpra.batch.global.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.global.app.service.MasterAuditService;
import com.sgl.smartpra.batch.global.model.MasterAudit;

@RestController
public class MasterAuditController {

	@Autowired
	private MasterAuditService masterAuditService;

	@GetMapping("/master-audit")
	public List<MasterAudit> getMasterAuditByResourceName(
			@RequestParam(value = "resourceName", required = false) String resourceName) {

		return masterAuditService.getMasterAuditByResourceName(resourceName);

	}

	@PutMapping("/master-audit")
	public void updateMasterAudit(@RequestParam(value = "newObj") Object newObj,
			@RequestParam(value = "oldObj") Object oldObj, @RequestParam(value = "tableName") String tableName,
			@RequestParam(value = "serviceName") String serviceName) {

		masterAuditService.updateMasterAudit(newObj, oldObj, tableName, serviceName);

	}

}
