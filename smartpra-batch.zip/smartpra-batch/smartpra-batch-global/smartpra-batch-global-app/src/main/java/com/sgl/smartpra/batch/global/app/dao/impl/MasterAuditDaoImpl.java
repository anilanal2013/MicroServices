package com.sgl.smartpra.batch.global.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.global.app.dao.MasterAuditDao;
import com.sgl.smartpra.batch.global.app.dao.spec.MasterAuditEntitySpecification;
import com.sgl.smartpra.batch.global.app.entity.MasterAuditEntity;
import com.sgl.smartpra.batch.global.app.repository.MasterAuditRepository;

@Component
public class MasterAuditDaoImpl implements MasterAuditDao {

	@Autowired
	private MasterAuditRepository masterAuditRepository;

	public List<MasterAuditEntity> getMasterAuditByResourceName(String resourceName) {
		return masterAuditRepository.findAll(MasterAuditEntitySpecification.search(resourceName));

	}

	public MasterAuditEntity updateMasterAudit(MasterAuditEntity masterAuditEntity) {
		return masterAuditRepository.save(masterAuditEntity);
	}

}
