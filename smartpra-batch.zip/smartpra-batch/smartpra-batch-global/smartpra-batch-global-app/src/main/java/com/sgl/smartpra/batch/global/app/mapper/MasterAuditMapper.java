package com.sgl.smartpra.batch.global.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.sgl.smartpra.batch.global.app.entity.MasterAuditEntity;
import com.sgl.smartpra.batch.global.model.MasterAudit;

@Mapper(componentModel = "Spring")
public interface MasterAuditMapper extends BaseMapper<MasterAudit, MasterAuditEntity> {

	MasterAuditEntity mapToEntity(MasterAudit masterAudit, @MappingTarget MasterAuditEntity masterAuditEntity);

	@Mapping(source = "masterAuditId", target = "masterAuditId", ignore = true)
	MasterAuditEntity mapToEntity(MasterAudit masterAudit);

}
