
package com.sgl.smartpra.batch.global.app.controller;

import java.math.BigInteger;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.global.app.service.FileLogService;
import com.sgl.smartpra.batch.global.model.FileLogging;

@RestController
public class FileLogController {

	@Autowired
	FileLogService fileLogService;

	@GetMapping("/filelogs")
	public List<FileLogging> getAllFileLog() {
		return fileLogService.getAllFileLog();

	}
	 

	@GetMapping("/filelog/{fileId}")
	public FileLogging getFileLogByFileId(@PathVariable(value = "fileId") BigInteger fileId) {
		return fileLogService.getFileLogByFileId(fileId);

	}
	 
	@GetMapping("/filelogs/filename/{fileName}")
	public List<FileLogging> getFileLogByFileName(@PathVariable(value = "fileName") String fileName) {
		return fileLogService.getFileLogByFileName(fileName);

	}
	

	@PostMapping("/filelog")
	public FileLogging createFileLog(@Valid @RequestBody FileLogging fileLog) {
		return fileLogService.createFileLog(fileLog);
	}
	
	@PutMapping("/filelog/{fileId}")
	public FileLogging updateFileLog(@PathVariable(value = "fileId") BigInteger fileId,
			@Valid @RequestBody FileLogging fileLog) {
		if(fileLog.getFileId()==null || fileLog.getFileId().intValue() == 0 ) {
			fileLog.setFileId(fileId);
		}
		return fileLogService.updateFileLog(fileLog); 
	}
	
	@DeleteMapping("/filelog/{fileId}")
	public void  deleteFileLog(@PathVariable(value = "fileId") BigInteger fileId) {
		 fileLogService.deleteFileLog(fileId); 
	}

}
