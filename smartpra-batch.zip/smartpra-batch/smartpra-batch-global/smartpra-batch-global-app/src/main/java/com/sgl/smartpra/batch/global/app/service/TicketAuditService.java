package com.sgl.smartpra.batch.global.app.service;

import java.util.List;

import com.sgl.smartpra.batch.global.model.TicketAudit;

public interface TicketAuditService {

	public List<TicketAudit> getAllTicketAudit(String documentNumber, String documentUniqueId, String issuingAirline);

	public TicketAudit updateTicketAudit(TicketAudit ticketAudit);

}
