package com.sgl.smartpra.batch.bhr.app.domain;

import java.util.Date;

import lombok.Data;

@Data
public class PaxManiFestHeader {

	private String boardingGate;

	private String boardingPoint;

	private String boardingTime;

	private Integer businessClassCount;

	private Integer economyClassCount;

	private Integer firstClassCount;

	private Date flightDate;

	private String flightNumber;

	private String flightUniqueId;

	private Integer issueAirlineCode;

	private Integer preecoClassCount;

	private String stdTime;

	private Integer totalCabinCount;

}
