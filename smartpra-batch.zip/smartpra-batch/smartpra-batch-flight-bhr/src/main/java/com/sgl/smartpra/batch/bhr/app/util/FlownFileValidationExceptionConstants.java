package com.sgl.smartpra.batch.bhr.app.util;

public class FlownFileValidationExceptionConstants {
	
	public static final String FILE_NOT_FOUND_LIFT1000="LIFT1000";
	public static final String LIFT1000_PARAM_1="File name";
	
	public static final String FILE_NAME_NOT_SPECIFICATION_LIFT1001="LIFT1001";
	public static final String LIFT1001_PARAM_1="File name";
	
	public static final String FILE_NO_RECORD_FOUND_LIFT1002="LIFT1002";
	public static final String LIFT1002_PARAM_1="File name";
	
	public static final String FILE_INCORRECT_DATA_REPORTED_LIFT1003="LIFT1003";
	public static final String LIFT1003_PARAM_1="File name";
	
}