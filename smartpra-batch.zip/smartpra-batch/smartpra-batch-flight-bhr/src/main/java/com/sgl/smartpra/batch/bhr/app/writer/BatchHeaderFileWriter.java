package com.sgl.smartpra.batch.bhr.app.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bhr.app.domain.BatchRecord;
import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;
import com.sgl.smartpra.batch.bhr.app.repository.FlightBatchHeaderRepository;

@Component
public class BatchHeaderFileWriter<T extends BatchRecord> implements ItemWriter<FlightBatchHeaderStg> {

	@Autowired
	private FlightBatchHeaderRepository flightBatchHeaderRepository;

	@Override
	public void write(List<? extends FlightBatchHeaderStg> flightBatchHeaderStg) throws Exception {

		flightBatchHeaderRepository.saveAll(flightBatchHeaderStg);

	}

}
