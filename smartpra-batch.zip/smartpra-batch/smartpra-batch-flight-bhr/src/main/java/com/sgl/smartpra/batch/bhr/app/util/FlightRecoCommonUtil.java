package com.sgl.smartpra.batch.bhr.app.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.commons.io.FileUtils;

import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.constant.SmartPRAConstant;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.master.model.SystemParameter;

public class FlightRecoCommonUtil {
	
	public static FileLogging initFileLogging() {

		FileLogging fileLogging = new FileLogging();
		fileLogging.setFileCategory(FileLoggingConstants.FILELOGGING_FILECATEGORY_TEXT);
		fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setModuleName(FlightRecoConstants.FILELOGGING_MODULE);
		fileLogging.setSource(FlightRecoConstants.FILE_SOURCE);
		fileLogging.setCreatedBy(FlightRecoConstants.CREATEDBY);
		fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));

		// may not be mandatory
		fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_STARTED);
		fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setTotalCounts(0);
		fileLogging.setTransferredCounts(0);
		fileLogging.setIsEncryptedPostSuccess("N");
		fileLogging.setIsEncryptedPriorLoading("N");
		fileLogging.setIsRenamedPostSuccess("N");
		fileLogging.setIsMovedToRelevantFolder("N");
		fileLogging.setIsNotificationSent("N");
		fileLogging.setModuleId(FlightRecoConstants.MODULE_ID);
		return fileLogging;
	}
	
	/**
	 * This method will get the host carrier designator code.
	 * 
	 * @param parameterName
	 * @return
	 */
	public static String getHostCarrierDesigCode(SmartpraMasterAppClient smartpraMasterAppClient) {
		String hostCarrierDesigCode = null;
		
		SystemParameter systemParameter = smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(BHRConstants.PARAM_DEFAULT_CARRIER_ALPHA_CODE,SmartPRAConstant.CLIENT_ID);
		if (systemParameter != null) {
			hostCarrierDesigCode = systemParameter.getParameterRangeFrom().get();
		}
		return hostCarrierDesigCode;
	}
	
	public static String getHostCarrierNumericCode(SmartpraMasterAppClient smartpraMasterAppClient) {
		String hostCarrierNumericCode = null;
		SystemParameter systemParameter = smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(BHRConstants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE,SmartPRAConstant.CLIENT_ID);
		if (systemParameter != null) {
			hostCarrierNumericCode = systemParameter.getParameterRangeFrom().get();
		}
		return hostCarrierNumericCode;
	}
	public static String getFlightNumberOption(SmartpraMasterAppClient smartpraMasterAppClient) {
		String flightNumberOption = null;
		SystemParameter systemParameter = smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(BHRConstants.FLIGHT_NUMBER_OPTION,SmartPRAConstant.CLIENT_ID);
		if (systemParameter != null) {
			flightNumberOption = systemParameter.getParameterRangeFrom().get();
		}
		return flightNumberOption;
	}
	
	public static boolean moveFile(String source, String target) {
		Path moveResp = null;
		try {
			moveResp = Files.move(Paths.get(source), Paths.get(target));
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return moveResp != null ? true : false;
	}
	public static String getFileSize(String fileName) {
		File fileObj = new File(fileName);
		return FileUtils.byteCountToDisplaySize(fileObj.length());
	}
	public static String derivedFlightNumber(String flightNumber, String flightNumberOption) {

		switch (flightNumberOption) {
		case "0":
			flightNumber = flightNumber.length() > 4 ? flightNumber.substring(flightNumber.length() - 4) : flightNumber;
			break;

		case "3":
			flightNumber = flightNumber.length() > 3 ? flightNumber.substring(flightNumber.length() - 3)
					: flightNumber.length() < 3 ? SmartPRACommonUtil.padString(flightNumber, "0", 3) : flightNumber;
			break;

		case "4":
			flightNumber = flightNumber.length() > 4 ? flightNumber.substring(flightNumber.length() - 4)
					: flightNumber.length() < 4 ? SmartPRACommonUtil.padString(flightNumber, "0", 4) : flightNumber;
			break;

		}

		return flightNumber;
	}



}
