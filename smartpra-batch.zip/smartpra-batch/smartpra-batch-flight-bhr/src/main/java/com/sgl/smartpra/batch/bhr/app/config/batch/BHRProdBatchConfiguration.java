package com.sgl.smartpra.batch.bhr.app.config.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.bhr.app.domain.BatchRecord;
import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;
import com.sgl.smartpra.batch.bhr.app.listener.JobCompletionNotificationListener;
import com.sgl.smartpra.batch.bhr.app.processor.BHRProdProcessor;
import com.sgl.smartpra.batch.bhr.app.repository.FlightBatchHeaderRepository;

@Configuration
@EnableBatchProcessing
public class BHRProdBatchConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;

	@Autowired
	private FlightBatchHeaderRepository bhrStgRepository;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Value("${max-threads}")
	private int maxThreads;

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setConcurrencyLimit(maxThreads);
		return taskExecutor;
	}

	@Bean
	public Job importBHRProdJob(JobCompletionNotificationListener listener, Step importBHRProdData) {

		// @formatter:off
		return jobBuilderFactory.get("importBHRProdData").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(importBHRProdData).end().build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step importBHRProdData() {
		// @formatter:off
		return ((stepBuilderFactory.get("importBHRProdData").<BatchRecord, BatchRecord>chunk(100)
				.reader((ItemReader<? extends BatchRecord>) bhrRepositoryItemReader(null))
				.processor((ItemProcessor<? super BatchRecord, ? extends BatchRecord>) bhrItemProcessor())
				.writer((ItemWriter<? super BatchRecord>) bhrRepositoryItemWriter())
				.transactionManager(transactionManager)))
				.taskExecutor(taskExecutor())
				//.throttleLimit(maxThreads)
				.build();
		// @formatter:on
	}

	@Bean
	@StepScope
	public ItemReader<? extends BatchRecord> bhrRepositoryItemReader(
			@Value("#{jobParameters[fileId]}") String fileHdrId) {
		RepositoryItemReader<FlightBatchHeaderStg> reader = new RepositoryItemReader<FlightBatchHeaderStg>();
		ArrayList<Integer> arguments = new ArrayList<Integer>();
		arguments.add(Integer.valueOf(fileHdrId));
		reader.setRepository(bhrStgRepository);
		reader.setMethodName("findByFileId");
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("fileId", Direction.ASC);
		reader.setSort(map);
		return reader;
	}

	@Bean
	@StepScope
	ItemProcessor<? extends BatchRecord, ? extends BatchRecord> bhrItemProcessor() {
		return new BHRProdProcessor();
	}

	@Bean
	@StepScope
	public ItemWriter<? super BatchRecord> bhrRepositoryItemWriter() {
		return new FlightBatchHeaderStg().prodWriter();
	}

}
