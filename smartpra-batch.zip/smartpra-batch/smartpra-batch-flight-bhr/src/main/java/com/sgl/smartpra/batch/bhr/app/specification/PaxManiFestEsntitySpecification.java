package com.sgl.smartpra.batch.bhr.app.specification;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.batch.bhr.app.domain.PaxManiFest;


public class PaxManiFestEsntitySpecification {

	public static Specification<PaxManiFest> serach(String flightNumber, Date flightDate, String fromCity,
			String toCity, String flightRecoStatus){		
		return (paxManiFest, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (flightRecoStatus != null && flightRecoStatus.trim().length() > 0) {
				predicates.add(criteriaBuilder.equal(paxManiFest.get("flightRecoStatus"), flightRecoStatus));
			}
			predicates.add(criteriaBuilder.equal(paxManiFest.get("flightNumber"), flightNumber));
			predicates.add(criteriaBuilder.equal(paxManiFest.get("flightDate"), flightDate));
			predicates.add(criteriaBuilder.equal(paxManiFest.get("fromCity"), fromCity));
			predicates.add(criteriaBuilder.equal(paxManiFest.get("toCity"), toCity));	
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
