package com.sgl.smartpra.batch.bhr.app.domain;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;


@Entity
@Table(name="pax_manifest", schema="SmartPRAFlown")
@Data
public class PaxManiFest implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pax_manifest_id")
	private Integer paxManifestId;

	@Column(name="boarding_gate")
	private String boardingGate;

	@Column(name="boarding_point")
	private String boardingPoint;

	@Column(name="boarding_time")
	private String boardingTime;

	@Column(name="business_class_count")
	private Integer businessClassCount;

	@Column(name="client_id")
	private String clientId;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="document_no")
	private String documentNo;

	@Column(name="economy_class_count")
	private Integer economyClassCount;

	@Column(name="file_id")
	private Integer fileId;

	@Column(name="file_source")
	private String fileSource;

	@Column(name="first_class_count")
	private Integer firstClassCount;

	@Column(name="flight_date")
	private Date flightDate;

	@Column(name="flight_number")
	private String flightNumber;

	@Column(name="flight_reco_date")
	private Date flightRecoDate;

	@Column(name="flight_reco_status")
	private String flightRecoStatus;

	@Column(name="from_city")
	private String fromCity;

	@Column(name="issue_airline_code")
	private String issueAirlineCode;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="passenger_name")
	private String passengerName;

	@Column(name="pax_gender")
	private String paxGender;

	@Column(name="pnr_no")
	private String pnrNo;

	@Column(name="preeco_class_count")
	private Integer preecoClassCount;

	@Column(name="rbd_operated")
	private String rbdOperated;

	@Column(name="seat_no")
	private String seatNo;

	@Column(name="std_time")
	private String stdTime;

	@Column(name="to_city")
	private String toCity;

	@Column(name="total_cabin_count")
	private Integer totalCabinCount;

	@Column(name="trvld_class")
	private String trvldClass;

}