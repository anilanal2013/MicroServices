package com.sgl.smartpra.batch.bhr.app.processor;

import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.*;
import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;
import com.sgl.smartpra.batch.bhr.app.util.BHRCommonUtil;
import com.sgl.smartpra.batch.bhr.app.util.BHRConstants;
import com.sgl.smartpra.batch.bhr.app.util.BHRCountReader;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.model.FlightControlDetails;
import com.sgl.smartpra.flown.model.FlightDataDetails;
import com.sgl.smartpra.flown.model.FlightFutureSchedule;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.master.model.Aircraft;
import com.sgl.smartpra.master.model.FlightControl;
import feign.FeignException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.*;

@Component
@Scope(value = "step")
public class BHRProdProcessor extends RecordProcessor
		implements ItemProcessor<FlightBatchHeaderStg, FlightBatchHeaderStg> {

	private static Logger LOGGER = LoggerFactory.getLogger(BHRProdProcessor.class);

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	SmartpraFlownClient smartpraFlownClient;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	ExceptionTransIntgAppClient exceptionTransIntgAppClient;

	@Autowired
	GlobalMasterFeignClient globalMasterFeignClient;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	ExceptionTransactionModel exceptionTransactionModel;
	List<ExceptionParametersValueModel> parametersValueModelList;
	ExceptionParametersValueModel parametersValueModel;
	FileLogging fileLogging;

	@Override
	public FlightBatchHeaderStg process(FlightBatchHeaderStg fileDetail) throws Exception {
		LOGGER.info("BHRProdProcessor.process() - start with flightNumber:" + fileDetail.getFlightNumber());
		// super.process(fileDetail);
		BHRCountReader.incTotalCount();
		ExceptionTransactionModel exceptionTransactionModel;
		List<ExceptionParametersValueModel> parametersValueModelList;
		ExceptionParametersValueModel parametersValueModel;
		FileLogging fileLogging;
		String flightDate = BHRCommonUtil.getDate(fileDetail.getFlightDate())
				.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

		String clientId = stepExecution.getJobExecution().getJobParameters().getString("clientId");

		String flightNumberOption = stepExecution.getJobExecution().getJobParameters().getString("flightNumberOption");

		String flightNumber = BHRCommonUtil.derivedFlightNumber(fileDetail.getFlightNumber(), flightNumberOption);

		LOGGER.info("smartpraFlownClient.getFlightDataDetails() - start with flight Numebr::" + flightNumber);
		FlightDataDetails flightDataDetailsDB = smartpraFlownClient.getFlightDataDetails(flightNumber,
				fileDetail.getFromAirport(), fileDetail.getToAirport(),
				BHRCommonUtil.getDate(fileDetail.getFlightDate()), null);
		LOGGER.info("smartpraFlownClient.getFlightDataDetails() - End");

		if (flightDataDetailsDB != null) {
			if (!flightDataDetailsDB.getFlightStatus().equals(BHRConstants.FLIGHT_STATUS_OUTSTANDING)) {
				BHRCountReader.incErrorCount();
				LOGGER.info("Flifgt Already Created Exception - Start");
				Map<String, String> paramsMap = new HashMap<>();
				paramsMap.put(BHRConstants.LIFT1011_PARAM_1, fileDetail.getFlightNumber());
				paramsMap.put(BHRConstants.LIFT1011_PARAM_2, fileDetail.getFromAirport());
				paramsMap.put(BHRConstants.LIFT1011_PARAM_3, fileDetail.getToAirport());
				paramsMap.put(BHRConstants.LIFT1011_PARAM_4, flightDate);

				prepareExceptionTransactionModel(BHRConstants.BHR_FILE_FLIGHT_ALREADY_CREATED_LIFT1011, paramsMap,
						fileDetail);

				LOGGER.info("Flifgt Already Created Exception  - End");

				return null;
			} else {
				FlightDataDetails flightDataDetails = new FlightDataDetails();
				flightDataDetails.setFlightStatus(BHRConstants.FLIGHT_STATUS_OPEN);
				flightDataDetails.setLastUpdatedBy(BHRConstants.BHR_LAST_UPDATEDBY);
				flightDataDetails.setSsimInd(flightDataDetailsDB.getSsimInd());
				flightDataDetails.setDataSource(flightDataDetailsDB.getDataSource());
				flightDataDetails.setFileId(flightDataDetailsDB.getFileId());
				try {
					LOGGER.info(
							"smartpraFlownClient.updateFlightDataDetails(flightKey, flightDataDetails) - start with flight Key::"
									+ flightDataDetailsDB.getFlightKey());

					flightDataDetails = smartpraFlownClient.updateFlightDataDetails(flightDataDetailsDB.getFlightKey(),
							flightDataDetails);
					// createFlightControlDetails(fileDetail, flightDataDetails);
					LOGGER.info(
							"smartpraFlownClient.updateFlightDataDetails(flightKey, flightDataDetails) - ends with flight Key::"
									+ flightDataDetailsDB.getFlightKey());
				} catch (Exception e) {
					LOGGER.info("Error in Flight Creation-Start");
					BHRCountReader.incErrorCount();

					Map<String, String> paramsMap = new HashMap<>();
					paramsMap.put(BHRConstants.LIFT1010_PARAM_1, fileDetail.getFlightNumber());
					paramsMap.put(BHRConstants.LIFT1010_PARAM_2, fileDetail.getFromAirport());
					paramsMap.put(BHRConstants.LIFT1010_PARAM_3, fileDetail.getToAirport());
					paramsMap.put(BHRConstants.LIFT1010_PARAM_4, flightDate);

					prepareExceptionTransactionModel(BHRConstants.BHR_FILE_ERROR_IN_UPDATING_FLIFGHT_DATA_DEATILS_LIFT1010,
							paramsMap, fileDetail);
					LOGGER.info("Error in Flight Creation-End");
				}
			}
		} else {
			FlightDataDetails flightDataDetails = new FlightDataDetails();
			flightDataDetails.setClientId(clientId);

			if (StringUtils.isNotEmpty(flightNumberOption)) {
				flightDataDetails.setFlightNumber(
						BHRCommonUtil.derivedFlightNumber(fileDetail.getFlightNumber(), flightNumberOption));
			} else {
				flightDataDetails.setFlightNumber(fileDetail.getFlightNumber());
			}

			Airport airport = null;
			// checking from airport code
			try {
				airport = globalMasterFeignClient.getAirportByAirportCode(fileDetail.getFromAirport());
			} catch (FeignException fex) {
				LOGGER.error(" From Airpot Code is not in Airport Master:" + fileDetail.getFromAirport());
			}
			if (airport != null) {
				LOGGER.info(" Airport Code Not Found Exeception  - start");
				flightDataDetails.setFromAirport(OptionalUtil.getValue(airport.getAirportCode()));
				LOGGER.info("Setting fromairport to flidata Details - end");
			} else {
				LOGGER.info("batchGlobalFeignClient.getFileLogByFileId()- start");
				BHRCountReader.incErrorCount();
				LOGGER.info("batchGlobalFeignClient.getFileLogByFileId()- start");
				fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileDetail.getFileId()));
				LOGGER.info("batchGlobalFeignClient.getFileLogByFileId() - end");

				Map<String, String> paramsMap = new HashMap<>();
				paramsMap.put(BHRConstants.LIFT1006_PARAM_1, fileLogging.getFileName());
				paramsMap.put(BHRConstants.LIFT1006_PARAM_2, fileDetail.getFromAirport());

				prepareExceptionTransactionModel(BHRConstants.BHR_FILE_INCORRECT_AIRPORTCODE_LIFT1006, paramsMap,
						fileDetail);
				LOGGER.info(" Airport Code Not Found Exeception  - End");
				return null;
			}

			// checking to airport code
			Airport toAirport = null;
			try {
				toAirport = globalMasterFeignClient.getAirportByAirportCode(fileDetail.getToAirport());
			} catch (FeignException fex) {
				LOGGER.error(" To Airpot Code is not in Airport Master:" + fileDetail.getToAirport());
			}

			if (toAirport != null) {
				LOGGER.info("Setting toairport to flidata Details - start");
				flightDataDetails.setToAirport(OptionalUtil.getValue(toAirport.getAirportCode()));
				LOGGER.info("Setting toairport to flidata Details - End");
			} else {

				LOGGER.info("batchGlobalFeignClient.getFileLogByFileId()- start");
				BHRCountReader.incErrorCount();
				LOGGER.info("batchGlobalFeignClient.getFileLogByFileId()- start");
				fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileDetail.getFileId()));
				LOGGER.info("batchGlobalFeignClient.getFileLogByFileId() - end");

				Map<String, String> paramsMap = new HashMap<>();
				paramsMap.put(BHRConstants.LIFT1006_PARAM_1, fileLogging.getFileName());
				paramsMap.put(BHRConstants.LIFT1006_PARAM_2, fileDetail.getToAirport());

				prepareExceptionTransactionModel(BHRConstants.BHR_FILE_INCORRECT_AIRPORTCODE_LIFT1006, paramsMap,
						fileDetail);
				LOGGER.info(" Airport Code Not Found Exeception  - End");
				return null;
			}

			flightDataDetails.setFlightDate(BHRCommonUtil.getDate(fileDetail.getFlightDate()));

			LOGGER.info("smartpraMasterAppClient.getAllAircraft(getAircraftRegistration) - start");
			List<Aircraft> aircrafts = null;
			Aircraft aircraft = null;
			try {
				aircrafts = smartpraMasterAppClient.getAllAircraft(fileDetail.getAircraftRegistration(), null, null);

			} catch (FeignException fex) {
				LOGGER.error(
						" getAircraftRegistration is not in Aircraft Master:" + fileDetail.getAircraftRegistration());
			}
			// Setting Aircraft Registration
			if (aircrafts != null && aircrafts.size() > 0) {
				LOGGER.info("Aircraft Registration to flidata Details - start");
				aircraft = aircrafts.get(0);
				flightDataDetails.setAircraftRegistration(aircraft.getAircraftRegistration().get());
				flightDataDetails.setAircraftType(aircraft.getAircraftType().get());
				LOGGER.info("Aircraft Registration to flidata Details - End");
			} else {

				LOGGER.info("Aircraft Registration Not Found Exception Creation-Start");

				LOGGER.info("batchGlobalFeignClient.getFileLogByFileId()- start");
				fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileDetail.getFileId()));
				LOGGER.info("batchGlobalFeignClient.getFileLogByFileId() - end");

				Map<String, String> paramsMap = new HashMap<>();
				paramsMap.put(BHRConstants.LIFT1007_PARAM_1, fileDetail.getAircraftRegistration());
				paramsMap.put(BHRConstants.LIFT1007_PARAM_2, fileLogging.getFileName());

				prepareExceptionTransactionModel(BHRConstants.BHR_FILE_INCORRECT_AIRCRAFT_REGISTRATION_LIFT1007,
						paramsMap, fileDetail);
				LOGGER.info("Aircraft Registration Not Found Exception Creation-End");
			}
			if (StringUtils.isNotEmpty(fileDetail.getPayload())) {
				flightDataDetails.setPayloadCapacity(Long.valueOf(fileDetail.getPayload()));
			} else if (aircraft != null) {
				flightDataDetails.setPayloadCapacity(Long.parseLong(aircraft.getPayload().get()));
			}

			flightDataDetails.setFileId(fileDetail.getFileId());
			// Flight master reference
			LOGGER.info("smartpraMasterAppClient.getFlightSchedule() - start");
			FlightFutureSchedule flightSchedule = smartpraFlownClient.getFlightSchedule(clientId,
					fileDetail.getFlightNumber(), fileDetail.getFromAirport(), fileDetail.getToAirport(),
					BHRCommonUtil.convertDate(fileDetail.getFlightDate()));
			LOGGER.info("smartpraMasterAppClient.getFlightSchedule() - End");
			flightDataDetails.setServiceType(SERVICE_TYPE_SCHEDULE);

			flightDataDetails.setArrivalTime(flightSchedule.getArrivalTime());
			flightDataDetails.setDepartureTime(flightSchedule.getDepartureTime());
			flightDataDetails.setFromLeg(flightSchedule.getFromLeg());
			flightDataDetails.setToLeg(flightSchedule.getToLeg());
			flightDataDetails
					.setFlightType(flightSchedule != null && StringUtils.isNotEmpty(flightSchedule.getFlightType())
							? flightSchedule.getFlightType()
							: FLIGHT_TYPE_DEFAULT);
			flightDataDetails.setEstimationFlag(ESTIMATION_FLAG_DEFAULT);
			flightDataDetails.setFlightIndicator(BHRConstants.FLIGHT_INDICATOR);
			if (StringUtils.isNotEmpty(fileDetail.getFirstClassCabinControl())) {
				flightDataDetails.setfCabinCapacity(Integer.valueOf(fileDetail.getFirstClassCabinControl()));
			}

			if (StringUtils.isNotEmpty(fileDetail.getBusinessCabinControl())) {
				flightDataDetails.setcCabinCapacity(Integer.valueOf(fileDetail.getBusinessCabinControl()));
			}

			if (StringUtils.isNotEmpty(fileDetail.getPremiumEconomyCabinControl())) {
				flightDataDetails.setwCabinCapacity(Integer.valueOf(fileDetail.getPremiumEconomyCabinControl()));
			}

			if (StringUtils.isNotEmpty(fileDetail.getEconomyCabinControl())) {
				flightDataDetails.setyCabinCapacity(Integer.valueOf(fileDetail.getEconomyCabinControl()));
			}

			if (StringUtils.isNotEmpty(fileDetail.getFirstClassCapacity())) {
				flightDataDetails.setfCabinBlockCapacity(Integer.valueOf(fileDetail.getFirstClassCapacity()));
			}

			if (StringUtils.isNotEmpty(fileDetail.getBusinessClassCapacity())) {
				flightDataDetails.setcCabinBlockCapacity(Integer.valueOf(fileDetail.getBusinessClassCapacity()));
			}

			if (StringUtils.isNotEmpty(fileDetail.getPremiumEcoClassCapacity())) {
				flightDataDetails.setwCabinBlockCapacity(Integer.valueOf(fileDetail.getPremiumEcoClassCapacity()));
			}

			if (StringUtils.isNotEmpty(fileDetail.getEconomyClassCapacity())) {
				flightDataDetails.setyCabinBlockCapacity(Integer.valueOf(fileDetail.getEconomyClassCapacity()));
			}

			Integer premiumEcCbnControl = 0;

			if (StringUtils.isNotEmpty(fileDetail.getFirstClassCabinControl())
					&& StringUtils.isNotEmpty(fileDetail.getBusinessCabinControl())
					&& StringUtils.isNotEmpty(fileDetail.getPremiumEconomyCabinControl())
					&& StringUtils.isNotEmpty(fileDetail.getEconomyCabinControl())) {

				flightDataDetails.setReceivedPaxCount(Integer.valueOf(fileDetail.getFirstClassCabinControl())
						+ Integer.valueOf(fileDetail.getBusinessCabinControl())
						+ Integer.valueOf(fileDetail.getPremiumEconomyCabinControl())
						+ Integer.valueOf(fileDetail.getEconomyCabinControl()));
			} else {
				flightDataDetails.setReceivedPaxCount(Integer.valueOf(fileDetail.getFirstClassCabinControl())
						+ Integer.valueOf(fileDetail.getBusinessCabinControl()) + premiumEcCbnControl
						+ Integer.valueOf(fileDetail.getEconomyCabinControl()));
			}

			flightDataDetails.setActualPaxCount(0);
			flightDataDetails.setMismatchPaxCount(
					flightDataDetails.getReceivedPaxCount() - flightDataDetails.getActualPaxCount());
			flightDataDetails.setInfantCount(Integer.valueOf(fileDetail.getTotalInfant()));

			flightDataDetails.setBalanceFlag(BALANCE_FLAG_DEFAULT);
			if (StringUtils.isNotEmpty(fileDetail.getDeadload())) {
				flightDataDetails.setDeadLoadCapacity(Long.valueOf(fileDetail.getDeadload()));
			}
			flightDataDetails.setSsimInd(SSIM_IND_N);
			flightDataDetails.setDataSource(BHRConstants.BHR_DATA_SOURCE_STATUS);
			flightDataDetails.setFlightStatus(BHRConstants.FLIGHT_STATUS_OPEN);
			flightDataDetails.setCreatedBy(fileDetail.getCreatedBy());
			flightDataDetails.setCreatedDate(new Timestamp(new Date().getTime()));
			try {
				LOGGER.info("smartpraFlownClient.createFlightDataDetails(flightDataDetails) - start with flightNumber::"
						+ flightDataDetails.getFlightNumber());

				flightDataDetails = smartpraFlownClient.createFlightDataDetails(flightDataDetails);
				// createFlightControlDetails(fileDetail, flightDataDetails);

				LOGGER.info("smartpraFlownClient.createFlightDataDetails(flightDataDetails) - End with flightNumber::"
						+ flightDataDetails.getFlightNumber());
			} catch (FeignException fex) {
				LOGGER.info("Error in Flight Creation-Start");
				BHRCountReader.incErrorCount();

				Map<String, String> paramsMap = new HashMap<>();
				paramsMap.put(BHRConstants.LIFT1008_PARAM_1, fileDetail.getFlightNumber());
				paramsMap.put(BHRConstants.LIFT1008_PARAM_2, fileDetail.getFromAirport());
				paramsMap.put(BHRConstants.LIFT1008_PARAM_3, fileDetail.getToAirport());
				paramsMap.put(BHRConstants.LIFT1008_PARAM_4, flightDate);

				prepareExceptionTransactionModel(BHRConstants.BHR_FILE_ERROR_IN_CREATING_FLIFGHT_LIFT1008, paramsMap,
						fileDetail);
				LOGGER.info("Error in Flight Creation-End");
				return null;
			}
		}
		LOGGER.info("BHRProdProcessor.process() - end");
		BHRCountReader.incTransferCount();
		return null;
	}

	private void createFlightControlDetails(FlightBatchHeaderStg fileDetail, FlightDataDetails flightDataDetails) {
		Integer receivedCount = null;
		BHRCommonUtil commonUtil = new BHRCommonUtil();
		LOGGER.info("smartpraMasterAppClient.getFlightControls(clientId) - start");
		List<FlightControl> flightControls = smartpraMasterAppClient.getFlightControls(fileDetail.getClientId());
		LOGGER.info("smartpraMasterAppClient.getFlightControls(clientId) - End");
		flightControls.sort(Comparator.comparing((FlightControl fc) -> fc.getControlType().get()).reversed());
		String flightDate = BHRCommonUtil.getDate(fileDetail.getFlightDate())
				.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		Map<String, Object> controlMap = new HashMap<>();
		if (CollectionUtils.isNotEmpty(flightControls)) {
			for (FlightControl flightControl : flightControls) {
				FlightControlDetails flightControlDetails = new FlightControlDetails();
				flightControlDetails.setClientId(fileDetail.getClientId());
				flightControlDetails.setFlightKey(flightDataDetails.getFlightKey());
				flightControlDetails.setFlightNumber(fileDetail.getFlightNumber());
				flightControlDetails.setFromAirport(fileDetail.getFromAirport());
				flightControlDetails.setToAirport(fileDetail.getToAirport());
				flightControlDetails.setFlightDate(BHRCommonUtil.getDate(fileDetail.getFlightDate()));
				flightControlDetails.setControlId(flightControl.getFlightControlId().get());

				String ctrlInd1 = null;
				String ctrlVal1 = null;
				String ctrlInd2 = null;
				String ctrlVal2 = null;
				String ctrlInd3 = null;
				String ctrlVal3 = null;
				String ctrlInd4 = null;
				String ctrlVal4 = null;
				String selfOalInd = null;

				if (flightControl.getControlIndicator1().isPresent()) {
					ctrlInd1 = flightControl.getControlIndicator1().get();
				}

				if (flightControl.getControlValue1().isPresent()) {
					ctrlVal1 = flightControl.getControlValue1().get();
				}

				if (flightControl.getControlIndicator2().isPresent()) {
					ctrlInd2 = flightControl.getControlIndicator2().get();
				}
				if (flightControl.getControlValue2().isPresent()) {
					ctrlVal2 = flightControl.getControlValue2().get();
				}

				if (flightControl.getControlIndicator3().isPresent()) {
					ctrlInd3 = flightControl.getControlIndicator3().get();
				}
				if (flightControl.getControlValue3().isPresent()) {
					ctrlVal3 = flightControl.getControlValue3().get();
				}
				if (flightControl.getControlIndicator4().isPresent()) {
					ctrlInd4 = flightControl.getControlIndicator4().get();
				}
				if (flightControl.getControlValue4().isPresent()) {
					ctrlVal4 = flightControl.getControlValue4().get();
				}
				if (flightControl.getSelfOalIndicator().isPresent()) {
					selfOalInd = flightControl.getSelfOalIndicator().get();
				}

				if (flightControl.getControlType().get().equalsIgnoreCase(CONTROL_VALUE)) {

					if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(CABIN)) {
						receivedCount = commonUtil.receivedCountCalculationCabin1(fileDetail, ctrlInd1, ctrlVal1,
								ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(CABIN)) {
						receivedCount = commonUtil.receivedCountCalculationCabin2(fileDetail, ctrlInd1, ctrlVal1,
								ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(CABIN)) {
						receivedCount = commonUtil.receivedCountCalculationCabin3(fileDetail, ctrlInd1, ctrlVal1,
								ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(CABIN)) {
						receivedCount = commonUtil.receivedCountCalculationCabin4(fileDetail, ctrlInd1, ctrlVal1,
								ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					}

					// Handling Non Revenue Indicator-for infant
					if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal1.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.infantCount1(fileDetail, ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3,
								ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal2.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.infantCount2(fileDetail, ctrlInd1, ctrlVal1, ctrlInd3, ctrlVal3,
								ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal3.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.infantCount3(fileDetail, ctrlInd1, ctrlVal1, ctrlInd2, ctrlVal2,
								ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal4.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.infantCount4(fileDetail, ctrlInd1, ctrlVal1, ctrlInd2, ctrlVal2,
								ctrlInd3, ctrlVal3);

					}

					// Handling MCO/EMD/FIN
					if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT))) {
						receivedCount = commonUtil.emdMcoEbtCount1(fileDetail, selfOalInd, ctrlInd1, ctrlVal1, ctrlInd2,
								ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
							&& (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT))) {
						receivedCount = commonUtil.emdMcoEbtCount2(fileDetail, selfOalInd, ctrlInd1, ctrlVal1, ctrlInd2,
								ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal3.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.emdMcoEbtCount3(fileDetail, selfOalInd, ctrlInd1, ctrlVal1, ctrlInd2,
								ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal4.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.emdMcoEbtCount4(fileDetail, selfOalInd, ctrlInd1, ctrlVal1, ctrlInd2,
								ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					}

					flightControlDetails.setReceivedCount(receivedCount != null ? receivedCount : 0);
					controlMap.put(flightControl.getFlightControlId().get(), receivedCount);
				} // END V

				if (flightControl.getControlType().get().equalsIgnoreCase(CONTROL_CAL)) {
					// formula evaluation
					receivedCount = commonUtil.parseControlFormula(flightControl.getControlFormula().get(), controlMap);
					flightControlDetails.setReceivedCount(receivedCount != null ? receivedCount : 0);
					controlMap.put(flightControl.getFlightControlId().get(), receivedCount);
				}
				flightControlDetails.setActualCount(0);
				flightControlDetails.setMismatchCount(0);
				flightControlDetails.setCreatedBy(fileDetail.getCreatedBy());
				flightControlDetails.setCreatedDate(new Timestamp(new Date().getTime()));

				try {
					smartpraFlownClient.createFlightControlDetails(flightDataDetails.getFlightKey(),
							flightControlDetails);
				} catch (FeignException fex) {
					LOGGER.info("Error in Flight Control Details Creation-Start");
					BHRCountReader.incErrorCount();

					Map<String, String> paramsMap = new HashMap<>();
					paramsMap.put(BHRConstants.LIFT1009_PARAM_1, fileDetail.getFlightNumber());
					paramsMap.put(BHRConstants.LIFT1009_PARAM_2, fileDetail.getFromAirport());
					paramsMap.put(BHRConstants.LIFT1009_PARAM_3, fileDetail.getToAirport());
					paramsMap.put(BHRConstants.LIFT1009_PARAM_4, flightDate);

					prepareExceptionTransactionModel(BHRConstants.BHR_FILE_ERROR_IN_POPULATE_FLOIGHT_CONTROL_LIFT1009,
							paramsMap, fileDetail);
					LOGGER.info("Error in Flight Control Details Creation-End");
				}
			}
		}
	}

	private void prepareExceptionTransactionModel(String excepCode, Map<String, String> paramsMap,
			FlightBatchHeaderStg fileDetail) {
		LOGGER.info("prepareExceptionTransactionModel()-Start");
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		String issueCxr = BHRCommonUtil.getHostCarrierNumericCode(smartpraMasterAppClient);
		String clientId = BHRCommonUtil.getHostCarrierDesigCode(smartpraMasterAppClient);
		exceptionTransactionModel.setExceptionCode(excepCode);
		exceptionTransactionModel.setClientId(clientId);
		exceptionTransactionModel.setIssuedCarrier(issueCxr);
		exceptionTransactionModel.setOrderId(String.valueOf(2));// for future use
		exceptionTransactionModel.setCreatedBy(BHRConstants.BHR_EXCEP_CREATEDBY);
		exceptionTransactionModel.setEnvironment(BHRConstants.BHR_EXCEP_ENVIRONMENT_S);
		exceptionTransactionModel.setFileId((long) fileDetail.getFileId());
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setStagingReferenceId(fileDetail.getBatchHdrId().longValue());

		exceptionTransactionModel.setBatchKey1(fileDetail.getFlightNumber());
		exceptionTransactionModel.setBatchKey2(fileDetail.getFromAirport());
		exceptionTransactionModel.setBatchKey3(fileDetail.getToAirport());
		exceptionTransactionModel.setBatchKey4(BHRConstants.FLIGHT_INDICATOR.toString());
		Date date = Date.from(
				BHRCommonUtil.getDate(fileDetail.getFlightDate()).atStartOfDay(ZoneId.systemDefault()).toInstant());
		exceptionTransactionModel.setBatchKey5(asLocalDateTime(date));
		exceptionTransactionModel.setBatchKey6(LocalDateTime.now());

		if (paramsMap != null) {
			List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
			ExceptionParametersValueModel parametersValueModel;
			for (String name : paramsMap.keySet()) {
				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName(name);
				parametersValueModel.setParameterValue(paramsMap.get(name));
				parametersValueModelList.add(parametersValueModel);
			}
			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
		}
		exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
		LOGGER.info("prepareExceptionTransactionModel()-End");
	}

	public static LocalDateTime asLocalDateTime(Date date) {
		return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
	}
}
