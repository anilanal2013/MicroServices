package com.sgl.smartpra.batch.bhr.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class BatchHeaderInFileLayout extends FixedLengthRecordLayout{

    public BatchHeaderInFileLayout(){
        fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightNumber",1,4));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fromAirport",5,7));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("toAirport",8,10));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightDate",11,16));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("aircraftRegistration",17,24));
        
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("firstClassCabinControl",25,27));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("businessCabinControl",28,30));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("economyCabinControl",31,33));
        
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalInfant",34,36));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("eTicketCount",37,39));
        
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ownMcoCount",43,48));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ownEbtCount",49,54));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ownEmdCount",55,60));
        
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oalPaxCount",61,66));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oalMcoCount",67,72));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oalEbtCount",73,78));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oalEmdCount",79,84));
        
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("payload",85,100));
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("deadload",101,115));
                
        fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("premiumEconomyCabinControlTemp", 116, null));   
        //fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("firstClassCapacity",120,122));
        //fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("businessClassCapacity",123,125));
        //fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("economyClassCapacity",126,128));
        //fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("premiumEcoClassCapacity",129,null));
        
        
        
    }
}
