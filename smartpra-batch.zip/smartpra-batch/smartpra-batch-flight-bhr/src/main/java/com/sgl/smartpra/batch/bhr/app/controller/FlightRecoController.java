package com.sgl.smartpra.batch.bhr.app.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.bhr.app.domain.PaxManiFest;
import com.sgl.smartpra.batch.bhr.app.service.FlightRecoService;

@RestController
@RequestMapping("/fligt-reco")
public class FlightRecoController {

	@Autowired
	private FlightRecoService flightRecoService;

	@GetMapping("/invoke-job")
	public String handle(@RequestParam("fileName") String fileName) {
		return flightRecoService.readFile(fileName, "Manual");

	}

	@GetMapping("/pnr-details")
	public List<PaxManiFest> viewPassengerDetails(
			@RequestParam(value = "flightNumber", required = true) String flightNumber,
			@RequestParam(value = "flightDate", required = true)@DateTimeFormat(pattern="yyyy-MM-dd") Date flightDate,
			@RequestParam(value = "fromCity", required = true) String fromCity,
			@RequestParam(value = "toCity", required = true) String toCity,
			@RequestParam(value = "flightRecoStatus", required = false) String flightRecoStatus) {
		return flightRecoService.getPassengerDetails(flightNumber, flightDate, fromCity, toCity,
				flightRecoStatus);
	}

}
