package com.sgl.smartpra.batch.bhr.app.config;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.model.FlightControlDetails;
import com.sgl.smartpra.flown.model.FlightDataDetails;
import com.sgl.smartpra.flown.model.FlightFutureSchedule;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.master.model.Aircraft;
import com.sgl.smartpra.master.model.Flight;
import com.sgl.smartpra.master.model.FlightControl;
import com.sgl.smartpra.master.model.ListOfValues;
import com.sgl.smartpra.master.model.SystemParameter;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-batch-global-app")
	public interface BatchGlobalFeignClient {

		@PostMapping("/filelog")
		public FileLogging createFileLog(@Valid @RequestBody FileLogging fileLog);

		@GetMapping("/filelogs/filename/{fileName}")
		public List<FileLogging> getFileLogByFileName(@PathVariable(value = "fileName") String fileName);

		@GetMapping("/filelog/{fileId}")
		public FileLogging getFileLogByFileId(@PathVariable(value = "fileId") BigInteger fileId);

		@PutMapping("/filelog/{fileId}")
		public FileLogging updateFileLog(@PathVariable(value = "fileId") BigInteger fileId,
				@Valid @RequestBody FileLogging fileLog);
	}

	@FeignClient(value = "smartpra-master-app")
	public interface SmartpraMasterAppClient {

		@GetMapping("/system-parameters-with-date/clientId/{clientId}/parameterName/{parameterName}")
		public SystemParameter getSystemParameterByparameterNameAndClientId(
				@PathVariable(value = "parameterName", required = true) String parameterName,
				@PathVariable(value = "clientId", required = true) String clientId);
		@GetMapping("/aircrafts")
		public List<Aircraft> getAllAircraft(
				@RequestParam(value = "aircraftRegistration", required = false) String aircraftRegistration,
				@RequestParam(value = "aircraftType", required = false) String aircraftType,
				@RequestParam(value = "activate", required = false) Boolean activate);

		@GetMapping("/aircrafts")
		public List<Aircraft> getFlight(
				@RequestParam(value = "aircraftRegistration", required = false) String aircraftRegistration,
				@RequestParam(value = "aircraftType", required = false) String aircraftType);

		@GetMapping("/flight-control/clientId/{clientId}")
		public List<FlightControl> getFlightControls(
				@PathVariable(value = "clientId", required = true) String clientId);

		@GetMapping("/flightByFlightNumber")
		public Flight getFlightByFlightNumber(@RequestParam(value = "clientId", required = true) String clientId,
				@RequestParam(value = "effectiveDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") String effectiveDate,
				@RequestParam(value = "flightNumber", required = true) String flightNumber,
				@RequestParam(value = "from", required = true) String from,
				@RequestParam(value = "to", required = true) String to);

		@GetMapping("/listofvalues/{clientId}/{tableName}/{columnName}/{fieldValue}")
		public ListOfValues getListOfValues(@PathVariable(value = "clientId", required = true) String clientId,
				@PathVariable(value = "tableName", required = true) String tableName,
				@PathVariable(value = "columnName", required = true) String columnName,
				@PathVariable(value = "fieldValue", required = true) String fieldValue);
	}

	@FeignClient(value = "smartpra-flown-app")
	public interface SmartpraFlownClient {

		@PostMapping("/flight-data-details")
		public FlightDataDetails createFlightDataDetails(
				@Validated(Create.class) @RequestBody FlightDataDetails flightDataDetails);

		@GetMapping("/flight-data-details")
		public List<FlightDataDetails> getAllFlightDataDetails(
				@RequestParam(value = "flightNumber", required = false) String flightNumber,
				@RequestParam(value = "fromAirport", required = false) String fromAirport,
				@RequestParam(value = "toAirport", required = false) String toAirport,
				@RequestParam(value = "flightStatus", required = false) String flightStatus);

		@GetMapping("/flight-data-details/{flightKey}")
		public FlightDataDetails getFlightDataDetailsByflightKey(@PathVariable(value = "flightKey") Integer flightKey);

		@PutMapping("/flight-data-details/{flightKey}")
		public FlightDataDetails updateFlightDataDetails(@PathVariable(value = "flightKey") Integer flightKey,
				@RequestBody FlightDataDetails flightDataDetails);

		@PostMapping("/flight-data-details/{flightKey}/flight-control-details")
		public FlightControlDetails createFlightControlDetails(@PathVariable(value = "flightKey") Integer flightKey,
				@Validated(Create.class) @RequestBody FlightControlDetails flightControlDetails);

		@PutMapping("/flight-data-details/{flightKey}/flight-control-details/{flightControlDataId}")
		public FlightControlDetails updateFlightControlDetails(@PathVariable(value = "flightKey") Integer flightKey,
				@PathVariable(value = "flightControlDataId") Integer flightControlDataId,
				@Validated(Update.class) @RequestBody FlightControlDetails flightControlDetails);

		@GetMapping("/flight-schedule")
		public FlightFutureSchedule getFlightSchedule(
				@RequestParam(value = "clientId", required = false) String clientId,
				@RequestParam(value = "flightNumber", required = false) String flightNumber,
				@RequestParam(value = "fromAirport", required = false) String fromAirport,
				@RequestParam(value = "toAirport", required = false) String toAirport,
				@RequestParam(value = "flightDate", required = false) String flightDate);

		@GetMapping("/flight-data-details/{flightKey}/flight-control-details")
		public List<FlightControlDetails> getAllFlightControlDetails(
				@PathVariable(value = "flightKey") Integer flightKey,
				@RequestParam(value = "flightNumber", required = false) String flightNumber,
				@RequestParam(value = "fromAirport", required = false) String fromAirport,
				@RequestParam(value = "toAirport", required = false) String toAirport,
				@RequestParam(value = "flightStatus", required = false) String flightStatus);
		
		@GetMapping("/flight-data-details/search")
		public FlightDataDetails getFlightDataDetails(
				@RequestParam(value = "flightNumber", required = true) String flightNumber,
				@RequestParam(value = "fromAirport", required = true) String fromAirport,
				@RequestParam(value = "toAirport", required = true) String toAirport,
				@RequestParam(value = "flightDate", required = true)  LocalDate flightDate,
				@RequestParam(value = "flightStatus", required = false) String flightStatus);

	}

	@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface ExceptionTransIntgAppClient {

		@PostMapping("/api/init-exceptionmessage")
		public void initExceptionTrasaction(@RequestBody ExceptionTransactionModel exceptionTransactionModel);
	}

	@FeignClient(value = "smartpra-global-master-app")
	public interface GlobalMasterFeignClient {
		@GetMapping("/airports/{airportCode}")
		public Airport getAirportByAirportCode(@PathVariable(value = "airportCode") String airportCode);
	}
}
