package com.sgl.smartpra.batch.bhr.app.util;

public class FlightRecoCountReader {
	private static FlightRecoCountReader instance = null;

	private static Integer transferCount = 0;
	private static Integer errorCount = 0;
	private static Integer totalCount = 0;

	private FlightRecoCountReader() {

	}
	
	public static FlightRecoCountReader getInstance() {
		if (instance == null) {
			synchronized (FlightRecoCountReader.class) {
				if (instance == null) {
					instance = new FlightRecoCountReader();
				}
			}
		}
		return instance;
	}

	synchronized public static void incErrorCount() {
		errorCount++;
	}

	synchronized public static void incTransferCount() {
		transferCount++;
	}

	synchronized public static void incTotalCount() {
		totalCount++;
	}

	synchronized public static Integer getErrorCount() {
		return errorCount;
	}

	synchronized public static Integer getTransferCount() {
		return transferCount;
	}

	synchronized public static Integer getTotalCount() {
		return totalCount;
	}

	synchronized public static void resetCounts() {
		transferCount = 0;
		errorCount = 0;
		totalCount = 0;
	}

}
