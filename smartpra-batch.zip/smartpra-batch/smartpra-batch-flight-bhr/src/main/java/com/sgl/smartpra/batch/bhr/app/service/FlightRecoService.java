package com.sgl.smartpra.batch.bhr.app.service;

import java.util.Date;
import java.util.List;

import com.sgl.smartpra.batch.bhr.app.domain.PaxManiFest;

public interface FlightRecoService {

	public String readFile(String fileName, String processedBy);

	public List<PaxManiFest> getPassengerDetails(String flightNumber, Date flightDate, String fromCity,
			String toCity, String flightRecoStatus);

}
