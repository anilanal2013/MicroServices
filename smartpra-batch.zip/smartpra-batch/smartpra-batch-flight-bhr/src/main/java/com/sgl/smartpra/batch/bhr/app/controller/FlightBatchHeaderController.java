package com.sgl.smartpra.batch.bhr.app.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.bhr.app.service.BatchHeaderService;

@RestController
public class FlightBatchHeaderController {

	private static final Logger LOGGER = LoggerFactory.getLogger(FlightBatchHeaderController.class);

	@Autowired
	BatchHeaderService batchHeaderService;

	@RequestMapping("/flightBhrInFile/version/{version}/invokejob")
	public String handle(@RequestParam("fileName") String fileName,@PathVariable("version") String version) throws Exception {
		LOGGER.info("RequestFileBatchController : handle ");
		return batchHeaderService.executeBhrStgInboundJob(fileName, "Manual", version);
	}

}
