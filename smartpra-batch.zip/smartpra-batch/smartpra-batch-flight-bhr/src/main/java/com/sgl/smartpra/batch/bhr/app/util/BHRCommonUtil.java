package com.sgl.smartpra.batch.bhr.app.util;

import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.CABIN;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.CABIN_C;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.CABIN_F;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.CABIN_W;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.CABIN_Y;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.DOC_TYPE;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.DOC_TYPE_EBT;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.DOC_TYPE_EMD;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.DOC_TYPE_MCO;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.DOC_TYPE_PAX;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.PAX_TYPE;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.PAX_TYPE_I;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.SELF_OAL_B;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.SELF_OAL_O;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.SELF_OAL_S;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.script.SimpleBindings;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.service.spi.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.ExceptionTransIntgAppClient;
import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.constant.SmartPRAConstant;
import com.sgl.smartpra.common.model.FileType;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.SystemParameter;

public class BHRCommonUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(BHRCommonUtil.class);

	/**
	 * This method will initialize the filelogging object with basic data.
	 * 
	 * @return
	 */
	
	public static FileLogging initFileLogging() {

		FileLogging fileLogging = new FileLogging();
		fileLogging.setFileCategory(FileLoggingConstants.FILELOGGING_FILECATEGORY_TEXT);
		fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setModuleName(BHRConstants.FILELOGGING_MODULE);
		fileLogging.setSource(BHRConstants.BHR);
		fileLogging.setCreatedBy(BHRConstants.CREATEDBY);
		fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));

		// may not be mandatory
		fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_STARTED);
		fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setTotalCounts(0);
		fileLogging.setTransferredCounts(0);
		fileLogging.setIsEncryptedPostSuccess("N");
		fileLogging.setIsEncryptedPriorLoading("N");
		fileLogging.setIsRenamedPostSuccess("N");
		fileLogging.setIsMovedToRelevantFolder("N");
		fileLogging.setIsNotificationSent("N");
		fileLogging.setModuleId(BHRConstants.MODULE_ID);
		return fileLogging;
	}

	public static List<String> unzipFiles(String sourceDir, String destinationDir) {
		byte[] buffer = new byte[1024];
		List<String> unzipedFiles = new ArrayList<>();
		try {
			File dir = new File(sourceDir);
			File[] listOfFiles = dir.listFiles();

			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(".zip")) {
					ZipInputStream zis = new ZipInputStream(
							new FileInputStream(new File(sourceDir + File.separator + listOfFiles[i].getName())));
					ZipEntry ze = zis.getNextEntry();
					while (ze != null) {
						String fileName = ze.getName();
						File outPut = new File(destinationDir + File.separator + fileName);
						FileOutputStream fos = new FileOutputStream(outPut);
						int len;
						while ((len = zis.read(buffer)) > 0) {
							fos.write(buffer, 0, len);
						}
						unzipedFiles.add(fileName);
						fos.close();
						ze = zis.getNextEntry();
					}
					zis.closeEntry();
					zis.close();
				} else if (listOfFiles[i].isDirectory()) {
					LOGGER.info(" Directory " + listOfFiles[i].getName());
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new ServiceException(e.getMessage());

		}

		return unzipedFiles;
	}

	/**
	 * This method is used to move a file from one folder to another folder.
	 * 
	 * @param source
	 * @param target
	 * @return
	 */
	public static boolean moveFile(String source, String target) {
		Path moveResp = null;
		try {
			moveResp = Files.move(Paths.get(source), Paths.get(target));
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return moveResp != null ? true : false;
	}

	public static String getFileSize(String fileName) {
		File fileObj = new File(fileName);
		return FileUtils.byteCountToDisplaySize(fileObj.length());
	}

	public static String padString(String str, String pad, final Integer maxLen) {
		int length = str.length();
		StringBuilder stringBuilder = new StringBuilder();
		while (length < maxLen) {
			stringBuilder.append(pad.trim());
			++length;
		}
		return stringBuilder.toString() + str;
	}

	// converts DDMMYY string date to java date
	public static LocalDate getDate(String StrDate) {
		String day = StrDate.substring(0, 2);
		String month = StrDate.substring(2, 4);
		String year = "20" + StrDate.substring(4, 6);
		String dateStr = year + "-" + month + "-" + day;
		return LocalDate.parse(dateStr);
		/*
		 * Date date = null; String dateStr = year + "-" + month + "-" + day;
		 * SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		 * 
		 * try { date = formatter.parse(dateStr); } catch (ParseException e) {
		 * e.printStackTrace(); } return date;
		 */
	}

	public static String convertDate(String StrDate) {
		String day = StrDate.substring(0, 2);
		String month = StrDate.substring(2, 4);
		String year = "20" + StrDate.substring(4, 6);
		String dateStr = year + "-" + month + "-" + day;

		return dateStr;
	}

	/**
	 * This method will get the host carrier designator code.
	 * 
	 * @param parameterName
	 * @return
	 */
	public static String getHostCarrierDesigCode(SmartpraMasterAppClient smartpraMasterAppClient) {
		String hostCarrierDesigCode = null;
		
		SystemParameter systemParameter = smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(BHRConstants.PARAM_DEFAULT_CARRIER_ALPHA_CODE,SmartPRAConstant.CLIENT_ID);
		if (systemParameter != null) {
			hostCarrierDesigCode = systemParameter.getParameterRangeFrom().get();
		}
		return hostCarrierDesigCode;
	}
	
	public static String getHostCarrierNumericCode(SmartpraMasterAppClient smartpraMasterAppClient) {
		String hostCarrierNumericCode = null;
		SystemParameter systemParameter = smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(BHRConstants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE,SmartPRAConstant.CLIENT_ID);
		if (systemParameter != null) {
			hostCarrierNumericCode = systemParameter.getParameterRangeFrom().get();
		}
		return hostCarrierNumericCode;
	}

	public static String getFlightNumberOption(SmartpraMasterAppClient smartpraMasterAppClient) {
		String flightNumberOption = null;
		SystemParameter systemParameter = smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(BHRConstants.FLIGHT_NUMBER_OPTION,SmartPRAConstant.CLIENT_ID);
		if (systemParameter != null) {
			flightNumberOption = systemParameter.getParameterRangeFrom().get();
		}
		return flightNumberOption;
	}

	public static String derivedFlightNumber(String flightNumber, String flightNumberOption) {

		switch (flightNumberOption) {
		case "0":
			flightNumber = flightNumber.length() > 4 ? flightNumber.substring(flightNumber.length() - 4) : flightNumber;
			break;

		case "3":
			flightNumber = flightNumber.length() > 3 ? flightNumber.substring(flightNumber.length() - 3)
					: flightNumber.length() < 3 ? SmartPRACommonUtil.padString(flightNumber, "0", 3) : flightNumber;
			break;

		case "4":
			flightNumber = flightNumber.length() > 4 ? flightNumber.substring(flightNumber.length() - 4)
					: flightNumber.length() < 4 ? SmartPRACommonUtil.padString(flightNumber, "0", 4) : flightNumber;
			break;

		}

		return flightNumber;
	}

	/*public static String validateFile(String fileName) {
		String errorMessage = null;
		File file = new File(fileName);
		String fileNm = file.getName();
		if (!SmartpraFileUtility.fileExists(fileName)) {
			return errorMessage = "File " + fileNm + " not found";
		}

		if (SmartpraFileUtility.isEmptyFile(fileName)) {
			return errorMessage = fileNm + " has no record i.e. Blank file reported";
		}

		if (!isValidFileName(fileName)) {
			return errorMessage = "File name " + fileNm + " is not as per specification";
		}
		return errorMessage;
	}

	public static boolean isValidFileName(String fileName) {
		boolean isValid = true;
		File file = new File(fileName);
		String fName = file.getName();// BHR2606192247
		String fileConstant = fName.substring(0, 3);
		String fileExt = fName.substring(fName.lastIndexOf('.') + 1, fName.length());
		String days = fName.substring(3, 5);
		String month = fName.substring(5, 7);
		String year = fName.substring(7, 9);
		String hrs = fName.substring(9, 11);
		String mnts = fName.substring(11, 13);

		if (fName.length() < 13 || fName.length() > 17) {
			isValid = false;
		}
		if (!fileConstant.equals(BHRConstants.BHR)) {
			isValid = false;
		}

		if (!FileType.contains(fileExt)) {
			isValid = false;
		}
		isValid = isValidDate(Integer.valueOf(days), Integer.valueOf(month), Integer.valueOf("20" + year));

		if (Integer.valueOf(hrs) < 0 || (Integer.valueOf(hrs) >= 24)) {
			isValid = false;
		}

		if (Integer.valueOf(mnts) < 0 || (Integer.valueOf(mnts) >= 60)) {
			isValid = false;
		}

		return isValid;
	}

	public static boolean isValidDate(int day, int month, int year) {
		boolean isValidDate = true;

		List<Integer> months31Days = Arrays.asList(1, 3, 5, 7, 8, 10, 12);
		List<Integer> months30Days = Arrays.asList(4, 6, 9, 11);
		if (day <= 0 || day > 31 || month <= 0 || month > 12 || year <= 0
				|| year != Calendar.getInstance().get(Calendar.YEAR)) {
			isValidDate = false;
		} else if (months31Days.contains(month)) {
			if (day > 31) {
				isValidDate = false;
			}
		} else if (months30Days.contains(month)) {
			if (day > 30) {
				isValidDate = false;
			}

		} else if (month == 2) // February check
		{
			if (year % 4 == 0) // Leap year check for February
			{
				if (day > 29) {
					isValidDate = false;
				}
			} else if (year % 4 != 0) {
				if (day > 28) {
					isValidDate = false;
				}
			}
		}

		return isValidDate;
	}*/

	public Integer receivedCountCalculationCabin1(FlightBatchHeaderStg fileDetail, String ctrlInd1, String ctrlVal1,
			String ctrlInd2, String ctrlVal2, String ctrlInd3, String ctrlVal3, String ctrlInd4, String ctrlVal4) {
		Integer receivedCount = null;

		// empty scenarios
		if (StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd4)) {
			return getCabinControl(fileDetail, ctrlVal1);
		}

		if (StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3)) {
			if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)) {
				return getCabinControl(fileDetail, ctrlVal1);
			}
		}

		if (StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd4)) {
			if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)) {
				return getCabinControl(fileDetail, ctrlVal1);
			}
		}

		if (StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd4)) {
			if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)) {

				return getCabinControl(fileDetail, ctrlVal1);
			}
		}

		if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal1);
		}

		if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal1);
		}

		if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal1);
		}

		if (StringUtils.isEmpty(ctrlInd2)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal1);
			}
		}

		if (StringUtils.isEmpty(ctrlInd3)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase("PAXType")
					&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal1);
			}
		}

		if (StringUtils.isEmpty(ctrlInd4)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal1);
			}
		}

		// repeating values
		if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(CABIN) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(ctrlVal1))
				|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(CABIN)
						&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(ctrlVal1))
				|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(CABIN)
						&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(ctrlVal1))) {

			return getCabinControl(fileDetail, ctrlVal1);
		}

		// END CONTROL INDICATOR-1

		return receivedCount;
	}

	public Integer receivedCountCalculationCabin2(FlightBatchHeaderStg fileDetail, String ctrlInd1, String ctrlVal1,
			String ctrlInd2, String ctrlVal2, String ctrlInd3, String ctrlVal3, String ctrlInd4, String ctrlVal4) {
		Integer receivedCount = null;

		// empty scenarios
		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd4)) {
			return getCabinControl(fileDetail, ctrlVal2);
		}

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd3)) {
			if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)) {
				return getCabinControl(fileDetail, ctrlVal2);
			}
		}

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd4)) {
			if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)) {
				return getCabinControl(fileDetail, ctrlVal2);
			}
		}

		if (StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd4)) {
			if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)) {

				return getCabinControl(fileDetail, ctrlVal2);
			}
		}

		if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal2);
		}

		if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal2);
		}

		if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal2);
		}

		if (StringUtils.isEmpty(ctrlInd1)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal2);
			}
		}

		if (StringUtils.isEmpty(ctrlInd3)) {
			if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase("PAXType")
					&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal2);
			}
		}

		if (StringUtils.isEmpty(ctrlInd4)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal2);
			}
		}

		// repeating values
		if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(CABIN) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(ctrlVal2))
				|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(CABIN)
						&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(ctrlVal2))
				|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(CABIN)
						&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(ctrlVal2))) {

			return getCabinControl(fileDetail, ctrlVal2);
		}

		// END CONTROL INDICATOR-2

		return receivedCount;
	}

	public Integer receivedCountCalculationCabin3(FlightBatchHeaderStg fileDetail, String ctrlInd1, String ctrlVal1,
			String ctrlInd2, String ctrlVal2, String ctrlInd3, String ctrlVal3, String ctrlInd4, String ctrlVal4) {
		Integer receivedCount = null;

		// empty scenarios
		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd4)) {
			return getCabinControl(fileDetail, ctrlVal3);
		}

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2)) {
			if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)) {
				return getCabinControl(fileDetail, ctrlVal3);
			}
		}

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd4)) {
			if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)) {
				return getCabinControl(fileDetail, ctrlVal3);
			}
		}

		if (StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd4)) {
			if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)) {

				return getCabinControl(fileDetail, ctrlVal3);
			}
		}

		if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal3);
		}

		if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal3);
		}

		if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal3);
		}

		if (StringUtils.isEmpty(ctrlInd1)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal3);
			}
		}

		if (StringUtils.isEmpty(ctrlInd2)) {
			if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && !ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal2);
			}
		}

		if (StringUtils.isEmpty(ctrlInd4)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal3);
			}
		}
		// repeating values
		if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(CABIN) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(ctrlVal3))
				|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(CABIN)
						&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(ctrlVal3))
				|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(CABIN)
						&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(ctrlVal3))) {

			return getCabinControl(fileDetail, ctrlVal3);
		}
		// END CONTROL INDICATOR-3
		return receivedCount;
	}

	public Integer receivedCountCalculationCabin4(FlightBatchHeaderStg fileDetail, String ctrlInd1, String ctrlVal1,
			String ctrlInd2, String ctrlVal2, String ctrlInd3, String ctrlVal3, String ctrlInd4, String ctrlVal4) {

		Integer receivedCount = null;

		// empty scenarios
		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3)) {
			return getCabinControl(fileDetail, ctrlVal4);
		}

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2)) {
			if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)) {
				return getCabinControl(fileDetail, ctrlVal4);
			}
		}

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd3)) {
			if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)) {
				return getCabinControl(fileDetail, ctrlVal4);
			}
		}

		if (StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3)) {
			if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)) {

				return getCabinControl(fileDetail, ctrlVal4);
			}
		}

		if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal4);
		}

		if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal4);
		}

		if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))) {

			return getCabinControl(fileDetail, ctrlVal4);
		}

		if (StringUtils.isEmpty(ctrlInd1)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal4);
			}
		}

		if (StringUtils.isEmpty(ctrlInd2)) {
			if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && !ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal4);
			}
		}

		if (StringUtils.isEmpty(ctrlInd3)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && !ctrlVal1.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && !ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX))) {

				return getCabinControl(fileDetail, ctrlVal4);
			}
		}

		// repeating values
		if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(CABIN) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(ctrlVal4))
				|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(CABIN)
						&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(ctrlVal4))
				|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(CABIN)
						&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(ctrlVal4))) {

			return getCabinControl(fileDetail, ctrlVal4);
		}
		// END CONTROL INDICATOR-4

		return receivedCount;
	}

	private Integer getCabinControl(FlightBatchHeaderStg fileDetail, String ctrlValue) {
		if (ctrlValue.equalsIgnoreCase(CABIN_F)) {
			return Integer.valueOf(fileDetail.getFirstClassCabinControl());
		}
		if (ctrlValue.equalsIgnoreCase(CABIN_C)) {
			return Integer.valueOf(fileDetail.getBusinessCabinControl());
		}
		if (ctrlValue.equalsIgnoreCase(CABIN_W)) {
			return Integer.valueOf(fileDetail.getPremiumEconomyCabinControl());
		}
		if (ctrlValue.equalsIgnoreCase(CABIN_Y)) {
			return Integer.valueOf(fileDetail.getEconomyCabinControl());
		}
		return null;
	}

	public Integer infantCount1(FlightBatchHeaderStg fileDetail, String ctrlInd2, String ctrlVal2, String ctrlInd3,
			String ctrlVal3, String ctrlInd4, String ctrlVal4) {

		if (StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd4)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isEmpty(ctrlInd2)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)
							&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if (StringUtils.isEmpty(ctrlInd3)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if (StringUtils.isEmpty(ctrlInd4)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
							&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if ((StringUtils.isEmpty(ctrlInd4) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd2)
				&& ctrlInd2.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if ((StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd4)
				&& ctrlInd4.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& ctrlVal4.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}
		if ((StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd4)) && StringUtils.isNotEmpty(ctrlInd3)
				&& ctrlInd3.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		return null;
	}

	public Integer infantCount2(FlightBatchHeaderStg fileDetail, String ctrlInd1, String ctrlVal1, String ctrlInd3,
			String ctrlVal3, String ctrlInd4, String ctrlVal4) {

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd4)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isEmpty(ctrlInd1)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)
							&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if (StringUtils.isEmpty(ctrlInd3)) {
			if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if (StringUtils.isEmpty(ctrlInd4)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
							&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if ((StringUtils.isEmpty(ctrlInd4) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd1)
				&& ctrlInd1.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd4)
				&& ctrlInd4.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& ctrlVal4.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}
		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd4)) && StringUtils.isNotEmpty(ctrlInd3)
				&& ctrlInd3.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		return null;
	}

	public Integer infantCount3(FlightBatchHeaderStg fileDetail, String ctrlInd1, String ctrlVal1, String ctrlInd2,
			String ctrlVal2, String ctrlInd4, String ctrlVal4) {

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd4)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isEmpty(ctrlInd1)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX)
							&& StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if (StringUtils.isEmpty(ctrlInd2)) {
			if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal4) && ctrlVal4.equalsIgnoreCase(DOC_TYPE_PAX))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if (StringUtils.isEmpty(ctrlInd4)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
							&& StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if ((StringUtils.isEmpty(ctrlInd4) && StringUtils.isEmpty(ctrlInd2)) && StringUtils.isNotEmpty(ctrlInd1)
				&& ctrlInd1.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2)) && StringUtils.isNotEmpty(ctrlInd4)
				&& ctrlInd4.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& ctrlVal4.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}
		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd4)) && StringUtils.isNotEmpty(ctrlInd2)
				&& ctrlInd2.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		return null;
	}

	public Integer infantCount4(FlightBatchHeaderStg fileDetail, String ctrlInd1, String ctrlVal1, String ctrlInd2,
			String ctrlVal2, String ctrlInd3, String ctrlVal3) {

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
				&& (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
						&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
						|| StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
								&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if (StringUtils.isEmpty(ctrlInd1)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX)
							&& StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if (StringUtils.isEmpty(ctrlInd2)) {
			if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)
							&& StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal3) && ctrlVal3.equalsIgnoreCase(DOC_TYPE_PAX))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if (StringUtils.isEmpty(ctrlInd3)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(DOC_TYPE_PAX)
					&& StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(PAX_TYPE)
					&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(PAX_TYPE_I))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal1) && ctrlVal1.equalsIgnoreCase(DOC_TYPE_PAX)
							&& StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(PAX_TYPE)
							&& StringUtils.isNotEmpty(ctrlVal2) && ctrlVal2.equalsIgnoreCase(PAX_TYPE_I))) {
				return Integer.valueOf(fileDetail.getTotalInfant());
			}
		}

		if ((StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd2)) && StringUtils.isNotEmpty(ctrlInd1)
				&& ctrlInd1.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& ctrlVal1.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2)) && StringUtils.isNotEmpty(ctrlInd3)
				&& ctrlInd3.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& ctrlVal3.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}
		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd2)
				&& ctrlInd2.equalsIgnoreCase(PAX_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& ctrlVal2.equalsIgnoreCase(PAX_TYPE_I)) {
			return Integer.valueOf(fileDetail.getTotalInfant());
		}

		return null;
	}

	public Integer emdMcoEbtCount1(FlightBatchHeaderStg fileDetail, String selfOalInd, String ctrlInd1, String ctrlVal1,
			String ctrlInd2, String ctrlVal2, String ctrlInd3, String ctrlVal3, String ctrlInd4, String ctrlVal4) {

		if (StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd4)) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal1);
		}

		if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
				&& (StringUtils.isNotEmpty(ctrlVal2) && (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT)
						|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))))
				|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
						&& (StringUtils.isNotEmpty(ctrlVal3) && (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT)
								|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))))
				|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
						&& (StringUtils.isNotEmpty(ctrlVal4)
								&& (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
										|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal1);
		}

		if (StringUtils.isEmpty(ctrlInd2)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal3) && (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal4) && (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal1);
			}
		}

		if (StringUtils.isEmpty(ctrlInd3)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal2) && (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal4) && (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal1);
			}
		}

		if (StringUtils.isEmpty(ctrlInd4)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal3) && (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal2) && (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal1);
			}
		}

		if ((StringUtils.isEmpty(ctrlInd4) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd2)
				&& ctrlInd2.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD)
						|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal1);
		}

		if ((StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd4)
				&& ctrlInd4.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
						|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal1);
		}
		if ((StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd4)) && StringUtils.isNotEmpty(ctrlInd3)
				&& ctrlInd3.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO)
						|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal1);
		}

		return null;
	}

	public Integer emdMcoEbtCount2(FlightBatchHeaderStg fileDetail, String selfOalInd, String ctrlInd1, String ctrlVal1,
			String ctrlInd2, String ctrlVal2, String ctrlInd3, String ctrlVal3, String ctrlInd4, String ctrlVal4) {

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd4)) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal2);
		}

		if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
				&& (StringUtils.isNotEmpty(ctrlVal1) && (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT)
						|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD))))
				|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
						&& (StringUtils.isNotEmpty(ctrlVal3) && (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT)
								|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))))
				|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
						&& (StringUtils.isNotEmpty(ctrlVal4)
								&& (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
										|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal2);
		}

		if (StringUtils.isEmpty(ctrlInd1)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal3) && (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal4) && (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal2);
			}
		}

		if (StringUtils.isEmpty(ctrlInd3)) {
			if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal1) && (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal4) && (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal2);
			}
		}

		if (StringUtils.isEmpty(ctrlInd4)) {
			if ((StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal3) && (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal1) && (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal2);
			}
		}

		if ((StringUtils.isEmpty(ctrlInd4) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd1)
				&& ctrlInd1.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD)
						|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal2);
		}

		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd4)
				&& ctrlInd4.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
						|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal2);
		}
		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd4)) && StringUtils.isNotEmpty(ctrlInd3)
				&& ctrlInd3.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO)
						|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal2);
		}

		return null;
	}

	public Integer emdMcoEbtCount3(FlightBatchHeaderStg fileDetail, String selfOalInd, String ctrlInd1, String ctrlVal1,
			String ctrlInd2, String ctrlVal2, String ctrlInd3, String ctrlVal3, String ctrlInd4, String ctrlVal4) {

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd4)) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal3);
		}

		if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
				&& (StringUtils.isNotEmpty(ctrlVal1) && (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT)
						|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD))))
				|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
						&& (StringUtils.isNotEmpty(ctrlVal2) && (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT)
								|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))))
				|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
						&& (StringUtils.isNotEmpty(ctrlVal4)
								&& (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
										|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal3);
		}

		if (StringUtils.isEmpty(ctrlInd1)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal2) && (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal4) && (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal3);
			}
		}

		if (StringUtils.isEmpty(ctrlInd2)) {
			if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal1) && (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal4) && (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal3);
			}
		}

		if (StringUtils.isEmpty(ctrlInd4)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal2) && (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal1) && (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal3);
			}
		}

		if ((StringUtils.isEmpty(ctrlInd4) && StringUtils.isEmpty(ctrlInd2)) && StringUtils.isNotEmpty(ctrlInd1)
				&& ctrlInd1.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD)
						|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal3);
		}

		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2)) && StringUtils.isNotEmpty(ctrlInd4)
				&& ctrlInd4.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal4)
				&& (ctrlVal4.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal4.equalsIgnoreCase(DOC_TYPE_MCO)
						|| ctrlVal4.equalsIgnoreCase(DOC_TYPE_EMD))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal3);
		}
		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd4)) && StringUtils.isNotEmpty(ctrlInd2)
				&& ctrlInd2.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO)
						|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal3);
		}

		return null;
	}

	public Integer emdMcoEbtCount4(FlightBatchHeaderStg fileDetail, String selfOalInd, String ctrlInd1, String ctrlVal1,
			String ctrlInd2, String ctrlVal2, String ctrlInd3, String ctrlVal3, String ctrlInd4, String ctrlVal4) {

		if (StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2) && StringUtils.isEmpty(ctrlInd3)) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal3);
		}

		if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
				&& (StringUtils.isNotEmpty(ctrlVal1) && (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT)
						|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD))))
				|| (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
						&& (StringUtils.isNotEmpty(ctrlVal2) && (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT)
								|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))))
				|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
						&& (StringUtils.isNotEmpty(ctrlVal3)
								&& (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO)
										|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal4);
		}

		if (StringUtils.isEmpty(ctrlInd1)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal2) && (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal3) && (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal4);
			}
		}

		if (StringUtils.isEmpty(ctrlInd2)) {
			if ((StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal1) && (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal3) && (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal4);
			}
		}

		if (StringUtils.isEmpty(ctrlInd3)) {
			if ((StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
					&& (StringUtils.isNotEmpty(ctrlVal2) && (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT)
							|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))))
					|| (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& (StringUtils.isNotEmpty(ctrlVal1) && (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT)
									|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD))))) {
				return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal4);
			}
		}

		if ((StringUtils.isEmpty(ctrlInd3) && StringUtils.isEmpty(ctrlInd2)) && StringUtils.isNotEmpty(ctrlInd1)
				&& ctrlInd1.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal1)
				&& (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD)
						|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal4);
		}

		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd2)) && StringUtils.isNotEmpty(ctrlInd3)
				&& ctrlInd3.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal3)
				&& (ctrlVal3.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal3.equalsIgnoreCase(DOC_TYPE_MCO)
						|| ctrlVal3.equalsIgnoreCase(DOC_TYPE_EMD))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal4);
		}
		if ((StringUtils.isEmpty(ctrlInd1) && StringUtils.isEmpty(ctrlInd3)) && StringUtils.isNotEmpty(ctrlInd2)
				&& ctrlInd2.equalsIgnoreCase(DOC_TYPE) && StringUtils.isNotEmpty(ctrlVal2)
				&& (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO)
						|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD))) {
			return getEbtEmdMco(fileDetail, selfOalInd, ctrlVal4);
		}

		return null;
	}

	private Integer getEbtEmdMco(FlightBatchHeaderStg fileDetail, String selfOalInd, String ctrlValue) {

		if (ctrlValue.equalsIgnoreCase(DOC_TYPE_MCO) && selfOalInd.equalsIgnoreCase(SELF_OAL_S)) {
			return Integer.valueOf(fileDetail.getOwnMcoCount());
		}
		if (ctrlValue.equalsIgnoreCase(DOC_TYPE_MCO) && selfOalInd.equalsIgnoreCase(SELF_OAL_O)) {
			return Integer.valueOf(fileDetail.getOalMcoCount());
		}
		if (ctrlValue.equalsIgnoreCase(DOC_TYPE_MCO) && selfOalInd.equalsIgnoreCase(SELF_OAL_B)) {
			return (Integer.valueOf(fileDetail.getOwnMcoCount()) + Integer.valueOf(fileDetail.getOalMcoCount()));
		}

		if (ctrlValue.equalsIgnoreCase(DOC_TYPE_EMD) && selfOalInd.equalsIgnoreCase(SELF_OAL_S)) {
			return Integer.valueOf(fileDetail.getOwnEmdCount());
		}
		if (ctrlValue.equalsIgnoreCase(DOC_TYPE_EMD) && selfOalInd.equalsIgnoreCase(SELF_OAL_O)) {
			return Integer.valueOf(fileDetail.getOalEmdCount());
		}
		if (ctrlValue.equalsIgnoreCase(DOC_TYPE_EMD) && selfOalInd.equalsIgnoreCase(SELF_OAL_B)) {
			return (Integer.valueOf(fileDetail.getOwnEmdCount()) + Integer.valueOf(fileDetail.getOalEmdCount()));
		}

		if (ctrlValue.equalsIgnoreCase(DOC_TYPE_EBT) && selfOalInd.equalsIgnoreCase(SELF_OAL_S)) {
			return Integer.valueOf(fileDetail.getOwnEbtCount());
		}
		if (ctrlValue.equalsIgnoreCase(DOC_TYPE_EBT) && selfOalInd.equalsIgnoreCase(SELF_OAL_O)) {
			return Integer.valueOf(fileDetail.getOalEbtCount());
		}
		if (ctrlValue.equalsIgnoreCase(DOC_TYPE_EBT) && selfOalInd.equalsIgnoreCase(SELF_OAL_B)) {
			return (Integer.valueOf(fileDetail.getOwnEbtCount()) + Integer.valueOf(fileDetail.getOalEbtCount()));
		}

		return null;
	}

	public Integer parseControlFormula(String formula, Map<String, Object> controlMap) {

		ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
		Double result = new Double(0.0);

		if (StringUtils.isNotEmpty(formula) && !controlMap.isEmpty()) {
			try {
				result = (Double) engine.eval(formula, new SimpleBindings(controlMap));
			} catch (ScriptException e) {
				LOGGER.error(e.getMessage());
			}
		}
		return result.intValue();
	}
}