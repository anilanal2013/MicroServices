package com.sgl.smartpra.batch.bhr.app.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.ExceptionTransIntgAppClient;
import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bhr.app.domain.PaxManiFest;
import com.sgl.smartpra.batch.bhr.app.domain.PaxManiFestHeader;
import com.sgl.smartpra.batch.bhr.app.repository.FlightRecoRepository;
import com.sgl.smartpra.batch.bhr.app.service.FlightRecoService;
import com.sgl.smartpra.batch.bhr.app.specification.PaxManiFestEsntitySpecification;
import com.sgl.smartpra.batch.bhr.app.util.FlightRecoCommonUtil;
import com.sgl.smartpra.batch.bhr.app.util.FlightRecoConstants;
import com.sgl.smartpra.batch.bhr.app.util.FlightRecoCountReader;
import com.sgl.smartpra.batch.bhr.app.util.FlownFileValidationExceptionConstants;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.constant.CommonExceptionConstants;
import com.sgl.smartpra.common.constant.Month;
import com.sgl.smartpra.common.model.FileType;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.repository.FlownCouponRepository;

@Service
public class FlightRecoServiceImpl implements FlightRecoService {

	@Autowired
	private FlightRecoRepository flightRecoRepository;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	ExceptionTransIntgAppClient exceptionTransIntgAppClient;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	FlownCouponRepository flownCouponRepository;

	@Value("${batch.directory.flight-reco.duplicate}")
	private String duplicateDir;

	@Value("${batch.directory.flight-reco.failed}")
	private String failedDir;

	@Value("${batch.directory.flight-reco.input}")
	private String inputDir;

	@Value("${batch.directory.flight-reco.processed}")
	private String processedDir;

	SimpleDateFormat dateFormat = new SimpleDateFormat("DDMMM");

	private static final Logger LOGGER = LoggerFactory.getLogger(FlightRecoServiceImpl.class);

	String flightNumberOption = null;
	String hostCarrierNumericCd = null;
	String hosrCarrierAlphaCd = null;
	ExceptionTransactionModel exceptionTransactionModel;
	List<ExceptionParametersValueModel> parametersValueModelList;
	ExceptionParametersValueModel parametersValueModel;
	List<FlownCoupon> flownCouponList;

	private void loadSysParamConfigurations() {
		LOGGER.info("###loadSysParamConfigurations---Start");
		flightNumberOption = FlightRecoCommonUtil.getFlightNumberOption(smartpraMasterAppClient);
		hostCarrierNumericCd = FlightRecoCommonUtil.getHostCarrierNumericCode(smartpraMasterAppClient);
		hosrCarrierAlphaCd = FlightRecoCommonUtil.getHostCarrierDesigCode(smartpraMasterAppClient);
		LOGGER.info("###loadSysParamConfigurations-End");
	}

	@Override
	public String readFile(String fileName, String processedBy) {
		LOGGER.info("readFile(String fileName, String processedBy)-Start");
		File file = new File(fileName);
		String fName = file.getName();
		String message = null;
		String loadingStatusMsg = null;
		loadSysParamConfigurations();
		LOGGER.info("FlightRecoCountReader.resetCounts();-Start");
		FlightRecoCountReader.resetCounts();
		LOGGER.info("FlightRecoCountReader.resetCounts();-End");

		FileLogging fileLogging = FlightRecoCommonUtil.initFileLogging();
		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_INPUT);
		fileLogging.setFileName(fileName);
		fileLogging.setProcessedBy(processedBy);
		fileLogging.setFileType(FlightRecoConstants.FILELOGGING_FILETYPE_FIGHT_RECO_IN);
		fileLogging.setClientId(hosrCarrierAlphaCd);
		FileErrorLog fileErrorLog;
		List<FileErrorLog> fileErrorLogList;

		fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);

		// Validate file
		String valdationMessage = validateFile(inputDir + fileName, fileLogging);

		if (StringUtils.isNotEmpty(valdationMessage)) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			FlightRecoCommonUtil.moveFile(inputDir + fileName, failedDir + fileName + tmpName);
			fileLogging.setModuleId(FlightRecoConstants.MODULE_ID);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setClientId(hosrCarrierAlphaCd);
			fileLogging.setRemarks(valdationMessage);
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Invalid File Input");
			fileErrorLog.setErrorDescription(valdationMessage);
			fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return valdationMessage;
		}

		// File duplicate check
		List<FileLogging> fileList = batchGlobalFeignClient.getFileLogByFileName(fileName);

		if (CollectionUtils.isNotEmpty(fileList)) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			String errorMsg = "File with same name " + fileName + " has been already loaded in system with file id "
					+ fileList.get(0).getFileId();

			Map<String, String> paramsMmap = new HashMap<>();
			paramsMmap.put(CommonExceptionConstants.EXCEPCODE_GEN1101_PARAM_1, fileName);

			prepareExceptionTransactionModel(CommonExceptionConstants.EXCEPCODE_GEN1101, paramsMmap, fileName,
					fileLogging);

			FlightRecoCommonUtil.moveFile(inputDir + fileName, duplicateDir + fileName + tmpName);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setModuleId(FlightRecoConstants.MODULE_ID);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setClientId(hosrCarrierAlphaCd);
			fileLogging.setRemarks(errorMsg);
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Invalid File Input");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}

		if (fName.startsWith("AETK")) {
			LOGGER.info("fName.startsWith(\"AETK\")-Start");
			if (hosrCarrierAlphaCd.equals(FlightRecoConstants.DEFAULT_CLIENT_ID)) {
				LOGGER.info("readFileForAetk(fName, fileLogging)-Start");
				message = readFileForAetkAndMnfst(fName, fileLogging);
				LOGGER.info("readFileForAetk(fName, fileLogging)-End");

				LOGGER.info("fileLodingCompletionMsg(message, fileLogging.getFileId(), fileName)-Start");
				loadingStatusMsg = fileLodingCompletionMsg(message, fileLogging.getFileId(), fileName);
				LOGGER.info("fileLodingCompletionMsg(message, fileLogging.getFileId(), fileName)-End");
			}
			LOGGER.info("fName.startsWith(\"AETK\")-Start");
		} else if (fName.startsWith("MNFST")) {
			if (hosrCarrierAlphaCd.equals(FlightRecoConstants.DEFAULT_CLIENT_ID)) {
				message = readFileForAetkAndMnfst(fName, fileLogging);
				loadingStatusMsg = fileLodingCompletionMsg(message, fileLogging.getFileId(), fileName);
			}

		} else if (fName.startsWith("GPM")) {

		} else if (fName.startsWith("SSCI")) {

		}
		LOGGER.info("readFile(String fileName, String processedBy)-End");
		return loadingStatusMsg;
	}

	private String readFileForAetkAndMnfst(String fileName, FileLogging fileLogging) {
		Stream<String> stream = null;
		List<String> list = null;
		PaxManiFestHeader paxManiFestHeader = null;
		try {
			LOGGER.info("Files.lines(Paths.get(inputDir + fileName))-Start");
			stream = Files.lines(Paths.get(inputDir + fileName));
			LOGGER.info("Files.lines(Paths.get(inputDir + fileName))-End");

			list = stream.skip(1).parallel().map(line -> line).collect(Collectors.toList());

			stream.close();

			paxManiFestHeader = createPaxmanifestHeader(list);

			for (String resultString : list.subList(3, list.size())) {
				FlightRecoCountReader.incTotalCount();
				if (resultString.length() > 65) {
					LOGGER.info("###### if(resultString.length() > 65)-Start");
					FlightRecoCountReader.incTransferCount();
					int size = 64;
					List<String> tokens = new ArrayList<>();
					for (int start = 0; start < resultString.length(); start += size) {
						tokens.add(resultString.substring(start, Math.min(resultString.length(), start + size)));
					}
					for (String resultedString : tokens) {
						if (!SmartPRACommonUtil.isNullOrTrimEmpty(resultedString)) {
							LOGGER.info("###resultedString:" + resultedString);
							createPaxManiFest(paxManiFestHeader, resultedString, fileName, fileLogging);

						}
					}
					LOGGER.info("###### if(resultString.length() > 65)-End");
				} else {
					if (!SmartPRACommonUtil.isNullOrTrimEmpty(resultString)) {
						createPaxManiFest(paxManiFestHeader, resultString, fileName, fileLogging);
						FlightRecoCountReader.incTransferCount();
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "COMPLETED";
	}

	private PaxManiFestHeader createPaxmanifestHeader(List<String> list) {
		LOGGER.info("###createPaxmanifestHeader(List<String> list)-Start");
		PaxManiFestHeader paxManiFestHeader = new PaxManiFestHeader();
		String flightNumber = null;
		String cabinCounts = null;
		Integer firstClassCount = null;
		Integer businessClassCount = null;
		Integer preecoClassCount = null;
		Integer economyClassCount = null;
		String[] cabinCountArray = null;
		java.sql.Date flightDate = null;

		String headerLine1 = list.get(0);
		String headerLine2 = list.get(1);

		String flightNum = headerLine2.substring(2, 6).trim();
		flightNumber = SmartPRACommonUtil.deriveFlightNo(flightNum, flightNumberOption);
		if (flightNumber != null) {
			paxManiFestHeader.setFlightNumber(flightNumber);
		}
		if (flightDate == null) {
			try {
				flightDate = java.sql.Date.valueOf(getFlightDateUsingIssueDate(headerLine2.substring(9, 14)));
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		paxManiFestHeader.setFlightDate(flightDate);
		paxManiFestHeader.setBoardingPoint(headerLine2.substring(16, 19));
		paxManiFestHeader.setBoardingTime(headerLine2.substring(47, 49) + ":" + headerLine2.substring(49, 51));
		paxManiFestHeader.setBoardingGate(headerLine2.substring(57, 62));
		paxManiFestHeader.setStdTime(headerLine2.substring(23, 25) + ":" + headerLine2.substring(25, 27));
		paxManiFestHeader.setTotalCabinCount(Integer.valueOf(headerLine1.substring(61, 64)));
		cabinCounts = headerLine1.substring(35, 56);
		cabinCountArray = cabinCounts.split("\\s+");
		for (String cabinCount : cabinCountArray) {
			if (cabinCount.contains("F")) {
				System.out.println(cabinCount.subSequence(1, cabinCount.length()));
				firstClassCount = Integer.valueOf((String) cabinCount.subSequence(1, cabinCount.length()));

			} else if (cabinCount.contains("J") || cabinCount.contains("C")) {
				businessClassCount = Integer.valueOf((String) cabinCount.subSequence(1, cabinCount.length()));

			} else if (cabinCount.contains("W")) {
				preecoClassCount = Integer.valueOf((String) cabinCount.subSequence(1, cabinCount.length()));

			} else if (cabinCount.contains("Y")) {
				economyClassCount = Integer.valueOf((String) cabinCount.subSequence(1, cabinCount.length()));
			}
		}
		if (firstClassCount != null) {
			paxManiFestHeader.setFirstClassCount(firstClassCount);
		}
		if (businessClassCount != null) {
			paxManiFestHeader.setBusinessClassCount(businessClassCount);
		}
		if (preecoClassCount != null) {
			paxManiFestHeader.setPreecoClassCount(preecoClassCount);
		}
		if (economyClassCount != null) {
			paxManiFestHeader.setEconomyClassCount(economyClassCount);
		}
		LOGGER.info("###createPaxmanifestHeader(List<String> list)-End");

		return paxManiFestHeader;
	}

	private void createPaxManiFest(PaxManiFestHeader paxManiFestHeader, String resultString, String fileName,
			FileLogging fileLogging) {
		LOGGER.info("###createPaxManiFest-Start");
		PaxManiFest paxManiFestEntity = new PaxManiFest();
		String flightNumber = paxManiFestHeader.getFlightNumber();
		String fromAirport = resultString.substring(29, 32);
		String toAirport = resultString.substring(33, 36);
		Date flightDate = paxManiFestHeader.getFlightDate();
		String pnrName = resultString.substring(4, 27).trim();
		LOGGER.info("###flownCouponRepository.getByFlightNoAndFlightDateAndFromAirportAndToAirportAndPnrNm-Start");
		flownCouponList = flownCouponRepository.getByFlightNoAndFlightDateAndFromAirportAndToAirportAndPnrNm(
				flightNumber, flightDate, fromAirport, toAirport, pnrName);
		LOGGER.info("###flownCouponRepository.getByFlightNoAndFlightDateAndFromAirportAndToAirportAndPnrNm-End");
		if (CollectionUtils.isNotEmpty(flownCouponList) && flownCouponList.size() > 0) {
			LOGGER.info("flownCouponList.size()::" + flownCouponList.size());
			for (FlownCoupon flownCoupon : flownCouponList) {
				String passengerName = flownCoupon.getPassengerName();
				if (passengerName.equals(pnrName)) {
					paxManiFestEntity.setFlightRecoStatus("Y");
					paxManiFestEntity.setFlightRecoDate(new Timestamp(new Date().getTime()));
				} else {
					paxManiFestEntity.setFlightRecoStatus("N");
				}
			}
		} else {
			paxManiFestEntity.setFlightRecoStatus("N");
		}

		paxManiFestEntity.setClientId(hosrCarrierAlphaCd);
		paxManiFestEntity.setFlightNumber(paxManiFestHeader.getFlightNumber());
		paxManiFestEntity.setFlightDate(paxManiFestHeader.getFlightDate());
		paxManiFestEntity.setBoardingPoint(paxManiFestHeader.getBoardingPoint());
		paxManiFestEntity.setBoardingGate(paxManiFestHeader.getBoardingGate());
		paxManiFestEntity.setBoardingTime(paxManiFestHeader.getBoardingTime());
		paxManiFestEntity.setStdTime(paxManiFestHeader.getStdTime());
		paxManiFestEntity.setFirstClassCount(paxManiFestHeader.getFirstClassCount());
		paxManiFestEntity.setBusinessClassCount(paxManiFestHeader.getBusinessClassCount());
		paxManiFestEntity.setEconomyClassCount(paxManiFestHeader.getEconomyClassCount());
		paxManiFestEntity.setPreecoClassCount(paxManiFestHeader.getPreecoClassCount());
		paxManiFestEntity.setPassengerName(resultString.substring(4, 27));
		paxManiFestEntity.setPaxGender(resultString.substring(27, 28));
		paxManiFestEntity.setFromCity(resultString.substring(29, 32));
		paxManiFestEntity.setToCity(resultString.substring(33, 36));
		paxManiFestEntity.setTrvldClass(resultString.substring(37, 38));
		paxManiFestEntity.setRbdOperated(resultString.substring(38, 39));
		paxManiFestEntity.setSeatNo(resultString.substring(42, 46));
		if (!SmartPRACommonUtil.isNullOrTrimEmpty(resultString.substring(47, 50))) {
			paxManiFestEntity.setIssueAirlineCode(resultString.substring(47, 50));
		}
		if (!SmartPRACommonUtil.isNullOrTrimEmpty(resultString.substring(50, 60))) {
			paxManiFestEntity.setDocumentNo(resultString.substring(50, 60));
		}

		if (fileName.startsWith("AETK")) {
			paxManiFestEntity.setFileSource(FlightRecoConstants.FILE_SOURCE_AETK);
		} else if (fileName.startsWith("MNFST")) {
			paxManiFestEntity.setFileSource(FlightRecoConstants.FILE_SOURCE_MNFST);
		}
		paxManiFestEntity.setFileId(fileLogging.getFileId().intValue());

		paxManiFestEntity.setCreatedBy("FlightRecoAdmin");
		paxManiFestEntity.setCreatedDate(new Timestamp(new Date().getTime()));
		try {
			flightRecoRepository.save(paxManiFestEntity);
		} catch (Exception e) {
			FlightRecoCountReader.incErrorCount();
		}
		LOGGER.info("###createPaxManiFest-End");

	}

	private LocalDate getFlightDateUsingIssueDate(String date) throws ParseException {
		int month = Month.valueOf(date.substring(2, 5).toUpperCase()).getMonthValue();

		LocalDate flightDate = null;
		Integer fDate=Integer.parseInt(date.substring(0, 2));
		String mth=date.substring(2, 5);
		
		if (fDate == 31 && mth.equals("DEC")) {
			flightDate = LocalDate.of(LocalDate.now().getYear() - 1, month, Integer.parseInt(date.substring(0, 2)));
			return flightDate;
		} else {
			flightDate = LocalDate.of(LocalDate.now().getYear(), month, Integer.parseInt(date.substring(0, 2)));
		}

		return flightDate;
	}

	private String validateFile(String fileName, FileLogging fileLogging) {
		LOGGER.info(" Validate File : " + fileName);
		String errorMessage = null;
		File file = new File(fileName);
		String fileNm = file.getName();
		if (!SmartpraFileUtility.fileExists(fileName)) {

			LOGGER.info("!SmartpraFileUtility.fileExists(fileName)");

			Map<String, String> paramsMmap = new HashMap<>();
			paramsMmap.put(FlownFileValidationExceptionConstants.LIFT1000_PARAM_1, fileNm);

			prepareExceptionTransactionModel(FlownFileValidationExceptionConstants.FILE_NOT_FOUND_LIFT1000, paramsMmap,
					fileNm, fileLogging);

			return errorMessage = "File " + fileNm + " not found";
		}

		if (SmartpraFileUtility.isEmptyFile(fileName)) {

			LOGGER.info("SmartpraFileUtility.isEmptyFile(fileName)");

			Map<String, String> paramsMmap = new HashMap<>();
			paramsMmap.put(FlownFileValidationExceptionConstants.LIFT1002_PARAM_1, fileNm);

			prepareExceptionTransactionModel(FlownFileValidationExceptionConstants.FILE_NO_RECORD_FOUND_LIFT1002,
					paramsMmap, fileNm, fileLogging);

			return errorMessage = fileNm + " has no record i.e. Blank file reported";
		}

		if (!isValidFileName(fileName)) {
			LOGGER.info("!isValidFileName(fileName)");

			Map<String, String> paramsMmap = new HashMap<>();
			paramsMmap.put(FlownFileValidationExceptionConstants.LIFT1001_PARAM_1, fileNm);

			prepareExceptionTransactionModel(FlownFileValidationExceptionConstants.FILE_NAME_NOT_SPECIFICATION_LIFT1001,
					paramsMmap, fileNm, fileLogging);

			return errorMessage = "File name " + fileNm + " is not as per specification";
		}
		if (!validateRecords(fileName)) {
			LOGGER.info("!validateRecords(fileName, version)");

			Map<String, String> paramsMmap = new HashMap<>();
			paramsMmap.put(FlownFileValidationExceptionConstants.LIFT1003_PARAM_1, fileNm);

			prepareExceptionTransactionModel(
					FlownFileValidationExceptionConstants.FILE_INCORRECT_DATA_REPORTED_LIFT1003, paramsMmap, fileNm,
					fileLogging);
			return errorMessage = "File name " + fileNm + "  is incorrect data reported";
		}
		return errorMessage;
	}

	private boolean isValidFileName(String fileName) {
		boolean isValid = false;
		File file = new File(fileName);
		String fName = file.getName();
		String fileExt = fName.substring(fName.lastIndexOf('.') + 1, fName.length());
		if (fName.startsWith("AETK")) {
			isValid = true;
		}
		if (fName.startsWith("MNFST")) {
			isValid = true;
		}

		if (!FileType.contains(fileExt)) {
			isValid = false;
		}
		return isValid;
	}

	private boolean validateRecords(String fileName) {
		boolean isValid = true;
		File file = new File(fileName);
		String fNmae = file.getName();
		BufferedReader bufferedReader;
		String readLine = "";
		String record = null;
		try {
			bufferedReader = new BufferedReader(new FileReader(file));
			while ((readLine = bufferedReader.readLine()) != null) {
				record = readLine;
				if (fNmae.startsWith("AETK")) {
					if (record.length() > 577) {
						isValid = false;
					}
				}
				if (fNmae.startsWith("MNFST")) {
					if (record.length() > 572) {
						isValid = false;
					}
				}
			}
			if (bufferedReader != null) {
				bufferedReader.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return isValid;
	}

	private String fileLodingCompletionMsg(String message, BigInteger fileId, String fileName) {
		Integer totalCount = FlightRecoCountReader.getTotalCount();
		Integer errorCount = FlightRecoCountReader.getErrorCount();
		Integer transferCount = FlightRecoCountReader.getTransferCount();
		String fName = null;
		String returnMessage = null;

		FileLogging fileLogging = batchGlobalFeignClient.getFileLogByFileId(fileId);
		fName = StringUtils.isNotEmpty(fileName) ? fileName : fileLogging.getFileName();
		if (message.equals("COMPLETED")) {
			fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
			fileLogging.setTotalCounts(totalCount);
			fileLogging.setHeaderCounts(0);
			fileLogging.setDetailCounts(totalCount);
			fileLogging.setTransferredCounts(transferCount);
			fileLogging.setErrorCounts(errorCount);
			fileLogging.setFileSize(
					StringUtils.isEmpty(fileLogging.getFileSize()) ? FlightRecoCommonUtil.getFileSize(inputDir + fName)
							: fileLogging.getFileSize());
			if (transferCount != null && totalCount != null && transferCount.equals(totalCount)) {
				fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
			} else if (transferCount != null && transferCount > 0 && totalCount != null
					&& !transferCount.equals(totalCount)) {
				fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_PARTTRANSFERRED);
			} else if (errorCount != null && errorCount.equals(totalCount)) {
				fileLogging.setTotalCounts(totalCount);
				fileLogging.setDetailCounts(totalCount);
				fileLogging.setTransferredCounts(0);
				fileLogging.setErrorCounts(totalCount);
				fileLogging.setFileSize(StringUtils.isEmpty(fileLogging.getFileSize())
						? FlightRecoCommonUtil.getFileSize(inputDir + fileName)
						: fileLogging.getFileSize());
				fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
				fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK);
				FileErrorLog fileErrorLog = new FileErrorLog();
				fileErrorLog.setFileId(fileLogging.getFileId());
				ArrayList<FileErrorLog> fileErrorLogList = new ArrayList<>();
				fileErrorLogList.add(fileErrorLog);
				fileLogging.setFileErrorLog(fileErrorLogList);
				String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
				FlightRecoCommonUtil.moveFile(inputDir + fName, failedDir + fName + tmpName);

				fileLogging.setIsMovedToRelevantFolder("Y");
				LOGGER.info("!!! JOB FINISHED -FAILED ! Time to verify the results");
				returnMessage = "File Loading -FAILED ! Time to verify the results";
			}
			if (SmartpraFileUtility.fileExists(inputDir + fName)) {
				FlightRecoCommonUtil.moveFile(inputDir + fName, processedDir + fName);
				LOGGER.info("!!! JOB FINISHED! Time to verify the results");
				returnMessage = "File Loading Completed ! Time to verify the results";
			}
			fileLogging.setIsMovedToRelevantFolder("Y");
		} else {
			fileLogging.setTotalCounts(totalCount);
			fileLogging.setDetailCounts(0);
			fileLogging.setTransferredCounts(0);
			fileLogging.setErrorCounts(totalCount);
			fileLogging.setFileSize(
					StringUtils.isEmpty(fileLogging.getFileSize()) ? FlightRecoCommonUtil.getFileSize(inputDir + fName)
							: fileLogging.getFileSize());
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
			fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK);
			FileErrorLog fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			ArrayList<FileErrorLog> fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			FlightRecoCommonUtil.moveFile(inputDir + fName, failedDir + fName + tmpName);

			fileLogging.setIsMovedToRelevantFolder("Y");
			LOGGER.info("!!! JOB FINISHED -FAILED ! Time to verify the results");
			returnMessage = "File Loading -FAILED ! Time to verify the results";
		}
		fileLogging = batchGlobalFeignClient.updateFileLog(fileId, fileLogging);

		return returnMessage;
	}

	private void prepareExceptionTransactionModel(String excepCode, Map<String, String> paramsMap, String fileName,
			FileLogging fileLogging) {
		LOGGER.info("prepareExceptionTransactionModel()-Start");
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setExceptionCode(excepCode);
		exceptionTransactionModel.setFileId(fileLogging.getFileId().longValue());
		exceptionTransactionModel.setIssuedCarrier(hostCarrierNumericCd);
		exceptionTransactionModel.setClientId(hosrCarrierAlphaCd);
		exceptionTransactionModel.setOrderId(String.valueOf(2));
		exceptionTransactionModel.setCreatedBy(FlightRecoConstants.CREATEDBY);
		exceptionTransactionModel.setEnvironment(FlightRecoConstants.EXCEPTION_ENVIRONEMENT_P);
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());

		if (paramsMap != null) {
			List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
			ExceptionParametersValueModel parametersValueModel;
			for (String name : paramsMap.keySet()) {
				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName(name);
				parametersValueModel.setParameterValue(paramsMap.get(name));
				parametersValueModelList.add(parametersValueModel);
			}
			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
		}
		exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
		LOGGER.info("prepareExceptionTransactionModel()-End");
	}

	@Override
	public List<PaxManiFest> getPassengerDetails(String flightNumber, Date flightDate, String fromCity, String toCity,
			String flightRecoStatus) {
		return flightRecoRepository.findAll(
				PaxManiFestEsntitySpecification.serach(flightNumber, flightDate, fromCity, toCity, flightRecoStatus));
	}
}
