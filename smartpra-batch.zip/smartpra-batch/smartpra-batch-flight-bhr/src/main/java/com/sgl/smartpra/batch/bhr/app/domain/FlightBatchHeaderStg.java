package com.sgl.smartpra.batch.bhr.app.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.bhr.app.layout.BatchHeaderInFileLayout_V_1_0;
import com.sgl.smartpra.batch.bhr.app.layout.BatchHeaderInFileLayout_V_1_1;
import com.sgl.smartpra.batch.bhr.app.layout.BatchHeaderInFileLayout_V_1_2;
import com.sgl.smartpra.batch.bhr.app.processor.BatchHeaderFileProcessor;
import com.sgl.smartpra.batch.bhr.app.util.BHRCommonUtil;
import com.sgl.smartpra.batch.bhr.app.writer.BHRProdWriter;
import com.sgl.smartpra.batch.bhr.app.writer.BatchHeaderFileWriter;

@Entity
@Table(name="flight_batch_header_stg")
public class FlightBatchHeaderStg extends BatchRecord implements Serializable {

	private static final long serialVersionUID = 3916175578602471154L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="batch_hdr_id")
	private BigInteger batchHdrId;
	
	@Column(name = "file_id")
	private Integer fileId;
	
	@Column(name = "client_id")
	private String clientId;
	
	@Column(name="flight_number")
	private String flightNumber;
	
	@Column(name="from_airport")
	private String fromAirport;
	
	@Column(name="to_airport")
	private String toAirport;
	
	@Column(name="flight_date")
	private String flightDate;
	
	@Column(name="aircraft_registration")
	private String aircraftRegistration;
	
	@Column(name="f_cabin_control")
	private String firstClassCabinControl;
	
	@Column(name="c_cabin_control")
	private String businessCabinControl;
	
	@Column(name="y_cabin_control")
	private String economyCabinControl;
	
	@Column(name="w_cabin_control")
	private String premiumEconomyCabinControl;
	
	@Column(name="total_infant")
	private String totalInfant;
	
	@Column(name="e_ticket_count")
	private String eTicketCount;
	
	
	@Column(name="own_mco_count")
	private String ownMcoCount;
	
	@Column(name="own_ebt_count")
	private String ownEbtCount;
	
	@Column(name="own_emd_count")
	private String ownEmdCount;
	
	@Column(name="oal_pax_count")
	private String oalPaxCount;
	
	@Column(name="oal_mco_count")
	private String oalMcoCount;
	
	@Column(name="oal_ebt_count")
	private String oalEbtCount;
	
	
	@Column(name="oal_emd_count")
	private String oalEmdCount;
	
	@Column(name="pay_load")
	private String payload;
		
	@Column(name="dead_load")
	private String deadload;
	
	@Column(name="first_class_capacity")
	private String firstClassCapacity;
	
	@Column(name="business_class_capacity")
	private String businessClassCapacity;
	
	@Column(name="economy_class_capacity")
	private String economyClassCapacity;
	
	@Column(name="premium_eco_clss_capacity")
	private String premiumEcoClassCapacity;
	
	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;
	
	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;
	
	@Transient
	private String premiumEconomyCabinControlTemp;

	@Transient
	private String filler;
	
	
	public BigInteger getBatchHdrId() {
		return batchHdrId;
	}

	public void setBatchHdrId(BigInteger batchHdrId) {
		this.batchHdrId = batchHdrId;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFromAirport() {
		return fromAirport;
	}

	public void setFromAirport(String fromAirport) {
		this.fromAirport = fromAirport;
	}

	public String getToAirport() {
		return toAirport;
	}

	public void setToAirport(String toAirport) {
		this.toAirport = toAirport;
	}

	public String getFlightDate() {
		return flightDate;
	}

	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	public String getAircraftRegistration() {
		return aircraftRegistration;
	}

	public void setAircraftRegistration(String aircraftRegistration) {
		this.aircraftRegistration = aircraftRegistration;
	}

	public String getFirstClassCabinControl() {
		return firstClassCabinControl;
	}

	public void setFirstClassCabinControl(String firstClassCabinControl) {
		this.firstClassCabinControl = firstClassCabinControl;
	}

	public String getBusinessCabinControl() {
		return businessCabinControl;
	}

	public void setBusinessCabinControl(String businessCabinControl) {
		this.businessCabinControl = businessCabinControl;
	}

	public String getEconomyCabinControl() {
		return economyCabinControl;
	}

	public void setEconomyCabinControl(String economyCabinControl) {
		this.economyCabinControl = economyCabinControl;
	}

	public String getPremiumEconomyCabinControl() {
		return premiumEconomyCabinControl;
	}

	public void setPremiumEconomyCabinControl(String premiumEconomyCabinControl) {
		
		if (StringUtils.isNotEmpty(premiumEconomyCabinControl) && premiumEconomyCabinControl.length()>=3) {
			this.premiumEconomyCabinControl = premiumEconomyCabinControl.substring(1,4);
		}else {
			this.premiumEconomyCabinControl = "000";
		}
	}
	
		
	public String getPremiumEconomyCabinControlTemp() {
		return premiumEconomyCabinControlTemp;
	}

	public void setPremiumEconomyCabinControlTemp(String premiumEconomyCabinControlTemp) {
			if(StringUtils.isNotEmpty(premiumEconomyCabinControlTemp) && premiumEconomyCabinControlTemp.equals("0"))
				premiumEconomyCabinControlTemp=null;
			
			this.setPremiumEconomyCabinControl(premiumEconomyCabinControlTemp);
			this.setFirstClassCapacity(premiumEconomyCabinControlTemp);
			this.setBusinessClassCapacity(premiumEconomyCabinControlTemp);
			this.setEconomyClassCapacity(premiumEconomyCabinControlTemp);
			this.setPremiumEcoClassCapacity(premiumEconomyCabinControlTemp);
			this.premiumEconomyCabinControlTemp = premiumEconomyCabinControlTemp;
	}

	public String getTotalInfant() {
		return totalInfant;
	}

	public void setTotalInfant(String totalInfant) {
		this.totalInfant = totalInfant;
	}

	public String geteTicketCount() {
		return eTicketCount;
	}

	public void seteTicketCount(String eTicketCount) {
		this.eTicketCount = eTicketCount;
	}

	public String getOwnMcoCount() {
		return ownMcoCount;
	}

	public void setOwnMcoCount(String ownMcoCount) {
		this.ownMcoCount = ownMcoCount;
	}

	public String getOwnEbtCount() {
		return ownEbtCount;
	}

	public void setOwnEbtCount(String ownEbtCount) {
		this.ownEbtCount = ownEbtCount;
	}

	public String getOwnEmdCount() {
		return ownEmdCount;
	}

	public void setOwnEmdCount(String ownEmdCount) {
		this.ownEmdCount = ownEmdCount;
	}

	
	public String getOalPaxCount() {
		return oalPaxCount;
	}

	public void setOalPaxCount(String oalPaxCount) {
		this.oalPaxCount = oalPaxCount;
	}

	public String getOalMcoCount() {
		return oalMcoCount;
	}

	public void setOalMcoCount(String oalMcoCount) {
		this.oalMcoCount = oalMcoCount;
	}

	public String getOalEbtCount() {
		return oalEbtCount;
	}

	public void setOalEbtCount(String oalEbtCount) {
		this.oalEbtCount = oalEbtCount;
	}

	public String getOalEmdCount() {
		return oalEmdCount;
	}

	public void setOalEmdCount(String oalEmdCount) {
		this.oalEmdCount = oalEmdCount;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getDeadload() {
		return deadload;
	}

	public void setDeadload(String deadload) {
		if(StringUtils.isNotEmpty(deadload) && deadload.length()<16) {
			this.deadload = BHRCommonUtil.padString(deadload, "0", 16);
		}else {
			this.deadload = deadload;
		}
		
	}

	public String getFirstClassCapacity() {
		return firstClassCapacity;
	}

	public void setFirstClassCapacity(String firstClassCapacity) {
		if(StringUtils.isNotEmpty(firstClassCapacity)  && firstClassCapacity.length() >= 7) {
			this.firstClassCapacity = firstClassCapacity.substring(4,7);
		}else {
			this.firstClassCapacity = firstClassCapacity;
		}
		
	}

	public String getBusinessClassCapacity() {
		return businessClassCapacity;
	}

	public void setBusinessClassCapacity(String businessClassCapacity) {
		if (StringUtils.isNotEmpty(businessClassCapacity) && businessClassCapacity.length() >= 10) {
			this.businessClassCapacity = businessClassCapacity.substring(7, 10);
		} else {
			this.businessClassCapacity = businessClassCapacity;
		}
	}

	public String getEconomyClassCapacity() {
		return economyClassCapacity;
	}

	public void setEconomyClassCapacity(String economyClassCapacity) {
		if (StringUtils.isNotEmpty(economyClassCapacity) && economyClassCapacity.length() >= 13) {
			this.economyClassCapacity = economyClassCapacity.substring(10, 13);
		} else {
			this.economyClassCapacity = economyClassCapacity;
		}
	}

	public String getPremiumEcoClassCapacity() {
		return premiumEcoClassCapacity;
	}

	public void setPremiumEcoClassCapacity(String premiumEcoClassCapacity) {
		if (StringUtils.isNotEmpty(premiumEcoClassCapacity) && premiumEcoClassCapacity.length() > 13
				&& premiumEcoClassCapacity.length() <= 16) {
			this.premiumEcoClassCapacity = premiumEcoClassCapacity.substring(13, 16);
		} else {
			this.premiumEcoClassCapacity = premiumEcoClassCapacity;
		}

	}
	
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	@Override
	public Integer getFileId() {
		return fileId;
	}

	@Override
	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	@Override
	public String getCreatedBy() {
		return createdBy;
	}

	@Override
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	@Override
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	@Override
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Override
	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	@Override
	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	@Override
	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	public LineTokenizer lineTokenizer_V_1_0() {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		BatchHeaderInFileLayout_V_1_0 bhrFileLayout_V_1_0 = new BatchHeaderInFileLayout_V_1_0();
		tokenizer.setColumns(bhrFileLayout_V_1_0.getColumns());
		tokenizer.setNames(bhrFileLayout_V_1_0.getNames());
		return tokenizer;
	}
	
	public LineTokenizer lineTokenizer_V_1_1() {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		BatchHeaderInFileLayout_V_1_1 bhrFileLayout_V_1_1 = new BatchHeaderInFileLayout_V_1_1();
		tokenizer.setColumns(bhrFileLayout_V_1_1.getColumns());
		tokenizer.setNames(bhrFileLayout_V_1_1.getNames());
		return tokenizer;
	}
	
	public LineTokenizer lineTokenizer_V_1_2() {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		BatchHeaderInFileLayout_V_1_2 bhrFileLayout_V_1_2 = new BatchHeaderInFileLayout_V_1_2();
		tokenizer.setColumns(bhrFileLayout_V_1_2.getColumns());
		tokenizer.setNames(bhrFileLayout_V_1_2.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BatchRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BatchRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(FlightBatchHeaderStg.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BatchRecord, ? extends BatchRecord> processor() {
		return new BatchHeaderFileProcessor();
	}

	@Override
	public ItemWriter<? super BatchRecord> writer() {
		return new BatchHeaderFileWriter();
	}
	
	public ItemWriter<? super BatchRecord> prodWriter() {
		return new BHRProdWriter();
	}
}
