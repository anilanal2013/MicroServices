package com.sgl.smartpra.batch.bhr.app.util;

public class BHRConstants {

	public static final String FILELOGGING_FILETYPE_BHR_IN = "BHR-IN";
	public static final String FILELOGGING_MODULE = "Flown";
	public static final String MODULE_ID = "FL";

	public static final String DEFAULT_CLIENT_ID = "QR";

	public static final String CREATEDBY = "BHR_BATCH";
	public static final String UPDATEDBY = "BHR_BATCH";

	public static final String PROD_JOB_NAME = "importBHRProdData";

	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";
	public static final String PARAM_DEFAULT_CARRIER_NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";
	public static final String FLIGHT_NUMBER_OPTION = "FLIGHT_NUMBER_OPTION";

	public static final String BHR = "BHR";
	public static final String BHR_DATA_SOURCE_STATUS = "BH";

	public static final String FLIGHT_STATUS_OPEN = "O";
	public static final String FLIGHT_STATUS_OUTSTANDING = "Z";

	public static final String SERVICE_TYPE_SCHEDULE = "S";
	public static final String FLIGHT_TYPE_DEFAULT = "A";
	public static final String ESTIMATION_FLAG_DEFAULT = "N";
	public static final String BALANCE_FLAG_DEFAULT = "N";
	public static final Integer FLIGHT_INDICATOR = 0;

	public static final String SSIM_IND_N = "N";
	public static final String SSIM_IND_Y = "Y";

	public static final String CONTROL_VALUE = "V";
	public static final String CONTROL_CAL = "C";

	public static final String PAX_TYPE = "PAX TYPE";
	public static final String PAX_TYPE_I = "I";
	public static final String PAX_TYPE_C = "C";
	public static final String PAX_TYPE_A = "A";

	public static final String DOC_TYPE = "Doc Type";
	public static final String DOC_TYPE_PAX = "PAX";
	public static final String DOC_TYPE_EBT = "EBT";
	public static final String DOC_TYPE_MCO = "MCO";
	public static final String DOC_TYPE_EMD = "EMD";

	public static final String NON_REVENUE_IND = "NonRev Ind";
	public static final String NON_REVENUE_IND_N = "N";
	public static final String NON_REVENUE_IND_Y = "Y";

	public static final String CABIN = "Cabin";
	public static final String CABIN_F = "F";
	public static final String CABIN_C = "C";
	public static final String CABIN_W = "W";
	public static final String CABIN_Y = "Y";

	public static final String SELF_OAL_S = "S";
	public static final String SELF_OAL_O = "O";
	public static final String SELF_OAL_B = "B";

	public static final String BHR_FILE_INCORRECT_AIRPORTCODE_LIFT1006 = "LIFT1006";
	public static final String LIFT1006_PARAM_1 = "File Name";
	public static final String LIFT1006_PARAM_2 = "Airport Code";

	public static final String BHR_FILE_INCORRECT_AIRCRAFT_REGISTRATION_LIFT1007 = "LIFT1007";
	public static final String LIFT1007_PARAM_1 = "Aircraft registration";
	public static final String LIFT1007_PARAM_2 = "File Name";

	public static final String BHR_FILE_ERROR_IN_CREATING_FLIFGHT_LIFT1008 = "LIFT1008";
	public static final String LIFT1008_PARAM_1 = "Flight Number";
	public static final String LIFT1008_PARAM_2 = "From sector";
	public static final String LIFT1008_PARAM_3 = "To sector";
	public static final String LIFT1008_PARAM_4 = "Depart date";

	public static final String BHR_FILE_ERROR_IN_POPULATE_FLOIGHT_CONTROL_LIFT1009 = "LIFT1009";
	public static final String LIFT1009_PARAM_1 = "Flight Number";
	public static final String LIFT1009_PARAM_2 = "From sector";
	public static final String LIFT1009_PARAM_3 = "To sector";
	public static final String LIFT1009_PARAM_4 = "Depart date";

	public static final String BHR_FILE_ERROR_IN_UPDATING_FLIFGHT_DATA_DEATILS_LIFT1010 = "LIFT1010";
	public static final String LIFT1010_PARAM_1 = "Flight Number";
	public static final String LIFT1010_PARAM_2 = "From sector";
	public static final String LIFT1010_PARAM_3 = "To sector";
	public static final String LIFT1010_PARAM_4 = "Depart date";

	public static final String BHR_FILE_FLIGHT_ALREADY_CREATED_LIFT1011 = "LIFT1011";
	public static final String LIFT1011_PARAM_1 = "Flight Number";
	public static final String LIFT1011_PARAM_2 = "From sector";
	public static final String LIFT1011_PARAM_3 = "To sector";
	public static final String LIFT1011_PARAM_4 = "Depart date";

	public static final String BHR_EXCEP_CREATEDBY = "BHRAdmin";
	public static final String BHR_LAST_UPDATEDBY = "BHRAdmin";
	public static final String BHR_EXCEP_ENVIRONMENT_S = "S";
	public static final String BHR_EXCEP_ENVIRONMENT_P = "P";

}
