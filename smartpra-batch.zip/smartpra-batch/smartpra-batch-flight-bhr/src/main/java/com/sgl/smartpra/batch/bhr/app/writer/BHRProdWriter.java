package com.sgl.smartpra.batch.bhr.app.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bhr.app.domain.BatchRecord;
import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;

@Component
public class BHRProdWriter<T extends BatchRecord> implements ItemWriter<FlightBatchHeaderStg> {

	@Override
	public void write(List<? extends FlightBatchHeaderStg> flightBatchHeaderStg) throws Exception {

		//flightBatchHeaderRepository.saveAll(flightBatchHeaderStg);

	}

}
