package com.sgl.smartpra.batch.bhr.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class BatchHeaderInFileLayout_V_1_2 extends FixedLengthRecordLayout {
	public BatchHeaderInFileLayout_V_1_2() {
		fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightNumber", 1, 4));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fromAirport", 5, 7));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("toAirport", 8, 10));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightDate", 11, 16));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("aircraftRegistration", 17, 24));

		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("firstClassCabinControl", 25, 27));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("businessCabinControl", 28, 30));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("economyCabinControl", 31, 33));

		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalInfant", 34, 36));

	}

}
