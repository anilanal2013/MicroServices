package com.sgl.smartpra.batch.bhr.app.util;

public class FlightRecoConstants {
	
	public static final String FILELOGGING_FILETYPE_FIGHT_RECO_IN = "FLIGHT-RECO-IN";
	public static final String FILELOGGING_MODULE = "Flown";
	public static final String MODULE_ID = "FL";
	
	public static final String DEFAULT_CLIENT_ID = "QR";
	
	public static final String FILE_SOURCE= "FLIGHT_RECON";
	
	public static final String CREATEDBY = "FLIGHT_RECO";
	public static final String UPDATEDBY = "FLIGHT_RECO";
	
	public static final String EXCEPTION_ENVIRONEMENT_P = "P";
	
	public static final String FILE_SOURCE_AETK = "AETK";
	public static final String FILE_SOURCE_MNFST = "MNFST";
	
	
	
	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";
	public static final String PARAM_DEFAULT_CARRIER_NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";	
	public static final String PARAM_FLIGHT_NUMBER_OPTION ="FLIGHT_NUMBER_OPTION";
	
	public static final String FLIGHT_RECO_FILE_NOT_FOUND="LIFT1000";
	public static final String FLIGHT_RECO_FILE_NAME_NOT_SPECIFICATION="LIFT1001";
	public static final String FLIGHT_RECO_FILE_NO_RECORD_FOUND="LIFT1002";
	public static final String FLIGHT_RECO_FILE_INCORRECT_DATA_REPORTED="LIFT1003";
	public static final String FLIGHT_RECO_FILE_IS_ALREADY_LOADED="LIFT1004";
}
