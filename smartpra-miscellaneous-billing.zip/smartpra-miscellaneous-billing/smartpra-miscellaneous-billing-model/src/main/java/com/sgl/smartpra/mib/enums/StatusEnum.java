package com.sgl.smartpra.mib.enums;

public enum StatusEnum {
	
	OPEN("OP"), EVALUATED("EV"), CONFIRMED("CF");

	private String statusValue;

	public String getStatusEnumValue() {
		return statusValue;
	}

	private StatusEnum(String statusValue) {
		this.statusValue = statusValue;
	}

}
