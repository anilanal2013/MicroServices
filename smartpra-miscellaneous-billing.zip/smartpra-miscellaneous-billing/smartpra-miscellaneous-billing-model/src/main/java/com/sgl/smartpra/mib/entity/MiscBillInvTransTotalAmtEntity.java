package com.sgl.smartpra.mib.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

import lombok.Data;


/**
 * The persistent class for the misc_bill_inv_trans_total_amt database table.
 * 
 */
@Data
@Entity
@Table(name="misc_bill_inv_trans_amount")
public class MiscBillInvTransTotalAmtEntity extends BaseEntity<String> implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="trans_summary_dtl_id")
	private Integer transSummaryDtlId;

	@Column(name="amount_type")
	private String amountType;
	
	@Column(name="currency_code")
	private String currencyCode;

	@Column(name="total_amount")
	private BigDecimal totalAmount;

	//bi-directional many-to-one association to MiscBillingInvTransHeader
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="trans_hdr_id")
	private MiscBillingInvTransHeaderEntity miscBillingInvTransHeader;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MiscBillInvTransTotalAmtEntity other = (MiscBillInvTransTotalAmtEntity) obj;
		if (transSummaryDtlId == null) {
			if (other.transSummaryDtlId != null)
				return false;
		} else if (!transSummaryDtlId.equals(other.transSummaryDtlId))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((transSummaryDtlId == null) ? 0 : transSummaryDtlId.hashCode());
		return result;
	}
}