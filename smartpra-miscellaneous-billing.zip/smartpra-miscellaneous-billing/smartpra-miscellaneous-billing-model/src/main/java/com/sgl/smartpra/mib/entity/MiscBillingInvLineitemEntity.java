package com.sgl.smartpra.mib.entity;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;


/**
 * The persistent class for the misc_billing_inv_lineitem database table.
 * 
 */
@Data
@Entity
@Table(name="misc_billing_inv_lineitem")
public class MiscBillingInvLineitemEntity extends BaseEntity<String> implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="inv_line_item_id", unique=true, nullable=false)
	private Integer invLineItemId;

	@Column(name="line_item_number", nullable=false)
	private Integer lineItemNumber;

	@Column(name="po_line_item_number", nullable=false)
	private Integer poLineItemNumber;

	@Column(name="charge_code", nullable=false, length=6)
	private String chargeCode;

	@Column(name="charge_cat_code", nullable=false, length=3)
	private String chargeCatCode;

	@Column(length=50)
	private String description;

	@Column(name="rejection_reason_code", length=2)
	private String rejectionReasonCode;

	@Column(name="rejected_value", precision=18, scale=3)
	private BigDecimal rejectedValue;

	@Column(name="product_id", length=25)
	private String productId;

	@Column(name="start_date")
	private Date startDate;

	@Column(name="end_date")
	private Date endDate;
	
	@Column(name="location_code", length=5)
	private String locationCode;

	@Column(name="quantity", precision=18, scale=4)
	private BigDecimal quantity;
	
	@Column(name="uom_code", length=3)
	private String uomCode;

	@Column(name="unit_price", precision=18, scale=3)
	private BigDecimal unitPrice;
	
	@Column(name="scalling_factor", length=2)
	private String scallingFactor;
	
	@Column(name="charge_amount", precision=18, scale=3)
	private BigDecimal chargeAmount;

	@Column(name="tax_amount", precision=16, scale=3)
	private BigDecimal taxAmount;

	@Column(name="vat_amount", precision=16, scale=3)
	private BigDecimal vatAmount;
	
	@Column(name="addon_charge_amount", precision=16, scale=3)
	private BigDecimal addonChargeAmount;

	@Column(name="total_addon_charge_amount", precision=16, scale=3)
	private BigDecimal totalAddonChargeAmount;

	@Column(name="total_tax_amount", precision=16, scale=3)
	private BigDecimal totalTaxAmount;

	@Column(name="total_vat_amount", precision=16, scale=3)
	private BigDecimal totalVatAmount;

	@Column(name="total_net_amount", precision=16, scale=3)
	private BigDecimal totalNetAmount;

	@Column(name="original_line_item_number")
	private Integer originalLineItemNumber;

	@Column(name="detail_count")
	private Integer detailCount;
	
	@Column(name="charge_amount_accepted" , precision=16, scale=3)
	private BigDecimal chargeAmountAccepted;

	@Column(name="total_tax_amount_accepted" , precision=16, scale=3)
	private BigDecimal totalTaxAmountAccepted;
	
	@Column(name="total_vat_amount_accepted" , precision=16, scale=3)
	private BigDecimal totalVatAmountAccepted;
	
	@Column(name="tot_addon_charge_amt_accepted" , precision=16, scale=3)
	private BigDecimal totAddonChargeAmtAccepted;
	
	@Column(name="net_amount_accepted", precision=16, scale=3)
	private BigDecimal netAmountAccepted;
	
	@Column(name="charge_amount_rejected", precision=16, scale=3)
	private BigDecimal chargeAmountRejected;
	
	@Column(name="total_tax_amount_rejected", precision=16, scale=3)
	private BigDecimal totalTaxAmountRejected;
	
	@Column(name="total_vat_amount_rejected", precision=16, scale=3)
	private BigDecimal totalVatAmountRejected;
	
	@Column(name="tot_addon_charge_amt_rejected", precision=16, scale=3)
	private BigDecimal totAddonChargeAmtRejected;
	
	@Column(name="net_amount_rejected", precision=16, scale=3)
	private BigDecimal netAmountRejected;
	
	@Column(name="process_status", length = 2)
	private String processStatus;
	
	@Column(name="charge_code_type" , length= 50)
	private String chargeCodeType;
	
	@Column(name="minimum_quantity_flag" , length= 1)
	private String minimumQuantityFlag;
	
	//bi-directional many-to-one association to MiscBillingTrnInvoice
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="invoice_urn")
	private MiscBillingTrnInvoiceEntity miscBillingTrnInvoice;
	
	//bi-directional many-to-one association to MiscBillingLineitemDetail
	@OneToMany(mappedBy="miscBillingInvLineitem", cascade = CascadeType.ALL)
	private List<MiscBillingInvLineitemDtlEntity> miscBillingLineitemDetails;

	//bi-directional many-to-one association to miscBillingTaxDetail
	@OneToMany(mappedBy="miscBillingInvLineitem", cascade = CascadeType.ALL)
	private List<MiscBillingTaxDetailsEntity> miscBillingTaxDetails;

	//bi-directional many-to-one association to miscBillingTaxDetail
	@OneToMany(mappedBy="miscBillingInvLineitem", cascade = CascadeType.ALL)
	private List<MiscBillingAddOnChargeDtlEntity> miscBillingAddOnChargeDtl;
		
	public MiscBillingInvLineitemDtlEntity addMiscBillingInvLineitemDtl(MiscBillingInvLineitemDtlEntity miscBillingLineitemDetails) {
		getMiscBillingLineitemDetails().add(miscBillingLineitemDetails);
		miscBillingLineitemDetails.setMiscBillingInvLineitem(this);
		return miscBillingLineitemDetails;
	}

	public MiscBillingInvLineitemDtlEntity removeMiscBillingInvLineitemDtl(MiscBillingInvLineitemDtlEntity miscBillingLineitemDetails) {
		getMiscBillingLineitemDetails().remove(miscBillingLineitemDetails);
		miscBillingLineitemDetails.setMiscBillingInvLineitem(null);
		return miscBillingLineitemDetails;
	}
	
	public MiscBillingTaxDetailsEntity addMiscBillingTaxDetails(MiscBillingTaxDetailsEntity miscBillingTaxDetails) {
		getMiscBillingTaxDetails().add(miscBillingTaxDetails);
		miscBillingTaxDetails.setMiscBillingInvLineitem(this);
		return miscBillingTaxDetails;
	}

	public MiscBillingTaxDetailsEntity removeMiscBillingTaxDetails(MiscBillingTaxDetailsEntity miscBillingTaxDetails) {
		getMiscBillingTaxDetails().remove(miscBillingTaxDetails);
		miscBillingTaxDetails.setMiscBillingInvLineitem(null);
		return miscBillingTaxDetails;
	}

	public MiscBillingAddOnChargeDtlEntity addMiscBillingAddOnChargeDtl(MiscBillingAddOnChargeDtlEntity miscBillingAddOnChargeDtl) {
		getMiscBillingAddOnChargeDtl().add(miscBillingAddOnChargeDtl);
		miscBillingAddOnChargeDtl.setMiscBillingInvLineitem(this);
		return miscBillingAddOnChargeDtl;
	}

	public MiscBillingAddOnChargeDtlEntity removeMiscBillingAddOnChargeDtl(MiscBillingAddOnChargeDtlEntity miscBillingAddOnChargeDtl) {
		getMiscBillingAddOnChargeDtl().remove(miscBillingAddOnChargeDtl);
		miscBillingAddOnChargeDtl.setMiscBillingInvLineitem(null);
		return miscBillingAddOnChargeDtl;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((invLineItemId == null) ? 0 : invLineItemId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MiscBillingInvLineitemEntity other = (MiscBillingInvLineitemEntity) obj;
		if (invLineItemId == null) {
			if (other.invLineItemId != null)
				return false;
		} else if (!invLineItemId.equals(other.invLineItemId))
			return false;
		return true;
	}	
}