package com.sgl.smartpra.mib.domain;

import com.sgl.smartpra.common.model.BaseMaster;
import lombok.Data;

@Data
public class MiscBillingSupportingDetail extends BaseMaster {

    private Integer supportDtlId;

    private Integer miscSectionDtlId;

    private String sectionName;

    private String jsonValue;
}
