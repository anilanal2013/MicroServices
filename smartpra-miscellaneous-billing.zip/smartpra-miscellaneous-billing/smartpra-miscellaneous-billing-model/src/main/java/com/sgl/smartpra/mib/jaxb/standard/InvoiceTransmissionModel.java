package com.sgl.smartpra.mib.jaxb.standard;

import java.util.List;

import com.sgl.smartpra.mib.entity.MiscBillInvTransTotalAmtEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

public class InvoiceTransmissionModel {

	private MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity;
	private List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmtEntityList;
	private List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntityListList;
	
	/**
	 * @return the miscBillingInvTransHeaderEntity
	 */
	public MiscBillingInvTransHeaderEntity getMiscBillingInvTransHeaderEntity() {
		return miscBillingInvTransHeaderEntity;
	}
	/**
	 * @param miscBillingInvTransHeaderEntity the miscBillingInvTransHeaderEntity to set
	 */
	public void setMiscBillingInvTransHeaderEntity(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity) {
		this.miscBillingInvTransHeaderEntity = miscBillingInvTransHeaderEntity;
	}
	/**
	 * @return the miscBillInvTransTotalAmtEntityList
	 */
	public List<MiscBillInvTransTotalAmtEntity> getMiscBillInvTransTotalAmtEntityList() {
		return miscBillInvTransTotalAmtEntityList;
	}
	/**
	 * @param miscBillInvTransTotalAmtEntityList the miscBillInvTransTotalAmtEntityList to set
	 */
	public void setMiscBillInvTransTotalAmtEntityList(
			List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmtEntityList) {
		this.miscBillInvTransTotalAmtEntityList = miscBillInvTransTotalAmtEntityList;
	}
	/**
	 * @return the miscBillingTrnInvoiceEntityListList
	 */
	public List<MiscBillingTrnInvoiceEntity> getMiscBillingTrnInvoiceEntityListList() {
		return miscBillingTrnInvoiceEntityListList;
	}
	/**
	 * @param miscBillingTrnInvoiceEntityListList the miscBillingTrnInvoiceEntityListList to set
	 */
	public void setMiscBillingTrnInvoiceEntityListList(
			List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntityListList) {
		this.miscBillingTrnInvoiceEntityListList = miscBillingTrnInvoiceEntityListList;
	}
}

