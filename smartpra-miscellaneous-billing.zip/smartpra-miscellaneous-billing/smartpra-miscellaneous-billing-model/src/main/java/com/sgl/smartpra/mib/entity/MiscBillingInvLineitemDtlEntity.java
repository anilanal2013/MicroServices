package com.sgl.smartpra.mib.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;


/**
 * The persistent class for the misc_billing_lineitem_detail database table.
 * 
 */
@Data
@Entity
@Table(name="misc_billing_lineitem_detail")
public class MiscBillingInvLineitemDtlEntity extends BaseEntity<String> implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="inv_line_itemdetail_id")
	private Integer invLineitemDetailId;

	@Column(name="line_item_detail_number")
	private Integer lineItemDetailNumber;

	@Column(name="description")
	private String description;

	@Column(name="product_id")
	private String productId;

	@Column(name="start_date")
	private Date startDate;

	@Column(name="end_date")
	private Date endDate;
	
	@Column(name="minimum_quantity_flag")
	private String minQtyFlag;

	@Column(name="uom_code")
	private String uomCode;
	
	@Column(name="quantity")
	private BigDecimal quantity;

	@Column(name="unit_price")
	private BigDecimal unitPrice;
	
	@Column(name="scalling_factor")
	private String scallingFactor;
	
	@Column(name="tax_amount")
	private BigDecimal taxAmt;
	
	@Column(name="vat_amount")
	private BigDecimal vatAmt;
	
	@Column(name="total_net_amount")
	private BigDecimal totalNetAmt;
	
	@Column(name="charge_amount")
	private BigDecimal chargeAmt;
	
	@Column(name="addon_charge_amount")
	private BigDecimal addOnChargeAmt;
	
	@Transient
	private BigInteger lineItemNumber;
	
	//bi-directional many-to-one association to MiscBillingInvLineitem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="inv_line_item_id")
	private MiscBillingInvLineitemEntity miscBillingInvLineitem;
	
	//bi-directional many-to-one association to MiscBillingLineitemDetail
	@OneToMany(mappedBy="miscBillingInvLineitemDtl", cascade = CascadeType.ALL)
	private List<MiscBillingSupportingDetailEntity> miscBillingSupportingDetail;
	
	//bi-directional many-to-one association to miscBillingTaxDetails
	@OneToMany(mappedBy="miscBillingInvLineitemDtl", cascade = CascadeType.ALL)
	private List<MiscBillingTaxDetailsEntity> miscBillingTaxDetails;
	
	//bi-directional many-to-one association to miscBillingTaxDetails
	@OneToMany(mappedBy="miscBillingInvLineitemDtl", cascade = CascadeType.ALL)
	private List<MiscBillingAddOnChargeDtlEntity> miscBillingAddOnChargeDtl;	

	public MiscBillingTaxDetailsEntity addMiscBillingTaxDetail(MiscBillingTaxDetailsEntity miscBillingTaxDetail) {
		getMiscBillingTaxDetails().add(miscBillingTaxDetail);
		miscBillingTaxDetail.setMiscBillingInvLineitemDtl(this);
		return miscBillingTaxDetail;
	}

	public MiscBillingTaxDetailsEntity removeMiscBillingTaxDetail(MiscBillingTaxDetailsEntity miscBillingTaxDetail) {
		getMiscBillingTaxDetails().remove(miscBillingTaxDetail);
		miscBillingTaxDetail.setMiscBillingInvLineitemDtl(null);
		return miscBillingTaxDetail;
	}
	
	public MiscBillingSupportingDetailEntity addMiscBillingSupportingDetail(MiscBillingSupportingDetailEntity miscBillingSupportingDetail) {
		getMiscBillingSupportingDetail().add(miscBillingSupportingDetail);
		miscBillingSupportingDetail.setMiscBillingInvLineitemDtl(this);
		return miscBillingSupportingDetail;
	}

	public MiscBillingSupportingDetailEntity removeMiscBillingSupportingDetail(MiscBillingSupportingDetailEntity miscBillingSupportingDetail) {
		getMiscBillingSupportingDetail().remove(miscBillingSupportingDetail);
		miscBillingSupportingDetail.setMiscBillingInvLineitemDtl(null);
		return miscBillingSupportingDetail;
	}
	
	public MiscBillingAddOnChargeDtlEntity addMiscBillingAddOnChargeDtl(MiscBillingAddOnChargeDtlEntity miscBillingAddOnChargeDtl) {
		getMiscBillingAddOnChargeDtl().add(miscBillingAddOnChargeDtl);
		miscBillingAddOnChargeDtl.setMiscBillingInvLineitemDtl(this);
		return miscBillingAddOnChargeDtl;
	}

	public MiscBillingAddOnChargeDtlEntity removeMiscBillingAddOnChargeDtl(MiscBillingAddOnChargeDtlEntity miscBillingAddOnChargeDtl) {
		getMiscBillingAddOnChargeDtl().remove(miscBillingAddOnChargeDtl);
		miscBillingAddOnChargeDtl.setMiscBillingInvLineitemDtl(null);
		return miscBillingAddOnChargeDtl;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MiscBillingInvLineitemDtlEntity other = (MiscBillingInvLineitemDtlEntity) obj;
		if (invLineitemDetailId == null) {
			if (other.invLineitemDetailId != null)
				return false;
		} else if (!invLineitemDetailId.equals(other.invLineitemDetailId))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((invLineitemDetailId == null) ? 0 : invLineitemDetailId.hashCode());
		return result;
	}
}