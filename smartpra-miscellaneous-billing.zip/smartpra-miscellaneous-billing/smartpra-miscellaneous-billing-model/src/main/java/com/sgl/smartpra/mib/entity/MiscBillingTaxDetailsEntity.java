package com.sgl.smartpra.mib.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

 /**
 * The persistent class for the misc_billing_addon_charge_dtl database table.
 * 
 */
@Data
@Entity
@Table(name="misc_billing_tax_details")
public class MiscBillingTaxDetailsEntity  extends BaseEntity<String> implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="misc_billing_tax_dtl_id", unique=true, nullable=false)
	private Integer miscBillingTaxDtlId;
	
	@Column(name="record_seq_number")
	private Integer recordSeqNumber;

	@Column(name="tax_type")
	private String taxType;

	@Column(name="tax_sub_type")
	private String taxSubType;

	@Column(name="tax_category")
	private String taxCategory;

	@Column(name="tax_text")
	private String taxText;

	@Column(name="tax_percentage")
	private BigDecimal taxPercentage;

	@Column(name="taxable_amount")
	private BigDecimal taxableAmount;
	
	@Column(name="tax_amount")
	private BigDecimal taxAmount;
	
	@Column(name="tax_level")
	private String taxLevel;
	
	@Column(name="tax_amount_accepted", precision=16, scale=3)
	private BigDecimal taxAmountAccepted;
	
	@Column(name="tax_amount_rejected", precision=16, scale=3)
	private BigDecimal taxAmountRejected;

	//bi-directional many-to-one association to MiscBillingTrnInvoice
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="invoice_urn")
	private MiscBillingTrnInvoiceEntity miscBillingTrnInvoice;

	//bi-directional many-to-one association to miscBillingInvLineitem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="inv_line_item_id")
	private MiscBillingInvLineitemEntity miscBillingInvLineitem;
	
	//bi-directional many-to-one association to miscBillingInvLineitemDtl
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="inv_line_itemdetail_id")
	private MiscBillingInvLineitemDtlEntity miscBillingInvLineitemDtl;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MiscBillingTaxDetailsEntity other = (MiscBillingTaxDetailsEntity) obj;
		if (miscBillingTaxDtlId == null) {
			if (other.miscBillingTaxDtlId != null)
				return false;
		} else if (!miscBillingTaxDtlId.equals(other.miscBillingTaxDtlId))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((miscBillingTaxDtlId == null) ? 0 : miscBillingTaxDtlId.hashCode());
		return result;
	}
}
