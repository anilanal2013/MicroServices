package com.sgl.smartpra.mib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;

@Repository
public interface MiscBillingInvTransHeaderDataRepository extends JpaRepository<MiscBillingInvTransHeaderEntity, Integer> {

	@Modifying
	@Query(value = "update MiscBillingInvTransHeaderEntity set fileId = :fileId where transHdrId = :transHdrId ")
	public void updateFileIdInInvTransHeader(@Param("fileId") Integer fileId, @Param("transHdrId") Integer transHdrId);
	
}
