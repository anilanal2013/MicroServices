package com.sgl.smartpra.mib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.Nullable;

import com.sgl.smartpra.common.model.BaseMaster;
import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;

/**
 * @author kanprasa
 *
 */
@Data

public class MiscBillingInvSupportingDoc extends BaseModel implements Serializable {

	/**
	 *  Serial Version Id
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer invSuppDocId;
	
	private String clientId;
	
	private String documentUniqueNo;
	
	private String billingType;
	
	private String billingMonth;
	
	private Integer billingPeriod;
	
	private String billingCarrier;

	private String billedCarrier;
	
	private String transactionType;
	
	private String invoiceNo;
	
	private String batchKey;
	
	private Integer batchSeq;
	
	private Integer recordSeq;
	
	private Integer breakdownSeqNo;
	
	private String carrierCode;
	
	private String documentNo;
	
	private Integer couponNo;
	
	private String memoNo;
	
	private String fimNo;
	
	private Integer attachmentSeq;
	
	private String attachmentType;
	
	private String fileName;
	
	private String filePath;
	
	private String transactionRefNo;
	
	private String fileId;

	
}
