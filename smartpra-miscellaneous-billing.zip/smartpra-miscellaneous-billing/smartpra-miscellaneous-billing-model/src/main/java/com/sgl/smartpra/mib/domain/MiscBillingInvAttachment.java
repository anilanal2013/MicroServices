package com.sgl.smartpra.mib.domain;

import com.sgl.smartpra.common.model.BaseMaster;
import lombok.Data;

import java.util.Date;

@Data
public class MiscBillingInvAttachment extends BaseMaster {

    private Integer invAttachmentId;

    private String clientId;

    private String fileName;

    private Integer fileSize;

    private Date fileDate;

    private String filePath;

    private String fileImageStatus;

//    private Integer miscBillingTrnInvoice;
}
