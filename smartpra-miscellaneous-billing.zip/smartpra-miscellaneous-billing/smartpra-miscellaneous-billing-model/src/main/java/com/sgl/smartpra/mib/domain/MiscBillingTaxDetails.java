package com.sgl.smartpra.mib.domain;

import com.sgl.smartpra.common.model.BaseMaster;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class MiscBillingTaxDetails extends BaseMaster {

    private Integer miscBillingTaxDtlId;

    private Integer recordSeqNumber;

    private String taxType;
    
    private String invoiceUrn;

    private String taxSubType;

    private String taxCategory;

    private String taxText;

    private BigDecimal taxPercentage;

    private BigDecimal taxableAmount;

    private BigDecimal taxAmount;

    private String taxLevel;

    private BigDecimal taxAmountAccepted;
    
    private BigDecimal taxAmountRejected;
    
//    private String miscBillingTrnInvoice;

//    private Integer miscBillingInvLineitem;

//    private Integer miscBillingInvLineitemDtl;

}
