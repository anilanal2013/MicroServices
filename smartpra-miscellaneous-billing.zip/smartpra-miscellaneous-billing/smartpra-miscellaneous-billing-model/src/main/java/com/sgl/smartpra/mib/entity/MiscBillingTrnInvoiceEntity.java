package com.sgl.smartpra.mib.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

/**
 * The persistent class for the misc_billing_trn_invoice database table.
 * 
 */
@Data
@Entity
@Table(name="misc_billing_trn_invoice")
public class MiscBillingTrnInvoiceEntity extends BaseEntity<String> implements Serializable  {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="invoice_urn", unique=true, nullable=false, length=30)
	private String invoiceUrn;
	
	@Column(name="client_id", nullable=false, length=2)
	private String clientId;

	@Column(name="invoice_number", nullable=false, length=30)
	private String invoiceNumber;

	@Column(name="jv_reference_number", length=30)
	private String jvReferenceNumber;
	
	@Column(name="invoice_date")
	private Date invoiceDate;

	@Column(name="invoice_type", length=1)
	private String invoiceType;

	@Column(name="tax_invoice_number", length=25)
	private String taxInvoiceNumber;

	@Column(name="tax_point_date")
	private Date taxPointDate;

	@Column(name="location_code", nullable=false, length=3)
	private String locationCode;

	@Column(name="charge_category_code", nullable=false, length=25)
	private String chargeCategoryCode;
	
	@Column(name="seller_organization_id", length=3)
	private String sellerOrganizationId;

	@Column(name="seller_location_id", length=3)
	private String sellerLocationId;
	
	@Column(name="buyer_organization_id", length=3)
	private String buyerOrganizationId;

	@Column(name="buyer_location_id", length=3)
	private String buyerLocationId;

	@Column(name="currency_code", length=3)
	private String currencyCode;

	@Column(name="clearance_currency_code", length=3)
	private String clearanceCurrencyCode;

	@Column(name="exchange_rate", precision=16, scale=3)
	private BigDecimal exchangeRate;

	@Column(name="bkr_exchange_rate", precision=16, scale=3)
	private BigDecimal bkrExchangeRate;

	@Column(name="accounting_month")
	private Integer accountingMonth;

	@Column(name="accounting_date")
	private Date accountingDate;

	@Column(name="settlement_month_period", length=6)
	private String settlementMonthPeriod;

	@Column(name="settlement_method", length=1)
	private String settlementMethod;

	@Column(name="digital_signature_flag", length=1)
	private String digitalSignatureFlag;

	@Column(name="suspended_flag", length=1)
	private String suspendedFlag;

	@Column(name="is_validation_flag", length=10)
	private String isValidationFlag;
	
	@Column(name="rejection_flag", length=1)
	private String rejectionFlag;

	@Column(name="rejection_stage")
	private Integer rejectionStage;

	@Column(name="original_invoice_number", length=10)
	private String originalInvoiceNumber;

	@Column(name="original_billing_period")
	private Integer originalBillingPeriod;

	@Column(name="orginal_billing_month")
	private String orginalBillingMonth;

	@Column(name="correspondance_flag", length=1)
	private String correspondanceFlag;

	@Column(name="authority_to_bill_flag", length=1)
	private String authorityToBillFlag;
	
	@Column(name="correspondance_ref_no")
	private Integer correspondanceRefNo;

	@Column(name="dispute_ref_number", length=20)
	private String disputeRefNumber;

	@Column(name="po_number", length=35)
	private String poNumber;

	@Column(name="invoice_template_language", length=2)
	private String invoiceTemplateLanguage;

	@Column(length=100)
	private String description;

	@Column(name="no_of_attachments")
	private Integer noOfAttachments;

	@Column(name="line_item_count")
	private Integer lineItemCount;

	@Column(name="total_line_item_amount", precision=16, scale=3)
	private BigDecimal totalLineItemAmount;
	
	@Column(name="tax_amount", precision=16, scale=3)
	private BigDecimal taxAmount;

	@Column(name="vat_amount", precision=16, scale=3)
	private BigDecimal vatAmount;

	@Column(name="addon_charge_amount", precision=16, scale=3)
	private BigDecimal addonChargeAmount;

	@Column(name="total_addon_charge_amount", precision=16, scale=3)
	private BigDecimal totalAddonChargeAmount;

	@Column(name="total_tax_amount", precision=16, scale=3)
	private BigDecimal totalTaxAmount;

	@Column(name="total_vat_amount", precision=16, scale=3)
	private BigDecimal totalVatAmount;

	@Column(name="total_amount", precision=16, scale=3)
	private BigDecimal totalAmount;

	@Column(name="total_clearance_currency_amt", precision=16, scale=3)
	private BigDecimal totalClearanceCurrencyAmt;

	@Column(name="base_currency", nullable=true, length=3)
	private String baseCurrency;

	@Column(name="amount_base_currency", precision=16, scale=3)
	private BigDecimal amountBaseCurrency;

	@Column(name="inward_outward_flag", nullable=false, length=1)
	private String inwardOutwardFlag;

	@Column(name="invoice_status", nullable=false, length=2)
	private String invoiceStatus;
	
	@Column(name="rej_invoice_no", length=10)
	private String rejInvoiceNo;

	@Column(name= "billing_month" , length = 6)
	private String billingMonth;

	@Column(name ="billing_period" )
	private Integer billingPeriod;

	@Column(name = "supplier_type")
	private String supplierType;
	
	//Added for invoice evaluation
	@Column(name = "charge_amount_accepted",precision=16, scale=3)
	private BigDecimal chargeAmountAccepted;
	
	@Column(name = "total_tax_amount_accepted",precision=16, scale=3)
	private BigDecimal totalTaxAmountAccepted;
	
	@Column(name = "total_vat_amount_accepted",precision=16, scale=3)
	private BigDecimal totalVatAmountAccepted;
	
	@Column(name = "tot_addon_charge_amt_accepted",precision=16, scale=3)
	private BigDecimal totalAddonChargeAmountAccepted;
	
	@Column(name = "net_amount_accepted",precision=16, scale=3)
	private BigDecimal netAmountAccepted;
	
	@Column(name = "charge_amount_rejected",precision=16, scale=3)
	private BigDecimal chargeAmountRejected;
	
	@Column(name = "total_tax_amount_rejected",precision=16, scale=3)
	private BigDecimal totalTaxAmountRejected;
	
	@Column(name = "total_vat_amount_rejected",precision=16, scale=3)
	private BigDecimal totalVatAmountRejected;
	
	@Column(name = "tot_addon_charge_amt_rejected",precision=16, scale=3)
	private BigDecimal totalAddonChargeAmountRejected;
	
	@Column(name = "net_amount_rejected",precision=16, scale=3)
	private BigDecimal netAmountRejected;
	
	@Column(name = "supplier_name")
	private String supplierName;

	
	//bi-directional many-to-one association to misc_billing_inv_attachment
	@OneToMany(mappedBy="miscBillingTrnInvoice", cascade = CascadeType.ALL)
	private List<MiscBillingInvLineitemEntity> miscBillingInvLineitem;
	
	//bi-directional many-to-one association to miscBillingTaxDetail
	@OneToMany(mappedBy="miscBillingTrnInvoice", cascade = CascadeType.ALL)
	private List<MiscBillingTaxDetailsEntity> miscBillingTaxDetails;

	//bi-directional many-to-one association to miscBillingTaxDetail
	@OneToMany(mappedBy="miscBillingTrnInvoice", cascade = CascadeType.ALL)
	private List<MiscBillingAddOnChargeDtlEntity> miscBillingAddOnChargeDtl;

	//bi-directional many-to-one association to miscBillingTaxDetail
	@OneToMany(mappedBy="miscBillingTrnInvoice", cascade = CascadeType.ALL)
	private List<MiscBillingInvAttachmentEntity> miscBillingInvAttachment;

	//bi-directional many-to-one association to MiscBillingInvTransHeader
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="trans_hdr_id", nullable=false)
	private MiscBillingInvTransHeaderEntity miscBillingInvTransHeader;

	public MiscBillingInvLineitemEntity addMiscBillingInvLineitem(MiscBillingInvLineitemEntity miscBillingInvLineitem) {
		getMiscBillingInvLineitem().add(miscBillingInvLineitem);
		miscBillingInvLineitem.setMiscBillingTrnInvoice(this);
		return miscBillingInvLineitem;
	}

	public MiscBillingInvLineitemEntity removeMiscBillingInvLineitem(MiscBillingInvLineitemEntity miscBillingInvLineitem) {
		getMiscBillingInvLineitem().remove(miscBillingInvLineitem);
		miscBillingInvLineitem.setMiscBillingTrnInvoice(null);
		return miscBillingInvLineitem;
	}

	public MiscBillingTaxDetailsEntity addMiscBillingTaxDetails(MiscBillingTaxDetailsEntity miscBillingTaxDetails) {
		getMiscBillingTaxDetails().add(miscBillingTaxDetails);
		miscBillingTaxDetails.setMiscBillingTrnInvoice(this);
		return miscBillingTaxDetails;
	}

	public MiscBillingTaxDetailsEntity removeMiscBillingTaxDetails(MiscBillingTaxDetailsEntity miscBillingTaxDetails) {
		getMiscBillingTaxDetails().remove(miscBillingTaxDetails);
		miscBillingTaxDetails.setMiscBillingTrnInvoice(null);
		return miscBillingTaxDetails;
	}

	public MiscBillingAddOnChargeDtlEntity addMiscBillingAddOnChargeDtl(MiscBillingAddOnChargeDtlEntity miscBillingAddOnChargeDtl) {
		getMiscBillingAddOnChargeDtl().add(miscBillingAddOnChargeDtl);
		miscBillingAddOnChargeDtl.setMiscBillingTrnInvoice(this);
		return miscBillingAddOnChargeDtl;
	}

	public MiscBillingAddOnChargeDtlEntity removeMiscBillingAddOnChargeDtl(MiscBillingAddOnChargeDtlEntity miscBillingAddOnChargeDtl) {
		getMiscBillingAddOnChargeDtl().remove(miscBillingAddOnChargeDtl);
		miscBillingAddOnChargeDtl.setMiscBillingTrnInvoice(null);
		return miscBillingAddOnChargeDtl;
	}

	public MiscBillingInvAttachmentEntity addMiscBillingInvAttachment(MiscBillingInvAttachmentEntity miscBillingInvAttachment) {
		getMiscBillingInvAttachment().add(miscBillingInvAttachment);
		miscBillingInvAttachment.setMiscBillingTrnInvoice(this);
		return miscBillingInvAttachment;
	}

	public MiscBillingInvAttachmentEntity removeMiscBillingInvAttachment(MiscBillingInvAttachmentEntity miscBillingInvAttachment) {
		getMiscBillingInvAttachment().remove(miscBillingInvAttachment);
		miscBillingInvAttachment.setMiscBillingTrnInvoice(null);
		return miscBillingInvAttachment;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MiscBillingTrnInvoiceEntity other = (MiscBillingTrnInvoiceEntity) obj;
		if (invoiceUrn == null) {
			if (other.invoiceUrn != null)
				return false;
		} else if (!invoiceUrn.equals(other.invoiceUrn))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((invoiceUrn == null) ? 0 : invoiceUrn.hashCode());
		return result;
	}
}