package com.sgl.smartpra.mib.domain;

import java.math.BigDecimal;

import com.sgl.smartpra.common.model.BaseMaster;

import lombok.Data;

@Data
public class MiscBillingAddOnChargeDtl extends BaseMaster {

    
	private static final long serialVersionUID = 1L;

	private Integer miscBillingAddOnChargeDtlId;

    private Integer recordSeqNumber;

    private String addOnChargeName;
    
    private String invoiceUrn;

    private BigDecimal addOnChargePercentage;

    private BigDecimal addOnChargeableAmount;

    private BigDecimal addOnChargeAmount;

    private String addOnLevel;

    private Integer invoiceId;
    
    private BigDecimal addonChargeAccepted;
    
    private BigDecimal addonChargeRejected;
}
