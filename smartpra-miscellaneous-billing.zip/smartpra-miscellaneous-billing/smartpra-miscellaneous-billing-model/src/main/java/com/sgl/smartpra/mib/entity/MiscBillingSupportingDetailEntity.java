package com.sgl.smartpra.mib.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;


/**
 * The persistent class for the misc_billing_supporting_detail database table.
 * 
 */
@Data
@Entity
@Table(name="misc_billing_supporting_detail")
public class MiscBillingSupportingDetailEntity extends BaseEntity<String> implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="inv_itemdetail_dtl_id")
	private Integer supportDtlId;

	@Column(name="misc_section_dtl_id")
	private Integer miscSectionDtlId;

	@Column(name="section_name")
	private String sectionName;

	@Column(name="json_value")
	private String jsonValue;

	//bi-directional many-to-one association to MiscBillingTrnInvoice
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="inv_line_itemdetail_id")
	private MiscBillingInvLineitemDtlEntity miscBillingInvLineitemDtl;
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MiscBillingSupportingDetailEntity other = (MiscBillingSupportingDetailEntity) obj;
		if (supportDtlId == null) {
			if (other.supportDtlId != null)
				return false;
		} else if (!supportDtlId.equals(other.supportDtlId))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((supportDtlId == null) ? 0 : supportDtlId.hashCode());
		return result;
	}
}