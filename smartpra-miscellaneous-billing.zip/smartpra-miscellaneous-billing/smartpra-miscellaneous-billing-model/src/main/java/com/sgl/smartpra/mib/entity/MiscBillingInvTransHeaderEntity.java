package com.sgl.smartpra.mib.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;


/**
 * The persistent class for the misc_billing_inv_trans_header database table.
 * 
 */
@Data
@Entity
@Table(name="misc_billing_inv_trans_header")
public class MiscBillingInvTransHeaderEntity extends BaseEntity<String> implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="trans_hdr_id", unique=true, nullable=false)
	private Integer transHdrId;
	
	@Column(name="client_id", nullable=false, length=2)
	private String clientId;

	@Column(name="billing_month", nullable=false, length=6)
	private String billingMonth;

	@Column(name="billing_period", nullable=false)
	private Integer billingPeriod;

	@Column(name="transmission_date_time", nullable=false, length=30)
	private String transmissionDateTime;

	@Column(name="trans_version", length=50)
	private String transVersion;

	@Column(name="transmission_id", length=50)
	private String transmissionId;

	@Column(name="issuing_organization_id", length=25)
	private String issuingOrganizationId;

	@Column(name="receiving_organization_id", length=25)
	private String receivingOrganizationId;

	@Column(name="invoice_count")
	private Integer invoiceCount;

	@Column(name="attachment_count")
	private Integer attachmentCount;

	@Column(name="billing_category", length=25)
	private String billingCategory;
	
	@Column(name="inward_outward_flag", nullable=false, length=1)
	private String inwardOutwardFlag;

	@Column(name="file_id")
	private Integer fileId;

	//bi-directional many-to-one association to MiscBillingTrnInvoiceEntity
	@OneToMany(mappedBy="miscBillingInvTransHeader", cascade = CascadeType.ALL)
	private List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoices;
	
	//bi-directional many-to-one association to MiscBillingTrnInvoiceEntity
	@OneToMany(mappedBy="miscBillingInvTransHeader", cascade = CascadeType.ALL)
	private List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmt;

	public MiscBillInvTransTotalAmtEntity addMiscBillInvTransTotalAmt(MiscBillInvTransTotalAmtEntity miscBillInvTransTotalAmt) {
		getMiscBillInvTransTotalAmt().add(miscBillInvTransTotalAmt);
		miscBillInvTransTotalAmt.setMiscBillingInvTransHeader(this);
		return miscBillInvTransTotalAmt;
	}

	public MiscBillInvTransTotalAmtEntity removeMiscBillInvTransTotalAmt(MiscBillInvTransTotalAmtEntity miscBillInvTransTotalAmt) {
		getMiscBillInvTransTotalAmt().remove(miscBillInvTransTotalAmt);
		miscBillInvTransTotalAmt.setMiscBillingInvTransHeader(null);
		return miscBillInvTransTotalAmt;
	}
	
	public MiscBillingTrnInvoiceEntity addMiscBillingTrnInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoice) {
		getMiscBillingTrnInvoices().add(miscBillingTrnInvoice);
		miscBillingTrnInvoice.setMiscBillingInvTransHeader(this);
		return miscBillingTrnInvoice;
	}

	public MiscBillingTrnInvoiceEntity removeMiscBillingTrnInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoice) {
		getMiscBillingTrnInvoices().remove(miscBillingTrnInvoice);
		miscBillingTrnInvoice.setMiscBillingInvTransHeader(null);
		return miscBillingTrnInvoice;
	}
}