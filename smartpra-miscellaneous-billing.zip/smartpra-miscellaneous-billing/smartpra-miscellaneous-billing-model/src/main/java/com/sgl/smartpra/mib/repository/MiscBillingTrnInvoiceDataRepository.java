package com.sgl.smartpra.mib.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

@Repository
public interface MiscBillingTrnInvoiceDataRepository extends JpaRepository<MiscBillingTrnInvoiceEntity, String>{
	
	@Query(value = "Select e from MiscBillingTrnInvoiceEntity e where e.miscBillingInvTransHeader.transHdrId = " +
			":transHdrId")
	public List<MiscBillingTrnInvoiceEntity> findAllByMiscBillingInvTransHeader(@Param("transHdrId") Integer transHdrId);
	
	@Query(value = "select e from MiscBillingTrnInvoiceEntity e where e.billingMonth = :billingMonth and e.billingPeriod = :billingPeriod "
			+ " and e.inwardOutwardFlag = 'O' and e.invoiceStatus in ('CO', 'SA') and e.clientId = :clientId "
			+ " and (e.invoiceNumber is null or e.invoiceNumber = '')")
	public List<MiscBillingTrnInvoiceEntity> findAllByBillingMonthAndPeriodAndStatus(@Param("billingMonth") String billingMonth, 
			@Param("billingPeriod") Integer billingPeriod, @Param("clientId") String clientId);

	@Query(value = "select max(invoiceUrn) from MiscBillingTrnInvoiceEntity where invoiceUrn like :batchNo% and clientId = :clientId ")
	public String getMaxBatchNo(@Param("clientId") String clientId, @Param("batchNo") String batchNo);
	
	@Query(value = "select max(invoiceNumber) from MiscBillingTrnInvoiceEntity where invoiceNumber like :invoiceNo% and clientId = :clientId ") 
	public String getMaxInvoiceNo(@Param("clientId") String clientId, @Param("invoiceNo") String invoiceNo);

	@Query(value = "select invoiceUrn from MiscBillingTrnInvoiceEntity where invoiceNumber = :invoiceNo and clientId = :clientId ")
	public String getInvoiceUrn(@Param("clientId") String clientId, @Param("invoiceNo") String invoiceNo);
	
	@Query(value = "select invoiceNumber from MiscBillingTrnInvoiceEntity where invoiceUrn = :invoiceUrn and clientId = :clientId ")
	public String getInvoiceNo(@Param("invoiceUrn") String invoiceUrn, @Param("clientId") String clientId);
}
