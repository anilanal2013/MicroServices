package com.sgl.smartpra.mib.domain;


import com.sgl.smartpra.common.model.BaseMaster;
import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

@Data
@SuppressWarnings("unused")
public class MiscBillingInvLineitemDtl extends BaseMaster {

	/**
	 *  Serial Version Id
	 */
	private static final long serialVersionUID = 1L;

	private Integer invLineitemDetailId;

	private Integer lineItemDetailNumber;

	private String description;

	private String productId;

	private Date startDate;

	private Date endDate;

	private String minQtyFlag;

	private String uomCode;

	private BigDecimal quantity;

	private BigDecimal unitPrice;

	private String scallingFactor;

	private BigDecimal taxAmt;

	private BigDecimal vatAmt;

	private BigDecimal totalNetAmt;

	private BigDecimal chargeAmt;

	private BigDecimal addOnChargeAmt;

	private BigInteger lineItemNumber;

//	private Integer miscBillingInvLineitem;

	private List<MiscBillingSupportingDetail> miscBillingSupportingDetail;

	private List<MiscBillingTaxDetails> miscBillingTaxDetails;

	private List<MiscBillingAddOnChargeDtl> miscBillingAddOnChargeDtl;

}
