package com.sgl.smartpra.mib.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="misc_billing_inv_attachment")
public class MiscBillingInvAttachmentEntity extends BaseEntity<String> implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="inv_attachment_id")
	private Integer invAttachmentId;

	@Column(name="client_id")
	private String clientId;
	
	@Column(name="file_name")
	private String fileName;

	@Column(name="file_size")
	private Integer fileSize;

	@Column(name="file_date")
	private Date fileDate;

	@Column(name="file_path")
	private String filePath;
	
	@Column(name="file_image_status")
	private String fileImageStatus;

	//bi-directional many-to-one association to MiscBillingTrnInvoice
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="invoice_urn")
	private MiscBillingTrnInvoiceEntity miscBillingTrnInvoice;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MiscBillingInvAttachmentEntity other = (MiscBillingInvAttachmentEntity) obj;
		if (invAttachmentId == null) {
			if (other.invAttachmentId != null)
				return false;
		} else if (!invAttachmentId.equals(other.invAttachmentId))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((invAttachmentId == null) ? 0 : invAttachmentId.hashCode());
		return result;
	}
}	