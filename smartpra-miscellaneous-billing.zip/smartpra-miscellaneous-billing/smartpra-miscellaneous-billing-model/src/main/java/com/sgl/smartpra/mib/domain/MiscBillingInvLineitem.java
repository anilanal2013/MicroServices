package com.sgl.smartpra.mib.domain;


import com.sgl.smartpra.common.model.BaseMaster;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@SuppressWarnings("unused")
@Data
public class MiscBillingInvLineitem extends BaseMaster {

	/**
	 *  Serial Version Id
	 */
	private static final long serialVersionUID = 1L;


//	private String miscBillingTrnInvoice;

	private Integer invLineItemId;

	private Integer lineItemNumber;

	private Integer poLineItemNumber;

	private String chargeCode;
	
	private String invoiceUrn;

	private String chargeCatCode;

	private String description;

	private String rejectionReasonCode;

	private BigDecimal rejectedValue;

	private String productId;

	private Date startDate;

	private Date endDate;

	private String locationCode;

	private BigDecimal quantity;

	private String uomCode;

	private BigDecimal unitPrice;

	private String scallingFactor;

	private BigDecimal chargeAmount;

	private BigDecimal taxAmount;

	private BigDecimal vatAmount;

	private BigDecimal addonChargeAmount;

	private BigDecimal totalAddonChargeAmount;

	private BigDecimal totalTaxAmount;

	private BigDecimal totalVatAmount;

	private BigDecimal totalNetAmount;

	private Integer originalLineItemNumber;

	private Integer detailCount;

	private BigDecimal chargeAmountAccepted;
	
	private BigDecimal totalTaxAmountAccepted;
	
	private BigDecimal totalVatAmountAccepted;
	
	private BigDecimal totAddonChargeAmtAccepted;
	
	private BigDecimal netAmountAccepted;
	
	private BigDecimal chargeAmountRejected;
	
	private BigDecimal totalTaxAmountRejected;
	
	private BigDecimal totalVatAmountRejected;
	
	private BigDecimal totAddonChargeAmtRejected;
	
	private BigDecimal netAmountRejected;
	
	private String processStatus;
	
	private String chargeCodeType;

	private List<MiscBillingInvLineitemDtl> miscBillingLineitemDetails;

	private List<MiscBillingTaxDetails> miscBillingTaxDetails;

	private List<MiscBillingAddOnChargeDtl> miscBillingAddOnChargeDtl;

}
