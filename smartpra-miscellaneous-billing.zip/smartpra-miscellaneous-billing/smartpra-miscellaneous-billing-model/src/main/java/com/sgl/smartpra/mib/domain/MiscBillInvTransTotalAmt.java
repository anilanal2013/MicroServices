package com.sgl.smartpra.mib.domain;

import java.math.BigDecimal;

import com.sgl.smartpra.common.model.BaseMaster;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class MiscBillInvTransTotalAmt extends BaseMaster {

	/**
	 *  Serial Version Id
	 */
	private static final long serialVersionUID = 1L;

	private int transSummaryDtlId;

	private String currencyCode;

	private BigDecimal totalAmount;
}
