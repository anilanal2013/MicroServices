package com.sgl.smartpra.mib.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/**
 * @author kanprasa
 *
 */
@Data
@Entity
@Table(name="invoice_supporting_document", schema="SmartPRASales")
public class MiscBillingInvSupportingDocEntity extends BaseEntity<String> implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="invoice_supporting_document_id", unique=true, nullable=false)
	private Integer invSuppDocId;
	
	@Column(name="client_id", nullable=false, length=2)
	private String clientId;
	
	@Column(name="document_unique_no", nullable=false, length=33)
	private String documentUniqueNo;
	
	@Column(name="billing_type", nullable=false, length=1)
	private String billingType;
	
	@Column(name="billing_month", nullable=false, length=6)
	private String billingMonth;
	
	@Column(name="billing_period", nullable=false)
	private Integer billingPeriod;
	
	@Column(name="billing_carrier", nullable=false, length=3)
	private String billingCarrier;

	@Column(name="billed_carrier", nullable=false, length=3)
	private String billedCarrier;
	
	@Column(name="transaction_type", nullable=false, length=3)
	private String transactionType;
	
	@Column(name="invoice_no", nullable=true, length=10)
	private String invoiceNo;
	
	@Column(name="batch_key", nullable=true, length=30)
	private String batchKey;
	
	@Column(name="batch_seq", nullable=true)
	private Integer batchSeq;
	
	@Column(name="record_seq", nullable=true)
	private Integer recordSeq;
	
	@Column(name="breakdown_seq_no", nullable=true)
	private Integer breakdownSeqNo;
	
	@Column(name="carrier_code", nullable=true, length=3)
	private String carrierCode;
	
	@Column(name="document_no", nullable=true, length=20)
	private String documentNo;
	
	@Column(name="coupon_no", nullable=true)
	private Integer couponNo;
	
	@Column(name="memo_no", nullable=true, length=11)
	private String memoNo;
	
	@Column(name="fim_no", nullable=true, length=20)
	private String fimNo;
	
	@Column(name="attachment_seq", nullable=false)
	private Integer attachmentSeq;
	
	@Column(name="attachment_type", nullable=false, length=10)
	private String attachmentType;
	
	@Column(name="file_name", nullable=false, length=65)
	private String fileName;
	
	@Column(name="file_path", nullable=false, length=250)
	private String filePath;
	
	@Column(name="transaction_ref_no", nullable=false, length=15)
	private String transactionRefNo;
	
	@Column(name="file_id", nullable=false, length=10)
	private String fileId;

	
}
