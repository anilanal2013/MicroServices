package com.sgl.smartpra.mib.utils;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MiscBillingCommonUtil {
	
	public MiscBillingCommonUtil() {}

	public static String getJsonSchema(MiscBillingTrnInvoice object) throws IOException {

		ObjectMapper mapper = new ObjectMapper();
		String jsonString = mapper.writeValueAsString(object);
		log.debug(jsonString);
		return jsonString;
	}

	public static String getMonth(String month) {
		String result = MiscBillingConstants.EMPTY_STRING;
		switch (month) {
		case "01":
			result = "JAN";
			break;
		case "02":
			result = "FEB";
			break;
		case "03":
			result = "MAR";
			break;
		case "04":
			result = "APR";
			break;
		case "05":
			result = "MAY";
			break;
		case "06":
			result = "JUN";
			break;
		case "07":
			result = "JUL";
			break;
		case "08":
			result = "AUG";
			break;
		case "09":
			result = "SEP";
			break;
		case "10":
			result = "OCT";
			break;
		case "11":
			result = "NOV";
			break;
		case "12":
			result = "DEC";
			break;
		}
		return result;
	}

	public static String getMonthInDigit(String month) {

		String result = MiscBillingConstants.EMPTY_STRING;
		switch (month) {
		case "JAN":
			result = "01";
			break;
		case "FEB":
			result = "02";
			break;
		case "MAR":
			result = "03";
			break;
		case "APR":
			result = "04";
			break;
		case "MAY":
			result = "05";
			break;
		case "JUN":
			result = "06";
			break;
		case "JUL":
			result = "07";
			break;
		case "AUG":
			result = "08";
			break;
		case "SEP":
			result = "09";
			break;
		case "OCT":
			result = "10";
			break;
		case "NOV":
			result = "11";
			break;
		case "DEC":
			result = "12";
			break;
		}
		return result;
	}

	public static String getMonthInMMMFormat(int month) {
		String result = MiscBillingConstants.EMPTY_STRING;
		switch (month) {
		case 1:
			result = "JAN";
			break;
		case 2:
			result = "FEB";
			break;
		case 3:
			result = "MAR";
			break;
		case 4:
			result = "APR";
			break;
		case 5:
			result = "MAY";
			break;
		case 6:
			result = "JUN";
			break;
		case 7:
			result = "JUL";
			break;
		case 8:
			result = "AUG";
			break;
		case 9:
			result = "SEP";
			break;
		case 10:
			result = "OCT";
			break;
		case 11:
			result = "NOV";
			break;
		case 12:
			result = "DEC";
			break;
		}
		return result;
	}
	
	public static String getCurrentBillingMonth() {
		LocalDate currentDate = LocalDate.now();
		int month = currentDate.getMonthValue();
	    int year = currentDate.getYear();
	    return getMonthInMMMFormat(month) +"-"+ String.valueOf(year).substring(2, 4);
	   
	}
	
	public static String getNextBatchNo(String currentBatchNo) {
		String batchConstant=currentBatchNo.substring(0,4);
		
		Integer seq = Integer.parseInt(currentBatchNo.substring(4));
   		seq++;
   		return batchConstant+SmartPRACommonUtil.padString(String.valueOf(seq), "0", 6);
	}
	
	public static BigDecimal getBigDecimalValue(BigDecimal data) {
		BigDecimal value = new BigDecimal(0);
		return  data!=null?data:value;
	}
	
	public static <T, E> T getKeyByValue(Map<T, E> map, E value) {
	    for (Entry<T, E> entry : map.entrySet()) {
	        if (Objects.equals(value, entry.getValue())) {
	            return entry.getKey();
	        }
	    }
	    return null;
	}
	
	public static String getDateToString(String dateFormat, Date date) {
		Optional<Date> dateOpt = Optional.ofNullable(date);
		String strDate=null;
		if(dateOpt.isPresent()) {
			strDate = new SimpleDateFormat(dateFormat).format(dateOpt.get());
		}
		return strDate;
	}
	
	public static String convertLocalDateToString(String format, LocalDate date) {
		if(date != null) {
			try {
				return date.format(DateTimeFormatter.ofPattern(format));
			} catch (Exception e) {
				log.debug("Exception thrown while converting locaDateToString()");
			}
		} 
		return "";
	}
	
	public static LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
	    return dateToConvert.toInstant()
	      .atZone(ZoneId.systemDefault())
	      .toLocalDate();
	}
	
	public static Date convertStringToDate(String format, String stringToDate) {
		
        Date date = null;
        try {
        	System.out.println(stringToDate);
            date = new SimpleDateFormat(format).parse(stringToDate);
            System.out.println(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
	}
	
}