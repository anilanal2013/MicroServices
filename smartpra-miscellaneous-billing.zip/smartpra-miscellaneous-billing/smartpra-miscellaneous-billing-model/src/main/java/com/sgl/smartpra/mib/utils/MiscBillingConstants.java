package com.sgl.smartpra.mib.utils;

import java.math.BigDecimal;

public class MiscBillingConstants {
	
	private MiscBillingConstants() {}
	
	public static final String EMPTY_STRING = "";
	public static final String MIB = "MIB";
	public static final String MIB10001 = "MIB10001";
	public static final String CREATED_BY = "Admin";
	
	public static final String MO = "MO";
	public static final String MI = "MI";
	public static final String FY = "19-20";
	public static final String BATCH_NUM_INTITIALIZER = "000001";
	
	public static final String INWARD_FLAG = "I";
	public static final String OUTWARD_FLAG = "O";
	
	public static final String CURRENCY_USD = "USD";
	public static final String RATE_TYPE_FDR = "FDR";
	public static final String RATE_TYPE_BKR = "BKR";

	public static final String MISC_1126 = "MISC1126";
	public static final String MISC_1125 = "MISC1125";



	public static final BigDecimal BIGDECIMAL_NULL = null;
	public static final BigDecimal BIGDECIMAL_ZERO = BigDecimal.ZERO.setScale(3);

	public static final String STRING_NULL = null;
	public static final String LINEITEM_INVOICE_STATUS_OPEN = "OP";
	public static final String LINEITEM_INVOICE_STATUS_EVALUATED = "EV";
	public static final String LINEITEM_INVOICE_STATUS_NOT_EVALUATED = "ER";
	public static final String LINEITEM_INVOICE_STATUS_CONFIRM = "CO";
	public static final String SUPPLIER_TYPE = "supplierType";
	public static final String SUPPLIER_NAME = "supplierName";
	public static final String SELLER_ORG_ID = "sellerOrganizationId";
	public static final String SETTLEMENT_MONTH_PERIOD = "settlementMonthPeriod";
	public static final String INWARD_OUTWARD_FLAG = "inwardOutwardFlag";
	public static final String INVOICE_STATUS = "invoiceStatus";
	public static final String INVOICE_NUMBER = "invoiceNumber";
	
	public static final String DEFAULT_CARRIER_NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";
	public static final String PARAM_DEFAULT_CURRENCY_CODE = "DEFAULT_CURRENCY_CODE";
	
}
