package com.sgl.smartpra.mib.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sgl.smartpra.common.model.BaseMaster;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MiscBillingTrnInvoice extends BaseMaster {

	/**
	 *  Serial version Id
	 */
	private static final long serialVersionUID = 1L;

	private String invoiceUrn;

	//private Integer transHdrId;
	
	private String clientId;

	private String invoiceNumber;

	private String jvReferenceNumber;

	private Date invoiceDate;

	private String invoiceType;

	private String taxInvoiceNumber;

	private Date taxPointDate;

	private String locationCode;

	private String chargeCategoryCode;

	private String sellerOrganizationId;

	private String sellerLocationId;

	private String buyerOrganizationId;

	private String buyerLocationId;

	private String currencyCode;

	private String clearanceCurrencyCode;

	private BigDecimal exchangeRate;

	private BigDecimal bkrExchangeRate;

	private Integer accountingMonth;

	private Date accountingDate;

	private String settlementMonthPeriod;

	private String settlementMethod;

	private String digitalSignatureFlag;

	private String suspendedFlag;

	private String isValidationFlag;

	private String rejectionFlag;

	private Integer rejectionStage;

	private String originalInvoiceNumber;

	private Integer originalBillingPeriod;

	private String orginalBillingMonth;

	private String correspondanceFlag;

	private String authorityToBillFlag;

	private Integer correspondanceRefNo;

	private String disputeRefNumber;

	private String poNumber;

	private String invoiceTemplateLanguage;

	private String description;

	private Integer noOfAttachments;

	private Integer lineItemCount;

	private BigDecimal totalLineItemAmount;

	private BigDecimal taxAmount;

	private BigDecimal vatAmount;

	private BigDecimal addonChargeAmount;

	private BigDecimal totalAddonChargeAmount;

	private BigDecimal totalTaxAmount;

	private BigDecimal totalVatAmount;

	private BigDecimal totalAmount;

	private BigDecimal totalClearanceCurrencyAmt;

	private String baseCurrency;

	private BigDecimal amountBaseCurrency;

	private String inwardOutwardFlag;

	private String invoiceStatus;

	private String rejInvoiceNo;

	private String billingMonth;

	private Integer billingPeriod;

	private String supplierType;
	
	private BigDecimal chargeAmountAccepted;
	
	private BigDecimal totalTaxAmountAccepted;
		
	private BigDecimal totalVatAmountAccepted;
		
	private BigDecimal totalAddonChargeAmountAccepted;
		
	private BigDecimal netAmountAccepted;
		
	private BigDecimal chargeAmountRejected;
	
	private BigDecimal totalTaxAmountRejected;
		
	private BigDecimal totalVatAmountRejected;
		
	private BigDecimal totalAddonChargeAmountRejected;
		
	private BigDecimal netAmountRejected;
	
	private String supplierName;

//	private Integer miscBillingInvTransHeader;

	private List<MiscBillingInvLineitem> miscBillingInvLineitem;

	private List<MiscBillingTaxDetails> miscBillingTaxDetails;

	private List<MiscBillingAddOnChargeDtl> miscBillingAddOnChargeDtl;

	private List<MiscBillingInvAttachment> miscBillingInvAttachment;

	private String errorMessage;
}
