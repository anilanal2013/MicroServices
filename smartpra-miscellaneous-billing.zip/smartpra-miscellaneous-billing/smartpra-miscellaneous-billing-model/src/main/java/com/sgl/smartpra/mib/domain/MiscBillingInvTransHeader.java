package com.sgl.smartpra.mib.domain;

import java.util.List;

import com.sgl.smartpra.common.model.BaseMaster;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class MiscBillingInvTransHeader extends BaseMaster {


	/**
	 *  Serial Version Id
	 */
	private static final long serialVersionUID = 1L;

	private Integer transHdrId;

	private String clientId;

	private String billingMonth;

	private Integer billingPeriod;

	private String transmissionDateTime;

	private String transVersion;

	private String transmissionId;

	private String issuingOrganizationId;

	private String receivingOrganizationId;

	private Integer invoiceCount;

	private Integer attachmentCount;

	private String billingCategory;

	private String inwardOutwardFlag;

	private Integer fileId;

	/*private List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoices;

	private List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmt;*/
}
