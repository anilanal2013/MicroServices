package com.sgl.smartpra.mib.entity;
import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

/**
 * The persistent class for the misc_billing_addon_charge_dtl database table.
 * 
 */
@Data
@Entity
@Table(name="misc_bill_addon_charge_detail")
public class MiscBillingAddOnChargeDtlEntity extends BaseEntity<String> implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="misc_billing_addon_dtl_id", unique=true, nullable=false)
	private Integer miscBillingAddOnChargeDtlId;
	
	@Column(name="record_seq_number")
	private Integer recordSeqNumber;

	@Column(name="addon_charge_name")
	private String addOnChargeName;

	@Column(name="addon_charge_percentage")
	private BigDecimal addOnChargePercentage;

	@Column(name="addon_chargeable_amount")
	private BigDecimal addOnChargeableAmount;

	@Column(name="addon_charge_amount")
	private BigDecimal addOnChargeAmount;

	@Column(name="addon_level")
	private String addOnLevel;
	
	@Column(name="addon_charge_accepted", precision=16, scale=3)
	private BigDecimal addonChargeAccepted;
	
	@Column(name="addon_charge_rejected", precision=16, scale=3)
	private BigDecimal addonChargeRejected;
	
	//bi-directional many-to-one association to MiscBillingTrnInvoice
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="invoice_urn")
	private MiscBillingTrnInvoiceEntity miscBillingTrnInvoice;

	//bi-directional many-to-one association to miscBillingInvLineitem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="inv_line_item_id")
	private MiscBillingInvLineitemEntity miscBillingInvLineitem;
	
	//bi-directional many-to-one association to miscBillingInvLineitemDtl
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="inv_line_itemdetail_id")
	private MiscBillingInvLineitemDtlEntity miscBillingInvLineitemDtl;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MiscBillingAddOnChargeDtlEntity other = (MiscBillingAddOnChargeDtlEntity) obj;
		if (miscBillingAddOnChargeDtlId == null) {
			if (other.miscBillingAddOnChargeDtlId != null)
				return false;
		} else if (!miscBillingAddOnChargeDtlId.equals(other.miscBillingAddOnChargeDtlId))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((miscBillingAddOnChargeDtlId == null) ? 0 : miscBillingAddOnChargeDtlId.hashCode());
		return result;
	}
    
}
