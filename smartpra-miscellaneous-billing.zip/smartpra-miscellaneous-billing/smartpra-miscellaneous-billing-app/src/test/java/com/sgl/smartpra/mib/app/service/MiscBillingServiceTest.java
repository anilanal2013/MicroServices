//package com.sgl.smartpra.mib.app.service;

/*import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import com.sgl.smartpra.mib.app.config.FeignConfiguration;
import com.sgl.smartpra.mib.app.mapper.InvoiceEvaluationMapper;
import com.sgl.smartpra.mib.app.mapper.InvoiceEvaluationMapperImpl;
import com.sgl.smartpra.mib.app.mapper.MiscBillingMapperImpl;
import com.sgl.smartpra.mib.app.repository.MiscBillingRepository;
import com.sgl.smartpra.mib.app.utility.MiscBillingUtil;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.mib.app.dao.MiscBillingDao;
import com.sgl.smartpra.mib.app.dto.InvoiceOperational;
import com.sgl.smartpra.mib.app.mapper.MiscBillingMapper;
import com.sgl.smartpra.mib.app.service.impl.MiscBillingServiceImpl;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

//@RunWith(SpringRunner.class)
/*@SpringBootTest(classes = MiscBillingServiceTest.conf.class)
@ActiveProfiles(value = "Test")*/
/*public class MiscBillingServiceTest {
    @Autowired
    MiscBillingService miscBillingService;

    @Autowired
    MiscBillingDao miscBillingDao;

    @Autowired
    MiscBillingMapper miscBillingMapper;

    @Autowired
    private MiscBillingRepository miscBillingRepository;

    @Autowired
    private InvoiceEvaluationMapper invoiceEvaluationMapper;

    @Autowired
    FeignConfiguration.AccountingServiceFeignClient accountingServiceFeignClient;

    @Autowired
    FeignConfiguration.ExchangeRateFeignClient exchangeRateFeignClient;

    @Autowired
    MiscBillingUtil miscBillingUtil;


   /* public static List<MiscBillingTrnInvoiceEntity> fetchMiscBillingTrnInvoices() {
        List<MiscBillingTrnInvoiceEntity> alMisc = new ArrayList<>();
        MiscBillingTrnInvoiceEntity miscBillingTrnInvoice = new MiscBillingTrnInvoiceEntity();
        miscBillingTrnInvoice.setBillingMonth("APR-19");
        miscBillingTrnInvoice.setBillingPeriod(2);
        miscBillingTrnInvoice.setSettlementMonthPeriod("190402");
        miscBillingTrnInvoice.setInwardOutwardFlag("I");
        miscBillingTrnInvoice.setSellerOrganizationId("A1");
        miscBillingTrnInvoice.setInvoiceType("I");
        miscBillingTrnInvoice.setCurrencyCode("USD");
        miscBillingTrnInvoice.setTotalAmount(new BigDecimal(100));
        alMisc.add(miscBillingTrnInvoice);
        miscBillingTrnInvoice = new MiscBillingTrnInvoiceEntity();
        miscBillingTrnInvoice.setBillingMonth("APR-19");
        miscBillingTrnInvoice.setBillingPeriod(2);
        miscBillingTrnInvoice.setSellerOrganizationId("A1");
        miscBillingTrnInvoice.setSettlementMonthPeriod("190402");
        miscBillingTrnInvoice.setInwardOutwardFlag("I");
        miscBillingTrnInvoice.setInvoiceType("I");
        miscBillingTrnInvoice.setCurrencyCode("USD");
        miscBillingTrnInvoice.setTotalAmount(new BigDecimal(100));
        alMisc.add(miscBillingTrnInvoice);
        miscBillingTrnInvoice = new MiscBillingTrnInvoiceEntity();
        miscBillingTrnInvoice.setBillingMonth("APR-19");
        miscBillingTrnInvoice.setBillingPeriod(2);
        miscBillingTrnInvoice.setSettlementMonthPeriod("190402");
        miscBillingTrnInvoice.setInwardOutwardFlag("I");
        miscBillingTrnInvoice.setSellerOrganizationId("A1");
        miscBillingTrnInvoice.setInvoiceType("I");
        miscBillingTrnInvoice.setCurrencyCode("USD");
        miscBillingTrnInvoice.setTotalAmount(new BigDecimal(100));
        alMisc.add(miscBillingTrnInvoice);
        miscBillingTrnInvoice = new MiscBillingTrnInvoiceEntity();
        miscBillingTrnInvoice.setBillingMonth("APR-19");
        miscBillingTrnInvoice.setBillingPeriod(2);
        miscBillingTrnInvoice.setSellerOrganizationId("A1");
        miscBillingTrnInvoice.setInvoiceType("C");
        miscBillingTrnInvoice.setCurrencyCode("USD");
        miscBillingTrnInvoice.setSettlementMonthPeriod("190402");
        miscBillingTrnInvoice.setInwardOutwardFlag("O");
        miscBillingTrnInvoice.setTotalAmount(new BigDecimal(100));
        alMisc.add(miscBillingTrnInvoice);
        miscBillingTrnInvoice = new MiscBillingTrnInvoiceEntity();
        miscBillingTrnInvoice.setBillingMonth("APR-19");
        miscBillingTrnInvoice.setBillingPeriod(3);
        miscBillingTrnInvoice.setSellerOrganizationId("AW");
        miscBillingTrnInvoice.setInvoiceType("I");
        miscBillingTrnInvoice.setCurrencyCode("USD");
        miscBillingTrnInvoice.setSettlementMonthPeriod("190403");
        miscBillingTrnInvoice.setInwardOutwardFlag("I");
        miscBillingTrnInvoice.setTotalAmount(new BigDecimal(100));
        alMisc.add(miscBillingTrnInvoice);
        miscBillingTrnInvoice = new MiscBillingTrnInvoiceEntity();
        miscBillingTrnInvoice.setBillingMonth("APR-19");
        miscBillingTrnInvoice.setBillingPeriod(3);
        miscBillingTrnInvoice.setSellerOrganizationId("AW");
        miscBillingTrnInvoice.setInvoiceType("I");
        miscBillingTrnInvoice.setCurrencyCode("USD");
        miscBillingTrnInvoice.setSettlementMonthPeriod("190403");
        miscBillingTrnInvoice.setInwardOutwardFlag("I");
        miscBillingTrnInvoice.setTotalAmount(new BigDecimal(100));
        alMisc.add(miscBillingTrnInvoice);
        miscBillingTrnInvoice = new MiscBillingTrnInvoiceEntity();
        miscBillingTrnInvoice.setBillingMonth("APR-19");
        miscBillingTrnInvoice.setBillingPeriod(3);
        miscBillingTrnInvoice.setSellerOrganizationId("AW");
        miscBillingTrnInvoice.setInvoiceType("C");
        miscBillingTrnInvoice.setCurrencyCode("USD");
        miscBillingTrnInvoice.setSettlementMonthPeriod("190403");
        miscBillingTrnInvoice.setInwardOutwardFlag("O");
        miscBillingTrnInvoice.setTotalAmount(new BigDecimal(100));
        alMisc.add(miscBillingTrnInvoice);
        return alMisc;
    }

    @Test
    public void testFetchInvoice() throws Exception {
        List<InvoiceOperational> al = new ArrayList<>();
        Mockito.when(miscBillingDao.fetchInvoice(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(fetchMiscBillingTrnInvoices());
        al = miscBillingService.fetchInvoice(Optional.of("APR-19"), Optional.of(2), null,
                null,
                null, null, Optional.of("176"), null,
                null, Optional.of("I"), Optional.of(""), null, null, null,
                null);

        ObjectMapper objectMapper = new ObjectMapper();
        Assert.assertEquals("[{\"supplierName\":null,\"billingMonth\":\"APR-19\",\"inward\":{\"amountInvoiceCurrency\":\"200\",\"noOfInvoices\":2,\"inOutChecks\":\"I\",\"baseCurrency\":null,\"amountBaseCurrency\":\"0\",\"invoiceCurrency\":\"USD\"},\"billingPeriod\":3,\"supplierCode\":\"AW\",\"outward\":{\"amountInvoiceCurrency\":\"100\",\"noOfInvoices\":1,\"inOutChecks\":\"O\",\"baseCurrency\":null,\"amountBaseCurrency\":\"0\",\"invoiceCurrency\":\"USD\"}},{\"supplierName\":null,\"billingMonth\":\"APR-19\",\"inward\":{\"amountInvoiceCurrency\":\"300\",\"noOfInvoices\":3,\"inOutChecks\":\"I\",\"baseCurrency\":null,\"amountBaseCurrency\":\"0\",\"invoiceCurrency\":\"USD\"},\"billingPeriod\":2,\"supplierCode\":\"A1\",\"outward\":{\"amountInvoiceCurrency\":\"100\",\"noOfInvoices\":1,\"inOutChecks\":\"O\",\"baseCurrency\":null,\"amountBaseCurrency\":\"0\",\"invoiceCurrency\":\"USD\"}}]",
                objectMapper.writeValueAsString(al));

    }

    @Test
    public void testFetchInvoiceInward() throws Exception {
        List<InvoiceOperational> al = new ArrayList<>();
        Mockito.when(miscBillingDao.fetchInvoice(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(fetchMiscBillingTrnInvoices().stream()
                .filter(w -> StringUtils.equalsIgnoreCase(w.getInwardOutwardFlag(), "I")).collect(Collectors.toList()));
        al = miscBillingService.fetchInvoice(Optional.of("APR-19"), Optional.of(2), null,
                null,
                null, null, Optional.of("176"), null,
                null, Optional.of("I"), Optional.of(""), null, null, null,
                null);

        ObjectMapper objectMapper = new ObjectMapper();
        Assert.assertEquals("[{\"supplierName\":null,\"billingMonth\":\"APR-19\",\"inward\":{\"amountInvoiceCurrency\":\"200\",\"noOfInvoices\":2,\"inOutChecks\":\"I\",\"baseCurrency\":null,\"amountBaseCurrency\":\"0\",\"invoiceCurrency\":\"USD\"},\"billingPeriod\":3,\"supplierCode\":\"AW\",\"outward\":{\"amountInvoiceCurrency\":null,\"noOfInvoices\":null,\"inOutChecks\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"invoiceCurrency\":null}},{\"supplierName\":null,\"billingMonth\":\"APR-19\",\"inward\":{\"amountInvoiceCurrency\":\"300\",\"noOfInvoices\":3,\"inOutChecks\":\"I\",\"baseCurrency\":null,\"amountBaseCurrency\":\"0\",\"invoiceCurrency\":\"USD\"},\"billingPeriod\":2,\"supplierCode\":\"A1\",\"outward\":{\"amountInvoiceCurrency\":null,\"noOfInvoices\":null,\"inOutChecks\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"invoiceCurrency\":null}}]",
                objectMapper.writeValueAsString(al));

    }

    @Test
    public void testFetchInvoiceOutward() throws Exception {
        List<InvoiceOperational> al = new ArrayList<>();
        Mockito.when(miscBillingDao.fetchInvoice(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(fetchMiscBillingTrnInvoices().stream()
                .filter(w -> StringUtils.equalsIgnoreCase(w.getInwardOutwardFlag(), "O")).collect(Collectors.toList()));
        al = miscBillingService.fetchInvoice(Optional.of("APR-19"), Optional.of(2), null,
                null,
                null, null, Optional.of("176"), null,
                null, Optional.of("I"), Optional.of(""), null, null, null,
                null);

        ObjectMapper objectMapper = new ObjectMapper();
        Assert.assertEquals("[{\"supplierName\":null,\"billingMonth\":\"APR-19\",\"inward\":{\"amountInvoiceCurrency\":null,\"noOfInvoices\":null,\"inOutChecks\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"invoiceCurrency\":null},\"billingPeriod\":3,\"supplierCode\":\"AW\",\"outward\":{\"amountInvoiceCurrency\":\"100\",\"noOfInvoices\":1,\"inOutChecks\":\"O\",\"baseCurrency\":null,\"amountBaseCurrency\":\"0\",\"invoiceCurrency\":\"USD\"}},{\"supplierName\":null,\"billingMonth\":\"APR-19\",\"inward\":{\"amountInvoiceCurrency\":null,\"noOfInvoices\":null,\"inOutChecks\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"invoiceCurrency\":null},\"billingPeriod\":2,\"supplierCode\":\"A1\",\"outward\":{\"amountInvoiceCurrency\":\"100\",\"noOfInvoices\":1,\"inOutChecks\":\"O\",\"baseCurrency\":null,\"amountBaseCurrency\":\"0\",\"invoiceCurrency\":\"USD\"}}]",
                objectMapper.writeValueAsString(al));

    }

    @Test
    public void testFetchInvoiceNull() throws Exception {
        List<InvoiceOperational> al = new ArrayList<>();
        Mockito.when(miscBillingDao.fetchInvoice(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(Collections.emptyList());
        al = miscBillingService.fetchInvoice(Optional.of("APR-19"), Optional.of(2), null,
                null,
                null, null, Optional.of("176"), null,
                null, Optional.of("I"), Optional.of(""), null, null, null,
                null);

        ObjectMapper objectMapper = new ObjectMapper();
        Assert.assertTrue(al.isEmpty());

    }

    @Test
    public void testfetchInvoiceDetailsIn() throws Exception {
        Mockito.when(miscBillingDao.fetchInvoiceDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(fetchMiscBillingTrnInvoices()
                        .stream()
                        .filter(w -> StringUtils.equalsIgnoreCase(w.getInwardOutwardFlag(), "I"))
                        .collect(Collectors.toList()));
        List<MiscBillingTrnInvoice> al = miscBillingService.fetchInvoiceDetails(Optional.of("APR-19"), Optional.of(2),
                Optional.of("176"), Optional.of("I"));
        ObjectMapper objectMapper = new ObjectMapper();
        Assert.assertEquals(objectMapper
                .writeValueAsString(al), "[{\"createdBy\":null,\"createdDate\":null,\"lastUpdatedBy\":null,\"lastUpdatedDate\":null,\"invoiceUrn\":null,\"clientId\":null,\"invoiceNumber\":null,\"jvReferenceNumber\":null,\"invoiceDate\":null,\"invoiceType\":\"I\",\"taxInvoiceNumber\":null,\"taxPointDate\":null,\"locationCode\":null,\"chargeCategoryCode\":null,\"sellerOrganizationId\":\"A1\",\"sellerLocationId\":null,\"currencyCode\":\"USD\",\"clearanceCurrencyCode\":null,\"exchangeRate\":null,\"bkrExchangeRate\":null,\"accountingMonth\":null,\"accountingDate\":null,\"settlementMonthPeriod\":\"190402\",\"settlementMethod\":null,\"digitalSignatureFlag\":null,\"suspendedFlag\":null,\"isValidationFlag\":null,\"rejectionFlag\":null,\"rejectionStage\":null,\"originalInvoiceNumber\":null,\"originalBillingPeriod\":null,\"orginalBillingMonth\":null,\"correspondanceFlag\":null,\"authorityToBillFlag\":null,\"correspondanceRefNo\":null,\"disputeRefNumber\":null,\"poNumber\":null,\"invoiceTemplateLanguage\":null,\"description\":null,\"noOfAttachments\":null,\"lineItemCount\":null,\"totalLineItemAmount\":null,\"taxAmount\":null,\"vatAmount\":null,\"addonChargeAmount\":null,\"totalAddonChargeAmount\":null,\"totalTaxAmount\":null,\"totalVatAmount\":null,\"totalAmount\":100,\"totalClearanceCurrencyAmt\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"inwardOutwardFlag\":\"I\",\"invoiceStatus\":null,\"rejInvoiceNo\":null,\"billingMonth\":\"APR-19\",\"billingPeriod\":2,\"settlementType\":null,\"miscBillingInvTransHeader\":null},{\"createdBy\":null,\"createdDate\":null,\"lastUpdatedBy\":null,\"lastUpdatedDate\":null,\"invoiceUrn\":null,\"clientId\":null,\"invoiceNumber\":null,\"jvReferenceNumber\":null,\"invoiceDate\":null,\"invoiceType\":\"I\",\"taxInvoiceNumber\":null,\"taxPointDate\":null,\"locationCode\":null,\"chargeCategoryCode\":null,\"sellerOrganizationId\":\"A1\",\"sellerLocationId\":null,\"currencyCode\":\"USD\",\"clearanceCurrencyCode\":null,\"exchangeRate\":null,\"bkrExchangeRate\":null,\"accountingMonth\":null,\"accountingDate\":null,\"settlementMonthPeriod\":\"190402\",\"settlementMethod\":null,\"digitalSignatureFlag\":null,\"suspendedFlag\":null,\"isValidationFlag\":null,\"rejectionFlag\":null,\"rejectionStage\":null,\"originalInvoiceNumber\":null,\"originalBillingPeriod\":null,\"orginalBillingMonth\":null,\"correspondanceFlag\":null,\"authorityToBillFlag\":null,\"correspondanceRefNo\":null,\"disputeRefNumber\":null,\"poNumber\":null,\"invoiceTemplateLanguage\":null,\"description\":null,\"noOfAttachments\":null,\"lineItemCount\":null,\"totalLineItemAmount\":null,\"taxAmount\":null,\"vatAmount\":null,\"addonChargeAmount\":null,\"totalAddonChargeAmount\":null,\"totalTaxAmount\":null,\"totalVatAmount\":null,\"totalAmount\":100,\"totalClearanceCurrencyAmt\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"inwardOutwardFlag\":\"I\",\"invoiceStatus\":null,\"rejInvoiceNo\":null,\"billingMonth\":\"APR-19\",\"billingPeriod\":2,\"settlementType\":null,\"miscBillingInvTransHeader\":null},{\"createdBy\":null,\"createdDate\":null,\"lastUpdatedBy\":null,\"lastUpdatedDate\":null,\"invoiceUrn\":null,\"clientId\":null,\"invoiceNumber\":null,\"jvReferenceNumber\":null,\"invoiceDate\":null,\"invoiceType\":\"I\",\"taxInvoiceNumber\":null,\"taxPointDate\":null,\"locationCode\":null,\"chargeCategoryCode\":null,\"sellerOrganizationId\":\"A1\",\"sellerLocationId\":null,\"currencyCode\":\"USD\",\"clearanceCurrencyCode\":null,\"exchangeRate\":null,\"bkrExchangeRate\":null,\"accountingMonth\":null,\"accountingDate\":null,\"settlementMonthPeriod\":\"190402\",\"settlementMethod\":null,\"digitalSignatureFlag\":null,\"suspendedFlag\":null,\"isValidationFlag\":null,\"rejectionFlag\":null,\"rejectionStage\":null,\"originalInvoiceNumber\":null,\"originalBillingPeriod\":null,\"orginalBillingMonth\":null,\"correspondanceFlag\":null,\"authorityToBillFlag\":null,\"correspondanceRefNo\":null,\"disputeRefNumber\":null,\"poNumber\":null,\"invoiceTemplateLanguage\":null,\"description\":null,\"noOfAttachments\":null,\"lineItemCount\":null,\"totalLineItemAmount\":null,\"taxAmount\":null,\"vatAmount\":null,\"addonChargeAmount\":null,\"totalAddonChargeAmount\":null,\"totalTaxAmount\":null,\"totalVatAmount\":null,\"totalAmount\":100,\"totalClearanceCurrencyAmt\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"inwardOutwardFlag\":\"I\",\"invoiceStatus\":null,\"rejInvoiceNo\":null,\"billingMonth\":\"APR-19\",\"billingPeriod\":2,\"settlementType\":null,\"miscBillingInvTransHeader\":null},{\"createdBy\":null,\"createdDate\":null,\"lastUpdatedBy\":null,\"lastUpdatedDate\":null,\"invoiceUrn\":null,\"clientId\":null,\"invoiceNumber\":null,\"jvReferenceNumber\":null,\"invoiceDate\":null,\"invoiceType\":\"I\",\"taxInvoiceNumber\":null,\"taxPointDate\":null,\"locationCode\":null,\"chargeCategoryCode\":null,\"sellerOrganizationId\":\"AW\",\"sellerLocationId\":null,\"currencyCode\":\"USD\",\"clearanceCurrencyCode\":null,\"exchangeRate\":null,\"b
    }

    @Test
    public void testfetchInvoiceDetailsOut() throws Exception {
        Mockito.when(miscBillingDao.fetchInvoiceDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(fetchMiscBillingTrnInvoices()
                        .stream()
                        .filter(w -> StringUtils.equalsIgnoreCase(w.getInwardOutwardFlag(), "O"))
                        .collect(Collectors.toList()));
        List<MiscBillingTrnInvoice> al = miscBillingService.fetchInvoiceDetails(Optional.of("APR-19"), Optional.of(2),
                Optional.of("176"), Optional.of("O"));
        ObjectMapper objectMapper = new ObjectMapper();

        Assert.assertEquals(objectMapper
                .writeValueAsString(al), "[{\"createdBy\":null,\"createdDate\":null,\"lastUpdatedBy\":null,\"lastUpdatedDate\":null,\"invoiceUrn\":null,\"clientId\":null,\"invoiceNumber\":null,\"jvReferenceNumber\":null,\"invoiceDate\":null,\"invoiceType\":\"C\",\"taxInvoiceNumber\":null,\"taxPointDate\":null,\"locationCode\":null,\"chargeCategoryCode\":null,\"sellerOrganizationId\":\"A1\",\"sellerLocationId\":null,\"currencyCode\":\"USD\",\"clearanceCurrencyCode\":null,\"exchangeRate\":null,\"bkrExchangeRate\":null,\"accountingMonth\":null,\"accountingDate\":null,\"settlementMonthPeriod\":\"190402\",\"settlementMethod\":null,\"digitalSignatureFlag\":null,\"suspendedFlag\":null,\"isValidationFlag\":null,\"rejectionFlag\":null,\"rejectionStage\":null,\"originalInvoiceNumber\":null,\"originalBillingPeriod\":null,\"orginalBillingMonth\":null,\"correspondanceFlag\":null,\"authorityToBillFlag\":null,\"correspondanceRefNo\":null,\"disputeRefNumber\":null,\"poNumber\":null,\"invoiceTemplateLanguage\":null,\"description\":null,\"noOfAttachments\":null,\"lineItemCount\":null,\"totalLineItemAmount\":null,\"taxAmount\":null,\"vatAmount\":null,\"addonChargeAmount\":null,\"totalAddonChargeAmount\":null,\"totalTaxAmount\":null,\"totalVatAmount\":null,\"totalAmount\":100,\"totalClearanceCurrencyAmt\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"inwardOutwardFlag\":\"O\",\"invoiceStatus\":null,\"rejInvoiceNo\":null,\"billingMonth\":\"APR-19\",\"billingPeriod\":2,\"settlementType\":null,\"miscBillingInvTransHeader\":null},{\"createdBy\":null,\"createdDate\":null,\"lastUpdatedBy\":null,\"lastUpdatedDate\":null,\"invoiceUrn\":null,\"clientId\":null,\"invoiceNumber\":null,\"jvReferenceNumber\":null,\"invoiceDate\":null,\"invoiceType\":\"C\",\"taxInvoiceNumber\":null,\"taxPointDate\":null,\"locationCode\":null,\"chargeCategoryCode\":null,\"sellerOrganizationId\":\"AW\",\"sellerLocationId\":null,\"currencyCode\":\"USD\",\"clearanceCurrencyCode\":null,\"exchangeRate\":null,\"bkrExchangeRate\":null,\"accountingMonth\":null,\"accountingDate\":null,\"settlementMonthPeriod\":\"190403\",\"settlementMethod\":null,\"digitalSignatureFlag\":null,\"suspendedFlag\":null,\"isValidationFlag\":null,\"rejectionFlag\":null,\"rejectionStage\":null,\"originalInvoiceNumber\":null,\"originalBillingPeriod\":null,\"orginalBillingMonth\":null,\"correspondanceFlag\":null,\"authorityToBillFlag\":null,\"correspondanceRefNo\":null,\"disputeRefNumber\":null,\"poNumber\":null,\"invoiceTemplateLanguage\":null,\"description\":null,\"noOfAttachments\":null,\"lineItemCount\":null,\"totalLineItemAmount\":null,\"taxAmount\":null,\"vatAmount\":null,\"addonChargeAmount\":null,\"totalAddonChargeAmount\":null,\"totalTaxAmount\":null,\"totalVatAmount\":null,\"totalAmount\":100,\"totalClearanceCurrencyAmt\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"inwardOutwardFlag\":\"O\",\"invoiceStatus\":null,\"rejInvoiceNo\":null,\"billingMonth\":\"APR-19\",\"billingPeriod\":3,\"settlementType\":null,\"miscBillingInvTransHeader\":null}]");
    }

    @Test
    public void testfetchInvoiceDetailsNull() throws Exception {
        Mockito.when(miscBillingDao.fetchInvoiceDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(fetchMiscBillingTrnInvoices()
                        .stream()
                        .filter(w -> StringUtils.equalsIgnoreCase(w.getInwardOutwardFlag(), "O"))
                        .collect(Collectors.toList()));
        List<MiscBillingTrnInvoice> al = miscBillingService.fetchInvoiceDetails(Optional.of("APR-19"), Optional.of(2),
                Optional.of("176"), Optional.of("I"));
        Assert.assertFalse(al.isEmpty());

    }
*/
/*
   @Test
   public void test(){
       System.out.println("The val");
      /* List<MiscBillingTrnInvoiceEntity> al = miscBillingRepository.finadAllByInvoiceStatusOrderByLastUpdatedDateAsc(
               Arrays.asList("CO"), Arrays.asList("BI"));
       Assert.assertEquals(2,al.size());*/
  /* }

    @TestConfiguration
    static class conf {

        @Bean
        public MiscBillingService miscBillingService() {
            return new MiscBillingServiceImpl();
        }

        @Bean
        public MiscBillingMapper miscBillingMapper() {
            return new MiscBillingMapperImpl();
        }

        @Bean
        public MiscBillingDao miscBillingDao() {
            return Mockito.mock(MiscBillingDao.class);
        }


        @Bean
        public InvoiceEvaluationMapper invoiceEvaluationMapper() {
            return new InvoiceEvaluationMapperImpl();
        }

       /* @Bean
        public FeignConfiguration.AccountingServiceFeignClient accountingServiceFeignClient() {
            return new FeignConfiguration.AccountingServiceFeignClient(){};
        }

        @Autowired
        FeignConfiguration.ExchangeRateFeignClient exchangeRateFeignClient;*/

       /* @Bean
        public MiscBillingUtil miscBillingUtil() {
            return new MiscBillingUtil();
        }*/
   // }
//}