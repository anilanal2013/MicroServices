package com.sgl.smartpra.mib.app.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class InvoiceOperational implements Serializable {

    private String supplierName;

    private String billingMonth;

    private InvoiceFlow inward;

    private Integer billingPeriod;

    private String supplierCode;

    private InvoiceFlow outward;
}
