package com.sgl.smartpra.mib.app.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.mib.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.mib.app.repository.MiscBillingRepository;
import com.sgl.smartpra.mib.utils.MiscBillingConstants;

import lombok.extern.slf4j.Slf4j;

@Service(value="miscBillingCommonService")
@Slf4j
public class MiscBillingCommonService {

	@Autowired
	private MiscBillingRepository miscBillingRepository;
	
	@Autowired
	private MasterFeignClient masterFeignClient;
	
	public String generateInwardBatchNo(String clientId){
		String latestBatchNoFromDb = getLatestInwardBatchNoFromDb();
		String invoiceUrn;
		String finYear = getCurrentFinancialYear(clientId);
		
		if (StringUtils.isEmpty(latestBatchNoFromDb)) {
			invoiceUrn = MiscBillingConstants.MI + finYear.substring(0, 2) + MiscBillingConstants.BATCH_NUM_INTITIALIZER;
		} else {
			invoiceUrn = getNextBatchNo(latestBatchNoFromDb, finYear);
		}
		
	   	return invoiceUrn;
	}
	
	private String getNextBatchNo(String currentBatchNo, String finYear) {
		Integer seq = Integer.parseInt(currentBatchNo.substring(4));
   		seq++;
   		String nextSeq = SmartPRACommonUtil.padString(String.valueOf(seq), "0", 6);
   		return MiscBillingConstants.MI+finYear.substring(0, 2) + nextSeq;
   	}
	
	private String getLatestInwardBatchNoFromDb() {
		String invoiceUrn = null;
	   	List<?> list = new ArrayList<>();
		Object[] existingInvoice = miscBillingRepository.findBySpecificId();
	   	if(existingInvoice != null && existingInvoice.length > 0) {
	   		
	   		if (existingInvoice.getClass().isArray()) {
	   			list = Arrays.asList((Object[])existingInvoice);
	   		} 
	   		
	   		for (Object obj : list) {
	   			List<?> newList;
	   			if (obj.getClass().isArray()) {
	   				newList = Arrays.asList((Object[])obj);
	   				if(newList != null && !newList.isEmpty()) {
	   					invoiceUrn = (String)newList.get(0);
	   					break;
	   				}
		   		} 
			}
	   	}
	   	return invoiceUrn;
	}
	
	public String generateOutwardBatchNo(String clientId) {
		String latestMoBatchNo = fetchLatestOutwardBatchNo();
		String invoiceUrn;
		
		String finYear = getCurrentFinancialYear(clientId);
				
		if (StringUtils.isEmpty(latestMoBatchNo)) {
			invoiceUrn = MiscBillingConstants.MO + finYear.substring(0, 2) + MiscBillingConstants.BATCH_NUM_INTITIALIZER;
		} else {
			invoiceUrn = getNextMoBatchNo(latestMoBatchNo,finYear);
		}
		return invoiceUrn;
	}

	private String getNextMoBatchNo(String currentBatchNo, String finYear) {
		Integer seq = Integer.parseInt(currentBatchNo.substring(4));
   		seq++;
   		String nextSeq = SmartPRACommonUtil.padString(String.valueOf(seq), "0", 6);
   		
   		return MiscBillingConstants.MO+finYear.substring(0, 2) + nextSeq;
	}
	
	private String fetchLatestOutwardBatchNo() {
		String invoiceUrn=null;
		List<?> list = new ArrayList<>();
		Object[] existingInvoice = miscBillingRepository.findBySpecificMoId();
		if (existingInvoice != null && existingInvoice.length > 0) {

			if (existingInvoice.getClass().isArray()) {
				list = Arrays.asList((Object[]) existingInvoice);
			}

			for (Object obj : list) {
				List<?> newList = null;
				if (obj.getClass().isArray()) {
					newList = Arrays.asList((Object[]) obj);
					if (newList != null && !newList.isEmpty()) {
						invoiceUrn = (String) newList.get(0);
						break;
					}
				}
			}
		}
		return invoiceUrn;
	}
	
	public String getCurrentFinancialYear(String clientId) {
		FinancialMonthModel financialMonthModel = null;
		String finYear = MiscBillingConstants.EMPTY_STRING;
		try {
			financialMonthModel = masterFeignClient.getCurrentOpenFinancialMonthForFinancialCalendar(clientId);
		} catch (Exception e) {
			log.error("Error thrown while calling master getCurrentOpenFinancialMonthForFinancialCalendar() " + e.getMessage());
		}
		if(financialMonthModel != null) {
			finYear = financialMonthModel.getFinancialYear();
		}else if(StringUtils.isEmpty(finYear)) {
			log.info("Current Financial Year not found in master data for client id :" + clientId);
			 int year = Calendar.getInstance().get(Calendar.YEAR);
			 finYear=String.valueOf(year);
		}
		return finYear;
	}
}
