package com.sgl.smartpra.mib.app.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.mib.app.dao.MiscBillingInvoiceDao;
import com.sgl.smartpra.mib.app.dto.Invoices;
import com.sgl.smartpra.mib.app.dto.StatusRequest;
import com.sgl.smartpra.mib.app.repository.MiscBillingInvoiceRepository;
import com.sgl.smartpra.mib.app.repository.spec.MiscBillingTrnInvoiceEntitySpec;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.repository.MiscBillingInvLineitemDataRepository;
import com.sgl.smartpra.mib.repository.MiscBillingTrnInvoiceDataRepository;

@Component
public class MiscBillingInvoiceDaoImpl implements MiscBillingInvoiceDao {

	@Autowired
	MiscBillingInvoiceRepository miscBillingInvoiceRepository;

	@Autowired
	MiscBillingInvLineitemDataRepository miscBillingInvLineitemDataRepository;

	@Autowired
	private MiscBillingTrnInvoiceDataRepository invoiceRepository;

	@PersistenceContext
    private EntityManager em;
	
	@Override
	public Optional<MiscBillingTrnInvoiceEntity> getInvoiceView(String batchNumber) {
		return miscBillingInvoiceRepository.findById(batchNumber);
	}

	@Override
	public MiscBillingTrnInvoiceEntity captureInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity) {
		return miscBillingInvoiceRepository.save(miscBillingTrnInvoiceEntity);
	}

	@Override
	public List<MiscBillingTrnInvoiceEntity> getAllInvoices(Optional<String> billingType, Optional<String> supplierType,
			Optional<String> supplierCode, Optional<String> supplierName, Optional<String> billingPeriodMonth,
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber) {
		return miscBillingInvoiceRepository.findAll(MiscBillingTrnInvoiceEntitySpec.getAllInvoices(billingType,
				supplierType, supplierCode, supplierName, billingPeriodMonth, billingPeriod, invoiceNumber));
	}
	
	@Override
	public List<MiscBillingTrnInvoiceEntity> getOutwardInvoicesByBillingMonth(String clientId, String billingMonth, 
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber, Optional<String> carrierCode,
			Optional<String> supplierType) {
		return miscBillingInvoiceRepository.findAll(
				MiscBillingTrnInvoiceEntitySpec.getOutwardInvoicesByBillingMonth(clientId, billingMonth, billingPeriod, 
						invoiceNumber, carrierCode, supplierType));
	}

	@Override
	public Optional<MiscBillingTrnInvoiceEntity> findById(String id) {
		return miscBillingInvoiceRepository.findById(id);
	}

	@Override
	public StatusRequest updateStatus(StatusRequest statusRequest, String level) {
		if (StringUtils.isNotBlank(level) && StringUtils.equalsIgnoreCase("INVOICE", level.toUpperCase())){
				fetchInvoice(statusRequest);
		} else if (StringUtils.isNotBlank(level) && StringUtils.equalsIgnoreCase("LINEITEM", level.toUpperCase())) {
				updateLineItemStatus(statusRequest);
		}

		return statusRequest;
	}

	private void updateLineItemStatus(StatusRequest statusRequest) {
		List<MiscBillingInvLineitemEntity> alMiscBill;
		List<Integer> alInvoices = statusRequest.getInvoices().stream().filter(Objects::nonNull)
				.map(invoices -> Integer.valueOf(invoices.getInvoiceno())).collect(Collectors.toList());
		List<MiscBillingInvLineitemEntity> miscBillingLineItemEntityList = miscBillingInvLineitemDataRepository.findAllById(alInvoices);
		if(miscBillingLineItemEntityList != null && !miscBillingLineItemEntityList.isEmpty()){
			alMiscBill = miscBillingLineItemEntityList.stream().filter(Objects::nonNull).map(miscBillingInvLineitemEntity -> {
				miscBillingInvLineitemEntity.setProcessStatus(statusRequest.getStatus());
				return miscBillingInvLineitemEntity;
			}).collect(Collectors.toList());
			alMiscBill = miscBillingInvLineitemDataRepository.saveAll(alMiscBill);
			statusRequest.setInvoices(alMiscBill.stream().map(miscBillingInvLineitemEntity -> {
				Invoices invoices = new Invoices();
				invoices.setInvoiceno(String.valueOf(miscBillingInvLineitemEntity.getInvLineItemId()));
				invoices.setStatus(miscBillingInvLineitemEntity.getProcessStatus());
				return invoices;
			}).collect(Collectors.toList()));
		}
	}

	private void fetchInvoice(StatusRequest statusRequest) {
		List<MiscBillingTrnInvoiceEntity> alMiscBill;
		List<String> alInvoices = statusRequest.getInvoices().stream().filter(Objects::nonNull)
				.map(Invoices::getInvoiceno).collect(Collectors.toList());
		List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntityList = miscBillingInvoiceRepository.findAllById(alInvoices);
		if(miscBillingTrnInvoiceEntityList != null && !miscBillingTrnInvoiceEntityList.isEmpty()){
			alMiscBill = miscBillingTrnInvoiceEntityList.stream().filter(Objects::nonNull).map(miscBillingTrnInvoiceEntity -> {
				miscBillingTrnInvoiceEntity.setInvoiceStatus(statusRequest.getStatus());
				return miscBillingTrnInvoiceEntity;
			}).collect(Collectors.toList());
			alMiscBill = miscBillingInvoiceRepository.saveAll(alMiscBill);
			statusRequest.setInvoices(alMiscBill.stream().map(miscBillingTrnInvoiceEntity -> {
				Invoices invoices = new Invoices();
				invoices.setInvoiceno(miscBillingTrnInvoiceEntity.getInvoiceUrn());
				invoices.setStatus(miscBillingTrnInvoiceEntity.getInvoiceStatus());
				return invoices;
			}).collect(Collectors.toList()));
		}

	}

	@Override
	public MiscBillingTrnInvoiceEntity updateInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity) {
		return miscBillingInvoiceRepository.save(miscBillingTrnInvoiceEntity);
	}

	@Override
	public List<MiscBillingTrnInvoiceEntity> processInvoices(String billingMonth, Integer billingPeriod, String clientId) {
		return invoiceRepository.findAllByBillingMonthAndPeriodAndStatus(billingMonth, billingPeriod, clientId);
	}

	@Override
	public String getMaxInvoiceNo(String clientId, String fy, String carrierCode) {
		return invoiceRepository.getMaxInvoiceNo(clientId, new StringBuffer("M").append(carrierCode).append(fy).toString());
	}

	@Override
	public List<MiscBillingTrnInvoiceEntity> getRejectedInvoice(Optional<List<String>> invoiceUrns) {
		return miscBillingInvoiceRepository.findAll(MiscBillingTrnInvoiceEntitySpec.getRejectedInvoice(invoiceUrns));
	}

	@Override
	public List<MiscBillingTrnInvoiceEntity> captureInvoices(
			List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntity) {
		return miscBillingInvoiceRepository.saveAll(miscBillingTrnInvoiceEntity);
	}
	
	public void updateRejectedInvoice(String moInvice, String miInvoice) {
			CriteriaBuilder criteriaBuilder = this.em.getCriteriaBuilder();
			CriteriaUpdate<MiscBillingTrnInvoiceEntity> update = criteriaBuilder.createCriteriaUpdate(MiscBillingTrnInvoiceEntity.class);
			Root<MiscBillingTrnInvoiceEntity> entity = update.from(MiscBillingTrnInvoiceEntity.class);
			update.set("rejInvoiceNo", moInvice);
			update.where(criteriaBuilder.equal(entity.get("invoiceUrn"), miInvoice));
			this.em.createQuery(update).executeUpdate();
	}
}

