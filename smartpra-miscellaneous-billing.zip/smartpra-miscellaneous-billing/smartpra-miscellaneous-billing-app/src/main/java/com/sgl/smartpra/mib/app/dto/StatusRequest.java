package com.sgl.smartpra.mib.app.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class StatusRequest implements Serializable {
    private String status;
    private List<Invoices> invoices;
}
