package com.sgl.smartpra.mib.app.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

@Repository
public interface MiscBillingRepository extends JpaRepository<MiscBillingTrnInvoiceEntity, String> , JpaSpecificationExecutor<MiscBillingTrnInvoiceEntity> {

    List<MiscBillingTrnInvoiceEntity> findByInvoiceUrnIn(List<String> invoiceList);
    
    @Query(value = "select invoiceUrn, max(createdDate) as createdDate from MiscBillingTrnInvoiceEntity where invoiceUrn like 'MI%' group by invoiceUrn order by createdDate desc")
	public Object[] findBySpecificId();
    
    @Query(value = "select invoiceUrn, max(createdDate) as createdDate from MiscBillingTrnInvoiceEntity where invoiceUrn like 'MO%' group by invoiceUrn order by createdDate desc")
   	public Object[] findBySpecificMoId();

    @Query(value = "select misc from MiscBillingTrnInvoiceEntity misc where (misc.inwardOutwardFlag =  'I' and misc.invoiceStatus in (:status)) or (misc.inwardOutwardFlag =  'O' and misc.invoiceStatus in (:oStatus)) order by lastModifiedDate desc")
    public List<MiscBillingTrnInvoiceEntity> finadAllByInvoiceStatusOrderByLastUpdatedDateAsc(@Param("status") List<String> status,@Param("oStatus") List<String> oStatus);

    @Query(value = "select misc from MiscBillingTrnInvoiceEntity misc where misc.invoiceNumber = :invoiceNum ")
    Optional<MiscBillingTrnInvoiceEntity> findByInvoiceNum(@Param("invoiceNum") String invoiceNum);
}
