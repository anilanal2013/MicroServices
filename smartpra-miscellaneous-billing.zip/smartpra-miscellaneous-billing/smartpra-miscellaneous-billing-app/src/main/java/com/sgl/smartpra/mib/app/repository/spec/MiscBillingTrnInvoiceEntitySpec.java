package com.sgl.smartpra.mib.app.repository.spec;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.mib.app.utility.MiscBillingUtil;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.utils.MiscBillingCommonUtil;
import com.sgl.smartpra.mib.utils.MiscBillingConstants;

public class MiscBillingTrnInvoiceEntitySpec {
	
	private MiscBillingTrnInvoiceEntitySpec() {}

    public static Specification<MiscBillingTrnInvoiceEntity> search(Optional<String> supplierType,Optional<String> supplierCode,
                                                                    Optional<String> supplierName,Optional<String> billingType,
                                                                    Optional<String> status, Optional<String> settlementInd,
                                                                    Optional<String> locationCode,Optional<String> chargeCat,
                                                                    Optional<String> invoiceCurrency,
                                                                    Optional<String> billingPeriodAsOnMonth,Optional<Integer> billingPeriodAsOn,
                                                                    Optional<String> billingPeriodFromMonth,Optional<Integer> billingPeriodFrom, 
                                                                    Optional<String> billingPeriodToMonth,Optional<Integer> billingPeriodTo) {
        return (miscBillingTrnInvoiceEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if(OptionalUtil.isPresent(billingType) && !StringUtils.equalsIgnoreCase("A",OptionalUtil.getValue(billingType))){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.INWARD_OUTWARD_FLAG),OptionalUtil.getValue(billingType)));
            }

            if(OptionalUtil.isPresent(supplierType)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SUPPLIER_TYPE),OptionalUtil.getValue(supplierType)));
            }

            if(OptionalUtil.isPresent(supplierCode)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SELLER_ORG_ID),OptionalUtil.getValue(supplierCode)));
            }
            
            if(OptionalUtil.isPresent(supplierName)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SUPPLIER_NAME),OptionalUtil.getValue(supplierName)));
            }

            if(OptionalUtil.isPresent(status) && !(StringUtils.equalsIgnoreCase("ALL",OptionalUtil.getValue(status)))){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.INVOICE_STATUS),OptionalUtil.getValue(status)));
            }

            if(OptionalUtil.isPresent(locationCode)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("locationCode"),OptionalUtil.getValue(locationCode)));
            }
            if(OptionalUtil.isPresent(settlementInd)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("settlementMethod"),OptionalUtil.getValue(settlementInd)));
            }
            if(OptionalUtil.isPresent(chargeCat)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("chargeCategoryCode"),OptionalUtil.getValue(chargeCat)));
            }
            if(OptionalUtil.isPresent(invoiceCurrency)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("currencyCode"),OptionalUtil.getValue(invoiceCurrency)));
            }

            if(OptionalUtil.isPresent(billingPeriodAsOnMonth) && OptionalUtil.isPresent(billingPeriodAsOn)){
            	String settlementMonthPeriod = MiscBillingUtil.convertToSettlementMonthPeriod(billingPeriodAsOnMonth.get(), billingPeriodAsOn.get());
            	predicates.add(criteriaBuilder.lessThanOrEqualTo(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SETTLEMENT_MONTH_PERIOD), settlementMonthPeriod));
            } else {
            	if(OptionalUtil.isPresent(billingPeriodFromMonth) && OptionalUtil.isPresent(billingPeriodFrom)
            		&& OptionalUtil.isPresent(billingPeriodToMonth) && OptionalUtil.isPresent(billingPeriodTo)) {
            		String fromSMP = MiscBillingUtil.convertToSettlementMonthPeriod(billingPeriodFromMonth.get(), billingPeriodFrom.get());
            		String toSMP = MiscBillingUtil.convertToSettlementMonthPeriod(billingPeriodToMonth.get(), billingPeriodTo.get());
            		predicates.add(criteriaBuilder.greaterThanOrEqualTo(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SETTLEMENT_MONTH_PERIOD), fromSMP));
            		predicates.add(criteriaBuilder.lessThanOrEqualTo(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SETTLEMENT_MONTH_PERIOD), toSMP));
            	}
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
        };

    }


    public static Specification<MiscBillingTrnInvoiceEntity> searchInvoiceDetails(Optional<String> billingPeriodAsOn, Optional<Integer> billingPeriodAsOnMonth, Optional<String> supplierCode, Optional<String> billingType) {
        return (miscBillingTrnInvoiceEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if(OptionalUtil.isPresent(billingPeriodAsOn)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("billingMonth"),OptionalUtil.getValue(billingPeriodAsOn)));
            }

            if(OptionalUtil.isPresent(billingPeriodAsOnMonth)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("billingPeriod"),OptionalUtil.getValue(billingPeriodAsOnMonth)));
            }

            if(OptionalUtil.isPresent(billingType) ){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.INWARD_OUTWARD_FLAG),OptionalUtil.getValue(billingType)));
            }

            if(OptionalUtil.isPresent(supplierCode)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SELLER_ORG_ID),OptionalUtil.getValue(supplierCode)));
            }
            
            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
        };
    }
    
    public static Specification<MiscBillingTrnInvoiceEntity> getAllInvoices(Optional<String> billingType, Optional<String> supplierType,
			Optional<String> supplierCode, Optional<String> supplierName, Optional<String> billingPeriodMonth,
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber) {
        return (miscBillingTrnInvoiceEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if(OptionalUtil.isPresent(billingType) && !StringUtils.equalsIgnoreCase("A",OptionalUtil.getValue(billingType))){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.INWARD_OUTWARD_FLAG),OptionalUtil.getValue(billingType)));
            }

            if(OptionalUtil.isPresent(supplierType)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SUPPLIER_TYPE),OptionalUtil.getValue(supplierType)));
            }

            if(OptionalUtil.isPresent(supplierCode) ){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("sellerOrganizationId"),OptionalUtil.getValue(supplierCode)));
            }
            
            if(OptionalUtil.isPresent(supplierName)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SUPPLIER_NAME),OptionalUtil.getValue(supplierName)));
            }
            
            if(OptionalUtil.isPresent(billingPeriodMonth) && OptionalUtil.isPresent(billingPeriod)){
            	String settlementMonthPeriod = MiscBillingUtil.convertToSettlementMonthPeriod(billingPeriodMonth.get(), billingPeriod.get());
            	predicates.add(criteriaBuilder.lessThanOrEqualTo(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SETTLEMENT_MONTH_PERIOD), settlementMonthPeriod));
            }
            
            if(OptionalUtil.isPresent(invoiceNumber)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.INVOICE_NUMBER),OptionalUtil.getValue(invoiceNumber)));
            }
            
            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
        };
    }
    
    public static Specification<MiscBillingTrnInvoiceEntity> getOutwardInvoicesByBillingMonth(String clientId, String billingMonth, 
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber, Optional<String> carrierCode,
			Optional<String> supplierType) {
        return (miscBillingTrnInvoiceEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("clientId"), clientId));
            predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("billingMonth"), billingMonth));
            predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.INWARD_OUTWARD_FLAG), "O"));
            
            if(OptionalUtil.isPresent(billingPeriod)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("billingPeriod"),OptionalUtil.getValue(billingPeriod)));
            }
            
            if(OptionalUtil.isPresent(invoiceNumber)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("invoiceNumber"),OptionalUtil.getValue(invoiceNumber)));
            }
            
            if(OptionalUtil.isPresent(carrierCode)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("buyerOrganizationId"),OptionalUtil.getValue(carrierCode)));
            }
            
            if(OptionalUtil.isPresent(supplierType)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("supplierType"),OptionalUtil.getValue(supplierType)));
            }
            
            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
        };
    }
    
    public static Specification<MiscBillingTrnInvoiceEntity> getAllInvoicesForEvaluation(Optional<String> status, Optional<String> billingType,
			Optional<String> billingPeriodMonth, Optional<Integer> billingPeriod,
			Optional<String> billingPeriodFromMonth, Optional<Integer> billingPeriodFrom,
			Optional<String> billingPeriodToMonth, Optional<Integer> billingPeriodTo, Optional<String> supplierType,
			Optional<String> supplierCode, Optional<String> supplierName, Optional<String> chargeCategoryCode,
			Optional<String> invoiceNumber) {
        return (miscBillingTrnInvoiceEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if(OptionalUtil.isPresent(status)){
                if("ALL".equalsIgnoreCase(OptionalUtil.getValue(status))) {
                	Predicate predicateForOP = criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.INVOICE_STATUS), "OP");
                	Predicate predicateForEV = criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.INVOICE_STATUS), "EV");
                	Predicate predicateForNE = criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.INVOICE_STATUS), "NE");
                	predicates.add(criteriaBuilder.or(predicateForOP, predicateForEV, predicateForNE));
                } else {
                	predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("invoiceStatus"),OptionalUtil.getValue(status)));
                }
            }
            
            if(OptionalUtil.isPresent(billingType) && !StringUtils.equalsIgnoreCase("A",OptionalUtil.getValue(billingType))){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("inwardOutwardFlag"),OptionalUtil.getValue(billingType)));
            }
            
            if(OptionalUtil.isPresent(billingPeriodMonth) && OptionalUtil.isPresent(billingPeriod)){
            	String settlementMonthPeriod = MiscBillingUtil.convertToSettlementMonthPeriod(billingPeriodMonth.get(), billingPeriod.get());
            	predicates.add(criteriaBuilder.lessThanOrEqualTo(miscBillingTrnInvoiceEntity.get(MiscBillingConstants.SETTLEMENT_MONTH_PERIOD), settlementMonthPeriod));
            }

            if(OptionalUtil.isPresent(billingPeriodFromMonth) && OptionalUtil.isPresent(billingPeriodFrom) 
            		&& OptionalUtil.isPresent(billingPeriodToMonth) && OptionalUtil.isPresent(billingPeriodTo)){
            	String settlementMonthPeriodFrom = MiscBillingUtil.convertToSettlementMonthPeriod(billingPeriodFromMonth.get(), billingPeriodFrom.get());
            	String settlementMonthPeriodTo = MiscBillingUtil.convertToSettlementMonthPeriod(billingPeriodToMonth.get(), billingPeriodTo.get());
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(miscBillingTrnInvoiceEntity.get("settlementMonthPeriod"), settlementMonthPeriodFrom));
                predicates.add(criteriaBuilder.lessThanOrEqualTo(miscBillingTrnInvoiceEntity.get("settlementMonthPeriod"), settlementMonthPeriodTo));
            }
            if(OptionalUtil.isPresent(supplierType)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("supplierType"),OptionalUtil.getValue(supplierType)));
            }

            if(OptionalUtil.isPresent(supplierCode) ){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("sellerOrganizationId"),OptionalUtil.getValue(supplierCode)));
            }
            
            if(OptionalUtil.isPresent(supplierName) ){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("supplierName"),OptionalUtil.getValue(supplierName)));
            }
            
            if(OptionalUtil.isPresent(chargeCategoryCode)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("chargeCategoryCode"),OptionalUtil.getValue(chargeCategoryCode)));
            }
            
            if(OptionalUtil.isPresent(invoiceNumber)){
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("invoiceNumber"),OptionalUtil.getValue(invoiceNumber)));
            }
            
            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
        };
    }
    
    public static Specification<MiscBillingInvLineitemEntity> getLineItemList(Optional<String> invoiceUrn) {
    	return (miscBillingInvLineitemEntity, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if(OptionalUtil.isPresent(invoiceUrn)){
                predicates.add(criteriaBuilder.equal(miscBillingInvLineitemEntity.join("miscBillingTrnInvoice").get("invoiceUrn"),OptionalUtil.getValue(invoiceUrn)));
            }
            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
    	};
    }
    
	public static Specification<MiscBillingTrnInvoiceEntity> getRejectedInvoice(Optional<List<String>> invoiceUrns) {
		return (miscBillingTrnInvoiceEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if(OptionalUtil.isPresent(invoiceUrns) && CollectionUtils.isNotEmpty(invoiceUrns.get())) {
				predicates.add(miscBillingTrnInvoiceEntity.get("invoiceUrn").in(invoiceUrns.get()));
			}
			predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("inwardOutwardFlag"),"I"));
			predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("invoiceStatus"),"CO"));//change to CO after testing
			predicates.add(criteriaBuilder.gt(miscBillingTrnInvoiceEntity.get("netAmountRejected"), BigDecimal.ZERO));
			predicates.add(criteriaBuilder.isNull(miscBillingTrnInvoiceEntity.get("rejInvoiceNo")));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	   public static Specification<MiscBillingTrnInvoiceEntity> getInvoicesForAutoEvaluation(String status, String billingType,
				String invoiceDate, String chargeCategoryCode, String supplierCode, String billingMonth,
				Integer billingPeriod, String clientId) {
	        return (miscBillingTrnInvoiceEntity, criteriaQuery, criteriaBuilder) -> {
	            List<Predicate> predicates = new ArrayList<>();

	            predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("invoiceStatus"), status));
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("inwardOutwardFlag"), billingType));
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("invoiceDate"), MiscBillingCommonUtil.convertStringToDate("yyyy-MM-dd", invoiceDate)));
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("chargeCategoryCode"), chargeCategoryCode));
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("sellerOrganizationId"), supplierCode));
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("billingMonth"), billingMonth));
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("billingPeriod"), billingPeriod));
                predicates.add(criteriaBuilder.equal(miscBillingTrnInvoiceEntity.get("clientId"), clientId));
                
	            return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
	        };
	    }
}
