package com.sgl.smartpra.mib.app.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.sgl.smartpra.accounting.model.AccountResponse;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mib.app.config.FeignConfiguration;
import com.sgl.smartpra.mib.app.mapper.InvoiceEvaluationMapper;
import com.sgl.smartpra.mib.app.repository.MiscBillingRepository;
import com.sgl.smartpra.mib.app.utility.MiscBillingUtil;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.repository.MiscBillingInvTransHeaderDataRepository;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ScheduleAccountServiceImpl {

    public static final String STATUS = "200";
    public static final String INVOICE_STATUS_ACCOUNT = "AA";
    public static final String INVOICE_STATUS_ACCOUNT_ERROR = "EA";
    public static final String SYSTEM = "System";
    public static final List<String> al = Arrays.asList("I","A");
    public static final String MISC_1126 = "MISC1126";
    public static final String MISC_1125 = "MISC1125";
    public static final String MISC_9002 = "MISC9002";
    private static final String BKR = "BKR";

    @Autowired
    @Qualifier(value = "threadExc")
    private ThreadPoolTaskScheduler threadPoolTaskScheduler;

    @Autowired
    private MiscBillingRepository miscBillingRepository;

    @Autowired
    private InvoiceEvaluationMapper invoiceEvaluationMapper;

    @Autowired
    FeignConfiguration.AccountingServiceFeignClient accountingServiceFeignClient;

    @Autowired
    FeignConfiguration.ExchangeRateFeignClient exchangeRateFeignClient;

    @Autowired
    MiscBillingUtil miscBillingUtil;

    final static ObjectMapper objectMapper = new ObjectMapper().registerModule(new Jdk8Module());


    final List<String> alStatus = Arrays.asList("CO");
	
	final List<String> alStatusOut = Arrays.asList("BI");


    @Scheduled(fixedDelayString = "${schedule.fixedDelay:5000}")
    public void setAccountServices() throws Exception {
       final List<MiscBillingTrnInvoiceEntity> alMiscBillingTrnInvoiceEntities = miscBillingRepository.finadAllByInvoiceStatusOrderByLastUpdatedDateAsc(alStatus,alStatusOut);
//       log.info("size of  alMiscBillingTrnInvoiceEntities "+alMiscBillingTrnInvoiceEntities.size());
//	   log.info("size of  alMiscBillingTrnInvoiceEntities "+alMiscBillingTrnInvoiceEntities);
       List<MiscBillingTrnInvoiceEntity> alMiscBillingTrnInvoiceEntity =  alMiscBillingTrnInvoiceEntities.stream().filter(Objects::nonNull).limit(Integer.parseInt("50")).map(miscBillingTrnInvoiceEntity -> {
           miscBillingTrnInvoiceEntity.setInvoiceStatus("SA");
           return miscBillingTrnInvoiceEntity;
       } ).collect(Collectors.toList());
       if (alMiscBillingTrnInvoiceEntity != null && !alMiscBillingTrnInvoiceEntity.isEmpty()) {
           alMiscBillingTrnInvoiceEntity = miscBillingRepository.saveAll(alMiscBillingTrnInvoiceEntity);
           final List<MiscBillingTrnInvoice> miscBillingTrnInvoices = invoiceEvaluationMapper.mapToMiscBillingTrnInvoice(alMiscBillingTrnInvoiceEntity);

           miscBillingTrnInvoices.parallelStream().forEach(miscBillingTrnInvoice -> {
               try {
                   AccountingTransaction accountingTransaction = setAccountingTransaction(miscBillingTrnInvoice,"T",Optional.ofNullable(miscBillingTrnInvoice.getInvoiceUrn()));
                   AccountResponse accountResponse = callAccounts(accountingTransaction,miscBillingTrnInvoice);
                   if ( StringUtils.equalsIgnoreCase("O",miscBillingTrnInvoice.getInwardOutwardFlag()) || !al.contains(miscBillingTrnInvoice.getSettlementMethod())){
                       accountingTransaction = setAccountingTransaction(miscBillingTrnInvoice,"I",Optional.of(miscBillingTrnInvoice.getInvoiceNumber()));
                       accountResponse = callAccounts(accountingTransaction,miscBillingTrnInvoice);
                   }
               } catch (Exception e) {
                   log.error(e.getMessage());
               }
           });
       }


    }

    private AccountResponse callAccounts(AccountingTransaction accountingTransaction, MiscBillingTrnInvoice miscBillingTrnInvoice) {
        AccountResponse accountResponse = accountingServiceFeignClient.getAttributeDetails(accountingTransaction);
        if (accountResponse != null) {
        	log.debug(accountResponse.toString());
            if (StringUtils.equalsIgnoreCase(accountResponse.getStatus(), STATUS)) {
                saveMiscBillTxn(accountResponse,INVOICE_STATUS_ACCOUNT);
            } else if (StringUtils.isBlank(accountResponse.getJvReferenceNum())) {
                log.error(accountResponse.getErrorCode());
                try {
                    Map<String,String> m = null;
                    if(StringUtils.equalsIgnoreCase(accountResponse.getErrorCode(), MISC_1126)){
                        m = new HashMap<>();
                        m.put("Element Name",miscBillingTrnInvoice.getSellerOrganizationId());
                        m.put("Invoice No.",miscBillingTrnInvoice.getInvoiceNumber());
                        m.put("Charge Code",miscBillingTrnInvoice.getChargeCategoryCode());
                    } else if (StringUtils.equalsIgnoreCase(accountResponse.getErrorCode(),MISC_9002)) {
                        m = new HashMap<>();
                        m.put("From Currency",miscBillingTrnInvoice.getCurrencyCode());
                        m.put("To Currency",miscBillingTrnInvoice.getBaseCurrency());
                        m.put("Date",String.valueOf(miscBillingTrnInvoice.getInvoiceDate()));
                        m.put("Rate Type",BKR);
                    }
                    saveMiscBillTxn(accountResponse,INVOICE_STATUS_ACCOUNT_ERROR);
                    ExceptionTransactionModel exceptionTransactionModel =   miscBillingUtil.prepareExceptionTransactionModel(accountResponse.getErrorCode(),m,miscBillingTrnInvoice.getClientId()
                    ,null,miscBillingTrnInvoice);
                    exchangeRateFeignClient.initExceptionTrasaction(exceptionTransactionModel);
                    // Call the client exce
                } catch (Exception e){
                    log.error("Exce : "+e);
                }
            }
        }
        return accountResponse;
    }

    private AccountingTransaction setAccountingTransaction(MiscBillingTrnInvoice miscBillingTrnInvoice, String invoiceLevel,Optional<String> invoiceNo) throws JsonProcessingException {
        AccountingTransaction accountingTransaction = new AccountingTransaction();
        accountingTransaction.setModule("M");
        accountingTransaction.setInvoiceNo(invoiceNo);
        accountingTransaction.setClientId(Optional.of(miscBillingTrnInvoice.getClientId()));
        accountingTransaction.setDateOfIssue(miscBillingTrnInvoice.getInvoiceDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        if(StringUtils.equalsIgnoreCase("I", miscBillingTrnInvoice.getSettlementMethod()) || StringUtils.equalsIgnoreCase("A", miscBillingTrnInvoice.getSettlementMethod())) {
        	miscBillingTrnInvoice.setSettlementMethod("I");
        }else{
        	miscBillingTrnInvoice.setSettlementMethod("D");
        }
        accountingTransaction.setRequest(Optional.of(objectMapper.writeValueAsString(miscBillingTrnInvoice)));
        accountingTransaction.setTransIssAirline(Optional.of(miscBillingTrnInvoice.getSellerOrganizationId()));
        accountingTransaction.setCreatedBy(Optional.of(SYSTEM));
        accountingTransaction.setCreatedDate(LocalDateTime.now());
        accountingTransaction.setInvoiceLevel(invoiceLevel);
        return accountingTransaction;
    }

    private void saveMiscBillTxn(AccountResponse accountResponse,final String status) {
        Optional<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntity = miscBillingRepository.findById(accountResponse.getTxn());
        if (OptionalUtil.isEmpty(miscBillingTrnInvoiceEntity)){
            miscBillingTrnInvoiceEntity = miscBillingRepository.findByInvoiceNum(accountResponse.getTxn());
        }

        if (OptionalUtil.isPresent(miscBillingTrnInvoiceEntity)){
           MiscBillingTrnInvoiceEntity misc = OptionalUtil.getValue(miscBillingTrnInvoiceEntity) ;
           String value = accountResponse.getJvReferenceNum();
           if (StringUtils.isNotBlank(misc.getJvReferenceNumber())&& StringUtils.isNotBlank(value)){
               value = StringUtils.join(misc.getJvReferenceNumber(),",", value );
           }
		   if(StringUtils.isNotBlank(value)){
			   misc.setJvReferenceNumber(value);
		   }
         misc.setInvoiceStatus(status);
         miscBillingRepository.save(misc);
        }
    }

    public void setMiscBillingRepository(MiscBillingRepository miscBillingRepository) {
        this.miscBillingRepository = miscBillingRepository;
    }

    public void setInvoiceEvaluationMapper(InvoiceEvaluationMapper invoiceEvaluationMapper) {
        this.invoiceEvaluationMapper = invoiceEvaluationMapper;
    }

    public void setAccountingServiceFeignClient(FeignConfiguration.AccountingServiceFeignClient accountingServiceFeignClient) {
        this.accountingServiceFeignClient = accountingServiceFeignClient;
    }

    public void setExchangeRateFeignClient(FeignConfiguration.ExchangeRateFeignClient exchangeRateFeignClient) {
        this.exchangeRateFeignClient = exchangeRateFeignClient;
    }

    public void setMiscBillingUtil(MiscBillingUtil miscBillingUtil) {
        this.miscBillingUtil = miscBillingUtil;
    }
}
