package com.sgl.smartpra.mib.app.config;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.accounting.model.AccountResponse;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.ChargeCategory;
import com.sgl.smartpra.integration.model.CurrencyRateIn;
import com.sgl.smartpra.integration.model.CurrencyRateOut;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.master.model.RateAndAgreementModel;
import com.sgl.smartpra.master.model.SystemParameter;


@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-global-master-app")
	public interface GlobalMasterFeignClient {

		@GetMapping("/charge-categories")
		public List<ChargeCategory> getAllChargeCategory(
				@RequestParam(value = "chargeCategoryCode", required = false) Optional<String> chargeCategoryCode,
				@RequestParam(value = "chargeCategoryName", required = false) Optional<String> chargeCategoryName,
				@RequestParam(value = "activate", required = false) Optional<Boolean> activate);
		
		@GetMapping("/carriers/{carrierCode}")
		public Carrier getCarrierByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode);
	}

	@FeignClient(value = "smartpra-master-app")
	public interface MasterFeignClient {

		@GetMapping("/billing-period/billing-month-periods/{billingMonth}/{billingPeriod}")
		public List<OutwardBillingPeriods> getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriod(
				@PathVariable(value = "billingMonth", required = true) String billingMonth,
				@PathVariable(value = "billingPeriod", required = true) Integer billingPeriod);

		@GetMapping("/billing-period/current-open")
		public OutwardBillingPeriods getCurrentOpenOutwardBillingPeriods(
				@RequestParam(value = "clientId", required = false) String clientId);

		@GetMapping("/financial-month/current-open")
		public FinancialMonthModel getCurrentOpenFinancialMonthForFinancialCalendar(
				@RequestParam(value = "clientId", required = false) String clientId);

		@GetMapping("/billing-period/start-date/{billingMonth}/{billingPeriod}")
		public Date getOutwardBillingPeriodsStartDate(@PathVariable(value = "billingMonth") String billingMonth,
				@PathVariable(value = "billingPeriod") Integer billingPeriod);

		@GetMapping("/billing-period/end-date/{billingMonth}/{billingPeriod}")
		public Date getOutwardBillingPeriodsEndDate(@PathVariable(value = "billingMonth") String billingMonth,
				@PathVariable(value = "billingPeriod") Integer billingPeriod);
		
		@GetMapping("/system-parameters-with-date/clientId/{clientId}/parameterName/{parameterName}")
		public SystemParameter getSystemParameterByparameterNameAndClientId(
				@PathVariable(value = "parameterName") String parameterName,
				@PathVariable(value = "clientId") String clientId);
		
	    @GetMapping("/rate-agreement")
	    public List<RateAndAgreementModel> fetchRateAndAgreement(
	            @RequestParam(name = "supplierCode", required = true) String supplierCode,
	            @RequestParam(name = "baseLocation", required = true) String baseLocation,
	            @RequestParam(name = "chargeCategory", required = true) String chargeCategory,
	            @RequestParam(name = "chargeCode", required = false) String chargeCode,
	            @RequestParam(name = "effectivePeriod", required = false) String effectivePeriodFrom,
	            @RequestParam(name = "effectivePeriod", required = false) String effectivePeriodTo,
	            @RequestParam(name = "airport", required = false) String airport);
	}

	@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface ExchangeRateFeignClient {
		@PostMapping("/integ/erd")
		public CurrencyRateOut getExchangeRate(@Validated @RequestBody CurrencyRateIn currencyRateIn);
		
		@PostMapping("/api/init-exceptionmessage")
		public void initExceptionTrasaction(@RequestBody ExceptionTransactionModel exceptionTransactionModel);
	}

	@FeignClient(value = "smartpra-accounting-app")
	public interface AccountingServiceFeignClient{
		@PostMapping("/accounting-misc/get-accounting-details")
		public AccountResponse getAttributeDetails(
				@RequestBody AccountingTransaction accountingTransaction);
	}
}
