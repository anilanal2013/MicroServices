package com.sgl.smartpra.mib.app.service;

import com.sgl.smartpra.mib.app.dto.InvoiceOperational;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

import java.util.List;
import java.util.Optional;

public interface MiscBillingService {

    List<InvoiceOperational> fetchInvoice(Optional<String> billingPeriodAsOnMonth,
    									  Optional<Integer> billingPeriodAsOn,
                                          Optional<String> billingPeriodFromMonth,
                                          Optional<Integer> billingPeriodFrom,
                                          Optional<String> billingPeriodToMonth,
                                          Optional<Integer> billingPeriodTo,
                                          Optional<String> supplierType, Optional<String> supplierCode,
                                          Optional<String> supplierName, Optional<String> billingType,
                                          Optional<String> status,
                                          Optional<String> settlementInd, Optional<String> locationCode,
                                          Optional<String> chargeCat, Optional<String> invoiceCurrency
                                             );

    List<MiscBillingTrnInvoice> fetchInvoiceDetails(Optional<String> billingPeriodAsOn,
                                                    Optional<Integer> billingPeriodAsOnMonth,
                                                    Optional<String> supplierCode, Optional<String> billingType);

    List<MiscBillingTrnInvoice> fetchInvoiceDetails(List<String> invoiceList);


}
