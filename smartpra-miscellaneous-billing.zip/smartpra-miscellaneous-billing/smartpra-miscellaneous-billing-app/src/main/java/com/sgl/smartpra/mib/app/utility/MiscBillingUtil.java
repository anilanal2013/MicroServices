package com.sgl.smartpra.mib.app.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MiscBillingUtil {


	private MiscBillingUtil() {}

	public static final String CREATEDBY = "MISC_BLNG_BATCH";
	public static final String UPDATEDBY = "MISC_BLNG_BATCH";

	public ExceptionTransactionModel prepareExceptionTransactionModel(String exceptionCode, Map<String,String> paremNameValueMap, String clientId, Integer fileId, MiscBillingTrnInvoice miscBillingTrnInvoice) {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setExceptionCode(exceptionCode);
		exceptionTransactionModel.setCreatedBy(CREATEDBY);
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setClientId(clientId);
		exceptionTransactionModel.setEnvironment("P"); //production data.
		if(fileId != null) {
			exceptionTransactionModel.setFileId(Long.valueOf(fileId));
		}
		if(StringUtils.isNotBlank(miscBillingTrnInvoice.getSellerOrganizationId() ) ) {

				exceptionTransactionModel.setBatchKey1(miscBillingTrnInvoice.getSellerOrganizationId());

		}
		exceptionTransactionModel.setBatchKey2(miscBillingTrnInvoice.getSellerOrganizationId());
		exceptionTransactionModel.setBatchKey3(miscBillingTrnInvoice.getChargeCategoryCode());
		exceptionTransactionModel.setBatchKey4(miscBillingTrnInvoice.getInvoiceNumber());
		exceptionTransactionModel.setInvoiceUrn(miscBillingTrnInvoice.getInvoiceUrn());
		try {
			LocalDate invoiceDate = miscBillingTrnInvoice.getInvoiceDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			LocalDateTime invoiceDateLT = (invoiceDate != null) ? invoiceDate.atTime(LocalTime.now()) : null;
			exceptionTransactionModel.setBatchKey5(invoiceDateLT);
		} catch (Exception e) {
			log.error("prepareExceptionTransactionModel : " +e.getMessage());
		}
		
		List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
		if (paremNameValueMap != null) {
			paremNameValueMap.forEach((key, value) -> {
				final ExceptionParametersValueModel parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName(key);
				parametersValueModel.setParameterValue(value);
				parametersValueModelList.add(parametersValueModel);
			});
		}

		exceptionTransactionModel.setParametersValueList(parametersValueModelList);

		return exceptionTransactionModel;
	}
	
	public ExceptionTransactionModel prepareExceptionTransactionModel(String exceptionCode, Map<String,String> paremNameValueMap, String clientId, Integer fileId, MiscBillingTrnInvoiceEntity entity) {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setExceptionCode(exceptionCode);
		exceptionTransactionModel.setCreatedBy(CREATEDBY);
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setClientId(clientId);
		exceptionTransactionModel.setEnvironment("P"); //production data.
		if(fileId != null) {
			exceptionTransactionModel.setFileId(Long.valueOf(fileId));
		}
		if(StringUtils.isNotBlank(entity.getSellerOrganizationId() ) ) {

				exceptionTransactionModel.setBatchKey1(entity.getSellerOrganizationId());

		}
		exceptionTransactionModel.setBatchKey2(entity.getSellerOrganizationId());
		exceptionTransactionModel.setBatchKey3(entity.getChargeCategoryCode());
		exceptionTransactionModel.setBatchKey4(entity.getInvoiceNumber());
		exceptionTransactionModel.setInvoiceUrn(entity.getInvoiceUrn());
		try {
			LocalDate invoiceDate = entity.getInvoiceDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			LocalDateTime invoiceDateLT = (invoiceDate != null) ? invoiceDate.atTime(LocalTime.now()) : null;
			exceptionTransactionModel.setBatchKey5(invoiceDateLT);
		} catch (Exception e) {
			log.error("prepareExceptionTransactionModel-with entity : " +e.getMessage());
		}
		
		List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>() ;
		if (paremNameValueMap != null) {
			paremNameValueMap.forEach((key, value) -> {
				final ExceptionParametersValueModel parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName(key);
				parametersValueModel.setParameterValue(value);
				parametersValueModelList.add(parametersValueModel);
			});
			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
		}

		return exceptionTransactionModel;
	}
	
	public static Boolean isElementEmpty(String element){
        Boolean isEmpty = Boolean.FALSE;
        if(StringUtils.isEmpty(element)) {
        	isEmpty = Boolean.TRUE;
        } 
        return isEmpty;
    }	
	
	public static String dateToString(Date date) {
		String str = StringUtils.EMPTY;
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  
			str = dateFormat.format(date);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return str;
	}
	
	public static LocalDate stringToLocalDate(String str) {
		LocalDate localDate = null;
		if(StringUtils.isBlank(str)) return null;
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			localDate = LocalDate.parse(str, formatter);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return localDate;
	}
	
	public static String convertToSettlementMonthPeriod(String billingMonth, Integer billingPeriod) {
		String month = billingMonth.substring(0, 3);
		String year = billingMonth.substring(4);
		return year + getMonthInDigit(month.toUpperCase()) + "0" + billingPeriod;
	}
	
	public static String getMonthInDigit(String month) {

		String result = "";
		switch (month) {
	        case "JAN":
	        	result = "01"; 
	            break;
	        case "FEB":
	        	result = "02";
	            break;
	        case "MAR":
	        	result = "03";
	            break;
	        case "APR":
	            result = "04";
	            break;
	        case "MAY":
	            result = "05";
	            break;    
	        case "JUN":
	            result = "06";
	            break;
	        case "JUL":
	            result = "07";
	            break;    
	        case "AUG":
	            result = "08";
	            break;
	        case "SEP":
	            result = "09";
	            break;
	        case "OCT":
	            result = "10";
	            break;
	        case "NOV":
	            result = "11";
	            break;
	        case "DEC":
	            result = "12";
	            break;
	        default:
	        	result = "";
	            break;
    
		}
		return result;
	}
}
