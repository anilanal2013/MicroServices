package com.sgl.smartpra.mib.app.mapper;

import java.util.List;

import org.mapstruct.*;

import com.sgl.smartpra.mib.domain.MiscBillingInvLineitem;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface InvoiceEvaluationMapper {
	
	MiscBillingTrnInvoiceEntity mapToEntity(MiscBillingTrnInvoice miscBillingTrnInvoice);
	
	MiscBillingTrnInvoice mapToModel(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity);
	
	@IterableMapping(qualifiedByName="mapToMiscBillingTrnInvoice")
	List<MiscBillingTrnInvoice> mapToMiscBillingTrnInvoice(List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntity);

	@Named("mapToMiscBillingTrnInvoice")
	@Mapping(target="miscBillingInvLineitem" , ignore= true)
	@Mapping(target="miscBillingTaxDetails" , ignore= true)
	@Mapping(target="miscBillingAddOnChargeDtl" , ignore= true) 
	@Mapping(target="miscBillingInvAttachment" , ignore= true)
	MiscBillingTrnInvoice mapToMiscBillingTrnInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity);
	
	List<MiscBillingInvLineitem> mapToModel(List<MiscBillingInvLineitemEntity> miscBillingInvLineitemEntity);

	MiscBillingInvLineitem mapMiscBillingInvLineitemToModel(MiscBillingInvLineitemEntity miscBillingInvLineitemEntity);

	@Mapping(target="miscBillingTrnInvoice" , ignore=true)
	MiscBillingInvLineitemEntity mapMiscBillingInvLineitemEntityToEntity(MiscBillingInvLineitem miscBillingInvLineitem, @MappingTarget MiscBillingInvLineitemEntity miscBillingInvLineitemEntity);
}
