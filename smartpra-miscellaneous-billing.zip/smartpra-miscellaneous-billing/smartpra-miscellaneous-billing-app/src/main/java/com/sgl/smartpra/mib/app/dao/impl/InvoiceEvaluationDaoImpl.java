package com.sgl.smartpra.mib.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.mib.app.dao.InvoiceEvaluationDao;
import com.sgl.smartpra.mib.app.repository.MiscBillingInvLineItemRepository;
import com.sgl.smartpra.mib.app.repository.MiscBillingRepository;
import com.sgl.smartpra.mib.app.repository.spec.MiscBillingTrnInvoiceEntitySpec;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.repository.MiscBillingTrnInvoiceDataRepository;

@Component
public class InvoiceEvaluationDaoImpl implements InvoiceEvaluationDao {

	@Autowired
	MiscBillingRepository miscBillingRepository;
	
	@Autowired
	MiscBillingInvLineItemRepository miscBillingInvLineItemRepository;
	
	@Autowired
	MiscBillingTrnInvoiceDataRepository invoiceRepository;

	@Override
	public List<MiscBillingTrnInvoiceEntity> getAllInvoices(Optional<String> status, Optional<String> billingType,
			Optional<String> billingPeriodMonth, Optional<Integer> billingPeriod,
			Optional<String> billingPeriodFromMonth, Optional<Integer> billingPeriodFrom,
			Optional<String> billingPeriodToMonth, Optional<Integer> billingPeriodTo, Optional<String> supplierType,
			Optional<String> supplierCode, Optional<String> supplierName, Optional<String> chargeCategoryCode,
			Optional<String> invoiceNumber) {
		return miscBillingRepository.findAll(
				MiscBillingTrnInvoiceEntitySpec.getAllInvoicesForEvaluation(status, billingType, billingPeriodMonth,
						billingPeriod, billingPeriodFromMonth, billingPeriodFrom, billingPeriodToMonth, billingPeriodTo,
						supplierType, supplierCode, supplierName, chargeCategoryCode, invoiceNumber));
	}

	@Override
	public List<MiscBillingInvLineitemEntity> getLineItemList(Optional<String> invoiceUrn) {
		return miscBillingInvLineItemRepository.findAll(MiscBillingTrnInvoiceEntitySpec.getLineItemList(invoiceUrn));
	}

	@Override
	public MiscBillingInvLineitemEntity updateLineItem(MiscBillingInvLineitemEntity miscBillingInvLineitemEntity) {
		return miscBillingInvLineItemRepository.save(miscBillingInvLineitemEntity);
	}

	@Override
	public void updateInvoice(MiscBillingTrnInvoiceEntity invoiceEntity) {
		invoiceRepository.save(invoiceEntity);
	}

	@Override
	public List<MiscBillingTrnInvoiceEntity> getInvoicesForAutoEvaluation(String status, String billingType,
			String invoiceDate, String chargeCategoryCode, String supplierCode, String billingMonth,
			Integer billingPeriod, String clientId) {
		return miscBillingRepository.findAll(
				MiscBillingTrnInvoiceEntitySpec.getInvoicesForAutoEvaluation(status, billingType, invoiceDate, chargeCategoryCode, 
						supplierCode, billingMonth, billingPeriod, clientId));
	}
}
