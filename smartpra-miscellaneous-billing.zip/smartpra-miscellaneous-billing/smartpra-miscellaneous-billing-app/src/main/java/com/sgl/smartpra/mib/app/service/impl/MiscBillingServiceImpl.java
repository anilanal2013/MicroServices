package com.sgl.smartpra.mib.app.service.impl;

import java.math.BigDecimal;
import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.mib.app.dao.MiscBillingDao;
import com.sgl.smartpra.mib.app.dto.InvoiceFlow;
import com.sgl.smartpra.mib.app.dto.InvoiceOperational;
import com.sgl.smartpra.mib.app.mapper.MiscBillingMapper;
import com.sgl.smartpra.mib.app.service.MiscBillingService;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class MiscBillingServiceImpl implements MiscBillingService {

	Function<BigDecimal, String> convertToSt = (w) -> w != null ? w.toPlainString() : BigDecimal.ZERO.toPlainString();

	@Autowired
	private MiscBillingDao miscBillingDao;

	@Autowired
	private MiscBillingMapper miscBillingMapper;

	@Override
	public List<InvoiceOperational> fetchInvoice(Optional<String> billingPeriodAsOnMonth,
			Optional<Integer> billingPeriodAsOn, Optional<String> billingPeriodFromMonth,
			Optional<Integer> billingPeriodFrom, Optional<String> billingPeriodToMonth,
			Optional<Integer> billingPeriodTo, Optional<String> supplierType, Optional<String> supplierCode,
			Optional<String> supplierName, Optional<String> billingType, Optional<String> status,
			Optional<String> settlementInd, Optional<String> locationCode, Optional<String> chargeCat,
			Optional<String> invoiceCurrency) {
		List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntities = miscBillingDao.fetchInvoice(supplierType, supplierCode, supplierName, billingType, status, settlementInd,
				locationCode, chargeCat, invoiceCurrency, billingPeriodAsOnMonth, billingPeriodAsOn,
                billingPeriodFromMonth, billingPeriodFrom, billingPeriodToMonth, billingPeriodTo);

		List<MiscBillingTrnInvoice> miscBillingTrnInvoices = miscBillingTrnInvoiceEntities.stream().filter(Objects::nonNull)
				.map(miscBillingTrnInvoiceEntity -> {
					MiscBillingTrnInvoice miscBillingTrnInvoice = new MiscBillingTrnInvoice();
					miscBillingTrnInvoice
							.setSettlementMonthPeriod(miscBillingTrnInvoiceEntity.getSettlementMonthPeriod());
					miscBillingTrnInvoice
							.setSellerOrganizationId(miscBillingTrnInvoiceEntity.getSellerOrganizationId());
					miscBillingTrnInvoice.setInwardOutwardFlag(miscBillingTrnInvoiceEntity.getInwardOutwardFlag());
					miscBillingTrnInvoice.setCurrencyCode(miscBillingTrnInvoiceEntity.getCurrencyCode());
					miscBillingTrnInvoice.setBaseCurrency(miscBillingTrnInvoiceEntity.getBaseCurrency());
					miscBillingTrnInvoice.setAmountBaseCurrency(miscBillingTrnInvoiceEntity.getAmountBaseCurrency());
					miscBillingTrnInvoice.setTotalAmount(miscBillingTrnInvoiceEntity.getTotalAmount());
					miscBillingTrnInvoice.setInvoiceUrn(miscBillingTrnInvoiceEntity.getInvoiceUrn());
					miscBillingTrnInvoice.setBillingMonth(miscBillingTrnInvoiceEntity.getBillingMonth());
					miscBillingTrnInvoice.setBillingPeriod(miscBillingTrnInvoiceEntity.getBillingPeriod());
					return miscBillingTrnInvoice;
				}).collect(Collectors.toList());
		miscBillingTrnInvoices = filterByBillingMonthAndPeriod(billingPeriodAsOnMonth,billingPeriodAsOn, billingPeriodFromMonth,
				billingPeriodFrom, billingPeriodToMonth,billingPeriodTo, miscBillingTrnInvoices);
		
		Map<String, Map<String, Map<String, Map<String, List<MiscBillingTrnInvoice>>>>> mMiscBill = miscBillingTrnInvoices
				.stream()
				.collect(Collectors.groupingBy(misc -> misc.getBillingMonth() +"/"+ misc.getBillingPeriod(),
						Collectors.groupingBy(MiscBillingTrnInvoice::getSellerOrganizationId,
								Collectors.groupingBy(MiscBillingTrnInvoice::getInwardOutwardFlag,
										Collectors.groupingBy(MiscBillingTrnInvoice::getCurrencyCode)))));

		List<InvoiceOperational> invoiceOperationals = new ArrayList<>();
		mMiscBill.entrySet().stream().forEach(e -> {
			Map<String, Map<String, Map<String, List<MiscBillingTrnInvoice>>>> mMiscBillSeller = e.getValue();
			if (mMiscBillSeller != null && !mMiscBillSeller.isEmpty()) {
				mMiscBillSeller.entrySet().stream().forEach(w -> {
					InvoiceOperational invoiceOperational = setInvoiceBillMonth(e.getKey()); 
					invoiceOperational.setSupplierCode(w.getKey());
					w.getValue().computeIfPresent("O", (k, v) -> {
						Map<String, List<MiscBillingTrnInvoice>> mMiscBillInvoiceC = v;
						InvoiceFlow outward = new InvoiceFlow();
						if (mMiscBillInvoiceC != null && !mMiscBillInvoiceC.isEmpty()) {
							mMiscBillInvoiceC.entrySet().stream().forEach(x -> {
								setInvoiceFlow(outward, x, "O");
								invoiceOperational.setOutward(outward);
							});
						}
						return v;
					});
					w.getValue().computeIfPresent("I", (k, v) -> {
						Map<String, List<MiscBillingTrnInvoice>> mMiscBillInvoiceC = v;
						InvoiceFlow inward = new InvoiceFlow();
						if (mMiscBillInvoiceC != null && !mMiscBillInvoiceC.isEmpty()) {
							mMiscBillInvoiceC.entrySet().stream().forEach(x -> {
								setInvoiceFlow(inward, x, "I");
								invoiceOperational.setInward(inward);
							});
						}
						return v;
					});

					if (invoiceOperational.getOutward() == null) {
						invoiceOperational.setOutward(setInvoiceFlowAsNull());
					} else if (invoiceOperational.getInward() == null) {
						invoiceOperational.setInward(setInvoiceFlowAsNull());
					}
					invoiceOperationals.add(invoiceOperational);
				});
			}

		});

		return invoiceOperationals;
	}

	@Override
	public List<MiscBillingTrnInvoice> fetchInvoiceDetails(Optional<String> billingPeriodAsOn,
			Optional<Integer> billingPeriodAsOnMonth, Optional<String> supplierCode, Optional<String> billingType) {
		List<MiscBillingTrnInvoice> alMiscBillingTrnInvoice = new ArrayList<>();
		miscBillingMapper.mapTransmissionHeaderToEntityList(miscBillingDao.fetchInvoiceDetails(billingPeriodAsOn,
				billingPeriodAsOnMonth, supplierCode, billingType), alMiscBillingTrnInvoice);
		return alMiscBillingTrnInvoice;
	}

	@Override
	public List<MiscBillingTrnInvoice> fetchInvoiceDetails(List<String> invoiceList) {
		List<MiscBillingTrnInvoice> alMiscBillingTrnInvoice = new ArrayList<>();
		miscBillingMapper.mapTransmissionHeaderToEntityList(miscBillingDao.fetchInvoiceDetails(invoiceList),
				alMiscBillingTrnInvoice);
		return alMiscBillingTrnInvoice;
	}

	private void setInvoiceFlow(InvoiceFlow inward, Map.Entry<String, List<MiscBillingTrnInvoice>> x, String i) {
		inward.setInvoiceCurrency(x.getKey());
		inward.setInOutChecks(i);
		inward.setAmountInvoiceCurrency(convertToSt.apply(x.getValue().stream()
				.map(total -> total.getTotalAmount() != null ? total.getTotalAmount() : BigDecimal.ZERO)
				.reduce(BigDecimal.ZERO, BigDecimal::add)));
		inward.setNoOfInvoices(x.getValue().size());
		inward.setBaseCurrency(x.getValue().get(0).getBaseCurrency());
		inward.setAmountBaseCurrency(convertToSt.apply(x.getValue().stream()
				.map(total -> total.getAmountBaseCurrency() != null ? total.getAmountBaseCurrency() : BigDecimal.ZERO)
				.reduce(BigDecimal.ZERO, BigDecimal::add)));
		inward.setInvoiceList(
				x.getValue().stream().map(MiscBillingTrnInvoice::getInvoiceUrn).collect(Collectors.toList()));
	}

	private InvoiceOperational setInvoiceBillMonth(String key) {
		InvoiceOperational invoiceOperational = new InvoiceOperational();
		invoiceOperational.setBillingMonth(StringUtils.split(key,"/")[0]);
		invoiceOperational.setBillingPeriod(Integer.parseInt(StringUtils.split(key,"/")[1]));
		return invoiceOperational;

	}

	private InvoiceFlow setInvoiceFlowAsNull() {
		InvoiceFlow invoiceFlow = new InvoiceFlow();
		invoiceFlow.setInOutChecks(null);
		invoiceFlow.setInvoiceCurrency(null);
		invoiceFlow.setAmountInvoiceCurrency(null);
		invoiceFlow.setNoOfInvoices(null);
		invoiceFlow.setBaseCurrency(null);
		invoiceFlow.setAmountBaseCurrency(null);
		return invoiceFlow;
	}

	public void setMiscBillingDao(MiscBillingDao miscBillingDao) {
		this.miscBillingDao = miscBillingDao;
	}

	public void setMiscBillingMapper(MiscBillingMapper miscBillingMapper) {
		this.miscBillingMapper = miscBillingMapper;
	}
	
	private List<MiscBillingTrnInvoice> filterByBillingMonthAndPeriod(Optional<String> billingPeriodAsOnMonth,
			Optional<Integer> billingPeriodAsOn, Optional<String> billingPeriodFromMonth,
			Optional<Integer> billingPeriodFrom, Optional<String> billingPeriodToMonth,
			Optional<Integer> billingPeriodTo,List<MiscBillingTrnInvoice> miscBillingTrnInvoices){
		List<String> months = Arrays.asList(new DateFormatSymbols().getShortMonths()).stream().map(String::toUpperCase).collect(Collectors.toList());
		if(billingPeriodAsOnMonth.isPresent() && billingPeriodAsOn.isPresent()) {
			miscBillingTrnInvoices  = miscBillingTrnInvoices.stream().filter(Objects::nonNull)
			.filter(miscBillingTrnInvoice ->{
				String searchedBillingMonth = billingPeriodAsOnMonth.get().split("-")[0];
				int searchedBillingYear = Integer.parseInt(billingPeriodAsOnMonth.get().split("-")[1]);
				String billingMonth = miscBillingTrnInvoice.getBillingMonth().split("-")[0]; 
				int billingYear = Integer.parseInt(miscBillingTrnInvoice.getBillingMonth().split("-")[1]);
				if(searchedBillingYear > billingYear) {
					return true;
				} else if(searchedBillingYear < billingYear) {
					return false;
				} else if(months.indexOf(billingMonth.toUpperCase()) < months.indexOf(searchedBillingMonth.toUpperCase())) {
					return true;
				} else if(months.indexOf(searchedBillingMonth.toUpperCase()) == months.indexOf(billingMonth.toUpperCase()) &&  miscBillingTrnInvoice.getBillingPeriod().intValue() <= billingPeriodAsOn.get().intValue()) {
					return true;
				}
				return false;
			}).collect(Collectors.toList());
		} else if(billingPeriodFromMonth.isPresent() && billingPeriodFrom.isPresent() && billingPeriodToMonth.isPresent() && billingPeriodTo.isPresent()) {
			miscBillingTrnInvoices  = miscBillingTrnInvoices.stream().filter(Objects::nonNull)
					.filter(miscBillingTrnInvoice ->{
						String searchedBillingMonthFrom = billingPeriodFromMonth.get().split("-")[0];
						int searchedBillingYearFrom = Integer.parseInt(billingPeriodFromMonth.get().split("-")[1]);
						String searchedBillingMonthTo = billingPeriodToMonth.get().split("-")[0];
						int searchedBillingYearTo = Integer.parseInt(billingPeriodToMonth.get().split("-")[1]);
						String billingMonth = miscBillingTrnInvoice.getBillingMonth().split("-")[0]; 
						int billingYear = Integer.parseInt(miscBillingTrnInvoice.getBillingMonth().split("-")[1]);
						if(billingYear < searchedBillingYearFrom  || searchedBillingYearTo < billingYear) {
							return false;
						} else if(billingYear > searchedBillingYearFrom  && searchedBillingYearTo > billingYear) {
							return true;
						} else if(billingYear == searchedBillingYearFrom && months.indexOf(billingMonth.toUpperCase()) > months.indexOf(searchedBillingMonthFrom.toUpperCase())
								|| billingYear == searchedBillingYearTo && months.indexOf(billingMonth.toUpperCase()) < months.indexOf(searchedBillingMonthTo.toUpperCase())) {
							return true;
						}  else if(billingYear == searchedBillingYearFrom && months.indexOf(billingMonth.toUpperCase()) == months.indexOf(searchedBillingMonthFrom.toUpperCase())
									&& miscBillingTrnInvoice.getBillingPeriod().intValue() >= billingPeriodFrom.get().intValue()  
								|| billingYear == searchedBillingYearTo && months.indexOf(billingMonth.toUpperCase()) == months.indexOf(searchedBillingMonthTo.toUpperCase())
									&& miscBillingTrnInvoice.getBillingPeriod().intValue() <= billingPeriodTo.get().intValue()) {
							return true;
						}
						return false;
					}).collect(Collectors.toList());
		}
		return miscBillingTrnInvoices;
	}
}
