package com.sgl.smartpra.mib.app.mapper;

import com.sgl.smartpra.mib.domain.*;
import com.sgl.smartpra.mib.entity.*;
import org.mapstruct.*;

import java.util.List;


@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface MiscBillingMapper {

    /* @Mapping(source = "miscBillingInvTransHeader.transHdrId" , target = "miscBillingInvTransHeader", qualifiedBy =
             QualifiedByUtil.TransHeaderToInteger.class)*/
    public void mapMiscBillingTrnInvoiceEntityToMiscBillingTrnInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity,
                                                                      @MappingTarget MiscBillingTrnInvoice miscBillingTrnInvoice);



    public void mapTransmissionHeaderToEntityList(List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntity, @MappingTarget List<MiscBillingTrnInvoice> miscBillingTrnInvoice);

    public void mapMiscBillingInvTransHeaderEntityToMiscBillingInvTransHeader(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity,
                                                                              @MappingTarget
                                                                                      MiscBillingInvTransHeader miscBillingInvTransHeader);

    /*@Mapping(source = "miscBillingTrnInvoice.invoiceUrn",target = "miscBillingTrnInvoice" ,  qualifiedByName =
            "invoice")*/
    public void mapMiscBillingInvLineitemEntityListToMiscBillingInvLineitemList(List<MiscBillingInvLineitemEntity> miscBillingInvLineitemEntities ,
                                                                                @MappingTarget List<MiscBillingInvLineitem> miscBillingInvLineitems);


    /*  @Mapping(target = "miscBillingTrnInvoice" ,  qualifiedByName =
              "invoice")*/
    public void mapMiscBillingInvLineitemEntityToMiscBillingInvLineitem(MiscBillingInvLineitemEntity miscBillingInvLineitemEntity ,
                                                                        @MappingTarget MiscBillingInvLineitem miscBillingInvLineitems);



    /*
        @Mapping(target = "miscBillingInvLineitem" ,  source= "miscBillingInvLineitem.invLineItemId") */
    public void mapMiscBillingInvLineitemDtlEntityListToMiscBillingInvLineitemDtlList(List<MiscBillingInvLineitemDtlEntity> miscBillingInvLineitemDtlEntities,
                                                                                      @MappingTarget List<MiscBillingInvLineitemDtl> miscBillingInvLineitemDtls);


    //    @Mapping(  source= "miscBillingInvLineitem.invLineItemId" ,target = "miscBillingInvLineitem" , ignore = true)
    public void mapMiscBillingInvLineitemDtlEntityToMiscBillingInvLineitemDtl(MiscBillingInvLineitemDtlEntity miscBillingInvLineitemDtlEntities,
                                                                              @MappingTarget MiscBillingInvLineitemDtl miscBillingInvLineitemDtls);


    //    @Mapping(target = "miscBillingInvLineitem" ,  source= "miscBillingInvLineitem.invLineItemId")
//    @Mapping(target = "miscBillingTrnInvoice" ,  source= "miscBillingTrnInvoice.invoiceUrn")
//    @Mapping(target = "miscBillingInvLineitemDtl" ,  source= "miscBillingInvLineitemDtl.invLineitemDetailId")
    public void mapMiscBillingTaxDetailsEntityToMiscBillingTaxDetails(List<MiscBillingTaxDetailsEntity> miscBillingTaxDetailsEntities,
                                                                      @MappingTarget List<MiscBillingTaxDetails> miscBillingTaxDetails);

    /*  @Mapping(  source= "miscBillingInvLineitem" , target = "miscBillingInvLineitem" , ignore = true)
      @Mapping(target = "miscBillingTrnInvoice" ,  source= "miscBillingTrnInvoice.invoiceUrn", ignore = true)
      @Mapping(target = "miscBillingInvLineitemDtl" ,  source= "miscBillingInvLineitemDtl.invLineitemDetailId" , ignore = true)*/
    public void mapMiscBillingTaxDetailsEntityToMiscBillingTaxDetails(MiscBillingTaxDetailsEntity miscBillingTaxDetailsEntities,
                                                                      @MappingTarget MiscBillingTaxDetails miscBillingTaxDetails);


    /* @Mapping(target = "miscBillingInvLineitem" ,  source= "miscBillingInvLineitem.invLineItemId" , ignore = true)
     @Mapping(target = "miscBillingTrnInvoice" ,  source= "miscBillingTrnInvoice.invoiceUrn" , ignore = true)
     @Mapping(target = "miscBillingInvLineitemDtl" ,  source= "miscBillingInvLineitemDtl.invLineitemDetailId" , ignore = true)*/
    public void mapMiscBillingAddOnChargeDtlEntityToMiscBillingAddOnChargeDtl(MiscBillingAddOnChargeDtlEntity miscBillingAddOnChargeDtlEntities,
                                                                              @MappingTarget MiscBillingAddOnChargeDtl miscBillingAddOnChargeDtls);

    public void mapMiscBillingAddOnChargeDtlEntityToMiscBillingAddOnChargeDtl(List<MiscBillingAddOnChargeDtlEntity> miscBillingAddOnChargeDtlEntities,
                                                                              @MappingTarget List<MiscBillingAddOnChargeDtl> miscBillingAddOnChargeDtls);


    //    @Mapping(target = "miscBillingInvLineitemDtl" ,  source= "miscBillingInvLineitemDtl.invLineitemDetailId" , ignore = true)
    public void mapMiscBillingSupportingDetailEntityToMiscBillingSupportingDetail(MiscBillingSupportingDetailEntity miscBillingSupportingDetailEntities,
                                                                                  @MappingTarget MiscBillingSupportingDetail miscBillingSupportingDetails);

    public void mapMiscBillingSupportingDetailEntityToMiscBillingSupportingDetail(List<MiscBillingSupportingDetailEntity> miscBillingSupportingDetailEntities,
                                                                                  @MappingTarget List<MiscBillingSupportingDetail> miscBillingSupportingDetails);


    //    @Mapping(target = "miscBillingTrnInvoice" , source = "miscBillingTrnInvoice.invoiceUrn" , ignore = true)
    public void mapMiscBillingInvAttachmentEntityToMiscBillingInvAttachment(MiscBillingInvAttachmentEntity miscBillingInvAttachmentEntities ,
                                                                            @MappingTarget MiscBillingInvAttachment miscBillingInvAttachments);

    public void mapMiscBillingInvAttachmentEntityToMiscBillingInvAttachment(List<MiscBillingInvAttachmentEntity> miscBillingInvAttachmentEntities ,
                                                                            @MappingTarget List<MiscBillingInvAttachment> miscBillingInvAttachments);




}
