package com.sgl.smartpra.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.mib.domain.MiscBillingInvLineitem;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface InvoiceLineItemMapper {
	
	MiscBillingInvLineitem mapToModel(MiscBillingInvLineitemEntity miscBillingInvLineitemEntity);
}
