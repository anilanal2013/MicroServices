package com.sgl.smartpra.mib.app.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;
import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface MiscBillingInvoiceMapper {

	MiscBillingTrnInvoiceEntity mapToEntity(MiscBillingTrnInvoice miscBillingTrnInvoice);

	MiscBillingTrnInvoice mapToModel(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity);

	@IterableMapping(qualifiedByName = "mapToMiscBillingTrnInvoice")
	List<MiscBillingTrnInvoice> mapToMiscBillingTrnInvoice(
			List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntity);

	@Named("mapToMiscBillingTrnInvoice")
	@Mapping(target = "miscBillingInvLineitem", ignore = true)
	@Mapping(target = "miscBillingTaxDetails", ignore = true)
	@Mapping(target = "miscBillingAddOnChargeDtl", ignore = true)
	@Mapping(target = "miscBillingInvAttachment", ignore = true)
	MiscBillingTrnInvoice mapToMiscBillingTrnInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity);

	@IterableMapping(qualifiedByName = "lineItem")
	@Named("lineItemList")
	List<MiscBillingInvLineitemEntity> mapToLineItem(List<MiscBillingInvLineitemEntity> miscBillingInvLineitemEntity);

	@Named("lineItem")
	@Mapping(target = "miscBillingTrnInvoice.invoiceUrn", ignore = true)
	@Mapping(target = "invLineItemId", ignore = true)
	@Mapping(target = "miscBillingLineitemDetails", ignore = true)
	MiscBillingInvLineitemEntity mapToLineItem(MiscBillingInvLineitemEntity miscBillingInvLineitemEntity);

	// Tax details
	@IterableMapping(qualifiedByName = "taxDetail")
	@Named("taxDetailList")
	List<MiscBillingTaxDetailsEntity> mapToTaxDetails(List<MiscBillingTaxDetailsEntity> miscBillingTaxDetails);

	@Named("taxDetail")
	@Mapping(target = "miscBillingTrnInvoice.invoiceUrn", ignore = true)
	@Mapping(target = "miscBillingTaxDtlId", ignore = true)
	@Mapping(target = "miscBillingInvLineitemDtl", ignore = true)
	MiscBillingTaxDetailsEntity mapToTaxDetails(MiscBillingTaxDetailsEntity miscBillingTaxDetailsEntity);

	// AddOn details
	@IterableMapping(qualifiedByName = "addOnDetail")
	@Named("addOnDetailList")
	List<MiscBillingAddOnChargeDtlEntity> mapToAddOnDetails(List<MiscBillingAddOnChargeDtlEntity> miscBillingAddOnChargeDtl);

	@Named("addOnDetail")
	@Mapping(target = "miscBillingTrnInvoice.invoiceUrn", ignore = true)
	@Mapping(target = "miscBillingAddOnChargeDtlId", ignore = true)
	@Mapping(target = "miscBillingInvLineitemDtl", ignore = true)
	MiscBillingAddOnChargeDtlEntity mapToTaxDetails(MiscBillingAddOnChargeDtlEntity miscBillingAddOnChargeDtlEntity);

	@Mapping(target = "miscBillingInvLineitem", source = "miscBillingInvLineitem", qualifiedByName = "lineItemList")
	@Mapping(target = "miscBillingTaxDetails", source = "miscBillingTaxDetails", qualifiedByName = "taxDetailList")
	@Mapping(target = "miscBillingAddOnChargeDtl", source = "miscBillingAddOnChargeDtl", qualifiedByName = "addOnDetailList")
	@Mapping(target = "invoiceUrn", ignore = true)
	@Mapping(target = "miscBillingInvAttachment", ignore = true)
	MiscBillingTrnInvoiceEntity copyEntity(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity);
	
	List<MiscBillingTrnInvoice> mapToModel(List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntity);
}
