package com.sgl.smartpra.mib.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

public interface MiscBillingDao {

    public List<MiscBillingTrnInvoiceEntity> fetchInvoice(Optional<String> supplierType,Optional<String> supplierCode,
            Optional<String> supplierName,Optional<String> billingType,
            Optional<String> status,Optional<String> settlementInd, Optional<String> locationCode,
            Optional<String> chargeCat, Optional<String> invoiceCurrency,
            Optional<String> billingPeriodAsOnMonth,Optional<Integer> billingPeriodAsOn,
            Optional<String> billingPeriodFromMonth,Optional<Integer> billingPeriodFrom, 
            Optional<String> billingPeriodToMonth,Optional<Integer> billingPeriodTo);

    List<MiscBillingTrnInvoiceEntity> fetchInvoiceDetails(Optional<String> billingPeriodAsOn,
                                                          Optional<Integer> billingPeriodAsOnMonth,
                                                          Optional<String> supplierCode, Optional<String> billingType);

    List<MiscBillingTrnInvoiceEntity> fetchInvoiceDetails(List<String> invoiceList);
}
