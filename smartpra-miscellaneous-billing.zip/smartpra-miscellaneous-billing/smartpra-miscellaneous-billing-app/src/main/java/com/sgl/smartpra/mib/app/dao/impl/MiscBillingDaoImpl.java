package com.sgl.smartpra.mib.app.dao.impl;

import com.sgl.smartpra.mib.app.dao.MiscBillingDao;
import com.sgl.smartpra.mib.app.repository.MiscBillingRepository;
import com.sgl.smartpra.mib.app.repository.spec.MiscBillingTrnInvoiceEntitySpec;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class MiscBillingDaoImpl implements MiscBillingDao {

    @Autowired
    private MiscBillingRepository miscBillingRepository;

    public List<MiscBillingTrnInvoiceEntity> fetchInvoice(Optional<String> supplierType,Optional<String> supplierCode,
                                                          Optional<String> supplierName,Optional<String> billingType,
                                                          Optional<String> status,Optional<String> settlementInd, Optional<String> locationCode,
                                                          Optional<String> chargeCat, Optional<String> invoiceCurrency,
                                                          Optional<String> billingPeriodAsOnMonth,Optional<Integer> billingPeriodAsOn,
                                                          Optional<String> billingPeriodFromMonth,Optional<Integer> billingPeriodFrom, 
                                                          Optional<String> billingPeriodToMonth,Optional<Integer> billingPeriodTo) {
        return miscBillingRepository.findAll(MiscBillingTrnInvoiceEntitySpec.search(supplierType,
                supplierCode,supplierName,billingType,status,settlementInd, locationCode,chargeCat, invoiceCurrency,
                billingPeriodAsOnMonth,billingPeriodAsOn,billingPeriodFromMonth,billingPeriodFrom, 
                billingPeriodToMonth,billingPeriodTo));
    }

    @Override
    public List<MiscBillingTrnInvoiceEntity> fetchInvoiceDetails(Optional<String> billingPeriodAsOn
            , Optional<Integer> billingPeriodAsOnMonth, Optional<String> supplierCode, Optional<String> billingType) {
        return miscBillingRepository.findAll(MiscBillingTrnInvoiceEntitySpec
                .searchInvoiceDetails(billingPeriodAsOn, billingPeriodAsOnMonth, supplierCode, billingType));
    }

    @Override
    public List<MiscBillingTrnInvoiceEntity> fetchInvoiceDetails(List<String> invoiceList) {
        return miscBillingRepository.findByInvoiceUrnIn(invoiceList);
    }
}
