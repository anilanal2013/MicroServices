package com.sgl.smartpra.mib.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.mib.app.dto.StatusRequest;
import com.sgl.smartpra.mib.app.service.MiscBillingInvoiceService;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/misc-billing-invoice")
public class MiscBillingInvoiceController {

	@Autowired
	private MiscBillingInvoiceService miscBillingInvoiceService;
	
	@GetMapping("/invoice-view")
	public MiscBillingTrnInvoice getInvoiceView(@RequestParam(value = "batchNumber") String batchNumber) {
		return miscBillingInvoiceService.getInvoiceView(batchNumber);
		
	}
	
	@GetMapping("/search-invoice")
	public List<MiscBillingTrnInvoice> getAllInvoices(
			@RequestParam(value = "billingType" , required = false) Optional<String> billingType,
			@RequestParam(value = "supplierType" , required = false) Optional<String> supplierType,
			@RequestParam(value = "supplierCode" , required = false) Optional<String> supplierCode,
			@RequestParam(value = "supplierName" , required = false) Optional<String> supplierName,
			@RequestParam(value = "billingPeriodMonth" , required = false) Optional<String> billingPeriodMonth,
			@RequestParam(value = "billingPeriod" , required = false) Optional<Integer> billingPeriod,
            @RequestParam(value = "invoiceNumber" , required = false) Optional<String> invoiceNumber) {
		return miscBillingInvoiceService.getAllInvoices(billingType, supplierType, supplierCode, supplierName, billingPeriodMonth, billingPeriod, invoiceNumber);
	}
	
	@PostMapping("/capture-invoice")
	@ResponseStatus(value = HttpStatus.CREATED)
	public MiscBillingTrnInvoice captureInvoice(@RequestBody MiscBillingTrnInvoice miscBillingTrnInvoice) {
		return miscBillingInvoiceService.captureInvoice(miscBillingTrnInvoice);
		
	}

	@PutMapping("/updateInvoiceStatus/{level}")
	@ResponseStatus(value = HttpStatus.OK)
	public StatusRequest updateStatus(
			@PathVariable(value = "level") String level,
			@RequestBody StatusRequest statusRequest){
		return miscBillingInvoiceService.updateStatus(statusRequest,level);
	}
	
	@PutMapping("/update-invoice/{invoiceUrn}")
	@ResponseStatus(value = HttpStatus.OK)
	public MiscBillingTrnInvoice updateInvoice(
			@PathVariable(value = "invoiceUrn") String invoiceUrn,
			@RequestBody MiscBillingTrnInvoice miscBillingTrnInvoice) {
		miscBillingTrnInvoice.setInvoiceUrn(invoiceUrn);
		return miscBillingInvoiceService.updateInvoice(miscBillingTrnInvoice);
	}
	
	@PostMapping("/create-rejected-invoice")
	@ResponseStatus(value = HttpStatus.CREATED)
	public List<MiscBillingTrnInvoice> createRejectedInvoice(@RequestBody(required=false) Optional<List<String>> invoiceUrns) {
		return miscBillingInvoiceService.createRejectedInvoice(invoiceUrns);

	}
	
	@PostMapping("/confirm-invoice")
	@ResponseStatus(value = HttpStatus.OK)
	public List<MiscBillingTrnInvoice> confirmInvoice(@RequestBody(required=false) Optional<List<String>> invoiceUrns) {
		return miscBillingInvoiceService.confirmInvoice(invoiceUrns);

	}
	
	@GetMapping("/search-invoice/outward")
	public List<MiscBillingTrnInvoice> getOutwardInvoicesByBillingMonth(
			@RequestParam(value = "clientId" , required = true) String clientId,
			@RequestParam(value = "billingMonth" , required = true) String billingMonth,
			@RequestParam(value = "billingPeriod" , required = false) Optional<Integer> billingPeriod,
            @RequestParam(value = "invoiceNumber" , required = false) Optional<String> invoiceNumber,
            @RequestParam(value = "carrierCode" , required = false) Optional<String> carrierCode,
            @RequestParam(value = "supplierType" , required = false) Optional<String> supplierType
            ) {
		return miscBillingInvoiceService.getOutwardInvoicesByBillingMonth(clientId, billingMonth, billingPeriod, 
				invoiceNumber, carrierCode, supplierType);
	}

	@PostMapping("/outward-invoice/save")
	public String processOutwardInvoices(
		@RequestParam(value = "billingMonth" , required = true) String billingMonth,
		@RequestParam(value = "billingPeriod" , required = true) Integer billingPeriod,
        @RequestParam(value = "clientId" , required = true) String clientId) {
		String msg = miscBillingInvoiceService.processInvoices(billingMonth, billingPeriod, clientId);
		log.debug("msg = " + msg);
		return msg;
	}
}

