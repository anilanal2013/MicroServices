package com.sgl.smartpra.mib.app.controller;

import com.sgl.smartpra.mib.app.dto.InvoiceOperational;
import com.sgl.smartpra.mib.app.service.MiscBillingService;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/miscbilling-dashboard")
public class MiscBillingDashboardController {

    @Autowired
    private MiscBillingService miscBillingService;

    @GetMapping(value = "/searchInvoices")
    public List<InvoiceOperational> fetchInvoices(
    		@RequestParam(value = "billingPeriodAsOnMonth" , required = false) Optional<String> billingPeriodAsOnMonth,
            @RequestParam(value = "billingPeriodAsOn" , required = false) Optional<Integer> billingPeriodAsOn,
            @RequestParam(value = "billingPeriodFromMonth" , required = false) Optional<String> billingPeriodFromMonth,
            @RequestParam(value = "billingPeriodFrom" , required = false) Optional<Integer> billingPeriodFrom,
            @RequestParam(value = "billingPeriodToMonth" , required = false) Optional<String> billingPeriodToMonth,
            @RequestParam(value = "billingPeriodTo" , required = false) Optional<Integer> billingPeriodTo,
            @RequestParam(value = "supplierType" , required = false) Optional<String> supplierType,
            @RequestParam(value = "supplierCode" , required = false) Optional<String> supplierCode,
            @RequestParam(value = "supplierName" , required = false) Optional<String> supplierName,
            @RequestParam(value = "billingType" , required = false) Optional<String> billingType,
            @RequestParam(value = "status" , required = false) Optional<String> status,
            @RequestParam(value = "settlementInd" , required = false) Optional<String> settlementInd,
            @RequestParam(value = "locationCode" , required = false) Optional<String> locationCode ,
            @RequestParam(value = "chargeCat" , required = false) Optional<String> chargeCat,
            @RequestParam(value = "invoiceCurrency" , required = false) Optional<String> invoiceCurrency

    ) {
        return miscBillingService.fetchInvoice(billingPeriodAsOnMonth,billingPeriodAsOn,billingPeriodFromMonth,billingPeriodFrom,
                billingPeriodToMonth, billingPeriodTo,supplierType,supplierCode,supplierName,billingType,status,settlementInd
                ,locationCode,chargeCat,invoiceCurrency);
    }


    @GetMapping(value = "/invoiceDetails")
    public List<MiscBillingTrnInvoice> fetchInvoices(
            @RequestParam(value = "invoiceList" , required = true) List<String> invoiceList
    ) {
        return miscBillingService.fetchInvoiceDetails(invoiceList);
    }

	
}
