package com.sgl.smartpra.mib.app.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class InvoiceFlow implements Serializable {


    private String amountInvoiceCurrency;

    private Integer noOfInvoices;

    private String inOutChecks;

    private String baseCurrency;

    private String amountBaseCurrency;

    private String invoiceCurrency;

    private List<String> invoiceList;
}
