package com.sgl.smartpra.mib.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

public interface InvoiceEvaluationDao {

	public List<MiscBillingTrnInvoiceEntity> getAllInvoices(Optional<String> status, Optional<String> billingType,
			Optional<String> billingPeriodMonth, Optional<Integer> billingPeriod,
			Optional<String> billingPeriodFromMonth, Optional<Integer> billingPeriodFrom,
			Optional<String> billingPeriodToMonth, Optional<Integer> billingPeriodTo, Optional<String> supplierType,
			Optional<String> supplierCode, Optional<String> supplierName, Optional<String> chargeCategoryCode,
			Optional<String> invoiceNumber);

	public List<MiscBillingInvLineitemEntity> getLineItemList(Optional<String> invoiceUrn);

    MiscBillingInvLineitemEntity updateLineItem( MiscBillingInvLineitemEntity mapMiscBillingInvLineitemEntityToEntity);
    
    public void updateInvoice(MiscBillingTrnInvoiceEntity invoiceEntity);
    
	public List<MiscBillingTrnInvoiceEntity> getInvoicesForAutoEvaluation(String status, String billingType, String invoiceDate, String chargeCategoryCode,
			String supplierCode, String billingMonth, Integer billingPeriod, String clientId);
    
}
