package com.sgl.smartpra.mib.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.mib.app.dto.StatusRequest;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

public interface MiscBillingInvoiceDao {

	public Optional<MiscBillingTrnInvoiceEntity> findById(String invoiceUrn);
	
	public Optional<MiscBillingTrnInvoiceEntity> getInvoiceView(String batchNumber);
	
	public MiscBillingTrnInvoiceEntity captureInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity);
	
	public List<MiscBillingTrnInvoiceEntity> getAllInvoices(Optional<String> billingType, Optional<String> supplierType,
			Optional<String> supplierCode, Optional<String> supplierName, Optional<String> billingPeriodMonth,
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber);

	public StatusRequest updateStatus(StatusRequest statusRequest, String level);
	
	public MiscBillingTrnInvoiceEntity updateInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity);
	
	List<MiscBillingTrnInvoiceEntity> getRejectedInvoice(Optional<List<String>> invoiceUrns);
	
	List<MiscBillingTrnInvoiceEntity> captureInvoices(List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntity);
	
	void updateRejectedInvoice(String moInvice, String miInvoice);
	
	public List<MiscBillingTrnInvoiceEntity> getOutwardInvoicesByBillingMonth(String clientId, String billingMonth, 
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber, Optional<String> carrierCode,
			Optional<String> supplierType);

	public List<MiscBillingTrnInvoiceEntity> processInvoices(String billingMonth, Integer billingPeriod, String clientId);
	
	public String getMaxInvoiceNo(String clientId, String fy, String carrierCode);
}

