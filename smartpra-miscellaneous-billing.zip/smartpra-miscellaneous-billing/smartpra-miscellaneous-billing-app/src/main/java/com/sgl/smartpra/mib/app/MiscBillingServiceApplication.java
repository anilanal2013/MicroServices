package com.sgl.smartpra.mib.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import org.springframework.scheduling.annotation.EnableScheduling;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableDiscoveryClient
@SpringBootApplication
@ComponentScan({ "com.sgl.smartpra.mib.app", "com.sgl.smartpra.mib.repository" })
@EntityScan("com.sgl.smartpra.mib")
@EnableJpaRepositories("com.sgl.smartpra.mib")
@EnableCircuitBreaker
@EnableSwagger2
@EnableFeignClients
@EnableScheduling
public class MiscBillingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiscBillingServiceApplication.class, args);
	}

}
