package com.sgl.smartpra.mib.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.sgl.smartpra.mib.app.dto.InvoiceEvaluationSummary;
import com.sgl.smartpra.mib.app.service.InvoiceEvaluationService;
import com.sgl.smartpra.mib.domain.MiscBillingInvLineitem;

@RestController
@RequestMapping("/misc-billing-invoice-evaluation")
public class InvoiceEvaluationController {

	@Autowired
	InvoiceEvaluationService invoiceEvaluationService;

	@GetMapping("/search-invoice")
	public List<InvoiceEvaluationSummary> getAllInvoices(
			@RequestParam(value = "status", required = false) Optional<String> status,
			@RequestParam(value = "billingType", required = false) Optional<String> billingType,
			@RequestParam(value = "billingPeriodMonth", required = false) Optional<String> billingPeriodMonth,
			@RequestParam(value = "billingPeriod", required = false) Optional<Integer> billingPeriod,
			@RequestParam(value = "billingPeriodFromMonth", required = false) Optional<String> billingPeriodFromMonth,
			@RequestParam(value = "billingPeriodFrom", required = false) Optional<Integer> billingPeriodFrom,
			@RequestParam(value = "billingPeriodToMonth", required = false) Optional<String> billingPeriodToMonth,
			@RequestParam(value = "billingPeriodTo", required = false) Optional<Integer> billingPeriodTo,
			@RequestParam(value = "supplierType", required = false) Optional<String> supplierType,
			@RequestParam(value = "supplierCode", required = false) Optional<String> supplierCode,
			@RequestParam(value = "supplierName", required = false) Optional<String> supplierName,
			@RequestParam(value = "chargeCategoryCode", required = false) Optional<String> chargeCategoryCode,
			@RequestParam(value = "invoiceNumber", required = false) Optional<String> invoiceNumber) {
		return invoiceEvaluationService.getAllInvoices(status, billingType, billingPeriodMonth, billingPeriod, billingPeriodFromMonth,
				billingPeriodFrom, billingPeriodToMonth, billingPeriodTo, supplierType, supplierCode, supplierName,
				chargeCategoryCode, invoiceNumber);
	}
	
	@GetMapping("/line-item-list")
	public List<MiscBillingInvLineitem> getLineItemList(@RequestParam(value = "invoiceUrn", required=false) Optional<String> invoiceUrn){
		
		return invoiceEvaluationService.getLineItemList(invoiceUrn);
	}

	@PutMapping("/lineItemUpdate/{id}")
	@ResponseStatus(value = HttpStatus.OK)
	public MiscBillingInvLineitem updateLineItem(
			@PathVariable("id") Integer id,
			@RequestBody MiscBillingInvLineitem miscBillingInvLineitem
	){
		return invoiceEvaluationService.updateLineItem(id,miscBillingInvLineitem);
	}
	
	@GetMapping("/auto-evaluation")
	public String autoEvaluation(
			@RequestParam(value = "status", required = true) String status,
			@RequestParam(value = "billingType", required = true) String billingType,
			@RequestParam(value = "invoiceDate", required = false) String invoiceDate,
			@RequestParam(value = "chargeCategoryCode", required = true) String chargeCategoryCode,
			@RequestParam(value = "sellerOrgId", required = true) String sellerOrgId,
			@RequestParam(value = "billingMonth", required = true) String billingMonth,
			@RequestParam(value = "billingPeriod", required = true) Integer billingPeriod,
			@RequestParam(value = "chargeCode", required = true) String chargeCode,
			@RequestParam(value = "clientId", required = true) String clientId) {
			
		return invoiceEvaluationService.getInvoicesForAutoEvaluation(status, billingType, invoiceDate, chargeCategoryCode, sellerOrgId, billingMonth, billingPeriod, chargeCode, clientId);
	}

}
