package com.sgl.smartpra.mib.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.mib.app.dto.StatusRequest;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;

public interface MiscBillingInvoiceService {

	public MiscBillingTrnInvoice getInvoiceView(String batchNumber);

	public MiscBillingTrnInvoice captureInvoice(MiscBillingTrnInvoice miscBillingTrnInvoice);

	public List<MiscBillingTrnInvoice> getAllInvoices(Optional<String> billingType, Optional<String> supplierType,
			Optional<String> supplierCode, Optional<String> supplierName, Optional<String> billingPeriodMonth,
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber);
	
	public MiscBillingTrnInvoice updateInvoice(MiscBillingTrnInvoice miscBillingTrnInvoice);

    StatusRequest updateStatus(StatusRequest statusRequest, String level);
    
    List<MiscBillingTrnInvoice> createRejectedInvoice(Optional<List<String>> invoiceUrns);
    
    List<MiscBillingTrnInvoice> confirmInvoice(Optional<List<String>> invoiceUrns);
    
	public List<MiscBillingTrnInvoice> getOutwardInvoicesByBillingMonth(String clientId, String billingMonth, 
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber, Optional<String> carrierCode,
			Optional<String> supplierType);

    public String processInvoices(String billingMonth, Integer billingPeriod, String clientId);
    
    public String generateInvoiceNo(String clientId, String fy, String carrierCode);
    
    public String getInvoiceSeq(Integer subInv);
    
    public String getCurrentFy(String clientId);

}