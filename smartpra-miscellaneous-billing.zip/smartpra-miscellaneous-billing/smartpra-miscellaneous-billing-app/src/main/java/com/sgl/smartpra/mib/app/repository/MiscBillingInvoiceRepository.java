package com.sgl.smartpra.mib.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

@Repository
public interface MiscBillingInvoiceRepository extends JpaRepository<MiscBillingTrnInvoiceEntity, String>,
		JpaSpecificationExecutor<MiscBillingTrnInvoiceEntity> {

}
