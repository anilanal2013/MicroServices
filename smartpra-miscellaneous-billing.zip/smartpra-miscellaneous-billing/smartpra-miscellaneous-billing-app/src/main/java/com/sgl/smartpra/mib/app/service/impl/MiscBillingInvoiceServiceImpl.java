package com.sgl.smartpra.mib.app.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.integration.model.CurrencyRateIn;
import com.sgl.smartpra.integration.model.CurrencyRateOut;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.mib.app.config.FeignConfiguration.ExchangeRateFeignClient;
import com.sgl.smartpra.mib.app.config.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.mib.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.mib.app.dao.MiscBillingInvoiceDao;
import com.sgl.smartpra.mib.app.dto.StatusRequest;
import com.sgl.smartpra.mib.app.mapper.MiscBillingInvoiceMapper;
import com.sgl.smartpra.mib.app.service.MiscBillingCommonService;
import com.sgl.smartpra.mib.app.service.MiscBillingInvoiceService;
import com.sgl.smartpra.mib.app.utility.MiscBillingUtil;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;
import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.enums.StatusEnum;
import com.sgl.smartpra.mib.utils.MiscBillingCommonUtil;
import com.sgl.smartpra.mib.utils.MiscBillingConstants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class MiscBillingInvoiceServiceImpl implements MiscBillingInvoiceService {

	@Autowired
	MiscBillingInvoiceDao miscBillingInvoiceDao;

	@Autowired
	MiscBillingInvoiceMapper miscBillingInvoiceMapper;

	@Autowired
	MiscBillingCommonService miscBillingCommonService;

	@Autowired
	private MasterFeignClient masterFeignClient;

	@Autowired
	ExchangeRateFeignClient exchangeRateFeignClient;
	
	@Autowired
    MiscBillingUtil miscBillingUtil;
	
	@Autowired
	private GlobalMasterFeignClient smartpraGlobalMasterAppClient;
	
	private static final String INVOICE = "Invoice";
	private static final String LINE_ITEM = "LineItem";
	private static final String EXCEPTION_CODE_MISC9002 = "MISC9002";
	private static final String EXCEPTION_CODE_MISC3026 = "MISC3026";
	private static final String EXCEPTION_CODE_MISC3027 = "MISC3027";

	@Override
	public MiscBillingTrnInvoice getInvoiceView(String batchNumber) {
		MiscBillingTrnInvoice miscBillingTrnInvoice = miscBillingInvoiceMapper.mapToModel(miscBillingInvoiceDao
				.getInvoiceView(batchNumber).orElseThrow(() -> new RecordNotFoundException(batchNumber)));
		miscBillingTrnInvoice.setMiscBillingAddOnChargeDtl(miscBillingTrnInvoice.getMiscBillingAddOnChargeDtl().stream()
				.filter(addOnCharge -> INVOICE.equalsIgnoreCase(addOnCharge.getAddOnLevel()))
				.collect(Collectors.toList()));
		miscBillingTrnInvoice.setMiscBillingTaxDetails(miscBillingTrnInvoice.getMiscBillingTaxDetails().stream()
				.filter(taxDetails -> INVOICE.equalsIgnoreCase(taxDetails.getTaxLevel())).collect(Collectors.toList()));
		return miscBillingTrnInvoice;
	}

	@Override
	public MiscBillingTrnInvoice captureInvoice(MiscBillingTrnInvoice miscBillingTrnInvoice) {
		if(StringUtils.isBlank(miscBillingTrnInvoice.getInvoiceUrn())) {
			if("I".equalsIgnoreCase(miscBillingTrnInvoice.getInwardOutwardFlag())) {
				miscBillingTrnInvoice
				.setInvoiceUrn(miscBillingCommonService.generateInwardBatchNo(miscBillingTrnInvoice.getClientId()));
			} else {
				miscBillingTrnInvoice
				.setInvoiceUrn(miscBillingCommonService.generateOutwardBatchNo(miscBillingTrnInvoice.getClientId()));
			}
		}
		miscBillingTrnInvoice.getMiscBillingInvLineitem().stream().filter(Objects::nonNull).forEach(lineItem -> {
			lineItem.setProcessStatus(miscBillingTrnInvoice.getInvoiceStatus());
		});
		MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity = setInvoiceUrnInLineItem(miscBillingInvoiceMapper.mapToEntity(miscBillingTrnInvoice));
		if(miscBillingTrnInvoiceEntity.getBillingPeriod() == null) {
			miscBillingTrnInvoiceEntity.setSettlementMonthPeriod(MiscBillingUtil.convertToSettlementMonthPeriod(miscBillingTrnInvoiceEntity.getBillingMonth(),1));
		} else {
			miscBillingTrnInvoiceEntity.setSettlementMonthPeriod(MiscBillingUtil.convertToSettlementMonthPeriod(miscBillingTrnInvoiceEntity.getBillingMonth(),miscBillingTrnInvoiceEntity.getBillingPeriod()));
		}
		
		return miscBillingInvoiceMapper.mapToModel(
				miscBillingInvoiceDao.captureInvoice(miscBillingTrnInvoiceEntity));
	}

	@Override
	public List<MiscBillingTrnInvoice> getAllInvoices(Optional<String> billingType, Optional<String> supplierType,
			Optional<String> supplierCode, Optional<String> supplierName, Optional<String> billingPeriodMonth,
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber) {
		return miscBillingInvoiceMapper.mapToMiscBillingTrnInvoice(miscBillingInvoiceDao.getAllInvoices(billingType,
				supplierType, supplierCode, supplierName, billingPeriodMonth, billingPeriod, invoiceNumber));
	}

	@Override
	public MiscBillingTrnInvoice updateInvoice(MiscBillingTrnInvoice miscBillingTrnInvoice) {
		miscBillingInvoiceDao.findById(miscBillingTrnInvoice.getInvoiceUrn())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(miscBillingTrnInvoice.getInvoiceUrn())));
		return miscBillingInvoiceMapper.mapToModel(
				miscBillingInvoiceDao.updateInvoice(miscBillingInvoiceMapper.mapToEntity(miscBillingTrnInvoice)));
	}

	@Override
	public StatusRequest updateStatus(StatusRequest statusRequest, String level) {
		return miscBillingInvoiceDao.updateStatus(statusRequest, level);
	}

	
	@Override
	public List<MiscBillingTrnInvoice> createRejectedInvoice(Optional<List<String>> invoiceUrns) {
		
		List<MiscBillingTrnInvoiceEntity> trnInvoiceEntityList = miscBillingInvoiceDao.getRejectedInvoice(invoiceUrns);
		List<MiscBillingTrnInvoiceEntity> coppiedInvList = new ArrayList<>();
		String prevInvoiceUrn = "";
		String invoiceUrn = "";
		List<MiscBillingInvLineitemEntity> rejectedLineItemList;
		List<MiscBillingTrnInvoiceEntity> rejectedInvErrorList=null;
		Map<String, String> batchInvoiceMap = new HashMap<>();

		if (CollectionUtils.isNotEmpty(trnInvoiceEntityList)) {
			for (MiscBillingTrnInvoiceEntity entity : trnInvoiceEntityList) {
				Boolean flag = rejectionStage(entity);
				log.info("RejectionStage flag : " + flag);
				if (flag) {
					batchInvoiceMap.put(entity.getInvoiceUrn(), entity.getInvoiceNumber());
					coppiedInvList.add(entity);
				} else {
					log.info("RejectionStage flag else : " + flag);
					rejectedInvErrorList = new ArrayList<>();
					rejectedInvErrorList.add(entity);
					log.info("rejectedInvErrorList  : " + rejectedInvErrorList.size());
				}
			}
		}
		log.info("batchInvoiceMap : " + batchInvoiceMap);
		
		List<MiscBillingTrnInvoiceEntity> rejectedInvList = new ArrayList<>();
		String description;
		MiscBillingTrnInvoiceEntity entityRejected;
		Map<String, String> newBatchInvoiceMap = new HashMap<>();
		
		if (CollectionUtils.isNotEmpty(coppiedInvList)) {
			for (MiscBillingTrnInvoiceEntity entity2 : coppiedInvList) {
				log.info("RejectionStage coppiedInvList : " + entity2.getRejectionStage());
				entityRejected = new MiscBillingTrnInvoiceEntity(); 
				Integer rejectionStage = entity2.getRejectionStage() == null ? 1 : entity2.getRejectionStage() + 1;
				entityRejected.setRejectionStage(rejectionStage);
				
				invoiceUrn = getInvoiceUrn(invoiceUrn, prevInvoiceUrn, entity2);
				
				log.info("Outward invoiceUrn  = " + invoiceUrn);
				description = entity2.getDescription();
				List<MiscBillingInvLineitemEntity> lineItemList = entity2.getMiscBillingInvLineitem();
				rejectedLineItemList = new ArrayList<>();
				entityRejected.setInvoiceUrn(invoiceUrn);
				
				newBatchInvoiceMap.put(invoiceUrn, entity2.getInvoiceNumber());
				
				populateRejectionEntity(entityRejected, entity2);
				
				int lineItemNum = 1;
				BigDecimal lineItemSumAddOnChargeRejected = MiscBillingConstants.BIGDECIMAL_ZERO;
				BigDecimal lineItemSumVatRejected = MiscBillingConstants.BIGDECIMAL_ZERO;
				BigDecimal lineItemSumTaxRejected = MiscBillingConstants.BIGDECIMAL_ZERO;
				MiscBillingInvLineitemEntity rejectionLineitemEntity = null;
				if (CollectionUtils.isNotEmpty(lineItemList)) {
					for (MiscBillingInvLineitemEntity lineitemEntity : lineItemList) {
						log.info("lineItemList for loop");
						rejectionLineitemEntity = new MiscBillingInvLineitemEntity();
						
						if (StringUtils.isNotEmpty(lineitemEntity.getRejectionReasonCode())
								&& lineitemEntity.getNetAmountRejected().compareTo(BigDecimal.ZERO) != 0) {

							rejectionLineitemEntity.setLineItemNumber(lineItemNum);
							if (StringUtils.isEmpty(description)) {
								description = lineitemEntity.getDescription();
							}

							lineItemSumAddOnChargeRejected = lineItemSumAddOnChargeRejected.add(MiscBillingCommonUtil
									.getBigDecimalValue(lineitemEntity.getTotAddonChargeAmtRejected()));
							lineItemSumVatRejected = lineItemSumVatRejected.add(MiscBillingCommonUtil
									.getBigDecimalValue(lineitemEntity.getTotalVatAmountRejected()));
							lineItemSumTaxRejected = lineItemSumTaxRejected.add(MiscBillingCommonUtil
									.getBigDecimalValue(lineitemEntity.getTotalTaxAmountRejected()));
							rejectionLineitemEntity.setTotalNetAmount(MiscBillingCommonUtil
									.getBigDecimalValue(lineitemEntity.getChargeAmountRejected())
									.add(MiscBillingCommonUtil
											.getBigDecimalValue(lineitemEntity.getTotAddonChargeAmtRejected()))
									.add(MiscBillingCommonUtil.getBigDecimalValue(lineitemEntity.getTotalTaxAmountRejected()))
									.add(MiscBillingCommonUtil.getBigDecimalValue(lineitemEntity.getTotalVatAmountRejected())));
							
							populateLineItemEntity(rejectionLineitemEntity, lineitemEntity);
							
							rejectionLineitemEntity.setMiscBillingTrnInvoice(entityRejected);
							// get line item tax dtl
							if (CollectionUtils.isNotEmpty(lineitemEntity.getMiscBillingTaxDetails())) {
								log.info("lineItemList Tax details ");
								rejectionLineitemEntity.setMiscBillingTaxDetails(getEligibleRejectedTaxLineItemLevel(
										lineitemEntity.getMiscBillingTaxDetails(), entityRejected,
										rejectionLineitemEntity, lineitemEntity.getInvLineItemId()));
							}
							// get line item addOn charge dtl
							if (CollectionUtils.isNotEmpty(lineitemEntity.getMiscBillingAddOnChargeDtl())) {
								rejectionLineitemEntity
										.setMiscBillingAddOnChargeDtl(getEligibleRejectedAddOnLineItemLevel(
												lineitemEntity.getMiscBillingAddOnChargeDtl(), entityRejected,
												rejectionLineitemEntity, lineitemEntity.getInvLineItemId()));
							}
							rejectedLineItemList.add(rejectionLineitemEntity);
							lineItemNum++;
						}
					}
				}
				entityRejected.setMiscBillingInvLineitem(rejectedLineItemList);
				
				entityRejected.setTotalAddonChargeAmount(lineItemSumAddOnChargeRejected.add(entity2.getTotalAddonChargeAmountRejected()));
				entityRejected.setTotalVatAmount(lineItemSumVatRejected.add(entity2.getTotalVatAmountRejected()));
				entityRejected.setTotalTaxAmount(lineItemSumTaxRejected.add(entity2.getTotalTaxAmountRejected()));
				
				//Inv level tax details
				if (CollectionUtils.isNotEmpty(entity2.getMiscBillingTaxDetails())) {
					entityRejected.setMiscBillingTaxDetails(getEligibleRejectedTaxInvLevel(
							entity2.getMiscBillingTaxDetails(), entityRejected));
				}
				
				//Inv level addOn charge details
				if (CollectionUtils.isNotEmpty(entity2.getMiscBillingAddOnChargeDtl())) {
					entityRejected.setMiscBillingAddOnChargeDtl(
							getEligibleRejectedAddOnInvLevel(entity2.getMiscBillingAddOnChargeDtl(), entityRejected));
				}
				entityRejected.setDescription(description);
				
				prevInvoiceUrn = invoiceUrn;
				rejectedInvList.add(entityRejected);
			}
		}
		log.info("rejectedInvList final = " + rejectedInvList.size());
		List<MiscBillingTrnInvoiceEntity> rejectedInovics = miscBillingInvoiceDao.captureInvoices(rejectedInvList);
		updateRejectedInvoiceNumber(rejectedInovics, newBatchInvoiceMap, batchInvoiceMap);
		
		List<MiscBillingTrnInvoice> miscBillingTrnErrorInvoice=null;
		if(CollectionUtils.isNotEmpty(rejectedInvErrorList)) {
			log.info("rejectedInvErrorList final " + rejectedInvErrorList);
			miscBillingTrnErrorInvoice = miscBillingInvoiceMapper.mapToModel(rejectedInvErrorList);
		}
		return miscBillingTrnErrorInvoice;
	}
	
	private String getInvoiceUrn(String invoiceUrn,String prevInvoiceUrn, MiscBillingTrnInvoiceEntity entity2 ) {
		if (StringUtils.isEmpty(invoiceUrn)) {
			return invoiceUrn = miscBillingCommonService.generateOutwardBatchNo(entity2.getClientId());
		} else {
			return invoiceUrn = MiscBillingCommonUtil.getNextBatchNo(prevInvoiceUrn);
		}
	}
	//update inv entity
	private void populateRejectionEntity(MiscBillingTrnInvoiceEntity entityRejected,
			MiscBillingTrnInvoiceEntity entity2) {
		entityRejected.setClientId(entity2.getClientId());
		entityRejected.setInvoiceType(entity2.getInvoiceType());
		entityRejected.setChargeCategoryCode(entity2.getChargeCategoryCode());
		entityRejected.setCurrencyCode(entity2.getCurrencyCode());
		entityRejected.setClearanceCurrencyCode(entity2.getClearanceCurrencyCode());
		entityRejected.setDigitalSignatureFlag(entity2.getDigitalSignatureFlag());
		entityRejected.setInvoiceDate(new Date());// current date
		entityRejected.setInwardOutwardFlag(MiscBillingConstants.OUTWARD_FLAG);
		entityRejected.setInvoiceStatus(StatusEnum.EVALUATED.getStatusEnumValue());
		entityRejected.setOriginalInvoiceNumber(entity2.getInvoiceNumber());
		entityRejected.setJvReferenceNumber(null);
		entityRejected.setCorrespondanceFlag("N");
		entityRejected.setAuthorityToBillFlag(null);
		entityRejected.setCorrespondanceRefNo(null);
		entityRejected.setOriginalBillingPeriod(entity2.getBillingPeriod());
		entityRejected.setOrginalBillingMonth(entity2.getBillingMonth());
		entityRejected.setLineItemCount(entity2.getLineItemCount());
		entityRejected.setBuyerOrganizationId(entity2.getSellerOrganizationId());// byerid
		entityRejected.setBuyerLocationId(entity2.getSellerLocationId());
		entityRejected.setSupplierType(entity2.getSupplierType());
		entityRejected.setSupplierName(entity2.getSupplierName());
		
		// new derivations
		entityRejected.setTotalLineItemAmount(entity2.getChargeAmountRejected());
		entityRejected.setAddonChargeAmount(entity2.getTotalAddonChargeAmountRejected());
		entityRejected.setVatAmount(entity2.getTotalVatAmountRejected());
		entityRejected.setTaxAmount(entity2.getTotalTaxAmountRejected());
		BigDecimal totalAmount = MiscBillingCommonUtil.getBigDecimalValue(entity2.getChargeAmountRejected())
				.add(MiscBillingCommonUtil.getBigDecimalValue(entity2.getTotalVatAmountRejected()))
				.add(MiscBillingCommonUtil.getBigDecimalValue(entity2.getTotalTaxAmountRejected()))
				.add(MiscBillingCommonUtil.getBigDecimalValue(entity2.getTotalAddonChargeAmountRejected()));
		entityRejected.setTotalAmount(totalAmount);

		SystemParameter sysParam = masterFeignClient.getSystemParameterByparameterNameAndClientId(
				MiscBillingConstants.DEFAULT_CARRIER_NUMERIC_CODE, entity2.getClientId());
		entityRejected.setSellerOrganizationId((sysParam != null && sysParam.getParameterRangeFrom().isPresent())
				? sysParam.getParameterRangeFrom().get()
				: null);// host carrier code
		entityRejected.setSellerLocationId(entity2.getBuyerLocationId());
		OutwardBillingPeriods outwardBillingPeriods = masterFeignClient
				.getCurrentOpenOutwardBillingPeriods(entity2.getClientId());
		entityRejected.setBillingMonth(
				outwardBillingPeriods != null ? outwardBillingPeriods.getBillingMonth().toUpperCase() : null);
		entityRejected
				.setBillingPeriod(outwardBillingPeriods != null ? outwardBillingPeriods.getBillingPeriod() : null);

		if (outwardBillingPeriods != null && outwardBillingPeriods.getBillingPeriod() == null) {
			entityRejected.setSettlementMonthPeriod(
					MiscBillingUtil.convertToSettlementMonthPeriod(outwardBillingPeriods.getBillingMonth(), 1));
		} else if (outwardBillingPeriods != null) {
			entityRejected.setSettlementMonthPeriod(MiscBillingUtil.convertToSettlementMonthPeriod(
					outwardBillingPeriods.getBillingMonth(), outwardBillingPeriods.getBillingPeriod()));
		}
		entityRejected.setSettlementMethod(entity2.getSettlementMethod());

		// Excahnge rate
		CurrencyRateIn currencyRateIn = new CurrencyRateIn();
		String baseCurrency = this.getBaseCurrency(masterFeignClient, entity2.getClientId());
		currencyRateIn.setClientId(Optional.of(entity2.getClientId()));
		currencyRateIn.setCurrencyFromCode(Optional.ofNullable(entity2.getCurrencyCode()));
		currencyRateIn.setCurrencyToCode(Optional.ofNullable(baseCurrency));
		currencyRateIn.setRateType(Optional.of(MiscBillingConstants.RATE_TYPE_BKR));
		
		String invoiceDate = new SimpleDateFormat("yyyy-MM-dd").format(entityRejected.getInvoiceDate());
		
		currencyRateIn.setAmount(Optional.ofNullable(entityRejected.getTotalAmount()));
		currencyRateIn.setConversionDate(Optional.ofNullable(invoiceDate));
		CurrencyRateOut currencyRateOut=null;
		try {
			currencyRateOut = exchangeRateFeignClient.getExchangeRate(currencyRateIn);

			entityRejected.setBaseCurrency(baseCurrency);

			if (currencyRateOut != null && StringUtils.isEmpty(currencyRateOut.getErrorCode())) {
				entityRejected.setAmountBaseCurrency(currencyRateOut.getOutAmount());
				entityRejected.setExchangeRate(currencyRateOut.getExchangeRate());
			} else {
				// raise error MISC9002
				logException(entity2.getCurrencyCode(), baseCurrency, invoiceDate, entity2);
			}
		} catch (ServiceException se) {
			log.error("Record not found for BKR " + entity2.getCurrencyCode() + " - BaseCurrency: " + baseCurrency
					+ " and invoiceDate: " + invoiceDate);
			logException(entity2.getCurrencyCode(), baseCurrency, invoiceDate, entity2);
		} catch (Exception e) {
			log.error("Exception thrown while getting data for BKR currency - method getExchangeRate(currencyRateIn).");
			logException(entity2.getCurrencyCode(), baseCurrency, invoiceDate, entity2);
		}

	}

	// update line item entity
	private void populateLineItemEntity(MiscBillingInvLineitemEntity rejectionLineitemEntity,
			MiscBillingInvLineitemEntity lineitemEntity) {
		rejectionLineitemEntity.setOriginalLineItemNumber(lineitemEntity.getLineItemNumber());
		rejectionLineitemEntity.setProcessStatus(StatusEnum.EVALUATED.getStatusEnumValue());
		rejectionLineitemEntity.setChargeAmount(lineitemEntity.getChargeAmountRejected());
		rejectionLineitemEntity.setTaxAmount(lineitemEntity.getTotalTaxAmountRejected());
		rejectionLineitemEntity.setVatAmount(lineitemEntity.getTotalVatAmountRejected());
		rejectionLineitemEntity.setAddonChargeAmount(lineitemEntity.getTotAddonChargeAmtRejected());
		rejectionLineitemEntity.setTotalAddonChargeAmount(lineitemEntity.getTotAddonChargeAmtRejected());
		rejectionLineitemEntity.setTotalTaxAmount(lineitemEntity.getTotalTaxAmountRejected());
		rejectionLineitemEntity.setTotalVatAmount(lineitemEntity.getTotalVatAmountRejected());
		
		rejectionLineitemEntity.setChargeCode(lineitemEntity.getChargeCode());
		rejectionLineitemEntity.setChargeCatCode(lineitemEntity.getChargeCatCode());
		rejectionLineitemEntity.setDescription(lineitemEntity.getDescription());
		rejectionLineitemEntity.setRejectionReasonCode(lineitemEntity.getRejectionReasonCode());
		rejectionLineitemEntity.setEndDate(lineitemEntity.getEndDate());
		rejectionLineitemEntity.setLocationCode(lineitemEntity.getLocationCode());
		rejectionLineitemEntity.setQuantity(new BigDecimal(1));
		rejectionLineitemEntity.setUomCode("EA");
		rejectionLineitemEntity.setUnitPrice(lineitemEntity.getChargeAmountRejected());
		rejectionLineitemEntity.setScallingFactor("1");
		rejectionLineitemEntity.setDetailCount(0);
		rejectionLineitemEntity.setChargeCodeType(lineitemEntity.getChargeCodeType());

	}
	private List<MiscBillingTaxDetailsEntity> getEligibleRejectedTaxInvLevel(
			List<MiscBillingTaxDetailsEntity> taxDtlEntity, MiscBillingTrnInvoiceEntity entity) {
		List<MiscBillingTaxDetailsEntity> taxDetailsList = new ArrayList<>();
		MiscBillingTaxDetailsEntity rejectionTaxDtl = null;
		int invSeq = 1;

		for (MiscBillingTaxDetailsEntity taxDtl : taxDtlEntity) {
			rejectionTaxDtl = new MiscBillingTaxDetailsEntity();
			if (taxDtl.getTaxLevel().equalsIgnoreCase(INVOICE)) {
				rejectionTaxDtl.setMiscBillingTrnInvoice(entity);
				
				rejectionTaxDtl.setTaxType(taxDtl.getTaxType());
				rejectionTaxDtl.setTaxSubType(taxDtl.getTaxSubType());
				rejectionTaxDtl.setTaxCategory(taxDtl.getTaxCategory());
				rejectionTaxDtl.setTaxText(taxDtl.getTaxText());
				rejectionTaxDtl.setTaxLevel(taxDtl.getTaxLevel());
				rejectionTaxDtl.setRecordSeqNumber(invSeq);
				
				rejectionTaxDtl.setTaxAmount(taxDtl.getTaxAmountRejected());
				invSeq++;
				taxDetailsList.add(rejectionTaxDtl);
			}

		}
		return taxDetailsList;
	}

	private List<MiscBillingTaxDetailsEntity> getEligibleRejectedTaxLineItemLevel(
			List<MiscBillingTaxDetailsEntity> taxDtlEntity, MiscBillingTrnInvoiceEntity entity,
			MiscBillingInvLineitemEntity lineItemEntity, Integer lineItemId) {

		log.info("Enter getEligibleRejectedTaxLineItemLevel  >>> ");
		List<MiscBillingTaxDetailsEntity> taxDetailsList = new ArrayList<>();
		MiscBillingTaxDetailsEntity rejectionTaxDtl = null;
		int lineSeq = 1;

		for (MiscBillingTaxDetailsEntity taxDtl : taxDtlEntity) {
			rejectionTaxDtl = new MiscBillingTaxDetailsEntity();
			if (taxDtl.getTaxLevel().equalsIgnoreCase(LINE_ITEM) && (taxDtl.getMiscBillingInvLineitem() != null
					&& lineItemId == taxDtl.getMiscBillingInvLineitem().getInvLineItemId())) {
				rejectionTaxDtl.setMiscBillingTrnInvoice(entity);
				rejectionTaxDtl.setRecordSeqNumber(lineSeq);
				
				rejectionTaxDtl.setTaxType(taxDtl.getTaxType());
				rejectionTaxDtl.setTaxSubType(taxDtl.getTaxSubType());
				rejectionTaxDtl.setTaxCategory(taxDtl.getTaxCategory());
				rejectionTaxDtl.setTaxText(taxDtl.getTaxText());
				rejectionTaxDtl.setTaxLevel(taxDtl.getTaxLevel());
				
				rejectionTaxDtl.setTaxAmount(taxDtl.getTaxAmountRejected());
				rejectionTaxDtl.setMiscBillingInvLineitem(lineItemEntity);
				lineSeq++;
				taxDetailsList.add(rejectionTaxDtl);
			}
		}

		log.info("<<< Exit getEligibleRejectedTaxLineItemLevel ");
		return taxDetailsList;
	}

	private List<MiscBillingAddOnChargeDtlEntity> getEligibleRejectedAddOnInvLevel(
			List<MiscBillingAddOnChargeDtlEntity> addonDtlEntity, MiscBillingTrnInvoiceEntity entity) {
		log.info("Enter getEligibleRejectedAddOnInvLevel >>>");
		List<MiscBillingAddOnChargeDtlEntity> addOnDetailsList = new ArrayList<>();
		int invSeq = 1;
		MiscBillingAddOnChargeDtlEntity rejectedAddOnDtl=null;
		for (MiscBillingAddOnChargeDtlEntity addOnDtl : addonDtlEntity) {
			rejectedAddOnDtl = new MiscBillingAddOnChargeDtlEntity();
			if (addOnDtl.getAddOnLevel().equalsIgnoreCase(INVOICE)) {
				rejectedAddOnDtl.setMiscBillingTrnInvoice(entity);
				rejectedAddOnDtl.setRecordSeqNumber(invSeq);
				rejectedAddOnDtl.setAddOnChargeName(addOnDtl.getAddOnChargeName());
				rejectedAddOnDtl.setAddOnLevel(addOnDtl.getAddOnLevel());
				rejectedAddOnDtl.setAddOnChargeAmount(addOnDtl.getAddonChargeRejected());
				invSeq++;
				addOnDetailsList.add(rejectedAddOnDtl);
			}

		}
		log.info("<<< Exit  getEligibleRejectedAddOnInvLevel");
		return addOnDetailsList;
	}

	private List<MiscBillingAddOnChargeDtlEntity> getEligibleRejectedAddOnLineItemLevel(
			List<MiscBillingAddOnChargeDtlEntity> addonDtlEntity, MiscBillingTrnInvoiceEntity entiry,
			MiscBillingInvLineitemEntity lineItemEntity, Integer lineItemId) {
		log.info("Enter  getEligibleRejectedAddOnLineItemLevel >>> ");
		List<MiscBillingAddOnChargeDtlEntity> addOnDetailsList = new ArrayList<>();
		MiscBillingAddOnChargeDtlEntity rejectedAddOnDtl=null;
		int lineSeq = 1;
		for (MiscBillingAddOnChargeDtlEntity addOnDtl : addonDtlEntity) {
			rejectedAddOnDtl = new MiscBillingAddOnChargeDtlEntity();
			if (addOnDtl.getAddOnLevel().equalsIgnoreCase(LINE_ITEM) && (addOnDtl.getMiscBillingInvLineitem() != null
					&& lineItemId == addOnDtl.getMiscBillingInvLineitem().getInvLineItemId())) {
				
				rejectedAddOnDtl.setMiscBillingTrnInvoice(entiry);
				rejectedAddOnDtl.setRecordSeqNumber(lineSeq);
				
				rejectedAddOnDtl.setMiscBillingInvLineitem(lineItemEntity);
				rejectedAddOnDtl.setAddOnChargeName(addOnDtl.getAddOnChargeName());
				rejectedAddOnDtl.setAddOnLevel(addOnDtl.getAddOnLevel());
				rejectedAddOnDtl.setAddOnChargeAmount(addOnDtl.getAddonChargeRejected());
				lineSeq++;
				addOnDetailsList.add(rejectedAddOnDtl);
			}
		}
		log.info("<<< Exit  getEligibleRejectedAddOnInvLevel");
		return addOnDetailsList;
	}
	
	@Override
	public List<MiscBillingTrnInvoice> getOutwardInvoicesByBillingMonth(String clientId, String billingMonth, 
			Optional<Integer> billingPeriod, Optional<String> invoiceNumber, Optional<String> carrierCode, Optional<String> supplierType){
		List<MiscBillingTrnInvoice> invoiceList = miscBillingInvoiceMapper.mapToMiscBillingTrnInvoice(miscBillingInvoiceDao
				.getOutwardInvoicesByBillingMonth(clientId, billingMonth, billingPeriod, invoiceNumber, carrierCode, supplierType));
		return invoiceList;
	}

	@Override
	public String processInvoices(String billingMonth, Integer billingPeriod, String clientId) {
		String msg = "Success";
		String fy = getCurrentFy(clientId);
		if(StringUtils.isNotBlank(fy)) {
			List<MiscBillingTrnInvoiceEntity> invoiceEntityList = miscBillingInvoiceDao.processInvoices(billingMonth, billingPeriod, clientId);
			if(invoiceEntityList != null && !invoiceEntityList.isEmpty()) {
				try {
					for (MiscBillingTrnInvoiceEntity invoiceEntity : invoiceEntityList) {
						Carrier carrier = smartpraGlobalMasterAppClient.getCarrierByCarrierCode(invoiceEntity.getBuyerOrganizationId());
						Optional<String> optCarrierDesignatorCode;
						String carrierDesignatorCode = "";
						if(carrier != null) {
							optCarrierDesignatorCode = carrier.getCarrierDesignatorCode();
							if(optCarrierDesignatorCode.isPresent()) {
								carrierDesignatorCode = optCarrierDesignatorCode.get();
							}
							String invoiceNo = this.generateInvoiceNo(clientId, fy, carrierDesignatorCode);
							invoiceEntity.setInvoiceNumber(invoiceNo);
							invoiceEntity.setInvoiceStatus("BI");
						} else {
							msg = "Invalid carrierCode: " + invoiceEntity.getBuyerOrganizationId();
							return msg;
						}
					}
				} catch (Exception e) {
					msg = "Error thrown while generating invoice numbers.";
					return msg;
				}
			} else {
				msg = "Zero invoices retrieved for the given billingMonth, billingPeriod and clientId.";
			}
		} else {
			msg = "Error thown while retrieving financial year. getCurrentOpenFinancialMonthForFinancialCalendar(clientId) failed.";
		}
		return msg;
	}
	
	@Override
	public String getCurrentFy(String clientId) {
		FinancialMonthModel financialMonthModel = null;
		String fy = MiscBillingConstants.EMPTY_STRING;
		try {
			financialMonthModel = masterFeignClient.getCurrentOpenFinancialMonthForFinancialCalendar(clientId);
		} catch (Exception e) {
			log.error("Error thrown while calling method getCurrentOpenFinancialMonthForFinancialCalendar() " + e.getMessage());
			e.printStackTrace();
		}
		if(financialMonthModel != null) {
			fy = financialMonthModel.getFinancialYear().substring(0,2).toUpperCase();
		}
		return fy;
	}
	
	@Override
	public String generateInvoiceNo(String clientId, String fy, String carrierCode) {
		log.debug("Start of generateInvoiceNo() " + carrierCode);
		String invoiceNo;
		String maxInvoiceNo = miscBillingInvoiceDao.getMaxInvoiceNo(clientId, fy, carrierCode);

		if(StringUtils.isBlank(maxInvoiceNo)) {
			invoiceNo = new StringBuffer("M").append(carrierCode).append(fy).append("00001").toString();
		} else {
			Integer subInv = Integer.parseInt(maxInvoiceNo.substring(5));
			subInv++;
			String invoiceSeq = getInvoiceSeq(subInv);
			invoiceNo = new StringBuffer("M").append(carrierCode).append(fy).append(invoiceSeq).toString();
		}
		log.debug("End of generateInvoiceNo() " + invoiceNo);
		return invoiceNo;
	}
	
	@Override
	public String getInvoiceSeq(Integer subInv) {
		String invoiceSeq;
		String subStr = subInv.toString();
		// 00001, 00011, 00111, 01111, 11111
		if(subStr.length() == 1) {
			invoiceSeq = "0000" + subStr; 
		} else if(subStr.length() == 2) {
			invoiceSeq = "000" + subStr;
		} else if(subStr.length() == 3) {
			invoiceSeq = "00" + subStr;
		} else if(subStr.length() == 4) {
			invoiceSeq = "0" + subStr;
		} else {
			invoiceSeq = subStr;
		}
		return invoiceSeq;
	}
	
	private MiscBillingTrnInvoiceEntity setInvoiceUrnInLineItem(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity) {
		miscBillingTrnInvoiceEntity.setMiscBillingTaxDetails(setInvoiceUrnInTax(miscBillingTrnInvoiceEntity.getMiscBillingTaxDetails(), miscBillingTrnInvoiceEntity, null, null));
		miscBillingTrnInvoiceEntity.setMiscBillingAddOnChargeDtl(setInvoiceUrnInAddOnCharge(miscBillingTrnInvoiceEntity.getMiscBillingAddOnChargeDtl(), miscBillingTrnInvoiceEntity, null, null));
		miscBillingTrnInvoiceEntity.getMiscBillingInvLineitem().stream().filter(Objects::nonNull).forEach(lineItem -> {
			lineItem.setMiscBillingTrnInvoice(miscBillingTrnInvoiceEntity);
			lineItem.setMiscBillingTaxDetails(setInvoiceUrnInTax(lineItem.getMiscBillingTaxDetails(), miscBillingTrnInvoiceEntity, lineItem, null));
			lineItem.setMiscBillingAddOnChargeDtl(setInvoiceUrnInAddOnCharge(lineItem.getMiscBillingAddOnChargeDtl(), miscBillingTrnInvoiceEntity, lineItem, null));
			lineItem.getMiscBillingLineitemDetails().stream().filter(Objects::nonNull).forEach(lineItemDetails -> {
				lineItemDetails.setMiscBillingInvLineitem(lineItem);
				lineItemDetails.setMiscBillingTaxDetails(setInvoiceUrnInTax(lineItemDetails.getMiscBillingTaxDetails(),miscBillingTrnInvoiceEntity, null, lineItemDetails));
				lineItemDetails.setMiscBillingAddOnChargeDtl(setInvoiceUrnInAddOnCharge(lineItemDetails.getMiscBillingAddOnChargeDtl(),miscBillingTrnInvoiceEntity, null, lineItemDetails));
				lineItemDetails.getMiscBillingSupportingDetail().stream().filter(Objects::nonNull).forEach(lineItemSupportingDetails -> {
					lineItemSupportingDetails.setMiscBillingInvLineitemDtl(lineItemDetails);
				});
			});
		});
		return miscBillingTrnInvoiceEntity;
	}
	
	private List<MiscBillingTaxDetailsEntity> setInvoiceUrnInTax(List<MiscBillingTaxDetailsEntity> miscBillingTaxDetailsEntity,MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity,
			MiscBillingInvLineitemEntity miscBillingInvLineitemEntity,MiscBillingInvLineitemDtlEntity miscBillingInvLineitemDtlEntity) {
		miscBillingTaxDetailsEntity.stream().filter(Objects::nonNull).forEach(taxDetails -> {
		taxDetails.setMiscBillingTrnInvoice(miscBillingTrnInvoiceEntity);
		taxDetails.setMiscBillingInvLineitem(miscBillingInvLineitemEntity);
		taxDetails.setMiscBillingInvLineitemDtl(miscBillingInvLineitemDtlEntity);
		});
		return miscBillingTaxDetailsEntity; 
	}
	
	private List<MiscBillingAddOnChargeDtlEntity> setInvoiceUrnInAddOnCharge(List<MiscBillingAddOnChargeDtlEntity> miscBillingAddOnChargeDtlEntity,MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity,
			MiscBillingInvLineitemEntity miscBillingInvLineitemEntity,MiscBillingInvLineitemDtlEntity miscBillingInvLineitemDtlEntity) {
		miscBillingAddOnChargeDtlEntity.stream().filter(Objects::nonNull).forEach(addOnCharge -> {
		addOnCharge.setMiscBillingTrnInvoice(miscBillingTrnInvoiceEntity);
		addOnCharge.setMiscBillingInvLineitem(miscBillingInvLineitemEntity);
		addOnCharge.setMiscBillingInvLineitemDtl(miscBillingInvLineitemDtlEntity);
		});
		return miscBillingAddOnChargeDtlEntity; 
	}

	@Override
	public List<MiscBillingTrnInvoice> confirmInvoice(Optional<List<String>> invoiceUrns) {
		List<MiscBillingTrnInvoiceEntity> confirmInvoiceList =  new ArrayList<>();
		List<String> batchKeys = new ArrayList<>();
		if(invoiceUrns.isPresent()) batchKeys = invoiceUrns.get();
		for (String invoiceUrn : batchKeys) {
			BigDecimal chargeAmountTotalAcceptedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			BigDecimal chargeAmountTotalRejectedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			BigDecimal taxAmountTotalAcceptedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			BigDecimal taxAmountTotalRejectedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			BigDecimal vatAmountTotalAcceptedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			BigDecimal vatAmountTotalRejectedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			BigDecimal addOnAmountTotalAcceptedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			BigDecimal addOnAmountTotalRejectedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			BigDecimal netAmountTotalAcceptedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			BigDecimal netAmountTotalRejectedInvoice = MiscBillingConstants.BIGDECIMAL_ZERO;
			
			MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity = miscBillingInvoiceDao.findById(invoiceUrn)
					.orElseThrow(() -> new RecordNotFoundException(String.valueOf(invoiceUrn)));
			if (CollectionUtils.isNotEmpty(miscBillingTrnInvoiceEntity.getMiscBillingInvLineitem())) {

				for (MiscBillingInvLineitemEntity miscBillingInvLineitemEntity : miscBillingTrnInvoiceEntity
						.getMiscBillingInvLineitem()) {

					//Charge Amount Confirmation logic
					if(miscBillingInvLineitemEntity.getChargeAmount() != MiscBillingConstants.BIGDECIMAL_NULL) {
					if (miscBillingInvLineitemEntity.getChargeAmountAccepted() == MiscBillingConstants.BIGDECIMAL_NULL
							&& miscBillingInvLineitemEntity
									.getChargeAmountRejected() == MiscBillingConstants.BIGDECIMAL_NULL) {
						miscBillingInvLineitemEntity
								.setChargeAmountAccepted(miscBillingInvLineitemEntity.getChargeAmount());
					}						
							miscBillingInvLineitemEntity
									.setChargeAmountRejected(miscBillingInvLineitemEntity.getChargeAmount()
											.subtract(miscBillingInvLineitemEntity.getChargeAmountAccepted()));
							chargeAmountTotalAcceptedInvoice = chargeAmountTotalAcceptedInvoice
									.add(miscBillingInvLineitemEntity.getChargeAmountAccepted());
							chargeAmountTotalRejectedInvoice = chargeAmountTotalRejectedInvoice
									.add(miscBillingInvLineitemEntity.getChargeAmountRejected());

					}
					//Tax Amount Confirmation logic
					if(miscBillingInvLineitemEntity.getTotalTaxAmount()!=MiscBillingConstants.BIGDECIMAL_NULL) {
					if (miscBillingInvLineitemEntity.getTotalTaxAmountAccepted() == MiscBillingConstants.BIGDECIMAL_NULL
							&& miscBillingInvLineitemEntity
									.getTotalTaxAmountRejected() == MiscBillingConstants.BIGDECIMAL_NULL) {
						miscBillingInvLineitemEntity
								.setTotalTaxAmountAccepted(miscBillingInvLineitemEntity.getTotalTaxAmount());
						
					} 
							
					miscBillingInvLineitemEntity
									.setTotalTaxAmountRejected(miscBillingInvLineitemEntity.getTotalTaxAmount()
											.subtract(miscBillingInvLineitemEntity.getTotalTaxAmountAccepted()));
					taxAmountTotalAcceptedInvoice = taxAmountTotalAcceptedInvoice
							.add(miscBillingInvLineitemEntity.getTotalTaxAmountAccepted());
					taxAmountTotalRejectedInvoice = taxAmountTotalRejectedInvoice
							.add(miscBillingInvLineitemEntity.getTotalTaxAmountRejected());
					}
					
					//vat Amount Confirmation logic
					if(miscBillingInvLineitemEntity.getTotalVatAmount()!=MiscBillingConstants.BIGDECIMAL_NULL) {
					if (miscBillingInvLineitemEntity.getTotalVatAmountAccepted() == MiscBillingConstants.BIGDECIMAL_NULL
							&& miscBillingInvLineitemEntity
									.getTotalVatAmountRejected() == MiscBillingConstants.BIGDECIMAL_NULL) {
						miscBillingInvLineitemEntity
								.setTotalVatAmountAccepted(miscBillingInvLineitemEntity.getTotalVatAmount());
						
						
					} 
							
					miscBillingInvLineitemEntity
									.setTotalVatAmountRejected(miscBillingInvLineitemEntity.getTotalVatAmount()
											.subtract(miscBillingInvLineitemEntity.getTotalVatAmountAccepted()));
					vatAmountTotalAcceptedInvoice = vatAmountTotalAcceptedInvoice
							.add(miscBillingInvLineitemEntity.getTotalVatAmountAccepted());
					vatAmountTotalRejectedInvoice = vatAmountTotalRejectedInvoice
							.add(miscBillingInvLineitemEntity.getTotalVatAmountRejected());
					}
					
					//Add On  Amount Confirmation logic
					if(miscBillingInvLineitemEntity.getTotalAddonChargeAmount()!=MiscBillingConstants.BIGDECIMAL_NULL) {
					if (miscBillingInvLineitemEntity.getTotAddonChargeAmtAccepted() == MiscBillingConstants.BIGDECIMAL_NULL
							&& miscBillingInvLineitemEntity
									.getTotAddonChargeAmtRejected() == MiscBillingConstants.BIGDECIMAL_NULL) {
						miscBillingInvLineitemEntity
								.setTotAddonChargeAmtAccepted(miscBillingInvLineitemEntity.getTotalAddonChargeAmount());
					} 
							
					miscBillingInvLineitemEntity
									.setTotAddonChargeAmtRejected(miscBillingInvLineitemEntity.getTotalAddonChargeAmount()
											.subtract(miscBillingInvLineitemEntity.getTotAddonChargeAmtAccepted()));
					addOnAmountTotalAcceptedInvoice = addOnAmountTotalAcceptedInvoice
							.add(miscBillingInvLineitemEntity.getTotAddonChargeAmtAccepted());
					addOnAmountTotalRejectedInvoice = addOnAmountTotalRejectedInvoice
							.add(miscBillingInvLineitemEntity.getTotAddonChargeAmtRejected());
					}
					//Net  Amount Confirmation logic
					if(miscBillingInvLineitemEntity.getTotalNetAmount()!=MiscBillingConstants.BIGDECIMAL_NULL) {
					if (miscBillingInvLineitemEntity.getNetAmountAccepted() == MiscBillingConstants.BIGDECIMAL_NULL
							&& miscBillingInvLineitemEntity
									.getNetAmountRejected() == MiscBillingConstants.BIGDECIMAL_NULL) {
						miscBillingInvLineitemEntity
								.setNetAmountAccepted(miscBillingInvLineitemEntity.getTotalNetAmount());
						
						
					} 
							
					miscBillingInvLineitemEntity
									.setNetAmountRejected(miscBillingInvLineitemEntity.getTotalNetAmount()
											.subtract(miscBillingInvLineitemEntity.getNetAmountAccepted()));
					netAmountTotalAcceptedInvoice = netAmountTotalAcceptedInvoice
							.add(miscBillingInvLineitemEntity.getNetAmountAccepted());
					netAmountTotalRejectedInvoice = netAmountTotalRejectedInvoice
							.add(miscBillingInvLineitemEntity.getNetAmountRejected());
					}
					miscBillingInvLineitemEntity.setProcessStatus(MiscBillingConstants.LINEITEM_INVOICE_STATUS_CONFIRM);
				}

			}
			miscBillingTrnInvoiceEntity.setChargeAmountAccepted(chargeAmountTotalAcceptedInvoice);
			miscBillingTrnInvoiceEntity.setChargeAmountRejected(chargeAmountTotalRejectedInvoice);
			miscBillingTrnInvoiceEntity.setTotalTaxAmountAccepted(taxAmountTotalAcceptedInvoice);
			miscBillingTrnInvoiceEntity.setTotalTaxAmountRejected(taxAmountTotalRejectedInvoice);
			miscBillingTrnInvoiceEntity.setTotalVatAmountAccepted(vatAmountTotalAcceptedInvoice);
			miscBillingTrnInvoiceEntity.setTotalVatAmountRejected(vatAmountTotalRejectedInvoice);
			miscBillingTrnInvoiceEntity.setTotalAddonChargeAmountAccepted(addOnAmountTotalAcceptedInvoice);
			miscBillingTrnInvoiceEntity.setTotalAddonChargeAmountRejected(addOnAmountTotalRejectedInvoice);
			miscBillingTrnInvoiceEntity.setNetAmountAccepted(netAmountTotalAcceptedInvoice);
			miscBillingTrnInvoiceEntity.setNetAmountRejected(netAmountTotalRejectedInvoice);
			
			miscBillingTrnInvoiceEntity.setInvoiceStatus(MiscBillingConstants.LINEITEM_INVOICE_STATUS_CONFIRM);
	
			confirmInvoiceList.add(miscBillingInvoiceDao.updateInvoice(miscBillingTrnInvoiceEntity));
						
		}
			//calling rejection invoice service to create Outward invoice.
		List<MiscBillingTrnInvoice> errorsDueToRjectionStage = createRejectedInvoice(invoiceUrns);
		List<MiscBillingTrnInvoice> confirmInvList = miscBillingInvoiceMapper.mapToModel(confirmInvoiceList);
		if(CollectionUtils.isNotEmpty(errorsDueToRjectionStage)) {
			 return updateErrorMessage(confirmInvList, errorsDueToRjectionStage);
		}else {
			return confirmInvList;
		}
	}
	
	private Boolean rejectionStage(MiscBillingTrnInvoiceEntity entity) {
		log.info("Enter rejectionStage() >>>");
		Integer rejectionStage = entity.getRejectionStage() == null ? 1 : entity.getRejectionStage() + 1;
		log.info("rejectionStage after claculation : " + rejectionStage);
		if (entity.getSettlementMethod().equalsIgnoreCase("I") && rejectionStage > 1) {
			log.info("SettlementMethod ICH");
			// raise error MISC3026
			ExceptionTransactionModel exceptionTransactionModel = miscBillingUtil.prepareExceptionTransactionModel(
					EXCEPTION_CODE_MISC3026, null, entity.getClientId(), null, entity);
			exchangeRateFeignClient.initExceptionTrasaction(exceptionTransactionModel);
			return Boolean.FALSE;
		}
		if (entity.getSettlementMethod().equalsIgnoreCase("A") && rejectionStage > 2) {
			log.info("SettlementMethod ACH");
			// raise error MISC3027
			ExceptionTransactionModel exceptionTransactionModel = miscBillingUtil.prepareExceptionTransactionModel(
					EXCEPTION_CODE_MISC3027, null, entity.getClientId(), null, entity);
			exchangeRateFeignClient.initExceptionTrasaction(exceptionTransactionModel);
			return Boolean.FALSE;
		}
		log.info("<<< Exit rejectionStage()");
		return Boolean.TRUE;
	}
	
	private List<MiscBillingTrnInvoice> updateErrorMessage(List<MiscBillingTrnInvoice> miscBillingTrnErrorInvoice,
			List<MiscBillingTrnInvoice> errorsDueToRjectionStage) {
		errorsDueToRjectionStage.forEach(obj2 -> miscBillingTrnErrorInvoice.stream()
				.filter(obj1 -> obj1.getInvoiceNumber().equals(obj2.getInvoiceNumber()))
				.filter(obj1 -> obj1.getInvoiceUrn().equals(obj2.getInvoiceUrn()))
				.forEach(obj1 -> obj1.setErrorMessage(rejectionStageErrorMessage(obj1))));
		return miscBillingTrnErrorInvoice;
	}
	
	private String rejectionStageErrorMessage(MiscBillingTrnInvoice trnInvoice) {
		String errorMessage = null;
		if ("I".equalsIgnoreCase(trnInvoice.getSettlementMethod())) {
			// raise error MISC3026
			errorMessage = trnInvoice.getInvoiceNumber() + "-The rejection stage for the ICH billing should be 1";
		}
		if ("A".equalsIgnoreCase(trnInvoice.getSettlementMethod())) {
			// raise error MISC3027
			errorMessage = trnInvoice.getInvoiceNumber() + "-The maximum rejection stage for the ACH billing should be 2";
		}
		return errorMessage;
	}
	
	private void updateRejectedInvoiceNumber(List<MiscBillingTrnInvoiceEntity> rejectedInoviceList,
			Map<String, String> newBatchInvoiceMap, Map<String, String> oldBatchInvoiceMap) {
		for (MiscBillingTrnInvoiceEntity invEntity : rejectedInoviceList) {

			if (newBatchInvoiceMap.containsKey(invEntity.getInvoiceUrn())) {
				String invoiceNumber = newBatchInvoiceMap.get(invEntity.getInvoiceUrn());
				if (oldBatchInvoiceMap.containsValue(invoiceNumber)) {
					String key = MiscBillingCommonUtil.getKeyByValue(oldBatchInvoiceMap, invoiceNumber);
					miscBillingInvoiceDao.updateRejectedInvoice(invEntity.getInvoiceUrn(), key);
				}

			}

		}

	}

	public String getBaseCurrency(MasterFeignClient smartpraMasterAppClient, String clientId) {
		String baseCurrency = null;
		SystemParameter systemParameter =  smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(MiscBillingConstants.PARAM_DEFAULT_CURRENCY_CODE, clientId);
		if (systemParameter != null) {
			baseCurrency = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
		}

		return baseCurrency;
	}
	
	private void logException(String fromCurrency, String toCurrency, String invoiceDate, MiscBillingTrnInvoiceEntity entity2) {
		Map<String, String> expParam = new HashMap<>();
		expParam.put("From Currency", fromCurrency);
		expParam.put("To Currency", toCurrency);
		expParam.put("Date", invoiceDate);
		expParam.put("Rate Type", MiscBillingConstants.RATE_TYPE_BKR);
		ExceptionTransactionModel exceptionTransactionModel = miscBillingUtil.prepareExceptionTransactionModel(
				EXCEPTION_CODE_MISC9002, expParam, entity2.getClientId(), null, entity2);
		exchangeRateFeignClient.initExceptionTrasaction(exceptionTransactionModel);
	}

}