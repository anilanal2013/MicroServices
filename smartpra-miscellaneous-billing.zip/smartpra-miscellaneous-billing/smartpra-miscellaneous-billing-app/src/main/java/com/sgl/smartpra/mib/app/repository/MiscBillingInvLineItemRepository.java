package com.sgl.smartpra.mib.app.repository;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;

@Repository
public interface MiscBillingInvLineItemRepository extends JpaRepository<MiscBillingInvLineitemEntity, Integer> , JpaSpecificationExecutor<MiscBillingInvLineitemEntity> {

	@EntityGraph(attributePaths = {"miscBillingTrnInvoice"})
	public MiscBillingInvLineitemEntity findByInvLineItemId(Integer invLineItemId);
}
