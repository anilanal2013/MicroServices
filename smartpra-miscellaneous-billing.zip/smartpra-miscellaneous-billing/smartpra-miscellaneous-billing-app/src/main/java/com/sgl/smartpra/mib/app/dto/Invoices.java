package com.sgl.smartpra.mib.app.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
public class Invoices implements Serializable {

    private String status;
    private String invoiceno;
}
