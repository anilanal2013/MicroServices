package com.sgl.smartpra.mib.app.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.model.ChargeCategory;
import com.sgl.smartpra.master.model.RateAndAgreementModel;
import com.sgl.smartpra.mib.app.config.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.mib.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.mib.app.dao.InvoiceEvaluationDao;
import com.sgl.smartpra.mib.app.dto.InvoiceEvaluationSummary;
import com.sgl.smartpra.mib.app.mapper.InvoiceEvaluationMapper;
import com.sgl.smartpra.mib.app.repository.MiscBillingInvLineItemRepository;
import com.sgl.smartpra.mib.app.repository.MiscBillingInvoiceRepository;
import com.sgl.smartpra.mib.app.service.InvoiceEvaluationService;
import com.sgl.smartpra.mib.app.utility.MiscBillingUtil;
import com.sgl.smartpra.mib.domain.MiscBillingAddOnChargeDtl;
import com.sgl.smartpra.mib.domain.MiscBillingInvLineitem;
import com.sgl.smartpra.mib.domain.MiscBillingInvLineitemDtl;
import com.sgl.smartpra.mib.domain.MiscBillingTaxDetails;
import com.sgl.smartpra.mib.domain.MiscBillingTrnInvoice;
import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingSupportingDetailEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.utils.MiscBillingCommonUtil;
import com.sgl.smartpra.mib.utils.MiscBillingConstants;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class InvoiceEvaluationServiceImpl implements InvoiceEvaluationService {

	@Autowired
	InvoiceEvaluationDao invoiceEvaluationDao;

	@Autowired
	MiscBillingInvoiceRepository invoiceRepository;
	
	@Autowired
	MiscBillingInvLineItemRepository lineItemRepository;

	@Autowired
	InvoiceEvaluationMapper invoiceEvaluationMapper;

	@Autowired
	GlobalMasterFeignClient globalMasterFeignClient;
	
	@Autowired
	private MasterFeignClient masterFeignClient;


	private static final String CHARGE_CATEGORY_NOT_FOUND = "Charge category not found";
	private static final String CHARGE_AMT_ACCEPTED = "chargeAmtAccepted";
	private static final String CHARGE_AMT_REJECTED = "chargeAmtRejected";
	private static final String NET_AMT_ACCEPTED = "netAmtAccepted";
	private static final String NET_AMT_REJECTED = "netAmtRejected";
	private static final String AOC_AMT_ACCEPTED = "totalAocAccepted";
	private static final String AOC_AMT_REJECTED = "totalAocRejected";
	private static final String TAX_AMT_ACCEPTED = "totalTaxAmtAccepted";
	private static final String TAX_AMT_REJECTED = "totalTaxAmtRejected";
	private static final String VAT_AMT_ACCEPTED = "totalVatAmtAccepted";
	private static final String VAT_AMT_REJECTED = "totalVatAmtRejected";
	private static final String DETAIL = "Detail";


	@Override
	public List<InvoiceEvaluationSummary> getAllInvoices(Optional<String> status, Optional<String> billingType,
			Optional<String> billingPeriodMonth, Optional<Integer> billingPeriod,
			Optional<String> billingPeriodFromMonth, Optional<Integer> billingPeriodFrom,
			Optional<String> billingPeriodToMonth, Optional<Integer> billingPeriodTo, Optional<String> supplierType,
			Optional<String> supplierCode, Optional<String> supplierName, Optional<String> chargeCategoryCode,
			Optional<String> invoiceNumber) {
		List<MiscBillingTrnInvoice> miscBillingTrnInvoices = invoiceEvaluationMapper
				.mapToMiscBillingTrnInvoice(invoiceEvaluationDao.getAllInvoices(status, billingType,
						billingPeriodMonth, billingPeriod, billingPeriodFromMonth, billingPeriodFrom,
						billingPeriodToMonth, billingPeriodTo, supplierType, supplierCode, supplierName,
						chargeCategoryCode, invoiceNumber));
		Map<String, List<MiscBillingTrnInvoice>> miscBillingEvaluationInvoices = miscBillingTrnInvoices.stream()
				.filter(Objects::nonNull).collect(Collectors.groupingBy(MiscBillingTrnInvoice::getChargeCategoryCode));

		List<ChargeCategory> chargeCategoryList = globalMasterFeignClient.getAllChargeCategory(null, null, null);

		List<InvoiceEvaluationSummary> invoiceEvaluationSummaryList = new ArrayList<>();
		miscBillingEvaluationInvoices.entrySet().stream().forEach(miscBillInvoice -> {
			InvoiceEvaluationSummary invoiceEvaluationSummary = new InvoiceEvaluationSummary();
			invoiceEvaluationSummary.setChargeCategoryCode(miscBillInvoice.getKey());
			invoiceEvaluationSummary.setChargeCategoryName(chargeCategoryList.stream()
					.filter(chargeCategory -> miscBillInvoice.getKey()
					.equalsIgnoreCase(chargeCategory.getChargeCategoryCode().get()))
					.findFirst().orElseThrow(() -> new RecordNotFoundException(CHARGE_CATEGORY_NOT_FOUND))
					.getChargeCategoryName().get());
			invoiceEvaluationSummary.setInvoiceList(miscBillInvoice.getValue().stream()
					.map(MiscBillingTrnInvoice::getInvoiceUrn).collect(Collectors.toList()));
			invoiceEvaluationSummary.setNoOfInvoices(miscBillInvoice.getValue().size());
			invoiceEvaluationSummaryList.add(invoiceEvaluationSummary);
		});

		return invoiceEvaluationSummaryList;
	}

	@Override
	public List<MiscBillingInvLineitem> getLineItemList(Optional<String> invoiceUrn) {
		
		List<MiscBillingInvLineitem> lineItemList =  invoiceEvaluationMapper.mapToModel(invoiceEvaluationDao.getLineItemList(invoiceUrn));
		for (MiscBillingInvLineitem lineItem : lineItemList) {
			this.updateLineItem(lineItem);
		}
		
		return lineItemList;
	}
	
	@Override
	public void updateLineItem(MiscBillingInvLineitem lineItem) {
		// 1. Get Tax, addonCharge Dtls from LineItemDtl - Where addOnLevel = 'Detail'
		// 2. Add all the tax, addOnCharge Dtls in lineItem
		List<MiscBillingAddOnChargeDtl> miscBillingAddOnChargeDtl = null;
		List<MiscBillingTaxDetails> miscBillingTaxDetails = null;
		for (MiscBillingInvLineitemDtl lineItemDtl : lineItem.getMiscBillingLineitemDetails()) {
			miscBillingAddOnChargeDtl = lineItemDtl.getMiscBillingAddOnChargeDtl().stream()
					.filter(x -> DETAIL.equals(x.getAddOnLevel())).collect(Collectors.toList());
			miscBillingTaxDetails = lineItemDtl.getMiscBillingTaxDetails().stream()
					.filter(x -> DETAIL.equals(x.getTaxLevel())).collect(Collectors.toList());
			lineItem.getMiscBillingAddOnChargeDtl().addAll(miscBillingAddOnChargeDtl);
			lineItem.getMiscBillingTaxDetails().addAll(miscBillingTaxDetails);
		}	
	}

	@Override
	@Transactional
	public MiscBillingInvLineitem updateLineItem(Integer id, MiscBillingInvLineitem miscBillingInvLineitem) {
		log.info("Enter in the updateLineItem id : " + id);
		MiscBillingInvLineitemEntity miscBillingInvLineitemEntity = lineItemRepository.findByInvLineItemId(id);
		if(miscBillingInvLineitemEntity == null) {
			throw new RecordNotFoundException("LineItem with the id Does not exists");
		}		
		
		MiscBillingTrnInvoiceEntity invoiceEntity = miscBillingInvLineitemEntity.getMiscBillingTrnInvoice();
		String invoiceUrn = invoiceEntity.getInvoiceUrn();
		List<MiscBillingInvLineitemEntity> lineItemList = invoiceEntity.getMiscBillingInvLineitem();
		
		MiscBillingInvLineitemEntity lineItemEntity = new MiscBillingInvLineitemEntity();
		lineItemEntity = invoiceEvaluationMapper.mapMiscBillingInvLineitemEntityToEntity(miscBillingInvLineitem, lineItemEntity);
		
		List<MiscBillingInvLineitemEntity> dblineItemList = invoiceEvaluationDao.getLineItemList(Optional.of(invoiceUrn));
		if(!CollectionUtils.sizeIsEmpty(dblineItemList)) {
			Long count = dblineItemList.stream().filter(x -> Integer.compare(x.getInvLineItemId(), miscBillingInvLineitem.getInvLineItemId()) != 0)
											.filter(x -> !"EV".equalsIgnoreCase(x.getProcessStatus()))
											.count();
			if(count == 0) {
				log.info(" All line items are marked as EV.");
				invoiceEntity.setInvoiceStatus("EV"); // All line items are marked as EV 
			}
		}
		
		this.populateInvoiceDetails(lineItemList, invoiceEntity);
		if(invoiceEntity.getMiscBillingInvLineitem() == null) {
			lineItemEntity.setMiscBillingTrnInvoice(invoiceEntity);
			if(lineItemEntity.getMiscBillingLineitemDetails() != null) {
				for (MiscBillingInvLineitemDtlEntity lineItemDtl : lineItemEntity.getMiscBillingLineitemDetails()) {
					lineItemDtl.setMiscBillingInvLineitem(lineItemEntity);
					if(lineItemDtl.getMiscBillingAddOnChargeDtl() != null) {
						for (MiscBillingAddOnChargeDtlEntity addOnCharge : lineItemDtl.getMiscBillingAddOnChargeDtl()) {
							addOnCharge.setMiscBillingTrnInvoice(invoiceEntity);
							addOnCharge.setMiscBillingInvLineitemDtl(lineItemDtl);
						}
					}
					if(lineItemDtl.getMiscBillingTaxDetails() != null) {
						for (MiscBillingTaxDetailsEntity taxEntity : lineItemDtl.getMiscBillingTaxDetails()) {
							taxEntity.setMiscBillingTrnInvoice(invoiceEntity);
							taxEntity.setMiscBillingInvLineitemDtl(lineItemDtl);
						}
					}
					if(lineItemDtl.getMiscBillingSupportingDetail() != null) {
						for (MiscBillingSupportingDetailEntity suppDtlEntity : lineItemDtl.getMiscBillingSupportingDetail()) {
							suppDtlEntity.setMiscBillingInvLineitemDtl(lineItemDtl);
						}
					}
				}
			}
			if(lineItemEntity.getMiscBillingAddOnChargeDtl() != null) {
				for (MiscBillingAddOnChargeDtlEntity addOnCharge : lineItemEntity.getMiscBillingAddOnChargeDtl()) {
					addOnCharge.setMiscBillingTrnInvoice(invoiceEntity);
					addOnCharge.setMiscBillingInvLineitem(lineItemEntity);
				}
			}
			if(lineItemEntity.getMiscBillingTaxDetails() != null) {
				for (MiscBillingTaxDetailsEntity taxEntity : lineItemEntity.getMiscBillingTaxDetails()) {
					taxEntity.setMiscBillingTrnInvoice(invoiceEntity);
					taxEntity.setMiscBillingInvLineitem(lineItemEntity);
				}
			}
			List<MiscBillingInvLineitemEntity> list = new ArrayList<>();
			list.add(lineItemEntity);
			
			invoiceEntity.setMiscBillingInvLineitem(list);
		}
		invoiceEvaluationDao.updateInvoice(invoiceEntity);
		this.updateLineItem(miscBillingInvLineitem);
		return miscBillingInvLineitem;
	}

	@Override
	public void populateInvoiceDetails(List<MiscBillingInvLineitemEntity> lineItemList, MiscBillingTrnInvoiceEntity invoiceEntity) {

		invoiceEntity.setChargeAmountAccepted(this.getAmount(CHARGE_AMT_ACCEPTED, lineItemList));
		invoiceEntity.setChargeAmountRejected(this.getAmount(CHARGE_AMT_REJECTED, lineItemList));
		
		invoiceEntity.setNetAmountAccepted(this.getAmount(NET_AMT_ACCEPTED, lineItemList));
		invoiceEntity.setNetAmountRejected(this.getAmount(NET_AMT_REJECTED, lineItemList));
		
		invoiceEntity.setTotalTaxAmountAccepted(this.getAmount(TAX_AMT_ACCEPTED, lineItemList));
		invoiceEntity.setTotalTaxAmountRejected(this.getAmount(TAX_AMT_REJECTED, lineItemList));
		
		invoiceEntity.setTotalVatAmountAccepted(this.getAmount(VAT_AMT_ACCEPTED, lineItemList));
		invoiceEntity.setTotalVatAmountRejected(this.getAmount(VAT_AMT_REJECTED, lineItemList));
		
		invoiceEntity.setTotalAddonChargeAmountAccepted(this.getAmount(AOC_AMT_ACCEPTED, lineItemList));
		invoiceEntity.setTotalAddonChargeAmountRejected(this.getAmount(AOC_AMT_REJECTED, lineItemList));
		
		invoiceEntity.setMiscBillingInvLineitem(null);
		invoiceEntity.setMiscBillingAddOnChargeDtl(null);
		invoiceEntity.setMiscBillingInvTransHeader(null);
		invoiceEntity.setMiscBillingTaxDetails(null);
	}
	
	public BigDecimal getAmount(String type, List<MiscBillingInvLineitemEntity> lineItemList) {
			
		Double value = 0.00;
		if(!CollectionUtils.sizeIsEmpty(lineItemList)) {
			if(CHARGE_AMT_ACCEPTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getChargeAmountAccepted() != null)
						.mapToDouble(x -> x.getChargeAmountAccepted().doubleValue())
						.sum();
			} else if(CHARGE_AMT_REJECTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getChargeAmountRejected() != null)
						.mapToDouble(x -> x.getChargeAmountRejected().doubleValue())
						.sum();
			} else if(TAX_AMT_ACCEPTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getTotalTaxAmountAccepted() != null)
						.mapToDouble(x -> x.getTotalTaxAmountAccepted().doubleValue())
						.sum();
			} else if(TAX_AMT_REJECTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getTotalTaxAmountRejected() != null)
						.mapToDouble(x -> x.getTotalTaxAmountRejected().doubleValue())
						.sum();
			} else if(VAT_AMT_ACCEPTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getTotalVatAmountAccepted() != null)
						.mapToDouble(x -> x.getTotalVatAmountAccepted().doubleValue())
						.sum();
			} else if(VAT_AMT_REJECTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getTotalVatAmountRejected() != null)
						.mapToDouble(x -> x.getTotalVatAmountRejected().doubleValue())
						.sum();
			} else if(AOC_AMT_ACCEPTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getTotAddonChargeAmtAccepted() != null)
						.mapToDouble(x -> x.getTotAddonChargeAmtAccepted().doubleValue())
						.sum();
			} else if(AOC_AMT_REJECTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getTotAddonChargeAmtRejected() != null)
						.mapToDouble(x -> x.getTotAddonChargeAmtRejected().doubleValue())
						.sum();
			} else if(NET_AMT_ACCEPTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getNetAmountAccepted() != null)
						.mapToDouble(x -> x.getNetAmountAccepted().doubleValue())
						.sum();
			} else if(NET_AMT_REJECTED.equalsIgnoreCase(type)) {
				value = lineItemList.stream()
						.filter(x -> x.getNetAmountRejected() != null)
						.mapToDouble(x -> x.getNetAmountRejected().doubleValue())
						.sum();
			}	
		
		}
		return BigDecimal.valueOf(value).setScale(2, BigDecimal.ROUND_HALF_UP);
	}
	
	@Override
	@Transactional
	public String getInvoicesForAutoEvaluation(String status, String billingType, String invoiceDate, String chargeCategoryCode,
			String supplierCode, String billingMonth, Integer billingPeriod, String chargeCode, String clientId) {
		
		List<MiscBillingTrnInvoiceEntity> invoiceEntityList = invoiceEvaluationDao.getInvoicesForAutoEvaluation(status, billingType, invoiceDate, chargeCategoryCode, supplierCode, billingMonth, billingPeriod, clientId);
		return this.walkThroughInvoices(supplierCode, chargeCategoryCode, chargeCode, invoiceEntityList);
	}
	
	public String walkThroughInvoices(String supplierCode, String chargeCategoryCode, String chargeCode, 
			List<MiscBillingTrnInvoiceEntity> invoiceEntityList) {
		
		String message = MiscBillingConstants.EMPTY_STRING;
		if(CollectionUtils.isNotEmpty(invoiceEntityList)) {
			for (MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity : invoiceEntityList) {
				List<MiscBillingInvLineitemEntity> lineItemEntityList = miscBillingTrnInvoiceEntity.getMiscBillingInvLineitem().stream()
						.filter(Objects::nonNull).filter(x -> StringUtils.equalsAnyIgnoreCase(x.getChargeCode(), chargeCode))
						.collect(Collectors.toList());
				message = this.walkThroughLineItems(supplierCode, chargeCategoryCode, chargeCode, miscBillingTrnInvoiceEntity, lineItemEntityList);
				if(!StringUtils.equalsAnyIgnoreCase("SUCCESS", message)) {
					break;
				}
			}
		} else {
			message = "No Invoices found for chargeCategory: " + chargeCategoryCode + ", chargeCode: " + chargeCode;
		}
		return message;
	}
	
	public String walkThroughLineItems(String supplierCode, String chargeCategoryCode, String chargeCode,
			MiscBillingTrnInvoiceEntity invoiceEntity, List<MiscBillingInvLineitemEntity> lineItemEntityList) {
		
		String message = MiscBillingConstants.EMPTY_STRING;
		try {
			if(CollectionUtils.isNotEmpty(lineItemEntityList)) {
				List<MiscBillingInvLineitemEntity> evLineItemList = new ArrayList<>();
				for (MiscBillingInvLineitemEntity lineItemEntity : lineItemEntityList) {
					List<RateAndAgreementModel> raModelList = masterFeignClient.fetchRateAndAgreement(supplierCode, 
							lineItemEntity.getLocationCode(), chargeCategoryCode, chargeCode, null, null, null);
					RateAndAgreementModel rateAgreement = this.getRateAndAgreementModel(invoiceEntity.getInvoiceDate(), raModelList);
					if(rateAgreement != null) {
						this.autoEvaluate(lineItemEntity, rateAgreement, evLineItemList);
					} else {
						log.debug("No rate and agreement for chargeCategory: " + chargeCategoryCode + ", chargecode: " + chargeCode);
					}
				}
				log.debug("Saving all lineItems for autoEvaluation!!");
				lineItemRepository.saveAll(evLineItemList);
				message = "SUCCESS";
			}
		} catch (Exception e) {
			message = "Exception thrown while walkThroughLineItems(): " + e.getLocalizedMessage();
			log.error(message);
			e.printStackTrace();
		}
		return message;
	}
	
	public void autoEvaluate(MiscBillingInvLineitemEntity lineItemEntity, RateAndAgreementModel rateAgreement, 
			List<MiscBillingInvLineitemEntity> evLineItemList) {
		BigDecimal chargeAmt = lineItemEntity.getChargeAmount();
		BigDecimal qty = lineItemEntity.getQuantity();
		Optional<String> rateOp = rateAgreement.getRates();
		if(rateOp.isPresent()) {
			BigDecimal rate = new BigDecimal(rateOp.get());
			BigDecimal chargeAmtAccepted = chargeAmt.multiply(qty).multiply(rate);
			BigDecimal chargeAmtRejected = chargeAmt.subtract(chargeAmtAccepted);
			lineItemEntity.setChargeAmountAccepted(chargeAmtAccepted);
			lineItemEntity.setChargeAmountRejected(chargeAmtRejected);
			evLineItemList.add(lineItemEntity);
		} else {
			log.debug("Rate not present for chargeCategory: " + lineItemEntity.getChargeCatCode() + ", chargeCode: " + lineItemEntity.getChargeCode());
		}
	}
	
	public RateAndAgreementModel getRateAndAgreementModel(Date invoiceDate, List<RateAndAgreementModel> raModelList) {
	
		RateAndAgreementModel ra = null;
		if(CollectionUtils.isNotEmpty(raModelList)) {
			for (RateAndAgreementModel rateAgreement : raModelList) {
				Optional<String> fromDate = rateAgreement.getEffectiveFromDate();
				Optional<String> toDate = rateAgreement.getEffectiveToDate();
				if(fromDate.isPresent() && toDate.isPresent()) {
					LocalDate ldFrom  = MiscBillingUtil.stringToLocalDate(fromDate.get());
					LocalDate ldTo    = MiscBillingUtil.stringToLocalDate(toDate.get());
					LocalDate invDate = MiscBillingCommonUtil.convertToLocalDateViaInstant(invoiceDate);
					if(ldFrom != null && ldTo != null && invDate != null 
					&& invDate.isAfter(ldFrom.minusDays(1)) && invDate.isBefore(ldTo.plusDays(1))) {
						ra = rateAgreement;
						break;
					}
				}
			}
		}
		return ra;
	}
}
