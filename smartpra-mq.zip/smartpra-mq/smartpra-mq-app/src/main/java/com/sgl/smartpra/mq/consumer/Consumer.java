package com.sgl.smartpra.mq.consumer;

import java.io.IOException;

public interface Consumer {

	public void receive(String message) throws IOException;
}
