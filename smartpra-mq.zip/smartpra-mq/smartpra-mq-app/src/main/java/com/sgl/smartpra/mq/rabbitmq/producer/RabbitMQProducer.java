package com.sgl.smartpra.mq.rabbitmq.producer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.mq.producer.Producer;

public class RabbitMQProducer implements Producer {

	private static final Logger LOGGER = LoggerFactory.getLogger(RabbitMQProducer.class);

	private RabbitTemplate rabbitTemplate;

	public RabbitMQProducer(RabbitTemplate rabbitTemplate) {
		super();
		this.rabbitTemplate = rabbitTemplate;
	}

	public void send(String exchange, String routingKey, Object object) {
		try {
			LOGGER.info(this.getClass().getName() + ".send(), object={}", object);
			rabbitTemplate.convertAndSend(exchange, routingKey, new ObjectMapper().writeValueAsString(object));
		} catch (Exception e) {
			LOGGER.error("Exception occurred in " + this.getClass().getName() + ".send(), E{}", e);
		}
	}

}
