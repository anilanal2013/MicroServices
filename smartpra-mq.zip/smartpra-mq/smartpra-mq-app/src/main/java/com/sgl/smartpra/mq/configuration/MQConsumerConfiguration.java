package com.sgl.smartpra.mq.configuration;

import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sgl.smartpra.mq.consumer.Consumer;
import com.sgl.smartpra.mq.rabbitmq.configuration.RabbitMQConsumerConfiguration;

@Configuration
public class MQConsumerConfiguration {

	@Value("${rabbitmq.consumer.queue: null}")
	private String consumerQueueName;

	@Autowired
	private ConnectionFactory connectionFactory;

	@Bean
	public RabbitMQConsumerConfiguration rabbitMQConsumerConfiguration() {
		return new RabbitMQConsumerConfiguration(connectionFactory, consumerQueueName);
	}

	@Bean
	public SimpleMessageListenerContainer container(Consumer consumer) {
		return rabbitMQConsumerConfiguration().container(consumer);
	}
}
