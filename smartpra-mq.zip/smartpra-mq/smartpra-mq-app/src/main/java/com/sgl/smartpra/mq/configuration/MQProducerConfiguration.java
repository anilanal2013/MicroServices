package com.sgl.smartpra.mq.configuration;

import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sgl.smartpra.mq.producer.Producer;
import com.sgl.smartpra.mq.rabbitmq.configuration.RabbitMQProducerConfiguration;

@Configuration
public class MQProducerConfiguration {

	@Autowired
	private ConnectionFactory connectionFactory;

	@Bean
	public RabbitMQProducerConfiguration rabbitMQProducerConfiguration() {
		return new RabbitMQProducerConfiguration(connectionFactory);
	}

	@Bean
	public Producer producer() {
		return rabbitMQProducerConfiguration().producer();
	}

}
