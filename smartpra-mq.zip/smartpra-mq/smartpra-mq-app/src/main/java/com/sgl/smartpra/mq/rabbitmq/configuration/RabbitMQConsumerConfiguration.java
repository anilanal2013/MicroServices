package com.sgl.smartpra.mq.rabbitmq.configuration;

import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;

import com.sgl.smartpra.mq.consumer.Consumer;

public class RabbitMQConsumerConfiguration {

	private ConnectionFactory connectionFactory;

	private String consumerQueueName;

	public RabbitMQConsumerConfiguration(ConnectionFactory connectionFactory, String consumerQueueName) {
		super();
		this.connectionFactory = connectionFactory;
		this.consumerQueueName = consumerQueueName;
	}

	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	public SimpleMessageListenerContainer container(Consumer consumer) {
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory);
		container.setQueueNames(consumerQueueName);
		container.setMessageListener(listenerAdapter(consumer));
		return container;
	}

	public MessageListenerAdapter listenerAdapter(Consumer consumer) {
		MessageListenerAdapter listenerAdapter = new MessageListenerAdapter(consumer, "receive");
		listenerAdapter.setMessageConverter(jsonMessageConverter());
		return listenerAdapter;
	}
}
