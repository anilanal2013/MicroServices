package com.sgl.smartpra.mq.producer;

public interface Producer {

	public void send(String exchange, String routingKey, Object object);

}
