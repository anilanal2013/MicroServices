package com.sgl.smartpra.mq.rabbitmq.configuration;

import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;

import com.sgl.smartpra.mq.producer.Producer;
import com.sgl.smartpra.mq.rabbitmq.producer.RabbitMQProducer;

public class RabbitMQProducerConfiguration {

	private ConnectionFactory connectionFactory;

	public RabbitMQProducerConfiguration(ConnectionFactory connectionFactory) {
		super();
		this.connectionFactory = connectionFactory;
	}

	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	public RabbitTemplate rabbitTemplate() {
		RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		return rabbitTemplate;
	}

	public Producer producer() {
		return new RabbitMQProducer(rabbitTemplate());
	}
}
