package com.sgl.smartpra.mq.enums;

public enum AppNameEnum {

	INTELLIGENCE, CMD_EXECUTOR, BPM_WRAPPER
}
