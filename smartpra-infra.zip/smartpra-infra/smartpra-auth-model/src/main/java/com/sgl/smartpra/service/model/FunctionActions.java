package com.sgl.smartpra.service.model;

import java.io.Serializable;
import java.util.List;

public class FunctionActions extends AuditableColumns implements Serializable{

	String Function;

	public String getFunction() {
		return Function;
	}

	public void setFunction(String function) {
		Function = function;
	}

	public List<String> getActions() {
		return actions;
	}

	public void setActions(List<String> actions) {
		this.actions = actions;
	}

	List<String> actions;
}
