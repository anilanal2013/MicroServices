package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the MasPasswordSecretQuestionEntity entity.
 */
public class MasPasswordSecretQuestion extends AuditableColumns implements Serializable {

    private Long masPasswordSecretQuestionId;

    private String secretQuestion1;

    private String secretAnswer1;

    private String secretQuestion2;

    private String secretAnswer2;

    private String secretQuestion3;

    private String secretAnswer3;

    private Long masUsersId;

 
	public Long getMasPasswordSecretQuestionId() {
		return masPasswordSecretQuestionId;
	}

	public void setMasPasswordSecretQuestionId(Long masPasswordSecretQuestionId) {
		this.masPasswordSecretQuestionId = masPasswordSecretQuestionId;
	}

	public String getSecretQuestion1() {
        return secretQuestion1;
    }

    public void setSecretQuestion1(String secretQuestion1) {
        this.secretQuestion1 = secretQuestion1;
    }

    public String getSecretAnswer1() {
        return secretAnswer1;
    }

    public void setSecretAnswer1(String secretAnswer1) {
        this.secretAnswer1 = secretAnswer1;
    }

    public String getSecretQuestion2() {
        return secretQuestion2;
    }

    public void setSecretQuestion2(String secretQuestion2) {
        this.secretQuestion2 = secretQuestion2;
    }

    public String getSecretAnswer2() {
        return secretAnswer2;
    }

    public void setSecretAnswer2(String secretAnswer2) {
        this.secretAnswer2 = secretAnswer2;
    }

    public String getSecretQuestion3() {
        return secretQuestion3;
    }

    public void setSecretQuestion3(String secretQuestion3) {
        this.secretQuestion3 = secretQuestion3;
    }

    public String getSecretAnswer3() {
        return secretAnswer3;
    }

    public void setSecretAnswer3(String secretAnswer3) {
        this.secretAnswer3 = secretAnswer3;
    }

    public Long getMasUsersId() {
        return masUsersId;
    }

    public void setMasUsersId(Long masUsersId) {
        this.masUsersId = masUsersId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MasPasswordSecretQuestion masPasswordSecretQuestionDTO = (MasPasswordSecretQuestion) o;
        if (masPasswordSecretQuestionDTO.getMasPasswordSecretQuestionId() == null || getMasPasswordSecretQuestionId() == null) {
            return false;
        }
        return Objects.equals(getMasPasswordSecretQuestionId(), masPasswordSecretQuestionDTO.getMasPasswordSecretQuestionId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getMasPasswordSecretQuestionId());
    }

    @Override
    public String toString() {
        return "MasPasswordSecretQuestion{" +
            "id=" + getMasPasswordSecretQuestionId() +
            ", secretQuestion1='" + getSecretQuestion1() + "'" +
            ", secretAnswer1='" + getSecretAnswer1() + "'" +
            ", secretQuestion2='" + getSecretQuestion2() + "'" +
            ", secretAnswer2='" + getSecretAnswer2() + "'" +
            ", secretQuestion3='" + getSecretQuestion3() + "'" +
            ", secretAnswer3='" + getSecretAnswer3() + "'" +
            ", masUsers=" + getMasUsersId() +
            "}";
    }
}
