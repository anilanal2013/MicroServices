package com.sgl.smartpra.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the mas_user_password database table.
 * 
 */
@Entity
@Table(name="mas_user_password")
@NamedQuery(name="MasUserPasswordEntity.findAll", query="SELECT m FROM MasUserPasswordEntity m")
public class MasUserPasswordEntity extends AbstractAuditingEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long userPwdId;
	private int invalidPwdCount;
	private String passwordHash;
	private String salt;
	private MasUsersEntity masUsers;

	public MasUserPasswordEntity() {
	}


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	//  @SequenceGenerator(name = "sequenceGenerator")
	@Column(name="user_pwd_id")
	public Long getUserPwdId() {
		return this.userPwdId;
	}

	public void setUserPwdId(Long userPwdId) {
		this.userPwdId = userPwdId;
	}




	@Column(name="invalid_pwd_count")
	public int getInvalidPwdCount() {
		return this.invalidPwdCount;
	}

	public void setInvalidPwdCount(int invalidPwdCount) {
		this.invalidPwdCount = invalidPwdCount;
	}

	@Column(name="password_hash")
	public String getPasswordHash() {
		return this.passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}


	public String getSalt() {
		return this.salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}


	//bi-directional many-to-one association to MasUser
	@OneToOne(fetch = FetchType.LAZY, optional = false, cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", nullable = false)
	public MasUsersEntity getMasUsers() {
		return masUsers;
	}
	
	public void setMasUsers(MasUsersEntity masUsers) {
		this.masUsers = masUsers;
	}

}