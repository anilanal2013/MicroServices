package com.sgl.smartpra.domain;

import java.io.Serializable;
import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;



/**
 * The persistent class for the user_2fa_login database table.
 * 
 */
@Entity
@Table(name="user_2fa_login")
@NamedQuery(name="User2faLoginEntity.findAll", query="SELECT u FROM User2faLoginEntity u")
public class User2faLoginEntity extends AbstractAuditingEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long user2faAutoid;
	private boolean isSmsToken;
	private boolean isSoftToken;
	private boolean isTokenBlocked;
	private boolean isTokenLost;
	private boolean isTokenRegistered;
	private Instant lastGeneratedToken;
	
	private String oypHardTokenSerialNumber;
	private Instant tokenDeviceExpiryDatetime;
	private MasUsersEntity masUsers;

	public User2faLoginEntity() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="user_2fa_autoid")
	public Long getUser2faAutoid() {
		return this.user2faAutoid;
	}

	public void setUser2faAutoid(Long user2faAutoid) {
		this.user2faAutoid = user2faAutoid;
	}





	@Column(name="is_sms_token")
	public boolean getIsSmsToken() {
		return this.isSmsToken;
	}

	public void setIsSmsToken(boolean isSmsToken) {
		this.isSmsToken = isSmsToken;
	}


	@Column(name="is_soft_token")
	public boolean getIsSoftToken() {
		return this.isSoftToken;
	}

	public void setIsSoftToken(boolean isSoftToken) {
		this.isSoftToken = isSoftToken;
	}


	@Column(name="is_token_blocked")
	public boolean getIsTokenBlocked() {
		return this.isTokenBlocked;
	}

	public void setIsTokenBlocked(boolean isTokenBlocked) {
		this.isTokenBlocked = isTokenBlocked;
	}


	@Column(name="is_token_lost")
	public boolean getIsTokenLost() {
		return this.isTokenLost;
	}

	public void setIsTokenLost(boolean isTokenLost) {
		this.isTokenLost = isTokenLost;
	}


	@Column(name="is_token_registered")
	public boolean getIsTokenRegistered() {
		return this.isTokenRegistered;
	}

	public void setIsTokenRegistered(boolean isTokenRegistered) {
		this.isTokenRegistered = isTokenRegistered;
	}


	@Column(name="last_generated_token")
	public Instant getLastGeneratedToken() {
		return this.lastGeneratedToken;
	}

	public void setLastGeneratedToken(Instant lastGeneratedToken) {
		this.lastGeneratedToken = lastGeneratedToken;
	}





	@Column(name="oyp_hard_token_serial_number")
	public String getOypHardTokenSerialNumber() {
		return this.oypHardTokenSerialNumber;
	}

	public void setOypHardTokenSerialNumber(String oypHardTokenSerialNumber) {
		this.oypHardTokenSerialNumber = oypHardTokenSerialNumber;
	}


	@Column(name="token_device_expiry_datetime")
	public Instant getTokenDeviceExpiryDatetime() {
		return this.tokenDeviceExpiryDatetime;
	}

	public void setTokenDeviceExpiryDatetime(java.time.Instant tokenDeviceExpiryDatetime) {
		this.tokenDeviceExpiryDatetime = tokenDeviceExpiryDatetime;
	}


	//bi-directional many-to-one association to MasUser
	@ManyToOne
	@JoinColumn(name="user_id")
	public MasUsersEntity getMasUsers() {
		return masUsers;
	}
	
	public void setMasUsers(MasUsersEntity masUsers) {
		this.masUsers = masUsers;
	}

}