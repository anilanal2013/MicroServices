package com.sgl.smartpra.service.model;

import java.util.List;

public class FunctionDetail {

	private Long functionId;

	private String functionName;
	
	private List<FunctionActionDetail> deActiveFunctionAction;

	private List<FunctionActionDetail> functionAction;

	public FunctionDetail() {
		super();
	}
	
	public FunctionDetail(Long functionId, String functionName, List<FunctionActionDetail> deActiveFunctionAction,
			List<FunctionActionDetail> functionAction) {
		super();
		this.functionId = functionId;
		this.functionName = functionName;
		this.deActiveFunctionAction = deActiveFunctionAction;
		this.functionAction = functionAction;
	}

	public Long getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public List<FunctionActionDetail> getFunctionAction() {
		return functionAction;
	}

	public void setFunctionAction(List<FunctionActionDetail> functionAction) {
		this.functionAction = functionAction;
	}

	public List<FunctionActionDetail> getDeActiveFunctionAction() {
		return deActiveFunctionAction;
	}

	public void setDeActiveFunctionAction(List<FunctionActionDetail> deActiveFunctionAction) {
		this.deActiveFunctionAction = deActiveFunctionAction;
	}
	
}
