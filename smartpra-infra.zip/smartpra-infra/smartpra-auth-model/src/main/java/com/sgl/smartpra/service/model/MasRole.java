package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the MasRoleEntity entity.
 */
public class MasRole extends AuditableColumns implements Serializable  {

    private Long roleId;

    private String roleName;

    private Boolean isActive;



	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MasRole masRoleDTO = (MasRole) o;
        if (masRoleDTO.getRoleId() == null || getRoleId() == null) {
            return false;
        }
        return Objects.equals(getRoleId(), masRoleDTO.getRoleId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getRoleId());
    }

    @Override
    public String toString() {
        return "MasRole{" +
            "id=" + getRoleId() +
            ", roleName='" + getRoleName() + "'" +
            ", isActive='" + isIsActive() + "'" +
            "}";
    }
}
