package com.sgl.smartpra.service.model;

import java.util.Date;


public class Action {

	
	private Long actionId;
	
	private String actionName;

	private String createdBy;

	private String modifiedBy;

	public Long getActionId() {
		return actionId;
	}

	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModidiedOn() {
		return modidiedOn;
	}

	public void setModidiedOn(Date modidiedOn) {
		this.modidiedOn = modidiedOn;
	}

	private Date modidiedOn;

}
