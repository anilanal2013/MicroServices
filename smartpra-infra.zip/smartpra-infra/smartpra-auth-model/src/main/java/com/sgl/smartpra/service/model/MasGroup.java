package com.sgl.smartpra.service.model;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * A DTO for the MasGroupEntity entity.
 */
public class MasGroup extends AuditableColumns implements Serializable {
	
	private Long groupId;
	private String groupName;
	private Integer clientId;
	private Integer moduleId;
	private Integer groupManagerId;
	private Boolean isActive;
	private MasTeam masTeam;
	private List<MasTeam> masTeams;

	
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Integer getClientId() {
		return clientId;
	}
	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}
	public Integer getModuleId() {
		return moduleId;
	}
	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}
	public Integer getGroupManagerId() {
		return groupManagerId;
	}
	public void setGroupManagerId(Integer groupManagerId) {
		this.groupManagerId = groupManagerId;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Boolean getActive() {
		return isActive;
	}
	public void setActive(Boolean active) {
		isActive = active;
	}
	public List<MasTeam> getMasTeams() {
		return masTeams;
	}
	public void setMasTeams(List<MasTeam> masTeams) {
		this.masTeams = masTeams;
	}
	public MasTeam getMasTeam() {
		return masTeam;
	}

	public void setMasTeam(MasTeam masTeam) {
		this.masTeam = masTeam;
	}

	@Override
	public String toString() {
		return "MasGroup{" +
				"groupId=" + groupId +
				", groupName='" + groupName + '\'' +
				", clientId=" + clientId +
				", moduleId=" + moduleId +
				", groupManagerId=" + groupManagerId +
				", isActive=" + isActive +
				", masTeam=" + masTeam +
				", masTeams=" + masTeams +
				'}';
	}

	
}
