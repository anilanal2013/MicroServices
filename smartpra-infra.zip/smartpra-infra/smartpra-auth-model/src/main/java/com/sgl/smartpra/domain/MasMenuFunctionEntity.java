package com.sgl.smartpra.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the mas_menu_function database table.
 * 
 */
@Entity
@Table(name="mas_menu_function")
@NamedQuery(name="MasMenuFunction.findAll", query="SELECT m FROM MasMenuFunctionEntity m")
public class MasMenuFunctionEntity extends AbstractAuditingEntity implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="menu_function_id", unique=true, nullable=false)
	private Long menuFunctionId;

	@Column(name="is_active", nullable=false, length=1)
	private String isActive;

	//bi-directional many-to-one association to MasFunction
	@ManyToOne
	@JoinColumn(name="function_id", nullable=false)
	private ScreenFunctionEntity masFunction;

	//bi-directional many-to-one association to MasMenu
	@ManyToOne
	@JoinColumn(name="menu_id", nullable=false)
	private MasMenuEntity masMenu;

	public MasMenuFunctionEntity() {
	}

	public Long getMenuFunctionId() {
		return this.menuFunctionId;
	}

	public void setMenuFunctionId(Long menuFunctionId) {
		this.menuFunctionId = menuFunctionId;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public ScreenFunctionEntity getMasFunction() {
		return this.masFunction;
	}

	public void setMasFunction(ScreenFunctionEntity masFunction) {
		this.masFunction = masFunction;
	}

	public MasMenuEntity getMasMenu() {
		return this.masMenu;
	}

	public void setMasMenu(MasMenuEntity masMenu) {
		this.masMenu = masMenu;
	}

}