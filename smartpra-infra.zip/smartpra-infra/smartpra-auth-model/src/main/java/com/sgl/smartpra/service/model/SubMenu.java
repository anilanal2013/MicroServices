package com.sgl.smartpra.service.model;

import java.util.List;

import lombok.Data;

@Data
public class SubMenu {

	private String menuName;
	
	private List<SubMenu> subMenu;
	
	private List<RoleActionPrivileges> function;
}
