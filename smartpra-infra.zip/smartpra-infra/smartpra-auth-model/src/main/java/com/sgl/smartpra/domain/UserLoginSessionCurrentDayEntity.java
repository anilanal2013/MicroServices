package com.sgl.smartpra.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.time.Instant;


/**
 * The persistent class for the user_login_session_current_day database table.
 * 
 */
@Entity
@Table(name="user_login_session_current_day")
@NamedQuery(name="UserLoginSessionCurrentDayEntity.findAll", query="SELECT u FROM UserLoginSessionCurrentDayEntity u")
public class UserLoginSessionCurrentDayEntity extends AbstractAuditingEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long userCurrSessionId;
	private Long browserSessionId;
	
	private int invalidPwdCount;
	private String isSessionTimedOut;
	private String keyUsed;
	private String lastAccessedScreenControl;
	
	private String passwordHash;
	private String saltUsed;
	private Instant sessionEndTime;
	private Instant sessionStartTime;
	private MasUsersEntity masUsers;

	public UserLoginSessionCurrentDayEntity() {
	}


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_curr_session_id")
	public Long getUserCurrSessionId() {
		return this.userCurrSessionId;
	}

	public void setUserCurrSessionId(Long userCurrSessionId) {
		this.userCurrSessionId = userCurrSessionId;
	}


	@Column(name="browser_session_id")
	public Long getBrowserSessionId() {
		return this.browserSessionId;
	}

	public void setBrowserSessionId(Long browserSessionId) {
		this.browserSessionId = browserSessionId;
	}


	


	@Column(name="invalid_pwd_count")
	public int getInvalidPwdCount() {
		return this.invalidPwdCount;
	}

	public void setInvalidPwdCount(int invalidPwdCount) {
		this.invalidPwdCount = invalidPwdCount;
	}


	@Column(name="is_session_timed_out")
	public String getIsSessionTimedOut() {
		return this.isSessionTimedOut;
	}

	public void setIsSessionTimedOut(String isSessionTimedOut) {
		this.isSessionTimedOut = isSessionTimedOut;
	}


	@Column(name="key_used")
	public String getKeyUsed() {
		return this.keyUsed;
	}

	public void setKeyUsed(String keyUsed) {
		this.keyUsed = keyUsed;
	}


	@Column(name="last_accessed_screen_control")
	public String getLastAccessedScreenControl() {
		return this.lastAccessedScreenControl;
	}

	public void setLastAccessedScreenControl(String lastAccessedScreenControl) {
		this.lastAccessedScreenControl = lastAccessedScreenControl;
	}





	@Column(name="password_hash")
	public String getPasswordHash() {
		return this.passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}


	@Column(name="salt_used")
	public String getSaltUsed() {
		return this.saltUsed;
	}

	public void setSaltUsed(String saltUsed) {
		this.saltUsed = saltUsed;
	}


	@Column(name="session_end_time")
	public Instant getSessionEndTime() {
		return this.sessionEndTime;
	}

	public void setSessionEndTime(Instant sessionEndTime) {
		this.sessionEndTime = sessionEndTime;
	}


	@Column(name="session_start_time")
	public Instant getSessionStartTime() {
		return this.sessionStartTime;
	}

	public void setSessionStartTime(Instant sessionStartTime) {
		this.sessionStartTime = sessionStartTime;
	}


	//bi-directional many-to-one association to MasUser
	@ManyToOne
	@JoinColumn(name="user_id")
	public MasUsersEntity getMasUsers() {
		return masUsers;
	}
	
	public void setMasUsers(MasUsersEntity masUsers) {
		this.masUsers = masUsers;
	}

}