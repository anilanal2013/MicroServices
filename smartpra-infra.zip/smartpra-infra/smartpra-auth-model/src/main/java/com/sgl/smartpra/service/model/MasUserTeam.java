package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the MasUserTeamEntity entity.
 */
public class MasUserTeam extends AuditableColumns implements Serializable {

    private Long masUserTeamId;

    private Boolean isActive;


    private Long masUsersId;

    private Long masTeamId;

 
    public Long getMasUserTeamId() {
		return masUserTeamId;
	}

	public void setMasUserTeamId(Long masUserTeamId) {
		this.masUserTeamId = masUserTeamId;
	}

	public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Long getMasUsersId() {
        return masUsersId;
    }

    public void setMasUsersId(Long masUsersId) {
        this.masUsersId = masUsersId;
    }

    public Long getMasTeamId() {
        return masTeamId;
    }

    public void setMasTeamId(Long masTeamId) {
        this.masTeamId = masTeamId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MasUserTeam masUserTeamDTO = (MasUserTeam) o;
        if (masUserTeamDTO.getMasUserTeamId() == null || getMasUserTeamId() == null) {
            return false;
        }
        return Objects.equals(getMasUserTeamId(), masUserTeamDTO.getMasUserTeamId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getMasUserTeamId());
    }

    @Override
    public String toString() {
        return "MasUserTeam{" +
            "id=" + getMasUserTeamId() +
            ", isActive='" + isIsActive() + "'" +
            ", masUsers=" + getMasUsersId() +
            ", masTeam=" + getMasTeamId() +
            "}";
    }
}
