package com.sgl.smartpra.service.model;
import java.time.Instant;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the User2faLoginEntity entity.
 */
public class User2faLogin extends AuditableColumns implements Serializable {

    private Long User2faLoginId;

    private Boolean isSmsToken;

    private Boolean isSoftToken;

    private Boolean isTokenBlocked;

    private Boolean isTokenLost;

    private Boolean isTokenRegistered;

    private Instant lastGeneratedToken;


    private Long masUsersId;

   
    public Long getUser2faLoginId() {
		return User2faLoginId;
	}

	public void setUser2faLoginId(Long user2faLoginId) {
		User2faLoginId = user2faLoginId;
	}

	public Boolean isIsSmsToken() {
        return isSmsToken;
    }

    public void setIsSmsToken(Boolean isSmsToken) {
        this.isSmsToken = isSmsToken;
    }

    public Boolean isIsSoftToken() {
        return isSoftToken;
    }

    public void setIsSoftToken(Boolean isSoftToken) {
        this.isSoftToken = isSoftToken;
    }

    public Boolean isIsTokenBlocked() {
        return isTokenBlocked;
    }

    public void setIsTokenBlocked(Boolean isTokenBlocked) {
        this.isTokenBlocked = isTokenBlocked;
    }

    public Boolean isIsTokenLost() {
        return isTokenLost;
    }

    public void setIsTokenLost(Boolean isTokenLost) {
        this.isTokenLost = isTokenLost;
    }

    public Boolean isIsTokenRegistered() {
        return isTokenRegistered;
    }

    public void setIsTokenRegistered(Boolean isTokenRegistered) {
        this.isTokenRegistered = isTokenRegistered;
    }

    public Instant getLastGeneratedToken() {
        return lastGeneratedToken;
    }

    public void setLastGeneratedToken(Instant lastGeneratedToken) {
        this.lastGeneratedToken = lastGeneratedToken;
    }

    public Long getMasUsersId() {
        return masUsersId;
    }

    public void setMasUsersId(Long masUsersId) {
        this.masUsersId = masUsersId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        User2faLogin user2faLoginDTO = (User2faLogin) o;
        if (user2faLoginDTO.getUser2faLoginId() == null || getUser2faLoginId() == null) {
            return false;
        }
        return Objects.equals(getUser2faLoginId(), user2faLoginDTO.getUser2faLoginId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getUser2faLoginId());
    }

    @Override
    public String toString() {
        return "User2faLogin{" +
            "id=" + getUser2faLoginId() +
            ", isSmsToken='" + isIsSmsToken() + "'" +
            ", isSoftToken='" + isIsSoftToken() + "'" +
            ", isTokenBlocked='" + isIsTokenBlocked() + "'" +
            ", isTokenLost='" + isIsTokenLost() + "'" +
            ", isTokenRegistered='" + isIsTokenRegistered() + "'" +
            ", lastGeneratedToken='" + getLastGeneratedToken() + "'" +
            ", masUsers=" + getMasUsersId() +
            "}";
    }
}
