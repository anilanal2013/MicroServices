package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

/**
 * A DTO for the UserPasswordHistoryEntity entity.
 */
public class UserPasswordHistory extends AuditableColumns implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long userPasswordHistoryId;
	private Instant pwdChangedDatetime;
	private String passwordHash;
    private Long masUsersId;

   
    public Long getUserPasswordHistoryId() {
		return userPasswordHistoryId;
	}

	public Instant getPwdChangedDatetime() {
		return pwdChangedDatetime;
	}

	public void setPwdChangedDatetime(Instant pwdChangedDatetime) {
		this.pwdChangedDatetime = pwdChangedDatetime;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public Long getMasUsersId() {
		return masUsersId;
	}

	public void setMasUsersId(Long masUsersId) {
		this.masUsersId = masUsersId;
	}

	public void setUserPasswordHistoryId(Long userPasswordHistoryId) {
		this.userPasswordHistoryId = userPasswordHistoryId;
	}

	
   
}
