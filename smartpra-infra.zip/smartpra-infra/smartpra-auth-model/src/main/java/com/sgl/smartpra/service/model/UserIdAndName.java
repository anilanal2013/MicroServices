package com.sgl.smartpra.service.model;

public interface UserIdAndName {

    String getFirstName();

    Long getUserId();
}
