package com.sgl.smartpra.service.model;

import java.util.List;

import lombok.Data;

@Data
public class RoleActionPrivileges {
	
	private Long functionId;

	private String functionName;
	
	private List<String> actions;
	
	public RoleActionPrivileges() {
		super();
	}

	public RoleActionPrivileges(Long functionId, String functionName, List<String> actions) {
		super();
		this.functionId = functionId;
		this.functionName = functionName;
		this.actions = actions;
	}

}
