package com.sgl.smartpra.service.model;

public class FunctionActionDetail {

	private Long functionActionId;
	
	private Long actionId;
	
	private String actionName;
	
	public FunctionActionDetail() {
		super();
	}

	public FunctionActionDetail(Long functionActionId, Long actionId, String actionName) {
		super();
		this.functionActionId = functionActionId;
		this.actionId = actionId;
		this.actionName = actionName;
	}

	public Long getFunctionActionId() {
		return functionActionId;
	}

	public void setFunctionActionId(Long functionActionId) {
		this.functionActionId = functionActionId;
	}

	public Long getActionId() {
		return actionId;
	}

	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	
}
