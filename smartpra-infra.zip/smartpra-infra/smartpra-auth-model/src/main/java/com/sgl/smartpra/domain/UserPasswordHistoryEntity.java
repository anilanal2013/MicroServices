package com.sgl.smartpra.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.time.Instant;


/**
 * The persistent class for the user_password_history database table.
 * 
 */
@Entity
@Table(name="user_password_history")
@NamedQuery(name="UserPasswordHistoryEntity.findAll", query="SELECT u FROM UserPasswordHistoryEntity u")
public class UserPasswordHistoryEntity extends AbstractAuditingEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long userPwdHistId;
	private Instant pwdChangedDatetime;
	private String passwordHash;
	private MasUsersEntity masUsers;

	public UserPasswordHistoryEntity() {
	}


	public Instant getPwdChangedDatetime() {
		return pwdChangedDatetime;
	}


	public void setPwdChangedDatetime(Instant pwdChangedDatetime) {
		this.pwdChangedDatetime = pwdChangedDatetime;
	}


	public String getPasswordHash() {
		return passwordHash;
	}


	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_pwd_hist_id")
	public Long getUserPwdHistId() {
		return this.userPwdHistId;
	}

	public void setUserPwdHistId(Long userPwdHistId) {
		this.userPwdHistId = userPwdHistId;
	}


	/*@Column(name="created_by")
	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	@Column(name="created_date")
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
*/


	//bi-directional many-to-one association to MasUser
	@ManyToOne
	@JoinColumn(name="user_id")
    public MasUsersEntity getMasUsers() {
		return masUsers;
	}
	
	public void setMasUsers(MasUsersEntity masUsers) {
		this.masUsers = masUsers;
	}

}