package com.sgl.smartpra.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.time.Instant;


/**
 * The persistent class for the mas_user_login database table.
 * 
 */
@Entity
@Table(name="mas_user_login")
@NamedQuery(name="MasUserLoginEntity.findAll", query="SELECT m FROM MasUserLoginEntity m")
public class MasUserLoginEntity extends AbstractAuditingEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long userLoginId;

	private MasUsersEntity masUsers;

	private boolean userLoginIsactive;
	
	private Boolean isFirstTimeLogin;
	
	private String isFirstTimePasswordChanged;
	
	private Boolean isLoginLocked;
	
	private Boolean isPasswordReset;
	
	private int failedLoginAttempts;
		
	private String lastAccessedScreenCtrlId;
	
	private String lastLoggedInCxrId;
	
	private String lastLoggedInIpAddress;
	
	private int lstLoginDayIdleSessionCnt;
	
	private String productivityLevel;
	
	private Instant lastLoginTime;

	private Instant last_logoutTime;
	

	
	public MasUserLoginEntity() {
	}


	@Id
/*	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")*/
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_login_id")
	public Long getUserLoginId() {
		return this.userLoginId;
	}

	public void setUserLoginId(Long userLoginId) {
		this.userLoginId = userLoginId;
	}


	

	@Column(name="failed_login_attempts")
	public int getFailedLoginAttempts() {
		return this.failedLoginAttempts;
	}

	public void setFailedLoginAttempts(int failedLoginAttempts) {
		this.failedLoginAttempts = failedLoginAttempts;
	}




	public Boolean getIsFirstTimeLogin() {
		return isFirstTimeLogin;
	}


	public void setIsFirstTimeLogin(Boolean isFirstTimeLogin) {
		this.isFirstTimeLogin = isFirstTimeLogin;
	}


	public Boolean getIsLoginLocked() {
		return isLoginLocked;
	}


	public void setIsLoginLocked(Boolean isLoginLocked) {
		this.isLoginLocked = isLoginLocked;
	}


	public Boolean getIsPasswordReset() {
		return isPasswordReset;
	}


	public void setIsPasswordReset(Boolean isPasswordReset) {
		this.isPasswordReset = isPasswordReset;
	}


	@Column(name="is_first_time_password_changed")
	public String getIsFirstTimePasswordChanged() {
		return this.isFirstTimePasswordChanged;
	}

	public void setIsFirstTimePasswordChanged(String isFirstTimePasswordChanged) {
		this.isFirstTimePasswordChanged = isFirstTimePasswordChanged;
	}


	

	@Column(name="[last_ logout_time]")
	public Instant getLast_logoutTime() {
		return this.last_logoutTime;
	}

	public void setLast_logoutTime(Instant last_logoutTime) {
		this.last_logoutTime = last_logoutTime;
	}


	@Column(name="last_accessed_screen_ctrl_id")
	public String getLastAccessedScreenCtrlId() {
		return this.lastAccessedScreenCtrlId;
	}

	public void setLastAccessedScreenCtrlId(String lastAccessedScreenCtrlId) {
		this.lastAccessedScreenCtrlId = lastAccessedScreenCtrlId;
	}


	@Column(name="last_logged_in_cxr_id")
	public String getLastLoggedInCxrId() {
		return this.lastLoggedInCxrId;
	}

	public void setLastLoggedInCxrId(String lastLoggedInCxrId) {
		this.lastLoggedInCxrId = lastLoggedInCxrId;
	}


	@Column(name="last_logged_in_ip_address")
	public String getLastLoggedInIpAddress() {
		return this.lastLoggedInIpAddress;
	}

	public void setLastLoggedInIpAddress(String lastLoggedInIpAddress) {
		this.lastLoggedInIpAddress = lastLoggedInIpAddress;
	}


	@Column(name="last_login_time")
	public Instant getLastLoginTime() {
		return this.lastLoginTime;
	}

	public void setLastLoginTime(Instant lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}


	

	@Column(name="lst_login_day_idle_session_cnt")
	public int getLstLoginDayIdleSessionCnt() {
		return this.lstLoginDayIdleSessionCnt;
	}

	public void setLstLoginDayIdleSessionCnt(int lstLoginDayIdleSessionCnt) {
		this.lstLoginDayIdleSessionCnt = lstLoginDayIdleSessionCnt;
	}


	@Column(name="productivity_level")
	public String getProductivityLevel() {
		return this.productivityLevel;
	}

	public void setProductivityLevel(String productivityLevel) {
		this.productivityLevel = productivityLevel;
	}


	@Column(name="user_login_isactive")
	public boolean getUserLoginIsactive() {
		return this.userLoginIsactive;
	}

	public void setUserLoginIsactive(boolean userLoginIsactive) {
		this.userLoginIsactive = userLoginIsactive;
	}


	//bi-directional many-to-one association to MasUser
	@ManyToOne
	@JoinColumn(name="user_id")
	public MasUsersEntity getMasUsers() {
		return masUsers;
	}
	
	public void setMasUsers(MasUsersEntity masUsers) {
		this.masUsers = masUsers;
	}

}