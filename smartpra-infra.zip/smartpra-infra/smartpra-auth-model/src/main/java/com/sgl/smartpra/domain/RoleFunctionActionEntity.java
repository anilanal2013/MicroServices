package com.sgl.smartpra.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "role_function_action")
public class RoleFunctionActionEntity  extends AbstractAuditingEntity implements java.io.Serializable {

	@Id
	@Column(name = "role_function_action_id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
	@SequenceGenerator(name = "sequenceGenerator")
	private Long roleFunctionActionId;
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name = "role_id")
	private MasRoleEntity masRole;
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name = "screen_function_action_id")
	private FunctionActionsEntity functionActions;

	public MasRoleEntity getMasRole() {
		return masRole;
	}

	public void setMasRole(MasRoleEntity masRole) {
		this.masRole = masRole;
	}

	public FunctionActionsEntity getFunctionActions() {
		return functionActions;
	}

	public void setFunctionActions(FunctionActionsEntity functionActions) {
		this.functionActions = functionActions;
	}

	public Long getRoleFunctionActionId() {
		return roleFunctionActionId;
	}

	public void setRoleFunctionActionId(Long roleFunctionActionId) {
		this.roleFunctionActionId = roleFunctionActionId;
	}

	@Override
	public String toString() {
		return "RoleFunctionActionEntity [roleFunctionActionId=" + roleFunctionActionId + ", masRole=" + masRole
				+ ", functionActions=" + functionActions + "]";
	}

}
