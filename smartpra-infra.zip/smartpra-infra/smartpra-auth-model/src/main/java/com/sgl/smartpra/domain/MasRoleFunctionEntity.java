package com.sgl.smartpra.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "mas_role_function")
public class MasRoleFunctionEntity extends AbstractAuditingEntity {

	@Id
	@Column(name = "role_function_id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long roleFunctionId;

	// bi-directional many-to-one association to functionActionsEntity
	@ManyToOne(fetch = FetchType.LAZY ,cascade = CascadeType.ALL)
	@JoinColumn(name = "function_action_id", nullable = false)
	private FunctionActionsEntity functionActionsEntity;
	
	// bi-directional many-to-one association to MasRole
	@ManyToOne(fetch = FetchType.LAZY ,cascade = CascadeType.ALL)
	@JoinColumn(name = "role_id", nullable = false)
	private MasRoleEntity masRoleEntity;
	
	@Column(name = "is_active", nullable = false, length = 1)
	private Boolean isActive;

	public Long getRoleFunctionId() {
		return roleFunctionId;
	}

	public void setRoleFunctionId(Long roleFunctionId) {
		this.roleFunctionId = roleFunctionId;
	}

	public FunctionActionsEntity getFunctionActionsEntity() {
		return functionActionsEntity;
	}

	public void setFunctionActionsEntity(FunctionActionsEntity functionActionsEntity) {
		this.functionActionsEntity = functionActionsEntity;
	}

	public MasRoleEntity getMasRoleEntity() {
		return masRoleEntity;
	}

	public void setMasRoleEntity(MasRoleEntity masRoleEntity) {
		this.masRoleEntity = masRoleEntity;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

}
