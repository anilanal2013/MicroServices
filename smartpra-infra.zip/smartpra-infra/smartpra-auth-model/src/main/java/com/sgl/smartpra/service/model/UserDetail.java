package com.sgl.smartpra.service.model;

import java.util.List;
import java.util.Set;

import lombok.Data;

@Data
public class UserDetail {

	public String displayName;
	
	public byte[] userPhoto;
	
	public Set<String> menus;
	
	private List<RoleActionPrivileges> function;
	
}
