package com.sgl.smartpra.service.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the MasProcessEntity entity.
 */
public class MasProcess extends AuditableColumns implements Serializable {

	private Long masProcessDTOId;

	private String processName;

	private Boolean isActive;

	public Long getMasProcessDTOId() {
		return masProcessDTOId;
	}

	public void setMasProcessDTOId(Long masProcessDTOId) {
		this.masProcessDTOId = masProcessDTOId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public Boolean isIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		MasProcess masProcessDTO = (MasProcess) o;
		if (masProcessDTO.getMasProcessDTOId() == null || getMasProcessDTOId() == null) {
			return false;
		}
		return Objects.equals(getMasProcessDTOId(), masProcessDTO.getMasProcessDTOId());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getMasProcessDTOId());
	}

	@Override
	public String toString() {
		return "MasProcess{" + "id=" + getMasProcessDTOId() + ", processName='" + getProcessName() + "'"
				+ ", isActive='" + isIsActive() + "'" + "}";
	}
}
