package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the MasModuleEntity entity.
 */
public class MasModule extends AuditableColumns implements Serializable {

    private Long masModuleId;

    private String moduleName;

    private Integer clientId;

    private Integer moduleManagerId;

    private Boolean isActive;



    public Long getMasModuleId() {
		return masModuleId;
	}

	public void setMasModuleId(Long masModuleId) {
		this.masModuleId = masModuleId;
	}

	public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Integer getModuleManagerId() {
        return moduleManagerId;
    }

    public void setModuleManagerId(Integer moduleManagerId) {
        this.moduleManagerId = moduleManagerId;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MasModule masModuleDTO = (MasModule) o;
        if (masModuleDTO.getMasModuleId() == null || getMasModuleId() == null) {
            return false;
        }
        return Objects.equals(getMasModuleId(), masModuleDTO.getMasModuleId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getMasModuleId());
    }

    @Override
    public String toString() {
        return "MasModule{" +
            "id=" + getMasModuleId() +
            ", moduleName='" + getModuleName() + "'" +
            ", clientId=" + getClientId() +
            ", moduleManagerId=" + getModuleManagerId() +
            ", isActive='" + isIsActive() + "'" +
            "}";
    }
}
