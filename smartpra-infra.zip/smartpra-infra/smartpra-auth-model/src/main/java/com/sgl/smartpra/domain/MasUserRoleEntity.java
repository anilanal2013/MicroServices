package com.sgl.smartpra.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "mas_user_role")
public class MasUserRoleEntity extends AbstractAuditingEntity implements java.io.Serializable {

	private Long userRoleId;
	private MasRoleEntity masRole;
	private MasUsersEntity masUsers;
	private Boolean isActive;
	

	public MasUserRoleEntity() {
	}

	
	@Id
	@Column(name = "user_role_id", unique = true, nullable = false)
	/*@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")*/
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getUserRoleId() {
		return this.userRoleId;
	}

	public void setUserRoleId(Long userRoleId) {
		this.userRoleId = userRoleId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "role_id", nullable = false)
	@NotNull
	public MasRoleEntity getMasRole() {
		return this.masRole;
	}

	public void setMasRole(MasRoleEntity masRole) {
		this.masRole = masRole;
	}

	@ManyToOne(fetch = FetchType.LAZY ,  cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", nullable = false)
	@NotNull
	public MasUsersEntity getMasUsers() {
		return this.masUsers;
	}

	public void setMasUsers(MasUsersEntity masUsers) {
		this.masUsers = masUsers;
	}

	@Column(name = "is_active", nullable = false, length = 1)
	public Boolean getIsActive() {
		return this.isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	
}
