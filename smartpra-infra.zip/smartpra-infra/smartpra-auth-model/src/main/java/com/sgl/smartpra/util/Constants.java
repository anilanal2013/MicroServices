package com.sgl.smartpra.util;

/**
 * Application constants.
 */
public final class Constants {

	// Regex for acceptable logins
	public static final String LOGIN_REGEX = "^[_.@A-Za-z0-9-]*$";
	public static final String SYSTEM_ACCOUNT = "Admin";
	public static final String ANONYMOUS_USER = "anonymoususer";
	public static final String DEFAULT_LANGUAGE = "en";
	public static final String SPRING_PROFILE_DEVELOPMENT = "dev";
	public static final String SPRING_PROFILE_TEST = "test";
	public static final String SPRING_PROFILE_PRODUCTION = "prod";
	public static final String SPRING_PROFILE_CLOUD = "cloud";
	public static final String SPRING_PROFILE_SWAGGER = "swagger";
	public static final String SPRING_PROFILE_K8S = "k8s";
	
	public static final String REQUEST_HEADER_AUTHORIZATION = "Authorization";
	public static final String REQUEST_HEADER_AUTHORIZATION_VALUE = "Basic ZGV2Z2xhbi1jbGllbnQ6ZGV2Z2xhbi1zZWNyZXQ=";
	
	public static final String RESPONSE_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
	public static final String RESPONSE_ALLOW_ORIGIN_VALUE = "*";
	public static final String RESPONSE_ALLOW_METHODS = "Access-Control-Allow-Methods";
	public static final String RESPONSE_ALLOW_METHODS_VALUE = "POST, GET, OPTIONS, DELETE, PUT";
	
	public static final String RESPONSE_ALLOW_MAX_AGE ="Access-Control-Max-Age";
	public static final String RESPONSE_ALLOW_MAX_AGE_VALUE ="3600";
	
	public static final String RESPONSE_ALLOW_HEADERS="Access-Control-Allow-Headers";
	public static final String RESPONSE_ALLOW_HEADERS_VALUE="x-requested-with, authorization, x-auth-token, origin, content-type, accept";

	public Constants() {
		//Default Constructor
	}
}
