package com.sgl.smartpra.service.model;
import java.time.Instant;
import java.io.Serializable;
import java.util.Objects;

import com.sgl.smartpra.domain.MasUsersEntity;

/**
 * A DTO for the MasUserLoginEntity entity.
 */
public class MasUserLogin extends AuditableColumns implements Serializable {

	private Long userLoginId;


	private boolean userLoginIsactive;
	
	private Boolean isFirstTimeLogin;
	
	private String isFirstTimePasswordChanged;
	
	private Boolean isLoginLocked;
	
	private Boolean isPasswordReset;
	
	private int failedLoginAttempts;
		
	private String lastAccessedScreenCtrlId;
	
	private String lastLoggedInCxrId;
	
	private String lastLoggedInIpAddress;
	
	private int lstLoginDayIdleSessionCnt;
	
	private String productivityLevel;
	
	private Instant lastLoginTime;

	private Instant last_logoutTime;

    private Long masUsersId;

	public Long getUserLoginId() {
		return userLoginId;
	}

	public void setUserLoginId(Long userLoginId) {
		this.userLoginId = userLoginId;
	}

	public boolean isUserLoginIsactive() {
		return userLoginIsactive;
	}

	public void setUserLoginIsactive(boolean userLoginIsactive) {
		this.userLoginIsactive = userLoginIsactive;
	}

	public Boolean getIsFirstTimeLogin() {
		return isFirstTimeLogin;
	}

	public void setIsFirstTimeLogin(Boolean isFirstTimeLogin) {
		this.isFirstTimeLogin = isFirstTimeLogin;
	}

	public String getIsFirstTimePasswordChanged() {
		return isFirstTimePasswordChanged;
	}

	public void setIsFirstTimePasswordChanged(String isFirstTimePasswordChanged) {
		this.isFirstTimePasswordChanged = isFirstTimePasswordChanged;
	}

	public Boolean getIsLoginLocked() {
		return isLoginLocked;
	}

	public void setIsLoginLocked(Boolean isLoginLocked) {
		this.isLoginLocked = isLoginLocked;
	}

	public Boolean getIsPasswordReset() {
		return isPasswordReset;
	}

	public void setIsPasswordReset(Boolean isPasswordReset) {
		this.isPasswordReset = isPasswordReset;
	}

	public int getFailedLoginAttempts() {
		return failedLoginAttempts;
	}

	public void setFailedLoginAttempts(int failedLoginAttempts) {
		this.failedLoginAttempts = failedLoginAttempts;
	}

	public String getLastAccessedScreenCtrlId() {
		return lastAccessedScreenCtrlId;
	}

	public void setLastAccessedScreenCtrlId(String lastAccessedScreenCtrlId) {
		this.lastAccessedScreenCtrlId = lastAccessedScreenCtrlId;
	}

	public String getLastLoggedInCxrId() {
		return lastLoggedInCxrId;
	}

	public void setLastLoggedInCxrId(String lastLoggedInCxrId) {
		this.lastLoggedInCxrId = lastLoggedInCxrId;
	}

	public String getLastLoggedInIpAddress() {
		return lastLoggedInIpAddress;
	}

	public void setLastLoggedInIpAddress(String lastLoggedInIpAddress) {
		this.lastLoggedInIpAddress = lastLoggedInIpAddress;
	}

	public int getLstLoginDayIdleSessionCnt() {
		return lstLoginDayIdleSessionCnt;
	}

	public void setLstLoginDayIdleSessionCnt(int lstLoginDayIdleSessionCnt) {
		this.lstLoginDayIdleSessionCnt = lstLoginDayIdleSessionCnt;
	}

	public String getProductivityLevel() {
		return productivityLevel;
	}

	public void setProductivityLevel(String productivityLevel) {
		this.productivityLevel = productivityLevel;
	}

	public Instant getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Instant lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public Instant getLast_logoutTime() {
		return last_logoutTime;
	}

	public void setLast_logoutTime(Instant last_logoutTime) {
		this.last_logoutTime = last_logoutTime;
	}

	public Long getMasUsersId() {
		return masUsersId;
	}

	public void setMasUsersId(Long masUsersId) {
		this.masUsersId = masUsersId;
	}


}
