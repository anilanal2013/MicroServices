package com.sgl.smartpra.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "mas_function_action")
public class FunctionActionsEntity  extends AbstractAuditingEntity implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "function_action_id", unique = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long functionActionId;

	@ManyToOne(fetch = FetchType.LAZY ,cascade = CascadeType.ALL)
	@JoinColumn(name = "function_id")
	private ScreenFunctionEntity screenFunctionEntity;

	@ManyToOne(fetch = FetchType.LAZY ,cascade= CascadeType.ALL)
	@JoinColumn(name = "action_id")
	private ActionEntity actionEntity;
	
	@Column(name = "is_active", nullable = false, length = 1)
	private Boolean isActive;
	
	public Long getFunctionActionId() {
		return functionActionId;
	}

	public void setFunctionActionId(Long functionActionId) {
		this.functionActionId = functionActionId;
	}

	public ScreenFunctionEntity getScreenFunctionEntity() {
		return screenFunctionEntity;
	}

	public void setScreenFunctionEntity(ScreenFunctionEntity screenFunctionEntity) {
		this.screenFunctionEntity = screenFunctionEntity;
	}

	public ActionEntity getActionEntity() {
		return actionEntity;
	}

	public void setActionEntity(ActionEntity actionEntity) {
		this.actionEntity = actionEntity;
	}

	public Boolean getIsActive() {
		return this.isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

}
