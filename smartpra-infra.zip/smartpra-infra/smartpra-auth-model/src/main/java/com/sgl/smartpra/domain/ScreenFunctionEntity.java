package com.sgl.smartpra.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mas_function")
public class ScreenFunctionEntity  extends AbstractAuditingEntity implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "function_id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long screenFunctionId;

	@Column(name = "function_name", nullable = false, length = 1)
	private String screenFunctionName;
	
	@Column(name = "function_description", nullable = false, length = 1)
	private String screenFunctiondescription;

	public Long getScreenFunctionId() {
		return screenFunctionId;
	}

	public void setScreenFunctionId(Long screenFunctionId) {
		this.screenFunctionId = screenFunctionId;
	}

	public String getScreenFunctionName() {
		return screenFunctionName;
	}

	public void setScreenFunctionName(String screenFunctionName) {
		this.screenFunctionName = screenFunctionName;
	}

	public String getScreenFunctiondescription() {
		return screenFunctiondescription;
	}

	public void setScreenFunctiondescription(String screenFunctiondescription) {
		this.screenFunctiondescription = screenFunctiondescription;
	}

}
