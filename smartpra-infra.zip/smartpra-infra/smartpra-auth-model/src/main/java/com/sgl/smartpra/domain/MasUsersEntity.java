package com.sgl.smartpra.domain;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "mas_users")
public class MasUsersEntity extends AbstractAuditingEntity implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Long userId;
	private String userName;
	private String userFullName;
	private String displayName;
	private String firstName;
	private String middleName;
	private String lastName;
	private String categoryLevel;
	private String processName;
	private Integer userManagerId;
	private Integer userTeamId;
	private String email;
	private Integer userRoleId;
	private Integer userModuleId;
	private Integer userGroupId;
	private Instant shiftStartTime;
	private Instant shiftEndTime;
	private byte[] userPhoto;
	private Instant dateOfJoining;
	private String preferredLanguage;
	private String userAddress1;
	private String userAddress2;
	private String userAddress3;
	private byte[] voiceProfile;
	private String userEmail;
	private String userRemarks;
	private String airLineCode;
	private String departmentName;
	private String organizationName;
	private Boolean isActive = true;
	//private boolean isUserActive;
	private MasUserPasswordEntity masUserPassword;
	private String langKey;
	private String activationKey;
	private String resetKey;
	private Instant resetDate;
	private Set<MasUserLoginEntity> masUserLogins = new HashSet<MasUserLoginEntity>(0);
	private Set<UserLoginSessionCurrentDayEntity> userLoginSessionCurrentDaies = new HashSet<UserLoginSessionCurrentDayEntity>(0);
	private Set<MasPasswordSecretQuestionEntity> masPasswordSecretQuestions = new HashSet<MasPasswordSecretQuestionEntity>(0);
	private Set<MasUserRoleEntity> masUserRoles = new HashSet<MasUserRoleEntity>(0);
	private Set<MasUserGroupEntity> masUserGroups = new HashSet<MasUserGroupEntity>(0);

	//private Set<UserPasswordHistoryEntity> userPasswordHistories = new HashSet<UserPasswordHistoryEntity>(0);
	private Set<MasUserTeamEntity> masUserTeams = new HashSet<MasUserTeamEntity>(0);
	private Set<User2faLoginEntity> user2faLogins = new HashSet<User2faLoginEntity>(0);
	private Set<MasUserModuleEntity> masUserModules = new HashSet<MasUserModuleEntity>(0);
	
	private Set<MasRoleEntity> masRoles;


	private String userTelephone;

	public MasUsersEntity() {
	}
	

	


	public MasUsersEntity(String userName, String email, Instant dateOfJoining, Boolean isActive, String langKey,
			String activationKey, String resetKey, Instant resetDate) {
		super();
		this.userName = userName;
		this.email = email;
		this.dateOfJoining = dateOfJoining;
		this.isActive = isActive;
		this.langKey = langKey;
		this.activationKey = activationKey;
		this.resetKey = resetKey;
		this.resetDate = resetDate;
	}





	@Id
	@Column(name = "user_id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
  //  @SequenceGenerator(name = "sequenceGenerator")
	public Long getUserId() {
		return this.userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@Column(name = "user_name", nullable = false, length = 20)
	@NotNull
	@Size(max = 20)
	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Column(name = "user_full_name", length = 100)
	@Size(max = 100)
	public String getUserFullName() {
		return this.userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	@Column(name = "display_name", length = 50)
	@Size(max = 50)
	public String getDisplayName() {
		return this.displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	@Column(name = "first_name", length = 20)
	@Size(max = 20)
	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@Column(name = "middle_name", length = 20)
	@Size(max = 20)
	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	@Column(name = "last_name", length = 20)
	@Size(max = 20)
	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Column(name = "category_level", length = 15)
	@Size(max = 15)
	public String getCategoryLevel() {
		return this.categoryLevel;
	}

	public void setCategoryLevel(String categoryLevel) {
		this.categoryLevel = categoryLevel;
	}

	@Column(name = "process_name", length = 20)
	@Size(max = 20)
	public String getProcessName() {
		return this.processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	@Column(name = "user_manager_id")
	public Integer getUserManagerId() {
		return this.userManagerId;
	}

	public void setUserManagerId(Integer userManagerId) {
		this.userManagerId = userManagerId;
	}

	@Column(name = "user_team_id")
	public Integer getUserTeamId() {
		return this.userTeamId;
	}

	public void setUserTeamId(Integer userTeamId) {
		this.userTeamId = userTeamId;
	}

	@Column(name = "email", length = 50)
	@Size(max = 50)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "user_role_id")
	public Integer getUserRoleId() {
		return this.userRoleId;
	}

	public void setUserRoleId(Integer userRoleId) {
		this.userRoleId = userRoleId;
	}

	@Column(name = "user_module_id")
	public Integer getUserModuleId() {
		return this.userModuleId;
	}

	public void setUserModuleId(Integer userModuleId) {
		this.userModuleId = userModuleId;
	}

	@Column(name = "user_group_id")
	public Integer getUserGroupId() {
		return this.userGroupId;
	}

	public void setUserGroupId(Integer userGroupId) {
		this.userGroupId = userGroupId;
	}

	//@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "shift_start_time", length = 23)
	public Instant getShiftStartTime() {
		return this.shiftStartTime;
	}

	public void setShiftStartTime(Instant shiftStartTime) {
		this.shiftStartTime = shiftStartTime;
	}

	//@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "shift_end_time", length = 23)
	public Instant getShiftEndTime() {
		return this.shiftEndTime;
	}

	public void setShiftEndTime(Instant shiftEndTime) {
		this.shiftEndTime = shiftEndTime;
	}

	@Column(name = "user_photo")
	public byte[] getUserPhoto() {
		return this.userPhoto;
	}

	public void setUserPhoto(byte[] userPhoto) {
		this.userPhoto = userPhoto;
	}

	//@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_of_joining", length = 23)
	public Instant getDateOfJoining() {
		return this.dateOfJoining;
	}

	public void setDateOfJoining(Instant dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	@Column(name = "preferred_language", length = 20)
	@Size(max = 20)
	public String getPreferredLanguage() {
		return this.preferredLanguage;
	}

	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}

	@Column(name = "user_address_1", length = 50)
	@Size(max = 50)
	public String getUserAddress1() {
		return this.userAddress1;
	}

	public void setUserAddress1(String userAddress1) {
		this.userAddress1 = userAddress1;
	}

	@Column(name = "user_address_2", length = 50)
	@Size(max = 50)
	public String getUserAddress2() {
		return this.userAddress2;
	}

	public void setUserAddress2(String userAddress2) {
		this.userAddress2 = userAddress2;
	}

	@Column(name = "user_address_3", length = 50)
	@Size(max = 50)
	public String getUserAddress3() {
		return this.userAddress3;
	}

	public void setUserAddress3(String userAddress3) {
		this.userAddress3 = userAddress3;
	}

	@Column(name = "voice_profile")
	public byte[] getVoiceProfile() {
		return this.voiceProfile;
	}

	public void setVoiceProfile(byte[] voiceProfile) {
		this.voiceProfile = voiceProfile;
	}

	@Column(name = "user_email", length = 100)
	@Size(max = 100)
	public String getUserEmail() {
		return this.userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	@Column(name = "user_remarks", length = 100)
	@Size(max = 100)
	public String getUserRemarks() {
		return this.userRemarks;
	}

	public void setUserRemarks(String userRemarks) {
		this.userRemarks = userRemarks;
	}

	@Column(name = "is_active", nullable = false)
	public Boolean getIsActive() {
		return this.isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masUsers")
	public Set<MasUserLoginEntity> getMasUserLogins() {
		return this.masUserLogins;
	}

	public void setMasUserLogins(Set<MasUserLoginEntity> masUserLogins) {
		this.masUserLogins = masUserLogins;
	}
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masUsers")
	public Set<UserLoginSessionCurrentDayEntity> getUserLoginSessionCurrentDaies() {
		return this.userLoginSessionCurrentDaies;
	}

	public void setUserLoginSessionCurrentDaies(Set<UserLoginSessionCurrentDayEntity> userLoginSessionCurrentDaies) {
		this.userLoginSessionCurrentDaies = userLoginSessionCurrentDaies;
	}
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masUsers")
	public Set<MasPasswordSecretQuestionEntity> getMasPasswordSecretQuestions() {
		return this.masPasswordSecretQuestions;
	}

	public void setMasPasswordSecretQuestions(Set<MasPasswordSecretQuestionEntity> masPasswordSecretQuestions) {
		this.masPasswordSecretQuestions = masPasswordSecretQuestions;
	}

	@JsonIgnore
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "masUsers",  cascade = CascadeType.ALL)
	public Set<MasUserRoleEntity> getMasUserRoles() {
		return this.masUserRoles;
	}

	public void setMasUserRoles(Set<MasUserRoleEntity> masUserRoles) {
		this.masUserRoles = masUserRoles;
	}
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masUsers")
	public Set<MasUserGroupEntity> getMasUserGroups() {
		return this.masUserGroups;
	}

	public void setMasUserGroups(Set<MasUserGroupEntity> masUserGroups) {
		this.masUserGroups = masUserGroups;
	}

	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "masUsers")
	public MasUserPasswordEntity getMasUserPassword() {
		return masUserPassword;
	}

	public void setMasUserPassword(MasUserPasswordEntity masUserPassword) {
		this.masUserPassword = masUserPassword;
	}

/*	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masUsers")
	public Set<UserPasswordHistoryEntity> getUserPasswordHistories() {
		return this.userPasswordHistories;
	}

	public void setUserPasswordHistories(Set<UserPasswordHistoryEntity> userPasswordHistories) {
		this.userPasswordHistories = userPasswordHistories;
	}*/
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masUsers")
	public Set<MasUserTeamEntity> getMasUserTeams() {
		return this.masUserTeams;
	}

	public void setMasUserTeams(Set<MasUserTeamEntity> masUserTeams) {
		this.masUserTeams = masUserTeams;
	}
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masUsers")
	public Set<User2faLoginEntity> getUser2faLogins() {
		return this.user2faLogins;
	}

	public void setUser2faLogins(Set<User2faLoginEntity> user2faLogins) {
		this.user2faLogins = user2faLogins;
	}
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masUsers")
	public Set<MasUserModuleEntity> getMasUserModules() {
		return this.masUserModules;
	}

	public void setMasUserModules(Set<MasUserModuleEntity> masUserModules) {
		this.masUserModules = masUserModules;
	}

	/*@Transient
	public boolean isUserActive() {
		if (isActive == 'Y') {
			setUserActive(true);
		} else {
			setUserActive(false);
		}

		return isUserActive;
	}

	public void setUserActive(boolean isUserActive) {
		this.isUserActive = isUserActive;
	}*/

	@Size(min = 2, max = 6)
	@Column(name = "lang_key", length = 6)
	public String getLangKey() {
		return langKey;
	}

	public void setLangKey(String langKey) {
		this.langKey = langKey;
	}

	@Size(max = 20)
	@Column(name = "activation_key", length = 20)
	@JsonIgnore
	public String getActivationKey() {
		return activationKey;
	}

	public void setActivationKey(String activationKey) {
		this.activationKey = activationKey;
	}

	@Size(max = 20)
	@Column(name = "reset_key", length = 20)
	@JsonIgnore
	public String getResetKey() {
		return resetKey;
	}

	public void setResetKey(String resetKey) {
		this.resetKey = resetKey;
	}

	@Column(name = "reset_date")
	public Instant getResetDate() {
		return resetDate;
	}
	
	public void setResetDate(Instant resetDate) {
		this.resetDate = resetDate;
	}
	
	@Column(name="user_telephone", length=30)
	public String getUserTelephone() {
		return userTelephone;
	}

	public void setUserTelephone(String userTelephone) {
		this.userTelephone = userTelephone;
	}


	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(schema="SmartPRAUsers",name = "mas_user_role", joinColumns = {
			@JoinColumn(name = "user_id", referencedColumnName = "user_id") }, inverseJoinColumns = {
					@JoinColumn(name = "role_id", referencedColumnName = "role_id") })
	public Set<MasRoleEntity> getMasRoles() {
		return masRoles;
	}

	public void setMasRoles(Set<MasRoleEntity> masRoles) {
		this.masRoles = masRoles;
	}


	@Size(min = 3, max = 3)
	@Column(name = "airline_code", length = 3)
	public String getAirLineCode() {
		return airLineCode;
	}

	public void setAirLineCode(String airLineCode) {
		this.airLineCode = airLineCode;
	}
	@Column(name = "department_name")
	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	@Column(name = "organization_name")
	public String getOrganizationName() {
		return organizationName;
	}


	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MasUsersEntity [userId=");
		builder.append(userId);
		builder.append(", userName=");
		builder.append(userName);
		builder.append(", userFullName=");
		builder.append(userFullName);
		builder.append(", displayName=");
		builder.append(displayName);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", middleName=");
		builder.append(middleName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", categoryLevel=");
		builder.append(categoryLevel);
		builder.append(", processName=");
		builder.append(processName);
		builder.append(", userManagerId=");
		builder.append(userManagerId);
		builder.append(", userTeamId=");
		builder.append(userTeamId);
		builder.append(", email=");
		builder.append(email);
		builder.append(", userRoleId=");
		builder.append(userRoleId);
		builder.append(", userModuleId=");
		builder.append(userModuleId);
		builder.append(", userGroupId=");
		builder.append(userGroupId);
		builder.append(", shiftStartTime=");
		builder.append(shiftStartTime);
		builder.append(", shiftEndTime=");
		builder.append(shiftEndTime);
		builder.append(", dateOfJoining=");
		builder.append(dateOfJoining);
		builder.append(", preferredLanguage=");
		builder.append(preferredLanguage);
		builder.append(", userAddress1=");
		builder.append(userAddress1);
		builder.append(", userAddress2=");
		builder.append(userAddress2);
		builder.append(", userAddress3=");
		builder.append(userAddress3);
		builder.append(", userEmail=");
		builder.append(userEmail);
		builder.append(", userRemarks=");
		builder.append(userRemarks);
		builder.append(", isActive=");
		builder.append(isActive);
		builder.append(", masUserPassword=");
		builder.append(masUserPassword);
		builder.append(", langKey=");
		builder.append(langKey);
		builder.append(", activationKey=");
		builder.append(activationKey);
		builder.append(", resetKey=");
		builder.append(resetKey);
		builder.append(", resetDate=");
		builder.append(resetDate);
		builder.append("]");
		return builder.toString();
	}
	

}