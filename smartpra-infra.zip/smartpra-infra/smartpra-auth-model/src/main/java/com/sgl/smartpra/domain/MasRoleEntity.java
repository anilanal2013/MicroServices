package com.sgl.smartpra.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "mas_role")
public class MasRoleEntity extends AbstractAuditingEntity implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Long roleId;
	private String roleName;
	private Boolean isActive;
	
	private Set<MasUserRoleEntity> masUserRoles = new HashSet<MasUserRoleEntity>(0);
	
	private Set<RoleFunctionActionEntity> roleFunctios=new HashSet<>();

	public MasRoleEntity() {
	}
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "functionActions",cascade=CascadeType.MERGE)
	public Set<RoleFunctionActionEntity> getRoleFunctios() {
		return roleFunctios;
	}

	public void setRoleFunctios(Set<RoleFunctionActionEntity> roleFunctios) {
		this.roleFunctios = roleFunctios;
	}

	@Id
	@Column(name = "role_id", unique = true, nullable = false)
	/*@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
	@SequenceGenerator(name = "sequenceGenerator")*/
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getRoleId() {
		return this.roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	@Column(name = "role_name", nullable = false, length = 20)
	@NotNull
	@Size(max = 20)
	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Column(name = "is_active", nullable = false, length = 1)
	public Boolean getIsActive() {
		return this.isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masRole")
	public Set<MasUserRoleEntity> getMasUserRoles() {
		return this.masUserRoles;
	}

	public void setMasUserRoles(Set<MasUserRoleEntity> masUserRoles) {
		this.masUserRoles = masUserRoles;
	}

}