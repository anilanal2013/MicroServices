package com.sgl.smartpra.service.model;

import java.io.Serializable;

public class ScreenFunction extends AuditableColumns implements Serializable{

	private Long screenFunctionId;


	private String screenFunctionName;

	public Long getScreenFunctionId() {
		return screenFunctionId;
	}

	public void setScreenFunctionId(Long screenFunctionId) {
		this.screenFunctionId = screenFunctionId;
	}

	public String getScreenFunctionName() {
		return screenFunctionName;
	}

	public void setScreenFunctionName(String screenFunctionName) {
		this.screenFunctionName = screenFunctionName;
	}

}
