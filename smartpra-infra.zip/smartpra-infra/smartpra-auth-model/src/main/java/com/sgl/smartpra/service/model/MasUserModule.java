package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the MasUserModuleEntity entity.
 */
public class MasUserModule extends AuditableColumns implements Serializable {

    private Long masUserModuleId;

    private Boolean isActive;


    private Long masUsersId;

    private Long masModuleId;

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Long getMasUsersId() {
        return masUsersId;
    }

    public void setMasUsersId(Long masUsersId) {
        this.masUsersId = masUsersId;
    }

    public Long getMasModuleId() {
        return masModuleId;
    }

    public void setMasModuleId(Long masModuleId) {
        this.masModuleId = masModuleId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MasUserModule masUserModuleDTO = (MasUserModule) o;
        if (masUserModuleDTO.getMasModuleId() == null || getMasModuleId() == null) {
            return false;
        }
        return Objects.equals(getMasModuleId(), masUserModuleDTO.getMasModuleId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getMasModuleId());
    }

    public Long getMasUserModuleId() {
		return masUserModuleId;
	}

	public void setMasUserModuleId(Long masUserModuleId) {
		this.masUserModuleId = masUserModuleId;
	}

	@Override
    public String toString() {
        return "MasUserModule{" +
            "id=" + getMasModuleId() +
            ", isActive='" + isIsActive() + "'" +
            ", masUsers=" + getMasUsersId() +
            ", masModule=" + getMasModuleId() +
            "}";
    }
}
