package com.sgl.smartpra.domain;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the mas_menu database table.
 * 
 */
@Entity
@Table(name="mas_menu")
@NamedQuery(name="MasMenu.findAll", query="SELECT m FROM MasMenuEntity m")
public class MasMenuEntity extends AbstractAuditingEntity implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="menu_id", unique=true, nullable=false)
	private Long menuId;

	@Column(name="client_id", nullable=false, length=2)
	private String clientId;

	@Column(name="is_active", nullable=false, length=1)
	private String isActive;

	@Column(name="is_child", nullable=false)
	private int isChild;

	@Column(name="is_parent", nullable=false)
	private int isParent;

	@Column(name="menu_description", length=100)
	private String menuDescription;

	@Column(name="menu_name", length=20)
	private String menuName;

	@Column(name="menu_order")
	private int menuOrder;

	@Column(name="module_id")
	private int moduleId;

	@Column(name="order_by", nullable=false, length=10)
	private String orderBy;

	@Column(name="parent_code", length=100)
	private String parentCode;

	@Column(length=2147483647)
	private String url;

	//bi-directional many-to-one association to MasMenuFunction
	@OneToMany(mappedBy="masMenu")
	private Set<MasMenuFunctionEntity> masMenuFunctions;

	public MasMenuEntity() {
	}

	public Long getMenuId() {
		return this.menuId;
	}

	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public int getIsChild() {
		return this.isChild;
	}

	public void setIsChild(int isChild) {
		this.isChild = isChild;
	}

	public int getIsParent() {
		return this.isParent;
	}

	public void setIsParent(int isParent) {
		this.isParent = isParent;
	}

	public String getMenuDescription() {
		return this.menuDescription;
	}

	public void setMenuDescription(String menuDescription) {
		this.menuDescription = menuDescription;
	}

	public String getMenuName() {
		return this.menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public int getMenuOrder() {
		return this.menuOrder;
	}

	public void setMenuOrder(int menuOrder) {
		this.menuOrder = menuOrder;
	}

	public int getModuleId() {
		return this.moduleId;
	}

	public void setModuleId(int moduleId) {
		this.moduleId = moduleId;
	}

	public String getOrderBy() {
		return this.orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getParentCode() {
		return this.parentCode;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Set<MasMenuFunctionEntity> getMasMenuFunctions() {
		return this.masMenuFunctions;
	}

	public void setMasMenuFunctions(Set<MasMenuFunctionEntity> masMenuFunctions) {
		this.masMenuFunctions = masMenuFunctions;
	}

	public MasMenuFunctionEntity addMasMenuFunction(MasMenuFunctionEntity masMenuFunction) {
		getMasMenuFunctions().add(masMenuFunction);
		masMenuFunction.setMasMenu(this);

		return masMenuFunction;
	}

	public MasMenuFunctionEntity removeMasMenuFunction(MasMenuFunctionEntity masMenuFunction) {
		getMasMenuFunctions().remove(masMenuFunction);
		masMenuFunction.setMasMenu(null);

		return masMenuFunction;
	}

}