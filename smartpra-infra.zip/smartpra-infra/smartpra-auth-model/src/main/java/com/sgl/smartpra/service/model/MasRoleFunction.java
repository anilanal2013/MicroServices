package com.sgl.smartpra.service.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;

public class MasRoleFunction extends AuditableColumns implements Serializable{

	private Long roleFunctionId;
	private Long roleId;
	private Long functionActionId;

	public Long getRoleFunctionId() {
		return roleFunctionId;
	}

	public void setRoleFunctionId(Long roleFunctionId) {
		this.roleFunctionId = roleFunctionId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Long getFunctionActionId() {
		return functionActionId;
	}

	public void setFunctionActionId(Long functionActionId) {
		this.functionActionId = functionActionId;
	}

}
