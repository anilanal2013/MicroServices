package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.util.Objects;

import javax.validation.constraints.Size;

/**
 * A DTO for the MasUserPasswordEntity entity.
 */
public class MasUserPassword extends AuditableColumns implements Serializable {
	
	
	public static final int PASSWORD_MIN_LENGTH = 4;

	public static final int PASSWORD_MAX_LENGTH = 100;



    private Long userPwdId;

    private Integer invalidPwdCount;
    @Size(min = PASSWORD_MIN_LENGTH, max = PASSWORD_MAX_LENGTH)
    private String passwordHash;

    private String salt;


 
    public Long getUserPwdId() {
		return userPwdId;
	}

	public void setUserPwdId(Long userPwdId) {
		this.userPwdId = userPwdId;
	}

	public Integer getInvalidPwdCount() {
        return invalidPwdCount;
    }

    public void setInvalidPwdCount(Integer invalidPwdCount) {
        this.invalidPwdCount = invalidPwdCount;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MasUserPassword masUserPasswordDTO = (MasUserPassword) o;
        if (masUserPasswordDTO.getUserPwdId() == null || getUserPwdId() == null) {
            return false;
        }
        return Objects.equals(getUserPwdId(), masUserPasswordDTO.getUserPwdId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getUserPwdId());
    }

    @Override
    public String toString() {
        return "MasUserPassword{" +
            "id=" + getUserPwdId() +
            ", invalidPwdCount=" + getInvalidPwdCount() +
            ", passwordHash='" + getPasswordHash() + "'" +
            ", salt='" + getSalt() + "'" +
            "}";
    }
}
