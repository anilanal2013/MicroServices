package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import com.sgl.smartpra.domain.MasGroupEntity;

/**
 * A DTO for the MasTeamEntity entity.
 */
public class MasTeam extends AuditableColumns implements Serializable {

	private Long teamId;
	private Long groupId;
	private String teamName;
	private Integer clientId;
	private Integer teamManagerId;
	private Boolean isActive;
	private List<MasUsers> masUser;
	public Long getTeamId() {
		return teamId;
	}
	public void setTeamId(Long teamId) {
		this.teamId = teamId;
	}

	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public Integer getClientId() {
		return clientId;
	}
	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}
	public Integer getTeamManagerId() {
		return teamManagerId;
	}
	public void setTeamManagerId(Integer teamManagerId) {
		this.teamManagerId = teamManagerId;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public List<MasUsers> getMasUser() {
		return masUser;
	}

	public void setMasUser(List<MasUsers> masUser) {
		this.masUser = masUser;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((teamId == null) ? 0 : teamId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MasTeam other = (MasTeam) obj;
		if (teamId == null) {
			if (other.teamId != null)
				return false;
		} else if (!teamId.equals(other.teamId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MasTeam [teamId=");
		builder.append(teamId);
		builder.append(", groupId=");
		builder.append(groupId);
		builder.append(", teamName=");
		builder.append(teamName);
		builder.append(", clientId=");
		builder.append(clientId);
		builder.append(", teamManagerId=");
		builder.append(teamManagerId);
		builder.append(", isActive=");
		builder.append(isActive);
		builder.append("]");
		return builder.toString();
	}
	
 
    
  

}
