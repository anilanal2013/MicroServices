package com.sgl.smartpra.service.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the MasUserRoleEntity entity.
 */
public class MasUserRole extends AuditableColumns implements Serializable {

	private Long masUserRoleId;

	private Boolean isActive;

	private Long masUsersId;

	private Long masRoleId;

	public Long getMasUserRoleId() {
		return masUserRoleId;
	}

	public void setMasUserRoleId(Long masUserRoleId) {
		this.masUserRoleId = masUserRoleId;
	}

	public Boolean isIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Long getMasUsersId() {
		return masUsersId;
	}

	public void setMasUsersId(Long masUsersId) {
		this.masUsersId = masUsersId;
	}

	public Long getMasRoleId() {
		return masRoleId;
	}

	public void setMasRoleId(Long masRoleId) {
		this.masRoleId = masRoleId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		MasUserRole masUserRoleDTO = (MasUserRole) o;
		if (masUserRoleDTO.getMasUserRoleId() == null || getMasUserRoleId() == null) {
			return false;
		}
		return Objects.equals(getMasUserRoleId(), masUserRoleDTO.getMasUserRoleId());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getMasUserRoleId());
	}

	@Override
	public String toString() {
		return "MasUserRole{" + "id=" + getMasUserRoleId() + ", isActive='" + isIsActive() + "'" + ", masUsers="
				+ getMasUsersId() + ", masRole=" + getMasRoleId() + "}";
	}
}
