package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the MasUserGroupEntity entity.
 */
public class MasUserGroup extends AuditableColumns implements Serializable {

    private Long masUserGroupId;

    private Boolean isActive;


    private Long masUsersId;

    private Long masGroupId;


    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Long getMasUsersId() {
        return masUsersId;
    }

    public void setMasUsersId(Long masUsersId) {
        this.masUsersId = masUsersId;
    }

    public Long getMasGroupId() {
        return masGroupId;
    }

    public void setMasGroupId(Long masGroupId) {
        this.masGroupId = masGroupId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MasUserGroup masUserGroupDTO = (MasUserGroup) o;
        if (masUserGroupDTO.getMasGroupId() == null || getMasGroupId() == null) {
            return false;
        }
        return Objects.equals(getMasGroupId(), masUserGroupDTO.getMasGroupId());
    }

    public Long getMasUserGroupId() {
		return masUserGroupId;
	}

	public void setMasUserGroupId(Long masUserGroupId) {
		this.masUserGroupId = masUserGroupId;
	}

	@Override
    public int hashCode() {
        return Objects.hashCode(getMasGroupId());
    }

    @Override
    public String toString() {
        return "MasUserGroup{" +
            "id=" + getMasGroupId() +
            ", isActive='" + isIsActive() + "'" +
            ", masUsers=" + getMasUsersId() +
            ", masGroup=" + getMasGroupId() +
            "}";
    }
}
