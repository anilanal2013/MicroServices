package com.sgl.smartpra.service.model;
import java.io.Serializable;
import java.time.Instant;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.validation.constraints.Size;

/**
 * A DTO for the MasUsersEntity entity.
 */
public class MasUsers extends AuditableColumns implements Serializable {

	private static final long serialVersionUID = 1L;

    private Long userId;

    private String userName;

    private String userFullName;

    private String displayName;

    private String firstName;

    private String middleName;

    private String lastName;

    private String categoryLevel;

    private String processName;

    private Integer userManagerId;

    private Integer userTeamId;

    private String email;

    private Integer userRoleId;

    private Integer userModuleId;

    private Integer userGroupId;

    private Instant shiftStartTime;

    private Instant shiftEndTime;

    private byte[] userPhoto;

    private Instant instantOfJoining;

    private String preferredLanguage;

    private String userAddress1;

    private String userAddress2;

    private String userAddress3;

    private byte[] voiceProfile;

    private String userEmail;

    private String userRemarks;

    private Boolean isActive;

    private Instant createInstant;

    private String createdBy;

    private Instant lastUpInstantdInstant;

    private String lastUpInstantdBy;

    private String passwordHash;
    
    private Integer roleId; 
    
	private String airLineCode;
	
	private String departmentName;
	
	private String organizationName;
    
    private Set<MasUserRole> masUserRoles = new HashSet<MasUserRole>();
    
    private Set<MasUserGroup> masUserGroups = new HashSet<MasUserGroup>(0); 
    
    private Set<MasUserTeam> masUserTeams = new HashSet<MasUserTeam>(0);

    private String userProfilePhoto;
    
    private Set<Long> roleIds;
   
	public Set<Long> getRoleIds() {
		return roleIds;
	}

	public void setRoleIds(Set<Long> roleIds) {
		this.roleIds = roleIds;
	}

	public Set<MasUserRole> getMasUserRoles() {
		return masUserRoles;
	}

	public void setMasUserRoles(Set<MasUserRole> masUserRoles) {
		this.masUserRoles = masUserRoles;
	}

	public Set<MasUserGroup> getMasUserGroups() {
		return masUserGroups;
	}

	public void setMasUserGroups(Set<MasUserGroup> masUserGroups) {
		this.masUserGroups = masUserGroups;
	}

	public Set<MasUserTeam> getMasUserTeams() {
		return masUserTeams;
	}

	public void setMasUserTeams(Set<MasUserTeam> masUserTeams) {
		this.masUserTeams = masUserTeams;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	private Long userPwdId;
    
    private String  userTelephone;
    @Size(min = 2, max = 6)
	private String langKey;


    public String getLangKey() {
		return langKey;
	}

	public void setLangKey(String langKey) {
		this.langKey = langKey;
	}

	public String getUserTelephone() {
		return userTelephone;
	}

	public void setUserTelephone(String userTelephone) {
		this.userTelephone = userTelephone;
	}

	public Long getUserPwdId() {
		return userPwdId;
	}

	public void setUserPwdId(Long userPwdId) {
		this.userPwdId = userPwdId;
	}

	public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserFullName() {
        return userFullName;
    }

    public void setUserFullName(String userFullName) {
        this.userFullName = userFullName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCategoryLevel() {
        return categoryLevel;
    }

    public void setCategoryLevel(String categoryLevel) {
        this.categoryLevel = categoryLevel;
    }

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public Integer getUserManagerId() {
        return userManagerId;
    }

    public void setUserManagerId(Integer userManagerId) {
        this.userManagerId = userManagerId;
    }

    public Integer getUserTeamId() {
        return userTeamId;
    }

    public void setUserTeamId(Integer userTeamId) {
        this.userTeamId = userTeamId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getUserRoleId() {
        return userRoleId;
    }

    public void setUserRoleId(Integer userRoleId) {
        this.userRoleId = userRoleId;
    }

    public Integer getUserModuleId() {
        return userModuleId;
    }

    public void setUserModuleId(Integer userModuleId) {
        this.userModuleId = userModuleId;
    }

    public Integer getUserGroupId() {
        return userGroupId;
    }

    public void setUserGroupId(Integer userGroupId) {
        this.userGroupId = userGroupId;
    }

    public Instant getShiftStartTime() {
        return shiftStartTime;
    }

    public void setShiftStartTime(Instant shiftStartTime) {
        this.shiftStartTime = shiftStartTime;
    }

    public Instant getShiftEndTime() {
        return shiftEndTime;
    }

    public void setShiftEndTime(Instant shiftEndTime) {
        this.shiftEndTime = shiftEndTime;
    }

  

    public byte[] getUserPhoto() {
		return userPhoto;
	}

	public void setUserPhoto(byte[] userPhoto) {
		this.userPhoto = userPhoto;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public Instant getInstantOfJoining() {
        return instantOfJoining;
    }

    public void setInstantOfJoining(Instant instantOfJoining) {
        this.instantOfJoining = instantOfJoining;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    public void setPreferredLanguage(String preferredLanguage) {
        this.preferredLanguage = preferredLanguage;
    }

    public String getUserAddress1() {
        return userAddress1;
    }

    public void setUserAddress1(String userAddress1) {
        this.userAddress1 = userAddress1;
    }

    public String getUserAddress2() {
        return userAddress2;
    }

    public void setUserAddress2(String userAddress2) {
        this.userAddress2 = userAddress2;
    }

    public String getUserAddress3() {
        return userAddress3;
    }

    public void setUserAddress3(String userAddress3) {
        this.userAddress3 = userAddress3;
    }

  

    public byte[] getVoiceProfile() {
		return voiceProfile;
	}

	public void setVoiceProfile(byte[] voiceProfile) {
		this.voiceProfile = voiceProfile;
	}

	public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserRemarks() {
        return userRemarks;
    }

    public void setUserRemarks(String userRemarks) {
        this.userRemarks = userRemarks;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Instant getCreateInstant() {
        return createInstant;
    }

    public void setCreateInstant(Instant createInstant) {
        this.createInstant = createInstant;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Instant getLastUpInstantdInstant() {
        return lastUpInstantdInstant;
    }

    public void setLastUpInstantdInstant(Instant lastUpInstantdInstant) {
        this.lastUpInstantdInstant = lastUpInstantdInstant;
    }

    public String getLastUpInstantdBy() {
        return lastUpInstantdBy;
    }

    public void setLastUpInstantdBy(String lastUpInstantdBy) {
        this.lastUpInstantdBy = lastUpInstantdBy;
    }

    public Long getMasUsersId() {
        return userPwdId;
    }

    public void setMasUsersId(Long masUserPasswordId) {
        this.userPwdId = masUserPasswordId;
    }
    
    

    public String getAirLineCode() {
		return airLineCode;
	}

	public void setAirLineCode(String airLineCode) {
		this.airLineCode = airLineCode;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getUserProfilePhoto() {
		return userProfilePhoto;
	}

	public void setUserProfilePhoto(String userProfilePhoto) {
		this.userProfilePhoto = userProfilePhoto;
	}

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MasUsers masUsersDTO = (MasUsers) o;
        if (masUsersDTO.getUserPwdId() == null || getUserPwdId() == null) {
            return false;
        }
        return Objects.equals(getUserPwdId(), masUsersDTO.getUserPwdId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getUserPwdId());
    }

    @Override
    public String toString() {
        return "MasUsers{" +
            "id=" + getUserPwdId() +
            ", userName='" + getUserName() + "'" +
            ", userFullName='" + getUserFullName() + "'" +
            ", displayName='" + getDisplayName() + "'" +
            ", firstName='" + getFirstName() + "'" +
            ", middleName='" + getMiddleName() + "'" +
            ", lastName='" + getLastName() + "'" +
            ", categoryLevel='" + getCategoryLevel() + "'" +
            ", processName='" + getProcessName() + "'" +
            ", userManagerId=" + getUserManagerId() +
            ", userTeamId=" + getUserTeamId() +
            ", email='" + getEmail() + "'" +
            ", userRoleId=" + getUserRoleId() +
            ", userModuleId=" + getUserModuleId() +
            ", userGroupId=" + getUserGroupId() +
            ", shiftStartTime='" + getShiftStartTime() + "'" +
            ", shiftEndTime='" + getShiftEndTime() + "'" +
            ", userPhoto='" + getUserPhoto() + "'" +
            ", instantOfJoining='" + getInstantOfJoining() + "'" +
            ", preferredLanguage='" + getPreferredLanguage() + "'" +
            ", userAddress1='" + getUserAddress1() + "'" +
            ", userAddress2='" + getUserAddress2() + "'" +
            ", userAddress3='" + getUserAddress3() + "'" +
            ", voiceProfile='" + getVoiceProfile() + "'" +
            ", userEmail='" + getUserEmail() + "'" +
            ", userRemarks='" + getUserRemarks() + "'" +
            ", isActive='" + isIsActive() + "'" +
            ", createInstant='" + getCreateInstant() + "'" +
            ", createdBy='" + getCreatedBy() + "'" +
            ", lastUpInstantdInstant='" + getLastUpInstantdInstant() + "'" +
            ", lastUpInstantdBy='" + getLastUpInstantdBy() + "'" +
            ", masUsers=" + getMasUsersId() +
            "}";
    }
}
