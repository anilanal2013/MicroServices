package com.sgl.smartpra.service.model;

import java.io.Serializable;

public class RoleFunction extends AuditableColumns implements Serializable{

	private Long roleFunctionActionId;

	private Integer roleId;

	private Integer functionActionId;

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	@Override
	public String toString() {
		return "RoleFunction [roleFunctionActionId=" + roleFunctionActionId + ", roleId=" + roleId
				+ ", functionActionId=" + functionActionId + "]";
	}

	public Integer getFunctionActionId() {
		return functionActionId;
	}

	public Long getRoleFunctionActionId() {
		return roleFunctionActionId;
	}

	public void setRoleFunctionActionId(Long roleFunctionActionId) {
		this.roleFunctionActionId = roleFunctionActionId;
	}

	public void setFunctionActionId(Integer functionActionId) {
		this.functionActionId = functionActionId;
	}

}
