package com.sgl.smartpra.domain;

public class RoleFunctionActionsEntity extends AbstractAuditingEntity implements java.io.Serializable {
	Long roleFunctionActionId;
	Long roleId;
	String roleName;
	String functionName;
	Long screenFunctionId;
	String actionName;
	Long  actionId;
	Long functionActionId;
	

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public Long getActionId() {
		return actionId;
	}

	public Long getFunctionActionId() {
		return functionActionId;
	}

	public void setFunctionActionId(Long functionActionId) {
		this.functionActionId = functionActionId;
	}

	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}

	@Override
	public String toString() {
		return "RoleFunctionActionsEntity [roleName=" + roleName + ", functionName=" + functionName + ", action=" + actionName
				+ "]";
	}

	public String getRoleName() {
		return roleName;
	}

	public RoleFunctionActionsEntity(String roleName, String functionName, String action) {
		super();
		this.roleName = roleName;
		this.functionName = functionName;
	
	}

	public Long getRoleFunctionActionId() {
		return roleFunctionActionId;
	}

	public void setRoleFunctionActionId(Long roleFunctionActionId) {
		this.roleFunctionActionId = roleFunctionActionId;
	}

	public Long getScreenFunctionId() {
		return screenFunctionId;
	}

	public void setScreenFunctionId(Long screenFunctionId) {
		this.screenFunctionId = screenFunctionId;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}


	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public RoleFunctionActionsEntity(Long roleId, String roleName,Long screenFunctionId, String functionName,
			String action,Long actionId,
			Long roleFunctionActionId ,Long functionActionId
			 ) {
		
		
		super();
		this.roleId = roleId;
		this.roleName = roleName;
		this.screenFunctionId = screenFunctionId;
		this.functionName = functionName;
		this.actionName = actionName;
		this.actionId=actionId;
		this.roleFunctionActionId = roleFunctionActionId;
		this.functionActionId=functionActionId;

		
	}

}
