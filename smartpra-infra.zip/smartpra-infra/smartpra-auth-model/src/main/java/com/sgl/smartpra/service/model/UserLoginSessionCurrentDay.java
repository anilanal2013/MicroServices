package com.sgl.smartpra.service.model;
import java.time.Instant;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the UserLoginSessionCurrentDayEntity entity.
 */
public class UserLoginSessionCurrentDay extends AuditableColumns implements Serializable {

    private Long userLoginSessionCurrentDayId;

    private Integer browserSessionId;

    private Boolean isSoftToken;

    private Integer invalidPwdCount;

    private String isSessionTimedOut;

    private String keyUsed;

    private String lastAccessedScreenControl;

    private String passwordHash;

    private String saltUsed;

    private Instant sessionEndTime;

    private Instant sessionStartTime;


    private Long masUsersId;

 

    public Integer getBrowserSessionId() {
        return browserSessionId;
    }

    public void setBrowserSessionId(Integer browserSessionId) {
        this.browserSessionId = browserSessionId;
    }

    public Boolean isIsSoftToken() {
        return isSoftToken;
    }

    public void setIsSoftToken(Boolean isSoftToken) {
        this.isSoftToken = isSoftToken;
    }

    public Integer getInvalidPwdCount() {
        return invalidPwdCount;
    }

    public void setInvalidPwdCount(Integer invalidPwdCount) {
        this.invalidPwdCount = invalidPwdCount;
    }

    public String getIsSessionTimedOut() {
        return isSessionTimedOut;
    }

    public void setIsSessionTimedOut(String isSessionTimedOut) {
        this.isSessionTimedOut = isSessionTimedOut;
    }

    public String getKeyUsed() {
        return keyUsed;
    }

    public void setKeyUsed(String keyUsed) {
        this.keyUsed = keyUsed;
    }

    public String getLastAccessedScreenControl() {
        return lastAccessedScreenControl;
    }

    public void setLastAccessedScreenControl(String lastAccessedScreenControl) {
        this.lastAccessedScreenControl = lastAccessedScreenControl;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getSaltUsed() {
        return saltUsed;
    }

    public void setSaltUsed(String saltUsed) {
        this.saltUsed = saltUsed;
    }

    public Instant getSessionEndTime() {
        return sessionEndTime;
    }

    public void setSessionEndTime(Instant sessionEndTime) {
        this.sessionEndTime = sessionEndTime;
    }

    public Instant getSessionStartTime() {
        return sessionStartTime;
    }

    public void setSessionStartTime(Instant sessionStartTime) {
        this.sessionStartTime = sessionStartTime;
    }

    public Long getMasUsersId() {
        return masUsersId;
    }

    public void setMasUsersId(Long masUsersId) {
        this.masUsersId = masUsersId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserLoginSessionCurrentDay userLoginSessionCurrentDayDTO = (UserLoginSessionCurrentDay) o;
        if (userLoginSessionCurrentDayDTO.getUserLoginSessionCurrentDayId() == null || getUserLoginSessionCurrentDayId() == null) {
            return false;
        }
        return Objects.equals(getUserLoginSessionCurrentDayId(), userLoginSessionCurrentDayDTO.getUserLoginSessionCurrentDayId());
    }

    public Long getUserLoginSessionCurrentDayId() {
		return userLoginSessionCurrentDayId;
	}

	public void setUserLoginSessionCurrentDayId(Long userLoginSessionCurrentDayId) {
		this.userLoginSessionCurrentDayId = userLoginSessionCurrentDayId;
	}

	@Override
    public int hashCode() {
        return Objects.hashCode(getUserLoginSessionCurrentDayId());
    }

    @Override
    public String toString() {
        return "UserLoginSessionCurrentDay{" +
            "id=" + getUserLoginSessionCurrentDayId() +
            ", browserSessionId=" + getBrowserSessionId() +
            ", isSoftToken='" + isIsSoftToken() + "'" +
            ", invalidPwdCount=" + getInvalidPwdCount() +
            ", isSessionTimedOut='" + getIsSessionTimedOut() + "'" +
            ", keyUsed='" + getKeyUsed() + "'" +
            ", lastAccessedScreenControl='" + getLastAccessedScreenControl() + "'" +
            ", passwordHash='" + getPasswordHash() + "'" +
            ", saltUsed='" + getSaltUsed() + "'" +
            ", sessionEndTime='" + getSessionEndTime() + "'" +
            ", sessionStartTime='" + getSessionStartTime() + "'" +
            ", masUsers=" + getMasUsersId() +
            "}";
    }
}
