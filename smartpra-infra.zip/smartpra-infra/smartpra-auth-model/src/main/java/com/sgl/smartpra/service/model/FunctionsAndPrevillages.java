package com.sgl.smartpra.service.model;

import java.io.Serializable;
import java.util.List;

public class FunctionsAndPrevillages extends AuditableColumns implements Serializable {

	List<String> roles;

	List<FunctionActions> functionsActions;

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<FunctionActions> getFunctionsActions() {
		return functionsActions;
	}

	public void setFunctionsActions(List<FunctionActions> functionsActions) {
		this.functionsActions = functionsActions;
	}

}
