package com.sgl.smartpra.auth;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sgl.smartpra.util.Constants;

public class CORSFilter implements Filter {

	public CORSFilter() {
		// Default constructor
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {

		HttpServletResponse response = (HttpServletResponse) res;
		req.setAttribute(Constants.REQUEST_HEADER_AUTHORIZATION, Constants.REQUEST_HEADER_AUTHORIZATION_VALUE);
		HttpServletRequest request = (HttpServletRequest) req;

		response.setHeader(Constants.RESPONSE_ALLOW_ORIGIN, Constants.RESPONSE_ALLOW_ORIGIN_VALUE);
		response.setHeader(Constants.RESPONSE_ALLOW_METHODS, Constants.RESPONSE_ALLOW_METHODS_VALUE);
		response.setHeader(Constants.RESPONSE_ALLOW_MAX_AGE, Constants.RESPONSE_ALLOW_MAX_AGE_VALUE);
		response.setHeader(Constants.RESPONSE_ALLOW_HEADERS, Constants.RESPONSE_ALLOW_HEADERS_VALUE);

		if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
			response.setStatus(HttpServletResponse.SC_OK);
		} else {
			chain.doFilter(req, res);
		}
	}

	@Override
	public void init(FilterConfig filterConfig) {
		// Init method
	}

	@Override
	public void destroy() {
		// Destroy method
	}
}