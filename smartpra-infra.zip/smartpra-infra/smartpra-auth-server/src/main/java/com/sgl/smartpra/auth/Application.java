package com.sgl.smartpra.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.sgl.smartpra.auth.config.UaaProperties;

@SpringBootApplication
@EnableDiscoveryClient
@ComponentScan(basePackages= {"com.sgl.smartpra","com.sgl.smartpra.auth.config"})
@EntityScan(basePackages= {"com.sgl.smartpra.domain"})
@EnableJpaRepositories(basePackages= {"com.sgl.smartpra.auth.dao"})
@EnableConfigurationProperties(UaaProperties.class)
@EnableAutoConfiguration
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}
