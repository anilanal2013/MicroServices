package com.sgl.smartpra.auth.config;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.RememberMeServices;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.authentication.rememberme.InMemoryTokenRepositoryImpl;

import com.sgl.smartpra.auth.listener.SmartPRARememberMeServices;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Resource(name = "userService")
    private UserDetailsService userDetailsService;
    
    @Autowired
    private AuthenticationSuccessHandler myAuthenticationSuccessHandler;
 
    @Autowired
    private LogoutSuccessHandler myLogoutSuccessHandler;
    
    @Autowired
    UaaProperties uaaProperties;
    

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Autowired
    public void globalUserDetails(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService)
                .passwordEncoder(encoder());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
    	http.httpBasic().disable();
        http
                .csrf().disable()
                .anonymous().disable()
                .authorizeRequests()
                .antMatchers("/master/**").permitAll()
                .and()
                .formLogin()
                .successHandler(myAuthenticationSuccessHandler)
                .and()
                .sessionManagement()
                    .invalidSessionUrl("/invalidSession.html")
                .and()
                .logout()
                    .logoutSuccessHandler(myLogoutSuccessHandler)
                    .invalidateHttpSession(false)
                    .logoutSuccessUrl("/logout.html?logSucc=true")
                    .deleteCookies("JSESSIONID")
                    .permitAll()
                    .and()
                .rememberMe().rememberMeServices(rememberMeServices()).key("theKey");
        
        
        
/*		http.addFilterBefore(corsFilter(), ChannelProcessingFilter.class).logout().deleteCookies("JESSIONID")
				.logoutUrl("/api/logout")
				.logoutSuccessHandler(logoutSuccessHandler())
				.and()
				.formLogin()
				.loginPage("/login").loginProcessingUrl("/api/login")
				.failureHandler(authenticationFailureHandler())
				.successHandler(authenticationSuccessHandler())
				.and().csrf().disable().exceptionHandling()
				.authenticationEntryPoint(authenticationEntryPoint())
				.accessDeniedHandler(accessDeniedHandler());*/

    }

    
    @Bean
    public BCryptPasswordEncoder encoder(){
     	return new BCryptPasswordEncoder(4) {
		};
    }
    
    @Bean
    public RememberMeServices rememberMeServices() {
        SmartPRARememberMeServices rememberMeServices = new SmartPRARememberMeServices("theKey", userDetailsService, new InMemoryTokenRepositoryImpl());
        return rememberMeServices;
    }
    
    @Bean
    public SessionRegistry sessionRegistry() {
        return new SessionRegistryImpl();
    }
}
