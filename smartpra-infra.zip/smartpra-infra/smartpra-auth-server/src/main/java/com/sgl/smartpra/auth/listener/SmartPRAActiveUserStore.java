package com.sgl.smartpra.auth.listener;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class SmartPRAActiveUserStore {

    private List<String> users;

    public SmartPRAActiveUserStore() {
        users = new ArrayList<>();
    }

   
}
