package com.sgl.smartpra.auth.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Configuration
//@Order(Ordered.HIGHEST_PRECEDENCE)
@ConfigurationProperties(prefix="auth")
@PropertySources({
    @PropertySource("classpath:auth.properties")
})
@Component
public class UaaProperties {

	
		@Value("${auth.server.config.accesstokenvalidity}")
    	private int accesstokenvalidityinseconds;
		
		@Value("${auth.server.config.refreshtokenvalidity}")
		private int refreshtokenvalidityinseconds;
		
		@Value("${auth.server.config.userSessionMaxInactiveInterval}")
        private int userSessionMaxInactiveInterval;
	
		@Value("${auth.server.config.bcryptPasswordEncoderTime}")
        private int bcryptPasswordEncoderTime;
		
		@Value("${auth.server.config.maxInvalidPasswordAttampt}")
        private int maxInvalidPasswordAttampt;
		
		@Value("${auth.server.config.passwordLockReleaseTime}")
		private int passwordLockReleaseTime;
		
		@Value("${auth.server.clinet.id}")
		private String clientId;
		
		@Value("${auth.server.client.secret}")
        private String secret;
		
		@Value("${auth.server.client.granttype}")
        private String grantTypePassword;
		
        @Value("${auth.server.client.signInKey}")
        private String signInKey;

        
        private String authorizationCode;
        private String refreshToken;
        private String implicit;
        private String scopeRead;
        private String scopeWrite;
        private String trust;
        
		public int getRefreshtokenvalidityinseconds() {
			return refreshtokenvalidityinseconds;
		}
		
		
		public int getAccesstokenvalidityinseconds() {
			return accesstokenvalidityinseconds;
		}
		public int getUserSessionMaxInactiveInterval() {
			return userSessionMaxInactiveInterval;
		}
		public int getBcryptPasswordEncoderTime() {
			return bcryptPasswordEncoderTime;
		}
		public int getMaxInvalidPasswordAttampt() {
			return maxInvalidPasswordAttampt;
		}
		public int getPasswordLockReleaseTime() {
			return passwordLockReleaseTime;
		}
		public String getClientId() {
			return clientId;
		}
		public String getSecret() {
			return secret;
		}
		public String getGrantTypePassword() {
			return grantTypePassword;
		}
		public String getAuthorizationCode() {
			return authorizationCode;
		}
		public String getRefreshToken() {
			return refreshToken;
		}
		public String getImplicit() {
			return implicit;
		}
		public String getScopeRead() {
			return scopeRead;
		}
		public String getScopeWrite() {
			return scopeWrite;
		}
		public String getTrust() {
			return trust;
		}
		public String getSignInKey() {
			return signInKey;
		}
        
        
        
	
}
