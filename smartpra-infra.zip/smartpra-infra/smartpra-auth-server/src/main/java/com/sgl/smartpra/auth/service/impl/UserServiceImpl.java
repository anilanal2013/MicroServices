package com.sgl.smartpra.auth.service.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.auth.config.UaaProperties;
import com.sgl.smartpra.auth.dao.UserRepository;
import com.sgl.smartpra.auth.listener.SmartPRALoginAttemptService;
import com.sgl.smartpra.domain.MasUserRoleEntity;
import com.sgl.smartpra.domain.MasUsersEntity;

import lombok.extern.slf4j.Slf4j;

@Service(value = "userService")
@Slf4j
public class UserServiceImpl implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	UaaProperties uaaProperties;

	@Autowired
	private SmartPRALoginAttemptService loginAttemptService;

	@Autowired
	private HttpServletRequest request;

	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		log.info("Server name '{}' and  Server port '{}'  and Context Path = '{}' ", request.getServerName(),
				request.getServerPort(), request.getContextPath());
		log.info("==================================== {}",
				PasswordEncoderFactories.createDelegatingPasswordEncoder().encode((uaaProperties.getSecret())));
		try {
			InetAddress address = InetAddress.getByName(request.getServerName());
			log.info("=================================>>>>>>>>>>>>>>> {}", address.getHostAddress());
		} catch (UnknownHostException e1) {
			log.error("Load user failed :: {}", e1);
		}
		log.info("===========================1======================> {}", request.getServerName());
			final String ip = getClientIP();
			if (loginAttemptService.isBlocked(ip)) {
				throw new RuntimeException("blocked");
			}
			log.info("===========================2======================>");
			Optional<MasUsersEntity> userOtion;
			if (userEmailValidator(userId)) {
				userOtion = userRepository.findOneByEmail(userId);
			} else {
				userOtion = userRepository.findByUserName(userId);
			}
			if(userOtion.isPresent() && userOtion.get().getIsActive()) {
				MasUsersEntity user = userOtion.get();
				userRepository.save(user);
				return new org.springframework.security.core.userdetails.User(user.getEmail(),
						user.getMasUserPassword().getPasswordHash(), getGrantedAuthorities(user));
			} else {
				log.info("===========================3======================>");
				throw new UsernameNotFoundException("Invalid username or password.");
			}
	}

	private boolean userEmailValidator(String email) {
		String regex = "^(.+)@(.+)$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}

	public MasUsersEntity findOne(long id) {
		Optional<MasUsersEntity> usersEntity = userRepository.findById(id);
		return usersEntity.isPresent() ? usersEntity.get() : null;
	}

	public void delete(long id) {
		userRepository.deleteById(id);
	}

	private List<GrantedAuthority> getGrantedAuthorities(MasUsersEntity user) {
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		Set<MasUserRoleEntity> masUserRoles = user.getMasUserRoles();
		
		masUserRoles.stream().filter(Objects::nonNull).filter(MasUserRoleEntity::getIsActive).forEach(x -> {
			authorities.add(new SimpleGrantedAuthority("ROLE_" + x.getMasRole().getRoleName()));
		});
		return authorities;
	}

	private final String getClientIP() {
		final String xfHeader = request.getHeader("X-Forwarded-For");
		if (StringUtils.isBlank(xfHeader)) {
			return request.getRemoteAddr();
		}
		return xfHeader.split(",")[0];
	}

}
