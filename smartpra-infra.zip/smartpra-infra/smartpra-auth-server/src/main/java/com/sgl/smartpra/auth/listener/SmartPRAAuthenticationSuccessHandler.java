package com.sgl.smartpra.auth.listener;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.auth.config.UaaProperties;
import com.sgl.smartpra.domain.MasUsersEntity;

@Component("myAuthenticationSuccessHandler")
public class SmartPRAAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
	private final Logger logger = LoggerFactory.getLogger(getClass());


	@Autowired
	SmartPRAActiveUserStore activeUserStore;
	
	@Autowired
	UaaProperties uaaProperties;

	@Override
	public void onAuthenticationSuccess(final HttpServletRequest request, final HttpServletResponse response,
		final Authentication authentication) throws IOException {
		logger.info("myAuthenticationSuccessHandler is called  after success login");
		final HttpSession session = request.getSession(false);
		if (session != null) {
			session.setMaxInactiveInterval(uaaProperties.getUserSessionMaxInactiveInterval());

			String username;
			if (authentication.getPrincipal() instanceof MasUsersEntity) {
				username = ((MasUsersEntity) authentication.getPrincipal()).getFirstName();
			} else {
				username = authentication.getName();
			}
			SmartPRALoggedUser user = new SmartPRALoggedUser(username, activeUserStore);
			session.setAttribute("user", user);
		}

	}

}