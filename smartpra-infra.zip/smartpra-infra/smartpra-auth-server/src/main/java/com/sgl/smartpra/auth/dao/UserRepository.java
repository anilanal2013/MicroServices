package com.sgl.smartpra.auth.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.domain.MasUsersEntity;

@Repository
public interface UserRepository extends CrudRepository<MasUsersEntity, Long> {
	Optional<MasUsersEntity> findByUserName(String username);
	Optional<MasUsersEntity> findOneByEmail(String email);
}
