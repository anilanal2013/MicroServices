package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasUserGroupService;
import com.sgl.smartpra.service.model.MasUserGroup;

/**
 * REST controller for managing MasUserGroupEntity.
 */
@RestController
@RequestMapping("/api")
public class MasUserGroupResource {/*

    private final Logger log = LoggerFactory.getLogger(MasUserGroupResource.class);

    private static final String ENTITY_NAME = "masUserGroup";

    private final MasUserGroupService masUserGroupService;

    public MasUserGroupResource(MasUserGroupService masUserGroupService) {
        this.masUserGroupService = masUserGroupService;
    }

    *//**
     * POST  /mas-user-groups : Create a new masUserGroup.
     *
     * @param masUserGroupDTO the masUserGroupDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masUserGroupDTO, or with status 400 (Bad Request) if the masUserGroup has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     *//*
    @PostMapping("/mas-user-groups")
    public ResponseEntity<MasUserGroup> createMasUserGroup(@RequestBody MasUserGroup masUserGroupDTO) throws URISyntaxException {
        log.debug("REST request to save MasUserGroupEntity : {}", masUserGroupDTO);
        if (masUserGroupDTO.getMasGroup().getGroupId() != null) {
            throw new BadRequestAlertException("A new masUserGroup cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasUserGroup result = masUserGroupService.save(masUserGroupDTO);
        return ResponseEntity.created(new URI("/api/mas-user-groups/" + result.getMasUserGroupId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getMasUserGroupId().toString()))
            .body(result);
    }

    *//**
     * PUT  /mas-user-groups : Updates an existing masUserGroup.
     *
     * @param masUserGroupDTO the masUserGroupDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masUserGroupDTO,
     * or with status 400 (Bad Request) if the masUserGroupDTO is not valid,
     * or with status 500 (Internal Server Error) if the masUserGroupDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     *//*
    @PutMapping("/mas-user-groups")
    public ResponseEntity<MasUserGroup> updateMasUserGroup(@RequestBody MasUserGroup masUserGroupDTO) throws URISyntaxException {
        log.debug("REST request to update MasUserGroupEntity : {}", masUserGroupDTO);
        if (masUserGroupDTO.getMasUserGroupId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasUserGroup result = masUserGroupService.save(masUserGroupDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masUserGroupDTO.getMasUserGroupId().toString()))
            .body(result);
    }

    *//**
     * GET  /mas-user-groups : get all the masUserGroups.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masUserGroups in body
     *//*
    @GetMapping("/mas-user-groups")
    public ResponseEntity<List<MasUserGroup>> getAllMasUserGroups(Pageable pageable) {
        log.debug("REST request to get a page of MasUserGroups");
        Page<MasUserGroup> page = masUserGroupService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-user-groups");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    *//**
     * GET  /mas-user-groups/:id : get the "id" masUserGroup.
     *
     * @param id the id of the masUserGroupDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masUserGroupDTO, or with status 404 (Not Found)
     *//*
    @GetMapping("/mas-user-groups/{id}")
    public ResponseEntity<MasUserGroup> getMasUserGroup(@PathVariable Long id) {
        log.debug("REST request to get MasUserGroupEntity : {}", id);
        Optional<MasUserGroup> masUserGroupDTO = masUserGroupService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masUserGroupDTO);
    }

    *//**
     * DELETE  /mas-user-groups/:id : delete the "id" masUserGroup.
     *
     * @param id the id of the masUserGroupDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     *//*
    @DeleteMapping("/mas-user-groups/{id}")
    public ResponseEntity<Void> deleteMasUserGroup(@PathVariable Long id) {
        log.debug("REST request to delete MasUserGroupEntity : {}", id);
        masUserGroupService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
*/}
