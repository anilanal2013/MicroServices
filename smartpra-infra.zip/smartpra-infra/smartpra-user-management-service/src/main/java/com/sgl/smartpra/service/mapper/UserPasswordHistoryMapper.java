package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.UserPasswordHistory;

import org.mapstruct.*;

/**
 * Mapper for the entity UserPasswordHistoryEntity and its DTO UserPasswordHistory.
 */
@Mapper(componentModel = "spring", uses = {MasUsersMapper.class})
public interface UserPasswordHistoryMapper extends EntityMapper<UserPasswordHistory, UserPasswordHistoryEntity> {

    @Mapping(source = "masUsers.userId", target = "masUsersId")
    UserPasswordHistory toModel(UserPasswordHistoryEntity userPasswordHistory);

    @Mapping(source = "masUsersId", target = "masUsers")
    UserPasswordHistoryEntity toEntity(UserPasswordHistory userPasswordHistoryDTO);

    default UserPasswordHistoryEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        UserPasswordHistoryEntity userPasswordHistory = new UserPasswordHistoryEntity();
        userPasswordHistory.setUserPwdHistId(id);
        return userPasswordHistory;
    }
}
