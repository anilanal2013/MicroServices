package com.sgl.smartpra.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.domain.MasRoleEntity;
import com.sgl.smartpra.repository.MasRoleRepository;
import com.sgl.smartpra.service.MasRoleService;
import com.sgl.smartpra.service.mapper.MasRoleMapper;
import com.sgl.smartpra.service.model.MasRole;
@Service
@Transactional
public class MasRoleServiceImpl implements MasRoleService{

    private final Logger log = LoggerFactory.getLogger(MasRoleServiceImpl.class);

    private final MasRoleRepository masRoleRepository;

    private final MasRoleMapper masRoleMapper;

    public MasRoleServiceImpl(MasRoleRepository masRoleRepository, MasRoleMapper masRoleMapper) {
        this.masRoleRepository = masRoleRepository;
        this.masRoleMapper = masRoleMapper;
    }

    /**
     * Save a masRole.
     *
     * @param masRoleDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasRole save(MasRole masRoleDTO) {
        log.debug("Request to save MasRoleEntity : {}", masRoleDTO);
        MasRoleEntity masRole = masRoleMapper.toEntity(masRoleDTO);
        masRole = masRoleRepository.save(masRole);
        return masRoleMapper.toModel(masRole);
    }

    /**
     * Get all the masRoles.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
	public List<MasRole> findAll() {
		log.debug("Request to get all MasRoles");
		List<MasRoleEntity> roleList = masRoleRepository.findAll();
		return masRoleMapper.toModel(roleList);

	}


    /**
     * Get one masRole by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasRole> findOne(Long id) {
        log.debug("Request to get MasRoleEntity : {}", id);
        return masRoleRepository.findById(id)
            .map(masRoleMapper::toModel);
    }

    /**
     * Delete the masRole by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasRoleEntity : {}", id);        
        masRoleRepository.deleteById(id);
    }

	/* (non-Javadoc)
	 * @see com.sgl.smartpra.service.MasRoleService#findByRoleName(java.lang.String)
	 */
	@Override
	public MasRole findByRoleName(String roleName) {
		Optional<MasRoleEntity> roleNameEntity = masRoleRepository.findOneByRoleName(roleName);
		return roleNameEntity.isPresent() ? masRoleMapper.toModel(roleNameEntity.get()) : null;
	}
}
