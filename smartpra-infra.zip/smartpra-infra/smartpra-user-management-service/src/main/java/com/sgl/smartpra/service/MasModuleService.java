package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasModule;

import java.util.Optional;

/**
 * Service Interface for managing MasModuleEntity.
 */
public interface MasModuleService {

    /**
     * Save a masModule.
     *
     * @param masModuleDTO the entity to save
     * @return the persisted entity
     */
    MasModule save(MasModule masModuleDTO);

    /**
     * Get all the masModules.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasModule> findAll(Pageable pageable);


    /**
     * Get the "id" masModule.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasModule> findOne(Long id);

    /**
     * Delete the "id" masModule.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
