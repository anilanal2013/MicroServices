package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasUserRoleService;
import com.sgl.smartpra.service.model.MasUserRole;

/**
 * REST controller for managing MasUserRoleEntity.
 */
@RestController
@RequestMapping("/api")
public class MasUserRoleResource {/*

    private final Logger log = LoggerFactory.getLogger(MasUserRoleResource.class);

    private static final String ENTITY_NAME = "masUserRole";

    private final MasUserRoleService masUserRoleService;

    public MasUserRoleResource(MasUserRoleService masUserRoleService) {
        this.masUserRoleService = masUserRoleService;
    }

    *//**
     * POST  /mas-user-roles : Create a new masUserRole.
     *
     * @param masUserRoleDTO the masUserRoleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masUserRoleDTO, or with status 400 (Bad Request) if the masUserRole has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     *//*
    @PostMapping("/mas-user-roles")
    public ResponseEntity<MasUserRole> createMasUserRole(@RequestBody MasUserRole masUserRoleDTO) throws URISyntaxException {
        log.debug("REST request to save MasUserRoleEntity : {}", masUserRoleDTO);
        if (masUserRoleDTO.getMasUserRoleId() != null) {
            throw new BadRequestAlertException("A new masUserRole cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasUserRole result = masUserRoleService.save(masUserRoleDTO);
        return ResponseEntity.created(new URI("/api/mas-user-roles/" + result.getMasUserRoleId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getMasUserRoleId().toString()))
            .body(result);
    }

    *//**
     * PUT  /mas-user-roles : Updates an existing masUserRole.
     *
     * @param masUserRoleDTO the masUserRoleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masUserRoleDTO,
     * or with status 400 (Bad Request) if the masUserRoleDTO is not valid,
     * or with status 500 (Internal Server Error) if the masUserRoleDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     *//*
    @PutMapping("/mas-user-roles")
    public ResponseEntity<MasUserRole> updateMasUserRole(@RequestBody MasUserRole masUserRoleDTO) throws URISyntaxException {
        log.debug("REST request to update MasUserRoleEntity : {}", masUserRoleDTO);
        if (masUserRoleDTO.getMasUserRoleId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasUserRole result = masUserRoleService.save(masUserRoleDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masUserRoleDTO.getMasUserRoleId().toString()))
            .body(result);
    }

    *//**
     * GET  /mas-user-roles : get all the masUserRoles.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masUserRoles in body
     *//*
    @GetMapping("/mas-user-roles")
    public ResponseEntity<List<MasUserRole>> getAllMasUserRoles(Pageable pageable) {
        log.debug("REST request to get a page of MasUserRoles");
        Page<MasUserRole> page = masUserRoleService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-user-roles");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    *//**
     * GET  /mas-user-roles/:id : get the "id" masUserRole.
     *
     * @param id the id of the masUserRoleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masUserRoleDTO, or with status 404 (Not Found)
     *//*
    @GetMapping("/mas-user-roles/{id}")
    public ResponseEntity<MasUserRole> getMasUserRole(@PathVariable Long id) {
        log.debug("REST request to get MasUserRoleEntity : {}", id);
        Optional<MasUserRole> masUserRoleDTO = masUserRoleService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masUserRoleDTO);
    }

    *//**
     * DELETE  /mas-user-roles/:id : delete the "id" masUserRole.
     *
     * @param id the id of the masUserRoleDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     *//*
    @DeleteMapping("/mas-user-roles/{id}")
    public ResponseEntity<Void> deleteMasUserRole(@PathVariable Long id) {
        log.debug("REST request to delete MasUserRoleEntity : {}", id);
        masUserRoleService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
*/}
