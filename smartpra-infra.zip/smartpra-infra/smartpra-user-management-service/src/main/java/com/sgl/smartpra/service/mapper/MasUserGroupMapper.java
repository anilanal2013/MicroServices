package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasUserGroup;

import org.mapstruct.*;

/**
 * Mapper for the entity MasUserGroupEntity and its DTO MasUserGroup.
 */
@Mapper(componentModel = "spring", uses = {MasUsersMapper.class, MasGroupMapper.class})
public interface MasUserGroupMapper extends EntityMapper<MasUserGroup, MasUserGroupEntity> {

   @Mappings({@Mapping(source = "masUsers.userId", target = "masUsersId"),
    @Mapping(source = "masGroup.groupId", target = "masGroupId")})
    MasUserGroup toModel(MasUserGroupEntity masUserGroup);

   @Mappings({@Mapping(source = "masUsersId", target = "masUsers"),
    @Mapping(source = "masGroupId", target = "masGroup")})
    MasUserGroupEntity toEntity(MasUserGroup masUserGroupDTO);

    default MasUserGroupEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasUserGroupEntity masUserGroup = new MasUserGroupEntity();
        masUserGroup.setUserGroupId(id);
        return masUserGroup;
    }
}
