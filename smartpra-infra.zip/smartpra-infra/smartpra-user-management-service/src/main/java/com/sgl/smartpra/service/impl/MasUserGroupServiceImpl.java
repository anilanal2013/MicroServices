package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.MasUserGroupService;
import com.sgl.smartpra.domain.MasUserGroupEntity;
import com.sgl.smartpra.repository.MasUserGroupRepository;
import com.sgl.smartpra.service.mapper.MasUserGroupMapper;
import com.sgl.smartpra.service.model.MasUserGroup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing MasUserGroupEntity.
 */
@Service
@Transactional
public class MasUserGroupServiceImpl implements MasUserGroupService {

    private final Logger log = LoggerFactory.getLogger(MasUserGroupServiceImpl.class);

    private final MasUserGroupRepository masUserGroupRepository;

    private final MasUserGroupMapper masUserGroupMapper;

    public MasUserGroupServiceImpl(MasUserGroupRepository masUserGroupRepository, MasUserGroupMapper masUserGroupMapper) {
        this.masUserGroupRepository = masUserGroupRepository;
        this.masUserGroupMapper = masUserGroupMapper;
    }

    /**
     * Save a masUserGroup.
     *
     * @param masUserGroupDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasUserGroup save(MasUserGroup masUserGroupDTO) {
        log.debug("Request to save MasUserGroupEntity : {}", masUserGroupDTO);
        MasUserGroupEntity masUserGroup = masUserGroupMapper.toEntity(masUserGroupDTO);
        masUserGroup = masUserGroupRepository.save(masUserGroup);
        return masUserGroupMapper.toModel(masUserGroup);
    }

    /**
     * Get all the masUserGroups.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasUserGroup> findAll(Pageable pageable) {
        log.debug("Request to get all MasUserGroups");
        return masUserGroupRepository.findAll(pageable)
            .map(masUserGroupMapper::toModel);
    }


    /**
     * Get one masUserGroup by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasUserGroup> findOne(Long id) {
        log.debug("Request to get MasUserGroupEntity : {}", id);
        return masUserGroupRepository.findById(id)
            .map(masUserGroupMapper::toModel);
    }

    /**
     * Delete the masUserGroup by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasUserGroupEntity : {}", id);        masUserGroupRepository.deleteById(id);
    }
}
