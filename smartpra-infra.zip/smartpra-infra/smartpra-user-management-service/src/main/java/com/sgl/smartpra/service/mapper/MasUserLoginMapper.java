package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasUserLogin;

import org.mapstruct.*;

/**
 * Mapper for the entity MasUserLoginEntity and its DTO MasUserLogin.
 */
@Mapper(componentModel = "spring", uses = {MasUsersMapper.class})
public interface MasUserLoginMapper extends EntityMapper<MasUserLogin, MasUserLoginEntity> {

    @Mapping(source = "masUsers.userId", target = "masUsersId")
    MasUserLogin toModel(MasUserLoginEntity masUserLogin);

    @Mapping(source = "masUsersId", target = "masUsers")
    MasUserLoginEntity toEntity(MasUserLogin masUserLoginDTO);

    default MasUserLoginEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasUserLoginEntity masUserLogin = new MasUserLoginEntity();
        masUserLogin.setUserLoginId(id);
        return masUserLogin;
    }
}
