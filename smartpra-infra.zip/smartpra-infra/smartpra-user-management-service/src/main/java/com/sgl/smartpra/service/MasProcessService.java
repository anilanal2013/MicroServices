package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasProcess;

import java.util.Optional;

/**
 * Service Interface for managing MasProcessEntity.
 */
public interface MasProcessService {

    /**
     * Save a masProcess.
     *
     * @param masProcessDTO the entity to save
     * @return the persisted entity
     */
    MasProcess save(MasProcess masProcessDTO);

    /**
     * Get all the masProcesses.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasProcess> findAll(Pageable pageable);


    /**
     * Get the "id" masProcess.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasProcess> findOne(Long id);

    /**
     * Delete the "id" masProcess.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
