package com.sgl.smartpra.service;

public interface FunctionActioService {

}
