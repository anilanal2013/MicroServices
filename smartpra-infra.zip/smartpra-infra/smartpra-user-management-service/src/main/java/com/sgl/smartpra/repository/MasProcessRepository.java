package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.MasProcessEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the MasProcessEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MasProcessRepository extends JpaRepository<MasProcessEntity, Long> {

}
