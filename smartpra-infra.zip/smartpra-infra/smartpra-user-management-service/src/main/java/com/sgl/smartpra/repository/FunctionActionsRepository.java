package com.sgl.smartpra.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sgl.smartpra.domain.FunctionActionsEntity;
import com.sgl.smartpra.domain.ScreenFunctionEntity;

public interface FunctionActionsRepository extends JpaRepository<FunctionActionsEntity, Long>{
	
	List<FunctionActionsEntity> findAllByScreenFunctionEntityAndIsActiveIsTrue(ScreenFunctionEntity screenFunctionEntity);

	List<FunctionActionsEntity> findAllByScreenFunctionEntityInAndIsActiveIsTrue(List<ScreenFunctionEntity> screenFunctionEntity);

}
