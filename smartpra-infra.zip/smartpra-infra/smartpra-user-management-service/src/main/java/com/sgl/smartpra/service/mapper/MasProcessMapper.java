package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasProcess;

import org.mapstruct.*;

/**
 * Mapper for the entity MasProcessEntity and its DTO MasProcess.
 */
@Mapper(componentModel = "spring", uses = {})
public interface MasProcessMapper extends EntityMapper<MasProcess, MasProcessEntity> {



    default MasProcessEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasProcessEntity masProcess = new MasProcessEntity();
        masProcess.setProcessId(id);
        return masProcess;
    }
}
