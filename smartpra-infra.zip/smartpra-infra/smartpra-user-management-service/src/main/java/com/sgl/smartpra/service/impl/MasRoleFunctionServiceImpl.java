package com.sgl.smartpra.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.config.Constants;
import com.sgl.smartpra.domain.ActionEntity;
import com.sgl.smartpra.domain.FunctionActionsEntity;
import com.sgl.smartpra.domain.MasRoleEntity;
import com.sgl.smartpra.domain.MasRoleFunctionEntity;
import com.sgl.smartpra.domain.ScreenFunctionEntity;
import com.sgl.smartpra.repository.FunctionActionsRepository;
import com.sgl.smartpra.repository.MasActionRepository;
import com.sgl.smartpra.repository.MasRoleFunctionRepository;
import com.sgl.smartpra.repository.MasRoleRepository;
import com.sgl.smartpra.repository.ScreenFunctionRepository;
import com.sgl.smartpra.service.MasRoleFunctionService;
import com.sgl.smartpra.service.mapper.ActionMapper;
import com.sgl.smartpra.service.mapper.MasRoleFunctionMapper;
import com.sgl.smartpra.service.mapper.ScreenFunctionMapper;
import com.sgl.smartpra.service.model.Action;
import com.sgl.smartpra.service.model.FunctionActionDetail;
import com.sgl.smartpra.service.model.FunctionDetail;
import com.sgl.smartpra.service.model.MasRoleFunction;
import com.sgl.smartpra.service.model.ScreenFunction;

@Service
public class MasRoleFunctionServiceImpl implements MasRoleFunctionService {

	@Autowired
	private MasRoleFunctionRepository masRoleFunctionRepository;

	@Autowired
	MasRoleFunctionMapper masRoleFunctionMapper;

	@Autowired
	ScreenFunctionMapper screenFunctionMapper;

	@Autowired
	ActionMapper actionMapper;

	@Autowired
	private MasRoleRepository masRoleRepository;

	@Autowired
	private ScreenFunctionRepository screenFunctionRepository;

	@Autowired
	private MasActionRepository masActionRepository;

	@Autowired
	private FunctionActionsRepository functionActionsRepository;

	@Autowired
	private CacheManager cacheManager;

	@Override
	public List<MasRoleFunction> saveMasRoleFunction(List<MasRoleFunction> masRoleFun) {
		List<MasRoleFunctionEntity> roleFunctions = masRoleFunctionRepository
				.saveAll(masRoleFunctionMapper.toEntity(masRoleFun));
		return masRoleFunctionMapper.toModel(roleFunctions);
	}

	@Override
	public List<MasRoleFunction> updateMasRoleFunction(List<MasRoleFunction> masRoleFun) {
		List<MasRoleFunctionEntity> roleFunctions = masRoleFunctionRepository
				.saveAll(masRoleFunctionMapper.toEntity(masRoleFun));
		return masRoleFunctionMapper.toModel(roleFunctions);
	}

	@Override
	public List<FunctionDetail> getRolesAndPrevillages(String role, List<Long> screenId) {
		Optional<MasRoleEntity> roleEntity = masRoleRepository.findOneByRoleName(role);
		Map<Long, Map<String, List<FunctionActionDetail>>> functionMap = new HashMap<>();
		constructFunctionMap(screenId, roleEntity, functionMap);
		List<FunctionDetail> rolePrevillages = new ArrayList<>();
		functionMap.entrySet().forEach(outerMap -> {
			outerMap.getValue().entrySet().forEach(innerMap -> {
				FunctionDetail functionDetail = new FunctionDetail(outerMap.getKey(), innerMap.getKey(), null,
						innerMap.getValue());
				rolePrevillages.add(functionDetail);
			});
		});

		return rolePrevillages;
	}

	private void constructFunctionMap(List<Long> screenId, Optional<MasRoleEntity> roleEntity,
			Map<Long, Map<String, List<FunctionActionDetail>>> functionMap) {
		if (roleEntity.isPresent() && Objects.nonNull(screenId)) {
			List<ScreenFunctionEntity> screenFunctionEntity = screenFunctionRepository.findAllById(screenId);
			List<FunctionActionsEntity> functionAction = functionActionsRepository
					.findAllByScreenFunctionEntityInAndIsActiveIsTrue(screenFunctionEntity);
			List<MasRoleFunctionEntity> roleFunction = masRoleFunctionRepository
					.findAllByMasRoleEntityAndFunctionActionsEntityInAndIsActiveIsTrue(roleEntity.get(),
							functionAction);
			fetchFunctionDetails(functionMap, roleFunction);

		} else if (roleEntity.isPresent()) {
			List<MasRoleFunctionEntity> roleFunctions = masRoleFunctionRepository
					.findAllByMasRoleEntityAndIsActiveIsTrue(roleEntity.get());
			fetchFunctionDetails(functionMap, roleFunctions);
		}
	}

	private void fetchFunctionDetails(Map<Long, Map<String, List<FunctionActionDetail>>> functionMap,
			List<MasRoleFunctionEntity> roleFunctions) {
		roleFunctions.forEach(roleFunction -> {
			FunctionActionsEntity masFunctionAction = roleFunction.getFunctionActionsEntity();
			Long screenFunctionId = masFunctionAction.getScreenFunctionEntity().getScreenFunctionId();
			String functionName = masFunctionAction.getScreenFunctionEntity().getScreenFunctionName().trim();
			Long actionId = masFunctionAction.getActionEntity().getActionId();
			String actionName = masFunctionAction.getActionEntity().getActionName().trim();
			Long functionActionId = masFunctionAction.getFunctionActionId();
			if (functionMap.containsKey(screenFunctionId)) {
				Map<String, List<FunctionActionDetail>> functionActionMap = functionMap.get(screenFunctionId);
				List<FunctionActionDetail> functionAction = functionActionMap.get(functionName);
				functionAction.add(new FunctionActionDetail(functionActionId, actionId, actionName));
				functionActionMap.put(functionName, functionAction);
				functionMap.put(screenFunctionId, functionActionMap);
			} else {
				Map<String, List<FunctionActionDetail>> functionActionMap = new HashMap<>();
				List<FunctionActionDetail> functionAction = new ArrayList<>();
				functionAction.add(new FunctionActionDetail(functionActionId, actionId, actionName));
				functionActionMap.put(functionName, functionAction);
				functionMap.put(screenFunctionId, functionActionMap);
			}

		});
	}

	@Override
	public List<MasRoleFunction> saveRoleFunctions(List<FunctionDetail> functionDetails, String role) {
		deleteRoleFunctions(functionDetails, role);
		Optional<MasRoleEntity> roleEntity = masRoleRepository.findOneByRoleName(role);
		List<MasRoleFunction> MasRoleFunctionsList = new ArrayList<>();
		functionDetails.forEach(functionDetail -> {
			Optional<ScreenFunctionEntity> screenFunctionEntiy = screenFunctionRepository
					.findById(functionDetail.getFunctionId());
			if (screenFunctionEntiy.isPresent()) {
				List<FunctionActionDetail> functionActionList = functionDetail.getFunctionAction();
				if (Objects.nonNull(functionActionList) && !functionActionList.isEmpty()) {
					constructRoleFunction(roleEntity, MasRoleFunctionsList, screenFunctionEntiy, functionActionList);
				}
			}
		});
		cacheManager.getCache(Constants.USERS_BY_EMAIL_CACHE).clear();
		return MasRoleFunctionsList;
	}

	private void constructRoleFunction(Optional<MasRoleEntity> roleEntity, List<MasRoleFunction> MasRoleFunctionsList,
			Optional<ScreenFunctionEntity> screenFunctionEntiy, List<FunctionActionDetail> functionActionList) {
		functionActionList.forEach(functionAction -> {
			MasRoleFunctionEntity masRoleFunctionEntity = new MasRoleFunctionEntity();
			Optional<ActionEntity> actionEntity = masActionRepository
					.findById(functionAction.getActionId());
			FunctionActionsEntity functionActionEntity = new FunctionActionsEntity();
			functionActionEntity.setActionEntity(actionEntity.get());
			functionActionEntity.setScreenFunctionEntity(screenFunctionEntiy.get());
			masRoleFunctionEntity.setFunctionActionsEntity(functionActionEntity);
			functionActionEntity.setIsActive(true);
			masRoleFunctionEntity.setMasRoleEntity(roleEntity.get());
			masRoleFunctionEntity.setIsActive(true);
			MasRoleFunctionEntity masRoleFunctionSaveEntity = masRoleFunctionRepository
					.save(masRoleFunctionEntity);
			MasRoleFunctionsList.add(masRoleFunctionMapper.toModel(masRoleFunctionSaveEntity));
		});
	}

	@Override
	public List<ScreenFunction> getScreenFunction() {
		return screenFunctionMapper.toModel(screenFunctionRepository.findAll());
	}

	@Override
	public List<Action> getAction() {
		return actionMapper.toModel(masActionRepository.findAll());
	}

	@Override
	public void deleteRoleFunctions(List<FunctionDetail> functionDetails, String role) {
		functionDetails.forEach(functionDetail -> {
			List<FunctionActionDetail> deActiveFunctionActionList = functionDetail.getDeActiveFunctionAction();
			if (Objects.nonNull(deActiveFunctionActionList) && !deActiveFunctionActionList.isEmpty()) {
				deActiveFunctionActionList.forEach(function -> {
					functionActionsRepository.findById(function.getFunctionActionId()).ifPresent(functionAction -> {
						functionAction.setIsActive(false);
						functionActionsRepository.saveAndFlush(functionAction);
					});
					FunctionActionsEntity functionActionsEntity = new FunctionActionsEntity();
					functionActionsEntity.setFunctionActionId(function.getFunctionActionId());
					MasRoleFunctionEntity masRoleFunctionEntity = masRoleFunctionRepository
							.findOneByFunctionActionsEntity(functionActionsEntity);
					masRoleFunctionRepository.findById(masRoleFunctionEntity.getRoleFunctionId())
							.ifPresent(roleFunction -> {
								roleFunction.setIsActive(false);
								masRoleFunctionRepository.saveAndFlush(roleFunction);
							});
				});
			}
		});
	}
}
