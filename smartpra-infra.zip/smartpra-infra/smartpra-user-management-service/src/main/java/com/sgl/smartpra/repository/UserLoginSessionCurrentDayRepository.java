package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.UserLoginSessionCurrentDayEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the UserLoginSessionCurrentDayEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface UserLoginSessionCurrentDayRepository extends JpaRepository<UserLoginSessionCurrentDayEntity, Long> {

}
