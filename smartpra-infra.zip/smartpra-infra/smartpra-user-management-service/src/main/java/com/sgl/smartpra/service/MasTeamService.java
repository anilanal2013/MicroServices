package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasTeam;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing MasTeamEntity.
 */
public interface MasTeamService {

    /**
     * Save a masTeam.
     *
     * @param masTeamDTO the entity to save
     * @return the persisted entity
     */
    MasTeam save(MasTeam masTeamDTO);

    /**
     * Get all the masTeams.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasTeam> findAll(Pageable pageable);


    /**
     * Get the "id" masTeam.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasTeam> findOne(Long id);

    /**
     * Delete the "id" masTeam.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
    
    List<MasTeam> findTeamsByGroup(Long groupId);
}
