package com.sgl.smartpra.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.domain.MasGroupEntity;
import com.sgl.smartpra.domain.MasTeamEntity;
import com.sgl.smartpra.repository.MasGroupRepository;
import com.sgl.smartpra.repository.MasTeamRepository;
import com.sgl.smartpra.service.MasTeamService;
import com.sgl.smartpra.service.mapper.MasTeamMapper;
import com.sgl.smartpra.service.model.MasTeam;

/**
 * Service Implementation for managing MasTeamEntity.
 */
@Service
@Transactional
public class MasTeamServiceImpl implements MasTeamService {

    private final Logger log = LoggerFactory.getLogger(MasTeamServiceImpl.class);

    private final MasTeamRepository masTeamRepository;
    
    private final MasGroupRepository masGroupRepository;

    private final MasTeamMapper masTeamMapper;

    public MasTeamServiceImpl(MasTeamRepository masTeamRepository, MasTeamMapper masTeamMapper,MasGroupRepository masGroupRepository) {
        this.masTeamRepository = masTeamRepository;
        this.masTeamMapper = masTeamMapper;
        this.masGroupRepository = masGroupRepository;
    }

    /**
     * Save a masTeam.
     *
     * @param masTeamDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasTeam save(MasTeam masTeamDTO) {
        log.debug("Request to save MasTeamEntity : {}", masTeamDTO);
        MasTeamEntity masTeam = masTeamMapper.toEntity(masTeamDTO);
        masTeam = masTeamRepository.save(masTeam);
        return masTeamMapper.toModel(masTeam);
    }

    /**
     * Get all the masTeams.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasTeam> findAll(Pageable pageable) {
        log.debug("Request to get all MasTeams");
        return masTeamRepository.findAll(pageable)
            .map(masTeamMapper::toModel);
    }


    /**
     * Get one masTeam by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasTeam> findOne(Long id) {
        log.debug("Request to get MasTeamEntity : {}", id);
        return masTeamRepository.findById(id)
            .map(masTeamMapper::toModel);
    }

    /**
     * Delete the masTeam by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasTeamEntity : {}", id);        masTeamRepository.deleteById(id);
    }

	public List<MasTeam> findTeamsByGroup(Long groupId) {

		List<MasTeamEntity> teams = new ArrayList<>();
		List<MasTeam> teamsList = new ArrayList<>();
		Optional<MasGroupEntity> group = masGroupRepository.findById(groupId);

		if (group.isPresent())
			teams = masTeamRepository.findAllByMasGroup(group.get());

		if (!teams.isEmpty())
			teamsList = masTeamMapper.toModel(teams);

		return teamsList;
	}

}
