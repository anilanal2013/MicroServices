package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.MasUserPasswordEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the MasUserPasswordEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MasUserPasswordRepository extends JpaRepository<MasUserPasswordEntity, Long> {

}
