package com.sgl.smartpra.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.domain.MasMenuFunctionEntity;
import com.sgl.smartpra.domain.ScreenFunctionEntity;

@Repository
public interface MasMenuFunctionRepository extends JpaRepository<MasMenuFunctionEntity, Long>{

	MasMenuFunctionEntity findByMasFunction(ScreenFunctionEntity masFunction);
}
