package com.sgl.smartpra.util;


public class SmartPRATenantContextHolder {

    private static final ThreadLocal<String> CONTEXT = new ThreadLocal<>();
    
    private static String default_Tenant = "default";

    public static void setTenantId(String tenant) {
    	if(tenant != null && !tenant.isEmpty()) {
        CONTEXT.set(tenant);
    	}
    	else {
    		 CONTEXT.set(default_Tenant);
    	}
    }

    public static String getTenant() {
        return CONTEXT.get();
    }

    public static void clear() {
        CONTEXT.remove();
    }
}