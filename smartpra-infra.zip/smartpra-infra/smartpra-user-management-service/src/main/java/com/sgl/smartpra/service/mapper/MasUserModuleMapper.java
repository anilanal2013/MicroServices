package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasUserModule;

import org.mapstruct.*;

/**
 * Mapper for the entity MasUserModuleEntity and its DTO MasUserModule.
 */
@Mapper(componentModel = "spring", uses = {MasUsersMapper.class, MasModuleMapper.class})
public interface MasUserModuleMapper extends EntityMapper<MasUserModule, MasUserModuleEntity> {
    @Mappings({
    @Mapping(source = "masUsers.userId", target = "masUsersId"),
    @Mapping(source = "masModule.moduleId", target = "masModuleId")})
    MasUserModule toModel(MasUserModuleEntity masUserModule);
 
    @Mappings({
    @Mapping(source = "masUsersId", target = "masUsers"),
    @Mapping(source = "masModuleId", target = "masModule")})
    MasUserModuleEntity toEntity(MasUserModule masUserModuleDTO);

    default MasUserModuleEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasUserModuleEntity masUserModule = new MasUserModuleEntity();
        masUserModule.setUserModuleId(id);
        return masUserModule;
    }
}
