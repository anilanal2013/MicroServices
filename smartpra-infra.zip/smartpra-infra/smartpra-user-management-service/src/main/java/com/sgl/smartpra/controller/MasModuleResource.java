package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasModuleService;
import com.sgl.smartpra.service.model.MasModule;

/**
 * REST controller for managing MasModuleEntity.
 */
@RestController
@RequestMapping("/api")
public class MasModuleResource {

    private final Logger log = LoggerFactory.getLogger(MasModuleResource.class);

    private static final String ENTITY_NAME = "masModule";

    private final MasModuleService masModuleService;

    public MasModuleResource(MasModuleService masModuleService) {
        this.masModuleService = masModuleService;
    }

    /**
     * POST  /mas-modules : Create a new masModule.
     *
     * @param masModuleDTO the masModuleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masModuleDTO, or with status 400 (Bad Request) if the masModule has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/mas-modules")
    public ResponseEntity<MasModule> createMasModule(@RequestBody MasModule masModuleDTO) throws URISyntaxException {
        log.debug("REST request to save MasModuleEntity : {}", masModuleDTO);
        if (masModuleDTO.getMasModuleId() != null) {
            throw new BadRequestAlertException("A new masModule cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasModule result = masModuleService.save(masModuleDTO);
        return ResponseEntity.created(new URI("/api/mas-modules/" + result.getMasModuleId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getMasModuleId().toString()))
            .body(result);
    }

    /**
     * PUT  /mas-modules : Updates an existing masModule.
     *
     * @param masModuleDTO the masModuleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masModuleDTO,
     * or with status 400 (Bad Request) if the masModuleDTO is not valid,
     * or with status 500 (Internal Server Error) if the masModuleDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/mas-modules")
    public ResponseEntity<MasModule> updateMasModule(@RequestBody MasModule masModuleDTO) throws URISyntaxException {
        log.debug("REST request to update MasModuleEntity : {}", masModuleDTO);
        if (masModuleDTO.getMasModuleId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasModule result = masModuleService.save(masModuleDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masModuleDTO.getMasModuleId().toString()))
            .body(result);
    }

    /**
     * GET  /mas-modules : get all the masModules.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masModules in body
     */
    @GetMapping("/mas-modules")
    public ResponseEntity<List<MasModule>> getAllMasModules(Pageable pageable) {
        log.debug("REST request to get a page of MasModules");
        Page<MasModule> page = masModuleService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-modules");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /mas-modules/:id : get the "id" masModule.
     *
     * @param id the id of the masModuleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masModuleDTO, or with status 404 (Not Found)
     */
    @GetMapping("/mas-modules/{id}")
    public ResponseEntity<MasModule> getMasModule(@PathVariable Long id) {
        log.debug("REST request to get MasModuleEntity : {}", id);
        Optional<MasModule> masModuleDTO = masModuleService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masModuleDTO);
    }

    /**
     * DELETE  /mas-modules/:id : delete the "id" masModule.
     *
     * @param id the id of the masModuleDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/mas-modules/{id}")
    public ResponseEntity<Void> deleteMasModule(@PathVariable Long id) {
        log.debug("REST request to delete MasModuleEntity : {}", id);
        masModuleService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
