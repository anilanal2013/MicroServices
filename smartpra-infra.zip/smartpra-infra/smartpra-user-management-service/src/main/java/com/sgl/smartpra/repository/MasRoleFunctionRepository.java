package com.sgl.smartpra.repository;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.config.Constants;
import com.sgl.smartpra.domain.FunctionActionsEntity;
import com.sgl.smartpra.domain.MasRoleEntity;
import com.sgl.smartpra.domain.MasRoleFunctionEntity;
import com.sgl.smartpra.domain.RoleFunctionActionsEntity;

@Repository
public interface MasRoleFunctionRepository extends JpaRepository<MasRoleFunctionEntity, Long> {

	@Query("SELECT new com.sgl.smartpra.domain.RoleFunctionActionsEntity"
			+ "(masRole.roleId,masRole.roleName,screen.screenFunctionId,screen.screenFunctionName,actions.actionName,actions.actionId,roleFunction.roleFunctionId,roleFunction.functionActionsEntity.functionActionId) "
			+ "FROM MasRoleFunctionEntity roleFunction,MasRoleEntity masRole ,FunctionActionsEntity functionActionsEntity,ScreenFunctionEntity screen,ActionEntity actions"
			+ " WHERE masRole.roleId=roleFunction.masRoleEntity.roleId and roleFunction.functionActionsEntity.functionActionId=functionActionsEntity.functionActionId and masRole.roleName=?1")
	List<RoleFunctionActionsEntity> getRolesAndPrevillages(String role);

	@Cacheable(cacheNames = Constants.USERS_FUNCTION_CACHE)
	List<MasRoleFunctionEntity> findAllByMasRoleEntityAndIsActiveIsTrue(MasRoleEntity masRoleEntity);

	List<MasRoleFunctionEntity> findAllByMasRoleEntityAndFunctionActionsEntityInAndIsActiveIsTrue(
			MasRoleEntity masRoleEntity, List<FunctionActionsEntity> functionActionsEntity);

	MasRoleFunctionEntity findOneByFunctionActionsEntity(FunctionActionsEntity functionActionsEntity);

}

// Optional<MasRoleEntity> findOneByRoleName(String anonymous);