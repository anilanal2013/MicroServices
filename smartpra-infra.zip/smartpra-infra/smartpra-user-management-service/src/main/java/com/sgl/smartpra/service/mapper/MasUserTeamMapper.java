package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasUserTeam;

import org.mapstruct.*;

/**
 * Mapper for the entity MasUserTeamEntity and its DTO MasUserTeam.
 */
@Mapper(componentModel = "spring", uses = {MasUsersMapper.class, MasTeamMapper.class})
public interface MasUserTeamMapper extends EntityMapper<MasUserTeam, MasUserTeamEntity> {
 
	@Mappings({
    @Mapping(source = "masUsers.userId", target = "masUsersId"),
    @Mapping(source = "masTeam.teamId", target = "masTeamId")})
    MasUserTeam toModel(MasUserTeamEntity masUserTeam);

	@Mappings({
    @Mapping(source = "masUsersId", target = "masUsers"),
    @Mapping(source = "masTeamId", target = "masTeam")})
    MasUserTeamEntity toEntity(MasUserTeam masUserTeamDTO);

    default MasUserTeamEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasUserTeamEntity masUserTeam = new MasUserTeamEntity();
        masUserTeam.setUserTeamId(id);
        return masUserTeam;
    }
}
