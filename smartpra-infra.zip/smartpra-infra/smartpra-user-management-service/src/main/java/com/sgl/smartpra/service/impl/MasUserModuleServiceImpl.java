package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.MasUserModuleService;
import com.sgl.smartpra.domain.MasUserModuleEntity;
import com.sgl.smartpra.repository.MasUserModuleRepository;
import com.sgl.smartpra.service.mapper.MasUserModuleMapper;
import com.sgl.smartpra.service.model.MasUserModule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing MasUserModuleEntity.
 */
@Service
@Transactional
public class MasUserModuleServiceImpl implements MasUserModuleService {

    private final Logger log = LoggerFactory.getLogger(MasUserModuleServiceImpl.class);

    private final MasUserModuleRepository masUserModuleRepository;

    private final MasUserModuleMapper masUserModuleMapper;

    public MasUserModuleServiceImpl(MasUserModuleRepository masUserModuleRepository, MasUserModuleMapper masUserModuleMapper) {
        this.masUserModuleRepository = masUserModuleRepository;
        this.masUserModuleMapper = masUserModuleMapper;
    }

    /**
     * Save a masUserModule.
     *
     * @param masUserModuleDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasUserModule save(MasUserModule masUserModuleDTO) {
        log.debug("Request to save MasUserModuleEntity : {}", masUserModuleDTO);
        MasUserModuleEntity masUserModule = masUserModuleMapper.toEntity(masUserModuleDTO);
        masUserModule = masUserModuleRepository.save(masUserModule);
        return masUserModuleMapper.toModel(masUserModule);
    }

    /**
     * Get all the masUserModules.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasUserModule> findAll(Pageable pageable) {
        log.debug("Request to get all MasUserModules");
        return masUserModuleRepository.findAll(pageable)
            .map(masUserModuleMapper::toModel);
    }


    /**
     * Get one masUserModule by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasUserModule> findOne(Long id) {
        log.debug("Request to get MasUserModuleEntity : {}", id);
        return masUserModuleRepository.findById(id)
            .map(masUserModuleMapper::toModel);
    }

    /**
     * Delete the masUserModule by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasUserModuleEntity : {}", id);        masUserModuleRepository.deleteById(id);
    }
}
