package com.sgl.smartpra.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.service.model.MasRole;

public interface MasRoleService {

    /**
     * Save a masRole.
     *
     * @param masRoleDTO the entity to save
     * @return the persisted entity
     */
    MasRole save(MasRole masRoleDTO);

    /**
     * Get all the masRoles.
     *
     * @return the list of entities
     */
    List<MasRole> findAll();


    /**
     * Get the "id" masRole.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasRole> findOne(Long id);

    /**
     * Delete the "id" masRole.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
    
    /**
     * Role details by role name
     * 
     * @param String roleName
     * @return MasRole entity
     */
    MasRole findByRoleName(String roleName);
}
