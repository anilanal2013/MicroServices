package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasUserGroup;

import java.util.Optional;

/**
 * Service Interface for managing MasUserGroupEntity.
 */
public interface MasUserGroupService {

    /**
     * Save a masUserGroup.
     *
     * @param masUserGroupDTO the entity to save
     * @return the persisted entity
     */
    MasUserGroup save(MasUserGroup masUserGroupDTO);

    /**
     * Get all the masUserGroups.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasUserGroup> findAll(Pageable pageable);


    /**
     * Get the "id" masUserGroup.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasUserGroup> findOne(Long id);

    /**
     * Delete the "id" masUserGroup.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
