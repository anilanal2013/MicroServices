package com.sgl.smartpra.service.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.sgl.smartpra.domain.FunctionActionsEntity;
import com.sgl.smartpra.service.model.FunctionAction;

@Mapper(componentModel = "spring", uses = { ScreenFunctionMapper.class, ActionMapper.class })
public interface FunctionActionMapper extends EntityMapper<FunctionAction, FunctionActionsEntity> {

	@Mappings({ @Mapping(source = "screenFunctionEntity.screenFunctionId", target = "functionId"),
			@Mapping(source = "actionEntity.actionId", target = "actionId") })
	FunctionAction toModel(FunctionActionsEntity functionActions);

	@Mappings({ @Mapping(source = "functionId", target = "screenFunctionEntity"),
			@Mapping(source = "actionId", target = "actionEntity") })
	FunctionActionsEntity toEntity(FunctionAction functionActionDto);

	default FunctionActionsEntity fromId(Long id) {
		if (id == null) {
			return null;
		}
		FunctionActionsEntity screenFunctionEntity = new FunctionActionsEntity();
		screenFunctionEntity.setFunctionActionId(id);
		return screenFunctionEntity;
	}
}
