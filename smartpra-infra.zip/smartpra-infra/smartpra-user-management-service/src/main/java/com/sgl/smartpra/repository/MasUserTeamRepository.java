package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.MasUserTeamEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the MasUserTeamEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MasUserTeamRepository extends JpaRepository<MasUserTeamEntity, Long> {

}
