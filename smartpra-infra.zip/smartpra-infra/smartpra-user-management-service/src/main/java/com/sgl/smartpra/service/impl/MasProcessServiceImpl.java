package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.MasProcessService;
import com.sgl.smartpra.domain.MasProcessEntity;
import com.sgl.smartpra.repository.MasProcessRepository;
import com.sgl.smartpra.service.mapper.MasProcessMapper;
import com.sgl.smartpra.service.model.MasProcess;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing MasProcessEntity.
 */
@Service
@Transactional
public class MasProcessServiceImpl implements MasProcessService {

    private final Logger log = LoggerFactory.getLogger(MasProcessServiceImpl.class);

    private final MasProcessRepository masProcessRepository;

    private final MasProcessMapper masProcessMapper;

    public MasProcessServiceImpl(MasProcessRepository masProcessRepository, MasProcessMapper masProcessMapper) {
        this.masProcessRepository = masProcessRepository;
        this.masProcessMapper = masProcessMapper;
    }

    /**
     * Save a masProcess.
     *
     * @param masProcessDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasProcess save(MasProcess masProcessDTO) {
        log.debug("Request to save MasProcessEntity : {}", masProcessDTO);
        MasProcessEntity masProcess = masProcessMapper.toEntity(masProcessDTO);
        masProcess = masProcessRepository.save(masProcess);
        return masProcessMapper.toModel(masProcess);
    }

    /**
     * Get all the masProcesses.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasProcess> findAll(Pageable pageable) {
        log.debug("Request to get all MasProcesses");
        return masProcessRepository.findAll(pageable)
            .map(masProcessMapper::toModel);
    }


    /**
     * Get one masProcess by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasProcess> findOne(Long id) {
        log.debug("Request to get MasProcessEntity : {}", id);
        return masProcessRepository.findById(id)
            .map(masProcessMapper::toModel);
    }

    /**
     * Delete the masProcess by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasProcessEntity : {}", id);        masProcessRepository.deleteById(id);
    }
}
