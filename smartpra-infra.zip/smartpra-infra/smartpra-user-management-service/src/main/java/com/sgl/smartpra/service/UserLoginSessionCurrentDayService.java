package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.UserLoginSessionCurrentDay;

import java.util.Optional;

/**
 * Service Interface for managing UserLoginSessionCurrentDayEntity.
 */
public interface UserLoginSessionCurrentDayService {

    /**
     * Save a userLoginSessionCurrentDay.
     *
     * @param userLoginSessionCurrentDayDTO the entity to save
     * @return the persisted entity
     */
    UserLoginSessionCurrentDay save(UserLoginSessionCurrentDay userLoginSessionCurrentDayDTO);

    /**
     * Get all the userLoginSessionCurrentDays.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<UserLoginSessionCurrentDay> findAll(Pageable pageable);


    /**
     * Get the "id" userLoginSessionCurrentDay.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<UserLoginSessionCurrentDay> findOne(Long id);

    /**
     * Delete the "id" userLoginSessionCurrentDay.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
