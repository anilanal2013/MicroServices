package com.sgl.smartpra.service.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.sgl.smartpra.domain.MasTeamEntity;
import com.sgl.smartpra.service.model.MasTeam;

/**
 * Mapper for the entity MasTeamEntity and its DTO MasTeam.
 */
@Mapper(componentModel = "spring", uses = {})
public interface MasTeamMapper extends EntityMapper<MasTeam, MasTeamEntity> {

    @Mapping(source = "groupId", target = "masGroup.groupId")
	MasTeamEntity toEntity(MasTeam masTeam);

	@Mapping(source = "masGroup.groupId", target = "groupId")
	MasTeam toModel(MasTeamEntity masTeamEntity);

	default MasTeamEntity fromId(Long id) {
		if (id == null) {
			return null;
		}
		MasTeamEntity masTeam = new MasTeamEntity();
		masTeam.setTeamId(id);
		return masTeam;
	}

}
