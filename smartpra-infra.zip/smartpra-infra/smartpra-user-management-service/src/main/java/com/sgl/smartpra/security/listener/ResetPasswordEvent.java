package com.sgl.smartpra.security.listener;

import org.springframework.context.ApplicationEvent;

import com.sgl.smartpra.domain.MasUsersEntity;
/**
 * 
 * @author mansound1
 *
 */
@SuppressWarnings("serial")
public class ResetPasswordEvent extends ApplicationEvent {

 
    private final MasUsersEntity user;
    
    private final String passwordHash;

  
	public ResetPasswordEvent(MasUsersEntity user, String passwordHash) {
		super(user);
		this.user = user;
		this.passwordHash = passwordHash;
	}


	public MasUsersEntity getUser() {
        return user;
    }

	   

    public String getPasswordHash() {
		return passwordHash;
	}

}
