package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.UserPasswordHistoryService;
import com.sgl.smartpra.domain.UserPasswordHistoryEntity;
import com.sgl.smartpra.repository.UserPasswordHistoryRepository;
import com.sgl.smartpra.service.mapper.UserPasswordHistoryMapper;
import com.sgl.smartpra.service.model.UserPasswordHistory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing UserPasswordHistoryEntity.
 */
@Service
@Transactional
public class UserPasswordHistoryServiceImpl implements UserPasswordHistoryService {

    private final Logger log = LoggerFactory.getLogger(UserPasswordHistoryServiceImpl.class);

    private final UserPasswordHistoryRepository userPasswordHistoryRepository;

    private final UserPasswordHistoryMapper userPasswordHistoryMapper;

    public UserPasswordHistoryServiceImpl(UserPasswordHistoryRepository userPasswordHistoryRepository, UserPasswordHistoryMapper userPasswordHistoryMapper) {
        this.userPasswordHistoryRepository = userPasswordHistoryRepository;
        this.userPasswordHistoryMapper = userPasswordHistoryMapper;
    }

    /**
     * Save a userPasswordHistory.
     *
     * @param userPasswordHistoryDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public UserPasswordHistory save(UserPasswordHistory userPasswordHistoryDTO) {
        log.debug("Request to save UserPasswordHistoryEntity : {}", userPasswordHistoryDTO);
        UserPasswordHistoryEntity userPasswordHistory = userPasswordHistoryMapper.toEntity(userPasswordHistoryDTO);
        userPasswordHistory = userPasswordHistoryRepository.save(userPasswordHistory);
        return userPasswordHistoryMapper.toModel(userPasswordHistory);
    }

    /**
     * Get all the userPasswordHistories.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<UserPasswordHistory> findAll(Pageable pageable) {
        log.debug("Request to get all UserPasswordHistories");
        return userPasswordHistoryRepository.findAll(pageable)
            .map(userPasswordHistoryMapper::toModel);
    }


    /**
     * Get one userPasswordHistory by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<UserPasswordHistory> findOne(Long id) {
        log.debug("Request to get UserPasswordHistoryEntity : {}", id);
        return userPasswordHistoryRepository.findById(id)
            .map(userPasswordHistoryMapper::toModel);
    }

    /**
     * Delete the userPasswordHistory by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete UserPasswordHistoryEntity : {}", id);        userPasswordHistoryRepository.deleteById(id);
    }

	@Override
	public UserPasswordHistory save(UserPasswordHistoryEntity userPasswordHistory) {
		UserPasswordHistoryEntity userPasswordHistoryLive = userPasswordHistoryRepository.save(userPasswordHistory);
		return userPasswordHistoryMapper.toModel(userPasswordHistoryLive);
	}

}
