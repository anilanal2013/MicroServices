package com.sgl.smartpra.service.util;

import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
/**
 * 
 * @author mansound1
 * 
 * Utility class for generating random Strings.
 *
 */
public final class RandomUtil {

    private static final int DEF_COUNT = 20;

    private RandomUtil() {
    }

    /**
     * Generate a password.
     *
     * @return the generated password
     */
    public static String generatePassword() {
        return RandomStringUtils.randomAlphanumeric(DEF_COUNT);
    }

    /**
     * Generate an activation key.
     *
     * @return the generated activation key
     */
    public static String generateActivationKey() {
        return RandomStringUtils.randomNumeric(DEF_COUNT);
    }

    /**
     * Generate a reset key.
     *
     * @return the generated reset key
     */
    public static String generateResetKey() {
        return RandomStringUtils.randomNumeric(DEF_COUNT);
    }
    /**
     * Generate a user name key.
     *
     * @return the generated user name key
     */
	public static String generateUserId(String firstname, String lastname) {
		Random rnd = new Random();
		String result="smartpra";
		result += Integer.toString(rnd.nextInt(99));
		if( firstname != null && !firstname.isEmpty() && lastname != null && !lastname.isEmpty()) {
		
		result = Character.toString(firstname.charAt(0)); // First char
		if (lastname.length() > 5)
			result += lastname.substring(0, 5);
		else
			result += lastname;
		result += Integer.toString(rnd.nextInt(99));
		}
		return result;
	}
}
