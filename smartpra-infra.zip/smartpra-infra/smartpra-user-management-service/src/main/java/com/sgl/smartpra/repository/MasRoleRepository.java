package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.MasRoleEntity;
import com.sgl.smartpra.domain.MasUsersEntity;

import java.util.Optional;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the MasRoleEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MasRoleRepository extends JpaRepository<MasRoleEntity, Long> {

	Optional<MasRoleEntity> findOneByRoleName(String userName);

	//Optional<MasRoleEntity> findOneByRoleName(String anonymous);
}
