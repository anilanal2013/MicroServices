package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasUserPassword;

import java.util.Optional;

/**
 * Service Interface for managing MasUserPasswordEntity.
 */
public interface MasUserPasswordService {

    /**
     * Save a masUserPassword.
     *
     * @param masUserPasswordDTO the entity to save
     * @return the persisted entity
     */
    MasUserPassword save(MasUserPassword masUserPasswordDTO);

    /**
     * Get all the masUserPasswords.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasUserPassword> findAll(Pageable pageable);


    /**
     * Get the "id" masUserPassword.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasUserPassword> findOne(Long id);

    /**
     * Delete the "id" masUserPassword.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
