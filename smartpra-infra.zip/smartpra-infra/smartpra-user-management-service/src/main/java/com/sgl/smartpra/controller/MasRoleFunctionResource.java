package com.sgl.smartpra.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.service.model.Action;
import com.sgl.smartpra.service.model.FunctionDetail;
import com.sgl.smartpra.service.model.MasRoleFunction;
import com.sgl.smartpra.service.model.ScreenFunction;

@RestController
@RequestMapping("/api")
public class MasRoleFunctionResource {
	private static String roleFunctionAction = "ROLE_FUNCTION_ACTION";

	@Autowired
	com.sgl.smartpra.service.MasRoleFunctionService masRoleFunctionService;

	@PostMapping("masrole-function")
	public ResponseEntity<List<MasRoleFunction>> saveMasRoleFunction(
			@RequestBody List<MasRoleFunction> masRoleFun) {
		List<MasRoleFunction> result = masRoleFunctionService.saveMasRoleFunction(masRoleFun);

		return ResponseEntity.created(null)
				.headers(HeaderUtil.createEntityCreationAlert(roleFunctionAction, result.toString())).body(result);
	}

	@PutMapping("masrole-function")
	public ResponseEntity<List<MasRoleFunction>> putMasRoleFunction(@RequestBody List<MasRoleFunction> masRoleFun)
			throws URISyntaxException {
		List<MasRoleFunction> result = masRoleFunctionService.saveMasRoleFunction(masRoleFun);

		return ResponseEntity.created(new URI("/api/masrole-function/" + result))
				.headers(HeaderUtil.createEntityCreationAlert(roleFunctionAction, result.toString())).body(result);
	}

	@GetMapping("masrole-function")
	public ResponseEntity<List<FunctionDetail>> getMasRoleFunction(
			@RequestParam(value = "role", required = true) String role,
			@RequestParam(value = "screenId", required = false) List<Long> screenId) {
		return ResponseEntity.ok().body(masRoleFunctionService.getRolesAndPrevillages(role, screenId));

	}
	
	@PostMapping("saveRoleFunctions")
	public List<MasRoleFunction> saveRoleFunctions(@RequestParam(value = "role", required = true) String role, 
			@RequestBody List<FunctionDetail> functionDetails) {
		return masRoleFunctionService.saveRoleFunctions(functionDetails, role);

	}
	
	@GetMapping("getScreenFunction")
	public List<ScreenFunction> getScreenFunction(){
		return masRoleFunctionService.getScreenFunction();
	}
	
	@GetMapping("getAction")
	public List<Action> getAction(){
		return masRoleFunctionService.getAction();
	}
	
	@DeleteMapping("deleteRoleFunctions")
	public ResponseEntity<Void> deleteRoleFunctions(@RequestParam(value = "role", required = true) String role, 
			@RequestBody List<FunctionDetail> functionDetails){
		masRoleFunctionService.deleteRoleFunctions(functionDetails, role);
		return ResponseEntity.ok().headers(HeaderUtil.createAlert("rolefunction.deleted", "successfully")).build();
	}
	
}
