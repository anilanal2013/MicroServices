package com.sgl.smartpra.security.listener;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.domain.UserPasswordHistoryEntity;
import com.sgl.smartpra.service.UserPasswordHistoryService;
/**
 * 
 * @author mansound1
 *
 */
@Component
public class ResetPasswordListener implements ApplicationListener<ResetPasswordEvent>{

	@Autowired
	UserPasswordHistoryService userPasswordHistoryService;
	
	@Override
	public void onApplicationEvent(final ResetPasswordEvent event) {
		System.out.println("Event called =====================>");
		
		UserPasswordHistoryEntity userPasswordHistory = new UserPasswordHistoryEntity();
		userPasswordHistory.setPasswordHash(event.getPasswordHash());
		userPasswordHistory.setMasUsers(event.getUser());
		userPasswordHistory.setPwdChangedDatetime(Instant.now());
		userPasswordHistoryService.save(userPasswordHistory);		
		System.out.println("DB updated=====================>");
	}

}
