package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.User2faLoginService;
import com.sgl.smartpra.service.model.User2faLogin;

/**
 * REST controller for managing User2faLoginEntity.
 */
@RestController
@RequestMapping("/api")
public class User2faLoginResource {

    private final Logger log = LoggerFactory.getLogger(User2faLoginResource.class);

    private static final String ENTITY_NAME = "user2faLogin";

    private final User2faLoginService user2faLoginService;

    public User2faLoginResource(User2faLoginService user2faLoginService) {
        this.user2faLoginService = user2faLoginService;
    }

    /**
     * POST  /user-2-fa-logins : Create a new user2faLogin.
     *
     * @param user2faLoginDTO the user2faLoginDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new user2faLoginDTO, or with status 400 (Bad Request) if the user2faLogin has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/user-2-fa-logins")
    public ResponseEntity<User2faLogin> createUser2faLogin(@RequestBody User2faLogin user2faLoginDTO) throws URISyntaxException {
        log.debug("REST request to save User2faLoginEntity : {}", user2faLoginDTO);
        if (user2faLoginDTO.getUser2faLoginId() != null) {
            throw new BadRequestAlertException("A new user2faLogin cannot already have an ID", ENTITY_NAME, "idexists");
        }
        User2faLogin result = user2faLoginService.save(user2faLoginDTO);
        return ResponseEntity.created(new URI("/api/user-2-fa-logins/" + result.getUser2faLoginId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getUser2faLoginId().toString()))
            .body(result);
    }

    /**
     * PUT  /user-2-fa-logins : Updates an existing user2faLogin.
     *
     * @param user2faLoginDTO the user2faLoginDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated user2faLoginDTO,
     * or with status 400 (Bad Request) if the user2faLoginDTO is not valid,
     * or with status 500 (Internal Server Error) if the user2faLoginDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/user-2-fa-logins")
    public ResponseEntity<User2faLogin> updateUser2faLogin(@RequestBody User2faLogin user2faLoginDTO) throws URISyntaxException {
        log.debug("REST request to update User2faLoginEntity : {}", user2faLoginDTO);
        if (user2faLoginDTO.getUser2faLoginId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        User2faLogin result = user2faLoginService.save(user2faLoginDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, user2faLoginDTO.getUser2faLoginId().toString()))
            .body(result);
    }

    /**
     * GET  /user-2-fa-logins : get all the user2faLogins.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of user2faLogins in body
     */
    @GetMapping("/user-2-fa-logins")
    public ResponseEntity<List<User2faLogin>> getAllUser2faLogins(Pageable pageable) {
        log.debug("REST request to get a page of User2faLogins");
        Page<User2faLogin> page = user2faLoginService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/user-2-fa-logins");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /user-2-fa-logins/:id : get the "id" user2faLogin.
     *
     * @param id the id of the user2faLoginDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the user2faLoginDTO, or with status 404 (Not Found)
     */
    @GetMapping("/user-2-fa-logins/{id}")
    public ResponseEntity<User2faLogin> getUser2faLogin(@PathVariable Long id) {
        log.debug("REST request to get User2faLoginEntity : {}", id);
        Optional<User2faLogin> user2faLoginDTO = user2faLoginService.findOne(id);
        return ResponseUtil.wrapOrNotFound(user2faLoginDTO);
    }

    /**
     * DELETE  /user-2-fa-logins/:id : delete the "id" user2faLogin.
     *
     * @param id the id of the user2faLoginDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/user-2-fa-logins/{id}")
    public ResponseEntity<Void> deleteUser2faLogin(@PathVariable Long id) {
        log.debug("REST request to delete User2faLoginEntity : {}", id);
        user2faLoginService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
