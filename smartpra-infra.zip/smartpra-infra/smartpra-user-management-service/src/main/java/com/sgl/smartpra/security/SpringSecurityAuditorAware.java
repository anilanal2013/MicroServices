package com.sgl.smartpra.security;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.util.Constants;


@Component
public class SpringSecurityAuditorAware implements AuditorAware<String> {

	 @Override
	    public Optional<String> getCurrentAuditor() {
	      //  Optional.of(SecurityUtils.getCurrentUserLogin().orElse(Constants.SYSTEM_ACCOUNT));
		 return Optional.of(Constants.SYSTEM_ACCOUNT);
	    }
}
