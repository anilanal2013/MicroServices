package com.sgl.smartpra.security.validation;

import java.util.Arrays;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.passay.AlphabeticalSequenceRule;
import org.passay.DigitCharacterRule;
import org.passay.LengthRule;
import org.passay.NumericalSequenceRule;
import org.passay.PasswordData;
import org.passay.PasswordValidator;
import org.passay.QwertySequenceRule;
import org.passay.RuleResult;
import org.passay.SpecialCharacterRule;
import org.passay.UppercaseCharacterRule;
import org.passay.WhitespaceRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.google.common.base.Joiner;
import com.sgl.smartpra.util.SmartPRATenantContextHolder;

@Configuration
@PropertySource({ "classpath:passwordpolicies.properties" })
public class SmartpraPasswordConstraintValidator implements ConstraintValidator<ValidPassword, String> {

	@Autowired
	private Environment env;

	// This Tenant name has been set when user login the application.
	private String tenatName = SmartPRATenantContextHolder.getTenant();

	@Override
	public void initialize(final ValidPassword arg0) {
		//Empty initialize method
	}

	@Override
	public boolean isValid(final String password, final ConstraintValidatorContext context) {

		int passwordMniLenth = Integer.parseInt(env.getProperty(tenatName + ".password.length.min"));
		int passwordMaxLenth = Integer.parseInt(env.getProperty(tenatName + ".password.length.max"));
		int uppercaseLenth = Integer.parseInt(env.getProperty(tenatName + ".password.uppercase.rule"));
		int digitLenth = Integer.parseInt(env.getProperty(tenatName + ".password.digit.rule"));
		int specialcharacterLenth = Integer.parseInt(env.getProperty(tenatName + ".password.specialcharacter.rule"));
		int numericalSequenceLenth = Integer.parseInt(env.getProperty(tenatName + ".password.numerical.sequence.rule"));
		int alphabeticalSequenceLenth = Integer.parseInt(env.getProperty(tenatName + ".alphabetical.sequence.rule"));
		int qwertyLenth = Integer.parseInt(env.getProperty(tenatName + ".password.qwerty.sequence.rule"));

		final PasswordValidator validator = new PasswordValidator(Arrays.asList(
				new LengthRule(passwordMniLenth, passwordMaxLenth), new UppercaseCharacterRule(uppercaseLenth),
				new DigitCharacterRule(digitLenth), new SpecialCharacterRule(specialcharacterLenth),
				new NumericalSequenceRule(numericalSequenceLenth, false),
				new AlphabeticalSequenceRule(alphabeticalSequenceLenth, false),
				new QwertySequenceRule(qwertyLenth, false), new WhitespaceRule()));
		final RuleResult result = validator.validate(new PasswordData(password));
		if (result.isValid()) {
			return true;
		}
		context.disableDefaultConstraintViolation();
		context.buildConstraintViolationWithTemplate(Joiner.on(",").join(validator.getMessages(result)))
				.addConstraintViolation();
		return false;
	}

}
