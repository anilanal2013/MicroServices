package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.User2faLoginEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the User2faLoginEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface User2faLoginRepository extends JpaRepository<User2faLoginEntity, Long> {

}
