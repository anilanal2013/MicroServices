package com.sgl.smartpra.service.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Properties;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.microsoft.sqlserver.jdbc.StringUtils;
import com.sgl.smartpra.domain.MasUsersEntity;

@Service
public class MailService {

	private final Logger log = LoggerFactory.getLogger(MailService.class);

	private static final String USER = "user";

	private static final String BASE_URL = "baseUrl";

	@Autowired
	private HttpServletRequest httpServletRequest;

	private final MessageSource messageSource;

	private final SpringTemplateEngine templateEngine;

	public MailService( MessageSource messageSource,
			SpringTemplateEngine templateEngine) {

		this.messageSource = messageSource;
		this.templateEngine = templateEngine;
	}
	
	
	

	
	private JavaMailSender getMailSender() {
		
		log.info("===========================Inside mail sender");
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

		Properties mailProperties = new Properties();
		mailProperties.put("mail.smtp.auth", false);
		mailProperties.put("mail.smtp.starttls.enable", true);
		mailProperties.put("mail.smtp.ssl.trust", "10.241.241.61");
		mailSender.setJavaMailProperties(mailProperties);
		mailSender.setHost("10.241.241.61");
		mailSender.setPort(25);
		mailSender.setProtocol("smtp");
		return mailSender;
	}
	
	
	

	@Async
	public void sendEmail(String to, String subject, String content, boolean isMultipart, boolean isHtml) {
		log.info("Send email[multipart '{}' and html '{}'] to '{}' with subject '{}' and content={}", isMultipart,
				isHtml, to, subject, content);

		// Prepare message using a Spring helper
		MimeMessage mimeMessage =  getMailSender().createMimeMessage();
		log.info("==================== {}", getMailSender().toString());
		try {
			MimeMessageHelper message = new MimeMessageHelper(mimeMessage, isMultipart, StandardCharsets.UTF_8.name());
			message.setTo(to);
			message.setFrom("SmartPRA_DEV@sutherlandglobal.com");
			message.setSubject(subject);
			message.setText(content, isHtml);
			 getMailSender().send(mimeMessage);
			log.debug("Sent email to User '{}'", to);
		} catch (Exception e) {
			log.error("Send Mail Failed :: {}", e);
			if (log.isDebugEnabled()) {
				log.warn("Email could not be sent to user '{}'", to, e);
			} else {
				log.warn("Email could not be sent to user '{}': {}", to, e.getMessage());
			}
		}
	}

	@Async
	public void sendEmailFromTemplate(MasUsersEntity user, String templateName, String titleKey) {
		Locale locale = Locale.forLanguageTag(user.getLangKey());
		Context context = new Context(locale);
		context.setVariable(USER, user);
		context.setVariable(BASE_URL, getAppUrl(httpServletRequest));
		String content = templateEngine.process(templateName, context);
		String subject = messageSource.getMessage(titleKey, null, locale);
		sendEmail(user.getEmail(), subject, content, false, true);

	}

	@Async
	public void sendActivationEmail(MasUsersEntity user) {
		log.debug("Sending activation email to '{}'", user.getEmail());
		sendEmailFromTemplate(user, "mail/activationEmail", "email.activation.title");
	}

	@Async
	public void sendCreationEmail(MasUsersEntity user) {
		log.debug("Sending creation email to '{}'", user.getEmail());
		sendEmailFromTemplate(user, "mail/creationEmail", "email.activation.title");
	}

	@Async
	public void sendPasswordResetMail(MasUsersEntity user) {
		log.debug("Sending password reset email to '{}'", user.getEmail());
		sendEmailFromTemplate(user, "mail/passwordResetEmail", "email.reset.title");
	}
	
	@Async
	public void sendForgetUserNameMail(MasUsersEntity user) {
		log.debug("Sending password forget user name email to '{}'", user.getEmail());
		sendEmailFromTemplate(user, "mail/forgetuseridEmail", "username.forget.title");
	}
	
	//forgetuseridEmail.html

	private String getAppUrl(HttpServletRequest request) {
		String appUrl = StringUtils.EMPTY;
		InetAddress address = null;
		try {
			address = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			log.error("getAppUrl Failed :: {}", e);
		}

		if (address != null) {
			appUrl = "http://" + address.getHostAddress();
		}

		return appUrl;
	}
	

}
