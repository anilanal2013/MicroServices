package com.sgl.smartpra.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.domain.MasUsersEntity;
import com.sgl.smartpra.service.model.MasUsers;
import com.sgl.smartpra.service.model.UserDetail;
import com.sgl.smartpra.service.model.UserIdAndName;

public interface MasUserService {

	Optional<MasUsersEntity> activateRegistration(String key);

	Optional<MasUsersEntity> completePasswordReset(String newPassword, String key);

	Optional<MasUsersEntity> requestPasswordReset(String email);

	MasUsersEntity registerUser(MasUsers userDTO, String password);

	MasUsersEntity createUser(MasUsers userDTO);

	void updateUser(String firstName, String lastName, String email, String langKey);

	Optional<MasUsers> updateUser(MasUsers userDTO);

	void deleteUser(String userName);

	void changePassword(String currentClearTextPassword, String newPassword);

	List<MasUsers> getAllManagedUsers();

	Optional<MasUsersEntity> getUserWithAuthoritiesByLogin(String userLogin);

	void removeNotActivatedUsers();

	void passwordExpiredRemaider();
	
	void acivateOrDeactivateUser(String userLogin);
	
	Optional<MasUsersEntity> setFirstTimePassword(String email,String newPassword);

	void bulkUserUpload(List<MasUsers> masUsers);
	
	void deleteUserById(Integer userId);

	List<MasUsers> getAllUsersByRoleName(String roleName);
	
	Optional<MasUsers> getUserByEmail(String email);
	
	Optional<MasUsers> getUserByUserId(Long userId);
	
	Optional<MasUsersEntity> requestUserName(String email);
	
	List<MasUsers> searchUsers(MasUsers userDTO);

	List<UserIdAndName> getUsersByTeamId(Integer teamId);

	Long getUserByNameOrEmail(String user);

    List<MasUsers> getUsersListByTeamId(Long teamId);
    
    /**
     * method for fetching screen functions and actions mapping
     * 
     * @param email of logged in user
     * @return list of {@code UserDetail}
     */
    UserDetail getFunctionDetails(String email);
}
