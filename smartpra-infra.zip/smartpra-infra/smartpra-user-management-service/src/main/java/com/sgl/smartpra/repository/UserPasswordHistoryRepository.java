package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.UserPasswordHistoryEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the UserPasswordHistoryEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface UserPasswordHistoryRepository extends JpaRepository<UserPasswordHistoryEntity, Long> {

}
