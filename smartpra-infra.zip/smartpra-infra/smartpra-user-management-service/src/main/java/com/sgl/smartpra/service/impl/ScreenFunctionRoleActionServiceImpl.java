/*package com.sgl.smartpra.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.domain.RoleFunctionActionEntity;
import com.sgl.smartpra.domain.RoleFunctionActionsEntity;
import com.sgl.smartpra.repository.RolesAndPrevillagesRepository;
import com.sgl.smartpra.security.SecurityUtils;
import com.sgl.smartpra.service.ScreenFunctionRoleActionService;
import com.sgl.smartpra.service.model.RoleFunction;
import com.sgl.smartpra.service.mapper.RoleFunctionActionMapper;

@Service
public class ScreenFunctionRoleActionServiceImpl implements ScreenFunctionRoleActionService {
	@Autowired
	RolesAndPrevillagesRepository repository;

	@Autowired
	RoleFunctionActionMapper mapper;

	@Override
	public List<RoleFunction> searchRole(String role) {

		List<RoleFunctionActionEntity> e = repository.serachRole(role);
		return mapper.toDto(e);
	}

	@Override
	public RoleFunction saveEntity(RoleFunction entity) {
		RoleFunctionActionEntity e = repository.save(mapper.toEntity(entity));
		return mapper.toDto(e);
	}

	@Override
	public List<RoleFunction> searchAllRole(String role) {
		List<RoleFunctionActionEntity> e = repository.serachRole(role);
		return mapper.toDto(e);
	}

	@Override
	public RoleFunction updateRoleFunctionAction(Long id, RoleFunction entity) {
		RoleFunctionActionEntity e = repository.save(mapper.toEntity(entity));
		return mapper.toDto(e);
	}

	@Override
	public void deleteeRoleFunctionAction(Long id) {

		repository.deleteById(id);
	}

	@Override
	public List<RoleFunctionActionsEntity> getRoleFunctions(String role) {
		return repository.getRolesAndPrevillages(role);
	}
}
*/