package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasUserPasswordService;
import com.sgl.smartpra.service.model.MasUserPassword;

/**
 * REST controller for managing MasUserPasswordEntity.
 */
@RestController
@RequestMapping("/api")
public class MasUserPasswordResource {

    private final Logger log = LoggerFactory.getLogger(MasUserPasswordResource.class);

    private static final String ENTITY_NAME = "masUserPassword";

    private final MasUserPasswordService masUserPasswordService;

    public MasUserPasswordResource(MasUserPasswordService masUserPasswordService) {
        this.masUserPasswordService = masUserPasswordService;
    }

    /**
     * POST  /mas-user-passwords : Create a new masUserPassword.
     *
     * @param masUserPasswordDTO the masUserPasswordDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masUserPasswordDTO, or with status 400 (Bad Request) if the masUserPassword has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/mas-user-passwords")
    public ResponseEntity<MasUserPassword> createMasUserPassword(@RequestBody MasUserPassword masUserPasswordDTO) throws URISyntaxException {
        log.debug("REST request to save MasUserPasswordEntity : {}", masUserPasswordDTO);
        if (masUserPasswordDTO.getUserPwdId() != null) {
            throw new BadRequestAlertException("A new masUserPassword cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasUserPassword result = masUserPasswordService.save(masUserPasswordDTO);
        return ResponseEntity.created(new URI("/api/mas-user-passwords/" + result.getUserPwdId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getUserPwdId().toString()))
            .body(result);
    }

    /**
     * PUT  /mas-user-passwords : Updates an existing masUserPassword.
     *
     * @param masUserPasswordDTO the masUserPasswordDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masUserPasswordDTO,
     * or with status 400 (Bad Request) if the masUserPasswordDTO is not valid,
     * or with status 500 (Internal Server Error) if the masUserPasswordDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/mas-user-passwords")
    public ResponseEntity<MasUserPassword> updateMasUserPassword(@RequestBody MasUserPassword masUserPasswordDTO) throws URISyntaxException {
        log.debug("REST request to update MasUserPasswordEntity : {}", masUserPasswordDTO);
        if (masUserPasswordDTO.getUserPwdId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasUserPassword result = masUserPasswordService.save(masUserPasswordDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masUserPasswordDTO.getUserPwdId().toString()))
            .body(result);
    }

    /**
     * GET  /mas-user-passwords : get all the masUserPasswords.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masUserPasswords in body
     */
    @GetMapping("/mas-user-passwords")
    public ResponseEntity<List<MasUserPassword>> getAllMasUserPasswords(Pageable pageable) {
        log.debug("REST request to get a page of MasUserPasswords");
        Page<MasUserPassword> page = masUserPasswordService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-user-passwords");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /mas-user-passwords/:id : get the "id" masUserPassword.
     *
     * @param id the id of the masUserPasswordDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masUserPasswordDTO, or with status 404 (Not Found)
     */
    @GetMapping("/mas-user-passwords/{id}")
    public ResponseEntity<MasUserPassword> getMasUserPassword(@PathVariable Long id) {
        log.debug("REST request to get MasUserPasswordEntity : {}", id);
        Optional<MasUserPassword> masUserPasswordDTO = masUserPasswordService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masUserPasswordDTO);
    }

    /**
     * DELETE  /mas-user-passwords/:id : delete the "id" masUserPassword.
     *
     * @param id the id of the masUserPasswordDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/mas-user-passwords/{id}")
    public ResponseEntity<Void> deleteMasUserPassword(@PathVariable Long id) {
        log.debug("REST request to delete MasUserPasswordEntity : {}", id);
        masUserPasswordService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
