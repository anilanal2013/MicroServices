package com.sgl.smartpra.service;

import java.util.List;

import com.sgl.smartpra.domain.RoleFunctionActionsEntity;
import com.sgl.smartpra.service.model.RoleFunction;

public interface ScreenFunctionRoleActionService {

	RoleFunction saveEntity(RoleFunction entity);

	List<RoleFunction> searchRole(String role);

	List<RoleFunction> searchAllRole(String role);

	RoleFunction updateRoleFunctionAction(Long id, RoleFunction entity);

	void deleteeRoleFunctionAction(Long id);
	
	List<RoleFunctionActionsEntity> getRoleFunctions(String role);

}
