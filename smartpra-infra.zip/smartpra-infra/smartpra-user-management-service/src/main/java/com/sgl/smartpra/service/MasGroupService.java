package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasGroup;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing MasGroupEntity.
 */
public interface MasGroupService {

    /**
     * Save a masGroup.
     *
     * @param masGroupDTO the entity to save
     * @return the persisted entity
     */
    MasGroup save(MasGroup masGroupDTO);

    /**
     * Get all the masGroups.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasGroup> findAll(Pageable pageable);


    /**
     * Get the "id" masGroup.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasGroup> findOne(Long id);

    /**
     * Delete the "id" masGroup.
     *
     * @param id the id of the entity
     */
    void delete(Long id);

    Optional<MasGroup> findMasGroupsById(Long teamId, Long  groupId, Long userId);

    Optional<List<MasGroup>> findMasGroupTeamByLovId(Integer lovId);

    MasGroup findApproverByTeamId(Long teamId);
}
