package com.sgl.smartpra.security.listener;

import org.springframework.context.ApplicationEvent;

import com.sgl.smartpra.domain.MasUsersEntity;
/**
 * 
 * @author mansound1
 *
 */
@SuppressWarnings("serial")
public class ProfileActivationEvent extends ApplicationEvent {

 
    private final MasUsersEntity user;

    public ProfileActivationEvent(final MasUsersEntity user) {
        super(user);
        this.user = user;
    
    }

    //

    public MasUsersEntity getUser() {
        return user;
    }

}
