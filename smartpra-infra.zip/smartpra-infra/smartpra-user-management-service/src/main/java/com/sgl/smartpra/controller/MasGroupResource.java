package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasGroupService;
import com.sgl.smartpra.service.model.MasGroup;

/**
 * REST controller for managing MasGroupEntity.
 */
@RestController
@RequestMapping("/api")
public class MasGroupResource {

    private final Logger log = LoggerFactory.getLogger(MasGroupResource.class);

    private static final String ENTITY_NAME = "masGroup";

    private final MasGroupService masGroupService;

    public MasGroupResource(MasGroupService masGroupService) {
        this.masGroupService = masGroupService;
    }

    /**
     * POST  /mas-groups : Create a new masGroup.
     *
     * @param masGroupDTO the masGroupDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masGroupDTO, or with status 400 (Bad Request) if the masGroup has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/mas-groups")
    public ResponseEntity<MasGroup> createMasGroup(@RequestBody MasGroup masGroupDTO) throws URISyntaxException {
        log.debug("REST request to save MasGroupEntity : {}", masGroupDTO);
        if (masGroupDTO.getGroupId() != null) {
            throw new BadRequestAlertException("A new masGroup cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasGroup result = masGroupService.save(masGroupDTO);
        return ResponseEntity.created(new URI("/api/mas-groups/" + result.getGroupId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getGroupId().toString()))
            .body(result);
    }

    /**
     * PUT  /mas-groups : Updates an existing masGroup.
     *
     * @param masGroupDTO the masGroupDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masGroupDTO,
     * or with status 400 (Bad Request) if the masGroupDTO is not valid,
     * or with status 500 (Internal Server Error) if the masGroupDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/mas-groups")
    public ResponseEntity<MasGroup> updateMasGroup(@RequestBody MasGroup masGroupDTO) throws URISyntaxException {
        log.debug("REST request to update MasGroupEntity : {}", masGroupDTO);
        if (masGroupDTO.getGroupId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        System.out.println("============1===================>"+masGroupDTO.getGroupId());
        MasGroup result = masGroupService.save(masGroupDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masGroupDTO.getGroupId().toString()))
            .body(result);
    }

    /**
     * GET  /mas-groups : get all the masGroups.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masGroups in body
     */
    @GetMapping("/mas-groups")
    public ResponseEntity<List<MasGroup>> getAllMasGroups(Pageable pageable) {
        log.debug("REST request to get a page of MasGroups");
        Page<MasGroup> page = masGroupService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-groups");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /mas-groups/:id : get the "id" masGroup.
     *
     * @param id the id of the masGroupDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masGroupDTO, or with status 404 (Not Found)
     */
    @GetMapping("/mas-groups/{id}")
    public ResponseEntity<MasGroup> getMasGroup(@PathVariable Long id) {
        log.debug("REST request to get MasGroupEntity : {}", id);
        Optional<MasGroup> masGroupDTO = masGroupService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masGroupDTO);
    }

    /**
     * DELETE  /mas-groups/:id : delete the "id" masGroup.
     *
     * @param id the id of the masGroupDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/mas-groups/{id}")
    public ResponseEntity<Void> deleteMasGroup(@PathVariable Long id) {
        log.debug("REST request to delete MasGroupEntity : {}", id);
        masGroupService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }

    @GetMapping("/mas-groups/groups")
    public ResponseEntity<MasGroup> getMasGroupById(@RequestParam(name = "teamId",required = false) Long teamId,
                                                    @RequestParam(name = "groupId",required = false) Long groupId,
                                                    @RequestParam(name = "userId",required = false) Long userId) {
        log.debug("REST request to get MasGroupEntityByGroup Team or Team Id : {}", teamId);
        return ResponseUtil.wrapOrNotFound(masGroupService.findMasGroupsById(teamId,groupId,userId));
    }

    @GetMapping("/mas-groups/groups/{lovId}")
    public ResponseEntity<List<MasGroup>> getGroupsByLovId(@PathVariable Integer lovId) {
        log.debug("REST request to get MasGroupEntityByGroup Team or Lov Id : {}", lovId);
        return ResponseUtil.wrapOrNotFound(masGroupService.findMasGroupTeamByLovId(lovId));
    }

    @GetMapping("/mas-groups/approver/{teamId}")
    public MasGroup getApproverByTeamId(@PathVariable Long teamId) {
        log.debug("REST request to get approvers bt teamid", teamId);
        return masGroupService.findApproverByTeamId(teamId);
    }

}
