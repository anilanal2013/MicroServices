package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasUserPassword;

import org.mapstruct.*;

/**
 * Mapper for the entity MasUserPasswordEntity and its DTO MasUserPassword.
 */
@Mapper(componentModel = "spring", uses = {})
public interface MasUserPasswordMapper extends EntityMapper<MasUserPassword, MasUserPasswordEntity> {



    default MasUserPasswordEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasUserPasswordEntity masUserPassword = new MasUserPasswordEntity();
        masUserPassword.setUserPwdId(id);
        return masUserPassword;
    }
}
