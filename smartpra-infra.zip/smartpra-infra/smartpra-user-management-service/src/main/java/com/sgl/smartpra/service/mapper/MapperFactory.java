package com.sgl.smartpra.service.mapper;

import org.mapstruct.factory.Mappers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//@Configuration
public class MapperFactory {

	/*@Bean
	public MasGroupMapper getMasGroupMapper() {
		return Mappers.getMapper(MasGroupMapper.class);
	}
*/
	/*@Bean
	public MasModuleMapper getCountryDetailMapper() {
		return Mappers.getMapper(MasModuleMapper.class);
	}

	@Bean
	public MasPasswordSecretQuestionMapper getAirportMapper() {
		return Mappers.getMapper(MasPasswordSecretQuestionMapper.class);
	}

	@Bean
	public MasProcessMapper getCarrierMapper() {
		return Mappers.getMapper(MasProcessMapper.class);
	}

	@Bean
	public MasRoleMapper getStandardAreaMapper() {
		return Mappers.getMapper(MasRoleMapper.class);
	}

	@Bean
	public MasTeamMapper getCurrencyDetailMapper() {
		return Mappers.getMapper(MasTeamMapper.class);
	}

	@Bean
	public MasUserGroupMapper getStandardAreaDetailMapper() {
		return Mappers.getMapper(MasUserGroupMapper.class);
	}

	@Bean
	public MasUserLoginMapper getCarrierDetailMapper() {
		return Mappers.getMapper(MasUserLoginMapper.class);
	}

	@Bean
	public MasUserModuleMapper getStandardAreaGeographyTypeMapper() {
		return Mappers.getMapper(MasUserModuleMapper.class);
	}

	@Bean
	public MasUserPasswordMapper getUserAreaMapper() {
		return Mappers.getMapper(MasUserPasswordMapper.class);
	}

	@Bean
	public MasUserRoleMapper getMprMapper() {
		return Mappers.getMapper(MasUserRoleMapper.class);
	}

	@Bean
	public MasUsersMapper getProrateFactorMapper() {
		return Mappers.getMapper(MasUsersMapper.class);
	}

	@Bean
	public MasUserTeamMapper getMasUserTeamMapper() {
		return Mappers.getMapper(MasUserTeamMapper.class);
	}

	@Bean
	public User2faLoginMapper getUser2faLoginMapper() {
		return Mappers.getMapper(User2faLoginMapper.class);
	}

	@Bean
	public UserLoginSessionCurrentDayMapper getUserLoginSessionCurrentDayMapper() {
		return Mappers.getMapper(UserLoginSessionCurrentDayMapper.class);
	}

	@Bean
	public UserPasswordHistoryMapper getProvisioBaseAmountMapper() {
		return Mappers.getMapper(UserPasswordHistoryMapper.class);
	}*/
}