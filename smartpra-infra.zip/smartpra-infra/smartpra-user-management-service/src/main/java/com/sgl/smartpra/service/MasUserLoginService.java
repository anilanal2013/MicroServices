package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasUserLogin;

import java.util.Optional;

/**
 * Service Interface for managing MasUserLoginEntity.
 */
public interface MasUserLoginService {

    /**
     * Save a masUserLogin.
     *
     * @param masUserLoginDTO the entity to save
     * @return the persisted entity
     */
    MasUserLogin save(MasUserLogin masUserLoginDTO);

    /**
     * Get all the masUserLogins.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasUserLogin> findAll(Pageable pageable);


    /**
     * Get the "id" masUserLogin.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasUserLogin> findOne(Long id);

    /**
     * Delete the "id" masUserLogin.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
    
    /**
     * 
     * @return
     */
    
    Optional<MasUserLogin> findOneByUser(Long userId);
}
