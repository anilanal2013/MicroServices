package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasProcessService;
import com.sgl.smartpra.service.model.MasProcess;

/**
 * REST controller for managing MasProcessEntity.
 */
@RestController
@RequestMapping("/api")
public class MasProcessResource {

    private final Logger log = LoggerFactory.getLogger(MasProcessResource.class);

    private static final String ENTITY_NAME = "masProcess";

    private final MasProcessService masProcessService;

    public MasProcessResource(MasProcessService masProcessService) {
        this.masProcessService = masProcessService;
    }

    /**
     * POST  /mas-processes : Create a new masProcess.
     *
     * @param masProcessDTO the masProcessDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masProcessDTO, or with status 400 (Bad Request) if the masProcess has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/mas-processes")
    public ResponseEntity<MasProcess> createMasProcess(@RequestBody MasProcess masProcessDTO) throws URISyntaxException {
        log.debug("REST request to save MasProcessEntity : {}", masProcessDTO);
        if (masProcessDTO.getMasProcessDTOId() != null) {
            throw new BadRequestAlertException("A new masProcess cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasProcess result = masProcessService.save(masProcessDTO);
        return ResponseEntity.created(new URI("/api/mas-processes/" + result.getMasProcessDTOId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getMasProcessDTOId().toString()))
            .body(result);
    }

    /**
     * PUT  /mas-processes : Updates an existing masProcess.
     *
     * @param masProcessDTO the masProcessDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masProcessDTO,
     * or with status 400 (Bad Request) if the masProcessDTO is not valid,
     * or with status 500 (Internal Server Error) if the masProcessDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/mas-processes")
    public ResponseEntity<MasProcess> updateMasProcess(@RequestBody MasProcess masProcessDTO) throws URISyntaxException {
        log.debug("REST request to update MasProcessEntity : {}", masProcessDTO);
        if (masProcessDTO.getMasProcessDTOId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasProcess result = masProcessService.save(masProcessDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masProcessDTO.getMasProcessDTOId().toString()))
            .body(result);
    }

    /**
     * GET  /mas-processes : get all the masProcesses.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masProcesses in body
     */
    @GetMapping("/mas-processes")
    public ResponseEntity<List<MasProcess>> getAllMasProcesses(Pageable pageable) {
        log.debug("REST request to get a page of MasProcesses");
        Page<MasProcess> page = masProcessService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-processes");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /mas-processes/:id : get the "id" masProcess.
     *
     * @param id the id of the masProcessDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masProcessDTO, or with status 404 (Not Found)
     */
    @GetMapping("/mas-processes/{id}")
    public ResponseEntity<MasProcess> getMasProcess(@PathVariable Long id) {
        log.debug("REST request to get MasProcessEntity : {}", id);
        Optional<MasProcess> masProcessDTO = masProcessService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masProcessDTO);
    }

    /**
     * DELETE  /mas-processes/:id : delete the "id" masProcess.
     *
     * @param id the id of the masProcessDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/mas-processes/{id}")
    public ResponseEntity<Void> deleteMasProcess(@PathVariable Long id) {
        log.debug("REST request to delete MasProcessEntity : {}", id);
        masProcessService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
