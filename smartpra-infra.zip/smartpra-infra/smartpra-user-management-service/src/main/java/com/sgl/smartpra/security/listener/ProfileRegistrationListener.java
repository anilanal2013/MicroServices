package com.sgl.smartpra.security.listener;

import java.time.Instant;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.domain.MasUsersEntity;
import com.sgl.smartpra.service.MasUserLoginService;
import com.sgl.smartpra.service.impl.MailService;
import com.sgl.smartpra.service.model.MasUserLogin;
/**
 * 
 * @author mansound1
 *
 * This Listener will triggered after profile registration for sending emails.
 * We can enhance based on any other activity required after profile registration
 */
@Component
public class ProfileRegistrationListener implements ApplicationListener<ProfileRegistrationCompleteEvent>{

	
	@Autowired
	MailService mailService;
	
	@Autowired
	MasUserLoginService masUserLoginService ;
	
    @Autowired
    private HttpServletRequest request;

	@Override
	public void onApplicationEvent(final ProfileRegistrationCompleteEvent event) {
		
		this.confirmRegistration(event);
		masUserLoginService.save(buildMasUserLoginDTO(event.getUser()));

	}
	
	private void confirmRegistration(final ProfileRegistrationCompleteEvent event) {
		mailService.sendActivationEmail(event.getUser());
	}
	
	private MasUserLogin buildMasUserLoginDTO(MasUsersEntity masUsers){
		
		MasUserLogin masUserLoginDTO = new MasUserLogin();
		masUserLoginDTO.setIsFirstTimeLogin(false);
		masUserLoginDTO.setUserLoginIsactive(false);
		masUserLoginDTO.setMasUsersId(masUsers.getUserId());
		masUserLoginDTO.setLastAccessedScreenCtrlId("login");
		masUserLoginDTO.setIsLoginLocked(false);
		masUserLoginDTO.setIsPasswordReset(false);
		masUserLoginDTO.setIsFirstTimePasswordChanged("0");
		masUserLoginDTO.setFailedLoginAttempts(0);
		masUserLoginDTO.setLastLoginTime(Instant.now());
		masUserLoginDTO.setLstLoginDayIdleSessionCnt(0);
		masUserLoginDTO.setLastLoggedInCxrId("log");
		masUserLoginDTO.setLastLoggedInIpAddress( getClientIP());
		return masUserLoginDTO;
		
	}
	
	private final String getClientIP() {
		String ipAddress = "127.0.0.1";
		try {
			final String xfHeader = request.getHeader("X-Forwarded-For");
			if (xfHeader == null) {
				ipAddress = request.getRemoteAddr();
			} else {
				return xfHeader.split(",")[0];
			}
		} catch (Exception e) {
			
		}
		return ipAddress;
	}  
	


}
