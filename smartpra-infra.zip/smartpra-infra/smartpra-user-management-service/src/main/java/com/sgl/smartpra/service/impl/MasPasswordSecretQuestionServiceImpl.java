package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.MasPasswordSecretQuestionService;
import com.sgl.smartpra.domain.MasPasswordSecretQuestionEntity;
import com.sgl.smartpra.repository.MasPasswordSecretQuestionRepository;
import com.sgl.smartpra.service.mapper.MasPasswordSecretQuestionMapper;
import com.sgl.smartpra.service.model.MasPasswordSecretQuestion;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing MasPasswordSecretQuestionEntity.
 */
@Service
@Transactional
public class MasPasswordSecretQuestionServiceImpl implements MasPasswordSecretQuestionService {

    private final Logger log = LoggerFactory.getLogger(MasPasswordSecretQuestionServiceImpl.class);

    private final MasPasswordSecretQuestionRepository masPasswordSecretQuestionRepository;

    private final MasPasswordSecretQuestionMapper masPasswordSecretQuestionMapper;

    public MasPasswordSecretQuestionServiceImpl(MasPasswordSecretQuestionRepository masPasswordSecretQuestionRepository, MasPasswordSecretQuestionMapper masPasswordSecretQuestionMapper) {
        this.masPasswordSecretQuestionRepository = masPasswordSecretQuestionRepository;
        this.masPasswordSecretQuestionMapper = masPasswordSecretQuestionMapper;
    }

    /**
     * Save a masPasswordSecretQuestion.
     *
     * @param masPasswordSecretQuestionDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasPasswordSecretQuestion save(MasPasswordSecretQuestion masPasswordSecretQuestionDTO) {
        log.debug("Request to save MasPasswordSecretQuestionEntity : {}", masPasswordSecretQuestionDTO);
        MasPasswordSecretQuestionEntity masPasswordSecretQuestion = masPasswordSecretQuestionMapper.toEntity(masPasswordSecretQuestionDTO);
        masPasswordSecretQuestion = masPasswordSecretQuestionRepository.save(masPasswordSecretQuestion);
        return masPasswordSecretQuestionMapper.toModel(masPasswordSecretQuestion);
    }

    /**
     * Get all the masPasswordSecretQuestions.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasPasswordSecretQuestion> findAll(Pageable pageable) {
        log.debug("Request to get all MasPasswordSecretQuestions");
        return masPasswordSecretQuestionRepository.findAll(pageable)
            .map(masPasswordSecretQuestionMapper::toModel);
    }


    /**
     * Get one masPasswordSecretQuestion by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasPasswordSecretQuestion> findOne(Long id) {
        log.debug("Request to get MasPasswordSecretQuestionEntity : {}", id);
        return masPasswordSecretQuestionRepository.findById(id)
            .map(masPasswordSecretQuestionMapper::toModel);
    }

    /**
     * Delete the masPasswordSecretQuestion by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasPasswordSecretQuestionEntity : {}", id);        masPasswordSecretQuestionRepository.deleteById(id);
    }
}
