/*package com.sgl.smartpra.service.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.sgl.smartpra.exception.master.entity.ExceptionParametersDefinitionEntity;
import com.sgl.smartpra.exception.master.model.ExceptionParametersDefinitionModel;


@Mapper
public interface RoleMapper {

	@Mapping(source="createdBy", target="createdBy")
	@Mapping(source="lastUpdatedBy", target="lastUpdatedBy")
	@Mapping(source="parametersDefinitionModel.parameterDefinitionId", target="parameterDefinitionId", ignore=true)
	ExceptionParametersDefinitionEntity mapToParametersDefinitionEntity(
			ExceptionParametersDefinitionModel parametersDefinitionModel, String createdBy, String lastUpdatedBy);

	ExceptionParametersDefinitionModel mapToParametersDefinitionModel(
			ExceptionParametersDefinitionEntity parametersDefinitionEntity);

	List<ExceptionParametersDefinitionEntity> mapToParametersDefinitionEntityList(
			List<ExceptionParametersDefinitionModel> parametersDefinitionModelList);

}*/