package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.User2faLoginService;
import com.sgl.smartpra.domain.User2faLoginEntity;
import com.sgl.smartpra.repository.User2faLoginRepository;
import com.sgl.smartpra.service.mapper.User2faLoginMapper;
import com.sgl.smartpra.service.model.User2faLogin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing User2faLoginEntity.
 */
@Service
@Transactional
public class User2faLoginServiceImpl implements User2faLoginService {

    private final Logger log = LoggerFactory.getLogger(User2faLoginServiceImpl.class);

    private final User2faLoginRepository user2faLoginRepository;

    private final User2faLoginMapper user2faLoginMapper;

    public User2faLoginServiceImpl(User2faLoginRepository user2faLoginRepository, User2faLoginMapper user2faLoginMapper) {
        this.user2faLoginRepository = user2faLoginRepository;
        this.user2faLoginMapper = user2faLoginMapper;
    }

    /**
     * Save a user2faLogin.
     *
     * @param user2faLoginDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public User2faLogin save(User2faLogin user2faLoginDTO) {
        log.debug("Request to save User2faLoginEntity : {}", user2faLoginDTO);
        User2faLoginEntity user2faLogin = user2faLoginMapper.toEntity(user2faLoginDTO);
        user2faLogin = user2faLoginRepository.save(user2faLogin);
        return user2faLoginMapper.toModel(user2faLogin);
    }

    /**
     * Get all the user2faLogins.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<User2faLogin> findAll(Pageable pageable) {
        log.debug("Request to get all User2faLogins");
        return user2faLoginRepository.findAll(pageable)
            .map(user2faLoginMapper::toModel);
    }


    /**
     * Get one user2faLogin by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<User2faLogin> findOne(Long id) {
        log.debug("Request to get User2faLoginEntity : {}", id);
        return user2faLoginRepository.findById(id)
            .map(user2faLoginMapper::toModel);
    }

    /**
     * Delete the user2faLogin by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete User2faLoginEntity : {}", id);        user2faLoginRepository.deleteById(id);
    }
}
