package com.sgl.smartpra.service.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.sgl.smartpra.domain.RoleFunctionActionEntity;
import com.sgl.smartpra.service.model.RoleFunction;

@Mapper(componentModel = "spring", uses = { MasRoleMapper.class, FunctionActionMapper.class })
public interface RoleFunctionActionMapper extends EntityMapper<RoleFunction, RoleFunctionActionEntity> {

	@Mappings({ @Mapping(source = "masRole.roleId", target = "roleId"),
			@Mapping(source = "functionActions.functionActionId", target = "functionActionId") ,
			@Mapping(source = "roleFunctionActionId", target = "roleFunctionActionId") })
	RoleFunction toModel(RoleFunctionActionEntity roleFunctionActionEntity);

	@Mappings({ @Mapping(source = "roleId", target = "masRole"),
			@Mapping(source = "functionActionId", target = "functionActions") })
	RoleFunctionActionEntity toEntity(RoleFunction masUserRoleDTO);
	
	

	default RoleFunctionActionEntity fromId(Long id) {
		if (id == null) {
			return null;
		}
		RoleFunctionActionEntity masUserRole = new RoleFunctionActionEntity();
		masUserRole.setRoleFunctionActionId(id);
		return masUserRole;
	}
}
