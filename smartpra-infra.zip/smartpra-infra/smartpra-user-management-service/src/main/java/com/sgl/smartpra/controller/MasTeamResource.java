package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasTeamService;
import com.sgl.smartpra.service.model.MasTeam;

/**
 * REST controller for managing MasTeamEntity.
 */
@RestController
@RequestMapping("/api")
public class MasTeamResource {

    private final Logger log = LoggerFactory.getLogger(MasTeamResource.class);

    private static final String ENTITY_NAME = "masTeam";

    private final MasTeamService masTeamService;

    public MasTeamResource(MasTeamService masTeamService) {
        this.masTeamService = masTeamService;
    }

    /**
     * POST  /mas-teams : Create a new masTeam.
     *
     * @param masTeamDTO the masTeamDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masTeamDTO, or with status 400 (Bad Request) if the masTeam has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/mas-teams")
    public ResponseEntity<MasTeam> createMasTeam(@RequestBody MasTeam masTeamDTO) throws URISyntaxException {
        log.debug("REST request to save MasTeamEntity : {}", masTeamDTO);
        if (masTeamDTO.getTeamId() != null) {
            throw new BadRequestAlertException("A new masTeam cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasTeam result = masTeamService.save(masTeamDTO);
        return ResponseEntity.created(new URI("/api/mas-teams/" + result.getTeamId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getTeamId().toString()))
            .body(result);
    }

    /**
     * PUT  /mas-teams : Updates an existing masTeam.
     *
     * @param masTeamDTO the masTeamDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masTeamDTO,
     * or with status 400 (Bad Request) if the masTeamDTO is not valid,
     * or with status 500 (Internal Server Error) if the masTeamDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/mas-teams")
    public ResponseEntity<MasTeam> updateMasTeam(@RequestBody MasTeam masTeamDTO) throws URISyntaxException {
        log.debug("REST request to update MasTeamEntity : {}", masTeamDTO);
        if (masTeamDTO.getTeamId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasTeam result = masTeamService.save(masTeamDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masTeamDTO.getTeamId().toString()))
            .body(result);
    }

    /**
     * GET  /mas-teams : get all the masTeams.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masTeams in body
     */
    @GetMapping("/mas-teams")
    public ResponseEntity<List<MasTeam>> getAllMasTeams(Pageable pageable) {
        log.debug("REST request to get a page of MasTeams");
        Page<MasTeam> page = masTeamService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-teams");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /mas-teams/:id : get the "id" masTeam.
     *
     * @param id the id of the masTeamDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masTeamDTO, or with status 404 (Not Found)
     */
    @GetMapping("/mas-teams/{id}")
    public ResponseEntity<MasTeam> getMasTeam(@PathVariable Long id) {
        log.debug("REST request to get MasTeamEntity : {}", id);
        Optional<MasTeam> masTeamDTO = masTeamService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masTeamDTO);
    }

    /**
     * DELETE  /mas-teams/:id : delete the "id" masTeam.
     *
     * @param id the id of the masTeamDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/mas-teams/{id}")
    public ResponseEntity<Void> deleteMasTeam(@PathVariable Long id) {
        log.debug("REST request to delete MasTeamEntity : {}", id);
        masTeamService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
    
    @GetMapping("/mas-teams/byGroup/{groupId}")
    public ResponseEntity<List<MasTeam>> getAllMasTeamsByGroup(@PathVariable Long groupId) {
        log.debug("REST request to get  MasTeams by Group");
        return ResponseEntity.ok().body(masTeamService.findTeamsByGroup(groupId));
    }
}
