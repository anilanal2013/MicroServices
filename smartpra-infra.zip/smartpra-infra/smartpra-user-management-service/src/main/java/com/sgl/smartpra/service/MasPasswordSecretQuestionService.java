package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasPasswordSecretQuestion;

import java.util.Optional;

/**
 * Service Interface for managing MasPasswordSecretQuestionEntity.
 */
public interface MasPasswordSecretQuestionService {

    /**
     * Save a masPasswordSecretQuestion.
     *
     * @param masPasswordSecretQuestionDTO the entity to save
     * @return the persisted entity
     */
    MasPasswordSecretQuestion save(MasPasswordSecretQuestion masPasswordSecretQuestionDTO);

    /**
     * Get all the masPasswordSecretQuestions.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasPasswordSecretQuestion> findAll(Pageable pageable);


    /**
     * Get the "id" masPasswordSecretQuestion.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasPasswordSecretQuestion> findOne(Long id);

    /**
     * Delete the "id" masPasswordSecretQuestion.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
