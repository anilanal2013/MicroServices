package com.sgl.smartpra.controller;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasPasswordSecretQuestionService;
import com.sgl.smartpra.service.model.MasPasswordSecretQuestion;

/**
 * REST controller for managing MasPasswordSecretQuestionEntity.
 */
@RestController
@RequestMapping("/api")
public class MasPasswordSecretQuestionResource {

    private final Logger log = LoggerFactory.getLogger(MasPasswordSecretQuestionResource.class);

    private static final String ENTITY_NAME = "masPasswordSecretQuestion";

    private final MasPasswordSecretQuestionService masPasswordSecretQuestionService;

    public MasPasswordSecretQuestionResource(MasPasswordSecretQuestionService masPasswordSecretQuestionService) {
        this.masPasswordSecretQuestionService = masPasswordSecretQuestionService;
    }

    /**
     * POST  /mas-password-secret-questions : Create a new masPasswordSecretQuestion.
     *
     * @param masPasswordSecretQuestionDTO the masPasswordSecretQuestionDTO to create
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/mas-password-secret-questions")
    public void createMasPasswordSecretQuestion(@RequestBody MasPasswordSecretQuestion masPasswordSecretQuestionDTO) throws URISyntaxException {
        log.debug("REST request to save MasPasswordSecretQuestionEntity : {}", masPasswordSecretQuestionDTO);
        if (masPasswordSecretQuestionDTO.getMasPasswordSecretQuestionId() != null) {
            throw new BadRequestAlertException("A new masPasswordSecretQuestion cannot already have an ID", ENTITY_NAME, "idexists");
        }
        masPasswordSecretQuestionService.save(masPasswordSecretQuestionDTO);
       /* return ResponseEntity.created(new URI("/api/mas-password-secret-questions/" + result.getMasPasswordSecretQuestionId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getMasPasswordSecretQuestionId().toString()))
            .body(result);*/
    }

    /**
     * PUT  /mas-password-secret-questions : Updates an existing masPasswordSecretQuestion.
     *
     * @param masPasswordSecretQuestionDTO the masPasswordSecretQuestionDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masPasswordSecretQuestionDTO,
     * or with status 400 (Bad Request) if the masPasswordSecretQuestionDTO is not valid,
     * or with status 500 (Internal Server Error) if the masPasswordSecretQuestionDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/mas-password-secret-questions")
    public ResponseEntity<MasPasswordSecretQuestion> updateMasPasswordSecretQuestion(@RequestBody MasPasswordSecretQuestion masPasswordSecretQuestionDTO) throws URISyntaxException {
        log.debug("REST request to update MasPasswordSecretQuestionEntity : {}", masPasswordSecretQuestionDTO);
        if (masPasswordSecretQuestionDTO.getMasPasswordSecretQuestionId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasPasswordSecretQuestion result = masPasswordSecretQuestionService.save(masPasswordSecretQuestionDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masPasswordSecretQuestionDTO.getMasPasswordSecretQuestionId().toString()))
            .body(result);
    }

    /**
     * GET  /mas-password-secret-questions : get all the masPasswordSecretQuestions.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masPasswordSecretQuestions in body
     */
    @GetMapping("/mas-password-secret-questions")
    public ResponseEntity<List<MasPasswordSecretQuestion>> getAllMasPasswordSecretQuestions(Pageable pageable) {
        log.debug("REST request to get a page of MasPasswordSecretQuestions");
        Page<MasPasswordSecretQuestion> page = masPasswordSecretQuestionService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-password-secret-questions");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /mas-password-secret-questions/:id : get the "id" masPasswordSecretQuestion.
     *
     * @param id the id of the masPasswordSecretQuestionDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masPasswordSecretQuestionDTO, or with status 404 (Not Found)
     */
    @GetMapping("/mas-password-secret-questions/{id}")
    public ResponseEntity<MasPasswordSecretQuestion> getMasPasswordSecretQuestion(@PathVariable Long id) {
        log.debug("REST request to get MasPasswordSecretQuestionEntity : {}", id);
        Optional<MasPasswordSecretQuestion> masPasswordSecretQuestionDTO = masPasswordSecretQuestionService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masPasswordSecretQuestionDTO);
    }

    /**
     * DELETE  /mas-password-secret-questions/:id : delete the "id" masPasswordSecretQuestion.
     *
     * @param id the id of the masPasswordSecretQuestionDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/mas-password-secret-questions/{id}")
    public ResponseEntity<Void> deleteMasPasswordSecretQuestion(@PathVariable Long id) {
        log.debug("REST request to delete MasPasswordSecretQuestionEntity : {}", id);
        masPasswordSecretQuestionService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
