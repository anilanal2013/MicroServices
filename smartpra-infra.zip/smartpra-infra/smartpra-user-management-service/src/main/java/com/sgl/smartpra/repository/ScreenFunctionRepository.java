package com.sgl.smartpra.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.domain.ScreenFunctionEntity;

@Repository
public interface ScreenFunctionRepository extends JpaRepository<ScreenFunctionEntity, Long> {

	ScreenFunctionEntity findByScreenFunctionName(String functionName);

}
