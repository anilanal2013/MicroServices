package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasUserModuleService;
import com.sgl.smartpra.service.model.MasUserModule;

/**
 * REST controller for managing MasUserModuleEntity.
 */
@RestController
@RequestMapping("/api")
public class MasUserModuleResource {

    private final Logger log = LoggerFactory.getLogger(MasUserModuleResource.class);

    private static final String ENTITY_NAME = "masUserModule";

    private final MasUserModuleService masUserModuleService;

    public MasUserModuleResource(MasUserModuleService masUserModuleService) {
        this.masUserModuleService = masUserModuleService;
    }

    /**
     * POST  /mas-user-modules : Create a new masUserModule.
     *
     * @param masUserModuleDTO the masUserModuleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masUserModuleDTO, or with status 400 (Bad Request) if the masUserModule has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/mas-user-modules")
    public ResponseEntity<MasUserModule> createMasUserModule(@RequestBody MasUserModule masUserModuleDTO) throws URISyntaxException {
        log.debug("REST request to save MasUserModuleEntity : {}", masUserModuleDTO);
        if (masUserModuleDTO.getMasModuleId() != null) {
            throw new BadRequestAlertException("A new masUserModule cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasUserModule result = masUserModuleService.save(masUserModuleDTO);
        return ResponseEntity.created(new URI("/api/mas-user-modules/" + result.getMasModuleId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getMasModuleId().toString()))
            .body(result);
    }

    /**
     * PUT  /mas-user-modules : Updates an existing masUserModule.
     *
     * @param masUserModuleDTO the masUserModuleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masUserModuleDTO,
     * or with status 400 (Bad Request) if the masUserModuleDTO is not valid,
     * or with status 500 (Internal Server Error) if the masUserModuleDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/mas-user-modules")
    public ResponseEntity<MasUserModule> updateMasUserModule(@RequestBody MasUserModule masUserModuleDTO) throws URISyntaxException {
        log.debug("REST request to update MasUserModuleEntity : {}", masUserModuleDTO);
        if (masUserModuleDTO.getMasModuleId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasUserModule result = masUserModuleService.save(masUserModuleDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masUserModuleDTO.getMasModuleId().toString()))
            .body(result);
    }

    /**
     * GET  /mas-user-modules : get all the masUserModules.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masUserModules in body
     */
    @GetMapping("/mas-user-modules")
    public ResponseEntity<List<MasUserModule>> getAllMasUserModules(Pageable pageable) {
        log.debug("REST request to get a page of MasUserModules");
        Page<MasUserModule> page = masUserModuleService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-user-modules");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /mas-user-modules/:id : get the "id" masUserModule.
     *
     * @param id the id of the masUserModuleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masUserModuleDTO, or with status 404 (Not Found)
     */
    @GetMapping("/mas-user-modules/{id}")
    public ResponseEntity<MasUserModule> getMasUserModule(@PathVariable Long id) {
        log.debug("REST request to get MasUserModuleEntity : {}", id);
        Optional<MasUserModule> masUserModuleDTO = masUserModuleService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masUserModuleDTO);
    }

    /**
     * DELETE  /mas-user-modules/:id : delete the "id" masUserModule.
     *
     * @param id the id of the masUserModuleDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/mas-user-modules/{id}")
    public ResponseEntity<Void> deleteMasUserModule(@PathVariable Long id) {
        log.debug("REST request to delete MasUserModuleEntity : {}", id);
        masUserModuleService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
