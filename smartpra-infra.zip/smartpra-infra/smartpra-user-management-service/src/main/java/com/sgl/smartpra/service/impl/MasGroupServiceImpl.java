package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.domain.MasTeamEntity;
import com.sgl.smartpra.domain.MasUsersEntity;
import com.sgl.smartpra.repository.MasTeamRepository;
import com.sgl.smartpra.repository.MasUserRepository;
import com.sgl.smartpra.service.MasGroupService;
import com.sgl.smartpra.domain.MasGroupEntity;
import com.sgl.smartpra.repository.MasGroupRepository;
import com.sgl.smartpra.service.mapper.MasGroupMapper;
import com.sgl.smartpra.service.mapper.MasTeamMapper;
import com.sgl.smartpra.service.mapper.MasUsersMapper;
import com.sgl.smartpra.service.model.MasGroup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Service Implementation for managing MasGroupEntity.
 */
@Service
@Transactional
public class MasGroupServiceImpl implements MasGroupService {

    private final MasTeamRepository masTeamRepository;

    private final MasUserRepository masUserRepository;

    private final Logger log = LoggerFactory.getLogger(MasGroupServiceImpl.class);

    private final MasGroupRepository masGroupRepository;

    private final MasGroupMapper masGroupMapper;

    private final MasTeamMapper masTeamMapper;

    private final MasUsersMapper masUsersMapper;

    public MasGroupServiceImpl(MasGroupRepository masGroupRepository, MasGroupMapper masGroupMapper,
                               MasTeamRepository masTeamRepository, MasUserRepository masUserRepository, MasTeamMapper masTeamMapper, MasUsersMapper masUsersMapper) {
        this.masGroupRepository = masGroupRepository;
        this.masGroupMapper = masGroupMapper;
        this.masTeamRepository = masTeamRepository;
        this.masUserRepository = masUserRepository;
        this.masTeamMapper = masTeamMapper;
        this.masUsersMapper = masUsersMapper;
    }

    /**
     * Save a masGroup.
     *
     * @param masGroupDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasGroup save(MasGroup masGroupDTO) {
        log.debug("Request to save MasGroupEntity : {}", masGroupDTO);
        System.out.println(masGroupDTO.getGroupId()+"=========================================ffffffffffff=============="+masGroupDTO.toString());
        MasGroupEntity masGroup = masGroupMapper.toEntity(masGroupDTO);
        System.out.println("=========================================eeeeeeeeeeeee=============="+masGroup.toString());
        if(masGroupDTO.getGroupId() != null) {
        	System.out.println();
        	masGroup.setGroupId(masGroupDTO.getGroupId());
        }
       masGroup = masGroupRepository.save(masGroup);
        return masGroupMapper.toModel(masGroup);
    }

    /**
     * Get all the masGroups.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasGroup> findAll(Pageable pageable) {
        log.debug("Request to get all MasGroups");
        return masGroupRepository.findAll(pageable)
            .map(masGroupMapper::toModel);
    }


    /**
     * Get one masGroup by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasGroup> findOne(Long id) {
        log.debug("Request to get MasGroupEntity : {}", id);
        return masGroupRepository.findById(id)
            .map(masGroupMapper::toModel);
    }

    /**
     * Delete the masGroup by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasGroupEntity : {}", id);        masGroupRepository.deleteById(id);
    }

    @Override
    public Optional<MasGroup> findMasGroupsById(Long teamId, Long groupId, Long userId) {

        MasGroup masGroup = null;

        if (groupId != null && teamId != null) {
            masGroup = getGroupByGroupIdAndTeamId(groupId, teamId);
        } else if (userId != null) {
            masGroup = getGroupByUserId(userId);
        }

        return Optional.ofNullable(masGroup);
    }

    @Override
    public Optional<List<MasGroup>> findMasGroupTeamByLovId(Integer lovId) {
        List<MasGroup> groupList = new ArrayList<>();
        List<MasGroupEntity> masGroupList = masGroupRepository.findMasGroupEntitiesAndMasTeamsByModuleId(lovId);
        if (masGroupList != null)
            return Optional.ofNullable(masGroupMapper.toModel(masGroupList));
        else
            return Optional.ofNullable(groupList);
    }

    private MasGroup getGroupByGroupIdAndTeamId(Long groupId, Long teamId) {

        MasGroup masGroup ;
        MasGroupEntity masGroupEntity = null;
        MasTeamEntity masTeamEntity;
        List<MasUsersEntity> masUsersEntities = null;

        masTeamEntity = masTeamRepository.findMasTeamEntitiesByTeamId(teamId);

        if (masTeamEntity != null) {
            masGroupEntity = masGroupRepository.findMasGroupEntitiesByGroupId(masTeamEntity.getMasGroup().getGroupId());
        }

        if (masGroupEntity != null && masTeamEntity.getTeamId()!=null) {
            masUsersEntities = masUserRepository.findMasMasUsersEntitysByUserTeamId(Math.toIntExact(masTeamEntity.getTeamId()));
        }

        masGroup = masGroupMapper.toModel(masGroupEntity);
        if (masGroup != null) {
            masGroup.setMasTeam(masTeamMapper.toModel(masTeamEntity));
        }
        if (masGroup != null && masGroup.getMasTeam() != null) {
            masGroup.getMasTeam().setMasUser(masUsersMapper.toModel(masUsersEntities));
        }


        return masGroup;
    }

    private MasGroup getGroupByUserId(Long userId) {

        MasGroup masGroup;
        MasGroupEntity masGroupEntity = null;
        MasUsersEntity masUsersEntity;
        MasTeamEntity masTeamEntity = null;


        masUsersEntity = masUserRepository.findMasUsersEntityByUserId(userId);

        if (masUsersEntity != null) {
            masTeamEntity = masTeamRepository.findMasTeamEntitiesByTeamId(Long.valueOf(masUsersEntity.getUserTeamId()));
        }

        if (masTeamEntity != null ) {
            masGroupEntity = masGroupRepository.findMasGroupEntitiesByGroupId(masTeamEntity.getMasGroup().getGroupId());
        }

        masGroup = masGroupMapper.toModel(masGroupEntity);

        if (masGroup != null) {
            masGroup.setMasTeam(masTeamMapper.toModel(masTeamEntity));
        }

        if (masGroup!=null && masGroup.getMasTeam() != null) {
            masGroup.getMasTeam().setMasUser(Collections.singletonList(masUsersMapper.toModel(masUsersEntity)));
        }


        return masGroup;
    }

    @Override
    public MasGroup findApproverByTeamId(Long teamId) {

        MasGroup masGroup = null;
        MasTeamEntity masTeamEntity = masTeamRepository.findMasTeamEntitiesByTeamId(teamId);

        if (masTeamEntity != null && masTeamEntity.getTeamManagerId() != null) {
            masGroup = getGroupByUserId(Long.parseLong(masTeamEntity.getTeamManagerId().toString()));
        }

        return masGroup;
    }


}
