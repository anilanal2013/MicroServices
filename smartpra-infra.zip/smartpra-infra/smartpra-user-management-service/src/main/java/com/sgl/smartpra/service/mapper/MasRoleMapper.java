package com.sgl.smartpra.service.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.sgl.smartpra.domain.MasRoleEntity;
import com.sgl.smartpra.service.model.MasRole;

/**
 * Mapper for the entity MasRoleEntity and its DTO MasRole.
 */
@Mapper(componentModel = "spring", uses = {})
public interface MasRoleMapper extends EntityMapper<MasRole, MasRoleEntity> {


    @Mapping(target = "masUserRoles", ignore = true)
    MasRoleEntity toEntity(MasRole masRoleDTO);
    
    
    @Mapping(source = "masRole.roleId", target = "roleId")
    MasRole toModel(MasRoleEntity masRole);
    
    List<MasRole> toModel(List<MasRoleEntity> masRole);

    default MasRoleEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasRoleEntity masRole = new MasRoleEntity();
        masRole.setRoleId(id);
        return masRole;
    }
}
