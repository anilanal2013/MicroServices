package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasUserTeamService;
import com.sgl.smartpra.service.model.MasUserTeam;

/**
 * REST controller for managing MasUserTeamEntity.
 */
@RestController
@RequestMapping("/api")
public class MasUserTeamResource {/*

    private final Logger log = LoggerFactory.getLogger(MasUserTeamResource.class);

    private static final String ENTITY_NAME = "masUserTeam";

    private final MasUserTeamService masUserTeamService;

    public MasUserTeamResource(MasUserTeamService masUserTeamService) {
        this.masUserTeamService = masUserTeamService;
    }

    *//**
     * POST  /mas-user-teams : Create a new masUserTeam.
     *
     * @param masUserTeamDTO the masUserTeamDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masUserTeamDTO, or with status 400 (Bad Request) if the masUserTeam has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     *//*
    @PostMapping("/mas-user-teams")
    public ResponseEntity<MasUserTeam> createMasUserTeam(@RequestBody MasUserTeam masUserTeamDTO) throws URISyntaxException {
        log.debug("REST request to save MasUserTeamEntity : {}", masUserTeamDTO);
        if (masUserTeamDTO.getMasUserTeamId() != null) {
            throw new BadRequestAlertException("A new masUserTeam cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasUserTeam result = masUserTeamService.save(masUserTeamDTO);
        return ResponseEntity.created(new URI("/api/mas-user-teams/" + result.getMasUserTeamId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getMasUserTeamId().toString()))
            .body(result);
    }

    *//**
     * PUT  /mas-user-teams : Updates an existing masUserTeam.
     *
     * @param masUserTeamDTO the masUserTeamDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masUserTeamDTO,
     * or with status 400 (Bad Request) if the masUserTeamDTO is not valid,
     * or with status 500 (Internal Server Error) if the masUserTeamDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     *//*
    @PutMapping("/mas-user-teams")
    public ResponseEntity<MasUserTeam> updateMasUserTeam(@RequestBody MasUserTeam masUserTeamDTO) throws URISyntaxException {
        log.debug("REST request to update MasUserTeamEntity : {}", masUserTeamDTO);
        if (masUserTeamDTO.getMasUserTeamId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasUserTeam result = masUserTeamService.save(masUserTeamDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masUserTeamDTO.getMasUserTeamId().toString()))
            .body(result);
    }

    *//**
     * GET  /mas-user-teams : get all the masUserTeams.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of masUserTeams in body
     *//*
    @GetMapping("/mas-user-teams")
    public ResponseEntity<List<MasUserTeam>> getAllMasUserTeams(Pageable pageable) {
        log.debug("REST request to get a page of MasUserTeams");
        Page<MasUserTeam> page = masUserTeamService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/mas-user-teams");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    *//**
     * GET  /mas-user-teams/:id : get the "id" masUserTeam.
     *
     * @param id the id of the masUserTeamDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masUserTeamDTO, or with status 404 (Not Found)
     *//*
    @GetMapping("/mas-user-teams/{id}")
    public ResponseEntity<MasUserTeam> getMasUserTeam(@PathVariable Long id) {
        log.debug("REST request to get MasUserTeamEntity : {}", id);
        Optional<MasUserTeam> masUserTeamDTO = masUserTeamService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masUserTeamDTO);
    }

    *//**
     * DELETE  /mas-user-teams/:id : delete the "id" masUserTeam.
     *
     * @param id the id of the masUserTeamDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     *//*
    @DeleteMapping("/mas-user-teams/{id}")
    public ResponseEntity<Void> deleteMasUserTeam(@PathVariable Long id) {
        log.debug("REST request to delete MasUserTeamEntity : {}", id);
        masUserTeamService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
*/}
