package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.User2faLogin;

import java.util.Optional;

/**
 * Service Interface for managing User2faLoginEntity.
 */
public interface User2faLoginService {

    /**
     * Save a user2faLogin.
     *
     * @param user2faLoginDTO the entity to save
     * @return the persisted entity
     */
    User2faLogin save(User2faLogin user2faLoginDTO);

    /**
     * Get all the user2faLogins.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<User2faLogin> findAll(Pageable pageable);


    /**
     * Get the "id" user2faLogin.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<User2faLogin> findOne(Long id);

    /**
     * Delete the "id" user2faLogin.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
