package com.sgl.smartpra.service;

import java.util.List;

import com.sgl.smartpra.service.model.Action;
import com.sgl.smartpra.service.model.FunctionDetail;
import com.sgl.smartpra.service.model.MasRoleFunction;
import com.sgl.smartpra.service.model.ScreenFunction;

public interface MasRoleFunctionService {

	List<FunctionDetail> getRolesAndPrevillages(String role, List<Long> screenId);

	List<MasRoleFunction> updateMasRoleFunction(List<MasRoleFunction> masRoleFun);

	List<MasRoleFunction> saveMasRoleFunction(List<MasRoleFunction> masRoleFun);

	List<MasRoleFunction> saveRoleFunctions(List<FunctionDetail> functionDetails, String role);
	
	List<ScreenFunction> getScreenFunction();
	
	List<Action> getAction();
	
	void deleteRoleFunctions(List<FunctionDetail> functionDetails, String role);

}
