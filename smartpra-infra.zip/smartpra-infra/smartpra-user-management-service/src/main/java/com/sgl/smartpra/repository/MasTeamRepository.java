package com.sgl.smartpra.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.domain.MasGroupEntity;
import com.sgl.smartpra.domain.MasTeamEntity;


/**
 * Spring Data  repository for the MasTeamEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MasTeamRepository extends JpaRepository<MasTeamEntity, Long> {

	List<MasTeamEntity> findAllByMasGroup(MasGroupEntity masGroup);

	MasTeamEntity findMasTeamEntitiesByTeamId(Long teamId);

	MasTeamEntity findMasTeamEntityByTeamManagerId(Long teamId);

}
