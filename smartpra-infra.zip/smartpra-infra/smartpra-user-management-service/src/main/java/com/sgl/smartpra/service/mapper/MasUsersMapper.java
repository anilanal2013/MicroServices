package com.sgl.smartpra.service.mapper;

import java.util.HashSet;
import java.util.Set;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;

import com.sgl.smartpra.domain.MasUserRoleEntity;
import com.sgl.smartpra.domain.MasUsersEntity;
import com.sgl.smartpra.service.model.MasUsers;

/**
 * Mapper for the entity MasUsersEntity and its DTO MasUsers.
 */
@Mapper(componentModel = "spring", uses = {MasUserPasswordMapper.class,MasUserRoleMapper.class,MasUserGroupMapper.class,MasUserTeamMapper.class})
public interface MasUsersMapper extends EntityMapper<MasUsers, MasUsersEntity> {

	 @Mappings({@Mapping(source = "masUsers.userId", target = "masUsersId"),
    @Mapping(source = "masUserRoles", target = "roleIds", qualifiedByName = "myTransformation")})
    MasUsers toModel(MasUsersEntity masUsers);

   @Mappings({ @Mapping(source = "masUsersId", target = "masUserPassword"),
    @Mapping(target = "masUserLogins", ignore = true),
    @Mapping(target = "userLoginSessionCurrentDaies", ignore = true),
    @Mapping(target = "masPasswordSecretQuestions", ignore = true),
    @Mapping(target = "masUserRoles", ignore = true),
    @Mapping(target = "masUserGroups", ignore = true),
   // @Mapping(target = "userPasswordHistories", ignore = true),
    @Mapping(target = "masUserTeams", ignore = true),
 //   @Mapping(target = "user2faLogins", ignore = true),
    @Mapping(target = "masUserModules", ignore = true)})
    MasUsersEntity toEntity(MasUsers masUsersDTO);

    default MasUsersEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasUsersEntity masUsers = new MasUsersEntity();
        masUsers.setUserId(id);
        return masUsers;
    }
    
    @Named("myTransformation")
    default Set<Long> myCustomTransformation(Set<MasUserRoleEntity> obj) {
    	Set<Long> roleIds = new HashSet<>();
    	for(MasUserRoleEntity masRole : obj) {
    		if(masRole.getIsActive()) {
    			roleIds.add(masRole.getMasRole().getRoleId());
    		}
    	}
    	return roleIds;
    }
}
