package com.sgl.smartpra.controller;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.error.EmailAlreadyUsedException;
import com.sgl.smartpra.controller.error.LoginAlreadyUsedException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.domain.MasUsersEntity;
import com.sgl.smartpra.repository.MasUserRepository;
import com.sgl.smartpra.security.AuthoritiesConstants;
import com.sgl.smartpra.security.SecurityUtils;
import com.sgl.smartpra.security.listener.ProfileRegistrationCompleteEvent;
import com.sgl.smartpra.service.MasUserService;
import com.sgl.smartpra.service.UserPasswordHistoryService;
import com.sgl.smartpra.service.impl.MailService;
import com.sgl.smartpra.service.mapper.MasUsersMapper;
import com.sgl.smartpra.service.model.MasUser;
import com.sgl.smartpra.service.model.MasUsers;
import com.sgl.smartpra.service.model.UserDetail;
import com.sgl.smartpra.service.model.UserIdAndName;
import com.sgl.smartpra.util.Constants;

@RestController
@RequestMapping("/api")
public class UserResource {

	private final Logger log = LoggerFactory.getLogger(UserResource.class);

	private final MasUserService userService;

	private final MasUserRepository userRepository;

	@Autowired
	private ApplicationEventPublisher eventPublisher;

	@Autowired
	private HttpServletRequest httpServletRequest;

	@Autowired
	MasUsersMapper masUsersMapper;
	public UserResource(MasUserService userService, MasUserRepository userRepository, MailService mailService,
			UserPasswordHistoryService userPasswordHistoryService) {

		this.userService = userService;
		this.userRepository = userRepository;
	}

	/**
	 * POST /users : Creates a new user.
	 * <p>
	 * Creates a new user if the login and email are not already used, and sends an
	 * mail with an activation link. The user needs to be activated on creation.
	 *
	 * @param userDTO the user to create
	 * @return the ResponseEntity with status 201 (Created) and with body the new
	 *         user, or with status 400 (Bad Request) if the login or email is
	 *         already in use
	 * @throws URISyntaxException       if the Location URI syntax is incorrect
	 * @throws BadRequestAlertException 400 (Bad Request) if the login or email is
	 *                                  already in use
	 */
	//@PostMapping( consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},path="/users",headers = {"content-type=multipart/form-data"}, produces=MediaType.APPLICATION_JSON_VALUE)
	@PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
	@PostMapping(path="/users",consumes = MediaType.APPLICATION_JSON_VALUE)
	public MasUsersEntity createUser(@Valid @RequestBody MasUsers userDTO) throws URISyntaxException {
		log.debug("REST request to save User : {}", userDTO);

		if (userDTO.getMasUsersId() != null && userDTO.getMasUsersId() > 0) {
			throw new BadRequestAlertException("A new user cannot already have an ID", "userManagement", "idexists");
		} else if (userRepository.findOneByUserName(userDTO.getUserName().toLowerCase()).isPresent()) {
			throw new BadRequestAlertException("A new user cannot already have an User name", "userManagement", "idexists");
		} else if (userRepository.findOneByEmailIgnoreCase(userDTO.getEmail()).isPresent()) {
			throw new EmailAlreadyUsedException();
		} else {
			MasUsersEntity newUser = userService.createUser(userDTO);
		//	mailService.sendCreationEmail(newUser);
			
			 try {
					eventPublisher.publishEvent(new ProfileRegistrationCompleteEvent(newUser, httpServletRequest.getLocale(), getAppUrl(httpServletRequest)));
				} catch (Exception e) {
				
				}
		return newUser;
		}
	}

	/**
	 * PUT /users : Updates an existing User.
	 *
	 * @param userDTO the user to update
	 * @return the ResponseEntity with status 200 (OK) and with body the updated
	 *         user
	 * @throws EmailAlreadyUsedException 400 (Bad Request) if the email is already
	 *                                   in use
	 * @throws LoginAlreadyUsedException 400 (Bad Request) if the login is already
	 *                                   in use
	 */
	@PutMapping("/users")
	@PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
	public ResponseEntity<MasUsers> updateUser(@Valid @RequestBody MasUsers userDTO) {
		log.debug("REST request to update User : {}", userDTO);
		Optional<MasUsersEntity> existingUser = userRepository.findOneByEmailIgnoreCase(userDTO.getEmail());
		if (existingUser.isPresent() && (!existingUser.get().getUserId().equals(userDTO.getMasUsersId()))) {
			throw new EmailAlreadyUsedException();
		}
		existingUser = userRepository.findOneByUserName(userDTO.getUserName().toLowerCase());
		if (existingUser.isPresent() && (!existingUser.get().getUserId().equals(userDTO.getMasUsersId()))) {
			throw new LoginAlreadyUsedException();
		}
		Optional<MasUsers> updatedUser = userService.updateUser(userDTO);

		return ResponseUtil.wrapOrNotFound(updatedUser,
				HeaderUtil.createAlert("userManagement.updated", userDTO.getUserName()));
	}

	/**
	 * GET /users : get all users.
	 *
	 * @param pageable the pagination information
	 * @return the ResponseEntity with status 200 (OK) and with body all users
	 */
	@GetMapping("/users")
	public ResponseEntity<List<MasUsers>> getAllUsers(Pageable pageable) {
		final List<MasUsers> page = userService.getAllManagedUsers();
		return new ResponseEntity<>(page, HttpStatus.OK);
	}
	
	@GetMapping("/users/role/{roleName}")
	public List<MasUsers> getUsersByRole(@PathVariable String roleName){
		return userService.getAllUsersByRoleName(roleName);
	}
	


	/**
	 * GET /users/:login : get the "login" user.
	 *
	 * @param login the login of the user to find
	 * @return the ResponseEntity with status 200 (OK) and with body the "login"
	 *         user, or with status 404 (Not Found)
	 */
	@GetMapping("/users/login/{login:" + Constants.LOGIN_REGEX + "}")
	public ResponseEntity<MasUser> getUser(@PathVariable String login) {
		log.debug("REST request to get User : {}", login);
		return ResponseUtil.wrapOrNotFound(userService.getUserWithAuthoritiesByLogin(login).map(MasUser::new));
	}

	/**
	 * DELETE /users/:login : delete the "login" User.
	 *
	 * @param login the login of the user to delete
	 * @return the ResponseEntity with status 200 (OK)
	 */
	@DeleteMapping("/users/{login:" + Constants.LOGIN_REGEX + "}")
	@PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
	public ResponseEntity<Void> deleteUser(@PathVariable String login) {
		log.debug("REST request to delete User: {}", login);
		userService.deleteUser(login);
		return ResponseEntity.ok().headers(HeaderUtil.createAlert("userManagement.deleted", login)).build();
	}
	
	@DeleteMapping("/users/{userId}")
	//@PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
	public ResponseEntity<Void> deleteUserById(@PathVariable Integer userId) {
		log.debug("REST request to delete User: {}", userId);
		userService.deleteUserById(userId);
		return ResponseEntity.ok().build();
	}
	
	
	
	@PutMapping("/users/activateordeactivate/{login:" + Constants.LOGIN_REGEX + "}")
	@PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
	public ResponseEntity<Void> userActivateOrDeactivate(@PathVariable String login){
		
		log.debug("REST request to ActivateOrDeactivate User: {}", login);
		userService.acivateOrDeactivateUser(login);
		return ResponseEntity.ok().headers(HeaderUtil.createAlert("userManagement.updated", login)).build();
		}
	
	
	/**
	 * GET /users/:login : get the "login" user.
	 *
	 * @param login the login of the user to find
	 * @return the ResponseEntity with status 200 (OK) and with body the "login"
	 *         user, or with status 404 (Not Found)
	 */
	@PostMapping("/users/email/{email}")
	public Optional<MasUsers> getUserByEmail(@RequestBody MasUsers userDTO) {
		log.debug("REST request to get User by email: {}", userDTO.getEmail());
		return userService.getUserByEmail(userDTO.getEmail());
	}
    
	/**
	 * GET /users/:login : get the "login" user.
	 *
	 * @param login the login of the user to find
	 * @return the ResponseEntity with status 200 (OK) and with body the "login"
	 *         user, or with status 404 (Not Found)
	 */
	@GetMapping("/users/userId/{userId}")
	public ResponseEntity<MasUsers> getUserById(@PathVariable Long userId) {
		log.debug("REST request to get User by user id: {}", userId);
		return ResponseUtil.wrapOrNotFound(userService.getUserByUserId(userId));
	}
	
	@PostMapping("/users/search")
	public List<MasUsers>searcUsers(@RequestBody MasUsers userDTO) {
		log.debug("REST request to serach User : {}", userDTO.getEmail());
		List<MasUsers> users = userService.searchUsers(userDTO);
		return users;
	}

	@GetMapping("/user/team/{teamId}")
	public List<UserIdAndName> getUserByTeamId(@PathVariable Integer teamId) {
		log.debug("REST request to get User by team id: {}", teamId);
		return userService.getUsersByTeamId(teamId);
	}

	@GetMapping("/user/userid")
	public Long getUserByNameOrEmail(@RequestParam("name") String user) {
		log.debug("REST request to get User by name or mail: {}", user);
		return userService.getUserByNameOrEmail(user);
	}


	private String getAppUrl(HttpServletRequest request) {
        return "http://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
    }
	
	/**
	 * Service to fetch user screen function and action
	 * 
	 * @return list of {@code FunctionDetail}
	 */
	@GetMapping("/userFunctionDetail")
	public UserDetail getUser() {
		Optional<String> currentUserLogin = SecurityUtils.getCurrentUserLogin();
		if (currentUserLogin.isPresent()) {
			return userService.getFunctionDetails(currentUserLogin.get());
		}
		return new UserDetail();
	}
}
	 


	