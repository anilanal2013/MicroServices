package com.sgl.smartpra.service;

import com.sgl.smartpra.domain.UserPasswordHistoryEntity;
import com.sgl.smartpra.service.model.UserPasswordHistory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

/**
 * Service Interface for managing UserPasswordHistoryEntity.
 */
public interface UserPasswordHistoryService {

    /**
     * Save a userPasswordHistory.
     *
     * @param userPasswordHistoryDTO the entity to save
     * @return the persisted entity
     */
    UserPasswordHistory save(UserPasswordHistory userPasswordHistoryDTO);

    /**
     * Get all the userPasswordHistories.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<UserPasswordHistory> findAll(Pageable pageable);


    /**
     * Get the "id" userPasswordHistory.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<UserPasswordHistory> findOne(Long id);

    /**
     * Delete the "id" userPasswordHistory.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
    
    UserPasswordHistory save(UserPasswordHistoryEntity userPasswordHistory);
}
