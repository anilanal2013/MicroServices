package com.sgl.smartpra.security;

/**
 * Constants for Spring Security authorities.
 */
public final class AuthoritiesConstants {

    public static final String ADMIN = "ADMIN";

    public static final String USER = "USER";

    public static final String ANONYMOUS = "ANONYMOUS";
    
    public static final String GUEST = "GUEST";

    private AuthoritiesConstants() {
    }
}
