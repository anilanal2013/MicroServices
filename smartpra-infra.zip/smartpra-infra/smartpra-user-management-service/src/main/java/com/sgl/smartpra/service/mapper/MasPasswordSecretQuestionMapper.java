package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasPasswordSecretQuestion;

import org.mapstruct.*;

/**
 * Mapper for the entity MasPasswordSecretQuestionEntity and its DTO MasPasswordSecretQuestion.
 */
@Mapper(componentModel = "spring", uses = {MasUsersMapper.class})
public interface MasPasswordSecretQuestionMapper extends EntityMapper<MasPasswordSecretQuestion, MasPasswordSecretQuestionEntity> {

    @Mapping(source = "masUsers.userId", target = "masUsersId")
    MasPasswordSecretQuestion toModel(MasPasswordSecretQuestionEntity masPasswordSecretQuestion);

    @Mapping(source = "masUsersId", target = "masUsers")
    MasPasswordSecretQuestionEntity toEntity(MasPasswordSecretQuestion masPasswordSecretQuestionDTO);

    default MasPasswordSecretQuestionEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasPasswordSecretQuestionEntity masPasswordSecretQuestion = new MasPasswordSecretQuestionEntity();
        masPasswordSecretQuestion.setPasswordQuestId(id);
        return masPasswordSecretQuestion;
    }
}
