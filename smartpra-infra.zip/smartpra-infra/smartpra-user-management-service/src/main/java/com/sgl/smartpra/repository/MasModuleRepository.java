package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.MasModuleEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the MasModuleEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MasModuleRepository extends JpaRepository<MasModuleEntity, Long> {

}
