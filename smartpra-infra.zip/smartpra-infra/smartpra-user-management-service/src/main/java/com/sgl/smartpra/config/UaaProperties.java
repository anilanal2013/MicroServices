package com.sgl.smartpra.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Properties for UAA-based OAuth2 security.
 */
@Component
@ConfigurationProperties(prefix = "uaa", ignoreUnknownFields = false)
public class UaaProperties {
 

    private WebClientConfiguration webClientConfiguration = new WebClientConfiguration();

    public WebClientConfiguration getWebClientConfiguration() {
        return webClientConfiguration;
    }

   
    public static class WebClientConfiguration {

    	private int accessTokenValidityInSec = 5 * 60;
    	private int refreshTokenValidityInSec;
        private int refreshTokenValidityInSecondsForRememberMe = 7 * 24 * 60 * 60;
        private String clientId = "web_app";
        private String secret = "changeit";
        private String grantTypePassword;
        private String authorizationCode;
        private String refreshToken;
        private String implicit;
        private String scopeRead;
        private String scopeWrite;
        private String trust;
        private String signInKey;

      
    }
}
