package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.UserLoginSessionCurrentDay;

import org.mapstruct.*;

/**
 * Mapper for the entity UserLoginSessionCurrentDayEntity and its DTO UserLoginSessionCurrentDay.
 */
@Mapper(componentModel = "spring", uses = {MasUsersMapper.class})
public interface UserLoginSessionCurrentDayMapper extends EntityMapper<UserLoginSessionCurrentDay, UserLoginSessionCurrentDayEntity> {

    @Mapping(source = "masUsers.userId", target = "masUsersId")
    UserLoginSessionCurrentDay toModel(UserLoginSessionCurrentDayEntity userLoginSessionCurrentDay);

    @Mapping(source = "masUsersId", target = "masUsers")
    UserLoginSessionCurrentDayEntity toEntity(UserLoginSessionCurrentDay userLoginSessionCurrentDayDTO);

    default UserLoginSessionCurrentDayEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        UserLoginSessionCurrentDayEntity userLoginSessionCurrentDay = new UserLoginSessionCurrentDayEntity();
        userLoginSessionCurrentDay.setUserCurrSessionId(id);
        return userLoginSessionCurrentDay;
    }
}
