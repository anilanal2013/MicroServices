package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasGroup;
import com.sgl.smartpra.service.model.MasRole;

import org.mapstruct.*;

/**
 * Mapper for the entity MasGroupEntity and its DTO MasGroup.
 */
@Mapper(componentModel = "spring", uses = {})
public interface MasGroupMapper extends EntityMapper<MasGroup, MasGroupEntity> {

	@Mapping(target = "masUserGroups", ignore = true)
	MasGroupEntity toEntity(MasGroup masGroupDTO);

	@Mapping(source = "masGroup.groupId", target = "groupId")
	MasGroup toModel(MasGroupEntity masGroup);

	default MasGroupEntity fromId(Long id) {
		if (id == null) {
			return null;
		}
		MasGroupEntity masGroup = new MasGroupEntity();
		masGroup.setGroupId(id);
		return masGroup;
	}
}
