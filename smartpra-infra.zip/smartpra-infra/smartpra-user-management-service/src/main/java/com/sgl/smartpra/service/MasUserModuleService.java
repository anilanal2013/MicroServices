package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasUserModule;

import java.util.Optional;

/**
 * Service Interface for managing MasUserModuleEntity.
 */
public interface MasUserModuleService {

    /**
     * Save a masUserModule.
     *
     * @param masUserModuleDTO the entity to save
     * @return the persisted entity
     */
    MasUserModule save(MasUserModule masUserModuleDTO);

    /**
     * Get all the masUserModules.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasUserModule> findAll(Pageable pageable);


    /**
     * Get the "id" masUserModule.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasUserModule> findOne(Long id);

    /**
     * Delete the "id" masUserModule.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
