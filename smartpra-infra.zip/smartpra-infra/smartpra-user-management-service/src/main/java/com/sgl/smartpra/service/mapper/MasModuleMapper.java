package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasModule;

import org.mapstruct.*;

/**
 * Mapper for the entity MasModuleEntity and its DTO MasModule.
 */
@Mapper(componentModel = "spring", uses = {})
public interface MasModuleMapper extends EntityMapper<MasModule, MasModuleEntity> {


    @Mapping(target = "masUserModules", ignore = true)
    MasModuleEntity toEntity(MasModule masModuleDTO);
    
    @Mapping(source = "masModule.moduleId", target = "masModuleId")
    MasModule toModel(MasModuleEntity masModule);

    default MasModuleEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasModuleEntity masModule = new MasModuleEntity();
        masModule.setModuleId(id);
        return masModule;
    }
}
