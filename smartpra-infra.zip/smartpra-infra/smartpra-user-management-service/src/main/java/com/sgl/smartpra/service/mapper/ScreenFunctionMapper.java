package com.sgl.smartpra.service.mapper;

import org.mapstruct.Mapper;

import com.sgl.smartpra.domain.ScreenFunctionEntity;
import com.sgl.smartpra.service.model.ScreenFunction;

@Mapper(componentModel = "spring", uses = {})

public interface ScreenFunctionMapper extends EntityMapper<ScreenFunction, ScreenFunctionEntity> {

	default ScreenFunctionEntity fromId(Long id) {
		if (id == null) {
			return null;
		}
		ScreenFunctionEntity screenFunctionEntity = new ScreenFunctionEntity();
		screenFunctionEntity.setScreenFunctionId(id);
		return screenFunctionEntity;
	}
}
