package com.sgl.smartpra.controller;




import java.io.IOException;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.sgl.smartpra.controller.error.EmailAlreadyUsedException;
import com.sgl.smartpra.controller.error.EmailNotFoundException;
import com.sgl.smartpra.controller.error.InternalServerErrorException;
import com.sgl.smartpra.controller.error.InvalidPasswordException;
import com.sgl.smartpra.controller.error.LoginAlreadyUsedException;
import com.sgl.smartpra.controller.vm.KeyAndPasswordVM;
import com.sgl.smartpra.domain.MasUsersEntity;
import com.sgl.smartpra.repository.MasUserRepository;
import com.sgl.smartpra.security.SecurityUtils;
import com.sgl.smartpra.security.listener.ProfileActivationEvent;
import com.sgl.smartpra.security.listener.ProfileRegistrationCompleteEvent;
import com.sgl.smartpra.security.listener.ResetPasswordEvent;
import com.sgl.smartpra.service.MasUserService;
import com.sgl.smartpra.service.impl.MailService;
import com.sgl.smartpra.service.model.MasUser;
import com.sgl.smartpra.service.model.MasUserPassword;
import com.sgl.smartpra.service.model.MasUsers;
import com.sgl.smartpra.service.model.PasswordChange;

/**
 * REST controller for managing the current user's account.
 */
@RestController
@RequestMapping("/api")
public class ProfileResource {

	private final Logger log = LoggerFactory.getLogger(ProfileResource.class);


	@Autowired
	private ApplicationEventPublisher eventPublisher;

	@Autowired
	private HttpServletRequest httpServletRequest;

	private final MasUserService userService;

	private final MailService mailService;
	
	private final MasUserRepository userRepository;
	
	@Autowired
	PasswordEncoder passwordEncoder;

	public ProfileResource(MasUserRepository userRepository, MasUserService userService, MailService mailService) {

		this.userRepository = userRepository;
		this.userService = userService;
		this.mailService = mailService;
	}
 

	/**
     * POST  /register : register the user.
     *
     * @param managedUserVM the managed user View Model
     * @throws InvalidPasswordException 400 (Bad Request) if the password is incorrect
     * @throws EmailAlreadyUsedException 400 (Bad Request) if the email is already used
     * @throws LoginAlreadyUsedException 400 (Bad Request) if the login is already used
     */
    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
	public void registerAccount(@Valid @RequestBody MasUsers masUserDTO) {

    	try {
			MasUsersEntity user = userService.registerUser(masUserDTO, masUserDTO.getPasswordHash());
			eventPublisher.publishEvent(new ProfileRegistrationCompleteEvent(user, httpServletRequest.getLocale(), getAppUrl(httpServletRequest)));
		} catch (Exception e) {
			log.error("User register Failed :: {}", e);
		}

	}

    /**
     * GET  /activate : activate the registered user.
     *
     * @param key the activation key
     * @throws RuntimeException 500 (Internal Server Error) if the user couldn't be activated
     */
    @GetMapping("/activate")
    public void activateAccount(@RequestParam(value = "key") String key) {
        Optional<MasUsersEntity> user = userService.activateRegistration(key);
        if (!user.isPresent()) {
            throw new InternalServerErrorException("No user was found for this activation key");
        }else{
        	eventPublisher.publishEvent(new ProfileActivationEvent(user.get()));
        }
    }

    /**
     * GET  /authenticate : check if the user is authenticated, and return its login.
     *
     * @param request the HTTP request
     * @return the login if the user is authenticated
     */
    @GetMapping("/authenticate")
    public String isAuthenticated(HttpServletRequest request) {
        log.debug("REST request to check if the current user is authenticated");
        return request.getRemoteUser();
    }


    /**
     * POST  /profile : update the current user information.
     *
     * @param userDTO the current user information
     * @throws EmailAlreadyUsedException 400 (Bad Request) if the email is already used
     * @throws RuntimeException 500 (Internal Server Error) if the user login wasn't found
     */
    @PostMapping("/profile")
    public void saveAccount(@Valid @RequestBody MasUser userDTO) {
        String userLogin = SecurityUtils.getCurrentUserLogin().orElseThrow(() -> new InternalServerErrorException("Current user login not found"));
        Optional<MasUsersEntity> existingUser = userRepository.findOneByEmailIgnoreCase(userDTO.getEmail());
        if (existingUser.isPresent() && (!existingUser.get().getEmail().equalsIgnoreCase(userLogin))) {
            throw new EmailAlreadyUsedException();
        }
        Optional<MasUsersEntity> user = userRepository.findOneByEmailIgnoreCase(userLogin);
        if (!user.isPresent()) {
            throw new InternalServerErrorException("User could not be found");
        }
        userService.updateUser(userDTO.getFirstName(), userDTO.getLastName(), userDTO.getEmail(),
            userDTO.getLangKey());
    }

    /**
     * POST  /profile/change-password : changes the current user's password
     *
     * @param passwordChangeDto current and new password
     * @throws InvalidPasswordException 400 (Bad Request) if the new password is incorrect
     */
    @PostMapping(path = "/profile/change-password")
    public void changePassword(@RequestBody PasswordChange passwordChangeDto) {
        if (!checkPasswordLength(passwordChangeDto.getNewPassword())) {
            throw new InvalidPasswordException();
        }
        	 
        userService.changePassword(passwordChangeDto.getCurrentPassword(), passwordChangeDto.getNewPassword());
        
        String userLogin = SecurityUtils.getCurrentUserLogin().orElseThrow(() -> new InternalServerErrorException("Current user login not found"));
        Optional<MasUsersEntity> existingUser = userRepository.findOneByEmailIgnoreCase(userLogin);
		if (existingUser.isPresent()) {
			eventPublisher.publishEvent(new ResetPasswordEvent(existingUser.get(),
					passwordEncoder.encode(passwordChangeDto.getNewPassword())));
		}
    }

    /**
     * POST   /profile/reset-password/init : Send an email to reset the password of the user
     *
     * @param mail the mail of the user
     * @throws EmailNotFoundException 400 (Bad Request) if the email address is not registered
     */
    @PostMapping(path = "/profile/reset-password/init")
    public void requestPasswordReset(@RequestBody MasUser masUserDTO) {
    	String mail = masUserDTO.getEmail();
       mailService.sendPasswordResetMail(
           userService.requestPasswordReset(mail)
               .orElseThrow(EmailNotFoundException::new)
       );
    }
    
   
    @PostMapping(path = "/profile/request-username/init")
    public void requestForgetUserName(@RequestBody MasUser masUserDTO) {
    	String mail = masUserDTO.getEmail();
    	mailService.sendForgetUserNameMail(
           userService.requestUserName(mail)
               .orElseThrow(EmailNotFoundException::new)
       );
    }
    
    @PostMapping(path = "/profile/firsttime-password/init")
    public void requestFirstTimePasswordReset(@RequestBody KeyAndPasswordVM keyAndPassword) {
    	
    	userService.setFirstTimePassword(keyAndPassword.getMail(), keyAndPassword.getPassword());
    }

    /**
     * POST   /profile/reset-password/finish : Finish to reset the password of the user
     *
     * @param keyAndPassword the generated key and the new password
     * @throws InvalidPasswordException 400 (Bad Request) if the password is incorrect
     * @throws RuntimeException 500 (Internal Server Error) if the password could not be reset
     */
    @PostMapping(path = "/profile/reset-password/finish")
    public void finishPasswordReset(@RequestBody KeyAndPasswordVM keyAndPassword) {
        if (!checkPasswordLength(keyAndPassword.getNewPassword())) {
            throw new InvalidPasswordException();
        }
        Optional<MasUsersEntity> user =
            userService.completePasswordReset(keyAndPassword.getNewPassword(), keyAndPassword.getKey());

        if (!user.isPresent()) {
            throw new InternalServerErrorException("No user was found for this reset key");
        }else {
        	
        	eventPublisher.publishEvent(new ResetPasswordEvent(user.get(),passwordEncoder.encode(keyAndPassword.getNewPassword())));
        }
    }

    
	@PostMapping("/profile/user-import")
	public void bulkUserUpload(@RequestParam("file") MultipartFile userDataFile) throws IOException {
		
		XSSFWorkbook workbook = new XSSFWorkbook(userDataFile.getInputStream());
		XSSFSheet worksheet = workbook.getSheetAt(0);
		
		 for (int i = 1; i < worksheet.getPhysicalNumberOfRows(); i++) {
			 MasUsers  masusers = new MasUsers();
			 XSSFRow row =  worksheet.getRow(i);
			 if(row.getCell(0) != null) {
			 masusers.setCategoryLevel(row.getCell(0).getStringCellValue());
			 }
			 if(row.getCell(1) != null) {
			 masusers.setDisplayName(row.getCell(1).getStringCellValue());
			 }
			 if(row.getCell(2) != null) {
			 masusers.setEmail(row.getCell(2).getStringCellValue());
			 }
			 if(row.getCell(3) != null) {
			 masusers.setFirstName(row.getCell(3).getStringCellValue());
			 }
			 if(row.getCell(4) != null) {
				 masusers.setInstantOfJoining(row.getCell(4).getDateCellValue().toInstant());
			 }
			 if(row.getCell(5) != null) {
			 masusers.setLangKey(row.getCell(5).getStringCellValue());
			 }
			 if(row.getCell(6) != null) {
			 masusers.setLastName(row.getCell(6).getStringCellValue());
			 }
			 if(row.getCell(7) != null) {
			 masusers.setMiddleName(row.getCell(7).getStringCellValue());
			 }
			 if(row.getCell(8) != null) {
			 masusers.setPreferredLanguage(row.getCell(8).getStringCellValue());
			 }
			 if(row.getCell(9) != null) {
			 masusers.setProcessName(row.getCell(9).getStringCellValue());
			 }
			 if(row.getCell(10) != null) {
				 masusers.setShiftStartTime(row.getCell(10).getDateCellValue().toInstant());
			 }
			 if(row.getCell(11) != null) {
				 masusers.setShiftEndTime(row.getCell(11).getDateCellValue().toInstant());
			 }
			 if(row.getCell(12) != null) {
			 masusers.setUserAddress1(row.getCell(12).getStringCellValue());
			 }
			 if(row.getCell(13) != null) {
			 masusers.setUserAddress2(row.getCell(13).getStringCellValue());
			 }
			 if(row.getCell(14) != null) {
			 masusers.setUserAddress3(row.getCell(14).getStringCellValue());
			 }
			 if(row.getCell(15) != null) {
			 masusers.setUserEmail(row.getCell(15).getStringCellValue());
			 }
			 if(row.getCell(16) != null) {
			 masusers.setUserFullName(row.getCell(16).getStringCellValue());
			 }
			 if(row.getCell(17) != null) {
			 masusers.setUserName(row.getCell(17).getStringCellValue());
			 }
			 if(row.getCell(18) != null) {
			 masusers.setUserRemarks(row.getCell(18).getStringCellValue());
			 }
			 if(row.getCell(19) != null) {
			 masusers.setUserTelephone(String.valueOf(row.getCell(19).getNumericCellValue()));
			 }
			 MasUsersEntity user = userService.registerUser(masusers, masusers.getPasswordHash());
			 try {
				eventPublisher.publishEvent(new ProfileRegistrationCompleteEvent(user, httpServletRequest.getLocale(), getAppUrl(httpServletRequest)));
			} catch (Exception e) {
				log.error("Event publishing Failed :: {}", e);
			}
		 }
	}
    
    
    private static boolean checkPasswordLength(String password) {
        return !StringUtils.isEmpty(password) &&
            password.length() >= MasUserPassword.PASSWORD_MIN_LENGTH &&
            password.length() <= MasUserPassword.PASSWORD_MAX_LENGTH;
    }
    
    private String getAppUrl(HttpServletRequest request) {
        return "http://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
    }
}
