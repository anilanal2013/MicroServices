package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.MasUserRoleService;
import com.sgl.smartpra.domain.MasUserRoleEntity;
import com.sgl.smartpra.repository.MasUserRoleRepository;
import com.sgl.smartpra.service.mapper.MasUserRoleMapper;
import com.sgl.smartpra.service.model.MasUserRole;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing MasUserRoleEntity.
 */
@Service
@Transactional
public class MasUserRoleServiceImpl implements MasUserRoleService {

    private final Logger log = LoggerFactory.getLogger(MasUserRoleServiceImpl.class);

    private final MasUserRoleRepository masUserRoleRepository;

    private final MasUserRoleMapper masUserRoleMapper;

    public MasUserRoleServiceImpl(MasUserRoleRepository masUserRoleRepository, MasUserRoleMapper masUserRoleMapper) {
        this.masUserRoleRepository = masUserRoleRepository;
        this.masUserRoleMapper = masUserRoleMapper;
    }

    /**
     * Save a masUserRole.
     *
     * @param masUserRoleDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasUserRole save(MasUserRole masUserRoleDTO) {
        log.debug("Request to save MasUserRoleEntity : {}", masUserRoleDTO);
        MasUserRoleEntity masUserRole = masUserRoleMapper.toEntity(masUserRoleDTO);
        masUserRole = masUserRoleRepository.save(masUserRole);
        return masUserRoleMapper.toModel(masUserRole);
    }

    /**
     * Get all the masUserRoles.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasUserRole> findAll(Pageable pageable) {
        log.debug("Request to get all MasUserRoles");
        return masUserRoleRepository.findAll(pageable)
            .map(masUserRoleMapper::toModel);
    }


    /**
     * Get one masUserRole by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasUserRole> findOne(Long id) {
        log.debug("Request to get MasUserRoleEntity : {}", id);
        return masUserRoleRepository.findById(id)
            .map(masUserRoleMapper::toModel);
    }

    /**
     * Delete the masUserRole by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasUserRoleEntity : {}", id);        masUserRoleRepository.deleteById(id);
    }
}
