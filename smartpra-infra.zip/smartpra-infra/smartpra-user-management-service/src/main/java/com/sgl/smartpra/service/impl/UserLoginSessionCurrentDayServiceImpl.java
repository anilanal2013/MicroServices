package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.UserLoginSessionCurrentDayService;
import com.sgl.smartpra.domain.UserLoginSessionCurrentDayEntity;
import com.sgl.smartpra.repository.UserLoginSessionCurrentDayRepository;
import com.sgl.smartpra.service.mapper.UserLoginSessionCurrentDayMapper;
import com.sgl.smartpra.service.model.UserLoginSessionCurrentDay;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing UserLoginSessionCurrentDayEntity.
 */
@Service
@Transactional
public class UserLoginSessionCurrentDayServiceImpl implements UserLoginSessionCurrentDayService {

    private final Logger log = LoggerFactory.getLogger(UserLoginSessionCurrentDayServiceImpl.class);

    private final UserLoginSessionCurrentDayRepository userLoginSessionCurrentDayRepository;

    private final UserLoginSessionCurrentDayMapper userLoginSessionCurrentDayMapper;

    public UserLoginSessionCurrentDayServiceImpl(UserLoginSessionCurrentDayRepository userLoginSessionCurrentDayRepository, UserLoginSessionCurrentDayMapper userLoginSessionCurrentDayMapper) {
        this.userLoginSessionCurrentDayRepository = userLoginSessionCurrentDayRepository;
        this.userLoginSessionCurrentDayMapper = userLoginSessionCurrentDayMapper;
    }

    /**
     * Save a userLoginSessionCurrentDay.
     *
     * @param userLoginSessionCurrentDayDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public UserLoginSessionCurrentDay save(UserLoginSessionCurrentDay userLoginSessionCurrentDayDTO) {
        log.debug("Request to save UserLoginSessionCurrentDayEntity : {}", userLoginSessionCurrentDayDTO);
        UserLoginSessionCurrentDayEntity userLoginSessionCurrentDay = userLoginSessionCurrentDayMapper.toEntity(userLoginSessionCurrentDayDTO);
        userLoginSessionCurrentDay = userLoginSessionCurrentDayRepository.save(userLoginSessionCurrentDay);
        return userLoginSessionCurrentDayMapper.toModel(userLoginSessionCurrentDay);
    }

    /**
     * Get all the userLoginSessionCurrentDays.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<UserLoginSessionCurrentDay> findAll(Pageable pageable) {
        log.debug("Request to get all UserLoginSessionCurrentDays");
        return userLoginSessionCurrentDayRepository.findAll(pageable)
            .map(userLoginSessionCurrentDayMapper::toModel);
    }


    /**
     * Get one userLoginSessionCurrentDay by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<UserLoginSessionCurrentDay> findOne(Long id) {
        log.debug("Request to get UserLoginSessionCurrentDayEntity : {}", id);
        return userLoginSessionCurrentDayRepository.findById(id)
            .map(userLoginSessionCurrentDayMapper::toModel);
    }

    /**
     * Delete the userLoginSessionCurrentDay by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete UserLoginSessionCurrentDayEntity : {}", id);        userLoginSessionCurrentDayRepository.deleteById(id);
    }
}
