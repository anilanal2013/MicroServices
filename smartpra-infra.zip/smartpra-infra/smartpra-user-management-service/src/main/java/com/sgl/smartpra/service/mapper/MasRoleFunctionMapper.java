package com.sgl.smartpra.service.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.sgl.smartpra.domain.MasRoleEntity;
import com.sgl.smartpra.domain.MasRoleFunctionEntity;
import com.sgl.smartpra.service.model.MasRoleFunction;

@Mapper(componentModel = "spring", uses = {})
public interface MasRoleFunctionMapper extends EntityMapper<MasRoleFunction, MasRoleFunctionEntity> {

	@Mappings({

			@Mapping(source = "roleFunctionId", target = "roleFunctionId"),
			@Mapping(source = "roleId", target = "masRoleEntity.roleId"),
			@Mapping(source = "functionActionId", target = "functionActionsEntity.functionActionId") })
	MasRoleFunctionEntity toEntity(MasRoleFunction masRoleDTO);

	@Mappings({

			@Mapping(source = "roleFunctionId", target = "roleFunctionId"),
			@Mapping(source = "masRoleEntity.roleId", target = "roleId"),
			@Mapping(source = "functionActionsEntity.functionActionId", target = "functionActionId") })
	MasRoleFunction toModel(MasRoleFunctionEntity masRole);

	default MasRoleEntity fromId(Long id) {
		if (id == null) {
			return null;
		}
		MasRoleEntity masRole = new MasRoleEntity();
		masRole.setRoleId(id);
		return masRole;
	}

}
