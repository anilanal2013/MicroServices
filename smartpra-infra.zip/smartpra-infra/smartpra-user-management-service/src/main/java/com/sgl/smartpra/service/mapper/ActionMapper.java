package com.sgl.smartpra.service.mapper;

import org.mapstruct.Mapper;

import com.sgl.smartpra.domain.ActionEntity;
import com.sgl.smartpra.service.mapper.EntityMapper;
import com.sgl.smartpra.service.model.Action;

@Mapper(componentModel = "spring", uses = {})
public interface ActionMapper extends EntityMapper<Action, ActionEntity> {

	default ActionEntity fromId(Long id) {
		if (id == null) {
			return null;
		}
		ActionEntity actionEntity = new ActionEntity();
		actionEntity.setActionId(id);
		return actionEntity;
	}
}
