package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.UserLoginSessionCurrentDayService;
import com.sgl.smartpra.service.model.UserLoginSessionCurrentDay;

/**
 * REST controller for managing UserLoginSessionCurrentDayEntity.
 */
@RestController
@RequestMapping("/api")
public class UserLoginSessionCurrentDayResource {

    private final Logger log = LoggerFactory.getLogger(UserLoginSessionCurrentDayResource.class);

    private static final String ENTITY_NAME = "userLoginSessionCurrentDay";

    private final UserLoginSessionCurrentDayService userLoginSessionCurrentDayService;

    public UserLoginSessionCurrentDayResource(UserLoginSessionCurrentDayService userLoginSessionCurrentDayService) {
        this.userLoginSessionCurrentDayService = userLoginSessionCurrentDayService;
    }

    /**
     * POST  /user-login-session-current-days : Create a new userLoginSessionCurrentDay.
     *
     * @param userLoginSessionCurrentDayDTO the userLoginSessionCurrentDayDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new userLoginSessionCurrentDayDTO, or with status 400 (Bad Request) if the userLoginSessionCurrentDay has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/user-login-session-current-days")
    public ResponseEntity<UserLoginSessionCurrentDay> createUserLoginSessionCurrentDay(@RequestBody UserLoginSessionCurrentDay userLoginSessionCurrentDayDTO) throws URISyntaxException {
        log.debug("REST request to save UserLoginSessionCurrentDayEntity : {}", userLoginSessionCurrentDayDTO);
        if (userLoginSessionCurrentDayDTO.getUserLoginSessionCurrentDayId() != null) {
            throw new BadRequestAlertException("A new userLoginSessionCurrentDay cannot already have an ID", ENTITY_NAME, "idexists");
        }
        UserLoginSessionCurrentDay result = userLoginSessionCurrentDayService.save(userLoginSessionCurrentDayDTO);
        return ResponseEntity.created(new URI("/api/user-login-session-current-days/" + result.getUserLoginSessionCurrentDayId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getUserLoginSessionCurrentDayId().toString()))
            .body(result);
    }

    /**
     * PUT  /user-login-session-current-days : Updates an existing userLoginSessionCurrentDay.
     *
     * @param userLoginSessionCurrentDayDTO the userLoginSessionCurrentDayDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated userLoginSessionCurrentDayDTO,
     * or with status 400 (Bad Request) if the userLoginSessionCurrentDayDTO is not valid,
     * or with status 500 (Internal Server Error) if the userLoginSessionCurrentDayDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/user-login-session-current-days")
    public ResponseEntity<UserLoginSessionCurrentDay> updateUserLoginSessionCurrentDay(@RequestBody UserLoginSessionCurrentDay userLoginSessionCurrentDayDTO) throws URISyntaxException {
        log.debug("REST request to update UserLoginSessionCurrentDayEntity : {}", userLoginSessionCurrentDayDTO);
        if (userLoginSessionCurrentDayDTO.getUserLoginSessionCurrentDayId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        UserLoginSessionCurrentDay result = userLoginSessionCurrentDayService.save(userLoginSessionCurrentDayDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, userLoginSessionCurrentDayDTO.getUserLoginSessionCurrentDayId().toString()))
            .body(result);
    }

    /**
     * GET  /user-login-session-current-days : get all the userLoginSessionCurrentDays.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of userLoginSessionCurrentDays in body
     */
    @GetMapping("/user-login-session-current-days")
    public ResponseEntity<List<UserLoginSessionCurrentDay>> getAllUserLoginSessionCurrentDays(Pageable pageable) {
        log.debug("REST request to get a page of UserLoginSessionCurrentDays");
        Page<UserLoginSessionCurrentDay> page = userLoginSessionCurrentDayService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/user-login-session-current-days");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /user-login-session-current-days/:id : get the "id" userLoginSessionCurrentDay.
     *
     * @param id the id of the userLoginSessionCurrentDayDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the userLoginSessionCurrentDayDTO, or with status 404 (Not Found)
     */
    @GetMapping("/user-login-session-current-days/{id}")
    public ResponseEntity<UserLoginSessionCurrentDay> getUserLoginSessionCurrentDay(@PathVariable Long id) {
        log.debug("REST request to get UserLoginSessionCurrentDayEntity : {}", id);
        Optional<UserLoginSessionCurrentDay> userLoginSessionCurrentDayDTO = userLoginSessionCurrentDayService.findOne(id);
        return ResponseUtil.wrapOrNotFound(userLoginSessionCurrentDayDTO);
    }

    /**
     * DELETE  /user-login-session-current-days/:id : delete the "id" userLoginSessionCurrentDay.
     *
     * @param id the id of the userLoginSessionCurrentDayDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/user-login-session-current-days/{id}")
    public ResponseEntity<Void> deleteUserLoginSessionCurrentDay(@PathVariable Long id) {
        log.debug("REST request to delete UserLoginSessionCurrentDayEntity : {}", id);
        userLoginSessionCurrentDayService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
