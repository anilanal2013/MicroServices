package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.MasUserLoginService;
import com.sgl.smartpra.domain.MasUserLoginEntity;
import com.sgl.smartpra.repository.MasUserLoginRepository;
import com.sgl.smartpra.service.mapper.MasUserLoginMapper;
import com.sgl.smartpra.service.model.MasUserLogin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing MasUserLoginEntity.
 */
@Service
@Transactional
public class MasUserLoginServiceImpl implements MasUserLoginService {

    private final Logger log = LoggerFactory.getLogger(MasUserLoginServiceImpl.class);

    private final MasUserLoginRepository masUserLoginRepository;

    private final MasUserLoginMapper masUserLoginMapper;

    public MasUserLoginServiceImpl(MasUserLoginRepository masUserLoginRepository, MasUserLoginMapper masUserLoginMapper) {
        this.masUserLoginRepository = masUserLoginRepository;
        this.masUserLoginMapper = masUserLoginMapper;
    }

    /**
     * Save a masUserLogin.
     *
     * @param masUserLoginDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasUserLogin save(MasUserLogin masUserLoginDTO) {
        log.debug("Request to save MasUserLoginEntity : {}", masUserLoginDTO);
        MasUserLoginEntity masUserLogin = masUserLoginMapper.toEntity(masUserLoginDTO);
        masUserLogin = masUserLoginRepository.save(masUserLogin);
        return masUserLoginMapper.toModel(masUserLogin);
    }

    /**
     * Get all the masUserLogins.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasUserLogin> findAll(Pageable pageable) {
        log.debug("Request to get all MasUserLogins");
        return masUserLoginRepository.findAll(pageable)
            .map(masUserLoginMapper::toModel);
    }


    /**
     * Get one masUserLogin by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasUserLogin> findOne(Long id) {
        log.debug("Request to get MasUserLoginEntity : {}", id);
        return masUserLoginRepository.findById(id)
            .map(masUserLoginMapper::toModel);
    }

    /**
     * Delete the masUserLogin by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasUserLoginEntity : {}", id);        masUserLoginRepository.deleteById(id);
    }

	@Override
	public Optional<MasUserLogin> findOneByUser(Long userId) {
		return masUserLoginRepository.findOneByMasUsersUserId(userId).map(masUserLoginMapper::toModel);
	}
}
