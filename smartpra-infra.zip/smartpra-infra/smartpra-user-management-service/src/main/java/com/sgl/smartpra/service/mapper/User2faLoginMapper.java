package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.User2faLogin;

import org.mapstruct.*;

/**
 * Mapper for the entity User2faLoginEntity and its DTO User2faLogin.
 */
@Mapper(componentModel = "spring", uses = {MasUsersMapper.class})
public interface User2faLoginMapper extends EntityMapper<User2faLogin, User2faLoginEntity> {

    @Mapping(source = "masUsers.userId", target = "masUsersId")
    User2faLogin toModel(User2faLoginEntity user2faLogin);

    @Mapping(source = "masUsersId", target = "masUsers")
    User2faLoginEntity toEntity(User2faLogin user2faLoginDTO);

    default User2faLoginEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        User2faLoginEntity user2faLogin = new User2faLoginEntity();
        user2faLogin.setUser2faAutoid(id);
        return user2faLogin;
    }
}
