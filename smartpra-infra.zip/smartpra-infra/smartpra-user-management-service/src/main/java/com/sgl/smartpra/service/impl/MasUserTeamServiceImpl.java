package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.MasUserTeamService;
import com.sgl.smartpra.domain.MasUserTeamEntity;
import com.sgl.smartpra.repository.MasUserTeamRepository;
import com.sgl.smartpra.service.mapper.MasUserTeamMapper;
import com.sgl.smartpra.service.model.MasUserTeam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing MasUserTeamEntity.
 */
@Service
@Transactional
public class MasUserTeamServiceImpl implements MasUserTeamService {

    private final Logger log = LoggerFactory.getLogger(MasUserTeamServiceImpl.class);

    private final MasUserTeamRepository masUserTeamRepository;

    private final MasUserTeamMapper masUserTeamMapper;

    public MasUserTeamServiceImpl(MasUserTeamRepository masUserTeamRepository, MasUserTeamMapper masUserTeamMapper) {
        this.masUserTeamRepository = masUserTeamRepository;
        this.masUserTeamMapper = masUserTeamMapper;
    }

    /**
     * Save a masUserTeam.
     *
     * @param masUserTeamDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasUserTeam save(MasUserTeam masUserTeamDTO) {
        log.debug("Request to save MasUserTeamEntity : {}", masUserTeamDTO);
        MasUserTeamEntity masUserTeam = masUserTeamMapper.toEntity(masUserTeamDTO);
        masUserTeam = masUserTeamRepository.save(masUserTeam);
        return masUserTeamMapper.toModel(masUserTeam);
    }

    /**
     * Get all the masUserTeams.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasUserTeam> findAll(Pageable pageable) {
        log.debug("Request to get all MasUserTeams");
        return masUserTeamRepository.findAll(pageable)
            .map(masUserTeamMapper::toModel);
    }


    /**
     * Get one masUserTeam by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasUserTeam> findOne(Long id) {
        log.debug("Request to get MasUserTeamEntity : {}", id);
        return masUserTeamRepository.findById(id)
            .map(masUserTeamMapper::toModel);
    }

    /**
     * Delete the masUserTeam by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasUserTeamEntity : {}", id);        masUserTeamRepository.deleteById(id);
    }
}
