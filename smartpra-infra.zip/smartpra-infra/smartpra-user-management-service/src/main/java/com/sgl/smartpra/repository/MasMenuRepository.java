package com.sgl.smartpra.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.domain.MasMenuEntity;

@Repository
public interface MasMenuRepository extends JpaRepository<MasMenuEntity, Long>{

	MasMenuEntity findByParentCode(String parentCode);
	
	MasMenuEntity findByMenuDescription(String desc);
}
