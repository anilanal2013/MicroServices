package com.sgl.smartpra.repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.config.Constants;
import com.sgl.smartpra.domain.MasUsersEntity;
import com.sgl.smartpra.service.model.UserIdAndName;

@Repository
public interface MasUserRepository extends JpaRepository<MasUsersEntity, Long> {

	

	Optional<MasUsersEntity> findOneByActivationKey(String activationKey);

	List<MasUsersEntity> findAllByIsActiveIsFalseAndCreatedDateBefore(@Param("createdDate") Instant createdDate);

	Optional<MasUsersEntity> findOneByResetKey(String resetKey);
	
	Optional<MasUsersEntity> findOneByEmailIgnoreCase(String email);

	Optional<MasUsersEntity> findOneByEmail(String email);

	Optional<MasUsersEntity> findOneByUserName(String userName);

	@EntityGraph(attributePaths = "masUserRoles")
	Optional<MasUsersEntity> findOneWithMasUserRolesByUserId(Long id);

	@EntityGraph(attributePaths = "masUserRoles")
	Optional<MasUsersEntity> findOneWithMasUserRolesByUserName(String userName);

	@EntityGraph(attributePaths = "masUserRoles")
	@Cacheable(cacheNames = Constants.USERS_BY_EMAIL_CACHE)
	Optional<MasUsersEntity> findOneWithMasUserRolesByEmail(String email);

	@Cacheable(cacheNames = Constants.GET_ALL_USERS_CACHE)
	List<MasUsersEntity> findAllByUserNameNot(String userName);
	
	@Query("select u from MasUsersEntity u,MasUserRoleEntity ur, MasRoleEntity r where u.userId = ur.masUsers and ur.masRole = r.roleId and r.roleName =:roleName")
	List<MasUsersEntity> getUserByRole(@Param("roleName")String roleName);
	
	List<MasUsersEntity> findAllByUserNameOrFirstNameOrLastNameOrEmail(String userName,String firstName,String lastName,String eamil);
	
	List<MasUsersEntity> findAllByUserNameOrFirstNameOrEmail(String userName,String firstName,String eamil);
	
	MasUsersEntity findMasUsersEntitiesByUserId(Long userId);

	MasUsersEntity findMasUsersEntityByUserId(long userId);

	List<MasUsersEntity> findMasMasUsersEntitysByUserTeamId(int teamId);

	List<UserIdAndName> findAllByUserTeamId(Integer teamId);

	UserIdAndName findAllByUserNameOrEmail(String userName, String userEmail);

	List<MasUsersEntity> findMasUsersEntitiesByUserTeamId(Long teamId);



}
