package com.sgl.smartpra.service.mapper;

import java.util.List;

/**
 * Contract for a generic model to entity mapper.
 *
 * @param <D> - DTO type parameter.
 * @param <E> - Entity type parameter.
 */

public interface EntityMapper <D, E> {

    E toEntity(D dto);

    D toModel(E entity);

    List <E> toEntity(List<D> dtoList);

    List <D> toModel(List<E> entityList);
}
