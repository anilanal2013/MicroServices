package com.sgl.smartpra.service.mapper;

import com.sgl.smartpra.domain.*;
import com.sgl.smartpra.service.model.MasUserRole;

import org.mapstruct.*;

/**
 * Mapper for the entity MasUserRoleEntity and its DTO MasUserRole.
 */
@Mapper(componentModel = "spring", uses = {MasUsersMapper.class, MasRoleMapper.class})
public interface MasUserRoleMapper extends EntityMapper<MasUserRole, MasUserRoleEntity> {

	@Mappings({
    @Mapping(source = "masUsers.userId", target = "masUsersId"),
    @Mapping(source = "masRole.roleId", target = "masRoleId"),
    @Mapping(source = "userRoleId", target = "masUserRoleId")})
    MasUserRole toModel(MasUserRoleEntity masUserRole);

	@Mappings({
    @Mapping(source = "masUsersId", target = "masUsers"),
    @Mapping(source = "masRoleId", target = "masRole")})
    MasUserRoleEntity toEntity(MasUserRole masUserRoleDTO);

    default MasUserRoleEntity fromId(Long id) {
        if (id == null) {
            return null;
        }
        MasUserRoleEntity masUserRole = new MasUserRoleEntity();
        masUserRole.setUserRoleId(id);
        return masUserRole;
    }
}
