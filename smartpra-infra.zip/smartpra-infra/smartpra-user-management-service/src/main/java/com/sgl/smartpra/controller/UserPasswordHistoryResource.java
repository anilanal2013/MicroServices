package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.PaginationUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.UserPasswordHistoryService;
import com.sgl.smartpra.service.model.UserPasswordHistory;

/**
 * REST controller for managing UserPasswordHistoryEntity.
 */
@RestController
@RequestMapping("/api")
public class UserPasswordHistoryResource {

    private final Logger log = LoggerFactory.getLogger(UserPasswordHistoryResource.class);

    private static final String ENTITY_NAME = "userPasswordHistory";

    private final UserPasswordHistoryService userPasswordHistoryService;

    public UserPasswordHistoryResource(UserPasswordHistoryService userPasswordHistoryService) {
        this.userPasswordHistoryService = userPasswordHistoryService;
    }

    /**
     * POST  /user-password-histories : Create a new userPasswordHistory.
     *
     * @param userPasswordHistoryDTO the userPasswordHistoryDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new userPasswordHistoryDTO, or with status 400 (Bad Request) if the userPasswordHistory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/user-password-histories")
    public ResponseEntity<UserPasswordHistory> createUserPasswordHistory(@RequestBody UserPasswordHistory userPasswordHistoryDTO) throws URISyntaxException {
        log.debug("REST request to save UserPasswordHistoryEntity : {}", userPasswordHistoryDTO);
        if (userPasswordHistoryDTO.getUserPasswordHistoryId() != null) {
            throw new BadRequestAlertException("A new userPasswordHistory cannot already have an ID", ENTITY_NAME, "idexists");
        }
        UserPasswordHistory result = userPasswordHistoryService.save(userPasswordHistoryDTO);
        return ResponseEntity.created(new URI("/api/user-password-histories/" + result.getUserPasswordHistoryId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getUserPasswordHistoryId().toString()))
            .body(result);
    }

    /**
     * PUT  /user-password-histories : Updates an existing userPasswordHistory.
     *
     * @param userPasswordHistoryDTO the userPasswordHistoryDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated userPasswordHistoryDTO,
     * or with status 400 (Bad Request) if the userPasswordHistoryDTO is not valid,
     * or with status 500 (Internal Server Error) if the userPasswordHistoryDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/user-password-histories")
    public ResponseEntity<UserPasswordHistory> updateUserPasswordHistory(@RequestBody UserPasswordHistory userPasswordHistoryDTO) throws URISyntaxException {
        log.debug("REST request to update UserPasswordHistoryEntity : {}", userPasswordHistoryDTO);
        if (userPasswordHistoryDTO.getUserPasswordHistoryId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        UserPasswordHistory result = userPasswordHistoryService.save(userPasswordHistoryDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, userPasswordHistoryDTO.getUserPasswordHistoryId().toString()))
            .body(result);
    }

    /**
     * GET  /user-password-histories : get all the userPasswordHistories.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of userPasswordHistories in body
     */
    @GetMapping("/user-password-histories")
    public ResponseEntity<List<UserPasswordHistory>> getAllUserPasswordHistories(Pageable pageable) {
        log.debug("REST request to get a page of UserPasswordHistories");
        Page<UserPasswordHistory> page = userPasswordHistoryService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/user-password-histories");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /user-password-histories/:id : get the "id" userPasswordHistory.
     *
     * @param id the id of the userPasswordHistoryDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the userPasswordHistoryDTO, or with status 404 (Not Found)
     */
    @GetMapping("/user-password-histories/{id}")
    public ResponseEntity<UserPasswordHistory> getUserPasswordHistory(@PathVariable Long id) {
        log.debug("REST request to get UserPasswordHistoryEntity : {}", id);
        Optional<UserPasswordHistory> userPasswordHistoryDTO = userPasswordHistoryService.findOne(id);
        return ResponseUtil.wrapOrNotFound(userPasswordHistoryDTO);
    }

    /**
     * DELETE  /user-password-histories/:id : delete the "id" userPasswordHistory.
     *
     * @param id the id of the userPasswordHistoryDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/user-password-histories/{id}")
    public ResponseEntity<Void> deleteUserPasswordHistory(@PathVariable Long id) {
        log.debug("REST request to delete UserPasswordHistoryEntity : {}", id);
        userPasswordHistoryService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
