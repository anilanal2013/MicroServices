package com.sgl.smartpra.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
/***
 * This util class is used to encrypt and decrypt smartpra user's KYC details.
 * 
 * @author mansound1
 *
 */
@Component
@ConfigurationProperties("smartpra")
public class SmartpraEncryptionUtil {
	
	private final static Logger log = LoggerFactory.getLogger(SmartpraEncryptionUtil.class);
	
	private static SecretKeySpec secretKey;
	
	private static byte[] key;
	
	@Value("${smartpra.encryption.secreatkey}")
	private static String encryptionKey="smartpra";

	public static void setKey(String myKey) {
		MessageDigest sha = null;
		try {
			key = myKey.getBytes("UTF-8");
			sha = MessageDigest.getInstance("SHA-1");
			key = sha.digest(key);
			key = Arrays.copyOf(key, 16);
			secretKey = new SecretKeySpec(key, "AES");
		} catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
			log.error("Set Key Failed :: {}", e);
		}
	}

	public static String getEncryptionKey() {
		return encryptionKey;
	}

	public static void setEncryptionKey(String encryptionKey) {
		SmartpraEncryptionUtil.encryptionKey = encryptionKey;
	}

	public static String encrypt(String strToEncrypt) {
		if (strToEncrypt != null) {
			try {
				setKey(encryptionKey);
				Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
				cipher.init(Cipher.ENCRYPT_MODE, secretKey);
				return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
			} catch (Exception e) {
				log.error("Error while encrypting: " + e.toString());
			}
		}
		return null;
	}

	public static String decrypt(String strToDecrypt) {
		if (strToDecrypt != null) {
			try {
				setKey(encryptionKey);
				Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
				cipher.init(Cipher.DECRYPT_MODE, secretKey);
				return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
			} catch (Exception e) {
				log.error("Error while decrypting: " + e.toString());
			}
		}
		return null;
	}
}
