package com.sgl.smartpra.service.impl;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.config.Constants;
import com.sgl.smartpra.controller.error.EmailAlreadyUsedException;
import com.sgl.smartpra.controller.error.InvalidPasswordException;
import com.sgl.smartpra.domain.FunctionActionsEntity;
import com.sgl.smartpra.domain.MasMenuEntity;
import com.sgl.smartpra.domain.MasMenuFunctionEntity;
import com.sgl.smartpra.domain.MasRoleEntity;
import com.sgl.smartpra.domain.MasRoleFunctionEntity;
import com.sgl.smartpra.domain.MasUserPasswordEntity;
import com.sgl.smartpra.domain.MasUserRoleEntity;
import com.sgl.smartpra.domain.MasUsersEntity;
import com.sgl.smartpra.domain.ScreenFunctionEntity;
import com.sgl.smartpra.repository.MasMenuFunctionRepository;
import com.sgl.smartpra.repository.MasMenuRepository;
import com.sgl.smartpra.repository.MasRoleFunctionRepository;
import com.sgl.smartpra.repository.MasRoleRepository;
import com.sgl.smartpra.repository.MasUserRepository;
import com.sgl.smartpra.repository.MasUserRoleRepository;
import com.sgl.smartpra.security.AuthoritiesConstants;
import com.sgl.smartpra.security.SecurityUtils;
import com.sgl.smartpra.security.validation.ValidPassword;
import com.sgl.smartpra.service.MasUserService;
import com.sgl.smartpra.service.mapper.MasUserRoleMapper;
import com.sgl.smartpra.service.mapper.MasUsersMapper;
import com.sgl.smartpra.service.model.MasUsers;
import com.sgl.smartpra.service.model.RoleActionPrivileges;
import com.sgl.smartpra.service.model.UserDetail;
import com.sgl.smartpra.service.model.UserIdAndName;
import com.sgl.smartpra.service.util.RandomUtil;
import com.sgl.smartpra.util.SmartpraEncryptionUtil;

/**
 * 
 * @author mansound1
 *
 */
@Service
@Transactional
public class MasUserServiceImpl implements MasUserService{

	private final Logger log = LoggerFactory.getLogger(MasUserServiceImpl.class);

	private final MasUserRepository userRepository;
	
	private final MasUserRoleRepository masUserRoleRepository;
	
	private final MasRoleFunctionRepository masRoleFunctionRepository;
	
	private final MasMenuRepository masMenuRepository;
	
	private final MasMenuFunctionRepository masMenuFunctionRepository;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	@Autowired
	MasUsersMapper masUsersMapper;
	
	@Autowired 
	MasUserRoleMapper masUserRoleMapper;
	
	@ValidPassword
	private String passwordraw;
	
	@Autowired
	private SmartpraEncryptionUtil smartpraEncryptionUtil;

	private final MasRoleRepository roleRepository;

	private final CacheManager cacheManager;

	public MasUserServiceImpl(MasUserRepository userRepository,
			MasRoleRepository authorityRepository, CacheManager cacheManager,
			MasUserRoleRepository masUserRoleRepository, MasRoleFunctionRepository masRoleFunctionRepository,
			MasMenuRepository masMenuRepository, MasMenuFunctionRepository masMenuFunctionRepository) {
		this.userRepository = userRepository;
		this.roleRepository = authorityRepository;
		this.cacheManager = cacheManager;
		this.masUserRoleRepository = masUserRoleRepository;
		this.masRoleFunctionRepository = masRoleFunctionRepository;
		this.masMenuRepository = masMenuRepository;
		this.masMenuFunctionRepository = masMenuFunctionRepository;
	}

	public Optional<MasUsersEntity> activateRegistration(String key) {
		log.debug("Activating user for activation key {}", key);
		return userRepository.findOneByActivationKey(key).map(user -> {
			// activate given user for the registration key.
			user.setIsActive(true);
			user.setActivationKey(null);
			this.clearUserCaches();
			log.debug("Activated user: {}", user);
			return user;
		});
	}

	public Optional<MasUsersEntity> completePasswordReset(String newPassword, String key) {
		log.debug("Reset user password for reset key {}", key);
		return userRepository.findOneByResetKey(key)
				.filter(user -> user.getResetDate().isAfter(Instant.now().minusSeconds(86400))).map(user -> {
					user.getMasUserPassword().setPasswordHash(passwordEncoder.encode(newPassword));
					user.setResetKey(null);
					this.clearUserCaches();
					return user;
				});
	}

	public Optional<MasUsersEntity> requestPasswordReset(String mail) {
		return userRepository.findOneByEmailIgnoreCase(mail).filter(MasUsersEntity::getIsActive).map(user -> {
			user.setResetKey(RandomUtil.generateResetKey());
			user.setResetDate(Instant.now());
			this.clearUserCaches();
			return user;
		});
	}
	
	public Optional<MasUsersEntity> requestUserName(String email) {
		return userRepository.findOneByEmailIgnoreCase(email).filter(MasUsersEntity::getIsActive).map(user -> {
			this.clearUserCaches();
			return user;
		});
	}

	
	public void bulkUserUpload(List<MasUsers> masUsers) {
		masUsers.forEach(user -> {
			registerUser(user,null);
		});
	}
	
	public MasUsersEntity registerUser(MasUsers userDTO, String password) {
		String encryptedPasswrd  = StringUtils.EMPTY;
		
			userRepository.findOneByEmailIgnoreCase(userDTO.getEmail()).ifPresent(existingUser -> {
				boolean removed = removeNonActivatedUser(existingUser);
				if (!removed) {
					throw new EmailAlreadyUsedException();
				}
			});
			 MasUsersEntity newUser = masUsersMapper.toEntity(userDTO);
			MasUserPasswordEntity masUserPassword = new MasUserPasswordEntity();
			// new user gets initially a generated password
			if(password == null) {
				// encryptedPassword = passwordEncoder.encode(RandomUtil.generatePassword());
				 encryptedPasswrd = passwordEncoder.encode("Password1$");
			}else {
				passwordraw = password;
				 encryptedPasswrd = passwordEncoder.encode(passwordraw);
			}
			
			masUserPassword.setPasswordHash(encryptedPasswrd);
			
			newUser.setFirstName(userDTO.getFirstName());
			newUser.setLastName(userDTO.getLastName());
			newUser.setEmail(userDTO.getEmail().toLowerCase());
			newUser.setLangKey(userDTO.getLangKey());
			newUser.setIsActive(false);
			
			String userName = RandomUtil.generateUserId(userDTO.getFirstName(), userDTO.getLastName());
			if(userRepository.findOneByUserName(userName).isPresent()) {
				userName = "s"+userName;
				newUser.setUserName(userName);
			}else {
				newUser.setUserName(userName);
			}
			newUser.setMasUserPassword(masUserPassword);
			masUserPassword.setMasUsers(newUser);
			
			// new user gets registration key
			newUser.setActivationKey(RandomUtil.generateActivationKey());
			newUser.setResetKey(RandomUtil.generateActivationKey());
			// new user gets ANONYMOUS role when registring and Admin will provides specific role through profile setup page
			Optional<MasRoleEntity> authorities = roleRepository.findOneByRoleName(AuthoritiesConstants.GUEST);
			MasUserRoleEntity masUserRole = new MasUserRoleEntity();
			Set<MasUserRoleEntity> masUserRoles = new HashSet<>();
			if (authorities.isPresent()) {
				masUserRole.setMasRole(authorities.get());
			}
			masUserRole.setIsActive(true);
			masUserRole.setMasUsers(newUser);
			masUserRoles.add(masUserRole);
			newUser.setMasUserRoles(masUserRoles);
			try {
				userRepository.save(newUser);
			} catch (Exception e) {
				log.error("User register Failed :: {}", e);
			}
			this.clearUserCaches();

			log.debug("Created Information for User: {}", newUser);
			return newUser;
		
	}

	private boolean removeNonActivatedUser(MasUsersEntity existingUser) {
		if (existingUser.getIsActive()) {
			return false;
		}
		userRepository.delete(existingUser);
		userRepository.flush();
		this.clearUserCaches();
		return true;
	}

	@SuppressWarnings("static-access")
	public MasUsersEntity createUser(MasUsers userDTO) {
		
		if (userDTO.getUserProfilePhoto() != null) {
			userDTO.setUserPhoto(Base64.decodeBase64(userDTO.getUserProfilePhoto()));

		}
		    MasUsersEntity user = masUsersMapper.toEntity(userDTO);
		  
			MasUserPasswordEntity masUserPassword = new MasUserPasswordEntity();
			user.setUserName(userDTO.getUserName().toLowerCase());
			user.setFirstName(userDTO.getFirstName());
			user.setLastName(userDTO.getLastName());
			String userName = RandomUtil.generateUserId(userDTO.getFirstName(), userDTO.getLastName());
			if(userRepository.findOneByUserName(userName).isPresent()) {
				userName = "s"+userName;
				user.setUserName(userName);
			}else {
				user.setUserName(userName);
			}
			user.setEmail(userDTO.getEmail().toLowerCase());
			if (userDTO.getLangKey() == null) {
				user.setLangKey(Constants.DEFAULT_LANGUAGE); // default language
			} else {
				user.setLangKey(userDTO.getLangKey());
			}
			passwordraw = userDTO.getPasswordHash();
			String encryptedPassword = passwordEncoder.encode(passwordraw);
			masUserPassword.setPasswordHash(encryptedPassword);
			masUserPassword.setMasUsers(user);
			user.setMasUserPassword(masUserPassword);
			user.setResetKey(RandomUtil.generateResetKey());
			user.setActivationKey(RandomUtil.generateResetKey());
			user.setResetDate(Instant.now());
			user.setIsActive(true);
			  if(user.getUserAddress1() != null) {
			    	user.setUserAddress1(smartpraEncryptionUtil.encrypt(user.getUserAddress1()));
			    }
			    if(user.getUserAddress2() != null) {
			    	user.setUserAddress2(smartpraEncryptionUtil.encrypt(user.getUserAddress2()));
			    }
			    if(user.getUserAddress3() != null) {
			    	user.setUserAddress3(smartpraEncryptionUtil.encrypt(user.getUserAddress3()));
			    }
			    if(user.getUserTelephone() != null) {
			    	user.setUserAddress3(smartpraEncryptionUtil.encrypt(user.getUserTelephone()));
			    }
			    
			MasUserRoleEntity masUserRole = new MasUserRoleEntity();
			Set<MasUserRoleEntity> masUserRoles = new HashSet<>();
			Set<Long> roleIds = userDTO.getRoleIds();
			for (Long roleId : roleIds) {
				MasUserRoleEntity masUserRoleEntity = new MasUserRoleEntity();
				Optional<MasRoleEntity> authorities = roleRepository.findById(roleId);
				if (authorities.isPresent()) {
					masUserRoleEntity.setMasRole(authorities.get());
					masUserRoleEntity.setMasUsers(user);
					masUserRoleEntity.setIsActive(true);
					masUserRoles.add(masUserRoleEntity);
				}
			}
			masUserRole.setMasUsers(user);
			user.setMasUserRoles(masUserRoles);
			userRepository.save(user);
			this.clearUserCaches();
			log.debug("Created Information for User: {}", user);
		
		return user;
	}

	/**
	 * Update basic information (first name, last name, email, language) for the
	 * current user.
	 *
	 * @param firstName first name of user
	 * @param lastName  last name of user
	 * @param email     email id of user
	 * @param langKey   language key
	 * @param imageUrl  image URL of user
	 */
	public void updateUser(String firstName, String lastName, String email, String langKey) {
		SecurityUtils.getCurrentUserLogin().flatMap(userRepository::findOneByEmailIgnoreCase).ifPresent(user -> {
			user.setFirstName(firstName);
			user.setLastName(lastName);
			user.setEmail(email.toLowerCase());
			user.setLangKey(langKey);
			this.clearUserCaches();
			log.debug("Changed Information for User: {}", user);
		});
	}

	/**
	 * Update all information for a specific user, and return the modified user.
	 *
	 * @param userDTO user to update
	 * @return updated user
	 */
	@SuppressWarnings("static-access")
	public Optional<MasUsers> updateUser(MasUsers userDTO) {
		return Optional.of(userRepository.findById(userDTO.getMasUsersId())).filter(Optional::isPresent).map(Optional::get)
				.map(user -> {
					this.clearUserCaches();
					user.setFirstName(userDTO.getFirstName());
					user.setLastName(userDTO.getLastName());
					user.setMiddleName(userDTO.getMiddleName());
					user.setDisplayName(userDTO.getDisplayName());
					user.setLangKey(userDTO.getLangKey());
					user.setPreferredLanguage(userDTO.getPreferredLanguage());
				
					  if(user.getUserAddress1() != null) {
					    	user.setUserAddress1(smartpraEncryptionUtil.encrypt(userDTO.getUserAddress1()));
					    }
					    if(user.getUserAddress2() != null) {
					    	user.setUserAddress2(smartpraEncryptionUtil.encrypt(userDTO.getUserAddress2()));
					    }
					    if(user.getUserAddress3() != null) {
					    	user.setUserAddress3(smartpraEncryptionUtil.encrypt(userDTO.getUserAddress3()));
					    }
					    if(user.getUserTelephone() != null) {
					    	user.setUserAddress3(smartpraEncryptionUtil.encrypt(userDTO.getUserTelephone()));
					    }
					user.setDateOfJoining(userDTO.getInstantOfJoining());
					user.setShiftEndTime(userDTO.getShiftEndTime());
					user.setShiftStartTime(userDTO.getShiftStartTime());
					user.setProcessName(userDTO.getProcessName());
					user.setUserRemarks(userDTO.getUserRemarks());
					user.setLangKey(userDTO.getLangKey());
					
					if(userDTO.getUserProfilePhoto() !=null) {
						user.setUserPhoto(Base64.decodeBase64(userDTO.getUserProfilePhoto()));
					}
					
					Set<MasUserRoleEntity> masUserRoles = user.getMasUserRoles();
					Set<Long> roleIds = userDTO.getRoleIds();
					Set<Long> userRoleIds = new HashSet<>();
					
					for(MasUserRoleEntity masUserRole : masUserRoles) {
						userRoleIds.add(masUserRole.getMasRole().getRoleId());
						if(!roleIds.contains(masUserRole.getMasRole().getRoleId()) && masUserRole.getIsActive()) {
							masUserRoleRepository.findById(masUserRole.getUserRoleId()).ifPresent(
									userRole -> {
										userRole.setMasRole(masUserRole.getMasRole());
										userRole.setMasUsers(user);
										userRole.setIsActive(false);
									});
						}
						if(roleIds.contains(masUserRole.getMasRole().getRoleId()) && !masUserRole.getIsActive()) {
							masUserRoleRepository.findById(masUserRole.getUserRoleId()).ifPresent(
									userRole -> {
										userRole.setMasRole(masUserRole.getMasRole());
										userRole.setMasUsers(user);
										userRole.setIsActive(true);
									});
						}
					}
					
					for(Long roleId : roleIds) {
						if(!userRoleIds.contains(roleId)) {
							MasUserRoleEntity masUserRoleEntity = new MasUserRoleEntity();
							Optional<MasRoleEntity> authorities = roleRepository.findById(roleId);
							if (authorities.isPresent()) {
								masUserRoleEntity.setMasRole(authorities.get());
								masUserRoleEntity.setMasUsers(user);
								masUserRoleEntity.setIsActive(true);
								masUserRoleRepository.save(masUserRoleEntity);
							}
						}
					}

					this.clearUserCaches();
					
					log.debug("Changed Information for User: {}", user);
					return user;
				}).map(masUsersMapper::toModel);
	}

	public void deleteUser(String login) {
		userRepository.findOneByEmailIgnoreCase(login).ifPresent(user -> {
			user.setIsActive(false);
			userRepository.saveAndFlush(user);
			this.clearUserCaches();
			log.debug("Deleted User: {}", user);
		});
	}

	public void changePassword(String currentClearTextPassword, String newPassword) {
		SecurityUtils.getCurrentUserLogin().flatMap(userRepository::findOneByEmailIgnoreCase).ifPresent(user -> {
			String currentEncryptedPassword = user.getMasUserPassword().getPasswordHash();
			if (!passwordEncoder.matches(currentClearTextPassword, currentEncryptedPassword)) {
				throw new InvalidPasswordException("Old password entered is incorrect");
			}
			String encryptedPassword = passwordEncoder.encode(newPassword);
			user.getMasUserPassword().setPasswordHash(encryptedPassword);
			this.clearUserCaches();
			log.debug("Changed password for User: {}", user);
		});
	}



	@Override
	@Transactional(readOnly = true)
	public List<MasUsers> getAllManagedUsers() {
		List<MasUsersEntity> findAllByUserNameNot = userRepository.findAllByUserNameNot(Constants.ANONYMOUS_USER);
		return masUsersMapper.toModel(findAllByUserNameNot);
	}

	@Transactional(readOnly = true)
	public Optional<MasUsersEntity> getUserWithAuthoritiesByLogin(String userName) {
		return userRepository.findOneWithMasUserRolesByUserName(userName);
	}

	@Transactional(readOnly = true)
	public Optional<MasUsersEntity> getUserWithAuthorities(Long id) {
		return userRepository.findOneWithMasUserRolesByUserId(id);
	}


	@Scheduled(cron = "0 0 1 * * ?")
	public void removeNotActivatedUsers() {
		userRepository.findAllByIsActiveIsFalseAndCreatedDateBefore(Instant.now().minus(3, ChronoUnit.DAYS))
				.forEach(user -> {
					userRepository.delete(user);
					this.clearUserCaches();
				});
	}

	@Scheduled(cron = "0 0 1 * * ?")
	public void passwordExpiredRemaider() {
       //TODO need to implement the login to notify the user.
	}
	

	private void clearUserCaches() {
		cacheManager.getCache(Constants.USERS_BY_LOGIN_CACHE).clear();
		cacheManager.getCache(Constants.USERS_BY_EMAIL_CACHE).clear();
		cacheManager.getCache(Constants.GET_ALL_USERS_CACHE).clear();
	}
	
	//Below line will be commented after implementing proper roles and permissions
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public void acivateOrDeactivateUser(String userLogin) {
		
			userRepository.findOneByEmailIgnoreCase(userLogin).ifPresent(user -> {
				if (user.getIsActive()) {
					user.setIsActive(false);
				} else {
					user.setIsActive(true);
				}
				this.clearUserCaches();
				log.debug("Changed Information for User: {}", user);
			});
		
	}

	
	
	public Optional<MasUsersEntity> setFirstTimePassword(String mail, String newPassword) {
		return userRepository.findOneByEmailIgnoreCase(mail).filter(MasUsersEntity::getIsActive).map(user -> {
			user.getMasUserPassword().setPasswordHash(passwordEncoder.encode(newPassword));
			user.setResetKey(RandomUtil.generateResetKey());
			user.setResetDate(Instant.now());
			this.clearUserCaches();
			return user;
		});
	}

	/*public String getPasswordraw() {
		return passwordraw;
	}*/

	public void setPasswordraw(String passwordraw) {
		this.passwordraw = passwordraw;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public void deleteUserById(Integer userId) {
		
		userRepository.findById(userId.longValue()).ifPresent(user -> {
			masUserRoleRepository.delete(user.getMasUserRoles().iterator().next());
			userRepository.delete(user);
			this.clearUserCaches();
			log.debug("Deleted User: {}", user);
		});
		
	
	}

	@Override
	public List<MasUsers> getAllUsersByRoleName(String roleName) {

		return userRepository.getUserByRole(roleName).stream().map(masUsersMapper::toModel).collect(Collectors.toCollection(LinkedList::new));

	}

	@Override
	public Optional<MasUsers> getUserByEmail(String email) {
		return decryptUserAddress(userRepository.findOneByEmail(email).map(masUsersMapper::toModel));
	}

	@Override
	public Optional<MasUsers> getUserByUserId(Long userId) {
		return decryptUserAddress(userRepository.findById(userId).map(masUsersMapper::toModel));
	}

	@Override
	public List<MasUsers> searchUsers(MasUsers userDTO) {
		if(isEmptyOrNull(userDTO.getUserName()) && isEmptyOrNull(userDTO.getFirstName()) &&
				isEmptyOrNull(userDTO.getEmail()) && isEmptyOrNull(userDTO.getLastName())) {
			return userRepository.findAll().stream().map(masUsersMapper::toModel).collect(Collectors.toCollection(LinkedList::new));
		}
		if(isEmptyOrNull(userDTO.getLastName())) {
			return userRepository.findAllByUserNameOrFirstNameOrEmail(userDTO.getUserName(), userDTO.getFirstName(), userDTO.getEmail()).stream().map(masUsersMapper::toModel).collect(Collectors.toCollection(LinkedList::new));
		} else {
			return userRepository.findAllByUserNameOrFirstNameOrLastNameOrEmail(userDTO.getUserName(), userDTO.getFirstName(), userDTO.getLastName(), userDTO.getEmail()).stream().map(masUsersMapper::toModel).collect(Collectors.toCollection(LinkedList::new));
		}
	}
	
	private boolean isEmptyOrNull(String value) {
		return value.isEmpty() || Objects.isNull(value);
	}

	@Override
	public List<UserIdAndName> getUsersByTeamId(Integer teamId) {
		return userRepository.findAllByUserTeamId(teamId);
	}

	@Override
	public Long getUserByNameOrEmail(String user) {
		Long userId = null;
		UserIdAndName userDao = userRepository.findAllByUserNameOrEmail(user,user);
		return userDao != null ? userDao.getUserId() :userId;
	}

	@Override
	public List<MasUsers> getUsersListByTeamId(Long teamId) {
		return masUsersMapper.toModel(userRepository.findMasUsersEntitiesByUserTeamId(teamId));
	}


	private synchronized Optional<MasUsers>  decryptUserAddress(Optional<MasUsers>  masUserModel){
		masUserModel.ifPresent(item -> {
			item.setUserAddress1(SmartpraEncryptionUtil.decrypt(item.getUserAddress1()));
			item.setUserAddress2(SmartpraEncryptionUtil.decrypt(item.getUserAddress2()));
			item.setUserAddress3(SmartpraEncryptionUtil.decrypt(item.getUserAddress3()));
		});

		return  masUserModel;
	}

	
	/* (non-Javadoc)
	 * @see com.sgl.smartpra.service.MasUserService#getFunctionDetails(java.lang.String)
	 */
	public UserDetail getFunctionDetails(String email) {
		
		Map<Long, Map<String, List<String>>> functionMap = new HashMap<>(); 
		 Optional<MasUsersEntity> masUserRolesByEmail = userRepository.findOneWithMasUserRolesByEmail(email);
		 Set<String> menus = new HashSet<>();
		 UserDetail userDetail = new UserDetail();
		 if(masUserRolesByEmail.isPresent()) {
			 masUserRolesByEmail.get().getMasUserRoles()
			 .forEach(userRole -> {
				 if(userRole.getIsActive()) {
					 List<MasRoleFunctionEntity> roleFunctions = masRoleFunctionRepository.findAllByMasRoleEntityAndIsActiveIsTrue(userRole.getMasRole());
					 roleFunctions.forEach(roleFunction -> {
						 if(roleFunction.getIsActive()) {
							 constructPrivilages(functionMap, menus, roleFunction);
						 }
					 });
				 }
			 });
			 userDetail.setDisplayName(masUserRolesByEmail.get().getDisplayName());
			 byte[] userPhoto = masUserRolesByEmail.get().getUserPhoto();
			 if(Objects.nonNull(userPhoto)) {
				 userDetail.setUserPhoto(Arrays.copyOf( userPhoto, userPhoto.length ));
			 }
		 }
		 
		 List<RoleActionPrivileges> rolePrevillages = new ArrayList<>();
			functionMap.entrySet().forEach(outerMap -> {
				outerMap.getValue().entrySet().forEach(innerMap -> {
					RoleActionPrivileges roleActionPrivileges  = new RoleActionPrivileges(outerMap.getKey(), innerMap.getKey(), innerMap.getValue());
					rolePrevillages.add(roleActionPrivileges);
				});
			});
			
			 userDetail.setFunction(rolePrevillages);
			 userDetail.setMenus(menus);
			return userDetail;
	}

	private void constructPrivilages(Map<Long, Map<String, List<String>>> functionMap, Set<String> menus,
			MasRoleFunctionEntity roleFunction) {
		FunctionActionsEntity masFunctionAction = roleFunction.getFunctionActionsEntity();
		Long screenFunctionId = masFunctionAction.getScreenFunctionEntity().getScreenFunctionId();
		String functionDesc = masFunctionAction.getScreenFunctionEntity().getScreenFunctiondescription().trim();
		String actionDesc = masFunctionAction.getActionEntity().getActionDescription();
		if (functionMap.containsKey(screenFunctionId)) {
			Map<String, List<String>> functionActionMap = functionMap.get(screenFunctionId);
			List<String> functionAction = functionActionMap.get(functionDesc);
			functionAction.add(actionDesc);
			functionActionMap.put(functionDesc, functionAction);
			functionMap.put(screenFunctionId, functionActionMap);
		} else {
			Map<String, List<String>> functionActionMap = new HashMap<>();
			List<String> functionAction = new ArrayList<>();
			functionAction.add(actionDesc);
			functionActionMap.put(functionDesc, functionAction);
			functionMap.put(screenFunctionId, functionActionMap);
			ScreenFunctionEntity scrnEntity= new ScreenFunctionEntity();
			scrnEntity.setScreenFunctionId(screenFunctionId);
			MasMenuFunctionEntity menuFunctionEntity = masMenuFunctionRepository.findByMasFunction(scrnEntity);
			MasMenuEntity masMenuEntity = menuFunctionEntity.getMasMenu();
			while (!menus.contains(masMenuEntity.getMenuDescription().trim()) &&
					Objects.nonNull(masMenuEntity.getParentCode())) {
				menus.add(masMenuEntity.getMenuDescription().trim());
				masMenuEntity = masMenuRepository.findByMenuDescription(masMenuEntity.getParentCode());
			} 
			if(!menus.contains(masMenuEntity.getMenuDescription().trim()) && 
					Objects.isNull(masMenuEntity.getParentCode())) {
				menus.add(masMenuEntity.getMenuDescription().trim());
			}
			menus.add(functionDesc);
		}
	}
	
}