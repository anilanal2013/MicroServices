package com.sgl.smartpra.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.service.model.MasUserRole;

import java.util.Optional;

/**
 * Service Interface for managing MasUserRoleEntity.
 */
public interface MasUserRoleService {

    /**
     * Save a masUserRole.
     *
     * @param masUserRoleDTO the entity to save
     * @return the persisted entity
     */
    MasUserRole save(MasUserRole masUserRoleDTO);

    /**
     * Get all the masUserRoles.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<MasUserRole> findAll(Pageable pageable);


    /**
     * Get the "id" masUserRole.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<MasUserRole> findOne(Long id);

    /**
     * Delete the "id" masUserRole.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
