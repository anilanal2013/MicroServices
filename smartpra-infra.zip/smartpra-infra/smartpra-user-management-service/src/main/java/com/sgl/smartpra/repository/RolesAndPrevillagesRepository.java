package com.sgl.smartpra.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.domain.RoleFunctionActionEntity;
import com.sgl.smartpra.domain.RoleFunctionActionsEntity;

/*@Repository*/
public interface RolesAndPrevillagesRepository extends JpaRepository<RoleFunctionActionEntity, Long> {
/*	@Query("SELECT roleFunction FROM RoleFunctionActionEntity roleFunction,MasRoleEntity masRole WHERE masRole.roleId=roleFunction.masRole.roleId and masRole.roleName LIKE %?1%")
	List<RoleFunctionActionEntity> serachRole(String role);

	@Query("SELECT new com.sgl.smartpra.domain.RoleFunctionActionsEntity(masRole.roleName,screen.screenFunctionName,actions.action) FROM RoleFunctionActionEntity roleFunction,MasRoleEntity masRole ,FunctionActionsEntity functionActions,ScreenFunctionEntity screen,ActionEntity actions"
			+ " WHERE masRole.roleId=roleFunction.masRole.roleId and roleFunction.functionActions.functionActionId=functionActions.functionActionId and masRole.roleName=?1")
	List<RoleFunctionActionsEntity> getRolesAndPrevillages(String role);*/
}

