package com.sgl.smartpra.service.impl;

import com.sgl.smartpra.service.MasUserPasswordService;
import com.sgl.smartpra.domain.MasUserPasswordEntity;
import com.sgl.smartpra.repository.MasUserPasswordRepository;
import com.sgl.smartpra.service.mapper.MasUserPasswordMapper;
import com.sgl.smartpra.service.model.MasUserPassword;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing MasUserPasswordEntity.
 */
@Service
@Transactional
public class MasUserPasswordServiceImpl implements MasUserPasswordService {

    private final Logger log = LoggerFactory.getLogger(MasUserPasswordServiceImpl.class);

    private final MasUserPasswordRepository masUserPasswordRepository;

    private final MasUserPasswordMapper masUserPasswordMapper;

    public MasUserPasswordServiceImpl(MasUserPasswordRepository masUserPasswordRepository, MasUserPasswordMapper masUserPasswordMapper) {
        this.masUserPasswordRepository = masUserPasswordRepository;
        this.masUserPasswordMapper = masUserPasswordMapper;
    }

    /**
     * Save a masUserPassword.
     *
     * @param masUserPasswordDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public MasUserPassword save(MasUserPassword masUserPasswordDTO) {
        log.debug("Request to save MasUserPasswordEntity : {}", masUserPasswordDTO);
        MasUserPasswordEntity masUserPassword = masUserPasswordMapper.toEntity(masUserPasswordDTO);
        masUserPassword = masUserPasswordRepository.save(masUserPassword);
        return masUserPasswordMapper.toModel(masUserPassword);
    }

    /**
     * Get all the masUserPasswords.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<MasUserPassword> findAll(Pageable pageable) {
        log.debug("Request to get all MasUserPasswords");
        return masUserPasswordRepository.findAll(pageable)
            .map(masUserPasswordMapper::toModel);
    }


    /**
     * Get one masUserPassword by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<MasUserPassword> findOne(Long id) {
        log.debug("Request to get MasUserPasswordEntity : {}", id);
        return masUserPasswordRepository.findById(id)
            .map(masUserPasswordMapper::toModel);
    }

    /**
     * Delete the masUserPassword by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete MasUserPasswordEntity : {}", id);        masUserPasswordRepository.deleteById(id);
    }
}
