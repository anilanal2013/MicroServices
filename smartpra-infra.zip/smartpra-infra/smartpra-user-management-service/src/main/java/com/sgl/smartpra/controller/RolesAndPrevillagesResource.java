/*package com.sgl.smartpra.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.service.ScreenFunctionRoleActionService;
import com.sgl.smartpra.service.model.RoleFunction;

@RestController("/api")
public class RolesAndPrevillagesResource {
	@Autowired
	private ScreenFunctionRoleActionService service;

	private static final String ENTITY_NAME = "roleFunctionAction";

	@PostMapping("/roles-function-actions")
	public ResponseEntity<RoleFunction> saveRolesAndPrevillages(@RequestBody RoleFunction roleFunctionDto)
			throws URISyntaxException {
		if (roleFunctionDto.getRoleFunctionActionId() != null) {
			throw new BadRequestAlertException("A new roleFunctionAction cannot already have an ID", ENTITY_NAME,
					"idexists");
		}
		RoleFunction result = service.saveEntity(roleFunctionDto);
		return ResponseEntity.created(new URI("/api/roles-function-actions/" + result.getRoleFunctionActionId()))
				.headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.toString())).body(result);
	}

	@GetMapping("/roles-function-actions/{role}")
	public ResponseEntity<List<RoleFunction>> getRolesAndPrevillagesByRoleID(@PathVariable String role) {
		return ResponseEntity.ok().body(service.searchRole(role));
	}

	@PutMapping("/roles-function-actions/{id}")
	public ResponseEntity<RoleFunction> updateRolesAndPrevillages(Long id,
			@RequestBody RoleFunction roleFunctionDto) throws URISyntaxException {
		System.out.println("Is the entity " + roleFunctionDto);
		RoleFunction result = service.saveEntity(roleFunctionDto);
		return ResponseEntity.created(new URI("/api/roles-function-actions/" + result.getRoleFunctionActionId()))
				.headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.toString())).body(result);
	}

	@SuppressWarnings("unchecked")
	@DeleteMapping("/roles-function-actions/{id}")
	public ResponseEntity<Void> uofateRolesAndPrevillages(Long id) throws URISyntaxException {
		service.deleteeRoleFunctionAction(id);
		return (ResponseEntity<Void>) ResponseEntity.ok();
	}

	
	
}
*/