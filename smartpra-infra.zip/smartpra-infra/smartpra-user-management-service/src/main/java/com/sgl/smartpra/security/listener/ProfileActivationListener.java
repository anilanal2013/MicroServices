package com.sgl.smartpra.security.listener;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.service.MasUserLoginService;
import com.sgl.smartpra.service.model.MasUserLogin;
/**
 * 
 * @author mansound1
 *
 */
@Component
public class ProfileActivationListener implements ApplicationListener<ProfileActivationEvent>{

	

	@Autowired
	MasUserLoginService masUserLoginService ;
	
    @Autowired
    private HttpServletRequest request;

	
	@Override
	public void onApplicationEvent(final ProfileActivationEvent event) {
		Optional<MasUserLogin> useLoginDTO = masUserLoginService.findOneByUser(event.getUser().getUserId());
		MasUserLogin masUserLogin = useLoginDTO.isPresent() ? useLoginDTO.get() : new MasUserLogin();
		masUserLoginService.save(buildMasUserLoginDTO(masUserLogin));
	}
	
	
	
	private MasUserLogin buildMasUserLoginDTO(MasUserLogin useLoginDTO){
		
		MasUserLogin masUserLoginDTO =useLoginDTO;
		masUserLoginDTO.setUserLoginIsactive(true);
		masUserLoginDTO.setIsFirstTimeLogin(true);
		masUserLoginDTO.setIsLoginLocked(false);
		masUserLoginDTO.setLastLoggedInIpAddress(getClientIP());
		return masUserLoginDTO;
		
	}
	
	private final String getClientIP() {
		String ipAddress = "127.0.0.1";
		try {
			final String xfHeader = request.getHeader("X-Forwarded-For");
			if (xfHeader == null) {
				ipAddress = request.getRemoteAddr();
			} else {
				return xfHeader.split(",")[0];
			}
		} catch (Exception e) {
			
		}
		return ipAddress;
	}  


}
