package com.sgl.smartpra.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.controller.error.BadRequestAlertException;
import com.sgl.smartpra.controller.util.HeaderUtil;
import com.sgl.smartpra.controller.util.ResponseUtil;
import com.sgl.smartpra.service.MasRoleService;
import com.sgl.smartpra.service.model.MasRole;

/**
 * REST controller for managing MasRoleEntity.
 */
@RestController
@RequestMapping("/api")
public class MasRoleResource {

    private final Logger log = LoggerFactory.getLogger(MasRoleResource.class);

    private static final String ENTITY_NAME = "masRole";

    private final MasRoleService masRoleService;

    public MasRoleResource(MasRoleService masRoleService) {
        this.masRoleService = masRoleService;
    }

    /**
     * POST  /mas-roles : Create a new masRole.
     *
     * @param masRoleDTO the masRoleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new masRoleDTO, or with status 400 (Bad Request) if the masRole has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/mas-roles")
    public ResponseEntity<Object> createMasRole(@RequestBody MasRole masRoleDTO) throws URISyntaxException {
			log.debug("REST request to save MasRoleEntity : {}", masRoleDTO);
			if (masRoleDTO.getRoleId() != null) {
			    throw new BadRequestAlertException("A new masRole cannot already have an ID", ENTITY_NAME, "idexists");
			}
			MasRole result= new MasRole();
			result = Objects.isNull(masRoleService.findByRoleName(masRoleDTO.getRoleName())) ?
					masRoleService.save(masRoleDTO) : null;
			return Objects.nonNull(result) ? ResponseEntity.created(new URI("/api/mas-roles/" + result.getRoleId()))
				    .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getRoleId().toString()))
				    .body(result) : ResponseEntity.ok()
				    .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, "Role already exists"))
				    .body("Role already exists");
    }

    /**
     * PUT  /mas-roles : Updates an existing masRole.
     *
     * @param masRoleDTO the masRoleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated masRoleDTO,
     * or with status 400 (Bad Request) if the masRoleDTO is not valid,
     * or with status 500 (Internal Server Error) if the masRoleDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/mas-roles")
    public ResponseEntity<MasRole> updateMasRole(@RequestBody MasRole masRoleDTO) throws URISyntaxException {
        log.debug("REST request to update MasRoleEntity : {}", masRoleDTO);
        if (masRoleDTO.getRoleId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasRole result = masRoleService.save(masRoleDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, masRoleDTO.getRoleId().toString()))
            .body(result);
    }

    /**
     * GET  /mas-roles : get all the masRoles.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of masRoles in body
     */
    @GetMapping("/mas-roles")
    public ResponseEntity<List<MasRole>> getAllMasRoles() {
        log.debug("REST request to get a page of MasRoles");
        List<MasRole> roleList = masRoleService.findAll();
        return new ResponseEntity<>(roleList, HttpStatus.OK);
    }

    /**
     * GET  /mas-roles/:id : get the "id" masRole.
     *
     * @param id the id of the masRoleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the masRoleDTO, or with status 404 (Not Found)
     */
    @GetMapping("/mas-roles/{id}")
    public ResponseEntity<MasRole> getMasRole(@PathVariable Long id) {
        log.debug("REST request to get MasRoleEntity : {}", id);
        Optional<MasRole> masRoleDTO = masRoleService.findOne(id);
        return ResponseUtil.wrapOrNotFound(masRoleDTO);
    }

    /**
     * DELETE  /mas-roles/:id : delete the "id" masRole.
     *
     * @param id the id of the masRoleDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/mas-roles/{id}")
    public ResponseEntity<Void> deleteMasRole(@PathVariable Long id) {
        log.debug("REST request to delete MasRoleEntity : {}", id);
        masRoleService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
    
    /**
     * Method to fetch MasRole by role name
     * 
     * @param String roleName
     * @return object either MasRole or string
     */
    @GetMapping("/mas-role")
    public Object getByRoleName(@RequestParam(value = "roleName", required = true) String roleName){
    	MasRole masRole = masRoleService.findByRoleName(roleName);
    	return Objects.nonNull(masRole) ? masRole : "Role is not present in DB";
    }
}
