package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.MasGroupEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * Spring Data  repository for the MasGroupEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MasGroupRepository extends JpaRepository<MasGroupEntity, Long> {

    MasGroupEntity findMasGroupEntitiesByGroupId(Long groupId);

    List<MasGroupEntity> findMasGroupEntitiesAndMasTeamsByModuleId(Integer moduleId);




}
