package com.sgl.smartpra.repository;

import com.sgl.smartpra.domain.MasUserModuleEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the MasUserModuleEntity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MasUserModuleRepository extends JpaRepository<MasUserModuleEntity, Long> {

}
