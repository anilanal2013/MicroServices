package com.sgl.smartpra.integration.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CheckDigitOut {
	private Integer value;
	private String errorCode;
	private String errorMsg;
}
