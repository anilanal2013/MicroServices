package com.sgl.smartpra.integration.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;


import lombok.Data;

@Data
public class DualUtilizationModel {
	
	private Integer dualUtilizationId;

	private BigDecimal admAmount;

	private Date admDate;

	private String admInvoice;

	private Long admNumber;

	private String agencyCode;

	private String batchKey1;

	private String batchKey2;

	private String batchKey3;

	private String batchKey4;

	private Date batchKey5;

	private Date batchKey6;

	private String billedAirlineCode;

	private String clientId;

	private Integer couponNumber;

	private String createdBy;

	private Timestamp createdDate;

	private String currencyOfAdm;

	private String discrepancyStatus;

	private String documentNumber;

	private String documentUniqueId;

	private String issueAirline;

	private String lastUpdatedBy;

	private Timestamp lastUpdatedDate;

	private String lastUpdatedProgramName;

	private String orderId;

	private String remarks;

	private Integer serialNumber;

	private Date utilizationDate;

	private String utilizationType;
	
	private String fromAirport;
	
	private String toAirport;
	
	private String dualUtilDescription;
}
