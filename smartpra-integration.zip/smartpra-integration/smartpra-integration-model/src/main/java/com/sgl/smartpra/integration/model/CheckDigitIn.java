package com.sgl.smartpra.integration.model;

import java.time.LocalDate;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class CheckDigitIn {
	
	@NotNull(message = "Coupon Number is required")
	@Range(min=1, max = 4, message = "Invalid Coupon Number")
	private Integer couponNumber;
	
	@NotNull(message = "Carieer Numeric Number is required")
	@NotEmpty(message = "Invalid Carieer Numeric Number")
	@Size(min = 3, max = 3, message = "Invalid Carieer Numeric Number")
	private String carieerNumericCode;
	
	@NotNull(message = "Document Number is required")
	@NotEmpty(message = "Invalid Document Number")
	@Size(min = 10, max = 10, message = "Invalid Document Number")
	private String documentNumber;
	
	@NotNull(message = "Date of Issue is required")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate effectiveDate;
}
