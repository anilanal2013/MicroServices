package com.sgl.smartpra.integration.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.integration.entity.DualUtilizationEntity;

@Repository
@Transactional
public interface DualUtilizationRepository extends JpaRepository<DualUtilizationEntity, Integer> {
	
	@Query(value="select dual from DualUtilizationEntity dual where  dual.couponNumber=:couponNumber and dual.documentUniqueId=:documentUniqueId")
	public List<DualUtilizationEntity> findByCpnoAndDocumentUniqueId(@Param ("couponNumber") Integer couponNumber,@Param ("documentUniqueId") String documentUniqueId);

	@Query(value="select count(*) from DualUtilizationEntity dual where  couponNumber=:couponNumber and documentUniqueId=:documentUniqueId ")
	public Integer findCountByCpnoAndDocumentUniqueId(@Param ("couponNumber")  Integer couponNumber,@Param ("documentUniqueId")  String documentUniqueId);
	
	
	@Query(value="select dual from DualUtilizationEntity dual where dual.documentUniqueId=:documentUniqueId Order By couponNumber")
	public List<DualUtilizationEntity> findByDocumentUniqueIdOrderByCpnNo(@Param ("documentUniqueId") String documentUniqueId);

	
}
