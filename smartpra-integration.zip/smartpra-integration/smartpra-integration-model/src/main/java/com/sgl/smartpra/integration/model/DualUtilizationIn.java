package com.sgl.smartpra.integration.model;

import java.util.Optional;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;

@Data
public class DualUtilizationIn{	

	@RequiredNotEmpty(message = "Please provide documentUniqueId")
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Integer> couponNumber;

	@RequiredNotEmpty(message = "Please provide document Number")
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> documentNumber;

	@RequiredNotEmpty(message = "Please provide documentUniqueId")
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> documentUniqueId;

	@RequiredNotEmpty(message = "Please provide issueAirline")
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, message = "issueAirline  should be minimum of 3 and maximum of 3 character")
	private Optional<String> issueAirline;

	private Optional<String> orderId;
	
	@RequiredNotEmpty(message = "Please provide utilizationDate")
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", message="Required Date Pattern is yyyy-MM-dd")
	private Optional<String> utilizationDate;
	
	@RequiredNotEmpty(message = "Please provide utilizationDate")
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 1, message = "utilization Type  should be minimum of 1 and maximum of 1 character")
	private Optional<String> utilizationType;
	
	private Optional<String> batchKey1;

	private Optional<String> batchKey2;

	private Optional<String> batchKey3;

	private Optional<String> batchKey4;

	@DateFormat(pattern = "yyyy-MM-dd")
	private Optional<String> batchKey5;

	@DateFormat(pattern = "yyyy-MM-dd")
	private Optional<String> batchKey6;

}
