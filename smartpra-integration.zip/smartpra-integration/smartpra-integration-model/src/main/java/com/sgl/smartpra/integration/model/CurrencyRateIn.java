package com.sgl.smartpra.integration.model;

import java.math.BigDecimal;
import java.util.Optional;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.ValidValues;

import lombok.Data;

@Data
public class CurrencyRateIn {
	
	@RequiredNotEmpty(message = "Please provide from currency code")
	@FieldSize(min = 3, max = 3, message = "Currency From Code should be 3-alpha code")
	private Optional<String> currencyFromCode;
	
	@RequiredNotEmpty(message = "Please provide to curreny code")
	@FieldSize(min = 3, max = 3, message = "Currency To Code should be 3-alpha code")
	private Optional<String> currencyToCode;
	
	@ValidValues(values = "BSR,BKR,MMR,FDR,ROE", message = "Currency Rate Type should be any of the following: BSR, BKR, MMR, FDR, ROE")
	@FieldSize(min = 3, max = 3, message = "Rate Type should be 3-alpha code")
	@RequiredNotEmpty(message = "Please provide rate type")
	private Optional<String> rateType;
	
	@RequiredNotEmpty(message = "Please provide conversion date")
	@DateFormat(pattern = "yyyy-MM-dd")
	private Optional<String> conversionDate;
	
	private Optional<BigDecimal> amount;
	
	@RequiredNotEmpty(message = "Please provide Client Id")
	@FieldSize(min = 2, max = 2, message = "Client Id should be 2-alpha code")
	private Optional<String> clientId;

}
