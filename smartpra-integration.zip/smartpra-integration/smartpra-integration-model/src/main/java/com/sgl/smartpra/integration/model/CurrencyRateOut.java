package com.sgl.smartpra.integration.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class CurrencyRateOut {

	private BigDecimal exchangeRate;
	
	private BigDecimal outAmount;
	
	private BigDecimal normalizedAmount;
	
	private String errorCode;
}
