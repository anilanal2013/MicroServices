package com.sgl.smartpra.integration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;


@Entity
@Table(name="dual_utilization",schema="SmartPRASales")
@Data
public class DualUtilization implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="dual_utilization_id")
	private Integer dualUtilizationId;

	@Column(name="adm_amount")
	private BigDecimal admAmount;

	@Column(name="adm_date")
	private Date admDate;

	@Column(name="adm_invoice")
	private String admInvoice;

	@Column(name="adm_number")
	private Long admNumber;

	@Column(name="agency_code")
	private String agencyCode;

	@Column(name="batch_key_1")
	private String batchKey1;

	@Column(name="batch_key_2")
	private String batchKey2;

	@Column(name="batch_key_3")
	private String batchKey3;

	@Column(name="batch_key_4")
	private String batchKey4;

	@Column(name="batch_key_5")
	private Date batchKey5;

	@Column(name="batch_key_6")
	private Date batchKey6;

	@Column(name="billed_airline_code")
	private String billedAirlineCode;

	@Column(name="client_id")
	private String clientId;

	@Column(name="coupon_number")
	private Integer couponNumber;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="currency_of_adm")
	private String currencyOfAdm;

	@Column(name="discrepancy_status")
	private String discrepancyStatus;

	@Column(name="document_number")
	private String documentNumber;

	@Column(name="document_unique_id")
	private String documentUniqueId;

	@Column(name="issue_airline")
	private String issueAirline;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="last_updated_program_name")
	private String lastUpdatedProgramName;

	@Column(name="order_id")
	private String orderId;

	private String remarks;

	@Column(name="serial_number")
	private Integer serialNumber;

	@Column(name="utilization_date")
	private Date utilizationDate;

	@Column(name="utilization_type")
	private String utilizationType;
}