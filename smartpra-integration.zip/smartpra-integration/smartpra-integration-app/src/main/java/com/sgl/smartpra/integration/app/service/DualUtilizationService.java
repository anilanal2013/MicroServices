package com.sgl.smartpra.integration.app.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sgl.smartpra.integration.model.DualUtilizationIn;
import com.sgl.smartpra.integration.model.DualUtilizationModel;

@Service
public interface DualUtilizationService {
	
	public Boolean createDualUtilization(DualUtilizationIn ticketCouponModel) throws Exception;
	
     List<DualUtilizationModel> searchDualUtilization(String documentUniqueId) throws Exception;

}
