package com.sgl.smartpra.integration.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.integration.app.service.CheckDigitDerivationService;
import com.sgl.smartpra.integration.model.CheckDigitIn;
import com.sgl.smartpra.integration.model.CheckDigitOut;

@RestController
@RequestMapping("/checkDigit")
public class CheckDigitDerivationController {

	@Autowired
	private CheckDigitDerivationService checkDigitDerivationService;

	@PostMapping("/deriveCheckDigit")
	public CheckDigitOut getCheckDigit(@Validated @RequestBody CheckDigitIn checkDigitIn) {

		return checkDigitDerivationService.getCheckDigit(checkDigitIn);

	}

}
