package com.sgl.smartpra.integration.app.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.integration.app.service.ExchangeRateService;
import com.sgl.smartpra.integration.model.CurrencyRateIn;
import com.sgl.smartpra.integration.model.CurrencyRateOut;

/**
 * Controller class for exchange rate derivation
 * 
 * @author Sanjay Murali
 *
 */
@RestController
@RequestMapping("/integ")
public class ExchangeRateController {

	/** {@link ExchangeRateService} used to derive the exchange rate **/
	@Autowired
	private ExchangeRateService exchangeRateService;

	/**
	 * Method accepts the input for calculation of exchange rate derivation
	 * 
	 * @param currencyRateIn has the currency details of from and to conversion.
	 * @return currencyRateOut has the converted currency value
	 */
	@PostMapping("/erd")
	public CurrencyRateOut getExchangeRate(@Validated @RequestBody CurrencyRateIn currencyRateIn) {
		return exchangeRateService.getExchangeRate(currencyRateIn);
	}
	/**
	 * Method accepts the input to calculate normalized amount .
	 * 
	 * @param .currency code to get MIN value.
	 * @param .clientId logged in user's client id.
	 * @param .amount to be normalized
	 * @param .effectiveDate to get MIN value. 
	 * @return currencyRateOut contains normalized amount
	 */
	@GetMapping(value = "amount-normalization/{clientId}/{currencyCode}")
	public CurrencyRateOut getNormalizedAmountByCurrencyCode(
			@PathVariable(value = "clientId") Optional<String> clientId,
			@PathVariable(value = "currencyCode") Optional<String> currencyCode,
			@RequestParam(value = "amount", required = true) double amount,
			@RequestParam(value = "effectiveDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return exchangeRateService.getNormalizedAmountByCurrencyCode(currencyCode, clientId, amount, effectiveDate);

	}

}
