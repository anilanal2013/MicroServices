package com.sgl.smartpra.integration.app.service;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.sgl.smartpra.integration.model.CurrencyRateIn;
import com.sgl.smartpra.integration.model.CurrencyRateOut;

/**
 * Interface used to define functionality for currency conversion
 * 
 * @author Sanjay Murali
 *
 */
@Component
public interface ExchangeRateService {
	
	/**
	 * This method is used to calculate the exchange rate between two currency code.
	 * 
	 * @param currencyRateIn has the currency details of from and to conversion.
	 * @return currencyRateOut has the converted currency value
	 */
	public CurrencyRateOut getExchangeRate(CurrencyRateIn currencyRateIn);
	
	public CurrencyRateOut getNormalizedAmountByCurrencyCode(Optional<String> currencyCode, Optional<String> clientId,
			double amount, Optional<String> effectiveDate);

}
