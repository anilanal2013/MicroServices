package com.sgl.smartpra.integration.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.integration.app.service.ExceptionTxnMsgSenderService;
import com.sgl.smartpra.integration.app.util.ExceptionMasterIntegrationUtil;

@RestController
@RequestMapping("/api")
public class ExceptionIntegrationController {

	@Autowired
	private ExceptionTxnMsgSenderService exceptionTxnMsgSenderService;

	@PostMapping("/init-exceptionmessage")
	public void initExceptionMessage(@RequestBody ExceptionTransactionModel exceptionTransactionModel) {
		exceptionTxnMsgSenderService.sendToExceptionQueue(exceptionTransactionModel);
	}

	@Autowired
	private ExceptionMasterIntegrationUtil exceptionMasterIntegrationUtil;

	@GetMapping("/init-exceptionmessage")
	public void initExceptionMessageTest() {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionMasterIntegrationUtil.initExceptionMaster(exceptionTransactionModel);
	}

}
