package com.sgl.smartpra.integration.app.util;

public class DualUtilConstants {
	
	public static final String DUAL_UTZN_UNUTILIZED ="S";
	
	public static final String DUAL_UTZN_FOR_FLOWN ="U";
		
	public static final String DUAL_UTZN_FOR_REFUND ="R";
	
	public static final String DUAL_UTZN_FOR_REISSUE ="E";
	
	public static final String DUAL_UTZN_FOR_INWARD ="I";
	
	public static final String DUAL_UTZN_FOR_FIM ="F";
	
	public static final String DUAL_UTZN_FOR_WRITE_BACK ="W";
	
	public static final String DUAL_UTZN_GEN_EXCEP ="GEN1118";
	
	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";
	
	public static final String PARAM_DEFAULT_CARRIER_NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";
	
	public static final String CREATED_BY = "DualAdmin";
	
	public static final String DISCREPANCY_STATUS_N = "N";
	
	public static final String DISCREPANCY_STATUS_Y = "Y";
	
	public static final String DUAL_EXCEP_ENV ="P";
	
	public static final String EXCEPCODE_GEN1118="GEN1118";
	public static final String EXCEPCODE_GEN1118_PARAM_1 = "Coupon Number";
	public static final String EXCEPCODE_GEN1118_PARAM_2 = "Issue Airline";
	public static final String EXCEPCODE_GEN1118_PARAM_3 = "Document Number";
	public static final String EXCEPCODE_GEN1118_PARAM_4 = "Utilization Type";
	public static final String EXCEPCODE_GEN1118_PARAM_5 = "Document Type";
	
	
	

}
