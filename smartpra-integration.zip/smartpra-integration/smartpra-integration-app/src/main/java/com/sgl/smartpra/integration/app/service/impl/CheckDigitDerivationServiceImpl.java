package com.sgl.smartpra.integration.app.service.impl;

import java.time.format.DateTimeFormatter;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.integration.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.integration.app.service.CheckDigitDerivationService;
import com.sgl.smartpra.integration.app.util.ExceptionMasterIntegrationUtil;
import com.sgl.smartpra.integration.model.CheckDigitIn;
import com.sgl.smartpra.integration.model.CheckDigitOut;
import com.sgl.smartpra.master.model.FormCode;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CheckDigitDerivationServiceImpl implements CheckDigitDerivationService {
	@Autowired
	private MasterFeignClient masterFeignClient;

	@Override
	public CheckDigitOut getCheckDigit(CheckDigitIn checkDigitIn) {
		FormCode formCodeObj = null;
		String documentNumber = checkDigitIn.getDocumentNumber();
		for (int i = 3; i > 1 && Objects.isNull(formCodeObj); i--) {
			try {
				DateTimeFormatter formatter = ExceptionMasterIntegrationUtil.getDateTimeFormatter("yyyy-MM-dd");
				formCodeObj = masterFeignClient.getFormCodeByfromCodeAndEffectiveDate(
						StringUtils.substring(documentNumber, 0, i), checkDigitIn.getEffectiveDate().format(formatter));
			} catch (BusinessException e) {
				log.error(e.getMessage());
			} catch(Exception ex) {
				log.error(ex.getMessage());
			}
		}

		if (Objects.isNull(formCodeObj)) {
			return new CheckDigitOut(null, "LIFT3009", "Form code definition is not available in the form code master");
		}

		Integer checkDigit = null;
		String errorMsg = null;
		Integer couponNumber = checkDigitIn.getCouponNumber();
		String carieerNumericCode = checkDigitIn.getCarieerNumericCode();
		String exceptionCode = null;
		try {
			if (OptionalUtil.getValue(formCodeObj.getIncludeCouponCheckdigit())
					&& OptionalUtil.getValue(formCodeObj.getIncldAirlineCodeCheckdigit())) {
				checkDigit = (int) (Long.parseLong(couponNumber + carieerNumericCode + documentNumber) % 7);
			} else if (OptionalUtil.getValue(formCodeObj.getIncludeCouponCheckdigit())) {
				checkDigit = (int) (Long.parseLong(couponNumber + documentNumber) % 7);
			} else if (OptionalUtil.getValue(formCodeObj.getIncldAirlineCodeCheckdigit())) {
				checkDigit = (int) (Long.parseLong(carieerNumericCode + documentNumber) % 7);
			} else {
				checkDigit = (int) (Long.parseLong(documentNumber) % 7);
			}

		} catch (Exception ex) {
			exceptionCode = "LIFT3006";
			errorMsg = "technical error";
		}
		return new CheckDigitOut(checkDigit, exceptionCode, errorMsg);
	}

}
