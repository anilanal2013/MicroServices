package com.sgl.smartpra.integration.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.exception.txn.model.validator.ModelValidator;
import com.sgl.smartpra.integration.app.config.FeignConfiguration.ExceptionMasterAppFeignClient;
import com.sgl.smartpra.mq.producer.Producer;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ExceptionTxnMsgSenderService {

	@Autowired
	private Producer producer;

	@Autowired
	private ModelValidator modelValidator;

	@Autowired
	private ExceptionMasterAppFeignClient exceptionMasterAppFeignClient;

	@Value("${rabbitmq.exchange}")
	private String exchange;

	@Value("${rabbitmq.exception.msg.routingKey}")
	private String routingKey;

	public void sendToExceptionQueue(ExceptionTransactionModel exceptionTransactionModel) {
		try {
			modelValidator.validate(exceptionTransactionModel,
					exceptionMasterAppFeignClient.findByExceptionCode(exceptionTransactionModel.getExceptionCode()));
			producer.send(exchange, routingKey, exceptionTransactionModel);
		} catch (Exception e) {
			log.error("Exception occurred in {}, E={}", this.getClass().getSimpleName(), e);
			throw e;
		}
	}
}
