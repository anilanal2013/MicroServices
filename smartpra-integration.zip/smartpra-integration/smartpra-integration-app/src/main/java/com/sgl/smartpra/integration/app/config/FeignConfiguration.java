package com.sgl.smartpra.integration.app.config;

import java.sql.Date;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.currency.model.CurrencyRate;
import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.master.model.CurrencyToleranceDetails;
import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.master.model.SystemParameter;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-exception-master-app")
	public interface ExceptionMasterAppFeignClient {

		@GetMapping("/exception/findByExceptionCode/{exceptionCode}")
		public ExceptionMasterModel findByExceptionCode(@PathVariable(value = "exceptionCode") String exceptionCode);

	}
	
	@FeignClient(value = "smartpra-global-master-app")
	public interface GlobalMasterFeignClient {
		@GetMapping("/currencies/{currencyCode}/validate")
		public boolean validateCurrencyCode(@PathVariable(value = "currencyCode") String currencyCode);
	}

	@FeignClient(value = "smartpra-master-app")
	public interface MasterFeignClient {

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(
				@PathVariable(value = "parameterName") String parameterName);
		
		@GetMapping("/system-parameters-with-date/clientId/{clientId}/parameterName/{parameterName}")
		public SystemParameter getSystemParameterByparameterNameAndClientId(
				@PathVariable(value = "parameterName", required = true) String parameterName,
				@PathVariable(value = "clientId", required = true) String clientId);

		@GetMapping("/form-code/formcode-date-search")
		public FormCode getFormCodeByfromCodeAndEffectiveDate(
				@RequestParam(value = "formCode", required = true) String formCode,
				@RequestParam(value = "effectiveDate", required = true) @DateFormat(pattern = "yyyy-MM-dd") String effectiveDate);
		
		@GetMapping("/billing-period/start-date/{billingMonth}/{billingPeriod}")
		public Date getOutwardBillingPeriodsEndDate(@PathVariable(value = "billingMonth") String billingMonth,
				@PathVariable(value = "billingPeriod") Integer billingPeriod);
		
		@GetMapping("/billing-period/billing-month-periods/{billingMonth}/{billingPeriod}")
		public List<OutwardBillingPeriods> getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriodV(
				@PathVariable(value = "billingMonth", required = true) String billingMonth,
				@PathVariable(value = "billingPeriod", required = true) Integer billingPeriod);

		@GetMapping(value = "/currency-tolerance/{currencyCode}/clientId/{clientId}")
		public CurrencyToleranceDetails getListOfCurrencyTolerance(
				@PathVariable(value = "currencyCode") String currencyCode,
				@PathVariable(value = "clientId") String clientId,
				@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") String effectiveFromDate);

	}

	@FeignClient(value = "smartpra-currency-master-app")
	public interface CurrencyFeignClient {

		@GetMapping("/currency/{currencyRateType}/{currencyFromCode}/{currencyToCode}/{effectiveDate}")
		public CurrencyRate getEffectiveCurrencyRate(
				@PathVariable(value = "currencyRateType", required = true) String currencyRateType,
				@PathVariable(value = "currencyFromCode", required = true) String currencyFromCode,
				@PathVariable(value = "currencyToCode", required = true) String currencyToCode,
				@PathVariable(value = "effectiveDate", required = true) String effectiveDate);

	}

}
