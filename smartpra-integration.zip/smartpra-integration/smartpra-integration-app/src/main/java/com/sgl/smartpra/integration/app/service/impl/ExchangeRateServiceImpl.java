package com.sgl.smartpra.integration.app.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.currency.model.CurrencyRate;
import com.sgl.smartpra.integration.app.config.FeignConfiguration.CurrencyFeignClient;
import com.sgl.smartpra.integration.app.config.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.integration.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.integration.app.service.ExchangeRateService;
import com.sgl.smartpra.integration.model.CurrencyRateIn;
import com.sgl.smartpra.integration.model.CurrencyRateOut;
import com.sgl.smartpra.master.model.CurrencyToleranceDetails;
import com.sgl.smartpra.master.model.SystemParameter;

import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of {@code ExchangeRateService} for currency conversion
 * 
 * @author Sanjay Murali
 *
 */
@Service
@Slf4j
public class ExchangeRateServiceImpl implements ExchangeRateService {

	/** masterFeignClient to fetch details of system config details **/
	@Autowired
	private MasterFeignClient masterFeignClient;
	@Autowired
	private GlobalMasterFeignClient globalMasterFeignClient;
	/** currencyFeignClient to get the exchange rate **/
	@Autowired
	private CurrencyFeignClient currencyFeignClient;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.sgl.smartpra.integration.app.service.ExchangeRateService#getExchangeRate(
	 * com.sgl.smartpra.integration.model.CurrencyRateIn)
	 */
	@Override
	public CurrencyRateOut getExchangeRate(CurrencyRateIn currencyRateIn) {
		CurrencyRateOut currencyRateOut = null;
		BigDecimal exchangeRate;
		if (OptionalUtil.getValue(currencyRateIn.getCurrencyFromCode())
				.equalsIgnoreCase(OptionalUtil.getValue(currencyRateIn.getCurrencyToCode()))) {
			BigDecimal amount = OptionalUtil.isPresent(currencyRateIn.getAmount())
					? OptionalUtil.getValue(currencyRateIn.getAmount())
					: null;
			currencyRateOut = constructSuccessRateOut(new BigDecimal(1), amount);
		} else {
			switch (OptionalUtil.getValue(currencyRateIn.getRateType())) {
			case "BKR":
				currencyRateOut = BKRConversion(currencyRateIn);
				break;
			case "BSR":
				exchangeRate = fetchExchangeRate(currencyRateIn);
				currencyRateOut = Objects.nonNull(exchangeRate)
						? calculateOutAmout(currencyRateIn.getAmount(), exchangeRate)
						: constructFailureRateOut("GEN1040");
				break;
			case "ROE":
				if (OptionalUtil.getValue(currencyRateIn.getCurrencyFromCode()).equalsIgnoreCase("NUC")
						|| OptionalUtil.getValue(currencyRateIn.getCurrencyToCode()).equalsIgnoreCase("NUC")) {
					exchangeRate = fetchExchangeRate(currencyRateIn);
					currencyRateOut = Objects.nonNull(exchangeRate)
							? calculateOutAmout(currencyRateIn.getAmount(), exchangeRate)
							: constructFailureRateOut("GEN1040");
				} else {
					currencyRateOut = constructFailureRateOut("GEN3012");
				}
				break;
			case "MMR":
				currencyRateOut = MMRandFDRConversion(currencyRateIn);
				break;
			case "FDR":
				currencyRateOut = MMRandFDRConversion(currencyRateIn);
				break;
			default:
				currencyRateOut = constructFailureRateOut(null);
			}
		}
		if (currencyRateOut.getOutAmount() != null) {
			CurrencyRateOut normalizedOut = getNormalizedAmountByCurrencyCode(currencyRateIn.getCurrencyToCode(),
					currencyRateIn.getClientId(), currencyRateOut.getOutAmount().doubleValue(),
					currencyRateIn.getConversionDate());
			currencyRateOut.setOutAmount(normalizedOut.getNormalizedAmount());
			currencyRateOut.setErrorCode(normalizedOut.getErrorCode());
		}
		return currencyRateOut;
	}

	/**
	 * Implementation of currency conversion for MMR & FDR type
	 *
	 * @param currencyRateIn has the currency details of from and to conversion
	 * @return CurrencyRateOut has the converted currency value
	 */
	private CurrencyRateOut MMRandFDRConversion(CurrencyRateIn currencyRateIn) {
		CurrencyRateOut currencyRateOut;
		BigDecimal exchangeRate;
		List<SystemParameter> defaultCurrencyList = null;
		try {
			defaultCurrencyList = masterFeignClient.getSystemParameterByparameterName("IATA_BILLING_CURRENCY_CODES");
		} catch (Exception ex) {
			return currencyRateOut = constructFailureRateOut("GEN3015");
		}
		SystemParameter iataCurrency = !defaultCurrencyList.isEmpty() ? defaultCurrencyList.get(0) : null;
		List<String> iataCurrencyCodes = Objects.nonNull(OptionalUtil.getValue(iataCurrency.getParameterRangeFrom()))
				? Arrays.stream(OptionalUtil.getValue(iataCurrency.getParameterRangeFrom()).split(","))
						.map(String::trim).collect(Collectors.toList())
				: null;
		if (iataCurrencyCodes.isEmpty()) {
			return currencyRateOut = constructFailureRateOut("GEN3015");
		}

		if (iataCurrencyCodes.contains(OptionalUtil.getValue(currencyRateIn.getCurrencyFromCode()))
				&& iataCurrencyCodes.contains(OptionalUtil.getValue(currencyRateIn.getCurrencyToCode()))) {
			exchangeRate = checkDirectExchangeRate(currencyRateIn);
			currencyRateOut = Objects.nonNull(exchangeRate)
					? calculateOutAmout(currencyRateIn.getAmount(), exchangeRate)
					: constructFailureRateOut("GEN1040");
		} else if (iataCurrencyCodes.contains(OptionalUtil.getValue(currencyRateIn.getCurrencyFromCode()))
				|| iataCurrencyCodes.contains(OptionalUtil.getValue(currencyRateIn.getCurrencyToCode()))) {
			exchangeRate = fetchExchangeRate(currencyRateIn);
			currencyRateOut = Objects.nonNull(exchangeRate)
					? calculateOutAmout(currencyRateIn.getAmount(), exchangeRate)
					: constructFailureRateOut("GEN1040");
		} else {
			BigDecimal fromExchangeRate = checkExchangeRate(currencyRateIn,
					OptionalUtil.getValue(currencyRateIn.getCurrencyFromCode()), "USD");
			BigDecimal toExchangeRate = checkExchangeRate(currencyRateIn,
					OptionalUtil.getValue(currencyRateIn.getCurrencyToCode()), "USD");
			if (Objects.nonNull(fromExchangeRate) && Objects.nonNull(toExchangeRate)) {
				exchangeRate = fromExchangeRate.divide(toExchangeRate, 5, RoundingMode.DOWN);
				currencyRateOut = calculateOutAmout(currencyRateIn.getAmount(), exchangeRate);
			} else {
				currencyRateOut = constructFailureRateOut("GEN1040");
			}
		}
		return currencyRateOut;
	}

	/**
	 * Implementation of currency conversion for BKR type
	 * 
	 * @param currencyRateIn  has the currency details of from and to conversion
	 * @param currencyRateOut passed as a reference
	 * @return CurrencyRateOut has the converted currency value
	 */
	private CurrencyRateOut BKRConversion(CurrencyRateIn currencyRateIn) {
		CurrencyRateOut currencyRateOut = null;
		BigDecimal exchangeRate;
		SystemParameter defaultCurrencyParam = null;
		try {
			String clientId = null;
			if(currencyRateIn.getClientId().isPresent()) {
				clientId = currencyRateIn.getClientId().get();  
			}
			defaultCurrencyParam = masterFeignClient
					.getSystemParameterByparameterNameAndClientId("DEFAULT_CURRENCY_CODE", clientId); 
		} catch (Exception ex) {
			return currencyRateOut = constructFailureRateOut("GEN3015");
		}
		if (Objects.nonNull(defaultCurrencyParam)) {
			String fromMasterCurrencyCode = OptionalUtil.getValue(defaultCurrencyParam.getParameterRangeFrom());
			String toMasterCurrencyCode = OptionalUtil.getValue(defaultCurrencyParam.getParameterRangeTo());
			String fromCurrencyCode = OptionalUtil.getValue(currencyRateIn.getCurrencyFromCode());
			String toCurrencyCode = OptionalUtil.getValue(currencyRateIn.getCurrencyToCode());
			if (!(fromCurrencyCode.equalsIgnoreCase(fromMasterCurrencyCode)
					|| fromCurrencyCode.equalsIgnoreCase(toMasterCurrencyCode)
					|| toCurrencyCode.equalsIgnoreCase(fromMasterCurrencyCode)
					|| toCurrencyCode.equalsIgnoreCase(toMasterCurrencyCode))) {
				currencyRateOut = constructFailureRateOut("GEN3011");
			} else {
				exchangeRate = fetchExchangeRate(currencyRateIn);
				if (Objects.nonNull(exchangeRate)) {
					currencyRateOut = calculateOutAmout(currencyRateIn.getAmount(), exchangeRate);
				} else {
					currencyRateIn.setRateType(Optional.of("FDR"));
					currencyRateOut = MMRandFDRConversion(currencyRateIn);
				}
			}
		}
		return currencyRateOut;
	}

	/**
	 * Used to get the exchange rate between two currency
	 * 
	 * @param currencyRateIn   has the currency details of from and to conversion
	 * @param currencyFromCode from currency code
	 * @param currencyToCode   to currency code
	 * @return BigDecimal the exchange rate value
	 */
	private BigDecimal checkExchangeRate(CurrencyRateIn currencyRateIn, String currencyFromCode,
			String currencyToCode) {
		CurrencyRate effectiveCurrencyRate;
		try {
			effectiveCurrencyRate = currencyFeignClient.getEffectiveCurrencyRate(
					OptionalUtil.getValue(currencyRateIn.getRateType()), currencyFromCode, currencyToCode,
					OptionalUtil.getValue(currencyRateIn.getConversionDate()));
			return new BigDecimal(OptionalUtil.getValue(effectiveCurrencyRate.getExchangeRate()));
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Used to get the exchange rate between two currency
	 * 
	 * @param currencyRateIn has the currency details of from and to conversion
	 * @return BigDecimal the exchange rate value
	 */
	private BigDecimal fetchExchangeRate(CurrencyRateIn currencyRateIn) {
		BigDecimal exchangeRate;
		exchangeRate = checkDirectExchangeRate(currencyRateIn);
		if (Objects.isNull(exchangeRate)) {
			exchangeRate = checkReverseExchangeRate(currencyRateIn);
		}
		return exchangeRate;
	}

	/**
	 * Used to get the direct exchange rate between two currency
	 * 
	 * @param currencyRateIn has the details of the currency of from and to
	 *                       conversion.
	 * @return BigDecimal the exchange rate value
	 */
	private BigDecimal checkDirectExchangeRate(CurrencyRateIn currencyRateIn) {
		CurrencyRate effectiveCurrencyRate = null;
		try {
			effectiveCurrencyRate = currencyFeignClient.getEffectiveCurrencyRate(
					OptionalUtil.getValue(currencyRateIn.getRateType()),
					OptionalUtil.getValue(currencyRateIn.getCurrencyFromCode()),
					OptionalUtil.getValue(currencyRateIn.getCurrencyToCode()),
					OptionalUtil.getValue(currencyRateIn.getConversionDate()));
			return new BigDecimal(OptionalUtil.getValue(effectiveCurrencyRate.getExchangeRate()));
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Used to get the reverse exchange rate between two currency
	 * 
	 * @param currencyRateIn has the currency details of from and to conversion
	 * @return BigDecimal the exchange rate value
	 */
	private BigDecimal checkReverseExchangeRate(CurrencyRateIn currencyRateIn) {
		CurrencyRate effectiveCurrencyRate;
		try {
			effectiveCurrencyRate = currencyFeignClient.getEffectiveCurrencyRate(
					OptionalUtil.getValue(currencyRateIn.getRateType()),
					OptionalUtil.getValue(currencyRateIn.getCurrencyToCode()),
					OptionalUtil.getValue(currencyRateIn.getCurrencyFromCode()),
					OptionalUtil.getValue(currencyRateIn.getConversionDate()));
			BigDecimal exchangeRate = new BigDecimal(OptionalUtil.getValue(effectiveCurrencyRate.getExchangeRate()));
			BigDecimal baseValue = new BigDecimal("1");
			return baseValue.divide(exchangeRate, 5, RoundingMode.DOWN);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * used to calculate the conversion amount based on exchange rate
	 * 
	 * @param amount      the amount to be converted
	 * @param exhangeRate the conversion rate between two currency
	 * @return CurrencyRateOut has the converted currency value
	 */
	private CurrencyRateOut calculateOutAmout(Optional<BigDecimal> amount, BigDecimal exhangeRate) {
		BigDecimal divide = Objects.nonNull(amount) ? 
				OptionalUtil.getValue(amount).divide(exhangeRate, 5, RoundingMode.DOWN) : null;
		return constructSuccessRateOut(exhangeRate, divide);
	}

	/**
	 * construct positive exchange rate output
	 * 
	 * @param exchangeRate the conversion rate between two currency
	 * @param outAmount    the calculated output amount
	 * @return CurrencyRateOut has the converted currency value
	 */
	private CurrencyRateOut constructSuccessRateOut(BigDecimal exchangeRate, BigDecimal outAmount) {
		CurrencyRateOut currencyRateOut = new CurrencyRateOut();
		currencyRateOut.setExchangeRate(exchangeRate);
		currencyRateOut.setOutAmount(outAmount);
		return currencyRateOut;
	}

	/**
	 * construct failure exchange rate output
	 * 
	 * @param errorCode the error for failure
	 * @return CurrencyRateOut has the converted currency value
	 */
	private CurrencyRateOut constructFailureRateOut(String errorCode) {
		CurrencyRateOut currencyRateOut = new CurrencyRateOut();
		currencyRateOut.setErrorCode(errorCode);
		return currencyRateOut;
	}
	private CurrencyRateOut constructWithMinAmount(String normalAmount) {
		CurrencyRateOut currencyRateOut = new CurrencyRateOut();
		currencyRateOut.setNormalizedAmount(new BigDecimal(normalAmount));
		return currencyRateOut;
	}

	@Override
	public CurrencyRateOut getNormalizedAmountByCurrencyCode(Optional<String> currencyCode, Optional<String> clientId,
			double amount, Optional<String> effectiveDate) {
		boolean validateCurrencyCode = false;
		if (currencyCode.isPresent()) {
			validateCurrencyCode = globalMasterFeignClient.validateCurrencyCode(currencyCode.get());
		}
		if (!validateCurrencyCode) {
			return constructFailureRateOut("GEN3010");
		}
		if (currencyCode.isPresent() && clientId.isPresent()) {
			CurrencyToleranceDetails currencyToleranceDetailsList = masterFeignClient
					.getListOfCurrencyTolerance(currencyCode.get(), clientId.get(), effectiveDate.get());

			Optional<String> minimumValue = currencyToleranceDetailsList.getMinimumValue();
			if (minimumValue.isPresent()) {
				String normalizedAmount = getNormalizedAmount(Double.valueOf(minimumValue.get()), amount);
				return constructWithMinAmount(normalizedAmount);
			}
		}
		return constructFailureRateOut("GEN3018");
	}

	private String getNormalizedAmount(double minValue, double amount) {
		double fraction = amount / minValue;
		double roundedFloat = Math.round(fraction) * minValue;
		String format = "0.";
		String minValueStr = "" + minValue;
		int length = minValueStr.split("\\.")[1].length();
		for (int i = 0; i < length; i++) {
			format += "0";
		}
		String normalizedAmount = new DecimalFormat(format).format(roundedFloat);
		log.debug("Min Value: {} Amount: {} NormalizedAmount: {}", minValue,amount,normalizedAmount);
		return normalizedAmount;
	}

}
