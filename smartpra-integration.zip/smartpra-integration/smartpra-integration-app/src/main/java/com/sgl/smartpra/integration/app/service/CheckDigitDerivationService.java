package com.sgl.smartpra.integration.app.service;
import com.sgl.smartpra.integration.model.CheckDigitIn;
import com.sgl.smartpra.integration.model.CheckDigitOut;

public interface CheckDigitDerivationService {
	CheckDigitOut getCheckDigit(CheckDigitIn checkDigitIn);
}
	