package com.sgl.smartpra.integration.app.service.impl;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.CommonExceptionConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.domain.FlightDataDetailsEntity;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.repository.FlightDataDetailsRepository;
import com.sgl.smartpra.flown.repository.FlownCouponRepository;
import com.sgl.smartpra.integration.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.integration.app.service.DualUtilizationService;
import com.sgl.smartpra.integration.app.service.ExceptionTxnMsgSenderService;
import com.sgl.smartpra.integration.app.util.DualUtilConstants;
import com.sgl.smartpra.integration.entity.DualUtilizationEntity;
import com.sgl.smartpra.integration.model.DualUtilizationIn;
import com.sgl.smartpra.integration.model.DualUtilizationModel;
import com.sgl.smartpra.integration.repository.DualUtilizationRepository;
import com.sgl.smartpra.interline.domain.entity.prod.idec.IbBillingCoupon;
import com.sgl.smartpra.interline.domain.entity.prod.idec.IbInvBatch;
import com.sgl.smartpra.interline.domain.entity.prod.idec.IbInvoice;
import com.sgl.smartpra.interline.domain.repository.prod.idec.IbBillingCouponRepository;
import com.sgl.smartpra.interline.domain.repository.prod.idec.IbInvBatchRepository;
import com.sgl.smartpra.interline.domain.repository.prod.idec.IbInvoiceRepository;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.sales.domain.AgentRegister;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.TicketOrgin;
import com.sgl.smartpra.sales.domain.TicketSale;
import com.sgl.smartpra.sales.repository.AgentRegisterRepository;
import com.sgl.smartpra.sales.repository.TicketCouponRepository;
import com.sgl.smartpra.sales.repository.TicketMainRepository;
import com.sgl.smartpra.sales.repository.TicketOrginRepository;
import com.sgl.smartpra.sales.repository.TicketSaleRepository;

@Service
public class DualUtilizationServiceImpl implements DualUtilizationService {

	@Autowired(required = true)
	TicketCouponRepository ticketCouponRepository;

	@Autowired
	TicketMainRepository ticketMainRepository;

	@Autowired
	TicketOrginRepository ticketOrginRepository;

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	ExceptionTxnMsgSenderService exceptionTxnMsgSenderService;

	@Autowired
	DualUtilizationRepository utilizationRepository;

	@Autowired
	FlownCouponRepository flownCouponRepository;

	@Autowired
	AgentRegisterRepository agentRegisterRepository;

	@Autowired
	FlightDataDetailsRepository flightDataDetailsRepository;

	@Autowired
	IbBillingCouponRepository ibBillingCouponRepository;

	@Autowired
	IbInvBatchRepository ibInvBatchRepository;

	@Autowired
	IbInvoiceRepository ibInvoiceRepository;

	@Autowired
	TicketSaleRepository ticketSaleRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(DualUtilizationServiceImpl.class);

	ExceptionTransactionModel exceptionTransactionModel;
	List<ExceptionParametersValueModel> parametersValueModelList;
	ExceptionParametersValueModel parametersValueModel;

	String tktMainAgentCode = null;
	String utilDocumentNumber = null;
	String utilDocumnetUniqueId = null;
	Integer utilCouponNumber = null;
	String utilIssueAirline = null;
	String dualUtilType = null;
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	public Boolean createDualUtilization(DualUtilizationIn dualUtilizationIn) throws Exception {
		LOGGER.info("################# createDualUtilization - start ");
		Boolean isUtilized = false;
		Boolean isCreated = false;
		TicketCoupon ticketCoupon = null;
		DualUtilizationEntity dualUtilizationEntity = null;
		Integer dualCount;
		if (dualUtilizationIn != null) {
			utilDocumentNumber = OptionalUtil.getValue(dualUtilizationIn.getDocumentNumber());
			utilCouponNumber = OptionalUtil.getValue(dualUtilizationIn.getCouponNumber());
			utilDocumnetUniqueId = OptionalUtil.getValue(dualUtilizationIn.getDocumentUniqueId());
			utilIssueAirline = OptionalUtil.getValue(dualUtilizationIn.getIssueAirline());
			dualUtilType = OptionalUtil.getValue(dualUtilizationIn.getUtilizationType());
			try {
				ticketCoupon = ticketCouponRepository
						.findByDocumentUniqueIdAndCouponNumber(utilDocumnetUniqueId, utilCouponNumber).get();
			} catch (Exception e) {
				ticketDataNotFounExcep(dualUtilizationIn, dualUtilizationEntity);
			}
			if (ticketCoupon != null && ticketCoupon.getUtilType() != null) {

				dualCount = utilizationRepository.findCountByCpnoAndDocumentUniqueId(utilCouponNumber,
						utilDocumnetUniqueId);
				LOGGER.info("##############  Dual Count-  ::" + dualCount);
				if (dualCount <= 0) {
					LOGGER.info("### initDaulUtilizationTicketCpn(ticketCoupon) - start ");
					isCreated = initDaulUtilizationTicketCpn(ticketCoupon, dualUtilizationIn);
					LOGGER.info("### initDaulUtilizationTicketCpn(ticketCoupon) - end ");
				}

				LOGGER.info(
						"### dualUtilizationIn.getUtilizationType():- start" + dualUtilizationIn.getUtilizationType());
				switch (OptionalUtil.getValue(dualUtilizationIn.getUtilizationType())) {
				case DualUtilConstants.DUAL_UTZN_FOR_REISSUE:
					if (isCreated) {
						if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - start ");
							reissueProcessForTicket(ticketCoupon);
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
							LOGGER.info("###  flownUtilizationUpdate(ticketCoupon); - Start ");
							flownUtilizationUpdate(ticketCoupon);
							LOGGER.info("###   flownUtilizationUpdate(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - Start ");
							refundDateUpdateForTciket(ticketCoupon);
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)) {
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - Start ");
							inwardUtilizationDateUpdate(ticketCoupon);
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - End ");
						}
					}
					isUtilized = addDaulUtilization(dualUtilizationIn, dualCount);
					break;

				case DualUtilConstants.DUAL_UTZN_FOR_REFUND:
					if (isCreated) {
						if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - Start ");
							refundDateUpdateForTciket(ticketCoupon);
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
							LOGGER.info("###  flownUtilizationUpdate(ticketCoupon); - Start ");
							flownUtilizationUpdate(ticketCoupon);
							LOGGER.info("###   flownUtilizationUpdate(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - start ");
							reissueProcessForTicket(ticketCoupon);
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)) {
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - Start ");
							inwardUtilizationDateUpdate(ticketCoupon);
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - End ");
						}
					}
					isUtilized = addDaulUtilization(dualUtilizationIn, dualCount);
					break;

				case DualUtilConstants.DUAL_UTZN_FOR_FLOWN:
					if (isCreated) {
						if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
							LOGGER.info("###  flownUtilizationUpdate(ticketCoupon); - Start ");
							flownUtilizationUpdate(ticketCoupon);
							LOGGER.info("###   flownUtilizationUpdate(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - Start ");
							refundDateUpdateForTciket(ticketCoupon);
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - start ");
							reissueProcessForTicket(ticketCoupon);
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)) {
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - Start ");
							inwardUtilizationDateUpdate(ticketCoupon);
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - End ");
						}
					}
					isUtilized = addDaulUtilization(dualUtilizationIn, dualCount);
					break;

				case DualUtilConstants.DUAL_UTZN_FOR_INWARD:
					if (isCreated) {
						if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
							LOGGER.info("###  flownUtilizationUpdate(ticketCoupon); - Start ");
							flownUtilizationUpdate(ticketCoupon);
							LOGGER.info("###   flownUtilizationUpdate(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - Start ");
							refundDateUpdateForTciket(ticketCoupon);
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - start ");
							reissueProcessForTicket(ticketCoupon);
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)) {
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - Start ");
							inwardUtilizationDateUpdate(ticketCoupon);
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - End ");
						}
					}
					isUtilized = addDaulUtilization(dualUtilizationIn, dualCount);
					break;

				case DualUtilConstants.DUAL_UTZN_FOR_FIM:
					if (isCreated) {
						if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
							LOGGER.info("###  flownUtilizationUpdate(ticketCoupon); - Start ");
							flownUtilizationUpdate(ticketCoupon);
							LOGGER.info("###   flownUtilizationUpdate(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - Start ");
							refundDateUpdateForTciket(ticketCoupon);
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - start ");
							reissueProcessForTicket(ticketCoupon);
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)) {
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - Start ");
							inwardUtilizationDateUpdate(ticketCoupon);
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - End ");
						}
					}
					isUtilized = addDaulUtilization(dualUtilizationIn, dualCount);
					break;

				case DualUtilConstants.DUAL_UTZN_FOR_WRITE_BACK:
					if (isCreated) {
						if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
							LOGGER.info("###  flownUtilizationUpdate(ticketCoupon); - Start ");
							flownUtilizationUpdate(ticketCoupon);
							LOGGER.info("###   flownUtilizationUpdate(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - Start ");
							refundDateUpdateForTciket(ticketCoupon);
							LOGGER.info("### refundDateUpdateFotTciket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - start ");
							reissueProcessForTicket(ticketCoupon);
							LOGGER.info("### reissueProcessForTicket(ticketCoupon); - End ");
						} else if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)) {
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - Start ");
							inwardUtilizationDateUpdate(ticketCoupon);
							LOGGER.info("### inwardUtilizationDateUpdate(ticketCoupon); - End ");
						}
					}
					isUtilized = addDaulUtilization(dualUtilizationIn, dualCount);
					break;

				default:
					break;
				}
			} else {
				return isUtilized;
			}
		}
		return isUtilized;
	}

	private void reissueProcessForTicket(TicketCoupon ticketCoupon) throws Exception {
		TicketOrgin ticketOrgin = null;
		TicketMain ticketMain = null;
		DualUtilizationEntity dualUtil = new DualUtilizationEntity();
		List<DualUtilizationEntity> dualUtilList = new ArrayList<>();

		ticketOrgin = getTicketOrigin(utilIssueAirline, utilDocumentNumber, utilCouponNumber);

		if (ticketOrgin != null) {
			ticketMain = getTicketMainByDocUniqId(ticketOrgin.getDocumentUniqueId());
			if (ticketMain != null) {
				dualUtilList = utilizationRepository.findByCpnoAndDocumentUniqueId(utilCouponNumber,
						utilDocumnetUniqueId);
				if (!dualUtilList.isEmpty()) {
					dualUtil = dualUtilList.get(0);
					LOGGER.info("### setUtilizationDate(ticketMain.getDateOfIssue())); - Start ");
					dualUtil.setUtilizationDate(ticketMain.getDateOfIssue());
					LOGGER.info("### setUtilizationDate(ticketMain.getDateOfIssue())); - End ");
					utilizationRepository.save(dualUtil);
				}
			}
		}
	}

	private void refundDateUpdateForTciket(TicketCoupon ticketCoupon) throws Exception {
		DualUtilizationEntity dualUtil = new DualUtilizationEntity();
		TicketOrgin ticketOrgin = null;
		List<DualUtilizationEntity> dualUtilList = new ArrayList<>();

		ticketOrgin = getTicketOrigin(utilIssueAirline, utilDocumentNumber, utilCouponNumber);

		if (ticketOrgin != null) {
			dualUtilList = utilizationRepository.findByCpnoAndDocumentUniqueId(utilCouponNumber, utilDocumnetUniqueId);
			if (!dualUtilList.isEmpty()) {
				dualUtil = dualUtilList.get(0);
				LOGGER.info(
						"### setUtilizationDate(ticketOrgin.getRefundDate())); - Start " + ticketOrgin.getRefundDate());
				if (ticketOrgin.getRefundDate() != null) {
					dualUtil.setUtilizationDate(ticketOrgin.getRefundDate());
				}
				LOGGER.info(
						"### setUtilizationDate(ticketOrgin.getRefundDate())); - End " + ticketOrgin.getRefundDate());
				utilizationRepository.save(dualUtil);
			}
		}
	}

	private void flownUtilizationUpdate(TicketCoupon ticketCoupon) {
		DualUtilizationEntity dualUtil = new DualUtilizationEntity();
		List<DualUtilizationEntity> dualUtilList = new ArrayList<>();
		FlownCoupon flownCoupon = flownCouponRepository.findByDocumentUniqueIdAndCouponNumber(
				ticketCoupon.getDocumentUniqueId(), ticketCoupon.getCouponNumber());
		if (Objects.nonNull(flownCoupon)) {
			dualUtilList = utilizationRepository.findByCpnoAndDocumentUniqueId(utilCouponNumber, utilDocumnetUniqueId);
			if (Objects.nonNull(dualUtilList) && !dualUtilList.isEmpty()) {
				dualUtil = dualUtilList.get(0);
				LOGGER.info("dualUtil.setUtilizationDate(flownCoupon.getFlightDate())-Start");
				dualUtil.setUtilizationDate(flownCoupon.getFlightDate());
				LOGGER.info("dualUtil.setUtilizationDate(flownCoupon.getFlightDate())-Start");
				utilizationRepository.save(dualUtil);
			}
		}
	}

	private void inwardUtilizationDateUpdate(TicketCoupon ticketCoupon) {
		DualUtilizationEntity dualUtil = new DualUtilizationEntity();
		List<DualUtilizationEntity> dualUtilList = new ArrayList<>();
		IbBillingCoupon ibBillingCoupon = null;
		IbInvBatch ibInvBatch = null;
		IbInvoice ibInvoice = null;
		dualUtilList = utilizationRepository.findByCpnoAndDocumentUniqueId(utilCouponNumber, utilDocumnetUniqueId);
		if (Objects.nonNull(dualUtilList) && !dualUtilList.isEmpty()) {
			dualUtil = dualUtilList.get(0);
		}

		ibBillingCoupon = ibBillingCouponRepository.findByDocumentUniqueIdAndCouponNo(utilDocumnetUniqueId,
				utilCouponNumber);
		if (Objects.nonNull(ibBillingCoupon) && Objects.nonNull(dualUtil)) {
			if (ibBillingCoupon.getFlightDate() != null) {
				dualUtil.setUtilizationDate(java.sql.Date.valueOf(ibBillingCoupon.getFlightDate()));
			} else {
				ibInvBatch = ibBillingCoupon.getIbInvBatch();
				ibInvoice = ibInvBatch.getIbInvoice();
				if (ibInvoice.getInvoiceDate() != null) {
					dualUtil.setUtilizationDate(java.sql.Date.valueOf(ibInvoice.getInvoiceDate()));
				}
			}
		}

	}

	private Boolean addDaulUtilization(DualUtilizationIn dualUtilizationIn, int dualCount) throws Exception {
		LOGGER.info("### addDaulUtilization(DualUtilizationIn dualUtilizationIn, int dualCount)-Start");
		Boolean isCrated = false;
		TicketMain ticketMain = null;
		Date convertedDate = null;
		convertedDate = convertStringToDate(OptionalUtil.getValue(dualUtilizationIn.getUtilizationDate()));

		DualUtilizationEntity dualUtilizationEntity = new DualUtilizationEntity();
		List<DualUtilizationEntity> dualUtilizationDBList = utilizationRepository.findByCpnoAndDocumentUniqueId(
				OptionalUtil.getValue(dualUtilizationIn.getCouponNumber()),
				OptionalUtil.getValue(dualUtilizationIn.getDocumentUniqueId()));

		if (!dualUtilizationDBList.isEmpty()) {
			for (DualUtilizationEntity dualUtilizationDB : dualUtilizationDBList) {
				if (dualUtilizationDB.getUtilizationType() != null
						&& dualUtilizationDB.getUtilizationType().equals(dualUtilType)
						&& dualUtilizationDB.getSerialNumber() > 1) {
					LOGGER.info("### If data already there in dual utilization update the same date ");
					isCrated = updateDaulUtilization(dualUtilizationDB, dualUtilizationIn);
					return isCrated;
				}
			}
		}
		dualUtilizationEntity.setClientId(getHostCarrierAlphaCd());
		dualUtilizationEntity.setIssueAirline(OptionalUtil.getValue(dualUtilizationIn.getIssueAirline()));
		dualUtilizationEntity.setDocumentNumber(OptionalUtil.getValue(dualUtilizationIn.getDocumentNumber()));
		dualUtilizationEntity.setDocumentUniqueId(OptionalUtil.getValue(dualUtilizationIn.getDocumentUniqueId()));
		dualUtilizationEntity.setCouponNumber(OptionalUtil.getValue(dualUtilizationIn.getCouponNumber()));
		dualUtilizationEntity.setUtilizationType(OptionalUtil.getValue(dualUtilizationIn.getUtilizationType()));
		if (convertedDate != null) {
			dualUtilizationEntity.setUtilizationDate(convertedDate);
		}

		if (dualUtilType.equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)
				|| dualUtilType.equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
			ticketMain = getTicketMainByDocUniqId(OptionalUtil.getValue(dualUtilizationIn.getDocumentUniqueId()));
			if (ticketMain != null) {
				LOGGER.info("###Ticket Main Agent Code=====" + ticketMain.getAgentCode());
				dualUtilizationEntity.setAgencyCode(ticketMain.getAgentCode());
			}
		}
		if (dualUtilType.equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)
				|| dualUtilType.equals(DualUtilConstants.DUAL_UTZN_FOR_WRITE_BACK)) {
			dualUtilizationEntity.setDiscrepancyStatus(DualUtilConstants.DISCREPANCY_STATUS_N);
			if (dualCount == 0) {
				dualUtilizationEntity.setSerialNumber(dualCount + 2);
			} else {
				dualUtilizationEntity.setSerialNumber(dualCount + 1);
			}

		} else {
			dualUtilizationEntity.setDiscrepancyStatus(DualUtilConstants.DISCREPANCY_STATUS_Y);
			if (dualCount == 0) {
				dualUtilizationEntity.setSerialNumber(dualCount + 2);
			} else {
				dualUtilizationEntity.setSerialNumber(dualCount + 1);
			}
		}

		if (dualUtilType.equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)
				|| dualUtilType.equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
			TicketCoupon ticketCoupon = ticketCouponRepository
					.findByDocumentUniqueIdAndCouponNumber(utilDocumnetUniqueId, utilCouponNumber).get();
			if (ticketCoupon != null) {
				dualUtilizationEntity.setBilledAirlineCode(ticketCoupon.getBilledCarrierCode());
			}
		}
		dualUtilizationEntity.setBatchKey1(OptionalUtil.getValue(dualUtilizationIn.getBatchKey1()));
		dualUtilizationEntity.setBatchKey2(OptionalUtil.getValue(dualUtilizationIn.getBatchKey2()));
		dualUtilizationEntity.setBatchKey3(OptionalUtil.getValue(dualUtilizationIn.getBatchKey3()));
		dualUtilizationEntity.setBatchKey4(OptionalUtil.getValue(dualUtilizationIn.getBatchKey4()));

		if (convertedDate != null) {
			dualUtilizationEntity.setUtilizationDate(convertedDate);
		}
		convertedDate = convertStringToDate(OptionalUtil.getValue(dualUtilizationIn.getBatchKey5()));
		if (convertedDate != null) {
			dualUtilizationEntity.setBatchKey5(convertedDate);
		}

		convertedDate = convertStringToDate(OptionalUtil.getValue(dualUtilizationIn.getBatchKey6()));
		if (convertedDate != null) {
			dualUtilizationEntity.setBatchKey6(convertedDate);
		}

		dualUtilizationEntity.setCreatedBy(DualUtilConstants.CREATED_BY);
		dualUtilizationEntity.setCreatedDate(new Timestamp(new Date().getTime()));

		try {
			utilizationRepository.save(dualUtilizationEntity);
			isCrated = true;
		} catch (Exception e) {
			dualUtilizationCreationExcep(dualUtilizationEntity, dualUtilizationIn);
		}
		LOGGER.info("### addDaulUtilization(DualUtilizationIn dualUtilizationIn, int dualCount)-End");
		return isCrated;
	}

	private Boolean updateDaulUtilization(DualUtilizationEntity dualUtilizationDB, DualUtilizationIn dualUtilizationIn)
			throws Exception {
		LOGGER.info(
				"### updateDaulUtilization(DualUtilization dualUtilizationDB, DualUtilizationIn dualUtilizationIn)-Start");
		TicketMain ticketMain = null;
		Boolean isCrated = false;
		TicketOrgin ticketOrgin = null;
		Date convertedDate = null;

		convertedDate = convertStringToDate(OptionalUtil.getValue(dualUtilizationIn.getUtilizationDate()));

		dualUtilizationDB.setIssueAirline(OptionalUtil.getValue(dualUtilizationIn.getIssueAirline()));

		if (dualUtilizationDB.getUtilizationType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
			ticketMain = getTicketMainByDocUniqId(OptionalUtil.getValue(dualUtilizationIn.getDocumentUniqueId()));
			if (ticketMain != null) {
				LOGGER.info("###Ticket Main Agent Code=====" + ticketMain.getAgentCode());
				dualUtilizationDB.setUtilizationDate(ticketMain.getDateOfIssue());
				dualUtilizationDB.setAgencyCode(ticketMain.getAgentCode());
			}
		}
		if (dualUtilizationDB.getUtilizationType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
			ticketOrgin = getTicketOrigin(utilIssueAirline, utilDocumentNumber, utilCouponNumber);
			if (ticketOrgin != null) {
				dualUtilizationDB.setUtilizationDate(ticketOrgin.getRefundDate());
			}
			ticketMain = getTicketMainByDocUniqId(OptionalUtil.getValue(dualUtilizationIn.getDocumentUniqueId()));
			if (ticketMain != null) {
				LOGGER.info("###Ticket Main Agent Code=====" + ticketMain.getAgentCode());
				dualUtilizationDB.setAgencyCode(ticketMain.getAgentCode());
			}
		}

		if (dualUtilizationDB.getUtilizationType().equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
			if (convertedDate != null) {
				dualUtilizationDB.setUtilizationDate(convertedDate);
			}
			dualUtilizationDB.setBatchKey1(OptionalUtil.getValue(dualUtilizationIn.getBatchKey1()));

			convertedDate = convertStringToDate(OptionalUtil.getValue(dualUtilizationIn.getBatchKey5()));
			if (convertedDate != null) {
				dualUtilizationDB.setBatchKey5(convertedDate);
			}
		}

		if (dualUtilizationDB.getUtilizationType().equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)) {
			TicketCoupon ticketCoupon = ticketCouponRepository.findByDocumentUniqueIdAndCouponNumber(
					dualUtilizationDB.getDocumentUniqueId(), dualUtilizationDB.getCouponNumber()).get();
			if (ticketCoupon != null) {
				dualUtilizationDB.setBilledAirlineCode(ticketCoupon.getBilledCarrierCode());
			}
			if (convertedDate != null) {
				dualUtilizationDB.setUtilizationDate(convertedDate);
			}
			convertedDate = convertStringToDate(OptionalUtil.getValue(dualUtilizationIn.getBatchKey5()));
			if (convertedDate != null) {
				dualUtilizationDB.setBatchKey5(convertedDate);
			}
		}
		dualUtilizationDB.setLastUpdatedBy(DualUtilConstants.CREATED_BY);
		dualUtilizationDB.setLastUpdatedDate(new Timestamp(new Date().getTime()));

		try {
			utilizationRepository.save(dualUtilizationDB);
			isCrated = true;
		} catch (Exception e) {
			dualUtilizationCreationExcep(dualUtilizationDB, dualUtilizationIn);
		}
		LOGGER.info(
				"### updateDaulUtilization(DualUtilization dualUtilizationDB, DualUtilizationIn dualUtilizationIn)-End");
		return isCrated;

	}

	private Boolean initDaulUtilizationTicketCpn(TicketCoupon ticketCoupon, DualUtilizationIn dualUtilizationIn)
			throws Exception {
		LOGGER.info("###initDaulUtilizationTicketCpn(TicketCoupon ticketCoupon)-Start");
		Boolean isCrated = false;
		TicketMain ticketMain = null;
		DualUtilizationEntity dualUtilization = new DualUtilizationEntity();

		dualUtilization.setClientId(getHostCarrierAlphaCd());
		dualUtilization.setIssueAirline(ticketCoupon.getIssueAirline());
		dualUtilization.setDocumentNumber(ticketCoupon.getDocumentNumber());
		dualUtilization.setDocumentUniqueId(ticketCoupon.getDocumentUniqueId());
		dualUtilization.setCouponNumber(ticketCoupon.getCouponNumber());
		dualUtilization.setUtilizationType(ticketCoupon.getUtilType());
		dualUtilization.setUtilizationDate(ticketCoupon.getOperatingFlightDeptDate());
		dualUtilization.setDiscrepancyStatus(DualUtilConstants.DISCREPANCY_STATUS_N);

		if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)) {
			dualUtilization.setBilledAirlineCode(ticketCoupon.getBilledCarrierCode());
			LOGGER.info("###bacthKeysForInward(dualUtilization, dualUtilizationIn)-Start");
			batchKeysForInward(dualUtilization, dualUtilizationIn);
			LOGGER.info("###bacthKeysForInward(dualUtilization, dualUtilizationIn)-End");
		}

		if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
			ticketMain = getTicketMainByDocUniqId(ticketCoupon.getDocumentUniqueId());
			if (ticketMain != null) {
				LOGGER.info("###Ticket Main Agent Code=====");
				dualUtilization.setAgencyCode(ticketMain.getAgentCode());
			}
			LOGGER.info("###batchKeysForExchange(dualUtilization, dualUtilizationIn)-Start");
			batchKeysForExchange(dualUtilization, dualUtilizationIn);
			LOGGER.info("###batchKeysForExchange(dualUtilization, dualUtilizationIn)-End");
		}
		if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
			ticketMain = getTicketMainByDocUniqId(ticketCoupon.getDocumentUniqueId());
			if (ticketMain != null) {
				LOGGER.info("###Ticket Main Agent Code=====");
				dualUtilization.setAgencyCode(ticketMain.getAgentCode());
			}
			LOGGER.info("###batchKeysForRefund(dualUtilization, dualUtilizationIn)-Start");
			batchKeysForRefund(dualUtilization, dualUtilizationIn);
			LOGGER.info("###batchKeysForRefund(dualUtilization, dualUtilizationIn)-End");
		}
		if (ticketCoupon.getUtilType().equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
			dualUtilization.setBilledAirlineCode(ticketCoupon.getBilledCarrierCode());
			LOGGER.info("###batchKeysForFlownCoupon(dualUtilization, dualUtilizationIn)-Start");
			batchKeysForFlownCoupon(dualUtilization, dualUtilizationIn);
			LOGGER.info("###batchKeysForFlownCoupon(dualUtilization, dualUtilizationIn)-Start");
		}
		dualUtilization.setSerialNumber(1);
		dualUtilization.setCreatedBy(DualUtilConstants.CREATED_BY);
		dualUtilization.setCreatedDate(new Timestamp(new Date().getTime()));
		try {
			utilizationRepository.save(dualUtilization);
			isCrated = true;
		} catch (Exception e) {
			dualUtilizationCreationExcep(dualUtilization, dualUtilizationIn);
		}
		LOGGER.info("###initDaulUtilizationTicketCpn(TicketCoupon ticketCoupon)-End");
		return isCrated;

	}

	private void batchKeysForExchange(DualUtilizationEntity dualUtilizationEntity, DualUtilizationIn dualUtilizationIn)
			throws Exception {
		TicketOrgin ticketOrgin = null;
		TicketSale ticketSale = null;
		ticketOrgin = getTicketOrigin(utilIssueAirline, utilDocumentNumber, utilCouponNumber);
		if (Objects.nonNull(ticketOrgin)) {
			LOGGER.info("###agentRegisterRepository.findById(ticketOrgin.getSalesKey())-Start");
			Optional<AgentRegister> agentRegister = agentRegisterRepository.findById(ticketOrgin.getSalesKey());
			LOGGER.info("###agentRegisterRepository.findById(ticketOrgin.getSalesKey())-End");
			if (agentRegister.isPresent()) {
				LOGGER.info("###agentRegister.isPresent()");
				if (agentRegister.get().getAgencyCode() != null) {
					dualUtilizationEntity.setBatchKey1(agentRegister.get().getAgencyCode());
				}

				if (agentRegister.get().getSalesUniqueKey() != null) {
					dualUtilizationEntity.setBatchKey3(String.valueOf(agentRegister.get().getSalesUniqueKey()));
				}
				if (agentRegister.get().getTransactionCurrency() != null) {
					dualUtilizationEntity.setBatchKey4(String.valueOf(agentRegister.get().getTransactionCurrency()));
				}
				if (agentRegister.get().getEffectiveFromDate() != null) {
					dualUtilizationEntity.setBatchKey5(agentRegister.get().getEffectiveFromDate());
				}
				if (agentRegister.get().getEffectiveToDate() != null) {
					dualUtilizationEntity.setBatchKey6(agentRegister.get().getEffectiveToDate());
				}
			}
			LOGGER.info("###ticketSaleRepository.findByDocumentUniqueIdAndSalesKey()-Start");
			ticketSale = ticketSaleRepository.findByDocumentUniqueIdAndSalesKey(ticketOrgin.getDocumentUniqueId(),
					ticketOrgin.getSalesKey());
			LOGGER.info("###ticketSaleRepository.findByDocumentUniqueIdAndSalesKey()-End");
			if (Objects.nonNull(ticketSale)) {
				LOGGER.info("###Objects.nonNull(ticketSale)");
				if (ticketSale.getTransactionType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
					dualUtilizationEntity.setBatchKey2(ticketSale.getTransactionType());
				}
			}
		}
	}

	private void batchKeysForRefund(DualUtilizationEntity dualUtilization, DualUtilizationIn dualUtilizationIn)
			throws Exception {
		TicketOrgin ticketOrgin = null;
		TicketSale ticketSale = null;
		ticketOrgin = getTicketOrigin(utilIssueAirline, utilDocumentNumber, utilCouponNumber);
		if (Objects.nonNull(ticketOrgin)) {
			LOGGER.info("###agentRegisterRepository.findById(ticketOrgin.getSalesKey())-Start");
			Optional<AgentRegister> agentRegister = agentRegisterRepository.findById(ticketOrgin.getSalesKey());
			LOGGER.info("###agentRegisterRepository.findById(ticketOrgin.getSalesKey())-End");
			if (agentRegister.isPresent()) {
				LOGGER.info("###agentRegister.isPresent()");
				if (agentRegister.get().getAgencyCode() != null) {
					dualUtilization.setBatchKey1(agentRegister.get().getAgencyCode());
				}
				if (agentRegister.get().getSalesUniqueKey() != null) {
					dualUtilization.setBatchKey3(String.valueOf(agentRegister.get().getSalesUniqueKey()));
				}
				if (agentRegister.get().getTransactionCurrency() != null) {
					dualUtilization.setBatchKey4(String.valueOf(agentRegister.get().getTransactionCurrency()));
				}
				if (agentRegister.get().getEffectiveFromDate() != null) {
					dualUtilization.setBatchKey5(agentRegister.get().getEffectiveFromDate());
				}
				if (agentRegister.get().getEffectiveToDate() != null) {
					dualUtilization.setBatchKey6(agentRegister.get().getEffectiveToDate());
				}
			}
			LOGGER.info("###ticketSaleRepository.findByDocumentUniqueIdAndSalesKey()-Start");
			ticketSale = ticketSaleRepository.findByDocumentUniqueIdAndSalesKey(ticketOrgin.getDocumentUniqueId(),
					ticketOrgin.getSalesKey());
			LOGGER.info("###ticketSaleRepository.findByDocumentUniqueIdAndSalesKey()-End");
			if (Objects.nonNull(ticketSale)) {
				LOGGER.info("###Objects.nonNull(ticketSale)");
				if (ticketSale.getTransactionType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
					dualUtilization.setBatchKey2(ticketSale.getTransactionType());
				}
			}
		}
	}

	private void batchKeysForFlownCoupon(DualUtilizationEntity dualUtilization, DualUtilizationIn dualUtilizationIn) {
		LOGGER.info("###flownCouponRepository.findByDocumentUniqueIdAndCouponNumber()-Start");
		FlownCoupon flownCoupon = flownCouponRepository.findByDocumentUniqueIdAndCouponNumber(utilDocumnetUniqueId,
				utilCouponNumber);
		LOGGER.info("###flownCouponRepository.findByDocumentUniqueIdAndCouponNumber-End");
		if (Objects.nonNull(flownCoupon)) {
			LOGGER.info("###Objects.nonNull(flownCoupon)");
			dualUtilization.setBatchKey1(flownCoupon.getFlightNumber());
			dualUtilization.setBatchKey2(flownCoupon.getFromAirport());
			dualUtilization.setBatchKey3(flownCoupon.getToAirport());
			LOGGER.info("###flightDataDetailsRepository.findByFlightKey()-Start");
			FlightDataDetailsEntity flightDataDetails = flightDataDetailsRepository
					.findByFlightKey(flownCoupon.getFlightKey().intValue()).get();
			LOGGER.info("###flightDataDetailsRepository.findByFlightKey()-End");
			if (flightDataDetails != null) {
				if (flightDataDetails.getFlightType() != null) {
					dualUtilization.setBatchKey4(flightDataDetails.getFlightType());
				}
				dualUtilization.setBatchKey6(flightDataDetails.getCreatedDate());
			}
			dualUtilization.setBatchKey5(flownCoupon.getFlightDate());

		}
	}

	private void batchKeysForInward(DualUtilizationEntity dualUtilization, DualUtilizationIn dualUtilizationIn) {
		IbBillingCoupon ibBillingCoupon = null;
		IbInvBatch ibInvBatch = null;
		IbInvoice ibInvoice = null;
		List<OutwardBillingPeriods> outwardBillingPeriodsList = null;
		LOGGER.info("###ibBillingCouponRepository.findByDocumentUniqueIdAndCouponNo()-Start");
		ibBillingCoupon = ibBillingCouponRepository.findByDocumentUniqueIdAndCouponNo(utilDocumnetUniqueId,
				utilCouponNumber);
		LOGGER.info("###ibBillingCouponRepository.findByDocumentUniqueIdAndCouponNo()-End");
		if (Objects.nonNull(ibBillingCoupon)) {
			LOGGER.info("###Objects.nonNull(ibBillingCoupon)");
			ibInvBatch = ibBillingCoupon.getIbInvBatch();
			if (Objects.nonNull(ibInvBatch)) {
				LOGGER.info("###Objects.nonNull(ibInvBatch)");
				if (ibInvBatch.getBillingAirline() != null) {
					dualUtilization.setBatchKey1(ibInvBatch.getBillingAirline());
				}
				if (ibInvBatch.getBilledAirline() != null) {
					dualUtilization.setBatchKey2(ibInvBatch.getBilledAirline());
				}
				if (ibInvBatch.getSourceCode() != null) {
					dualUtilization.setBatchKey3(ibInvBatch.getSourceCode());
				}
				if (ibInvBatch.getInvoiceNumber() != null) {
					dualUtilization.setBatchKey4(ibInvBatch.getInvoiceNumber());
				}
				ibInvoice = ibInvBatch.getIbInvoice();
				LOGGER.info("###masterFeignClient.getOutwardBillingPeriodsStartDate(()-Start");
				outwardBillingPeriodsList = masterFeignClient
						.getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriodV(ibInvoice.getBillingMonth(),
								ibInvoice.getBillingPeriod());
				LOGGER.info("###masterFeignClient.getOutwardBillingPeriodsStartDate(()-End");

				if (Objects.nonNull(outwardBillingPeriodsList) && outwardBillingPeriodsList.size() > 0) {
					OutwardBillingPeriods outwardBillingPeriods = outwardBillingPeriodsList.get(0);
					LOGGER.info("###outwardBillingPeriods.getEndDate()::::" + outwardBillingPeriods.getEndDate());
					
					Date batchKey6 = java.util.Date.from(outwardBillingPeriods.getEndDate().atStartOfDay()
						      .atZone(ZoneId.systemDefault())
						      .toInstant());
					dualUtilization.setBatchKey6(batchKey6);
				}
				if (ibInvoice.getInvoiceDate() != null) {
					dualUtilization.setBatchKey5(
							Date.from(ibInvoice.getInvoiceDate().atStartOfDay(ZoneId.systemDefault()).toInstant()));
				}
			}
		}
	}

	private String getHostCarrierAlphaCd() {
		LOGGER.info("###masterFeignClient.getHostCarrierAlphaCd(()-Start");
		String hostCarrierAlphaCode = null;
		List<SystemParameter> systemParameterList = masterFeignClient
				.getSystemParameterByparameterName(DualUtilConstants.PARAM_DEFAULT_CARRIER_ALPHA_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierAlphaCode = systemParameterList.get(0).getParameterRangeFrom().get();
		}
		LOGGER.info("###masterFeignClient.getHostCarrierAlphaCd(()-Start");
		return hostCarrierAlphaCode;
	}

	private String getHostCarrierNumericCd() {
		LOGGER.info("###masterFeignClient.getHostCarrierAlphaCd(()-Start");
		String hostCarrierAlphaCode = null;
		List<SystemParameter> systemParameterList = masterFeignClient
				.getSystemParameterByparameterName(DualUtilConstants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierAlphaCode = systemParameterList.get(0).getParameterRangeFrom().get();
		}
		LOGGER.info("###masterFeignClient.getHostCarrierAlphaCd(()-Start");
		return hostCarrierAlphaCode;
	}

	private void dualUtilizationCreationExcep(DualUtilizationEntity dualUtilizationEntity,
			DualUtilizationIn dualUtilizationIn) throws Exception {
		LOGGER.info("###dualUtilizationCreationExcep(DualUtilization dualUtilization)-Start");
		TicketMain ticketMain = null;

		ticketMain = getTicketMainByDocUniqId(dualUtilizationEntity.getDocumentUniqueId());

		Map<String, String> paramsMmap = new HashMap<>();
		paramsMmap.put(DualUtilConstants.EXCEPCODE_GEN1118_PARAM_1,
				String.valueOf(dualUtilizationEntity.getCouponNumber()));
		paramsMmap.put(DualUtilConstants.EXCEPCODE_GEN1118_PARAM_2, dualUtilizationEntity.getIssueAirline());
		paramsMmap.put(DualUtilConstants.EXCEPCODE_GEN1118_PARAM_3, dualUtilizationEntity.getDocumentNumber());
		paramsMmap.put(DualUtilConstants.EXCEPCODE_GEN1118_PARAM_4, dualUtilizationEntity.getUtilizationType());
		paramsMmap.put(DualUtilConstants.EXCEPCODE_GEN1118_PARAM_5, ticketMain.getDocType());

		createExceptionTxn(DualUtilConstants.EXCEPCODE_GEN1118, paramsMmap, dualUtilizationEntity, dualUtilizationIn);
		LOGGER.info("###dualUtilizationCreationExcep(DualUtilization dualUtilization)-End");
	}

	private TicketMain getTicketMainByDocUniqId(String documentUniqueId) throws Exception {
		TicketMain ticketMain = null;
		try {
			ticketMain = ticketMainRepository.findByDocumentUniqueId(documentUniqueId).get();
		} catch (Exception e) {
			throw new Exception("In Ticket Main with documnetUniqId=" + documentUniqueId + "data not available");
		}

		return ticketMain;
	}

	private TicketOrgin getTicketOrigin(String issuAirline, String documentNumber, Integer couponNumber)
			throws Exception {
		TicketOrgin ticketOrgin = null;
		try {
			ticketOrgin = ticketOrginRepository.findByOrigIssueAirlineAndOrigDocumentAndOrigCpnNo(issuAirline,
					documentNumber, String.valueOf(couponNumber)).get();
		} catch (Exception e) {
			throw new Exception("In Ticket Orgin table no data available for above combination");
		}
		return ticketOrgin;
	}

	private Date convertStringToDate(String conversionDate) {
		Date date = null;
		try {
			date = formatter.parse(conversionDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;

	}

	private void createExceptionTxn(String excepCode, Map<String, String> paramsMap,
			DualUtilizationEntity dualUtilizationEntity, DualUtilizationIn utilizationIn) {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();

		exceptionTransactionModel.setExceptionCode(excepCode);
		exceptionTransactionModel.setClientId(getHostCarrierAlphaCd());
		exceptionTransactionModel.setOrderId(String.valueOf(2));
		exceptionTransactionModel.setCreatedBy(DualUtilConstants.CREATED_BY);
		exceptionTransactionModel.setEnvironment(DualUtilConstants.DUAL_EXCEP_ENV);
		exceptionTransactionModel.setIssuedCarrier(OptionalUtil.getValue(utilizationIn.getIssueAirline()));
		exceptionTransactionModel.setDocumentUniqueId(OptionalUtil.getValue(utilizationIn.getDocumentUniqueId()));
		exceptionTransactionModel.setMainDocument(OptionalUtil.getValue(utilizationIn.getDocumentNumber()));
		exceptionTransactionModel.setCouponNumber(OptionalUtil.getValue(utilizationIn.getCouponNumber()));
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setBatchKey1(OptionalUtil.getValue(utilizationIn.getBatchKey1()));
		exceptionTransactionModel.setBatchKey2(OptionalUtil.getValue(utilizationIn.getBatchKey2()));
		exceptionTransactionModel.setBatchKey3(OptionalUtil.getValue(utilizationIn.getBatchKey3()));
		exceptionTransactionModel.setBatchKey4(OptionalUtil.getValue(utilizationIn.getBatchKey4()));
		exceptionTransactionModel
				.setBatchKey5(OptionalUtil.getLocalDateValue(utilizationIn.getBatchKey5()).atStartOfDay());
		exceptionTransactionModel
				.setBatchKey6(OptionalUtil.getLocalDateValue(utilizationIn.getBatchKey6()).atStartOfDay());

		if (paramsMap != null) {
			List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
			ExceptionParametersValueModel parametersValueModel;
			for (String name : paramsMap.keySet()) {
				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName(name);
				parametersValueModel.setParameterValue(paramsMap.get(name));
				parametersValueModelList.add(parametersValueModel);
			}
			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
		}
		exceptionTxnMsgSenderService.sendToExceptionQueue(exceptionTransactionModel);

	}

	public static LocalDateTime asLocalDateTime(Date date) {
		return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

	private void ticketDataNotFounExcep(DualUtilizationIn utilizationIn, DualUtilizationEntity dualUtilizationEntity) {
		Map<String, String> paramsMap = new HashMap<>();
		paramsMap.put(CommonExceptionConstants.EXCEPCODE_GEN2000_PARAM_1, getHostCarrierNumericCd());
		paramsMap.put(CommonExceptionConstants.EXCEPCODE_GEN2000_PARAM_2,
				OptionalUtil.getValue(utilizationIn.getDocumentNumber()));
		paramsMap.put(CommonExceptionConstants.EXCEPCODE_GEN2000_PARAM_3,
				String.valueOf(utilizationIn.getCouponNumber()));
		createExceptionTxn(CommonExceptionConstants.EXCEPCODE_GEN2000, paramsMap, dualUtilizationEntity, utilizationIn);
	}

	public List<DualUtilizationModel> searchDualUtilization(String documentUniqueId) throws Exception {

		LOGGER.info("###searchDualUtilization(String documentUniqueId)-Start");
		List<DualUtilizationModel> dualUtilizationModelList = new ArrayList<>();
		List<DualUtilizationEntity> dualUtilizationEntities = null;
		TicketCoupon ticketCoupon = null;
		dualUtilizationEntities = utilizationRepository.findByDocumentUniqueIdOrderByCpnNo(documentUniqueId);
		if (Objects.nonNull(dualUtilizationEntities) && dualUtilizationEntities.size() > 0) {
			for (DualUtilizationEntity utilizationEntity : dualUtilizationEntities) {
				DualUtilizationModel dUtilizationModel = new DualUtilizationModel();
				dUtilizationModel.setAdmAmount(utilizationEntity.getAdmAmount());
				dUtilizationModel.setAdmDate(utilizationEntity.getAdmDate());
				dUtilizationModel.setAdmInvoice(utilizationEntity.getAdmInvoice());
				dUtilizationModel.setAdmNumber(utilizationEntity.getAdmNumber());
				dUtilizationModel.setAgencyCode(utilizationEntity.getAgencyCode());
				dUtilizationModel.setBatchKey1(utilizationEntity.getBatchKey1());
				dUtilizationModel.setBatchKey2(utilizationEntity.getBatchKey2());
				dUtilizationModel.setBatchKey3(utilizationEntity.getBatchKey3());
				dUtilizationModel.setBatchKey4(utilizationEntity.getBatchKey4());
				dUtilizationModel.setBatchKey5(utilizationEntity.getBatchKey5());
				dUtilizationModel.setBatchKey6(utilizationEntity.getBatchKey6());
				dUtilizationModel.setBilledAirlineCode(utilizationEntity.getBilledAirlineCode());
				dUtilizationModel.setClientId(utilizationEntity.getClientId());
				dUtilizationModel.setCouponNumber(utilizationEntity.getCouponNumber());
				dUtilizationModel.setCreatedBy(utilizationEntity.getCreatedBy());
				dUtilizationModel.setCreatedDate(utilizationEntity.getCreatedDate());
				dUtilizationModel.setCurrencyOfAdm(utilizationEntity.getCurrencyOfAdm());
				dUtilizationModel.setDiscrepancyStatus(utilizationEntity.getDiscrepancyStatus());
				dUtilizationModel.setDocumentNumber(utilizationEntity.getDocumentNumber());
				dUtilizationModel.setDocumentUniqueId(utilizationEntity.getDocumentUniqueId());
				dUtilizationModel.setIssueAirline(utilizationEntity.getIssueAirline());
				dUtilizationModel.setLastUpdatedBy(utilizationEntity.getLastUpdatedBy());
				dUtilizationModel.setLastUpdatedDate(utilizationEntity.getLastUpdatedDate());
				dUtilizationModel.setLastUpdatedProgramName(utilizationEntity.getLastUpdatedProgramName());
				dUtilizationModel.setOrderId(utilizationEntity.getOrderId());
				dUtilizationModel.setRemarks(utilizationEntity.getRemarks());
				dUtilizationModel.setSerialNumber(utilizationEntity.getSerialNumber());
				dUtilizationModel.setUtilizationType(utilizationEntity.getUtilizationType());
				dUtilizationModel.setUtilizationDate(utilizationEntity.getAdmDate());
				if (utilizationEntity.getUtilizationType().equals(DualUtilConstants.DUAL_UTZN_FOR_FLOWN)) {
					String description = "FlightDate:" + utilizationEntity.getBatchKey5() + "," + "FlightNumber:"
							+ utilizationEntity.getBatchKey1() + "," + "From Airport:"
							+ utilizationEntity.getBatchKey2() + "," + "To Airport:" + utilizationEntity.getBatchKey3()
							+ "," + "Flight Type:" + utilizationEntity.getBatchKey4();

					dUtilizationModel.setDualUtilDescription(description);
				}

				if (utilizationEntity.getUtilizationType().equals(DualUtilConstants.DUAL_UTZN_FOR_INWARD)) {
					String description = "Invoice Date:" + utilizationEntity.getBatchKey5() + ","
							+ "Billing Airline Code:" + utilizationEntity.getBatchKey1() + "," + "Billed Carrier Code:"
							+ utilizationEntity.getBatchKey2() + "," + "Source Code:" + utilizationEntity.getBatchKey3()
							+ "," + "Invoice Number:" + utilizationEntity.getBatchKey4() + ","
							+ " Billing Period End Date:" + utilizationEntity.getBatchKey6();

					dUtilizationModel.setDualUtilDescription(description);
				}

				if (utilizationEntity.getUtilizationType().equals(DualUtilConstants.DUAL_UTZN_FOR_REISSUE)) {
					String description = "Effective From Date:" + utilizationEntity.getBatchKey5() + "," + "Agency:"
							+ utilizationEntity.getBatchKey1() + "," + "Transaction Currency:"
							+ utilizationEntity.getBatchKey4() + "," + "Transcation Type:"
							+ utilizationEntity.getBatchKey2() + "Effective To Date:"
							+ utilizationEntity.getBatchKey6();

					dUtilizationModel.setDualUtilDescription(description);
				}

				if (utilizationEntity.getUtilizationType().equals(DualUtilConstants.DUAL_UTZN_FOR_REFUND)) {
					String description = "Effective From Date: " + utilizationEntity.getBatchKey5() + "," + "Agency: "
							+ utilizationEntity.getBatchKey1() + "," + "Transaction Currency: "
							+ utilizationEntity.getBatchKey4() + "," + "Transcation Type: "
							+ utilizationEntity.getBatchKey2() + "Effective To Date: "
							+ utilizationEntity.getBatchKey6();
					dUtilizationModel.setDualUtilDescription(description);
				}

				try {
					LOGGER.info("###ticketCouponRepository.findByDocumentUniqueIdAndCouponNumber()-Start");
					ticketCoupon = ticketCouponRepository.findByDocumentUniqueIdAndCouponNumber(
							utilizationEntity.getDocumentUniqueId(), utilizationEntity.getCouponNumber()).get();
					LOGGER.info("###ticketCouponRepository.findByDocumentUniqueIdAndCouponNumber()-End");
				} catch (Exception e) {
				}

				if (Objects.nonNull(ticketCoupon)) {
					dUtilizationModel.setFromAirport(ticketCoupon.getFromAirport());
					dUtilizationModel.setToAirport(ticketCoupon.getToAirport());
				}
				dualUtilizationModelList.add(dUtilizationModel);
			}
		}
		LOGGER.info("###searchDualUtilization(String documentUniqueId)-End");
		return dualUtilizationModelList;
	}
}
