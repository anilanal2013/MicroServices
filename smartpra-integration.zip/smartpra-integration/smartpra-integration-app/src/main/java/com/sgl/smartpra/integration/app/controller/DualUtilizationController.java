package com.sgl.smartpra.integration.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.integration.app.service.DualUtilizationService;
import com.sgl.smartpra.integration.model.DualUtilizationIn;
import com.sgl.smartpra.integration.model.DualUtilizationModel;

@RestController
@RequestMapping("/api")
public class DualUtilizationController {

	@Autowired
	DualUtilizationService dualUtilizationService;
	
	@PostMapping("/dual-utilization")
	public Boolean crateDualUtilization(@Validated @RequestBody DualUtilizationIn dualUtilizationIn) throws Exception {
		return dualUtilizationService.createDualUtilization(dualUtilizationIn);
	}
	
	@GetMapping("/dual-utilization/documentUniqueId/{documentUniqueId}")
	public List<DualUtilizationModel> getDualUtilization(@PathVariable("documentUniqueId")String documentUniqueId) throws Exception{
		return dualUtilizationService.searchDualUtilization(documentUniqueId);	
	}
	
}
