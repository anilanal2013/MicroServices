/*
 * package com.sgl.smartpra.integration.app.handler;
 * 
 * import java.util.Objects;
 * 
 * import org.codehaus.jettison.json.JSONException; import
 * org.codehaus.jettison.json.JSONObject; import
 * org.springframework.http.HttpStatus; import
 * org.springframework.http.ResponseEntity; import
 * org.springframework.web.bind.annotation.RestControllerAdvice; import
 * org.springframework.web.context.request.WebRequest;
 * 
 * import com.fasterxml.jackson.core.JsonProcessingException; import
 * com.sgl.smartpra.integration.model.CurrencyRateOut;
 * 
 * @RestControllerAdvice public class ExceptionHandler {
 * 
 * @org.springframework.web.bind.annotation.ExceptionHandler(Exception.class)
 * protected ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest
 * request) throws JsonProcessingException { CurrencyRateOut currencyRateOut =
 * new CurrencyRateOut(); try { String message = ex.getMessage(); String cause
 * =message.contains(":") ? (String) message.split(":",2)[1] : message;
 * JSONObject exceptionCause = cause.contains("{") ? new JSONObject(cause) :
 * null; currencyRateOut.setErrorCode(Objects.nonNull(exceptionCause) ? (String)
 * exceptionCause.get("message") : cause); } catch (JSONException e) {
 * e.printStackTrace(); } return new ResponseEntity<Object>(currencyRateOut,
 * HttpStatus.BAD_REQUEST); }
 * 
 * }
 */