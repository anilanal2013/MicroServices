package com.sgl.smartpra.integration.app.util;

import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mq.producer.Producer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.ArrayList;
import java.util.List;

@Component
public class ExceptionMasterIntegrationUtil {

	@Autowired
	private Producer producer;

	@Value("${rabbitmq.exchange}")
	private String exchange;

	@Value("${rabbitmq.exception.msg.routingKey}")
	private String routingKey;

	/*@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;
*/
	private static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";

	private static final String PARAM_DEFAULT_CARRIER_NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";
	
	//private String EXCEPTION_CODE_STRING = RandomStringUtils.randomAlphanumeric(8);

	public void initExceptionMaster(ExceptionTransactionModel exceptionTransactionModel) {

	//	ExceptionTransactionModel transactionModel = prepareExceptionTransactionModel(exceptionTransactionModel);
		if (exceptionTransactionModel != null) {
			initExceptionTxnMsgSender(exceptionTransactionModel);
		}

	}

	private void initExceptionTxnMsgSender(ExceptionTransactionModel transactionModel) {
		try {
			producer.send(exchange, routingKey, transactionModel);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private ExceptionTransactionModel prepareExceptionTransactionModel(
			ExceptionTransactionModel exceptionTransactionModel) {
		
		
		//exceptionTransactionModel.setClientId(getHostCarrierDesigCode());
		exceptionTransactionModel.setExceptionCode("jZJEj630");
		exceptionTransactionModel.setClientId("abc");
		exceptionTransactionModel.setOrderId(String.valueOf(2));// for future use
		exceptionTransactionModel.setCreatedBy("SmartPRA File Validation Admin");
		exceptionTransactionModel.setEnvironment("S");
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setExceptionTransactionId(1L);

		List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
		ExceptionParametersValueModel parametersValueModel = new ExceptionParametersValueModel();
		parametersValueModel.setParameterName("countryName");
		parametersValueModel.setParameterValue("INDIA");
		parametersValueModelList.add(parametersValueModel);
		exceptionTransactionModel.setParametersValueList(parametersValueModelList);

		return exceptionTransactionModel;
	}

	/*private String getHostCarrierDesigCode() {
		String hostCarrierDesigCode = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient
				.getSystemParameterByparameterName(PARAM_DEFAULT_CARRIER_ALPHA_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierDesigCode = OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());
		}
		return hostCarrierDesigCode;
	}

	private String getHostCarrierCode() {
		String hostCarrierCode = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient
				.getSystemParameterByparameterName(PARAM_DEFAULT_CARRIER_NUMERIC_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierCode = OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());
		}

		return hostCarrierCode;
	}*/
	
	public static DateTimeFormatter getDateTimeFormatter(String d_MMM_yyPattern) {
		final DateTimeFormatter formatterInput = new DateTimeFormatterBuilder().parseCaseInsensitive()
				.appendPattern(d_MMM_yyPattern).toFormatter();
		return formatterInput;
	}
}
