package com.sgl.smartpra.integration.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
@EntityScan({ "com.sgl.smartpra.sales", "com.sgl.smartpra.flown", "com.sgl.smartpra.integration",
		"com.sgl.smartpra.interline" })
@EnableJpaRepositories({ "com.sgl.smartpra.sales", "com.sgl.smartpra.flown", "com.sgl.smartpra.integration",
		"com.sgl.smartpra.interline" })
public class SmartPRAIntegrationApp {
	public static void main(String[] args) {
		SpringApplication.run(SmartPRAIntegrationApp.class, args);
	}
}