package com.sgl.smartpra.integration.app.controller;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.context.WebApplicationContext;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.currency.model.CurrencyRate;
import com.sgl.smartpra.integration.app.config.FeignConfiguration.CurrencyFeignClient;
import com.sgl.smartpra.integration.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.integration.app.service.ExchangeRateService;
import com.sgl.smartpra.integration.app.service.impl.ExchangeRateServiceImpl;
import com.sgl.smartpra.integration.model.CurrencyRateIn;
import com.sgl.smartpra.integration.model.CurrencyRateOut;
import com.sgl.smartpra.master.model.SystemParameter;

@RunWith(SpringRunner.class)
@WebMvcTest
@ContextConfiguration(classes = { TestContext.class, WebApplicationContext.class, ExchangeRateServiceImpl.class })
public class ExchangeRateControllerTest {
	
	@InjectMocks
	private ExchangeRateController exchangeRateController;
	
	@Autowired
	private ExchangeRateService exchangeRateService;
	
	@MockBean
	private MasterFeignClient masterFeignClient;

	@MockBean
	private CurrencyFeignClient currencyFeignClient;
	
	@Before
	public void setUp() {
		ReflectionTestUtils.setField(exchangeRateController, "exchangeRateService", exchangeRateService);
		ReflectionTestUtils.setField(exchangeRateService, "masterFeignClient", masterFeignClient);
		ReflectionTestUtils.setField(exchangeRateService, "currencyFeignClient", currencyFeignClient);
	}
	
	@Test
	public void testExchangeRateSuccess() {
		CurrencyRateIn request = createRequest();
		Mockito.doReturn(masterDefaultCurrencyValue()).when(masterFeignClient).getSystemParameterByparameterName("DEFAULT_CURRENCY_CODE");
		Mockito.doReturn(masterIataCurrencyValue()).when(masterFeignClient).getSystemParameterByparameterName("IATA_BILLING_CURRENCY_CODES");
		Mockito.doReturn(exchangeRateValue()).when(currencyFeignClient).getEffectiveCurrencyRate(OptionalUtil.getValue(request.getRateType()), OptionalUtil.getValue(request.getCurrencyFromCode()), 
				OptionalUtil.getValue(request.getCurrencyToCode()), OptionalUtil.getValue(request.getConversionDate()));
		CurrencyRateOut exchangeRate = exchangeRateController.getExchangeRate(createRequest());
		assertNotNull(exchangeRate.getExchangeRate());
	}
	
	private CurrencyRate exchangeRateValue() {
		CurrencyRate currencyRate = new CurrencyRate();
		currencyRate.setExchangeRate(Optional.of("1.125"));
		return currencyRate;
	}

	private List<SystemParameter> masterIataCurrencyValue() {
		SystemParameter systemParameter = new SystemParameter();
		systemParameter.setParameterRangeFrom(Optional.of("USD, EUR, GBP"));
		return Collections.singletonList(systemParameter);
	}

	private List<SystemParameter> masterDefaultCurrencyValue() {
		SystemParameter systemParameter = new SystemParameter();
		systemParameter.setParameterRangeFrom(Optional.of("INR"));
		return Collections.singletonList(systemParameter);
	}

	private CurrencyRateIn createRequest() {
		CurrencyRateIn currencyRateIn = new CurrencyRateIn();
		currencyRateIn.setAmount(Optional.of(new BigDecimal(100)));
		currencyRateIn.setConversionDate(Optional.of("2018-12-10"));
		currencyRateIn.setCurrencyFromCode(Optional.of("EUR"));
		currencyRateIn.setCurrencyToCode(Optional.of("GBP"));
		currencyRateIn.setRateType(Optional.of("FDR"));
		return currencyRateIn;
	}

}
