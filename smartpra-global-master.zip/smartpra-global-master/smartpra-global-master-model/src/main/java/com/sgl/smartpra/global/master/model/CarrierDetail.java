package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CarrierDetail extends BaseModel {

	private static final long serialVersionUID = 1L;

	private Integer carrierDetailId;

	@OptionalNotEmpty(groups = { Create.class,Update.class })
	@FieldSize(min = 3, max = 3, message = "carrier code should be 3 characters", groups = { Update.class,
			Create.class })
	private Optional<String> carrierCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;
	
	@OptionalFieldSize(min = 1, max = 4, message = "carrierType  should be minimum of 1 and maximum of 4 characters", groups = {
			Create.class, Update.class })
	private Optional<String> carrierType;
	
	@RequiredNotEmpty(message = "Please provide base country Code", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 2, message = "base country code  should be minimum of 1 and maximum of 2 characters", groups = {
			Create.class, Update.class })
	private Optional<String> baseCountryCode;

	@RequiredNotEmpty(message = "Please provide base city Code", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, message = "base city code should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> baseCityCode;

	@RequiredNotEmpty(message = "Please provide list currency", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, message = "list currency  should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> listCurrency;

	@RequiredNotEmpty(message = "Please provide country Code Icao", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 2, message = "countryCodeIcao  should be minimum of 1 and maximum of 2 characters", groups = {
			Create.class, Update.class })
	private Optional<String> countryCodeIcao;

}
