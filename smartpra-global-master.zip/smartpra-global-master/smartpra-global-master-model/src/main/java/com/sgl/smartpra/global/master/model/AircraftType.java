package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class AircraftType extends BaseModel {

	/**
	 *  Serial Version Id
	 */
	private static final long serialVersionUID = 1L;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 10, message = "aircraftTypeCode should be minimum of 1 and maximum of 10 characters", groups = {
			Create.class, Update.class })
	private Optional<String> aircraftTypeCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 100, message = "description should be minimum of 1 and maximum of 100 characters", groups = {
			Create.class, Update.class })
	private Optional<String> description;
	
	
}
