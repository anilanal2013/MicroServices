package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.OptionalPattern;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ProvisoMainModel extends BaseModel {

	private static final long serialVersionUID = 1L;

	private Integer provisoMainId;

	@RequiredNotEmpty(message = "Please provide carrierNumCode", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, message = "Carrier Number code should be minimum of 3 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> carrierNumCode;

	@RequiredNotEmpty(message = "Please provide Proviso Seq Number", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Integer> provisoSeqNumber;

	@RequiredNotEmpty(message = "Please provide EffectiveFromDate", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;

	@RequiredNotEmpty(message = "Please provide EffectiveToDate", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;

	@FieldSize(min = 1, max = 60, message = "Description should be minimum of 1 and maximum of 60 characters", groups = {
			Create.class, Update.class })
	@OptionalNotEmpty(groups = Create.class)
	@RequiredNotEmpty(message = "Please provide Description", groups = Create.class)
	private Optional<String> description;

	@RequiredNotEmpty(message = "Please provide Proviso Section", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@OptionalPattern(regexp = "^([A-B1-99]*)$", message = "Proviso Section should be A,B and 1 to 99", groups = {
			Create.class, Update.class })
	@OptionalFieldSize(min = 1, max = 2, message = "Proviso Section should be minimum of 1 and maximum of 2 characters", groups = {
			Create.class, Update.class })
	private Optional<String> provisoSection;

	private Boolean additionalDiscountFlag;

	private Optional<String> provisoStatus;
	
	private transient Optional<String> discountCode;
}
