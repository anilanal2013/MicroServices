package com.sgl.smartpra.global.master.model;

import java.io.Serializable;

public class CommonIdName implements Serializable{
	private String id;
	private String name;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		if (id != null) {
			this.id = id.trim();
		}
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		if (name != null) {
			this.name = name.trim();
		}
	}
}
