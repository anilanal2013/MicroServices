package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.Range;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@SuppressWarnings("unused")
public class DictionaryValue extends BaseModel {

	/**
	 *  Serial version Id
	 */
	private static final long serialVersionUID = 1L;

	@Null(message = "dictionaryValueId is not valid input", groups = { Create.class, Update.class })
	private int dictionaryValueId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> dictionaryValue;

	private int dictionaryId;

	private Dictionary dictionary;
	
}
