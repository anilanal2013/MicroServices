package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.NotNull;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.ValidValues;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ProvisoRouting extends BaseModel {
	private static final long serialVersionUID = 1L;
	private Integer provisoRoutingId;
	private Optional<Integer> provisoMainId;

	@RequiredNotEmpty(message = "Please provide carrierNumCode", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, message = "Carrier Number code should be minimum of 3 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> carrierNumCode;

	@RequiredNotEmpty(message = "Please provide provisoSeqNumber", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Integer> provisoSeqNumber;

	@RequiredNotEmpty(message = "Please provide DetailRecNumber", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Integer> detailRecNumber;

	@RequiredNotEmpty(message = "Please provide RoutingRecNumber", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Integer> routingRecNumber;

	@FieldSize(min = 1, max = 1, message = "AreaTypeFlag should be of 1 character", groups = { Create.class,
			Update.class })
	@NotNull(message = "AreaTypeFlag is not a valid input", groups = { Create.class, Update.class })
	@ValidValues(values = "A,J", message = "AreaCheckType accepted values are A,J", groups = { Create.class, Update.class })
	private Optional<String> areaTypeFlag;

	@FieldSize(min = 1, max = 1, message = "AreaCheckType should be of 1 character", groups = { Create.class,
			Update.class })
	@NotNull(message = "AreaCheckType is not a valid input", groups = { Create.class, Update.class })
	@ValidValues(values = "B,W,F,O,T,H", message = "AreaCheckType accepted values are B,W,F,O,T,H", groups = { Create.class, Update.class })
	private Optional<String> areaCheckType;

	@RequiredNotEmpty(message = "Please provide AreaFrom", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 4, message = "AreaFrom should be minimum of 1 and maximum of 4 characters", groups = {
			Create.class, Update.class })
	private Optional<String> areaFrom;

	@OptionalFieldSize(min = 0, max = 4, message = "AreaTo should be minimum of null and maximum of 4 characters", groups = {
			Create.class, Update.class })
	private Optional<String> areaTo;
    
	@OptionalFieldSize(min = 0, max = 4, message = "AreaTo should be minimum of null and maximum of 4 characters", groups = {
			Create.class, Update.class })
	private Optional<String> areaVia;

}
