package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.OptionalPattern;
import com.sgl.smartpra.common.validator.Range;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class MPR extends BaseModel {

	private Integer minimumProrateRuleId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@OptionalPattern(regexp = "^\\d{0,3}(\\.\\d{1,3})?$", message = "please provide valid mprPercentage ", groups = {
			Create.class, Update.class })
	private Optional<String> mprPercentage;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@OptionalPattern(regexp = "^\\d{0,1}(\\.\\d{0,5})?$", message = "please provide valid mpqValue ", groups = {
			Create.class, Update.class })
	private Optional<String> mpqValue;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@Range(min = 0, max = 9, groups = { Create.class, Update.class })
	private Optional<Integer> quotientDecimals;

	@Null(message = "isActive is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;

}
