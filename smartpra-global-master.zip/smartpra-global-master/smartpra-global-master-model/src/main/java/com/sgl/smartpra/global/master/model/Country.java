package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Size;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.Range;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode(callSuper = false)
public class Country extends BaseModel {

	private static final long serialVersionUID = 1L;
	/*
	 * @RequiredNotEmpty(groups = Create.class)
	 * 
	 * @OptionalNotEmpty(groups = Update.class)
	 * 
	 * @FieldSize(min = 2, max = 2, message = "Country code should be 2 characters",
	 * groups = Create.class) private Optional<String> countryCode;
	 */
	
	@NotNull(message = "Please provide country code", groups = Create.class)
	@Size(min = 2, max = 2, message = "Country code should be 2 characters", groups = Create.class)
	private String countryCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, message = "Iso alph3 country code should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> isoAlpha3CountryCode;

	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@Range(min = 001, max = 999, message ="Country number should be 3 numeric value", groups = { Create.class,
	 Update.class })
	private Optional<Integer> countryNumber;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 30, message = "Country name should be minimum of 1 and maximum of 30 characters", groups = {
			Create.class, Update.class })	
	private Optional<String> countryName;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, message = "Iata area code should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> iataAreaCode;
	
	@Null(message = "isActive is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;	
	
	private Boolean copyFlag;
	
	private String copyRecordId;

}
