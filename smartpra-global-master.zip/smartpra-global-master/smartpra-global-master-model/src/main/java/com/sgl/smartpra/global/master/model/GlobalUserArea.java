package com.sgl.smartpra.global.master.model;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.sgl.smartpra.common.model.BaseMasterParent;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

public class GlobalUserArea extends BaseMasterParent {

	@Null(message = " globalUserAreaId Id is not a valid input", groups = { Create.class, Update.class })
	private Integer globalUserAreaId;

	@NotNull(message = "Please provide userAreaCode", groups = Create.class)
	@Size(min = 1, max = 3, message = "userAreaCode should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private String userAreaCode;

	@NotNull(message = "Please provide areaKey1", groups = Create.class)
	@Size(min = 1, max = 1, message = "areaKey1 should be maximum of 1 character", groups = {
			Create.class, Update.class })
	@Pattern(regexp = "(^P)", message = "areaKey1 should be 'P'", groups = Create.class)
	private String areaKey1;

	@NotNull(message = "Please provide areaKey2", groups = Create.class)
	@Size(min = 1, max = 5, message = "areaKey2 should be minimum of 1 and maximum of 5 characters", groups = {
			Create.class, Update.class })
	private String areaKey2;

	@NotNull(message = "Please provide areaKey3", groups = Create.class)
	@Size(min = 1, max = 5, message = "areaKey3 should be minimum of 1 and maximum of 5 characters", groups = {
			Create.class, Update.class })
	@Pattern(regexp = "^\\d+$", message = "areaKey3 should be positive number ", groups = Create.class)
	private String areaKey3;

	@NotNull(message = "Please provide areaKey4", groups = Create.class)
	@Size(min = 1, max = 5, message = "areaKey4 should be minimum of 1 and maximum of 5 characters", groups = {
			Create.class, Update.class })
	private String areaKey4;

	@NotNull(message = "Please provide userAreaName", groups = { Create.class, Update.class })
	@Size(min = 1, max = 30, message = "userAreaName should be minimum of 1 and maximum of 30 characters", groups = {
			Create.class, Update.class })
	private String userAreaName;

	@Size(min = 1, max = 1000, message = "areaIncludeList should be minimum of 1 and maximum of 1000 characters", groups = {
			Create.class, Update.class })
	private String areaIncludeList;

	@Size(min = 1, max = 1000, message = "areaExcludeList should be minimum of 1 and maximum of 1000 characters", groups = {
			Create.class, Update.class })
	private String areaExcludeList;

	private transient List<Geo> includeGeoList;

	private transient List<Geo> excludeGeoList;

	public Integer getGlobalUserAreaId() {
		return globalUserAreaId;
	}

	public void setGlobalUserAreaId(Integer globalUserAreaId) {
		this.globalUserAreaId = globalUserAreaId;
	}

	public String getUserAreaCode() {
		return userAreaCode;
	}

	public void setUserAreaCode(String userAreaCode) {
		if (userAreaCode != null)
			this.userAreaCode = userAreaCode.trim();
	}

	public String getAreaKey1() {
		return areaKey1;
	}

	public void setAreaKey1(String areaKey1) {
		if (areaKey1 != null)
			this.areaKey1 = areaKey1.trim();
	}

	public String getAreaKey2() {
		return areaKey2;
	}

	public void setAreaKey2(String areaKey2) {
		if (areaKey2 != null)
			this.areaKey2 = areaKey2.trim();
	}

	public String getAreaKey3() {
		return areaKey3;
	}

	public void setAreaKey3(String areaKey3) {
		if (areaKey3 != null)
			this.areaKey3 = areaKey3.trim();
	}

	public String getAreaKey4() {
		return areaKey4;
	}

	public void setAreaKey4(String areaKey4) {
		if (areaKey4 != null)
			this.areaKey4 = areaKey4.trim();
	}

	public String getUserAreaName() {
		return userAreaName;
	}

	public void setUserAreaName(String userAreaName) {
		if (userAreaName != null)
			this.userAreaName = userAreaName.trim();
	}

	public String getAreaIncludeList() {
		return areaIncludeList;
	}

	public void setAreaIncludeList(String areaIncludeList) {
		if (areaIncludeList != null)
			this.areaIncludeList = areaIncludeList.trim();
	}

	public String getAreaExcludeList() {
		return areaExcludeList;
	}

	public void setAreaExcludeList(String areaExcludeList) {
		if (areaExcludeList != null)
			this.areaExcludeList = areaExcludeList.trim();
	}

	public List<Geo> getIncludeGeoList() {
		return includeGeoList;
	}

	public void setIncludeGeoList(List<Geo> includeGeoList) {
		this.includeGeoList = includeGeoList;
	}

	public List<Geo> getExcludeGeoList() {
		return excludeGeoList;
	}

	public void setExcludeGeoList(List<Geo> excludeGeoList) {
		this.excludeGeoList = excludeGeoList;
	}

}