package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ChargeCategory extends BaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@RequiredNotEmpty(groups = Create.class)
	@FieldSize(min = 1, max = 3, groups = { Create.class, Update.class })
	private Optional<String> chargeCategoryCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 30, groups = { Create.class, Update.class })
	private Optional<String> chargeCategoryName;

	@FieldSize(min = 0, max = 3, groups = { Create.class, Update.class })
	private Optional<String> financialTransactionType;

	private Optional<Boolean> locationRequiredIndicator;

	private Optional<Boolean> poNumberRequiredIndicator;
	
	@FieldSize(min=0,max=50,groups= {Create.class,Update.class})
	private Optional<String> accountCode;
	
	@FieldSize(min=0,max=50,groups= {Create.class,Update.class})
	private Optional<String> attribute1;
	
	@FieldSize(min=0,max=50,groups= {Create.class,Update.class})
	private Optional<String> attribute2;
	
	@FieldSize(min=0,max=50,groups= {Create.class,Update.class})
	private Optional<String> profitCentre;
	
	@FieldSize(min=0,max=50,groups= {Create.class,Update.class})
	private Optional<String> costCenterCode;

	@Null(message = "activate is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;

}