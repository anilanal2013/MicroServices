package com.sgl.smartpra.global.master.model;

import com.sgl.smartpra.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Optional;

@Data
@EqualsAndHashCode(callSuper = false)
public class GlobalClient extends BaseModel {

    private static final long serialVersionUID = 1L;

    private Optional<String> clientId;

    private Optional<String> clientName;

    private Optional<String> clientTitle;

    private Optional<String> appUrl;

    private Optional<String> ipRange;

    private Optional<String> clientAddress;

    private Optional<String> city;

    private Optional<String> region;

    private Optional<String> phone;

    private Optional<String> fax;

    private Optional<Boolean> isActive;

}
