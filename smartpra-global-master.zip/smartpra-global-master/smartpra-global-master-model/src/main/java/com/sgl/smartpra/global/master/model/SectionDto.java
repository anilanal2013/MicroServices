/**
 * 
 */
package com.sgl.smartpra.global.master.model;

import java.io.Serializable;

import javax.persistence.Column;

import lombok.Getter;
import lombok.Setter;

/**
 * @author kanprasa
 *
 */
@Getter
@Setter
public class SectionDto implements Serializable {

    private static final long serialVersionUID = 1L;
    
	private Integer sectionMasterId;
	private String sectionNameActual;
	private String chargeCode;
	private String sectionElementNameActual;
	private Boolean displayIndicator;
	private String applicability;
	private String mandatoryFromPeriod;
	private String nonMandatoryFromPeriod;

	public SectionDto() {}
	
	public SectionDto(Integer sectionMasterId, String sectionNameActual, String chargeCode, 
			String sectionElementNameActual, Boolean displayIndicator, String applicability,
			String mandatoryFromPeriod, String nonMandatoryFromPeriod) {
		this.sectionMasterId = sectionMasterId;
		this.sectionNameActual = sectionNameActual;
		this.chargeCode = chargeCode;
		this.sectionElementNameActual = sectionElementNameActual;
		this.displayIndicator = displayIndicator;
		this.applicability = applicability;
		this.mandatoryFromPeriod = mandatoryFromPeriod;
		this.nonMandatoryFromPeriod = nonMandatoryFromPeriod;
	}
}
