package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class Fares extends BaseModel {
	
	private static final long serialVersionUID = 1L;
	
	private Integer fareId;
	 
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3,message = "Tariff code should be 3 characters", groups = { Create.class, Update.class })
	private Optional<String> tariffCode; 
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 2, max = 2,message = "CXR code should be 2 characters", groups = { Create.class, Update.class })
	private Optional<String> cxrCode;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3,message = "Origin city code should be 3 characters", groups = { Create.class, Update.class })
	private Optional<String> originCity;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3,message = "Destination city code should be 3 characters", groups = { Create.class, Update.class })
	private Optional<String> destinationCity;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 8,message = "Fare basis should be 8 characters", groups = { Create.class, Update.class })
	private Optional<String> fareBasis;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;
	
	@OptionalFieldSize(min = 4, max = 4, message = "Rule number should be 4 characters", groups = { Create.class,
			Update.class })
	private Optional<String> ruleNumber;
	
	@OptionalFieldSize(min = 4, max = 4, message = "Routing number should be 4 digits", groups = { Create.class,
			Update.class } )
	private Optional<String> routingNumber;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 1, message = "OW-RT should be only 1 character", groups = { Create.class, Update.class })
	private Optional<String> owRtIndicator;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	//@ValidValues(values = "USD,CAD", message = "Accepted values are USD, CAD", groups = { Create.class, Update.class })
	@FieldSize(min = 3, max = 3, message = "Fare Currency should be only USD, CAD", groups = { Create.class, Update.class })
	private Optional<String> fareCurrency;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)	
	private Optional<Double> fareValue;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)	
	@FieldSize(min = 3, max = 3, message = "Fare Type should be only 3 characters", groups = { Create.class, Update.class })
	private Optional<String> fareType;
	
	@OptionalFieldSize(min = 0, max = 1, message = "Construction should be only 1 character", groups = { Create.class, Update.class })
	private Optional<String> construction;
	
	@OptionalFieldSize(min = 0, max = 1, message = "Prorate should be only 1 character", groups = { Create.class, Update.class })
	private Optional<String> prorate;
	
	@OptionalFieldSize(min = 0, max = 1, message = "Differential should be only 1 character", groups = { Create.class, Update.class })
	private Optional<String> differential;
	
	@OptionalFieldSize(min = 0, max = 1, message = "Proportional should be only 1 character", groups = { Create.class, Update.class })
	private Optional<String> proportional;
	
	@OptionalFieldSize(min = 2, max = 2, message = "Fare Foot Note should be only 2 character", groups = { Create.class, Update.class })
	private Optional<String> fareFootNote;
	
	@OptionalFieldSize(min = 1, max = 1, message = "Action should be only 1 character", groups = { Create.class, Update.class })
	private Optional<String> action;
	
	@OptionalFieldSize(min = 3, max = 3, message = "Link Number should be only 3 digit", groups = { Create.class, Update.class })
	private Optional<String> linkNumber;
	
	@OptionalFieldSize(min = 5, max = 5, message = "Sequence Number should be only 5 digit", groups = { Create.class, Update.class })
	private Optional<String> sequenceNumber;
	
	@OptionalFieldSize(min = 5, max = 5, message = "Old MCN should be only 5 digit", groups = { Create.class, Update.class })
	private Optional<String> oldMCN;
	
	@OptionalFieldSize(min = 5, max = 5, message = "New MCN should be only 5 digit", groups = { Create.class, Update.class })
	private Optional<String> newMCN;
	
	@Null(message = "activate is not a valid input", groups = { Create.class, Update.class })
	private Optional<Boolean> activate;	
}
