package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.OptionalPattern;
import com.sgl.smartpra.common.validator.Range;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class Currency extends BaseModel {

	private static final long serialVersionUID = 1L;

	@RequiredNotEmpty(message = "Please provide Currency Code",  groups = Create.class)
	@OptionalPattern(regexp = "^[a-zA-Z]*$", message = "Only alpha values can be allowed", groups = {
			Create.class, Update.class })
	@FieldSize(min = 1, max = 3, message = "Currency Code should be minimum of 1 and maximum of 3 characters", groups = { Update.class, Create.class })
	private Optional<String> currencyCode;

	@RequiredNotEmpty(message = "Please provide Currency Name",  groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 50, message = "Currency Name should be minimum of 1 and maximum of 50 characters", groups = { Update.class, Create.class })
	private Optional<String> currencyName;

	@RequiredNotEmpty(message = "Please provide currency Numeric Code",  groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@Range(min = 1, max = 999, message = "Currency Numeric Code should be minimum of 1 and maximum of 999", groups = { Update.class, Create.class })
	private Optional<Integer> currencyNumericCode;
	
	@Null(message = "isActive is not a valid input", groups = { Create.class, Update.class })
	private Boolean isActive;

}
