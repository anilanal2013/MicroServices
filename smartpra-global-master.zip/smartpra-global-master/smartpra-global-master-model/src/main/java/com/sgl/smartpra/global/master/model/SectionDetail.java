package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.OptionalPattern;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class SectionDetail extends BaseModel {


	private Integer sectionDetailId;

	private Integer sectionMasterId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 50, message = "sectionElementName should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> sectionElementName;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@OptionalPattern(regexp = "(^RA|R|M)", message = "Only valid values for applicability field is 'RA'|'R'|'M'", groups = {
			Create.class, Update.class })
	private Optional<String> applicability;

	@OptionalPattern(regexp = "^\\d{0,8}(\\.\\d{1,3})?$", message = "The displayOrderNumber should be of 10,2 format", groups = {
			Create.class, Update.class })
	private Optional<String> displayOrderNumber;

	@NotNull(message = "Please provide displayIndicator", groups = { Update.class })
	private Boolean displayIndicator;

	@OptionalPattern(regexp = "^[0-1]+$", message = "maxOccurrence value must be 0 or 1 only", groups = { Create.class,
			Update.class })
	private Optional<String> minOccurrence;

	@OptionalPattern(regexp = "^[-1-9]{1,3}$", message = "maxOccurrence value must be -1 or 999", groups = {
			Create.class, Update.class })
	private Optional<String> maxOccurrence;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@OptionalPattern(regexp = "(^N|A|AN|DT)", message = "Only valid values for elementType field is 'N'|'AN'|'DT'|DT", groups = {
			Create.class, Update.class })
	@FieldSize(min = 1, max = 2, message = "elementType should be minimum of 1 and maximum of 2 characters", groups = {
			Create.class, Update.class })
	private Optional<String> elementType;

	@OptionalPattern(regexp = "^[0-9]\\d*$", message = "elementSize value must be positive", groups = { Create.class,
			Update.class })
	private Optional<String> elementSize;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@OptionalPattern(regexp = "^\\d{0,8}(\\.\\d{1,3})?$", message = "The orderNumber should be of 10,2 format", groups = {
			Create.class, Update.class })
	private Optional<String> orderNumber;

	@FieldSize(min = 1, max = 50, message = "validationClass should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> validationClass;

	@FieldSize(min = 1, max = 50, message = "sectionNameActual should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> sectionNameActual;

	@FieldSize(min = 1, max = 50, message = "parentSectionElementName should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> parentSectionElementName;

	private Integer allowedOccurrence;

	@FieldSize(min = 1, max = 1, message = "uomType should be minimum of 1 and maximum of 1 characters", groups = {
			Create.class, Update.class })
	private Optional<String> uomType;

	@FieldSize(min = 1, max = 250, message = "hintValue should be minimum of 1 and maximum of 250 characters", groups = {
			Create.class, Update.class })
	private Optional<String> hintValue;

	@FieldSize(min = 1, max = 9, message = "mandatoryFromPeriod should be minimum of 1 and maximum of 9 characters", groups = {
			Create.class, Update.class })
	private Optional<String> mandatoryFromPeriod;

	@FieldSize(min = 1, max = 9, message = "mandatoryFromPeriod should be minimum of 1 and maximum of 9 characters", groups = {
			Create.class, Update.class })
	private Optional<String> nonMandatoryFromPeriod;

	@FieldSize(min = 1, max = 50, message = "tagName should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> tagName;

	@Null(message = "activate is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;

}
