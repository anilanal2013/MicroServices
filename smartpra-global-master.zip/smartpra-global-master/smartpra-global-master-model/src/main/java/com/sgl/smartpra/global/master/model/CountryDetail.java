package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.ValidValues;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CountryDetail extends BaseModel {
	
	private static final long serialVersionUID = 1L;

	@Null(message = "countryDetail Id is not a valid input", groups = { Create.class, Update.class })
	private Integer countryDtlId;
	
	@OptionalNotEmpty(groups = {Create.class, Update.class})
	@FieldSize(min = 2, max = 2, message = "Country code should be 2 characters", groups = Create.class)
	private Optional<String> countryCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromPeriod;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToPeriod;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, message = "Country base currency Code should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> baseCurrencyCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, message = "Country dual currency code should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> dualCurrencyCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, message = "Country strong currency code should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> strongCurrencyCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(max = 1, message = "Country attachmentAIndi should be maximum of 1 character", groups = { Create.class,
			Update.class })
	private Optional<String> attachmentAIndi;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(max = 1, message = "Country euMember should be maximum of 1 character", groups = { Create.class,
			Update.class })
	@ValidValues(values = "Y,N", message = "Country euMember should be Y or N", groups = { 
			Create.class, Update.class })
	private Optional<String> euMember;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 2, message = "Parent country code should be minimum of 1 and maximum of 2 characters", groups = {
			Create.class, Update.class })
	private Optional<String> parentCountryCode;

}
