package com.sgl.smartpra.global.master.model;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;

@Data
public class TicketOverwrite {
	
	private Long scenarioNo;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 1, message = "auditTrail should be minimum of 1 and maximum of 1 characters", groups = {
			Create.class, Update.class })
	private Optional<String> auditTrail;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 1, message = "isActive should be minimum of 1 and maximum of 1 characters", groups = {
			Create.class, Update.class })
	private Optional<String> isActive;

	private String processStatus;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 2, message = "result should be minimum of 1 and maximum of 2 characters", groups = {
			Create.class, Update.class })
	private Optional<String> result;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 20, message = "source1 should be minimum of 1 and maximum of 20 characters", groups = {
			Create.class, Update.class })
	private Optional<String> source1;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 20, message = "source2 should be minimum of 1 and maximum of 20 characters", groups = {
			Create.class, Update.class })
	private Optional<String> source2;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 10, message = "transationCode should be minimum of 1 and maximum of 10 characters", groups = {
			Create.class, Update.class })
	private Optional<String> transationCode;
	
	private List<TicketOverwriteDetail> ticketOverwiteDetails;

}
