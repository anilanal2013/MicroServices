package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_NULL)
public class OneCountry extends BaseModel {
	
	private static final long serialVersionUID = 1L;
	
	private Integer oneCountryId;

	@RequiredNotEmpty(message = "Please provide oneCountryCode", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 6, message = "oneCountryCode should be minimum of 1 and maximum of 6 characters", groups = {
			Create.class, Update.class })
	private Optional<String> oneCountryCode;

	@RequiredNotEmpty(message = "Please provide oneCountryDescription", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 25, message = "oneCountryDescription should be minimum of 1 and maximum of 25 characters", groups = {
			Create.class, Update.class })
	private Optional<String> oneCountryDescription;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;

	@RequiredNotEmpty(message = "Please provide countryCodeList", groups = { Create.class, Update.class })
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 200, message = "countryCodeList should be minimum of 1 and maximum of 200 characters", groups = {
			Create.class, Update.class })
	private Optional<String> countryCodeList;
	
	@Null(message = "isActive is not a valid input", groups = { Create.class, Update.class })
	private Boolean isActive;

	
}
