package com.sgl.smartpra.global.master.model;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ProvisoDetailStgModel extends BaseModel {

	private static final long serialVersionUID = 1L;

	private Integer provisoDetailId;

	private Optional<Integer> provisoMainId;

	@RequiredNotEmpty(message = "Please provide Carrier Num Code", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, message = "Carrier Number code should be minimum of 3 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> carrierNumCode;

	@RequiredNotEmpty(message = "Please provide Proviso Seq Number", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Integer> provisoSeqNumber;

	private Optional<Integer> detailRecNumber;

	@RequiredNotEmpty(message = "Please provide Fb Group Code", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 5, message = "Fb Group Code code should be minimum of 1 and maximum of 5 characters", groups = {
			Create.class, Update.class })
	private Optional<String> fbGroupCode;

	private Optional<String> sectorFbFlag;

	@OptionalFieldSize(max = 4, message = "SectorFrom should be maximum of 4 characters", groups = { Create.class,
			Update.class })
	private Optional<String> sectorFrom;

	@OptionalFieldSize(max = 4, message = "SectorTo should be maximum of 4 characters", groups = { Create.class,
			Update.class })
	private Optional<String> sectorTo;

	private Optional<String> percentage;

	private Boolean articleC;

	private Boolean exceptionIndicator;

	private Optional<Integer> exceptionFromRecord;

	private Optional<Integer> exceptionToRecord;

	@FieldSize(min = 0, max = 15, message = "Sub-ParaReference can hold maximum of 15 characters", groups = {
			Create.class, Update.class })
	private Optional<String> subParaReference;

	private transient List<Geo> sectorFromInclude;

	private transient List<Geo> sectorFromExclude;

	private transient List<Geo> sectorToInclude;

	private transient List<Geo> sectorToExclude;

	private transient String fromUserSectorName;

	private transient String toUserSectorName;

}
