package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.OptionalPattern;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CurrencyDetail extends BaseModel {

	private static final long serialVersionUID = 1L;
	
	@Null(message = "Currency Detail Id is not a valid input", groups = { Create.class, Update.class })
	private Integer currencyDetailId;
	
	@RequiredNotEmpty(message = "Please provide Currency Code",  groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, message = "Currency code should be minimum of 1 and maximum of 3 characters", groups = { Update.class, Create.class })
	private Optional<String> currencyCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;
	
	@OptionalNotEmpty(groups = {Create.class, Update.class})
	private Optional<String> localCurrencyFare;
	
	@OptionalNotEmpty(groups = {Create.class, Update.class})
	private Optional<String> otherCharges;
	
	@OptionalNotEmpty(groups = {Create.class, Update.class})
	private Optional<String> decimalUnit;

	@OptionalFieldSize(min = 1, max = 2, message = "method of rounding  should be minimum of 1 and maximum of 2 characters", groups = { Update.class, Create.class })
	private Optional<String> methodOfRounding;

}
