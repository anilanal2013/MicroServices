package com.sgl.smartpra.global.master.model;

import java.util.List;
import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class Dictionary extends BaseModel {

	/**
	 *  Serial Version Id
	 */
	private static final long serialVersionUID = 1L;

	@Null(message = "dictionaryId is not valid input", groups = { Create.class, Update.class })
	private int dictionaryId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> dictionaryDefine;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> elementName;

	private List<DictionaryValue> dictionaryValue;
}
