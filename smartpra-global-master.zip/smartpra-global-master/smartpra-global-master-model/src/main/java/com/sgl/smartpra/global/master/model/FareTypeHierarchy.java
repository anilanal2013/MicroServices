package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.Range;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FareTypeHierarchy extends BaseModel {

	private static final long serialVersionUID = 1L;

	private Integer fareTypeHierarchyId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 1, message = "Cabin should be 1 character", groups = { Create.class, Update.class })
	private Optional<String> cabin;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@Range(min = 1, max = 9, message = "Cabin Level should be a single digit number", groups = { Create.class,
			Update.class })
	private Optional<Integer> cabinLevel;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, message = "FareTypeCode should be 3 character", groups = { Create.class,
			Update.class })
	private Optional<String> fareTypeCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Integer> fareTypeLevel;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;

	@Null(message = "activate is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;

}