package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ChargeCode extends BaseModel {

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 6, groups = { Create.class, Update.class })
	private Optional<String> chargeCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 100, groups = { Create.class, Update.class })
	private Optional<String> chargeCodeName;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, groups = { Create.class, Update.class })
	private Optional<String> chargeCategoryCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Boolean> chargeCodeTypeRequiredIndicator;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Boolean> locationCodeRequiredIndicator;

	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 50, groups = { Create.class, Update.class })
	private Optional<String> accountCode;

	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 50, groups = { Create.class, Update.class })
	private Optional<String> profitCentre;

	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 50, groups = { Create.class, Update.class })
	private Optional<String> attribute1;

	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 50, groups = { Create.class, Update.class })
	private Optional<String> attribute2;

	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 20, groups = { Create.class, Update.class })
	private Optional<String> costCenterCode;

	@OptionalNotEmpty(groups = Update.class)
	private Optional<Boolean> poLineItemRequiredIndicator;

	private Optional<Boolean> productIdRequiredIndicator;

	@Null(message = "activate is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;

}
