package com.sgl.smartpra.global.master.model;

import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Size;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class StandardArea extends BaseModel {

	@NotNull(message = "Please provide standardArea Code", groups = Create.class)
	@Null(message = "standardArea Code is not a valid input", groups = Update.class)
	@Size(min = 1, max = 3, message = "standardArea Code should be minimum of 1 and maximum of 3 characters", groups = Create.class)
	private String standardAreaCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 100, groups = { Create.class, Update.class })
	private Optional<String> standardAreaName;

	private String standardAreaList;

	@NotNull(message = "Please provide standardAreaGeoList", groups = Create.class)
	private List<Geo> standardAreaGeoList;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 1, groups = { Create.class, Update.class })
	private Optional<String> areaType;

	@Null(message = "activate is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;

}