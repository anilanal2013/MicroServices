package com.sgl.smartpra.global.master.model;
import java.io.Serializable;


public class FrequencyTypeDTO implements Serializable {



    private static final long serialVersionUID = 1L;
    
	
    private Long frequencyTypeId;

  
    private String frequencyTypeName;

    private Boolean isActive;
   


    public Long getFrequencyTypeId() {
		return frequencyTypeId;
	}

	public void setFrequencyTypeId(Long frequencyTypeId) {
		this.frequencyTypeId = frequencyTypeId;
	}

	public String getFrequencyTypeName() {
		return frequencyTypeName;
	}

	public void setFrequencyTypeName(String frequencyTypeName) {
		this.frequencyTypeName = frequencyTypeName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}



    @Override
    public String toString() {
        return "FrequencyType{" +
            "id=" + getFrequencyTypeId() +
            ", frequecncyTypeName='" + getFrequencyTypeName() + "'" +
            ", isActive='" + getIsActive() + "'" +
            "}";
    }

}
