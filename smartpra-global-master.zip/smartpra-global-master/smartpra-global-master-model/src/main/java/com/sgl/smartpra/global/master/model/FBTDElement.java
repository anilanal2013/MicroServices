package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FBTDElement  extends BaseModel {

	private static final long serialVersionUID = 1L;
	
	@Null(message = " fbtdElement Id is not a valid input", groups = { Create.class, Update.class })
	private Integer fbtdId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Integer> elementType;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class, Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class, Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 2, groups = { Create.class, Update.class })
	private Optional<String> elementCode;

	@OptionalFieldSize(min = 0, max = 60, groups = { Create.class, Update.class })
	private Optional<String> elementDescription;

	@OptionalFieldSize(min = 0, max = 1, groups = { Create.class, Update.class })
	private Optional<String> additionalInfo;

	@OptionalFieldSize(min = 0, max = 1, groups = { Create.class, Update.class })
	private Optional<String> otherInfo;

	@OptionalFieldSize(min = 0, max = 1, groups = { Create.class, Update.class })
	private Optional<String> normalSpecial;
	
	@Null(message = "activate is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;
}
