package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ChargeCodeType extends BaseModel {
	
	/**
	 *  Serial version Id
	 */
	private static final long serialVersionUID = 1L;

	@Null(message = "chargeCodeTypeId is not valid input", groups = { Create.class, Update.class })
	private Integer chargeCodeTypeId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, message = "chargeCategoryCode should be of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> chargeCatCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 6, max = 6, message = "chargeCode should be of 6 characters", groups = {
			Create.class, Update.class })
	private Optional<String> chargeCode;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 100, message = "chargeCodeType should be minimum of 1 and maximum of 100 characters", groups = {
			Create.class, Update.class })
	private Optional<String> chargeCodeType;

}
