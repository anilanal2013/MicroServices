package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;

@Data
public class TicketOverwriteDetail {

	private Long scenrioDtlId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 50, message = "columnName should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> columnName;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 50, message = "tableName should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> tableName;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Long> scenarioNo;
}
