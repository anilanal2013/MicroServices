package com.sgl.smartpra.global.master.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Size;

import com.sgl.smartpra.common.model.BaseMaster;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

public class StandardAreaDetail extends BaseMaster {
	@Null(message = " standardAreaDetail Id is not a valid input", groups = { Create.class, Update.class })
	private Integer standardAreaDetailId;

	@Null(message = "StandardArea Code is not a valid input", groups = { Create.class, Update.class })
	@Size(min = 1, max = 3, message = "standardAreaCode should be minimum of 1 and maximum of 3 characters", groups = Create.class)
	private String standardAreaCode;

	@NotNull(message = "Please provide geographicalType Id", groups = { Create.class, Update.class })
	private Integer geographicalTypeId;

	@NotNull(message = "Please provide standardArea value", groups = { Create.class, Update.class })
	@Size(min = 1, max = 6, message = "standardArea value should be minimum of 1 and maximum of 6 characters", groups = Create.class)
	private String standardAreaValue;

	public Integer getStandardAreaDetailId() {
		return standardAreaDetailId;
	}

	public void setStandardAreaDetailId(Integer standardAreaDetailId) {
		this.standardAreaDetailId = standardAreaDetailId;
	}

	public String getStandardAreaCode() {
		return standardAreaCode;
	}

	public void setStandardAreaCode(String standardAreaCode) {
		if (standardAreaCode != null)
			this.standardAreaCode = standardAreaCode.trim();
	}

	public Integer getGeographicalTypeId() {
		return geographicalTypeId;
	}

	public void setGeographicalTypeId(Integer geographicalTypeId) {
		this.geographicalTypeId = geographicalTypeId;
	}

	public String getStandardAreaValue() {
		return standardAreaValue;
	}

	public void setStandardAreaValue(String standardAreaValue) {
		if (standardAreaValue != null)
			this.standardAreaValue = standardAreaValue.trim();
	}

}
