package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ListOfValues extends BaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Null(message = " lovId Id is not a valid input", groups = { Create.class, Update.class })
	private Integer lovId;
	
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 2, max = 2, message = "clientId should be minimum and maximum of 2 characters", groups = { Create.class, Update.class })
	private Optional<String> clientId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 30, max = 30, message = "tableName should be minimum of 1 character", groups = { Create.class,
			Update.class })
	private Optional<String> tableName;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 30, max = 30, message = "columeName should be minimum of 1 character", groups = { Create.class,
			Update.class })
	private Optional<String> columnName;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 20, max = 20, message = "fieldValue should be minimum of 1 character", groups = { Create.class,
			Update.class })
	private Optional<String> fieldValue;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 100, max = 100, message = "fieldShortDescription should be minimum of 1 character", groups = {
			Create.class, Update.class })
	private Optional<String> fieldShortDescription;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 2, max = 2, message = "addlDescription should be minimum of 1 character", groups = { Create.class,
			Update.class })
	private Optional<String> addlDescription;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> displayOrder;
	
	@OptionalFieldSize(min = 0, max = 30, groups = { Create.class, Update.class })
	private Optional<String> dependentColumnName;
	
	@OptionalFieldSize(min = 0, max = 20, groups = { Create.class, Update.class })
	private Optional<String> dependentFieldValue;
	
	@Null(message = "isActive is not a valid input", groups = { Create.class, Update.class })
	private Boolean isActive;
}
