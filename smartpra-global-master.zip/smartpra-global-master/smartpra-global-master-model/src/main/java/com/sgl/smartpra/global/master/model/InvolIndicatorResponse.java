package com.sgl.smartpra.global.master.model;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class InvolIndicatorResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private long totalCount;

	private List<InvolIndicator> data;
}
