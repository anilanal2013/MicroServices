package com.sgl.smartpra.global.master.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.sgl.smartpra.common.model.BaseMasterParent;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

public class UOM extends BaseMasterParent {

	@Null(message = "uom Id is not a valid input", groups = Create.class)
	private Integer uomId;

	@NotNull(message = "Please provide UOM Code", groups = { Create.class, Update.class })
	@Size(min = 1, max = 3, message = "uomCode should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private String uomCode;

	@NotNull(message = "Please provide uomType", groups = { Create.class, Update.class })
	@Size(min = 1, max = 1, message = "uomValue should be minimum of 1 and maximum of 1 characters", groups = {
			Create.class, Update.class })
	@Pattern(regexp = "[A-Za-z]", message = "uomType should be  maximum of 1 characters any of {A-Z or a-z}", groups = {
			Create.class, Update.class })
	private String uomType;

	@NotNull(message = "Please provide uomValue", groups = { Create.class, Update.class })
	@Size(min = 1, max = 50, message = "uomValue should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private String uomValue;

	public Integer getUomId() {
		return uomId;
	}

	public void setUomId(Integer uomId) {
		this.uomId = uomId;
	}

	public String getUomCode() {
		return uomCode;
	}

	public void setUomCode(String uomCode) {
		if (uomCode != null)
			this.uomCode = uomCode.trim();

	}

	public String getUomType() {
		return uomType;
	}

	public void setUomType(String uomType) {
		if (uomType != null)
			this.uomType = uomType.trim();

	}

	public String getUomValue() {
		return uomValue;
	}

	public void setUomValue(String uomValue) {
		if (uomValue != null)
			this.uomValue = uomValue.trim();

	}

}
