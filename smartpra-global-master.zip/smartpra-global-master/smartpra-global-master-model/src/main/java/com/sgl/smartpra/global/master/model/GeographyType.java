package com.sgl.smartpra.global.master.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.sgl.smartpra.common.model.BaseMasterParent;
import com.sgl.smartpra.common.validator.group.Create;

public class GeographyType extends BaseMasterParent {

	@NotNull(message = "Please provide geographicalType Id", groups = Create.class)
	private Integer geographicalTypeId;

	@NotNull(message = "Please provide standardArea value", groups = Create.class)
	@Size(min = 1, max = 20, message = "geoType should be minimum of 1 and maximum of 30 characters", groups = Create.class)
	private String geoType;

	public Integer getGeographicalTypeId() {
		return geographicalTypeId;
	}

	public void setGeographicalTypeId(Integer geographicalTypeId) {
		this.geographicalTypeId = geographicalTypeId;
	}

	public String getGeoType() {
		return geoType;
	}

	public void setGeoType(String geoType) {
		if (geoType != null) {
			this.geoType = geoType.trim();
		}
	}

}
