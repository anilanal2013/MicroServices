package com.sgl.smartpra.global.master.model;

import java.util.List;
import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.Range;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class SIRSRates extends BaseModel {

	private Integer sirsRateId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 4, groups = { Create.class, Update.class })
	private Optional<String> fromArea;

	@FieldSize(min = 1, max = 1, groups = { Create.class, Update.class })
	private Optional<String> geoAreaIndicator;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 1, groups = { Create.class, Update.class })
	private Optional<String> globalRegion;

	@Null(message = "isActive is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
//	@Range(min = 01, max = 99, groups = { Create.class, Update.class })
	private Optional<String> sirsPercentage;

	@FieldSize(min = 1, max = 4, groups = { Create.class, Update.class })
	private Optional<String> toArea;

	private transient List<Geo> fromAreaInclude;
	private transient List<Geo> fromAreaExclude;
	private transient List<Geo> toAreaInclude;
	private transient List<Geo> toAreaExclude;
	private transient String userFromAreaName;
	private transient String userToAreaName;

}
