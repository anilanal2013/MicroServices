package com.sgl.smartpra.global.master.model;

public class Geo {
	private Integer geoTypeId;
	private String geoTypeValue;

	public Integer getGeoTypeId() {
		return geoTypeId;
	}

	public void setGeoTypeId(Integer geoTypeId) {
		this.geoTypeId = geoTypeId;
	}

	public String getGeoTypeValue() {
		return geoTypeValue;
	}

	public void setGeoTypeValue(String geoTypeValue) {
		this.geoTypeValue = geoTypeValue;
	}

	public String toString() {
		return geoTypeId + geoTypeValue;
	}

}
