package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.OptionalPattern;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class Section extends BaseModel {

	private Integer sectionMasterId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 6, message = "sectionCode should be minimum of 1 and maximum of 6 characters", groups = {
			Create.class, Update.class })
	private Optional<String> sectionCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 50, message = "sectionName should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> sectionName;

	@FieldSize(min = 1, max = 6, message = "chargeCode should be minimum of 1 and maximum 6 character only", groups = {
			Create.class, Update.class })
	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> chargeCode;

	@FieldSize(min = 1, max = 50, message = "sectionNameActual should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> sectionNameActual;

	@OptionalPattern(regexp = "^\\d{0,8}(\\.\\d{1,2})?$", message = "The displayOrderNumber should be of 10,2 format", groups = {
			Create.class, Update.class })
	private Optional<String> sectionOrderNumber;

	@OptionalPattern(regexp = "^[0-1]+$", message = "maxOccurrence value must be 0 or 1 only", groups = {
			Create.class, Update.class })
	private Optional<String> minOccurrence;

	@OptionalPattern(regexp = "^[-1-9]{1,3}$", message = "maxOccurrence value must be -1 or 999", groups = {
			Create.class, Update.class })
	private Optional<String> maxOccurrence;

	@Null(message = "activate is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;

}