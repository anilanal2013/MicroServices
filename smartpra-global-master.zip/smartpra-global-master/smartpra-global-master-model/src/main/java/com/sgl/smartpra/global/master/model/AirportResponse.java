package com.sgl.smartpra.global.master.model;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class AirportResponse implements Serializable{

	private static final long serialVersionUID = 1L;

	private Long totalCount;

	private List<Airport> data;

}
