package com.sgl.smartpra.global.master.model;

import java.math.BigDecimal;
import java.util.Optional;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class RateAndAgreementModel extends BaseModel {

	private static final long serialVersionUID = 1L;

	private Integer rateAgreementId;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 1, max = 1,message = "Supplier Type should be 1 characters", groups = { Create.class, Update.class })
    private Optional<String> supplierType;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 3, max = 3,message = "Supplier Code should be 3 characters", groups = { Create.class, Update.class })
    private Optional<String> supplierCode;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 3, max = 3,message = "Location Code should be 3 characters", groups = { Create.class, Update.class })
    private Optional<String> locationCode;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 3, max = 3,message = "Charge category should be 3 characters", groups = { Create.class, Update.class })
    private Optional<String> chargeCategory;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 6, max = 6,message = "Charge Code should be 6 characters", groups = { Create.class, Update.class })
    private Optional<String> chargeCode;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 1, max = 1,message = "Rate Type should be 1 characters", groups = { Create.class, Update.class })
    private Optional<String> rateType;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 1, max = 1,message = "Flight Type should be 1 characters", groups = { Create.class, Update.class })
    private Optional<String> flightType;

    @FieldSize(min = 1, max = 1,message = "Schedule/Charter should be 1 characters", groups = { Create.class, Update.class })
    private Optional<String> scheduleOrCharter;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 3, max = 3,message = "Airport should be 3 characters", groups = { Create.class, Update.class })
    private Optional<String> airport;

    @OptionalFieldSize(min = 1, max = 5,message = "Aircraft Type should be between 1 and 5 characters", groups = { Create.class, Update.class })
    private Optional<String> aircraftType;

    @OptionalFieldSize(min = 1, max = 50,message = "Engine Number should be between 1 and 50 characters", groups = { Create.class, Update.class })
    private Optional<String> engineNumber;

    @OptionalFieldSize(min = 3, max = 3,message = "Carrier should be 3 characters", groups = { Create.class, Update.class })
    private Optional<String> carrier;

    @OptionalFieldSize(min = 4, max = 4,message = "Flight No. should be 4 characters", groups = { Create.class, Update.class })
    private Optional<String> flightNo;

    @OptionalFieldSize(min = 7, max = 7,message = "Sector should be 7 characters", groups = { Create.class, Update.class })
    private Optional<String> sector;

    @FieldSize(min = 1, max = 1,message = "Arrival/Departure should be 1 characters", groups = { Create.class, Update.class })
    private Optional<String> arrivalOrDeparture;

    @OptionalFieldSize(min = 3, max = 3,message = "Base Airport should be 3 characters", groups = { Create.class, Update.class })
    private Optional<String> baseAirport;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 3, max = 3,message = "Currency Code (Local) should be 3 characters", groups = { Create.class, Update.class })
    private Optional<String> currencyCodeLocal;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 3, max = 3,message = "Currency Code (Invoice) should be 3 characters", groups = { Create.class, Update.class })
    private Optional<String> currencyCodeInvoice;

    private BigDecimal exchangeRate;

    private BigDecimal quantity;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 3, max = 3,message = "Unit of Measurement should be 3 characters", groups = { Create.class, Update.class })
    private Optional<String> unitOfMeasurement;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 1, max = 500,message = "Rates should be between 1 and 500 characters", groups = { Create.class, Update.class })
    private Optional<String> rates;

    private BigDecimal variancepercentage;

    @OptionalFieldSize(min = 1, max = 1,message = "Include Tax Indicator should be 1 characters", groups = { Create.class, Update.class })
    private Optional<String> rateIncludeTaxIndicators;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 1, max = 1,message = "Date and Time Validity should be 1 characters", groups = { Create.class, Update.class })
    private Optional<String> dateAndTimeValidity;

    @OptionalFieldSize(min = 1, max = 1000,message = "Applicable Airport should be between 1 and 1000 characters", groups = { Create.class, Update.class })
    private Optional<String> applicableAirports;

    @RequiredNotEmpty(groups = Create.class)
    @OptionalNotEmpty(groups = Update.class)
    @FieldSize(min = 2, max = 2,message = "Client Id should be 2 characters", groups = { Create.class, Update.class })
    private Optional<String> clientId;

    @OptionalFieldSize(min = 1, max = 1000,message = "Contact reference should be between 1 and 1000 characters", groups = { Create.class, Update.class })
    private Optional<String> contractRef;
}
