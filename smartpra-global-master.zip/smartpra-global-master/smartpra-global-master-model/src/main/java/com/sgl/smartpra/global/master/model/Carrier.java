package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class Carrier extends BaseModel {

	private static final long serialVersionUID = 1L;

	@RequiredNotEmpty(message = "Please provide Carrier Code", groups = Create.class)
	@FieldSize(min = 3, max = 3, message = "carrierCode should be 3 characters", groups = { Update.class,
			Create.class })
	private Optional<String> carrierCode;

	@RequiredNotEmpty(message = "Please provide carrier Designator code", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 2, max = 2, message = "carrier Designator code should be 2 characters", groups = { Update.class,
			Create.class })
	private Optional<String> carrierDesignatorCode;

	@OptionalFieldSize(min = 0, max = 7, message = "location Id should be minimum of 1 and maximum of 7 characters", groups = {
			Update.class, Create.class })
	private Optional<String> locationId;

	@OptionalFieldSize(min = 0, max = 50, message = "Carrier Name1 should be minimum of 1 and maximum of 50 characters", groups = {
			Update.class, Create.class })
	private Optional<String> carrierName1;

	@OptionalFieldSize(min = 0, max = 50, message = "Carrier Name2 should be minimum of 1 and maximum of 50 characters", groups = {
			Update.class, Create.class })
	private Optional<String> carrierName2;

	@OptionalFieldSize(min = 0, max = 70, message = "Carrier Address 1 should be minimum of 1 and maximum of 70 characters", groups = {
			Update.class, Create.class })
	private Optional<String> carrierAddress1;

	@OptionalFieldSize(min = 0, max = 70, message = "Carrier Address 2 should be minimum of 1 and maximum of 70 characters", groups = {
			Update.class, Create.class })
	private Optional<String> carrierAddress2;

	@OptionalFieldSize(min = 0, max = 70, message = "Carrier Address 3 should be minimum of 1 and maximum of 70 characters", groups = {
			Update.class, Create.class })
	private Optional<String> carrierAddress3;

	@RequiredNotEmpty(message = "Please provide cityCode", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 3, message = "City Code should be minimum of 1 and maximum of 3 characters", groups = {
			Update.class, Create.class })
	private Optional<String> cityCode;

	@OptionalFieldSize(min = 0, max = 3, message = "subDivisionCode should be minimum of 1 and maximum of 3 characters", groups = {
			Update.class, Create.class })
	private Optional<String> subDivisionCode;

	@OptionalFieldSize(min = 0, max = 50, message = "subDivisionName should be minimum of 1 and maximum of 50 characters", groups = {
			Update.class, Create.class })
	private Optional<String> subDivisionName;

	@RequiredNotEmpty(message = "Please provide Country Code", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 2, message = "Country Code should be minimum of 1 and maximum of 2 characters", groups = {
			Update.class, Create.class })
	private Optional<String> countryCode;

	@OptionalFieldSize(min = 0, max = 50, message = "postalCode should be minimum of 1 and maximum of 50 characters", groups = {
			Update.class, Create.class })
	private Optional<String> postalCode;

	@OptionalFieldSize(min = 0, max = 30, message = "Interline Address 1 should be minimum of 1 and maximum of 30 characters", groups = {
			Update.class, Create.class })
	private Optional<String> interlineAddress1;

	@OptionalFieldSize(min = 0, max = 30, message = "Interline Address 2 should be minimum of 1 and maximum of 30 characters", groups = {
			Update.class, Create.class })
	private Optional<String> interlineAddress2;

	@OptionalFieldSize(min = 0, max = 30, message = "Interline Address 3 should be minimum of 1 and maximum of 30 characters", groups = {
			Update.class, Create.class })
	private Optional<String> interlineAddress3;

	@OptionalFieldSize(min = 0, max = 25, message = "taxRegistrationId should be minimum of 1 and maximum of 25 characters", groups = {
			Create.class, Update.class })
	private Optional<String> taxRegistrationId;

	@OptionalFieldSize(min = 0, max = 25, message = "addlTaxRegistrationId should be minimum of 1 and maximum of 25 characters", groups = {
			Create.class, Update.class })
	private Optional<String> addlTaxRegistrationId;

	@OptionalFieldSize(min = 0, max = 25, message = "companyRegistrationId should be minimum of 1 and maximum of 25 characters", groups = {
			Create.class, Update.class })
	private Optional<String> companyRegistrationId;

	@OptionalFieldSize(min = 0, max = 50, message = "contactName should be minimum of 1 and maximum of 50 characters", groups = {
			Create.class, Update.class })
	private Optional<String> contactName;

	@OptionalFieldSize(min = 0, max = 255, message = "telephoneNumber should be minimum of 1 and maximum of 255 characters", groups = {
			Create.class, Update.class })
	private Optional<String> telephoneNumber;

	@OptionalFieldSize(min = 0, max = 25, message = "faxNumber should be minimum of 1 and maximum of 25 characters", groups = {
			Create.class, Update.class })
	private Optional<String> faxNumber;

	@OptionalFieldSize(min = 0, max = 255, message = "telex should be minimum of 1 and maximum of 255 characters", groups = {
			Create.class, Update.class })
	private Optional<String> telex;

	@OptionalFieldSize(min = 0, max = 255, message = "aftn should be minimum of 1 and maximum of 255 characters", groups = {
			Create.class, Update.class })
	private Optional<String> aftn;

	@OptionalFieldSize(min = 0, max = 255, message = "sita should be minimum of 1 and maximum of 255 characters", groups = {
			Create.class, Update.class })
	private Optional<String> sita;

	@OptionalFieldSize(min = 0, max = 255, message = "email should be minimum of 1 and maximum of 255 characters", groups = {
			Create.class, Update.class })
	private Optional<String> email;

	@OptionalFieldSize(min = 0, max = 255, message = "website should be minimum of 1 and maximum of 255 characters", groups = {
			Create.class, Update.class })
	private Optional<String> website;

	@Null(message = "isActive is not a valid input", groups = { Create.class, Update.class })
	private Boolean isActive;
}
