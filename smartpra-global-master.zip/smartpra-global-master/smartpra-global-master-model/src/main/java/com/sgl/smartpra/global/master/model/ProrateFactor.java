package com.sgl.smartpra.global.master.model;

import java.util.Optional;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ProrateFactor extends BaseModel {

	private static final long serialVersionUID = 1L;

	@Null(message = " prorateFactorId Id is not a valid input", groups = { Create.class, Update.class })
	private Integer prorateFactorId;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveFromDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@DateFormat(pattern = "yyyy-MM-dd", groups = { Create.class,
			Update.class }, message = "Required Date Pattern is yyyy-MM-dd")
	private Optional<String> effectiveToDate;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, groups = { Create.class, Update.class })
	private Optional<String> fromCityCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@FieldSize(min = 3, max = 3, groups = { Create.class, Update.class })
	private Optional<String> toCityCode;

	@RequiredNotEmpty(groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<String> prorateFactor;

	@FieldSize(min = 0, max = 1, groups = { Create.class, Update.class })
	private Optional<String> changeIndicator;

	private Optional<String> addendumFileId;

	private Optional<String> inboundFileId;

	@Null(message = "activate is not a valid input", groups = { Create.class, Update.class })
	private Boolean activate;

}
