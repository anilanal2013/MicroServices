package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.joda.time.DateTime;
import org.joda.time.Months;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ProrateFactorDao;
import com.sgl.smartpra.global.master.app.mapper.ProrateFactorMapper;
import com.sgl.smartpra.global.master.app.repository.entity.ProrateFactorEntity;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.ProrateFactorService;
import com.sgl.smartpra.global.master.model.ProrateFactor;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProrateFactorServiceImpl implements ProrateFactorService {

	@Autowired
	ProrateFactorMapper prorateFactorMapper;

	@Autowired
	ProrateFactorDao prorateFactorDao;

	@Autowired
	private AirportService airportService;

	private static final String DATEVALIDATION = "Record already exists";
	private static final String PRORATEFACTORINACTIVE = "Prorate Factor is already in deactivated state";
	private static final String PRORATEFACTORACTIVE = "Prorate Factor is already in activated state";
	private static final String LASTUPDATEDBYVALIDLENGTH = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	private static final String MANDATORYLASTUPDATEDBY = "Please provide Last Updated By";
	private static final String VALIDFROMDATE = "Effective From Date must be 1-Dec, 1-Mar, 1-Jun or 1-Sep of the Year";
	private static final String VALIDTODATE = "Effective To Date must be 28/29-Feb, 31-May, 31-Aug or 30-Nov of the Year";
	private static final String QUATERLYCHECK = "Effective period not falling within the quaters";
	private static final String DEACTIVATESTATE = "Record already exist in deactivated state";

	@Override
	public ProrateFactor createProrateFactor(ProrateFactor prorateFactor) {

		String fromCityCode = OptionalUtil.getValue(prorateFactor.getFromCityCode());
		String toCityCode = OptionalUtil.getValue(prorateFactor.getToCityCode());

		LocalDate effectiveFromDate = OptionalUtil.getLocalDateValue(prorateFactor.getEffectiveFromDate());
		LocalDate effectiveToDate = OptionalUtil.getLocalDateValue(prorateFactor.getEffectiveToDate());

		sameDateInActiveRecord(fromCityCode, toCityCode, effectiveFromDate, effectiveToDate);
		commonValidation(prorateFactor);

		if (prorateFactorDao.checkOverlapExits(effectiveFromDate, effectiveToDate, fromCityCode, toCityCode) > 0) {
			throw new BusinessException(DATEVALIDATION);
		}

		prorateFactor.setActivate(Boolean.TRUE);
		return prorateFactorMapper.mapToModel(prorateFactorDao.create(prorateFactorMapper.mapToEntity(prorateFactor)));
	}

	@Override
	public List<ProrateFactor> getListOfProrateFactor(Optional<String> fromCityCode, Optional<String> toCityCode,
			Optional<Boolean> activate) {

		return prorateFactorMapper.mapToModel(prorateFactorDao.search(fromCityCode, toCityCode, activate));
	}

	@Override
	public List<ProrateFactor> getProrateFactorByTicketDate(Optional<String> fromCityCode, Optional<String> toCityCode,
			Optional<String> effectiveDate) {

		List<ProrateFactorEntity> prorateFactorList = null;

		if (OptionalUtil.getValue(fromCityCode) != null && OptionalUtil.getValue(toCityCode) != null
				&& OptionalUtil.getLocalDateValue(effectiveDate) != null) {
			prorateFactorList = prorateFactorDao.getAllProrateFactorEntity(fromCityCode, toCityCode, effectiveDate);
			if (prorateFactorList != null) {
				return prorateFactorMapper.mapToModel(prorateFactorList);
			} else {
				throw new BusinessException("Result not found");
			}
		}
		return prorateFactorMapper.mapToModel(prorateFactorList);
	}

	@Override
	public ProrateFactor updateProrateFactor(Integer prorateFactorId, ProrateFactor prorateFactor) {

		ProrateFactorEntity prorateFactorEntity = prorateFactorDao.findById(prorateFactorId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(prorateFactorId)));

		// update only if the record is active
		if (!prorateFactorEntity.getActivate()) {
			throw new BusinessException("Prorate Factor is not active");
		}
		validateBusinessConstriants(prorateFactor, prorateFactorEntity);
		commonValidationForUpdate(prorateFactor, prorateFactorEntity);

		prorateFactor.setActivate(Boolean.TRUE);
		return prorateFactorMapper.mapToModel(
				prorateFactorDao.update(prorateFactorMapper.mapToEntity(prorateFactor, prorateFactorEntity)));
	}

	@Override
	public void deactivateProrateFactor(Integer prorateFactorId, String lastUpdatedBy) {
		ProrateFactorEntity prorateFactorEntity = prorateFactorDao.findById(prorateFactorId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(prorateFactorId)));

		if (!prorateFactorEntity.getActivate())
			throw new BusinessException(PRORATEFACTORINACTIVE);

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		prorateFactorEntity.setLastUpdatedBy(lastUpdatedBy);
		prorateFactorEntity.setLastUpdatedDate(LocalDateTime.now());
		prorateFactorEntity.setActivate(Boolean.FALSE);
		prorateFactorDao.update(prorateFactorEntity);
	}

	@Override
	public void activateProrateFactor(Integer prorateFactorId, String lastUpdatedBy) {
		ProrateFactorEntity prorateFactorEntity = prorateFactorDao.findById(prorateFactorId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(prorateFactorId)));

		if (prorateFactorEntity.getActivate())
			throw new BusinessException(PRORATEFACTORACTIVE);

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		prorateFactorEntity.setActivate(Boolean.TRUE);
		prorateFactorEntity.setLastUpdatedBy(lastUpdatedBy);
		prorateFactorEntity.setLastUpdatedDate(LocalDateTime.now());
		prorateFactorDao.update(prorateFactorEntity);

	}

	private void validateBusinessConstriants(ProrateFactor prorateFactor, ProrateFactorEntity prorateFactorEntity) {

		String fromCityCode = getFromCityCode(prorateFactor, prorateFactorEntity);
		String toCityCode = getToCityCode(prorateFactor, prorateFactorEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(prorateFactor, prorateFactorEntity);
		LocalDate effectiveToDate = getEffectiveToDate(prorateFactor, prorateFactorEntity);

		sameDateInActiveRecord(fromCityCode, toCityCode, effectiveFromDate, effectiveToDate);
		validateOverLapForUpdate(effectiveFromDate, effectiveToDate, fromCityCode, toCityCode,
				prorateFactorEntity.getProrateFactorId());

	}

	private void validateOverLapForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, String fromCityCode,
			String toCityCode, Integer prorateFactorId) {

		if (prorateFactorDao.verifyIfOverlapExits(effectiveFromDate, effectiveToDate, fromCityCode, toCityCode,
				prorateFactorId) != 0) {
			throw new BusinessException(DATEVALIDATION);
		}
	}

	private LocalDate getEffectiveFromDate(ProrateFactor prorateFactor, ProrateFactorEntity prorateFactorEntity) {

		return OptionalUtil.isPresent(prorateFactor.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(prorateFactor.getEffectiveFromDate())
				: prorateFactorEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(ProrateFactor prorateFactor, ProrateFactorEntity prorateFactorEntity) {
		return OptionalUtil.isPresent(prorateFactor.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(prorateFactor.getEffectiveToDate())
				: prorateFactorEntity.getEffectiveToDate();

	}

	private String getToCityCode(ProrateFactor prorateFactor, ProrateFactorEntity prorateFactorEntity) {
		return OptionalUtil.isPresent(prorateFactor.getToCityCode())
				? OptionalUtil.getValue(prorateFactor.getToCityCode())
				: prorateFactorEntity.getToCityCode();
	}

	private String getFromCityCode(ProrateFactor prorateFactor, ProrateFactorEntity prorateFactorEntity) {
		return OptionalUtil.isPresent(prorateFactor.getFromCityCode())
				? OptionalUtil.getValue(prorateFactor.getFromCityCode())
				: prorateFactorEntity.getFromCityCode();
	}

	public void commonValidation(ProrateFactor prorateFactor) {

		LocalDate effectiveToDate = OptionalUtil.getLocalDateValue(prorateFactor.getEffectiveToDate());
		LocalDate effectiveFromDate = OptionalUtil.getLocalDateValue(prorateFactor.getEffectiveFromDate());

		validateEffectiveToDate(effectiveFromDate, effectiveToDate);

		if (prorateFactor.getFromCityCode().equals(prorateFactor.getToCityCode())) {
			throw new BusinessException("From City Code and To City Code should not be same");
		}

		if (!airportService.isValidAirportCodeOrCityCode(OptionalUtil.getValue(prorateFactor.getFromCityCode()))) {
			throw new BusinessException(
					"Invalid From City Code " + OptionalUtil.getValue(prorateFactor.getFromCityCode()));
		}

		if (!airportService.isValidAirportCodeOrCityCode(OptionalUtil.getValue(prorateFactor.getToCityCode()))) {
			throw new BusinessException("Invalid To City Code " + OptionalUtil.getValue(prorateFactor.getToCityCode()));
		}

		boolean validFromFlag = false;
		boolean validToFlag = false;

		String[] fromDateValidate = { "12-01", "03-01", "06-01", "09-01" };
		String[] toDateValidate = { "02-28", "02-29", "05-31", "08-31", "11-30" };

		DateTimeFormatter sdf1 = DateTimeFormatter.ofPattern("MM-dd");

		try {

			for (String date : fromDateValidate) {
				if (date.equals(sdf1.format(effectiveFromDate))) {
					validFromFlag = true;
				}
			}

			for (String date : toDateValidate) {
				if (date.equals(sdf1.format(effectiveToDate))) {
					validToFlag = true;
				}
			}

		} catch (Exception e) {
			log.error("CONTEXT ", e);
		}

		if (!validFromFlag) {
			throw new BusinessException(VALIDFROMDATE);
		}

		if (!validToFlag) {
			throw new BusinessException(VALIDTODATE);
		}

		Date frmDate = Date.from(effectiveFromDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Date tDate = Date.from(effectiveToDate.atStartOfDay(ZoneId.systemDefault()).toInstant());

		DateTime checkFromDate = new DateTime(frmDate);
		DateTime checkToDate = new DateTime(tDate);

		Months monthsCheck = Months.monthsBetween(checkFromDate, checkToDate);

		if (monthsCheck.getMonths() > 2) {
			throw new BusinessException(QUATERLYCHECK);
		}

	}

	public void commonValidationForUpdate(ProrateFactor prorateFactor, ProrateFactorEntity prorateFactorEntity) {

		LocalDate effectiveFromDate = getEffectiveFromDate(prorateFactor, prorateFactorEntity);
		LocalDate effectiveToDate = getEffectiveToDate(prorateFactor, prorateFactorEntity);

		String fromCityCode = getFromCityCode(prorateFactor, prorateFactorEntity);
		String toCityCode = getToCityCode(prorateFactor, prorateFactorEntity);

		validateEffectiveToDate(effectiveFromDate, effectiveToDate);

		if (fromCityCode.equals(toCityCode)) {
			throw new BusinessException("From City Code and To City Code should not be same");
		}

		if (!airportService.isValidAirportCodeOrCityCode(fromCityCode)) {
			throw new BusinessException("Invalid From City Code " + fromCityCode);
		}

		if (!airportService.isValidAirportCodeOrCityCode(toCityCode)) {
			throw new BusinessException("Invalid To City Code " + toCityCode);
		}

		boolean validFromFlag = false;
		boolean validToFlag = false;

		String[] fromDateValidate = { "12-01", "03-01", "06-01", "09-01" };
		String[] toDateValidate = { "02-28", "02-29", "05-31", "08-31", "11-30" };

		DateTimeFormatter sdf1 = DateTimeFormatter.ofPattern("MM-dd");

		try {

			for (String date : fromDateValidate) {
				if (date.equals(sdf1.format(effectiveFromDate))) {
					validFromFlag = true;
				}
			}

			for (String date : toDateValidate) {
				if (date.equals(sdf1.format(effectiveToDate))) {
					validToFlag = true;
				}
			}

		} catch (Exception e) {

			log.error("CONTEXT ", e);
		}

		if (!validFromFlag) {
			throw new BusinessException(VALIDFROMDATE);
		}

		if (!validToFlag) {
			throw new BusinessException(VALIDTODATE);
		}

		Date frmDate = Date.from(effectiveFromDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Date tDate = Date.from(effectiveToDate.atStartOfDay(ZoneId.systemDefault()).toInstant());

		DateTime checkFromDate = new DateTime(frmDate);
		DateTime checkToDate = new DateTime(tDate);

		Months monthsCheck = Months.monthsBetween(checkFromDate, checkToDate);

		if (monthsCheck.getMonths() > 2) {
			throw new BusinessException(QUATERLYCHECK);
		}

	}

	public void sameDateInActiveRecord(String fromCityCode, String toCityCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {

		long sameRecordCount = prorateFactorDao.checkSameInActiveRecord(fromCityCode, toCityCode, effectiveFromDate,
				effectiveToDate);

		if (sameRecordCount == 1) {
			throw new BusinessException(DEACTIVATESTATE);
		}
	}

	@Override
	public ProrateFactor getProrateFactorByTicketDateFTE(Optional<String> fromCityCode, Optional<String> toCityCode,
			Optional<String> effectiveDate) {

		Optional<ProrateFactorEntity> prorateFactorList = prorateFactorDao.getAllProrateFactorEntityFTE(fromCityCode,
				toCityCode, effectiveDate);
		if (prorateFactorList.isPresent()) {
			return prorateFactorMapper.mapToModel(prorateFactorList.get());
		} else {
			return new ProrateFactor();
		}
	}

	protected void validateEffectiveToDate(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}
}
