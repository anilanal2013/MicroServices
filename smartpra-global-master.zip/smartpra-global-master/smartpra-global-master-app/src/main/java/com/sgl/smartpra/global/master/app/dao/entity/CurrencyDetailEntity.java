package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
@Table(name = "global_mas_currency_detail")
public class CurrencyDetailEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "currency_dtl_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int currencyDetailId;

	@Column(name = "currency_code", nullable = false, length = 3)
	private String currencyCode;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;

	@Column(name = "local_currency_fare", length = 10)
	private Double localCurrencyFare;

	@Column(name = "other_charges", nullable = false, length = 10)
	private Double otherCharges;

	@Column(name = "decimal_unit", nullable = false, length = 7)
	private Double decimalUnit;

	@Column(name = "method_of_rounding", length = 2)
	private String methodOfRounding;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}
	
	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
