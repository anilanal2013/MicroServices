package com.sgl.smartpra.global.master.app.repository.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.global.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * The persistent class for the global_mas_dictionary database table.
 * 
 */
@Entity
@Table(name="global_mas_dictionary")
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicUpdate
@DynamicInsert
public class DictionaryEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="dictionary_id")
	private int dictionaryId;

	@Column(name="dictionary_define")
	private String dictionaryDefine;

	@Column(name="element_name")
	private String elementName;

	@OneToMany(mappedBy="dictionaryEntity", cascade=CascadeType.ALL)
	private List<DictionaryValueEntity> dictionaryValue;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
	
	
}