package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.CountryEntity;

public class CountryEntitySpecification {

	private CountryEntitySpecification() {

	}

	public static Specification<CountryEntity> equalCountryCode(String countryCode) {
		return (countryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(countryEntity.get("countryCode"), countryCode);
	}

	public static Specification<CountryEntity> equalCountryName(String countryName) {
		return (countryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(countryEntity.get("countryName"), countryName);
	}

	public static Specification<CountryEntity> equalsActivate(Boolean activate) {
		return (countryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(countryEntity.get("activate"),
				activate);
	}

	public static Specification<CountryEntity> notEqualsCountryCode(String countryCode) {
		return (countryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(countryEntity.get("countryCode"), countryCode);
	}

	public static Specification<CountryEntity> equalsCountryNumber(Integer countryNumber) {
		return (countryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(countryEntity.get("countryNumber"), countryNumber);
	}

	public static Specification<CountryEntity> equalsISOAlpha3CountryCode(String isoAlpha3CountryCode) {
		return (countryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(countryEntity.get("isoAlpha3CountryCode"), isoAlpha3CountryCode);
	}

	public static void orderByAsc(Root<CountryEntity> countryEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(countryEntity.get(orderByString)));
	}

	public static Specification<CountryEntity> getListOfCountries(Optional<String> countryCode,
			Optional<String> countryName) {
		return (countryEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(countryCode)) {
				predicates.add(
						criteriaBuilder.equal(countryEntity.get("countryCode"), OptionalUtil.getValue(countryCode)));
			}
			if (OptionalUtil.isPresent(countryName)) {
				predicates.add(
						criteriaBuilder.equal(countryEntity.get("countryName"), OptionalUtil.getValue(countryName)));
			}
			predicates.add(criteriaBuilder.equal(countryEntity.get("activate"), Boolean.TRUE));
			orderByAsc(countryEntity, criteriaQuery, criteriaBuilder, "countryCode"); 
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<CountryEntity> getListOfCountriesByIsActive(Optional<String> countryCode,
			Optional<String> countryName, Optional<Boolean> activate) {
		return (countryEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(countryCode)) {
				predicates.add(criteriaBuilder.like(countryEntity.get("countryCode"),
						OptionalUtil.getValue(countryCode) + "%"));
			}

			if (OptionalUtil.isPresent(countryName)) {
				predicates.add(criteriaBuilder.like(countryEntity.get("countryName"),
						OptionalUtil.getValue(countryName) + "%"));
			}

			if (OptionalUtil.getValue(activate) == null || OptionalUtil.getValue(activate)) {
				predicates.add(criteriaBuilder.isTrue(countryEntity.get("activate")));
			} else {
				predicates.add(criteriaBuilder.isFalse(countryEntity.get("activate")));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
