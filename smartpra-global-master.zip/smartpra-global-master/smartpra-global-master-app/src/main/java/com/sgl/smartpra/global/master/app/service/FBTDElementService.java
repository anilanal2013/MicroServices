package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.FBTDElement;

public interface FBTDElementService {

	public List<FBTDElement> getAllFBTDElementDetails(Optional<Integer> elementType, Optional<String> elementCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate);

	public FBTDElement getFBTDElementByFBTDId(Optional<Integer> elementType, Optional<String> elementCode, Optional<String> effectiveDate);
	
	public FBTDElement createFBTDElement(FBTDElement fdtdElement);

	public FBTDElement updateFBTDElement(Integer fbtdId, FBTDElement fbtdElement);

	public void deactivateFBTDElement(Integer fbtdId, String lastUpdatedBy);

	public void activateFBTDElement(Integer fbtdId, String lastUpdatedBy);

	public boolean getFBTDElementByElementCode(String elementCode);
	
	public boolean getFBTDElementByElementCodeBasedOnPrimeCode(String elementCode,Integer elementType);

	public Boolean validateCabin(String cabin);
	
	public Boolean validateOtherInfo(String otherInfo);

	public boolean validateIATAFareType(String iataFareType);

	public boolean validateSeasonalCode(String seasonalCode);

	public boolean validateDayOfWeek(String dayOfWeek);

	public boolean validateDiscountCode(String discountCode);

	public boolean validateJourneyType(String journeyType);

	public boolean validateZedIdentifier(String zedIdentifier);

	public FBTDElement getFBTDElementByFBTDId(Integer fbtdId); 
	
	public List<FBTDElement> getCabinLevel();

}
