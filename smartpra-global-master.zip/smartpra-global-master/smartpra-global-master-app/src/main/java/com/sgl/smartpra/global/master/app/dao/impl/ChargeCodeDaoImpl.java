package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.global.master.app.dao.ChargeCodeDao;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ChargeCodeEntitySpec;
import com.sgl.smartpra.global.master.app.repository.ChargeCodeRepository;
import com.sgl.smartpra.global.master.app.repository.entity.ChargeCodeEntity;

@Component
public class ChargeCodeDaoImpl<T> extends CommonSearchDao<T> implements ChargeCodeDao {

	@Autowired
	ChargeCodeRepository chargeCodeRepository;

	@Override
	public List<ChargeCodeEntity> findAll(Optional<String> chargeCode, Optional<String> chargeCodeName,
			Optional<String> chargeCategoryCode) {
		return chargeCodeRepository
				.findAll(ChargeCodeEntitySpec.search(chargeCode, chargeCodeName, chargeCategoryCode));
	}

	@Override
	@Cacheable(value = "chargeCode", key = "#chargeCode")
	public Optional<ChargeCodeEntity> findOne(Optional<String> chargeCode) {

		return chargeCodeRepository.findOne(ChargeCodeEntitySpec.findOne(chargeCode));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "chargeCode", key = "#chargeCodeEntity.chargeCode"),
			@CacheEvict(value = "chargeCodeSearch", allEntries = true) })
	public ChargeCodeEntity create(ChargeCodeEntity chargeCodeEntity) {
		return chargeCodeRepository.save(chargeCodeEntity);
	}

	@Override
	public List<ChargeCodeEntity> update(List<ChargeCodeEntity> chargeCodeEntity) {
		return chargeCodeRepository.saveAll(chargeCodeEntity);
	}

	@Override
	public List<String> getChargeCodeFromChargeCodeMaster() {

		return chargeCodeRepository.getChargeCodeFromChargeCodeMaster();
	}

}
