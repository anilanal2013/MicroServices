package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoRoutingStg;

public interface ProvisoRoutingStgService {

	public ProvisoRoutingStg createProvisoRouting(ProvisoRoutingStg provisoRoutingStg);

	public List<ProvisoRoutingStg> getProvisoRoutingByProvisoMainId(Optional<Integer> provisoMainId);

	public ProvisoRoutingStg getProvisoRoutingByProvisoRoutingId(Integer provisoRoutingId);

	public List<ProvisoRoutingStg> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber);

	public ProvisoRoutingStg updateProvisoRouting(Integer provisoRoutingId, ProvisoRoutingStg provisoRoutingStg);
	
	public void deleteProvisoRoutingByProvisoMainId(Integer provisoMainId);

	public void deleteProvisoRoutingByProvisoRoutingId(Integer provisoRoutingId);
}
