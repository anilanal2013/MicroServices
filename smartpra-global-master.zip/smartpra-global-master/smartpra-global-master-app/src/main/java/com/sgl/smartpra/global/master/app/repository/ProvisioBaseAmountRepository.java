package com.sgl.smartpra.global.master.app.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.ProvisioBaseAmountEntity;

@Repository
public interface ProvisioBaseAmountRepository
		extends JpaRepository<ProvisioBaseAmountEntity, Integer>, JpaSpecificationExecutor<ProvisioBaseAmountEntity> {

	@Query(value = "select a from ProvisioBaseAmountEntity a  where "
			+ "((:effectiveDate between a.effectiveFromDate  AND a.effectiveToDate) "
			+ " or (a.effectiveFromDate >=:effectiveDate and a.effectiveToDate <=:effectiveDate )) "
			+ "AND a.fromCityCode =:fromCityCode AND a.toCityCode =:toCityCode AND a.carrierCode =:carrierCode AND a.classCode =:classCode AND a.activate = 'Y'")
	public ProvisioBaseAmountEntity getAllProvisioBaseAmountEntity(@Param("effectiveDate") LocalDate effectiveDate,
			@Param("fromCityCode") String fromCityCode, @Param("toCityCode") String toCityCode,
			@Param("carrierCode") String carrierCode, @Param("classCode") String classCode);

	@Query(value = "select a from ProvisioBaseAmountEntity a  where  a.fromCityCode =:fromCityCode AND (:date between a.effectiveFromDate  AND a.effectiveToDate) AND a.toCityCode =:toCityCode AND a.carrierCode =:carrierCode AND a.classCode =:classCode AND a.activate = 'Y'")
	public ProvisioBaseAmountEntity getProvisoBaseAmount(@Param("fromCityCode") String fromCityCode,
			@Param("toCityCode") String toCityCode, @Param("classCode") String classCode,
			@Param("carrierCode") String carrierCode, @Param("date") LocalDate date);
}
