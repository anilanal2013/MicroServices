package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.CurrencyDetailEntity;

public interface CurrencyDetailDao {

	public Optional<CurrencyDetailEntity> findById(Integer currencyDetailId);

	public CurrencyDetailEntity create(CurrencyDetailEntity currencyDetailEntity);

	public CurrencyDetailEntity update(CurrencyDetailEntity currencyDetailEntity);
	
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String currencyCode);
	
	void deleteById(Integer id);
	
	public List<CurrencyDetailEntity> getAllCurrencyDetails(Optional<String> currencyCode,Optional<String> effectiveDate);

	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, String currencyCode, Integer currencyDtlId);

	public CurrencyDetailEntity getCurrencyByCurrencyCodeAndEffectiveDate(String currencyCode,
			Optional<String> effectiveDate);
}
