package com.sgl.smartpra.global.master.app.service;

import com.sgl.smartpra.global.master.model.RateAndAgreementModel;

import java.util.List;
import java.util.Optional;

public interface RateAndAgreementService {

    public RateAndAgreementModel create(RateAndAgreementModel rateAndAgreementModel);

    RateAndAgreementModel saveExist(RateAndAgreementModel rateAndAgreementModel);

    List<RateAndAgreementModel> fetchAll(Optional<String> supplierCode, Optional<String> baseLocation, Optional<String> chargeCategory, Optional<String> chargeCode, Optional<String> effectivePeriodFrom, Optional<String> effectivePeriodTo, Optional<String> airport);

    Boolean delete(Integer id);
}
