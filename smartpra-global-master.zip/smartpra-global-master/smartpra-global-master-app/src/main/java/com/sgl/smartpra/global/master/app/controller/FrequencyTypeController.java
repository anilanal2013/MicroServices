package com.sgl.smartpra.global.master.app.controller;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.controller.util.HeaderUtil;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.service.FrequencyTypeService;
import com.sgl.smartpra.global.master.model.FrequencyTypeDTO;



@RestController
@RequestMapping
public class FrequencyTypeController {

    private final Logger log = LoggerFactory.getLogger(FrequencyTypeController.class);

    private static final String ENTITY_NAME = "frequencyType";
 
    @Autowired
    FrequencyTypeService frequencyTypeService;

    public FrequencyTypeController(FrequencyTypeService frequencyTypeService) {
        this.frequencyTypeService = frequencyTypeService;
    }

    /**
     * POST  /frequency-types : Create a new frequencyType.
     *
     * @param frequencyTypeDTO the frequencyTypeDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new frequencyTypeDTO, or with status 400 (Bad Request) if the frequencyType has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/frequency-types")
    public ResponseEntity<FrequencyTypeDTO> createFrequencyType(@Valid @RequestBody FrequencyTypeDTO frequencyTypeDTO) throws URISyntaxException {
        log.debug("REST request to save FrequencyType : {}", frequencyTypeDTO);
        if (frequencyTypeDTO.getFrequencyTypeId() != null) {
            throw new ServiceException("A new frequencyType cannot already have an ID"+ ENTITY_NAME+"idexists");
        }
        FrequencyTypeDTO result=null;
		try {
			result = frequencyTypeService.save(frequencyTypeDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
        return ResponseEntity.created(new URI("/api/frequency-types/" + result.getFrequencyTypeId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getFrequencyTypeId().toString()))
            .body(result);
    }

    /**
     * PUT  /frequency-types : Updates an existing frequencyType.
     *
     * @param frequencyTypeDTO the frequencyTypeDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated frequencyTypeDTO,
     * or with status 400 (Bad Request) if the frequencyTypeDTO is not valid,
     * or with status 500 (Internal Server Error) if the frequencyTypeDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/frequency-types")
    public ResponseEntity<FrequencyTypeDTO> updateFrequencyType(@Valid @RequestBody FrequencyTypeDTO frequencyTypeDTO) throws URISyntaxException {
        log.debug("REST request to update FrequencyType : {}", frequencyTypeDTO);
        if (frequencyTypeDTO.getFrequencyTypeId() == null) {
            throw new ServiceException("Invalid id"+ENTITY_NAME+"idnull");
        }
        FrequencyTypeDTO result = frequencyTypeService.save(frequencyTypeDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, frequencyTypeDTO.getFrequencyTypeId().toString()))
            .body(result);
    }

    /**
     * GET  /frequency-types : get all the frequencyTypes.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of frequencyTypes in body
     */
    @GetMapping("/frequency-types")
    public List<FrequencyTypeDTO> getAllFrequencyTypes() {
        log.debug("REST request to get all FrequencyTypes");
        return frequencyTypeService.findAll();
    }

    /**
     * GET  /frequency-types/:id : get the "id" frequencyType.
     *
     * @param id the id of the frequencyTypeDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the frequencyTypeDTO, or with status 404 (Not Found)
     */
    @GetMapping("/frequency-types/{id}")
    public FrequencyTypeDTO getFrequencyType(@PathVariable Long id) {
        log.debug("REST request to get FrequencyType : {}", id);
        return  frequencyTypeService.findOne(id);
       
    }

    /**
     * DELETE  /frequency-types/:id : delete the "id" frequencyType.
     *
     * @param id the id of the frequencyTypeDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
  /*  @DeleteMapping("/frequency-types/{id}")
    public ResponseEntity<Void> deleteFrequencyType(@PathVariable Long id) {
        log.debug("REST request to delete FrequencyType : {}", id);
        frequencyTypeService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }*/
}
