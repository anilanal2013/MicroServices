package com.sgl.smartpra.global.master.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.configuration.CacheManage;



@RestController
public class CacheEvitController {
	
	@Autowired
	private CacheManage cacheManage;
	
	@DeleteMapping("/clear-cache")
	public void clearCache() {
		cacheManage.evictAllcachesAtIntervals();
	}

}
