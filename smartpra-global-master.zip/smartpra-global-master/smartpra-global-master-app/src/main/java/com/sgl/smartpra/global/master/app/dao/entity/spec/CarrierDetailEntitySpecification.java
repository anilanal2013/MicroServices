package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.CarrierDetailEntity;

public class CarrierDetailEntitySpecification {

	private CarrierDetailEntitySpecification() {
	}

	public static void orderByEffectiveToDateByAsc(Root<CarrierDetailEntity> carrierDetailEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String effectiveToDate) {
		criteriaQuery.orderBy(criteriaBuilder.asc(carrierDetailEntity.get(effectiveToDate)));
	}

	public static Specification<CarrierDetailEntity> search(Optional<String> carrierCode,
			Optional<String> effectiveDate) {
		return (carrierDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierCode)) {
				predicates.add(criteriaBuilder.like(carrierDetailEntity.get("carrierCode"),
						OptionalUtil.getValue(carrierCode) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
						carrierDetailEntity.get("effectiveFromDate"), carrierDetailEntity.get("effectiveToDate")));
			}
			orderByEffectiveToDateByAsc(carrierDetailEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<CarrierDetailEntity> equalsCarrierCode(String carrierCode) {
		return (carrierDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierDetailEntity.get("carrierCode"), carrierCode);
	}

	public static Specification<CarrierDetailEntity> notEqualsCarrierDetailId(Integer carrierDetailId) {
		return (carrierDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(carrierDetailEntity.get("carrierDetailId"), carrierDetailId);
	}

	public static Specification<CarrierDetailEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (carrierDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), carrierDetailEntity.get("effectiveFromDate"),
				carrierDetailEntity.get("effectiveToDate"));
	}
	
	public static Specification<CarrierDetailEntity> betweenEffectiveFrom(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return (carrierDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				carrierDetailEntity.get("effectiveFromDate"), criteriaBuilder.literal(effectiveFromDate),
				criteriaBuilder.literal(effectiveToDate));

	}

}
