package com.sgl.smartpra.global.master.app.repository.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.global.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_mini_prorate_rule")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class MPREntity extends BaseEntity {

	@Id
	@Column(name = "min_prorate_rule_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer minimumProrateRuleId;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;

	@Column(name = "mpr_percentage", nullable = false)
	private BigDecimal mprPercentage;

	@Column(name = "mpq_value", nullable = false)
	private BigDecimal mpqValue;

	@Column(name = "quotient_decimals", nullable = false)
	private Integer quotientDecimals;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

}
