package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ProvisoCodeshareStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoDetailStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoMainStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoRoutingStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoSectorStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorStgEntity;
import com.sgl.smartpra.global.master.app.service.ProvisoAddlDiscountService;
import com.sgl.smartpra.global.master.app.service.ProvisoAddlDiscountStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoCodeshareService;
import com.sgl.smartpra.global.master.app.service.ProvisoCodeshareStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoDetailService;
import com.sgl.smartpra.global.master.app.service.ProvisoDetailStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoMainService;
import com.sgl.smartpra.global.master.app.service.ProvisoMainStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoRoutingService;
import com.sgl.smartpra.global.master.app.service.ProvisoRoutingStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoSectorService;
import com.sgl.smartpra.global.master.app.service.ProvisoSectorStgService;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscountStg;
import com.sgl.smartpra.global.master.model.ProvisoCodeshareStgModel;
import com.sgl.smartpra.global.master.model.ProvisoDetailStgModel;
import com.sgl.smartpra.global.master.model.ProvisoMainStgModel;
import com.sgl.smartpra.global.master.model.ProvisoRoutingStg;
import com.sgl.smartpra.global.master.model.ProvisoSectorStgModel;

@RestController
@RequestMapping("/proviso/main/stg")
public class ProvisoMainStgController {
	public static final String PROVISO_SECTION_RISTRICTION_FOR_MOVE = "Proviso Section should be Numeric[1 to 99] for this Move";
	@Autowired
	ProvisoMainStgService provisoMainStgService;
	@Autowired
	ProvisoMainService provisoMainService;
	@Autowired
	ProvisoCodeshareStgService provisoCodeshareStgService;
	@Autowired
	ProvisoCodeshareService provisoCodeshareService;
	@Autowired
	ProvisoSectorStgService provisoSectorStgService;
	@Autowired
	ProvisoSectorService provisoSectorService;
	@Autowired
	ProvisoDetailStgService provisoDetailStgService;
	@Autowired
	ProvisoDetailService provisoDetailService;
	@Autowired
	private ProvisoRoutingStgService provisoRoutingStgService;
	@Autowired
	private ProvisoRoutingService provisoRoutingService;
	@Autowired
	private ProvisoAddlDiscountStgService provisoAddlDiscountStgService;
	@Autowired
	private ProvisoAddlDiscountService provisoAddlDiscountService;
	@Autowired
	private ProvisoMainStgDao provisoMainStgDao;
	@Autowired
	private ProvisoCodeshareStgDao provisoCodeshareStgDao;
	@Autowired
	private ProvisoSectorStgDao provisoSectorStgDao;
	@Autowired
	private ProvisoDetailStgDao provisoDetailStgDao;
	@Autowired
	private ProvisoRoutingStgDao provisoRoutingStgDao;
	
	ProvisoCodeshareStgModel savedProvisoCodeshare;
	ProvisoSectorStgModel savedProvisoSector;
	ProvisoDetailStgModel savedProvisoDetail;
	ProvisoRoutingStg savedProvisoRouting;
	ProvisoAdditionalDiscountStg savedProvisoAddlDiscount;

	@PostMapping("/proviso-main")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoMainStgModel createProvisoMain(
			@Validated(Create.class) @RequestBody ProvisoMainStgModel provisoMainStgModel) {
		return provisoMainStgService.createProvisoMain(provisoMainStgModel);
	}

	@GetMapping("/{provisoMainId}")
	public ProvisoMainStgModel getProvisoMainByprovisoMainId(
			@PathVariable(value = "provisoMainId") Integer provisoMainId) {
		return provisoMainStgService.getProvisoMainByprovisoMainId(provisoMainId);
	}

	@PutMapping("/{provisoMainId}")
	@ResponseStatus(value = HttpStatus.OK)
	public ProvisoMainStgModel updateProvisoMain(@PathVariable(value = "provisoMainId") Integer provisoMainId,
			@Validated(Update.class) @RequestBody ProvisoMainStgModel provisoMainStgModel) {
		provisoMainStgModel.setProvisoMainId(provisoMainId);
		return provisoMainStgService.updateProvisoMain(provisoMainStgModel);
	}

	@GetMapping("/search")
	public List<ProvisoMainStgModel> search(
			@RequestParam(name = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@RequestParam(name = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(name = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(name = "provisoSection", required = false) Optional<String> provisoSection,
			@RequestParam(name = "provisoStatus", required = false) Optional<String> provisoStatus) {
		return provisoMainStgService.search(carrierNumCode, effectiveFromDate, effectiveToDate, provisoSection,
				provisoStatus);
	}

	@PutMapping("/inActive/{provisoMainId}")
	@ResponseStatus(value = HttpStatus.OK)
	public void inActivateProvisoMain(@PathVariable(value = "provisoMainId") Integer provisoMainId,
			@Validated(Update.class) @RequestBody ProvisoMainStgModel provisoMainStgModel) {
		provisoMainStgModel.setProvisoMainId(provisoMainId);
		provisoMainStgService.inActiveProvisoMain(provisoMainStgModel);
	}

	@PostMapping("/moveMainToProd/{provisoMainId}")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoMainStgModel moveProvisoMainStaggingToProvisoMainProd(
			@PathVariable(value = "provisoMainId") Integer provisoMainId) {
		ProvisoMainStgModel provisoMainStgModel = provisoMainStgService.getProvisoMainByprovisoMainId(provisoMainId);
		provisoMainStgModel
				.setProvisoSection(Optional.of(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).trim()));

		if (provisoMainStgModel.getProvisoStatus().equals(Optional.of("R"))
				|| !(provisoMainStgModel.getProvisoStatus().equals(Optional.of("M")))
				|| !(provisoMainStgModel.getProvisoStatus().equals(Optional.of("I")))) {
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A")) {
				provisoMainStgModel.setProvisoStatus(Optional.of("M"));
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B")) {
				provisoMainStgModel.setProvisoStatus(Optional.of("M"));
			}
		}
		return provisoMainService.saveProvisoMain(provisoMainStgModel);
	}

	@PostMapping("/moveCodeshareToProd/{provisoMainId}")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoCodeshareStgModel moveProvisoCodeshareStaggingToProvisoCodeshareProd(
			@PathVariable(value = "provisoMainId") Integer provisoMainId) {
		ProvisoMainStgModel provisoMainStgModel = provisoMainStgService.getProvisoMainByprovisoMainId(provisoMainId);
		List<ProvisoCodeshareStgModel> provisoCodeshareStgModelList = provisoCodeshareStgService
				.getProvisoCodeshareByProvisoMainId(Optional.of(provisoMainId));
		provisoMainStgModel
				.setProvisoSection(Optional.of(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).trim()));

		for (ProvisoCodeshareStgModel provisoCodeshareStgModel : provisoCodeshareStgModelList) {

			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A")) {
				savedProvisoCodeshare = provisoCodeshareService.saveProvisoCodeshare(provisoCodeshareStgModel);
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B")) {
				savedProvisoCodeshare = provisoCodeshareService.saveProvisoCodeshare(provisoCodeshareStgModel);
			}
		}

		return savedProvisoCodeshare;
	}

	@PostMapping("/moveSectorToProd/{provisoMainId}")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoSectorStgModel moveProvisoSectorStaggingToProvisoSectorProd(
			@PathVariable(value = "provisoMainId") Integer provisoMainId) {
		ProvisoMainStgModel provisoMainStgModel = provisoMainStgService.getProvisoMainByprovisoMainId(provisoMainId);
		List<ProvisoSectorStgModel> provisoSectorStgModelList = provisoSectorStgService
				.getProvisoSectorByProvisoMainId(Optional.of(provisoMainId));
		provisoMainStgModel
				.setProvisoSection(Optional.of(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).trim()));

		for (ProvisoSectorStgModel provisoSectorStgModel : provisoSectorStgModelList) {
			if (!(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A"))
					&& !(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B"))) {
				savedProvisoSector = provisoSectorService.saveProvisoSector(provisoSectorStgModel);
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A")) {
				throw new BusinessException(PROVISO_SECTION_RISTRICTION_FOR_MOVE);
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B")) {
				throw new BusinessException(PROVISO_SECTION_RISTRICTION_FOR_MOVE);
			}
		}

		return savedProvisoSector;

	}

	@PostMapping("/moveDetailToProd/{provisoMainId}")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoDetailStgModel moveProvisoDetailStaggingToProvisoDetailProd(
			@PathVariable(value = "provisoMainId") Integer provisoMainId) {
		ProvisoMainStgModel provisoMainStgModel = provisoMainStgService.getProvisoMainByprovisoMainId(provisoMainId);
		List<ProvisoDetailStgModel> provisoDetailStgModelList = provisoDetailStgService
				.getProvisoDetailByProvisoMainId(Optional.of(provisoMainId));
		provisoMainStgModel
				.setProvisoSection(Optional.of(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).trim()));
		for (ProvisoDetailStgModel provisoDetailStgModel : provisoDetailStgModelList) {
			if (!(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A"))
					&& !(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B"))) {
				savedProvisoDetail = provisoDetailService.saveProvisoDetail(provisoDetailStgModel);
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A")) {
				throw new BusinessException(PROVISO_SECTION_RISTRICTION_FOR_MOVE);
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B")) {
				throw new BusinessException(PROVISO_SECTION_RISTRICTION_FOR_MOVE);
			}
		}
		return savedProvisoDetail;

	}

	@PostMapping("/moveRoutingToProd/{provisoMainId}")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoRoutingStg moveProvisoRoutingStaggingToProvisoRoutingProd(
			@PathVariable(value = "provisoMainId") Integer provisoMainId) {
		ProvisoMainStgModel provisoMainStgModel = provisoMainStgService.getProvisoMainByprovisoMainId(provisoMainId);
		List<ProvisoRoutingStg> provisoRoutingStgList = provisoRoutingStgService
				.getProvisoRoutingByProvisoMainId(Optional.of(provisoMainId));
		provisoMainStgModel
				.setProvisoSection(Optional.of(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).trim()));

		for (ProvisoRoutingStg provisoRoutingStg : provisoRoutingStgList) {
			if (!(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A"))
					&& !(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B"))) {
				savedProvisoRouting = provisoRoutingService.saveProvisoRouting(provisoRoutingStg);
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A")) {
				throw new BusinessException(PROVISO_SECTION_RISTRICTION_FOR_MOVE);
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B")) {
				throw new BusinessException(PROVISO_SECTION_RISTRICTION_FOR_MOVE);
			}
		}
		return savedProvisoRouting;
	}

	@PostMapping("/moveAddlDiscountToProd/{provisoMainId}")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoAdditionalDiscountStg moveProvisoAddlDiscountStaggingToProvisoAddlDiscountProd(
			@PathVariable(value = "provisoMainId") Integer provisoMainId) {
		ProvisoMainStgModel provisoMainStgModel = provisoMainStgService.getProvisoMainByprovisoMainId(provisoMainId);
		List<ProvisoAdditionalDiscountStg> provisoAdditionalDiscountStgList = provisoAddlDiscountStgService
				.getProvisoAddlDiscountByProvisoMainId(Optional.of(provisoMainId));
		provisoMainStgModel
				.setProvisoSection(Optional.of(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).trim()));

		for (ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg : provisoAdditionalDiscountStgList) {
			if (!(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A"))
					&& !(OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B"))) {
				savedProvisoAddlDiscount = provisoAddlDiscountService
						.saveProvisoAddlDiscount(provisoAdditionalDiscountStg);
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("A")) {
				throw new BusinessException(PROVISO_SECTION_RISTRICTION_FOR_MOVE);
			}
			if (OptionalUtil.getValue(provisoMainStgModel.getProvisoSection()).equals("B")) {
				throw new BusinessException(PROVISO_SECTION_RISTRICTION_FOR_MOVE);
			}
		}
		return savedProvisoAddlDiscount;

	}

	@DeleteMapping("/deleteProvisoMasterStgOneToMany/{provisoMainId}")
	public void deleteProvisoMasterStgOneToMany(@PathVariable(value = "provisoMainId") Integer provisoMainId) {
		ProvisoMainStgEntity provisoMainStgEntityRec = provisoMainStgDao.findById(provisoMainId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoMainId)));

		if ((provisoMainStgEntityRec.getProvisoSection().toString()).contains("A")) {
			List<ProvisoCodeshareStgEntity> provisoCodeshareStgEntityList = provisoCodeshareStgDao
					.findByMainId(Optional.of(provisoMainId));
			if (provisoCodeshareStgEntityList != null) {
				provisoCodeshareStgService.deleteProvisoCodehareByProvisoMainId(provisoMainId);
			}
				provisoMainStgService.deleteProvisoMain(provisoMainId);
		}

		if ((provisoMainStgEntityRec.getProvisoSection().toString()).contains("B")) {
			List<ProvisoCodeshareStgEntity> provisoCodeshareStgEntityList = provisoCodeshareStgDao
					.findByMainId(Optional.of(provisoMainId));
			if (provisoCodeshareStgEntityList != null) {
				provisoCodeshareStgService.deleteProvisoCodehareByProvisoMainId(provisoMainId);
			}
				provisoMainStgService.deleteProvisoMain(provisoMainId);
		}

		if (!((provisoMainStgEntityRec.getProvisoSection().toString()).contains("A"))
				&& !((provisoMainStgEntityRec.getProvisoSection().toString()).contains("B"))) {
			List<ProvisoSectorStgEntity> provisoSectorStgEntityList = provisoSectorStgDao
					.findByMainId(Optional.of(provisoMainId));
			List<ProvisoDetailStgEntity> provisoDetailStgEntityList=provisoDetailStgDao.findByMainId(Optional.of(provisoMainId));
			List<ProvisoRoutingStgEntity> provisoRoutingStgEntityList=provisoRoutingStgDao.findByMainId(Optional.of(provisoMainId));
			
			if (!provisoRoutingStgEntityList.isEmpty()) {
				provisoRoutingStgService.deleteProvisoRoutingByProvisoMainId(provisoMainId);
			}
			if (!provisoDetailStgEntityList.isEmpty()) { 
				provisoDetailStgService.deleteProvisoDetailByProvisoMainId(provisoMainId);
			}
			if (!provisoSectorStgEntityList.isEmpty()) { 
				provisoSectorStgService.deleteProvisoSectorByProvisoMainId(provisoMainId);
			}
			
				provisoMainStgService.deleteProvisoMain(provisoMainId);

		}
		
	}
	
	@GetMapping("/proviso-main/discount-list")
	public List<CommonIdName> getDiscountList() {
		return provisoMainStgService.getDiscountList();
	}

}
