package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoSectorStgModel;

public interface ProvisoSectorStgService {

	public ProvisoSectorStgModel createProvisoSector(ProvisoSectorStgModel provisoSectorStsModel);

	public List<ProvisoSectorStgModel> getProvisoSectorByProvisoMainId(Optional<Integer> provisoMainId);

	public ProvisoSectorStgModel getProvisoSectorByProvisoSectorId(Integer provisoSectorId);

	public List<ProvisoSectorStgModel> searchByProvisoInMain(Optional<Integer> provisoMainId,
			Optional<String> areaFrom);

	public List<ProvisoSectorStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);

	public ProvisoSectorStgModel updateProvisoSector(Integer provisoSectorId,
			ProvisoSectorStgModel provisoSectorStgModel);

	public List<ProvisoSectorStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> sectionRecNumber);

	public void deleteProvisoSectorByProvisoMainId(Integer provisoMainId);

	public void deleteProvisoSectorByProvisoSectorId(Integer provisoSectorId);
}
