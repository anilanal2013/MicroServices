package com.sgl.smartpra.global.master.app.service;

import com.sgl.smartpra.global.master.model.GeographyType;

public interface StandardAreaGeographyTypeService {

	public GeographyType getStandardAreaGeographyTypeByStandardAreaGeographyTypeId(Integer geographicalTypeId);

}
