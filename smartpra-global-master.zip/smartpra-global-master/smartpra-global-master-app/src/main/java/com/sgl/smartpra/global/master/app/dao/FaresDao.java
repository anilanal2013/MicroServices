package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.FaresEntity;

public interface FaresDao {
 
	public Optional<FaresEntity> findById(Integer fareId);

	public FaresEntity create(FaresEntity faresEntity);

	public FaresEntity update(FaresEntity faresEntity);

	public void delete(Integer id);

	public List<FaresEntity> findAll();

	long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String tariffCode,
			String cxrCode, String originCity, String destinationCity, String fareBasis);

	long getOverLapRecordCount(String tariffCode, String cxrCode, String originCity, String destinationCity,
			String fareBasis);

	public List<FaresEntity> search(Optional<String> cxrCode, Optional<String> originCity,
			Optional<String> destinationCity, Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	public List<FaresEntity> getFareForFareSelectionProcessing(Optional<String> cxrCode, Optional<String> originCity,
			Optional<String> destinationCity, Optional<String> effectiveDate);

	public List<FaresEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String tariffCode, String cxrCode, String originCity, String destinationCity,
			String fareBasis, Integer fareId); 

}
