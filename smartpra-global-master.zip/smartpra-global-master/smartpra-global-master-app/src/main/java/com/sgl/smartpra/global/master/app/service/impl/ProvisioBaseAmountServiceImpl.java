package com.sgl.smartpra.global.master.app.service.impl;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.ProvisioBaseAmountDao;
import com.sgl.smartpra.global.master.app.mapper.ProvisioBaseAmountMapper;
import com.sgl.smartpra.global.master.app.repository.entity.ProvisioBaseAmountEntity;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CarrierService;
import com.sgl.smartpra.global.master.app.service.CurrencyService;
import com.sgl.smartpra.global.master.app.service.ProvisioBaseAmountService;
import com.sgl.smartpra.global.master.model.ProvisioBaseAmount;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisioBaseAmountServiceImpl implements ProvisioBaseAmountService {

	@Autowired
	ProvisioBaseAmountMapper provisioBaseAmountMapper;

	@Autowired
	ProvisioBaseAmountDao provisioBaseAmountDao;

	@Autowired
	private AirportService airportService;

	@Autowired
	private CurrencyService currencyService;

	@Autowired
	private CarrierService carrierService;

	@Autowired
	private MasterFeignClient masterFeignClient;

	private static final String PROVISOIBASEAMOUNTINACTIVE = "Provisio Base Amount is already in deactivated state";
	private static final String PROVISOIBASEAMOUNTACTIVE = "Provisio Base Amount is already in activated state";
	private static final String LASTUPDATEDBYVALIDLENGTH = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	private static final String MANDATORYLASTUPDATEDBY = "Please provide Last Updated By";
	private static final String VALIDFROMDATE = "Effective From date must be 1-Dec, 1-Mar, 1-Jun or 1-Sep of the Year";
	private static final String VALIDTODATE = "Effective To Date must be 28/29-Feb, 31-May, 31-Aug or 30-Nov of the Year";
	private static final String QUATERLYCHECK = "Effective period not falling within the quaters";
	private static final String EFFECTIVE_TO_DATE = "Effective To date[";
	private static final String CONTEXT = "context ";
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String CLASS_CODE_LOV_COLUMN_VALUE = LOVEnum.CABIN.getLOVEnum();
	public static final String REGEX_PATTERN_AVERAGE = "^\\d{0,13}(\\.\\d{0,3})?$";
	String clientId = null;

	@Override
	public ProvisioBaseAmount createProvisioBaseAmount(ProvisioBaseAmount provisioBaseAmount) {
		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveToDate()));
		validateFromAndToCityCode(provisioBaseAmount);

		if (OptionalUtil.isPresent(provisioBaseAmount.getClassCode())) {
			validateClassCode(OptionalUtil.getValue(provisioBaseAmount.getClassCode()), clientId);
		}
		commonValidation(provisioBaseAmount);

		validEffectiveDateForCreate(provisioBaseAmount);

		validateOverLapForCreate(provisioBaseAmount);

		provisioBaseAmount.setActivate(Boolean.TRUE);

		return provisioBaseAmountMapper.mapToModel(provisioBaseAmountDao
				.createProvisioBaseAmount(provisioBaseAmountMapper.mapToEntity(provisioBaseAmount)));
	}

	@Override
	public List<ProvisioBaseAmount> getListOfProvisioBaseAmount(String fromCityCode, String toCityCode,
			String carrierCode, Boolean activate) {

		return provisioBaseAmountMapper.mapToModel(
				provisioBaseAmountDao.getListOfProvisioBaseAmount(fromCityCode, toCityCode, carrierCode, activate));

	}

	@Override
	public ProvisioBaseAmount getProvisioBaseAmountByTicketDate(String fromCityCode, String toCityCode,
			Date effectiveDate, String carrierCode, String classCode) {
		LocalDate effDate = null;
		ProvisioBaseAmountEntity provisioBaseAmountEntity = new ProvisioBaseAmountEntity();
		if (fromCityCode != null && toCityCode != null && effectiveDate != null && carrierCode != null
				&& classCode != null) {
			effDate = effectiveDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			provisioBaseAmountEntity = provisioBaseAmountDao.getAllProvisioBaseAmountEntity(effDate, fromCityCode,
					toCityCode, carrierCode, classCode);
			if (provisioBaseAmountEntity != null) {
				return provisioBaseAmountMapper.mapToModel(provisioBaseAmountEntity);
			} else {
				throw new BusinessException("Result not found");
			}
		}

		return provisioBaseAmountMapper.mapToModel(provisioBaseAmountEntity);
	}

	@Override
	public ProvisioBaseAmount updateProvisioBaseAmount(Integer provisioBaseAmountId,
			ProvisioBaseAmount provisioBaseAmount) {

		ProvisioBaseAmountEntity provisioBaseAmountEntity = provisioBaseAmountDao.findById(provisioBaseAmountId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisioBaseAmountId)));

		// update only if the record is active
		if (!provisioBaseAmountEntity.getActivate()) {
			throw new BusinessException("ProrateFactor is not active");
		}
		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		validateEffectiveToDate(getEffectiveFromDate(provisioBaseAmount, provisioBaseAmountEntity),
				getEffectiveToDate(provisioBaseAmount, provisioBaseAmountEntity));
		validateFromAndToCityCode(provisioBaseAmount, provisioBaseAmountEntity);
		if (OptionalUtil.isPresent(provisioBaseAmount.getClassCode())) {
			validateClassCode(OptionalUtil.getValue(provisioBaseAmount.getClassCode()), clientId);
		}
		commonValidation(provisioBaseAmount);

		validEffectiveDateForUpdate(provisioBaseAmount, provisioBaseAmountEntity);

		validateOverLapForUpdate(provisioBaseAmount, provisioBaseAmountEntity);

		return provisioBaseAmountMapper.mapToModel(provisioBaseAmountDao.updateProvisioBaseAmount(
				provisioBaseAmountMapper.mapToEntity(provisioBaseAmount, provisioBaseAmountEntity)));
	}

	@Override
	public void deactivateProvisioBaseAmount(Integer provisioBaseAmountId, String lastUpdatedBy) {

		ProvisioBaseAmountEntity provisioBaseAmountEntity = provisioBaseAmountDao.findById(provisioBaseAmountId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisioBaseAmountId)));

		if (!provisioBaseAmountEntity.getActivate())
			throw new BusinessException(PROVISOIBASEAMOUNTINACTIVE);

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		provisioBaseAmountEntity.setLastUpdatedBy(lastUpdatedBy);
		provisioBaseAmountEntity.setLastUpdatedDate(LocalDateTime.now());
		provisioBaseAmountEntity.setActivate(Boolean.FALSE);
		provisioBaseAmountDao.updateProvisioBaseAmount(provisioBaseAmountEntity);
	}

	@Override
	public void activateProvisioBaseAmount(Integer provisioBaseAmountId, String lastUpdatedBy) {
		ProvisioBaseAmountEntity provisioBaseAmountEntity = provisioBaseAmountDao.findById(provisioBaseAmountId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisioBaseAmountId)));

		if (provisioBaseAmountEntity.getActivate())
			throw new BusinessException(PROVISOIBASEAMOUNTACTIVE);

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		provisioBaseAmountEntity.setActivate(Boolean.TRUE);
		provisioBaseAmountEntity.setLastUpdatedBy(lastUpdatedBy);
		provisioBaseAmountEntity.setLastUpdatedDate(LocalDateTime.now());
		provisioBaseAmountDao.updateProvisioBaseAmount(provisioBaseAmountEntity);

	}

	public void validEffectiveDateForCreate(ProvisioBaseAmount provisioBaseAmount) {

		boolean validFromFlag = false;
		boolean validToFlag = false;

		String[] fromDateValidate = { "12-01", "03-01", "06-01", "09-01" };
		String[] toDateValidate = { "02-28", "02-29", "05-31", "08-31", "11-30" };

		LocalDate effectiveFromDate = OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveFromDate());
		LocalDate effectiveToDate = OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveToDate());

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd");

		try {

			for (String date : fromDateValidate) {
				if (date.equals(formatter.format(effectiveFromDate))) {
					validFromFlag = true;
					break;
				}
			}

			for (String date : toDateValidate) {
				if (date.equals(formatter.format(effectiveToDate))) {
					validToFlag = true;
					break;
				}
			}

		} catch (Exception e) {

			log.error(CONTEXT, e);
		}

		if (!validFromFlag) {
			throw new BusinessException(VALIDFROMDATE);
		}

		if (!validToFlag) {
			throw new BusinessException(VALIDTODATE);
		}

		LocalDate fromDate = OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveFromDate());
		LocalDate toDate = OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveToDate());

		long monthsBetween = ChronoUnit.MONTHS.between(YearMonth.from(fromDate), YearMonth.from(toDate));

		if (monthsBetween > 2) {
			throw new BusinessException(QUATERLYCHECK);
		}
	}

	private void validEffectiveDateForUpdate(ProvisioBaseAmount provisioBaseAmount,
			ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		boolean validFromFlag = false;
		boolean validToFlag = false;

		String[] fromDateValidate = { "12-01", "03-01", "06-01", "09-01" };
		String[] toDateValidate = { "02-28", "02-29", "05-31", "08-31", "11-30" };

		LocalDate effectiveFromDate = getEffectiveFromDate(provisioBaseAmount, provisioBaseAmountEntity);
		LocalDate effectiveToDate = getEffectiveToDate(provisioBaseAmount, provisioBaseAmountEntity);
		DateTimeFormatter sdf1 = DateTimeFormatter.ofPattern("MM-dd");
		try {

			for (String date : fromDateValidate) {
				if (date.equals(sdf1.format(effectiveFromDate))) {
					validFromFlag = true;
				}
			}

			for (String date : toDateValidate) {
				if (date.equals(sdf1.format(effectiveToDate))) {
					validToFlag = true;
				}
			}

		} catch (Exception e) {

			log.error(CONTEXT, e);
		}

		if (!validFromFlag) {
			throw new BusinessException(VALIDFROMDATE);
		}

		if (!validToFlag) {
			throw new BusinessException(VALIDTODATE);
		}

		LocalDate fromDate = getEffectiveFromDate(provisioBaseAmount, provisioBaseAmountEntity);
		LocalDate toDate = getEffectiveToDate(provisioBaseAmount, provisioBaseAmountEntity);

		long monthsBetween = ChronoUnit.MONTHS.between(YearMonth.from(fromDate), YearMonth.from(toDate));

		if (monthsBetween > 2) {
			throw new BusinessException(QUATERLYCHECK);
		}
	}

	public void commonValidation(ProvisioBaseAmount provisioBaseAmount) {

		if (OptionalUtil.isPresent(provisioBaseAmount.getProvisoBaseAmount())) {
			validateProvisoBaseAmount(provisioBaseAmount.getProvisoBaseAmount());
		}

		if (OptionalUtil.isPresent(provisioBaseAmount.getCarrierCode())) {
			if (!carrierService
					.isValidcarrierDesignatorCodeList(OptionalUtil.getValue(provisioBaseAmount.getCarrierCode()))) {
				throw new BusinessException(
						"Invalid Carrier Code " + OptionalUtil.getValue(provisioBaseAmount.getCarrierCode()));
			}
		}

		if (OptionalUtil.isPresent(provisioBaseAmount.getAlphaCurrencyCode())) {
			if (!currencyService
					.isValidCurrencyCode(OptionalUtil.getValue(provisioBaseAmount.getAlphaCurrencyCode()))) {
				throw new BusinessException("Invalid Alpha Currency Code "
						+ OptionalUtil.getValue(provisioBaseAmount.getAlphaCurrencyCode()));
			}
		}

		if (OptionalUtil.isPresent(provisioBaseAmount.getFromCityCode())) {
			if (!airportService
					.isValidAirportCodeOrCityCode(OptionalUtil.getValue(provisioBaseAmount.getFromCityCode()))) {
				throw new BusinessException(
						"Invalid From City Code " + OptionalUtil.getValue(provisioBaseAmount.getFromCityCode()));
			}
		}
		if (OptionalUtil.isPresent(provisioBaseAmount.getToCityCode())) {
			if (!airportService
					.isValidAirportCodeOrCityCode(OptionalUtil.getValue(provisioBaseAmount.getToCityCode()))) {
				throw new BusinessException(
						"Invalid To City Code " + OptionalUtil.getValue(provisioBaseAmount.getToCityCode()));
			}
		}

	}

	private void validateProvisoBaseAmount(Optional<String> provisoBaseAmount) {
		
		if (OptionalUtil.isPresent(provisoBaseAmount)) {
			Pattern digitPattern = Pattern.compile(REGEX_PATTERN_AVERAGE);
			if (!digitPattern.matcher(OptionalUtil.getValue(provisoBaseAmount)).matches()) {
				throw new BusinessException("Invalid Proviso Base Amount "+ OptionalUtil.getValue(provisoBaseAmount));
			}
		}
	}

	@Override
	public ProvisioBaseAmount getProvisioBaseAmountByTicketDate(String fromCityCode, String toCityCode,
			String effectiveDate, String carrierCode, String classCode) {
		ProvisioBaseAmountEntity provisioBaseAmountEntity = new ProvisioBaseAmountEntity();
		if (fromCityCode != null && toCityCode != null && effectiveDate != null && carrierCode != null
				&& classCode != null) {
			Date date = null;
			try {
				date = new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
			} catch (Exception e) {
				log.error(CONTEXT, e);
			}
			LocalDate effDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			provisioBaseAmountEntity = provisioBaseAmountDao.getAllProvisioBaseAmountEntity(effDate, fromCityCode,
					toCityCode, carrierCode, classCode);
			if (provisioBaseAmountEntity != null) {
				return provisioBaseAmountMapper.mapToModel(provisioBaseAmountEntity);
			} else {
				return new ProvisioBaseAmount();
			}
		}

		return provisioBaseAmountMapper.mapToModel(provisioBaseAmountEntity);
	}

	@Override
	public ProvisioBaseAmount getProvisoBaseAmount(String fromCityCode, String toCityCode, String classCode,
			String carrierCode, String issueDate) {

		Date date = null;
		try {
			date = new SimpleDateFormat("yyyy-MM-dd").parse(issueDate);
		} catch (Exception e) {
			log.error(CONTEXT, e);
		}
		LocalDate issDate = null;
		issDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

		ProvisioBaseAmountEntity provisioBaseAmountEntity = new ProvisioBaseAmountEntity();
		provisioBaseAmountEntity = provisioBaseAmountDao.getProvisoBaseAmount(fromCityCode, toCityCode, classCode,
				carrierCode, issDate);

		if (provisioBaseAmountEntity != null) {
			return provisioBaseAmountMapper.mapToModel(provisioBaseAmountEntity);
		} else {
			return null;
		}
	}

	private LocalDate getEffectiveToDate(ProvisioBaseAmount provisioBaseAmount,
			ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		return OptionalUtil.isPresent(provisioBaseAmount.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveToDate())
				: provisioBaseAmountEntity.getEffectiveToDate();
	}

	private LocalDate getEffectiveFromDate(ProvisioBaseAmount provisioBaseAmount,
			ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		return OptionalUtil.isPresent(provisioBaseAmount.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveFromDate())
				: provisioBaseAmountEntity.getEffectiveFromDate();
	}

	protected void validateEffectiveToDate(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException(EFFECTIVE_TO_DATE + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException(EFFECTIVE_TO_DATE + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}

	private void validateOverLapForCreate(ProvisioBaseAmount provisioBaseAmount) {

		List<ProvisioBaseAmountEntity> overLapForCreate = provisioBaseAmountDao.getOverLapForCreate(
				OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(provisioBaseAmount.getEffectiveToDate()),
				OptionalUtil.getValue(provisioBaseAmount.getFromCityCode()),
				OptionalUtil.getValue(provisioBaseAmount.getToCityCode()),
				OptionalUtil.getValue(provisioBaseAmount.getCarrierCode()),
				OptionalUtil.getValue(provisioBaseAmount.getClassCode()));

		if (!overLapForCreate.isEmpty() && overLapForCreate.get(0).getActivate()) {
			throw new BusinessException("Record already exists");
		}
		if (!overLapForCreate.isEmpty() && !overLapForCreate.get(0).getActivate()) {
			throw new BusinessException("Record already exists in Deactivate state");
		}

	}

	private void validateOverLapForUpdate(ProvisioBaseAmount provisioBaseAmount,
			ProvisioBaseAmountEntity provisioBaseAmountEntity) {

		LocalDate effectiveFromDate = getEffectiveFromDate(provisioBaseAmount, provisioBaseAmountEntity);
		LocalDate effectiveToDate = getEffectiveToDate(provisioBaseAmount, provisioBaseAmountEntity);
		String fromCityCode = getFromCityCode(provisioBaseAmount, provisioBaseAmountEntity);
		String toCityCode = getToCityCode(provisioBaseAmount, provisioBaseAmountEntity);
		String carrierCode = getCarrierCode(provisioBaseAmount, provisioBaseAmountEntity);
		String classCode = getClassCode(provisioBaseAmount, provisioBaseAmountEntity);

		List<ProvisioBaseAmountEntity> overLapForUpdate = provisioBaseAmountDao.getOverLapForUpdate(effectiveFromDate,
				effectiveToDate, fromCityCode, toCityCode, carrierCode, classCode,
				provisioBaseAmountEntity.getProvisoBaseid());

		if (!overLapForUpdate.isEmpty() && overLapForUpdate.get(0).getActivate()) {
			throw new BusinessException("Record already exists");
		}
		if (!overLapForUpdate.isEmpty() && !overLapForUpdate.get(0).getActivate()) {
			throw new BusinessException("Record already exists in Deactivate state");
		}

	}

	private String getClassCode(ProvisioBaseAmount provisioBaseAmount,
			ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		return OptionalUtil.isPresent(provisioBaseAmount.getClassCode())
				? OptionalUtil.getValue(provisioBaseAmount.getClassCode())
				: provisioBaseAmountEntity.getClassCode();
	}

	private String getCarrierCode(ProvisioBaseAmount provisioBaseAmount,
			ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		return OptionalUtil.isPresent(provisioBaseAmount.getCarrierCode())
				? OptionalUtil.getValue(provisioBaseAmount.getCarrierCode())
				: provisioBaseAmountEntity.getCarrierCode();
	}

	private void validateFromAndToCityCode(ProvisioBaseAmount provisioBaseAmount) {
		if (OptionalUtil.getValue(provisioBaseAmount.getFromCityCode())
				.equalsIgnoreCase(OptionalUtil.getValue(provisioBaseAmount.getToCityCode()))) {
			throw new BusinessException("From City Code [" + OptionalUtil.getValue(provisioBaseAmount.getFromCityCode())
					+ "] and To City Code [" + OptionalUtil.getValue(provisioBaseAmount.getToCityCode())
					+ "] should not be same");
		}
	}

	private void validateFromAndToCityCode(ProvisioBaseAmount provisioBaseAmount,
			ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		if (getFromCityCode(provisioBaseAmount, provisioBaseAmountEntity)
				.equalsIgnoreCase(getToCityCode(provisioBaseAmount, provisioBaseAmountEntity))) {
			throw new BusinessException("From City Code ["
					+ getFromCityCode(provisioBaseAmount, provisioBaseAmountEntity) + "] and To City Code ["
					+ getToCityCode(provisioBaseAmount, provisioBaseAmountEntity) + "] should not be same");
		}
	}

	private String getToCityCode(ProvisioBaseAmount provisioBaseAmount,
			ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		return OptionalUtil.isPresent(provisioBaseAmount.getToCityCode())
				? OptionalUtil.getValue(provisioBaseAmount.getToCityCode())
				: provisioBaseAmountEntity.getToCityCode();
	}

	private String getFromCityCode(ProvisioBaseAmount provisioBaseAmount,
			ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		return OptionalUtil.isPresent(provisioBaseAmount.getFromCityCode())
				? OptionalUtil.getValue(provisioBaseAmount.getFromCityCode())
				: provisioBaseAmountEntity.getFromCityCode();
	}

	private void validateClassCode(String classCode, String clientId) {
		if (classCode != null) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, TABLENAME,
					CLASS_CODE_LOV_COLUMN_VALUE);

			if (!(listOfValues.contains(classCode))) {
				throw new BusinessException("Class Code[" + classCode + "] is Not Valid");
			}
		}
	}

	@Override
	public ProvisioBaseAmount findByProvisioBaseId(Integer provisoBaseid) {
		return provisioBaseAmountMapper.mapToModel(provisioBaseAmountDao.findById(provisoBaseid)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoBaseid))));
	}
}
