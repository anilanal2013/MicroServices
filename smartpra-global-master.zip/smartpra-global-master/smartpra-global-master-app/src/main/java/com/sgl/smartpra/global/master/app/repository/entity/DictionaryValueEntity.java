package com.sgl.smartpra.global.master.app.repository.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.global.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name="global_mas_dictionary_value")
@Data
@EqualsAndHashCode(callSuper=false)
@DynamicInsert
@DynamicUpdate
public class DictionaryValueEntity extends BaseEntity {

	/**
	 *  Serial Version Id
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="dictionary_value_id")
	private int dictionaryValueId;

	@Column(name="dictionary_value")
	private String dictionaryValue;

	//bi-directional many-to-one association to dictionaryEntity
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="dictionary_id")
	private DictionaryEntity dictionaryEntity;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
