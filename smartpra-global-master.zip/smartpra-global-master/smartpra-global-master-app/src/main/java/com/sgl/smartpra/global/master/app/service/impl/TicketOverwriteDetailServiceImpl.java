package com.sgl.smartpra.global.master.app.service.impl;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.dao.entity.TicketOverwiteDetailEntity;
import com.sgl.smartpra.global.master.app.dao.repository.TicketOverwriteDetailRepository;
import com.sgl.smartpra.global.master.app.mapper.TicketOverwriteDetailMapper;
import com.sgl.smartpra.global.master.app.mapper.TicketOverwriteMapper;
import com.sgl.smartpra.global.master.app.service.TicketOverwriteDetailService;
import com.sgl.smartpra.global.master.model.TicketOverwrite;
import com.sgl.smartpra.global.master.model.TicketOverwriteDetail;

@Service
@Transactional
public class TicketOverwriteDetailServiceImpl implements TicketOverwriteDetailService {

	@Autowired
	private TicketOverwriteDetailRepository ticketOverwriteDetailRepository;
	
	@Autowired
	private TicketOverwriteDetailMapper ticketOverwriteDetailMapper;
	
	
	@Autowired
	private TicketOverwriteMapper ticketOverwriteMapper;

	@Override
	public TicketOverwriteDetail saveTicketOverwriteDetail(
			TicketOverwriteDetail ticketOverwiteDetailDao) {
		TicketOverwiteDetailEntity ticketOverwiteDetailEntity = ticketOverwriteDetailMapper.mapToEntity(ticketOverwiteDetailDao);
		TicketOverwiteDetailEntity saveticketOverwiteDetailEntity = ticketOverwriteDetailRepository
				.save(ticketOverwiteDetailEntity);
		return ticketOverwriteDetailMapper.mapToModel(saveticketOverwiteDetailEntity);
	}

	@Override
	public TicketOverwriteDetail getTicketOverwriteDetail(Long id) {
		return ticketOverwriteDetailMapper.mapToModel(ticketOverwriteDetailRepository.findById(id).get());
	}

	@Override
	public void deleteTicketOverwriteDetail(Long id) {
		ticketOverwriteDetailRepository.findById(id).ifPresent(ticket ->{
			ticket.getTicketOverwrite().setIsActive("0");
			ticketOverwriteDetailRepository.save(ticket);
		});
	}

	@Override
	public void activateOrDeactiveTicketDetail(Long id) {
		ticketOverwriteDetailRepository.findById(id).ifPresent(ticket ->{
			if(ticket.getTicketOverwrite().getIsActive().equalsIgnoreCase("1")) {
				ticket.getTicketOverwrite().setIsActive("0");
			} else {
				ticket.getTicketOverwrite().setIsActive("1");
			}
			ticketOverwriteDetailRepository.save(ticket);
		});

	}

	public List<TicketOverwriteDetail> getTicketOverwriteDetail(TicketOverwrite ticketOverwrite,String tableName) {
		List<TicketOverwiteDetailEntity> ticketOverwiteDetailList= ticketOverwriteDetailRepository.findByTicketOverwriteAndTableName(ticketOverwriteMapper.mapToEntity(ticketOverwrite),tableName);
	return ticketOverwiteDetailList.stream().map(ticketOverwriteDetailMapper::mapToModel).collect(Collectors.toCollection(LinkedList::new));
	}
}
