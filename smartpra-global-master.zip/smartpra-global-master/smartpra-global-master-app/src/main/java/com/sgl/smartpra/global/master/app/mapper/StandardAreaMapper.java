package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.repository.entity.StandardAreaEntity;
import com.sgl.smartpra.global.master.model.StandardArea;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface StandardAreaMapper extends BaseMapper<StandardArea, StandardAreaEntity> {
	
	StandardAreaEntity mapToEntity(StandardArea standardArea, @MappingTarget StandardAreaEntity standardAreaEntity);

	//@Mapping(source = "standardAreaCode", target = "standardAreaCode", ignore = true)
	StandardAreaEntity mapToEntity(StandardArea standardArea);
}