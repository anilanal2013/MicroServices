package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ProvisoDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailEntity;
import com.sgl.smartpra.global.master.app.mapper.ProvisoDetailCombinedMapper;
import com.sgl.smartpra.global.master.app.mapper.ProvisoDetailMapper;
import com.sgl.smartpra.global.master.app.service.ProvisoDetailService;
import com.sgl.smartpra.global.master.model.ProvisoDetailModel;
import com.sgl.smartpra.global.master.model.ProvisoDetailStgModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoDetailServiceImpl implements ProvisoDetailService {
	private static final String DETAIL_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso Detail data not available for selected Proviso Main record";

	@Autowired
	private ProvisoDetailDao provisoDetailDao;
	@Autowired
	private ProvisoDetailMapper provisoDetailMapper;
	@Autowired
	private ProvisoDetailCombinedMapper provisoDetailCombinedMapper;

	@Override
	public List<ProvisoDetailModel> getProvisoDetailByProvisoMainId(Optional<Integer> provisoMainId) {
		
		List<Integer> provisoMainIdFromDb=provisoDetailDao.getListOfProvisoMainIdFromDetailDb();
		if(!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))){
			throw new BusinessException(DETAIL_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		return provisoDetailMapper.mapToModel(provisoDetailDao.findByMainId(provisoMainId));
	}

	@Override
	public ProvisoDetailModel getProvisoDetailByProvisoDetailId(Integer provisoDetailId) {

		return provisoDetailMapper.mapToModel(provisoDetailDao.findById(provisoDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoDetailId))));
	}

	@Override
	public List<ProvisoDetailModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {
		return provisoDetailMapper.mapToModel(provisoDetailDao.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	public List<ProvisoDetailModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> fbGroupCode) {

		return provisoDetailMapper.mapToModel(provisoDetailDao.search(carrierNumCode, provisoSeqNumber, fbGroupCode));
	}

	@Override
	public ProvisoDetailStgModel saveProvisoDetail(ProvisoDetailStgModel provisoDetailStgModel) {
		provisoDetailStgModel.setCreatedDate(LocalDateTime.now());
		return provisoDetailCombinedMapper
				.mapToModel(provisoDetailDao.create(provisoDetailCombinedMapper.mapToEntity(provisoDetailStgModel)));
	}

	@Override
	public List<ProvisoDetailModel> getExceptionRecordFromProvisoDetail(Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber, Optional<String> carrierNumCode) {
		return provisoDetailMapper.mapToModel(provisoDetailDao.getExceptionRecordFromProvisoDetail(provisoSeqNumber,
				detailRecNumber, carrierNumCode));
	}
}
