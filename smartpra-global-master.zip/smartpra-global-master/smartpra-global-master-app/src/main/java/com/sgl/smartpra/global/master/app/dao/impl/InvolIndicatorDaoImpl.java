package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.InvolIndicatorDao;
import com.sgl.smartpra.global.master.app.dao.entity.spec.InvolIndicatorEntitySpecification;
import com.sgl.smartpra.global.master.app.repository.InvolIndicatorRepository;
import com.sgl.smartpra.global.master.app.repository.entity.InvolIndicatorEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class InvolIndicatorDaoImpl<T> extends CommonSearchDao<T> implements InvolIndicatorDao {

	@Autowired
	private InvolIndicatorRepository involIndicatorRepository;

	@Override
	public List<InvolIndicatorEntity> findAll(Optional<String> effectiveDate, Optional<String> indicatorType) {
		return involIndicatorRepository
				.findAll(InvolIndicatorEntitySpecification.findAll(effectiveDate, indicatorType));
	}

	@Override
	public List<InvolIndicatorEntity> search(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> indicatorType, Optional<String> ticketField, Optional<Boolean> activate) {
		return involIndicatorRepository.findAll(InvolIndicatorEntitySpecification.search(effectiveFromDate,
				effectiveToDate, indicatorType, ticketField, activate));
	}

	@Override
	@Cacheable(value = "involIndicator", key = "#id")
	public Optional<InvolIndicatorEntity> findById(Integer id) {
		log.info("Cacheable involIndicator Entity's ID= {}", id);
		return involIndicatorRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "involIndicator", key = "#involIndicatorEntity.involIndicatorId"),
			@CacheEvict(value = "involIndicatorSearch", allEntries = true) })
	public InvolIndicatorEntity create(InvolIndicatorEntity involIndicatorEntity) {
		return involIndicatorRepository.save(involIndicatorEntity);
	}

	@Override
	@CachePut(value = "involIndicator", key = "#involIndicatorEntity.involIndicatorId")
	@CacheEvict(value = "involIndicatorSearch", allEntries = true)
	public InvolIndicatorEntity update(InvolIndicatorEntity involIndicatorEntity) {
		return involIndicatorRepository.save(involIndicatorEntity);
	}

	@Override
	public long getOverLapRecordCount(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> ticketField, Optional<String> indicatorText) {
		return involIndicatorRepository.count(Specification
				.where(InvolIndicatorEntitySpecification.equalsTicketField(OptionalUtil.getValue(ticketField)))
				.and(InvolIndicatorEntitySpecification.equalsIndicatorText(OptionalUtil.getValue(indicatorText)))
				.and(InvolIndicatorEntitySpecification
						.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveFromDate))
						.or(InvolIndicatorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(
								OptionalUtil.getLocalDateValue(effectiveToDate)))));
	}

	@Override
	public List<InvolIndicatorEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return involIndicatorRepository
				.findAll((InvolIndicatorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(InvolIndicatorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(InvolIndicatorEntitySpecification.isActive())));

	}

	@Override
	public List<InvolIndicatorEntity> validateDate(Optional<String> effectiveDate) {
		return involIndicatorRepository.findAll(InvolIndicatorEntitySpecification.validateDate(effectiveDate));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String ticketField,
			String indicatorText, Integer involIndicatorId) {
		return involIndicatorRepository.count(Specification
				.where(InvolIndicatorEntitySpecification.equalsTicketField(ticketField))
				.and(InvolIndicatorEntitySpecification.equalsIndicatorText(indicatorText))
				.and(InvolIndicatorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(InvolIndicatorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(InvolIndicatorEntitySpecification.notEqualsInvolIndicatorId(involIndicatorId))));
	}

	@Override
	public long getCount(InvolIndicatorEntity involIndicatorEntity) {
		return involIndicatorRepository.count(InvolIndicatorEntitySpecification.search(involIndicatorEntity));
	}

	@Override
	public Page<InvolIndicatorEntity> getData(InvolIndicatorEntity mapToEntity, Pageable pageable) {

		return involIndicatorRepository.findAll(InvolIndicatorEntitySpecification.search(mapToEntity), pageable);

	}

}
