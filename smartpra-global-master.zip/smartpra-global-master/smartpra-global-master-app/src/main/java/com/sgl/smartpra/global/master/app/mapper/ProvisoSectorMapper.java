package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorEntity;
import com.sgl.smartpra.global.master.model.ProvisoSectorModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoSectorMapper extends BaseMapper<ProvisoSectorModel, ProvisoSectorEntity> {
	ProvisoSectorEntity mapToEntity(ProvisoSectorModel provisoSectorModel,
			@MappingTarget ProvisoSectorEntity provisoSectorStgEntity);

	@Mapping(source = "provisoSectorId", target = "provisoSectorId", ignore = true)
	ProvisoSectorEntity mapToEntity(ProvisoSectorModel provisoSectorModel);
}
