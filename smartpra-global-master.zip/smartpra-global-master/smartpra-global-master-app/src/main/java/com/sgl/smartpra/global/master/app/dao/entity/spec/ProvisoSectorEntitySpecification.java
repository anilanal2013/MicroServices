package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorEntity;

public class ProvisoSectorEntitySpecification {
	ProvisoSectorEntitySpecification(){
		
	}
	public static Specification<ProvisoSectorEntity> searchByProMain(Optional<Integer> provisoMainId,
			Optional<String> areaFrom) {
		return (provisoSectorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoSectorEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}
			if (OptionalUtil.isPresent(areaFrom)) {
				predicates.add(
						criteriaBuilder.equal(provisoSectorEntity.get("areaFrom"), OptionalUtil.getValue(areaFrom)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<ProvisoSectorEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber) {
		return (provisoSectorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoSectorEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoSectorEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProvisoSectorEntity> findByMainId(Optional<Integer> provisoMainId) {
		return (provisoSectorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoSectorEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}
			
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<ProvisoSectorEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber,Optional<Integer> sectionRecNumber) {
		return (provisoSectorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoSectorEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoSectorEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			if (OptionalUtil.isPresent(sectionRecNumber)) {
				predicates.add(criteriaBuilder.equal(provisoSectorEntity.get("sectionRecNumber"),
						OptionalUtil.getValue(sectionRecNumber)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
