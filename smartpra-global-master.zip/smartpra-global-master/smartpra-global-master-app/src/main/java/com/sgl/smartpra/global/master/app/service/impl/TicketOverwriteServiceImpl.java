package com.sgl.smartpra.global.master.app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.dao.entity.TicketOverwiteDetailEntity;
import com.sgl.smartpra.global.master.app.dao.entity.TicketOverwriteEntity;
import com.sgl.smartpra.global.master.app.dao.repository.TicketOverwriteRepository;
import com.sgl.smartpra.global.master.app.mapper.TicketOverwriteDetailMapper;
import com.sgl.smartpra.global.master.app.mapper.TicketOverwriteMapper;
import com.sgl.smartpra.global.master.app.service.TicketOverwriteService;
import com.sgl.smartpra.global.master.model.TicketOverwrite;

@Service
@Transactional
public class TicketOverwriteServiceImpl implements TicketOverwriteService {

		
	@Autowired
	private TicketOverwriteRepository ticketOverwriteRepository;

	@Autowired
	private TicketOverwriteDetailMapper ticketOverwriteDetailMapper;
	
	@Autowired
	private TicketOverwriteMapper ticketOverwriteMapper;

	@Override
	public TicketOverwrite saveTicketOverwrite(
			TicketOverwrite ticketOverwriteDao) {
		TicketOverwriteEntity mapToEntity = ticketOverwriteMapper.mapToEntity(ticketOverwriteDao);
		TicketOverwriteEntity ticketOverwriteEntity = ticketOverwriteRepository
						.save(mapToEntity);
		TicketOverwrite ticketOverwriteDetailDao = ticketOverwriteMapper.mapToModel(ticketOverwriteEntity);
		return ticketOverwriteDetailDao;
	}

	@Override
	public TicketOverwrite getTicketOverwrite(Long id) {
		Optional<TicketOverwriteEntity> ticketOverwriteEntity = ticketOverwriteRepository.findById(id);
		TicketOverwrite ticketOverwriteDao = null;
		if(ticketOverwriteEntity.isPresent()) {
			ticketOverwriteDao = ticketOverwriteMapper.mapToModel(ticketOverwriteEntity.get());
			List<TicketOverwiteDetailEntity> ticketOverwiteDetails = ticketOverwriteEntity.get().getTicketOverwiteDetails();
			ticketOverwriteDao.setTicketOverwiteDetails(ticketOverwriteDetailMapper.mapToModel(ticketOverwiteDetails));
		}
		return ticketOverwriteDao;
	}

	@Override
	public TicketOverwrite validateTicketOverwriteDetail(String source1, String source2, String processStatus,
			String transationCode) {
		TicketOverwriteEntity ticketOverwriteFilter = new TicketOverwriteEntity();
		TicketOverwrite ticketOverwrite = new TicketOverwrite();
		if (source1!=null) {
			ticketOverwriteFilter.setSource1(source1);
		}

		if (source2!=null) {
			ticketOverwriteFilter.setSource2(source2);
		}

		if (processStatus!=null) {
			ticketOverwriteFilter.setProcessStatus(processStatus);
		}
		if (transationCode!=null) {
			ticketOverwriteFilter.setTransationCode(transationCode);
		}
		if(ticketOverwriteFilter!=null)
		{
		List<TicketOverwriteEntity> ticketOverwriteObj = ticketOverwriteRepository.findAll(Example.of(ticketOverwriteFilter));
		if(!ticketOverwriteObj.isEmpty() && ticketOverwriteObj.size()>0)
		{
			ticketOverwrite = ticketOverwriteMapper.mapToModel(ticketOverwriteObj.get(0));
		}
		
		}
		return ticketOverwrite;
	}

}
