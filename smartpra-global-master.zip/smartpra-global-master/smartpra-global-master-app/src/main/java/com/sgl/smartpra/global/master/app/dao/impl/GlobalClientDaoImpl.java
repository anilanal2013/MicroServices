package com.sgl.smartpra.global.master.app.dao.impl;

import com.sgl.smartpra.global.master.app.dao.GlobalClientDao;
import com.sgl.smartpra.global.master.app.dao.entity.GlobalClientEntity;
import com.sgl.smartpra.global.master.app.dao.repository.GlobalClientRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@Slf4j
public class GlobalClientDaoImpl implements GlobalClientDao {

    @Autowired
    private GlobalClientRepository globalClientRepository;


    public Optional<GlobalClientEntity> findAll(Example<GlobalClientEntity> globalClient) {
        return globalClientRepository.findOne(globalClient);
    }

}
