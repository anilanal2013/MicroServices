package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.ProvisoSectorService;
import com.sgl.smartpra.global.master.model.ProvisoSectorModel;

@RestController
@RequestMapping("/proviso/sector")
public class ProvisoSectorController {

	@Autowired
	private ProvisoSectorService provisoSectorService;

	@GetMapping("/provisoMain/{provisoMainId}")
	public List<ProvisoSectorModel> getProvisoSectorByProvisoMainId(
			@PathVariable(name = "provisoMainId", required = false) Optional<Integer> provisoMainId) {

		return provisoSectorService.getProvisoSectorByProvisoMainId(provisoMainId);
	}

	@GetMapping("/{provisoSectorId}")
	public ProvisoSectorModel getProvisoSectorByProvisioSectorId(
			@PathVariable(value = "provisoSectorId") Integer provisoSectorId) {
		return provisoSectorService.getProvisoSectorByProvisioSectorId(provisoSectorId);
	}

	@GetMapping("/{provisoMainId}/{areaFrom}")
	public List<ProvisoSectorModel> searchByProvisoInMain(
			@PathVariable(name = "provisoMainId", required = false) Optional<Integer> provisoMainId,
			@PathVariable(name = "areaFrom", required = false) Optional<String> areaFrom) {
		return provisoSectorService.searchByProvisoInMain(provisoMainId, areaFrom);
	}

	@GetMapping("/proviso-sector/{carrierNumCode}/{provisoSeqNumber}")
	public List<ProvisoSectorModel> searchByProvisoSector(
			@PathVariable(name = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@PathVariable(name = "provisoSeqNumber", required = false) Optional<Integer> provisoSeqNumber) {
		return provisoSectorService.search(carrierNumCode, provisoSeqNumber);
	}

	@GetMapping("/search")
	public List<ProvisoSectorModel> search(
			@RequestParam(name = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@RequestParam(name = "provisoSeqNumber", required = false) Optional<Integer> provisoSeqNumber,
			@RequestParam(name = "sectionRecNumber", required = false) Optional<Integer> sectionRecNumber) {
		return provisoSectorService.search(carrierNumCode, provisoSeqNumber, sectionRecNumber);
	}
}
