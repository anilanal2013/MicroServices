package com.sgl.smartpra.global.master.app.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.SearchCriteria;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.global.master.app.dao.UserAreaDao;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.UserAreaMapper;
import com.sgl.smartpra.global.master.app.repository.UserAreaRepository;
import com.sgl.smartpra.global.master.app.repository.entity.UserAreaEntity;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CarrierService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.StandardAreaSrevice;
import com.sgl.smartpra.global.master.app.service.UserAreaSrevice;
import com.sgl.smartpra.global.master.model.Geo;
import com.sgl.smartpra.global.master.model.GlobalUserArea;

@Service
@Transactional
public class UserAreaServiceImpl implements UserAreaSrevice {

	@Autowired
	UserAreaMapper userAreaMapper;

	@Autowired
	private UserAreaRepository userAreaRepository;

	@Autowired
	private UserAreaDao userAreaDao;

	@Autowired
	private AirportService airportService;

	@Autowired
	private CountryService countryService;

	@Autowired
	private StandardAreaSrevice standardAreaSrevice;

	@Autowired
	private CarrierService carrierService;

	private static final String USERAREA = "Userarea";
	private static final String MANDATORYLASTUPDATEDBY = "Please provide lastupdatedby";
	private static final String MANDATORYGEOTYPEVALUE = "Please provide Geo Type Value";
	private static final String USERAREAALREADYEXIST = "UserAreacode Record already exists";
	private static final String LASTUPDATEDBYVALIDLENGTH = "LastUpdatedBy should be minimum of 1 and maximum of 15 characters";

	@Override
	public List<GlobalUserArea> getListOfUserArea(String userAreaCode, String userAreaName) {

		List<SearchCriteria> params = new ArrayList<>();

		// fetch only active records
		params.add(new SearchCriteria("isActive", "=", new Boolean("true")));

		if (userAreaCode != null && userAreaCode.length() > 0) {
			params.add(new SearchCriteria("userAreaCode", "=", userAreaCode));
		}

		if (userAreaName != null && userAreaName.length() > 0) {
			params.add(new SearchCriteria("userAreaName", ":", userAreaName));
		}

		return userAreaMapper.mapToUserAreaModelList(userAreaDao.search(params, new UserAreaEntity()));

	}

	@Override
	public GlobalUserArea getUserAreaByUserAreaCode(Integer globalUserAreaId) {

		Optional<UserAreaEntity> userAreaEntity = userAreaRepository.findById(globalUserAreaId);

		if (userAreaEntity.isPresent()) {

			// return only if the record is active
			if (userAreaEntity.get().getIsActive()) {
				return userAreaMapper.mapToUserAreaModel(userAreaEntity.get());
			}

			throw new BusinessException("User is not active");

		} else {
			throw new ResourceNotFoundException("User", "id", globalUserAreaId);
		}
	}

	@Override
	public GlobalUserArea createUserArea(GlobalUserArea globaluserArea) {
		boolean flag = false;
		List<UserAreaEntity> userAreaEntity = userAreaRepository.findByUserAreaCode(globaluserArea.getUserAreaCode());
		String carrierCode = globaluserArea.getAreaKey2();
		if (!userAreaEntity.isEmpty()) {
			throw new BusinessException(USERAREAALREADYEXIST);
		}

		if (globaluserArea.getAreaKey1().equals("P")) {

			carrierService.findCarrierByCarrierCode(carrierCode);

			try {
				carrierService.findCarrierByCarrierCode(carrierCode);
			} catch (ResourceNotFoundException rnfe) {
				throw new BusinessException("Invalid" + carrierCode);
			} catch (BusinessException se) {
				throw new BusinessException("Invalid" + carrierCode);
			}

			if (!globaluserArea.getAreaKey4().equals("GLB")) {
				throw new BusinessException(
						"Invalid  area_key combination value pair for " + globaluserArea.getAreaKey1());
			}
		}

		List<Geo> geoList = globaluserArea.getIncludeGeoList();

		List<Geo> geoList1 = globaluserArea.getExcludeGeoList();

		StringBuilder geoString = new StringBuilder();

		StringBuilder m1 = userGeoList(geoList, geoString, flag);

		StringBuilder geoString1 = new StringBuilder();

		flag = true;
		StringBuilder ex = userGeoList(geoList1, geoString1, flag);

		String str = m1.toString();

		globaluserArea.setAreaIncludeList(str);

		String str1 = ex.toString();

		globaluserArea.setAreaExcludeList(str1);
		typeValueList = new ArrayList<>();
		typeValueList.clear();
		globaluserArea.setIsActive(Boolean.TRUE);
		globaluserArea.setCreatedDate(new Timestamp(new Date().getTime()));

		return userAreaMapper
				.mapToUserAreaModel(userAreaRepository.save(userAreaMapper.mapToUserAreaEntity(globaluserArea)));

	}

	@Override
	public GlobalUserArea updateUserArea(Integer globalUserAreaId, GlobalUserArea globaluserArea) {

		boolean flag = false;
		typeValueList.clear();

		Optional<UserAreaEntity> userAreaEntity = userAreaRepository.findById(globalUserAreaId);

		List<Geo> geoList = globaluserArea.getIncludeGeoList();

		List<Geo> geoList1 = globaluserArea.getExcludeGeoList();

		StringBuilder geoString = new StringBuilder();

		StringBuilder m1 = userGeoList(geoList, geoString, flag);

		StringBuilder geoString1 = new StringBuilder();

		flag = true;
		StringBuilder ex = userGeoList(geoList1, geoString1, flag);

		String str = m1.toString();

		globaluserArea.setAreaIncludeList(str);

		String str1 = ex.toString();

		globaluserArea.setAreaExcludeList(str1);

		if (!userAreaEntity.isPresent())
			throw new ResourceNotFoundException("userArea", "id", globalUserAreaId);

		if (!userAreaEntity.get().getIsActive()) {
			throw new BusinessException("user is not active");
		}

		typeValueList = new ArrayList<>();
		typeValueList.clear();
		userAreaEntity.get().setAreaIncludeList(globaluserArea.getAreaIncludeList());
		userAreaEntity.get().setAreaExcludeList(globaluserArea.getAreaExcludeList());

		userAreaEntity.get().setUserAreaName(globaluserArea.getUserAreaName());

		userAreaEntity.get().setLastUpdatedBy(globaluserArea.getLastUpdatedBy());
		userAreaEntity.get().setLastUpdatedDate(new Timestamp(new Date().getTime()));

		return userAreaMapper.mapToUserAreaModel(userAreaRepository.save(userAreaEntity.get()));
	}

	@Override
	public void deactivateUserArea(Integer globalUserAreaId, String lastUpdatedBy) {
		Optional<UserAreaEntity> userAreaEntity = userAreaRepository.findById(globalUserAreaId);

		if (!userAreaEntity.isPresent())
			throw new ResourceNotFoundException(USERAREA, "id", globalUserAreaId);

		if (!userAreaEntity.get().getIsActive())
			throw new BusinessException("userArea is already in deactivated state");

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		userAreaEntity.get().setLastUpdatedBy(lastUpdatedBy);
		userAreaEntity.get().setLastUpdatedDate(new Timestamp(new Date().getTime()));
		userAreaEntity.get().setIsActive(Boolean.FALSE);
		userAreaRepository.save(userAreaEntity.get());

	}

	@Override
	public void activateUserArea(Integer globalUserAreaId, String lastUpdatedBy) {
		Optional<UserAreaEntity> userAreaEntity = userAreaRepository.findById(globalUserAreaId);

		if (!userAreaEntity.isPresent())
			throw new ResourceNotFoundException(USERAREA, "id", globalUserAreaId);

		if (userAreaEntity.get().getIsActive())
			throw new BusinessException("userArea is already in active state");

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		userAreaEntity.get().setLastUpdatedBy(lastUpdatedBy);
		userAreaEntity.get().setLastUpdatedDate(new Timestamp(new Date().getTime()));
		userAreaEntity.get().setIsActive(Boolean.TRUE);
		userAreaRepository.save(userAreaEntity.get());

	}

	List<String> typeValueList = new ArrayList<>();

	private StringBuilder userGeoList(List<Geo> l, StringBuilder geoString, boolean flag) {

		for (Geo geo : l) {

			if (geo.getGeoTypeId() == null)
				throw new BusinessException("GeoTypeId should be 1,2,3 or 5 ");
			if (geo.getGeoTypeId() == 1 || geo.getGeoTypeId() == 2 || geo.getGeoTypeId() == 3
					|| geo.getGeoTypeId() == 5) {

				if (geo.getGeoTypeId() == 1
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"Value Length: For  Airport/City Code Element length should be 3 only - User Defined Area");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(
								"This field GeoTypeValue " + geo.getGeoTypeValue() + " cannot be blank");
					}
					if (!airportService.isValidAirportCodeOrCityCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value" + geo.getGeoTypeValue().toUpperCase());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 2
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 2) {
							typeValueList.clear();
							throw new BusinessException(
									"Value Length: For  Country Code Element length should be 2 only - User Defined Area");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					try {
						countryService.getCountryByCountryCode(geo.getGeoTypeValue().toUpperCase());
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException(
								"Invalid Geo Type Value. Country Code : " + geo.getGeoTypeValue().toUpperCase());
					} catch (ServiceException se) {
						typeValueList.clear();
						throw new BusinessException(
								"Invalid Geo Type Value. Country Code :" + geo.getGeoTypeValue().toUpperCase());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 3
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (flag) {
						typeValueList.clear();
						throw new BusinessException("Geo Type Id 3 is not applicable for excludeGeoList");
					}
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"Value Length: For  StandardAreaCode Element length should be 3 only - User Defined Area");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					try {
						if (!standardAreaSrevice.isValidateStandardArea(geo.getGeoTypeValue().toUpperCase())) {
							typeValueList.clear();
							throw new BusinessException(
									"Invalid Geo Type Value. standardArea Code :" + geo.getGeoTypeValue().toUpperCase());
						}
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException(
								"Invalid Geo Type Value. standardArea Code : " + geo.getGeoTypeValue().toUpperCase());
					} catch (BusinessException se) {
						typeValueList.clear();
						throw new BusinessException(
								"Invalid Geo Type Value. standardArea Code :" + geo.getGeoTypeValue().toUpperCase());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 5
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 4) {
							typeValueList.clear();
							throw new BusinessException(
									"Value Length: For  State Code Element length should be 4 only - User Defined Area");
						}
					} else {
						typeValueList.clear();
						throw new ServiceException(MANDATORYGEOTYPEVALUE);
					}
					if (!airportService.isValidStateCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException(
								"Invalid Geo Type Value. State Code : " + geo.getGeoTypeValue().toUpperCase());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					typeValueList.clear();
					throw new BusinessException(geo.getGeoTypeValue().toUpperCase() + "Record already exists");
				}

			} else {
				typeValueList.clear();
				throw new BusinessException("Invalid Geo type id :" + geo.getGeoTypeId());
			}

		}
		if (geoString.length() > 1000) {
			typeValueList.clear();
			throw new BusinessException(
					"area_include_list or area_exclude_list length must be less than 1000 charecters");
		}
		if (geoString.length() != 0) {
			geoString.delete(geoString.length() - 1, geoString.length());
		}

		return geoString;

	}

	@Override
	public Boolean isValidateAreaCode(String areaCode) {
		List<UserAreaEntity> userAreaEntity = userAreaRepository.findByUserAreaCode(areaCode);
		if (userAreaEntity.size() > 0) {
			return true;
		}
		return false;
	}

	@Override
	public void clientSpecificUserAreaInsertOrUpdate(Map<String, String> map) {
		String userAreaCode = "";
		String areaKey1 = "";
		String areaKey2 = "";
		String areaKey3 = "";
		String areaKey4 = "";
		String areaFromInclude = "";
		String areaViaInclude = null;
		String areaToInclude = null;
		Boolean flag = false;
		GlobalUserArea globalUserArea = new GlobalUserArea();

		for (Map.Entry<String, String> m : map.entrySet()) {
			if (m.getKey().equals("userToArea") && m.getValue() != null) {
				globalUserArea.setUserAreaCode(m.getValue());
				userAreaCode = m.getValue();
			} else if (m.getKey().equals("userViaArea") && m.getValue() != null) {
				globalUserArea.setUserAreaCode(m.getValue());
				userAreaCode = m.getValue();
			} else if (m.getKey().equals("userFromArea") && m.getValue() != null) {
				globalUserArea.setUserAreaCode(m.getValue());
				userAreaCode = m.getValue();
			} else if (m.getKey().equals("areaKey1")) {
				globalUserArea.setAreaKey1(m.getValue());
				areaKey1 = m.getValue();
			} else if (m.getKey().equals("areaKey2")) {
				globalUserArea.setAreaKey2(m.getValue());
				areaKey2 = m.getValue();
			} else if (m.getKey().equals("areaKey3")) {
				globalUserArea.setAreaKey3(m.getValue());
				areaKey3 = m.getValue();
			} else if (m.getKey().equals("areaKey4")) {
				globalUserArea.setAreaKey4(m.getValue());
				areaKey4 = m.getValue();
			} else if (m.getKey().equals("areaFromInclude")) {
				globalUserArea.setAreaIncludeList(m.getValue());
				areaFromInclude = m.getValue();
			} else if (m.getKey().equals("areaFromExclude")) {
				globalUserArea.setAreaExcludeList(m.getValue());
			} else if (m.getKey().equals("createdBy")) {
				globalUserArea.setCreatedBy(m.getValue());
			} else if (m.getKey().equals("areaViaInclude")) {
				globalUserArea.setAreaIncludeList(m.getValue());
				areaViaInclude = m.getValue();
			} else if (m.getKey().equals("areaViaExclude")) {
				globalUserArea.setAreaExcludeList(m.getValue());
			} else if (m.getKey().equals("areaToInclude")) {
				globalUserArea.setAreaIncludeList(m.getValue());
				areaToInclude = m.getValue();
			} else if (m.getKey().equals("areaToExclude")) {
				globalUserArea.setAreaExcludeList(m.getValue());
			} else if (m.getKey().equals("updateFlag")) {
				String flagSet = m.getValue();
				flag = Boolean.valueOf(flagSet);
			} else if (m.getKey().equals("userFromAreaName")) {
				if (m.getValue() != null)
					globalUserArea.setUserAreaName(m.getValue());
			} else if (m.getKey().equals("createdBy")) {
				globalUserArea.setCreatedBy(m.getValue());
			} else if (m.getKey().equals("lastUpdatedBy")) {
				globalUserArea.setLastUpdatedBy(m.getValue());
			} else if (m.getKey().equals("lastUpdatedDate")) {
				globalUserArea.setLastUpdatedDate(new Timestamp(new Date().getTime()));
			} else if (m.getKey().equals("userViaAreaName")) {
				if (m.getValue() != null)
					globalUserArea.setUserAreaName(m.getValue());
			} else if (m.getKey().equals("userToAreaName")) {
				if (m.getValue() != null)
					globalUserArea.setUserAreaName(m.getValue());
			}
		}
		UserAreaEntity userAreaEntity = null;
		if (!flag) {
			if (areaToInclude == null) {
				userAreaEntity = userAreaRepository.getUniqueRecord(userAreaCode, areaKey1, areaKey2, areaKey3,
						areaKey4);
			} else {
				userAreaEntity = userAreaRepository.getUniqueRecord(userAreaCode, areaKey1, areaKey2, areaKey3,
						areaKey4);
			}
			if (userAreaEntity != null) {
				throw new BusinessException(USERAREAALREADYEXIST);
			}
			globalUserArea.setIsActive(Boolean.TRUE);
			globalUserArea.setCreatedDate(new Timestamp(new Date().getTime()));

			userAreaMapper
					.mapToUserAreaModel(userAreaRepository.save(userAreaMapper.mapToUserAreaEntity(globalUserArea)));
		} else {
			UserAreaEntity userAreaEntityUpdated = null;
			if (areaToInclude == null) {
				userAreaEntityUpdated = userAreaRepository.getUniqueRecord(
						userAreaCode.substring(1, userAreaCode.length()), areaKey1, areaKey2, areaKey3, areaKey4);
			} else {
				userAreaEntityUpdated = userAreaRepository.getUniqueRecord(
						userAreaCode.substring(1, userAreaCode.length()), areaKey1, areaKey2, areaKey3, areaKey4);
			}
			if (userAreaEntityUpdated == null) {
				throw new BusinessException("Record not found");
			}
			userAreaEntityUpdated.setUserAreaCode(userAreaCode.substring(1, userAreaCode.length()));
			userAreaEntityUpdated.setAreaKey1(areaKey1);
			userAreaEntityUpdated.setAreaKey2(areaKey2);
			userAreaEntityUpdated.setAreaKey3(areaKey3);
			userAreaEntityUpdated.setAreaKey4(areaKey4);
			for (Map.Entry<String, String> m : map.entrySet()) {
				if (m.getKey().equals("areaFromInclude")) {
					userAreaEntityUpdated.setAreaIncludeList(m.getValue());
				} else if (m.getKey().equals("areaFromExclude")) {
					userAreaEntityUpdated.setAreaExcludeList(m.getValue());
				} else if (m.getKey().equals("areaToInclude")) {
					userAreaEntityUpdated.setAreaIncludeList(m.getValue());
				} else if (m.getKey().equals("areaToExclude")) {
					userAreaEntityUpdated.setAreaExcludeList(m.getValue());
				} else if (m.getKey().equals("lastUpdatedBy")) {
					userAreaEntityUpdated.setLastUpdatedBy(m.getValue());
				} else if (m.getKey().equals("userFromAreaName")) {
					if (m.getValue() != null)
						userAreaEntityUpdated.setUserAreaName(m.getValue());
				} else if (m.getKey().equals("userToAreaName")) {
					if (m.getValue() != null)
						userAreaEntityUpdated.setUserAreaName(m.getValue());
				}
			}
			userAreaEntityUpdated.setLastUpdatedDate(new Timestamp(new Date().getTime()));
			userAreaEntityUpdated.setIsActive(Boolean.TRUE);
			userAreaRepository.save(userAreaEntityUpdated);

		}
	}

	@Override
	public void deleteUserArea(String areaKey1, String areaKey2, String areaKey3) {
		userAreaRepository.deleteUserArea(areaKey1, areaKey2, areaKey3);
	}

	@Override
	public GlobalUserArea getUserAreaBasedOnKeys(String userAreaCode, String areaKey1, String areaKey2, String areaKey3,
			String areaKey4) {
		List<SearchCriteria> params = new ArrayList<>();

		// fetch only active records
		params.add(new SearchCriteria("isActive", "=", new Boolean("true")));

		if (userAreaCode != null && userAreaCode.length() > 0) {
			params.add(new SearchCriteria("userAreaCode", "=", userAreaCode));
		}

		if (areaKey1 != null && areaKey1.length() > 0) {
			params.add(new SearchCriteria("areaKey1", "=", areaKey1));
		}

		if (areaKey2 != null && areaKey2.length() > 0) {
			params.add(new SearchCriteria("areaKey2", "=", areaKey2));
		}

		if (areaKey3 != null && areaKey3.length() > 0) {
			params.add(new SearchCriteria("areaKey3", "=", areaKey3));
		}

		if (areaKey4 != null && areaKey4.length() > 0) {
			params.add(new SearchCriteria("areaKey4", "=", areaKey4));
		}

		List<GlobalUserArea> globalUserArea = userAreaMapper
				.mapToUserAreaModelList(userAreaDao.search(params, new UserAreaEntity()));

		if (globalUserArea == null || globalUserArea.isEmpty()) {
			return new GlobalUserArea();
		} else {
			return globalUserArea.get(0);
		}
	}

}
