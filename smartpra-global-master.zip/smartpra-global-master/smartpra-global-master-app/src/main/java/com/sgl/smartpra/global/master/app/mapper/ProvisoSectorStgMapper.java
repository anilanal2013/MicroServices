package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorStgEntity;
import com.sgl.smartpra.global.master.model.ProvisoSectorStgModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoSectorStgMapper extends BaseMapper<ProvisoSectorStgModel, ProvisoSectorStgEntity> {
	ProvisoSectorStgEntity mapToEntity(ProvisoSectorStgModel provisoSectorStgModel,
			@MappingTarget ProvisoSectorStgEntity provisoSectorStgEntity);

	@Mapping(source = "provisoSectorId", target = "provisoSectorId", ignore = true)
	ProvisoSectorStgEntity mapToEntity(ProvisoSectorStgModel provisoSectorStgModel);
}
