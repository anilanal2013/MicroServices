package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareStgEntity;

@Repository
public interface ProvisoCodeshareStgDao {
	ProvisoCodeshareStgEntity create(ProvisoCodeshareStgEntity provisoCodeshareStgEntity);

	ProvisoCodeshareStgEntity update(ProvisoCodeshareStgEntity provisoCodeshareStgEntity);

	List<ProvisoCodeshareStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> provisoSection, Optional<String> areaFrom, Optional<String> areaTo);

	List<ProvisoCodeshareStgEntity> searchByProvisoMain(Optional<Integer> provisoMainId, Optional<String> areaFrom,
			Optional<String> areaTo);

	Optional<ProvisoCodeshareStgEntity> findById(Integer provisoCodeshareId);

	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, String provisoSection,
			String areaFrom, String areaTo);

	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, String provisoSection,
			String areaFrom, String areaTo, Integer provisoCodeshareId);

	List<ProvisoCodeshareStgEntity> findByMainId(Optional<Integer> provisoMainId);

	public List<Integer> getListOfProvisoMainIdFromCodeshareStgDb();

	void deleteProvisoCodehareByProvisoMainId(Integer provisoMainId);

	void deleteProvisoCodehareByProvisoCodeshareId(Integer provisoCodeshareId);

	public Integer getMaxOfCodeshareRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);
}
