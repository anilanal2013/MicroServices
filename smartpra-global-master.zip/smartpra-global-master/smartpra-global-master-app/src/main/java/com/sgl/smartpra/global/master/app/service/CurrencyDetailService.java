package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.sgl.smartpra.global.master.model.CurrencyDetail;

public interface CurrencyDetailService {

	CurrencyDetail createCurrencyDetail(String currencyCode, @Valid CurrencyDetail currencyDetails);

	List<CurrencyDetail> getAllCurrencyDetails(String currencyCode, Optional<String> effectiveDate);

	CurrencyDetail getCurrencyDetailByCurrencyDetailCode(String currencyCode, int currencyDetailId);

	CurrencyDetail updateCurrencyDetail(String currencyCode, int currencyDetailId,
			@Valid CurrencyDetail currencyDetail);

	void deleteCurrencyDetail(String currencyCode, int currencyDetailId);

	CurrencyDetail getCurrencyByCurrencyCodeAndEffectiveDate(String currencyCode, Optional<String> effectiveDate);

}
