package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.factory.Mappers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperFactory {

	@Bean
	public StandardAreaDetailMapper getStandardAreaDetailMapper() {
		return Mappers.getMapper(StandardAreaDetailMapper.class);
	}

	@Bean
	public StandardAreaGeographyTypeMapper getStandardAreaGeographyTypeMapper() {
		return Mappers.getMapper(StandardAreaGeographyTypeMapper.class);
	}

	@Bean
	public UserAreaMapper getUserAreaMapper() {
		return Mappers.getMapper(UserAreaMapper.class);
	}

	@Bean
	public UOMMapper getUOMMapper() {
		return Mappers.getMapper(UOMMapper.class);
	}

}