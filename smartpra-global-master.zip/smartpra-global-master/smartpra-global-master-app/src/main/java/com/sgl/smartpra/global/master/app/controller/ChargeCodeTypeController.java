package com.sgl.smartpra.global.master.app.controller;

import com.sgl.smartpra.global.master.app.service.ChargeCodeTypeService;
import com.sgl.smartpra.global.master.model.ChargeCodeType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
public class ChargeCodeTypeController {
	
	@Autowired
	ChargeCodeTypeService chargeCodeTypService;
	
	@GetMapping("/chargeCodeType")
	public List<ChargeCodeType> getAllChargeCodeTypeByCodeandCat(
			@RequestParam(value = "chargeCode" , required = false) Optional<String> chargeCode,
			@RequestParam(value = "chargeCatCode" , required = false) Optional<String> chargeCatCode
			){
		
		return chargeCodeTypService.getAllChargeCodeTypeByCodeandCat(chargeCode,chargeCatCode);
	}
	
	@GetMapping("/chargeCodeType/{chargeCodeTypeId}")
	public ChargeCodeType getAllChargeCodeTypeById(
			@Valid @PathVariable(value = "chargeCodeTypeId") Integer id
			){
		
		return chargeCodeTypService.getChargeCodeById(id);
	}

	@GetMapping("/chargeCodeType/{chargeCodeCategory}/{chargeCode}/{chargeCodeType}")
	public ChargeCodeType getAllChargeCodeTypeByChargeCodeType(
			@Valid @PathVariable(value = "chargeCodeCategory") Optional<String> chargeCodeCategory,
			@Valid @PathVariable(value = "chargeCode") Optional<String> chargeCode,
			@Valid @PathVariable(value = "chargeCodeType") Optional<String> chargeType
	){

		return chargeCodeTypService.getChargeCodeTypeByChargeCatAndChargeCodeAndChargeCodeType(chargeCodeCategory,
				chargeCode,chargeType);
	}
}
