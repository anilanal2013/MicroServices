package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.MPRDao;
import com.sgl.smartpra.global.master.app.dao.entity.spec.MPREntitySpecification;
import com.sgl.smartpra.global.master.app.repository.MPRRepository;
import com.sgl.smartpra.global.master.app.repository.entity.MPREntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MPRDaoImpl<T> extends CommonSearchDao<T> implements MPRDao {

	@Autowired
	private MPRRepository mprRepository;

	@Override
	@Cacheable(value = "mpr", key = "#minimumProrateRuleId")
	public Optional<MPREntity> findById(Integer minimumProrateRuleId) {
		log.info("Cacheable mpr Entity's ID= {}", minimumProrateRuleId);
		return mprRepository.findById(minimumProrateRuleId);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "mpr", key = "#mprEntity.minimumProrateRuleId"),
			@CacheEvict(value = "mprSearch", allEntries = true) })
	public MPREntity create(MPREntity mprEntity) {
		return mprRepository.save(mprEntity);
	}

	@Override
	@CachePut(value = "mpr", key = "#mprEntity.minimumProrateRuleId")
	@CacheEvict(value = "mprSearch", allEntries = true)
	public MPREntity update(MPREntity mprEntity) {
		return mprRepository.save(mprEntity);
	}

	/*
	 * @Override public List<MPREntity> getMprDetails(Optional<String>
	 * effectiveDate) { return
	 * mprRepository.findAll(MPREntitySpecification.getMprDetails(effectiveDate)); }
	 */
	
	@Override
	public Optional<MPREntity> getMprDetails(Optional<String> effectiveDate) {
		return mprRepository.findOne(Specification.where(MPREntitySpecification.getMprDetails(effectiveDate)).and(MPREntitySpecification.isActive()));
	}

	@Override
	public List<MPREntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return mprRepository.findAll((MPREntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(MPREntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.and(MPREntitySpecification.isActive())));
	}

	@Override
	public List<MPREntity> getMPR(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate) {
		return mprRepository.findAll(MPREntitySpecification.getMPR(effectiveFromDate, effectiveToDate, activate));
	}

}
