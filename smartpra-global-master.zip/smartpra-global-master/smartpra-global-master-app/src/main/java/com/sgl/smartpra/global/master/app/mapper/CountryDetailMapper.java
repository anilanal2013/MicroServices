package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.CountryDetailEntity;
import com.sgl.smartpra.global.master.model.CountryDetail;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CountryDetailMapper extends BaseMapper<CountryDetail, CountryDetailEntity>{

	CountryDetailEntity mapToEntity(CountryDetail countryDetail, @MappingTarget CountryDetailEntity countryDetailEntity);

	CountryDetailEntity mapToEntity(CountryDetail countryDetail);
}
