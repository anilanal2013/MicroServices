package com.sgl.smartpra.global.master.app.repository.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.global.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_misc_charge_code")
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicInsert
@DynamicUpdate
public class ChargeCodeEntity extends BaseEntity {
	@Id
	@Column(name = "charge_code", nullable = false, length = 6)
	private String chargeCode;

	@Column(name = "charge_code_name", nullable = false, length = 100)
	private String chargeCodeName;

	@Column(name = "charge_cat_code", nullable = false, length = 3)
	private String chargeCategoryCode;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "cost_center_code")
	private String costCenterCode;

	@Column(name = "profit_centre")
	private String profitCentre;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@Column(name = "charge_code_typ_req_ind", nullable = false)
	private Boolean chargeCodeTypeRequiredIndicator = Boolean.FALSE;

	@Column(name = "location_req_ind", nullable = false)
	private Boolean locationCodeRequiredIndicator = Boolean.FALSE;

	@Column(name = "po_req_ind")
	private Boolean poLineItemRequiredIndicator = Boolean.FALSE;

	@Column(name = "product_id_req_ind")
	private Boolean productIdRequiredIndicator = Boolean.FALSE;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
		
	}
}
