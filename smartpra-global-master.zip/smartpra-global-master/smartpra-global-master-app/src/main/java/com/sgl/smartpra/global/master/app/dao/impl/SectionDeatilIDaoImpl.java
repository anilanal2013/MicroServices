package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.SectionDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.SectionDetailEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.SectionDetailEntitySpecfication;
import com.sgl.smartpra.global.master.app.dao.repository.SectionDetailRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SectionDeatilIDaoImpl implements SectionDetailDao {
	
	@Autowired
	private SectionDetailRepository sectionDetailRepository;

	@Override
	@Cacheable(value = "sectionDetailEntity", key = "#sectionDeatilId")
	public Optional<SectionDetailEntity> findById(Integer sectionDeatilId) {
		return sectionDetailRepository.findById(sectionDeatilId);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "sectionDetailEntity", key = "#sectionDetailEntity.sectionDeatilId") })
	public SectionDetailEntity create(SectionDetailEntity sectionDetailEntity) {
		return sectionDetailRepository.save(sectionDetailEntity);
	}

	@Override
	@CachePut(value = "sectionDetailEntity", key = "#sectionDetailEntity.sectionDeatilId")
	public SectionDetailEntity update(SectionDetailEntity sectionDetailEntity) {
		return sectionDetailRepository.save(sectionDetailEntity);
	}
	
	@Override
	public List<SectionDetailEntity> update(List<SectionDetailEntity> sectionDetailEntitys){
		return sectionDetailRepository.saveAll(sectionDetailEntitys);
	}

	@Override
	public List<SectionDetailEntity> findAll(Integer sectionMasterId, Integer sectionDetailId,
			Optional<String> sectionElementName, Optional<Boolean> activate) {
		return sectionDetailRepository.findAll(SectionDetailEntitySpecfication.search(sectionMasterId, sectionDetailId, sectionElementName, activate));
	}

	@Override
	public List<SectionDetailEntity> getByOrderNumber(Optional<String> orderNumber) {
		return sectionDetailRepository.findAll(SectionDetailEntitySpecfication.getOrderNumber(orderNumber));
	}

	@Override
	public List<SectionDetailEntity> getByDisplayOrderNumber(Integer sectionMasterId, Integer sectionDetailId, Optional<String> displayOrderNumber) {
		return sectionDetailRepository.findAll(SectionDetailEntitySpecfication.getByDisplayOrderNumber(sectionMasterId, sectionDetailId, displayOrderNumber));
	}
	
	@Override
	public List<SectionDetailEntity> getListOfSectionDetailsByChargeCode(List<Integer> sections, Optional<String> sectionElementName, Optional<Boolean> activate){
		return sectionDetailRepository.findAll(SectionDetailEntitySpecfication.getListOfSectionDetailsByChargeCode(sections, sectionElementName, activate));
	}
	
}
