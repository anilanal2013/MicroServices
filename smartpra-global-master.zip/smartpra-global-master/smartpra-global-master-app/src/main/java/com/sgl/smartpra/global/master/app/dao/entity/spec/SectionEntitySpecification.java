package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.SectionEntity;

public final class SectionEntitySpecification {

	public static Specification<SectionEntity> search(Optional<String> chargeCode, Optional<String> sectionCode,
			Optional<String> sectionName, Optional<Boolean> activate) {

		return (sectionEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(sectionCode)) {
				predicates.add(criteriaBuilder.like(sectionEntity.get("sectionCode"),
						OptionalUtil.getValue(sectionCode) + "%"));
			}
			if (OptionalUtil.isPresent(sectionName)) {
				predicates.add(criteriaBuilder.like(sectionEntity.get("sectionName"),
						OptionalUtil.getValue(sectionName) + "%"));
			}

			if (OptionalUtil.isPresent(chargeCode)) {
				predicates.add(
						criteriaBuilder.like(sectionEntity.get("chargeCode"), OptionalUtil.getValue(chargeCode) + "%"));
			}

			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(sectionEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
