package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.global.master.app.service.ProvisoMainService;
import com.sgl.smartpra.global.master.model.ProvisoMainModel;

@RestController
@RequestMapping("/proviso/main")
public class ProvisoMainController {
	@Autowired
	ProvisoMainService provisoMainService;
	
	@GetMapping("/{provisoMainId}")
	public ProvisoMainModel getProvisoMainByprovisoMainId(
			@PathVariable(value = "provisoMainId") Integer provisoMainId) {
		return provisoMainService.getProvisoMainByprovisoMainId(provisoMainId);
	}

	@GetMapping("/search")
	public List<ProvisoMainModel> search(
			@RequestParam(name = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@RequestParam(name = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(name = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(name = "provisoSection", required = false) Optional<String> provisoSection,
			@RequestParam(name = "provisoStatus", required = false) Optional<String> provisoStatus) {
		return provisoMainService.search(carrierNumCode, effectiveFromDate, effectiveToDate, provisoSection,provisoStatus);
	}

	@GetMapping("/provisomainlist")
	public List<ProvisoMainModel> getProvisoMainList(
			@RequestParam(name = "carrierNumCode", required = false) String carrierNumCode,
			@RequestParam(name = "effectiveDate", required = false)  String effectiveDate){
		return provisoMainService.getProvisoMainList(carrierNumCode,effectiveDate);
	}
	
	
}
