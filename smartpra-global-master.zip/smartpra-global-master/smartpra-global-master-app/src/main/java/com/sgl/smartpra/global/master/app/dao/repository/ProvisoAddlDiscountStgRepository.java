package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountStgEntity;
@Repository
public interface ProvisoAddlDiscountStgRepository extends JpaRepository<ProvisoAdditionalDiscountStgEntity, Integer>,
		JpaSpecificationExecutor<ProvisoAdditionalDiscountStgEntity> {
	@Query(value = "select pads.provisoMainId from ProvisoAdditionalDiscountStgEntity pads")
	List<Integer> getListOfProvisoMainIdFromAddlDistcountStgDb();
    
	@Transactional
	@Modifying
	@Query("delete from ProvisoAdditionalDiscountStgEntity padse where padse.provisoMainId= ?1")
	void deleteProvisoAddlDiscountByProvisoMainId(Integer provisoMainId);
	
	@Transactional
	@Modifying
	@Query("delete from ProvisoAdditionalDiscountStgEntity padse where padse.provisoMainId= ?1 AND padse.carrierNumCode=?2 AND padse.provisoSeqNumber=?3")
	void deleteProvisoAddlDiscountStgFromDb(Integer provisoMainId, String carrierNumCode, Integer provisoSeqNumber);
	
}
