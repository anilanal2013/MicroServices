package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.global.master.app.repository.entity.DictionaryValueEntity;

public class DictionaryValueEntitySpecification {

	public static Specification<DictionaryValueEntity> search(Integer dictionaryId) {
		return (dictionaryValueEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			predicates.add(
					criteriaBuilder.equal(dictionaryValueEntity.get("dictionaryId"), dictionaryId));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
