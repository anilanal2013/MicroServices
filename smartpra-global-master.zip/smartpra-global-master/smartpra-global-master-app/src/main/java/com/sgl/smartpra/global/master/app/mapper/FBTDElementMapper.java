package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.repository.entity.FBTDElementEntity;
import com.sgl.smartpra.global.master.model.FBTDElement;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FBTDElementMapper extends BaseMapper<FBTDElement, FBTDElementEntity> {
	
	FBTDElementEntity mapToEntity(FBTDElement fbtdElement, @MappingTarget FBTDElementEntity fbtdElementEntity);

	@Mapping(source = "fbtdId", target = "fbtdId", ignore = true)
	FBTDElementEntity mapToEntity(FBTDElement fbtdElement);
}