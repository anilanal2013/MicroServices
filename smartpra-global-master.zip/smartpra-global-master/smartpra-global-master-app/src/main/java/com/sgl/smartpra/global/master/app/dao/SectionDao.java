package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.SectionEntity;
import com.sgl.smartpra.global.master.model.SectionDto;


@Repository
public interface SectionDao  {
	
	public Optional<SectionEntity> findById(Integer id);

	public SectionEntity create(SectionEntity sectionEntity);

	public SectionEntity update(SectionEntity sectionEntity);
	
	public List<SectionEntity> update(List<SectionEntity> sectionEntity);
	
	public Optional<SectionEntity> findOne(Integer id);

	public List<SectionEntity> findAll( Optional<String> chargeCode,Optional<String> sectionCode, Optional<String> sectionName,Optional<Boolean> activate);
	
	public List<SectionDto> fetchSectionByChargeCode(String chargeCode, String currentBillingPeriod);
}
