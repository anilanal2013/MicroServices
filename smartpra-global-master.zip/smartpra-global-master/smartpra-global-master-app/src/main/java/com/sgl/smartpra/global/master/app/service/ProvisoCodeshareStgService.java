package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoCodeshareStgModel;

public interface ProvisoCodeshareStgService {
	public ProvisoCodeshareStgModel createProvisoCodeshare(ProvisoCodeshareStgModel provisoCodeshareStgModel);

	public ProvisoCodeshareStgModel updateProvisoCodeshare(Integer provisoCodeshareId,
			ProvisoCodeshareStgModel provisoCodeshareStgModel);

	public List<ProvisoCodeshareStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> provisoSection, Optional<String> areaFrom, Optional<String> areaTo);

	public List<ProvisoCodeshareStgModel> searchByProvisoMain(Optional<Integer> provisoMainId,
			Optional<String> areaFrom, Optional<String> areaTo);

	public ProvisoCodeshareStgModel getProvisoCodeshareByProvisoCodeshareId(Integer provisioCodeshareId);

	public List<ProvisoCodeshareStgModel> getProvisoCodeshareByProvisoMainId(Optional<Integer> provisoMainId);

	public void deleteProvisoCodehareByProvisoMainId(Integer provisoMainId);

	public void deleteProvisoCodehareByProvisoCodeshareId(Integer provisoCodeshareId);
}
