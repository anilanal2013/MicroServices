package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.CarrierEntity;

public interface CarrierDao {

	public Optional<CarrierEntity> findById(String carrierCode);

	public CarrierEntity create(CarrierEntity carrierEntity);

	public CarrierEntity update(CarrierEntity carrierEntity);

	public List<CarrierEntity> findAll(Optional<String> carrierCode, Optional<String> carrierDesignatorCode,
			Optional<String> carrierName1, Optional<String> carrierName2, Optional<Boolean> isActive,Optional<String> exceptionCall);

	public List<CarrierEntity> findDistinctByCarrierCodeIsNotNullAndIsActiveTrueOrderByCarrierCode();

	public Optional<CarrierEntity> getCarrierByCarrierDesignatorCode(String carrierDesignatorCode);

	public Optional<CarrierEntity> getCarrierByCarrierCode(String carrierCode);
	
	public List<CarrierEntity> isValidCarrierDesignatorCodeList(String carrierDesignatorCode);
}