package com.sgl.smartpra.global.master.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.sgl.smartpra.global.master.app.repository.entity.ChargeCodeEntity;

public interface ChargeCodeRepository
		extends JpaRepository<ChargeCodeEntity, String>, JpaSpecificationExecutor<ChargeCodeEntity> {

	@Query(value = "select distinct(chargeCode) from ChargeCodeEntity where activate='Y'")
	List<String> getChargeCodeFromChargeCodeMaster();
}
