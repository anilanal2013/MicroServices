package com.sgl.smartpra.global.master.app.repository.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "global_mas_std_area_dtl")
public class StandardAreaDetailEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "std_area_dtl_id", nullable = false)
	private Integer standardAreaDetailId;

	@Column(name = "std_area_code", nullable = false, length = 4)
	private String standardAreaCode;

	@Column(name = "geo_type_id", nullable = false, length = 3)
	private Integer geographicalTypeId;

	@Column(name = "std_area_value", nullable = false, length = 6)
	private String standardAreaValue;

	@Column(name = "created_by", nullable = false, length = 15)
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;

	@Column(name = "last_updated_by", nullable = true, length = 15)
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	public Integer getStandardAreaDetailId() {
		return standardAreaDetailId;
	}

	public void setStandardAreaDetailId(Integer standardAreaDetailId) {
		this.standardAreaDetailId = standardAreaDetailId;
	}

	public String getStandardAreaCode() {
		return standardAreaCode;
	}

	public void setStandardAreaCode(String standardAreaCode) {
		this.standardAreaCode = standardAreaCode;
	}

	public Integer getGeographicalTypeId() {
		return geographicalTypeId;
	}

	public void setGeographicalTypeId(Integer geographicalTypeId) {
		this.geographicalTypeId = geographicalTypeId;
	}

	public String getStandardAreaValue() {
		return standardAreaValue;
	}

	public void setStandardAreaValue(String standardAreaValue) {
		this.standardAreaValue = standardAreaValue;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
