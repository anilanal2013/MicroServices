package com.sgl.smartpra.global.master.app.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.global.master.app.dao.DictionaryValueDao;
import com.sgl.smartpra.global.master.app.mapper.DictionaryValueMapper;
import com.sgl.smartpra.global.master.app.service.DictionaryValueService;
import com.sgl.smartpra.global.master.model.DictionaryValue;

@Service
@Transactional
public class DictionaryVaueServiceImpl implements DictionaryValueService {

	@Autowired
	DictionaryValueMapper dictionaryValueMapper;
	
	@Autowired
	DictionaryValueDao dictionaryValueDao;
	
	
	@Override
	public List<DictionaryValue> fetchAllDictionaryById(Integer dictionaryId) {
		return dictionaryValueMapper.mapToModel(dictionaryValueDao.getDictionaryValueByDictionaryId(dictionaryId));
	}
	
	
}
