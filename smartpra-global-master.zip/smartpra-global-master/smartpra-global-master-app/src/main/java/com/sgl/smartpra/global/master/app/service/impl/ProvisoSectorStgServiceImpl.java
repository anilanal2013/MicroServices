package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.ProvisoMainStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoSectorStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorStgEntity;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.ProvisoSectorStgMapper;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CarrierService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.ProvisoMainStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoSectorStgService;
import com.sgl.smartpra.global.master.app.service.StandardAreaSrevice;
import com.sgl.smartpra.global.master.app.service.UserAreaSrevice;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.Geo;
import com.sgl.smartpra.global.master.model.ProvisoSectorStgModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoSectorStgServiceImpl implements ProvisoSectorStgService {

	public static final String OVERLAP_COMBINATION_EXIST = "Record already exist";
	private static final String AIRPORTCITY = "Only alphabets are allowed for Airport/City";
	private static final String PATTERN = "^[a-zA-Z]*$";
	private static final String AIRPORTCITYINVALID = "Invalid  Airport/City code : ";
	private static final String COUNTRYCODEALPHA = "Only alphabets are allowed for country code";
	private static final String COUNTRYCODEINVALID = "Invalid  country code : ";
	private static final String INVALIDSTDAREACODE = "Invalid  standard area code : ";
	private static final String GLOBAL = "global";
	private static final String FROMAREAINCLUDEMENDATORY = "Please provide AreaFromInclude";
	private static final String STATECODEALPHA = "Only alphabets are allowed for state code";
	private static final String INVALIDSTATECODE = "Invalid state code : ";
	private static final String MANDATORYGEOTYPEVALUE = "Please provide Geo Type Value";
	private static final String DOESNOTEXIST = " Does not exist";
	private static final String ISNOTACTIVE = " is not active";
	
	@Autowired
	private ProvisoSectorStgDao provisoSectorStgDao;
	
	@Autowired
	private ProvisoMainStgDao provisoMainStgDao;
	
	@Autowired
	private ProvisoSectorStgMapper provisoSectorStgMapper;
	
	@Autowired
	private MasterFeignClient masterFeignClient;

	@Autowired
	private CarrierService carrierService;

	@Autowired
	private UserAreaSrevice userAreaSrevice;

	@Autowired
	private AirportService airportService;

	@Autowired
	private CountryService countryService;

	@Autowired
	StandardAreaSrevice standardAreaSrevice;

	@Autowired
	private ProvisoMainStgService provisoMainStgService;

	String clientId = null;
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String AREACHECKFLAG_LOV_COLUMN_VALUE = LOVEnum.AREA_CHECK_FLAG.getLOVEnum();
	private static final String PROVISO_SECTOR_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN = "CarierNumCode of Proviso Sector should be similar to CarierNumCode of Proviso Main Corresponding to Proviso Main Id";
	private static final String SECTOR_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso Sector data not available for selected Proviso Main record";
	
	Boolean getAreaFromFlag = false;
	Boolean getAreaToFlag = false;

	@Override
	@Transactional(rollbackOn = BusinessException.class)
	public ProvisoSectorStgModel createProvisoSector(ProvisoSectorStgModel provisoSectorStgModel) {
		
		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(OptionalUtil.getValue(provisoSectorStgModel.getProvisoMainId()))
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(OptionalUtil.getValue(provisoSectorStgModel.getProvisoMainId()))));
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}
		
		Integer sectionRecNumber = provisoSectorStgDao.getMaxOfProvisoSecRecNumber(provisoSectorStgModel.getCarrierNumCode(),provisoSectorStgModel.getProvisoSeqNumber());
		sectionRecNumber=(sectionRecNumber==null)?Integer.valueOf(1):Integer.valueOf(sectionRecNumber.intValue() + 1);
		provisoSectorStgModel.setSectionRecNumber(Optional.of(sectionRecNumber));

		provisoSectorStgModel.setCreatedDate(LocalDateTime.now());
		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		String areaFromInclude = null;
		String areaFromExclude = null;
		String areaToInclude = null;
		String areaToExclude = null;
		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()))) {
			String[] fromAreaArray = validateArea(provisoSectorStgModel.getAreaFrom(),
					provisoSectorStgModel.getAreaFromInclude(), provisoSectorStgModel.getAreaFromExclude(),
					provisoSectorStgModel.getFromUserAreaName(), GLOBAL);
			areaFromInclude = fromAreaArray[0];
			areaFromExclude = fromAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()))) {
			String[] toAreaArray = validateArea(provisoSectorStgModel.getAreaTo(),
					provisoSectorStgModel.getAreaToInclude(), provisoSectorStgModel.getAreaToExclude(),
					provisoSectorStgModel.getToUserAreaName(), GLOBAL);
			areaToInclude = toAreaArray[0];
			areaToExclude = toAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		boolean fromAreaStandardAreaFlag = false;
		boolean toAreaStandardAreaFlag = false;
		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom())))
			fromAreaStandardAreaFlag = OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo())))
			toAreaStandardAreaFlag = OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()))) {
			provisoSectorStgModel.setAreaFrom(Optional.of(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom())));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()))) {
			provisoSectorStgModel.setAreaTo(Optional.of(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo())));
		}
		validateBusinessConstraintsForCreate(provisoSectorStgModel);
		ProvisoSectorStgModel provisoSectorStgRecord = provisoSectorStgMapper
				.mapToModel(provisoSectorStgDao.create(provisoSectorStgMapper.mapToEntity(provisoSectorStgModel)));
		Boolean updateFlag = false;
		String areaKey1 = "P";
		Carrier carrier = carrierService
				.findCarrierByCarrierCode(OptionalUtil.getValue(provisoSectorStgModel.getCarrierNumCode()));
		String areaKey2 = OptionalUtil.getValue(carrier.getCarrierCode());
		String areaKey3 = provisoSectorStgRecord.getProvisoSectorId().toString();
		String areaKey4 = "GLB";
		Map<String, String> map = new HashMap<>();
		map.put("areaKey1", areaKey1);
		map.put("areaKey2", areaKey2);
		map.put("areaKey3", areaKey3);
		map.put("areaKey4", areaKey4);
		map.put("userFromAreaName", provisoSectorStgModel.getFromUserAreaName());
		map.put("areaFromInclude", areaFromInclude);
		map.put("areaFromExclude", areaFromExclude);
		map.put("createdBy", OptionalUtil.getValue(provisoSectorStgModel.getCreatedBy()));
		if(OptionalUtil.isPresent(provisoSectorStgModel.getAreaFrom())) {
		map.put("userFromArea", OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()).substring(1,
				OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()).length()));
		}
		map.put("updateFlag", updateFlag.toString());

		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom())) && fromAreaStandardAreaFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo())) && toAreaStandardAreaFlag) {
			map.put("areaToInclude", areaToInclude);
			map.put("areaToExclude", areaToExclude);
			map.put("userToAreaName", provisoSectorStgModel.getToUserAreaName());
			map.put("userToArea", OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()).substring(1,
					OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()).length()));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo())) && toAreaStandardAreaFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		updateMainProvisoStatus(provisoMainStgEntity);
		return provisoSectorStgRecord;
	}
	
	@Transactional(rollbackOn = BusinessException.class)
	private void updateMainProvisoStatus(ProvisoMainStgEntity provisoMainStgEntity) {
		provisoMainStgDao.updateProvisoMainStg(provisoMainStgEntity);		
	}

	private void validateBusinessConstraintsForCreate(ProvisoSectorStgModel provisoSectorStgModel) {
		validateOverlapForCreate(provisoSectorStgModel);
		validateCheckAreaToForAreaCheckFlag(provisoSectorStgModel);
		validateCarrierNumCodeByProvisoMainId(provisoSectorStgModel);
	}

	private void validateCarrierNumCodeByProvisoMainId(ProvisoSectorStgModel provisoSectorStsModel) {

		String carrierNumCode = OptionalUtil.getValue((provisoMainStgService
				.getProvisoMainByprovisoMainId(OptionalUtil.getValue(provisoSectorStsModel.getProvisoMainId())))
						.getCarrierNumCode());

		if (!(OptionalUtil.getValue(provisoSectorStsModel.getCarrierNumCode()).equalsIgnoreCase(carrierNumCode))) {
			throw new BusinessException(PROVISO_SECTOR_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN);
		}

	}

	protected void validateCheckAreaToForAreaCheckFlag(ProvisoSectorStgModel provisoSectorStsModel) {
		if (OptionalUtil.isPresent(provisoSectorStsModel.getAreaCheckFlag())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, TABLENAME,
					AREACHECKFLAG_LOV_COLUMN_VALUE);

			if (!(listOfValues.contains(OptionalUtil.getValue(provisoSectorStsModel.getAreaCheckFlag()))) && 
					Objects.nonNull(OptionalUtil.getValue(provisoSectorStsModel.getAreaTo()))) {
					throw new BusinessException("Area To should be Empty");
			}
			if (listOfValues.contains(OptionalUtil.getValue(provisoSectorStsModel.getAreaCheckFlag()))  && 
					Objects.isNull(OptionalUtil.getValue(provisoSectorStsModel.getAreaTo()))
					&& !OptionalUtil.getValue(provisoSectorStsModel.getAreaCheckFlag()).equalsIgnoreCase("W")) {
						throw new BusinessException("Area To should not be Empty");
			} 
			if (OptionalUtil.getValue(provisoSectorStsModel.getAreaCheckFlag()).equalsIgnoreCase("W")
					&& Objects.nonNull(OptionalUtil.getValue(provisoSectorStsModel.getAreaTo()))){
				throw new BusinessException("Area To should be Empty");
			}
				
		}

	}

	private void validateOverlapForCreate(ProvisoSectorStgModel provisoSectorStsModel) {
		if (OptionalUtil.isPresent(provisoSectorStsModel.getCarrierNumCode())
				&& OptionalUtil.isPresent(provisoSectorStsModel.getProvisoSeqNumber())
				&& OptionalUtil.isPresent(provisoSectorStsModel.getSectionRecNumber())) {
			if (provisoSectorStgDao.getOverlapRecordCount(
					OptionalUtil.getValue(provisoSectorStsModel.getCarrierNumCode()),
					OptionalUtil.getValue(provisoSectorStsModel.getProvisoSeqNumber()),
					OptionalUtil.getValue(provisoSectorStsModel.getSectionRecNumber())) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}

	}

	@Override
	public List<ProvisoSectorStgModel> getProvisoSectorByProvisoMainId(Optional<Integer> provisoMainId) {

		List<Integer> provisoMainIdFromDb = provisoSectorStgDao.getListOfProvisoMainIdFromSectorStgDb();
		if (!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))) {
			throw new BusinessException(SECTOR_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		return provisoSectorStgMapper.mapToModel(provisoSectorStgDao.findByMainId(provisoMainId));
	}

	@Override
	public ProvisoSectorStgModel getProvisoSectorByProvisoSectorId(Integer provisoSectorId) {
		return provisoSectorStgMapper.mapToModel(provisoSectorStgDao.findById(provisoSectorId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoSectorId))));
	}

	@Override
	public List<ProvisoSectorStgModel> searchByProvisoInMain(Optional<Integer> provisoMainId,
			Optional<String> areaFrom) {

		return provisoSectorStgMapper.mapToModel(provisoSectorStgDao.searchByProvisoInMain(provisoMainId, areaFrom));
	}

	@Override
	public List<ProvisoSectorStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {

		return provisoSectorStgMapper.mapToModel(provisoSectorStgDao.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	@Transactional(rollbackOn = BusinessException.class)
	public ProvisoSectorStgModel updateProvisoSector(Integer provisoSectorId,
			ProvisoSectorStgModel provisoSectorStgModel) {
		
		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(OptionalUtil.getValue(provisoSectorStgModel.getProvisoMainId()))
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(OptionalUtil.getValue(provisoSectorStgModel.getProvisoMainId()))));
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}

		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		String areaFromInclude = null;
		String areaFromExclude = null;
		String areaToInclude = null;
		String areaToExclude = null;

		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()))) {
			String[] fromAreaArray = validateArea(provisoSectorStgModel.getAreaFrom(),
					provisoSectorStgModel.getAreaFromInclude(), provisoSectorStgModel.getAreaFromExclude(),
					provisoSectorStgModel.getFromUserAreaName(), GLOBAL);
			areaFromInclude = fromAreaArray[0];
			areaFromExclude = fromAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()))) {
			String[] toAreaArray = validateArea(provisoSectorStgModel.getAreaTo(),
					provisoSectorStgModel.getAreaToInclude(), provisoSectorStgModel.getAreaToExclude(),
					provisoSectorStgModel.getToUserAreaName(), GLOBAL);
			areaToInclude = toAreaArray[0];
			areaToExclude = toAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		boolean fromAreaStandardAreaFlag = false;
		boolean toAreaStandardAreaFlag = false;
		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom())))
			fromAreaStandardAreaFlag = OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo())))
			toAreaStandardAreaFlag = OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()))) {
			provisoSectorStgModel.setAreaFrom(Optional.of(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom())));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()))) {
			provisoSectorStgModel.setAreaTo(Optional.of(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo())));
		}

		log.info("{}", provisoSectorStgModel);
		ProvisoSectorStgEntity provisoSectorStgEntity = provisoSectorStgDao.findById(provisoSectorId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoSectorId)));
		validateBusinessConstraintsForUpdate(provisoSectorStgModel, provisoSectorStgEntity);
		provisoSectorStgModel.setLastUpdatedDate(LocalDateTime.now());
		ProvisoSectorStgModel provisoSectorStgUpdatedRecord = provisoSectorStgMapper.mapToModel(provisoSectorStgDao
				.update(provisoSectorStgMapper.mapToEntity(provisoSectorStgModel, provisoSectorStgEntity)));

		Boolean updateFlag = false;
		String areaKey1 = "P";
		Carrier carrier = carrierService
				.findCarrierByCarrierCode(OptionalUtil.getValue(provisoSectorStgModel.getCarrierNumCode()));
		String areaKey2 = OptionalUtil.getValue(carrier.getCarrierCode());
		String areaKey3 = provisoSectorStgUpdatedRecord.getProvisoSectorId().toString();
		String areaKey4 = "GLB";
		Map<String, String> map = new HashMap<>();
		map.put("areaKey1", areaKey1);
		map.put("areaKey2", areaKey2);
		map.put("areaKey3", areaKey3);
		map.put("areaKey4", areaKey4);
		map.put("userFromAreaName", provisoSectorStgModel.getFromUserAreaName());
		map.put("areaFromInclude", areaFromInclude);
		map.put("areaFromExclude", areaFromExclude);
		map.put("createdBy", provisoSectorStgEntity.getCreatedBy());
		if(OptionalUtil.isPresent(provisoSectorStgModel.getAreaFrom())) {
		map.put("userFromArea", OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()).substring(1,
				OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom()).length()));
		}
		map.put("updateFlag", updateFlag.toString());
		map.put("lastUpdatedBy", OptionalUtil.getValue(provisoSectorStgModel.getLastUpdatedBy()));
		provisoSectorStgModel.setLastUpdatedDate(LocalDateTime.now());
		map.put("lastUpdatedDate", provisoSectorStgModel.getLastUpdatedDate().toString());

		userAreaSrevice.deleteUserArea(areaKey1, areaKey2, areaKey3);

		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaFrom())) && fromAreaStandardAreaFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo())) && toAreaStandardAreaFlag) {
			map.put("areaToInclude", areaToInclude);
			map.put("areaToExclude", areaToExclude);
			map.put("userToAreaName", provisoSectorStgModel.getToUserAreaName());
			map.put("userToArea", OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()).substring(1,
					OptionalUtil.getValue(provisoSectorStgModel.getAreaTo()).length()));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoSectorStgModel.getAreaTo())) && toAreaStandardAreaFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		updateMainProvisoStatus(provisoMainStgEntity);
		return provisoSectorStgUpdatedRecord;
	}

	private void validateBusinessConstraintsForUpdate(ProvisoSectorStgModel provisoSectorStgModel,
			ProvisoSectorStgEntity provisoSectorStgEntity) {
		validateOverlapForUpdate(provisoSectorStgModel, provisoSectorStgEntity);
		validateCheckAreaToForAreaCheckFlag(provisoSectorStgModel);
		validateCarrierNumCodeByProvisoMainId(provisoSectorStgModel);
	}

	private void validateOverlapForUpdate(ProvisoSectorStgModel provisoSectorStgModel,
			ProvisoSectorStgEntity provisoSectorStgEntity) {
		String carrierNumCode = getCarrierNumCode(provisoSectorStgModel, provisoSectorStgEntity);
		Integer provisoSeqNumber = getProvisoSeqNumber(provisoSectorStgModel, provisoSectorStgEntity);
		Integer sectionRecNumber = getSectionRecNumber(provisoSectorStgModel, provisoSectorStgEntity);

		if (!carrierNumCode.equalsIgnoreCase(provisoSectorStgEntity.getCarrierNumCode())
				|| !provisoSeqNumber.equals(provisoSectorStgEntity.getProvisoSeqNumber())
				|| !sectionRecNumber.equals(provisoSectorStgEntity.getSectionRecNumber())) {
			if (provisoSectorStgDao.getOverlapRecordCount(carrierNumCode, provisoSeqNumber, sectionRecNumber,
					provisoSectorStgEntity.getProvisoSectorId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private String getCarrierNumCode(ProvisoSectorStgModel provisoSectorStgModel,
			ProvisoSectorStgEntity provisoSectorStgEntity) {
		return OptionalUtil.isPresent(provisoSectorStgModel.getCarrierNumCode())
				? OptionalUtil.getValue(provisoSectorStgModel.getCarrierNumCode())
				: provisoSectorStgEntity.getCarrierNumCode();
	}

	private Integer getProvisoSeqNumber(ProvisoSectorStgModel provisoSectorStgModel,
			ProvisoSectorStgEntity provisoSectorStgEntity) {
		return OptionalUtil.isPresent(provisoSectorStgModel.getProvisoSeqNumber())
				? OptionalUtil.getValue(provisoSectorStgModel.getProvisoSeqNumber())
				: provisoSectorStgEntity.getProvisoSeqNumber();
	}

	private Integer getSectionRecNumber(ProvisoSectorStgModel provisoSectorStgModel,
			ProvisoSectorStgEntity provisoSectorStgEntity) {
		return OptionalUtil.isPresent(provisoSectorStgModel.getSectionRecNumber())
				? OptionalUtil.getValue(provisoSectorStgModel.getSectionRecNumber())
				: provisoSectorStgEntity.getSectionRecNumber();
	}

	@Override
	public List<ProvisoSectorStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> sectionRecNumber) {
		return provisoSectorStgMapper
				.mapToModel(provisoSectorStgDao.search(carrierNumCode, provisoSeqNumber, sectionRecNumber));
	}

	List<String> typeValueList = new ArrayList<>();

	private StringBuilder userGeoList(List<Geo> l, StringBuilder geoString, boolean flag) {
		for (Geo geo : l) {

			if (geo.getGeoTypeId() == null)
				throw new BusinessException("GeoTypeId should be 1,2,3 or 5 ");
			if (geo.getGeoTypeId() == 1 || geo.getGeoTypeId() == 2 || geo.getGeoTypeId() == 3
					|| geo.getGeoTypeId() == 5) {

				if (geo.getGeoTypeId() == 1
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"GeoTypeValue should be maximum of 3 characters for  Airport/City Code");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					if (!airportService.isValidAirportCodeOrCityCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. Airport/City Code : "
								+ geo.getGeoTypeValue().toUpperCase() + "Does not exist or not active");
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 2
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 2) {
							typeValueList.clear();
							throw new BusinessException(
									"GeoTypeValue should be maximum of 2 characters for countryCode");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					try {
						countryService.getCountryByCountryCode(geo.getGeoTypeValue().toUpperCase());
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. Country Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					} catch (BusinessException se) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. Country Code :"
								+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 3
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (flag) {
						typeValueList.clear();
						throw new BusinessException("Geo Type Id 3 is not applicable for excludeGeoList");
					}
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"GeoTypeValue should be maximum of 3 characters for standardAreaCode");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					try {
						if (!standardAreaSrevice.isValidateStandardArea(geo.getGeoTypeValue().toUpperCase())) {
							typeValueList.clear();
							throw new BusinessException("Invalid Geo Type Value. standardArea Code :"
									+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
						}
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. standardArea Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					} catch (BusinessException se) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. standardArea Code :"
								+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 5
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 4) {
							typeValueList.clear();
							throw new BusinessException("GeoTypeValue should be maximum of 4 characters for stateCode");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					if (!airportService.isValidStateCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. State Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST + " or " + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					typeValueList.clear();
					throw new BusinessException("Duplicate Geotype Value: " + geo.getGeoTypeValue().toUpperCase());
				}

			} else {
				typeValueList.clear();
				throw new BusinessException(
						"Invalid Geo type id :" + geo.getGeoTypeId() + " Only 1,2,3,5 are the valid Geo type id ");
			}

		}
		if (geoString.length() > 1000) {
			typeValueList.clear();
			throw new BusinessException(
					"Area include list or Area exclude list length must be less than 1000 charecters");
		}
		if (geoString.length() != 0) {
			geoString.delete(geoString.length() - 1, geoString.length());
		}
		return geoString;

	}

	public String[] validateArea(Optional<String> geoArea, List<Geo> list, List<Geo> list2, String userAreaName,
			String area) {

		String[] array = new String[2];
		String areaInclude = "";
		String areaExclude = "";

		if (OptionalUtil.getValue(geoArea).startsWith("1") || OptionalUtil.getValue(geoArea).startsWith("2")
				|| OptionalUtil.getValue(geoArea).startsWith("3") || OptionalUtil.getValue(geoArea).startsWith("5")) {
			if (list != null || list2 != null || userAreaName != null) {
				throw new BusinessException("For " + OptionalUtil.getValue(geoArea)
						+ " IncludeArea, ExcludeArea and userAreaName not required for non User Defined Area");
			}
		}
		if (OptionalUtil.getValue(geoArea) != null) {
			if (OptionalUtil.getValue(geoArea).startsWith("1")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(AIRPORTCITY);
				} else {
					if (!airportService.isValidAirportCodeOrCityCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(AIRPORTCITYINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("2")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(COUNTRYCODEALPHA);
				} else {
					if (!countryService.isValidCountryCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(COUNTRYCODEINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("3")) {
				if (!standardAreaSrevice.getActiveStandardAreaByStandardAreaCode(
						OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
					throw new BusinessException(INVALIDSTDAREACODE
							+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("4") && area.equals(GLOBAL)) {
				boolean flag = false;
				List<Geo> geoFromAreaInclude = list;
				if (list != null && !list.isEmpty()) {

					if (userAreaName == null) {
						throw new BusinessException("please provide User Area Name");
					}

					StringBuilder geoString = new StringBuilder();
					StringBuilder strareaIncludeList = userGeoList(geoFromAreaInclude, geoString, flag);
					areaInclude = strareaIncludeList.toString();
					if (list2 != null) {
						List<Geo> geoFromAreaExclude = list2;
						StringBuilder geoString1 = new StringBuilder();
						flag = true;
						StringBuilder strAreaExcludeList = userGeoList(geoFromAreaExclude, geoString1, flag);

						areaExclude = strAreaExcludeList.toString();
					}
					array[0] = areaInclude;
					array[1] = areaExclude;

				} else {
					throw new BusinessException(FROMAREAINCLUDEMENDATORY);
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("5")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(STATECODEALPHA);
				} else {
					if (!airportService.isValidStateCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(INVALIDSTATECODE
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			}
		}
		return array;
	}

	@Override
	public void deleteProvisoSectorByProvisoMainId(Integer provisoMainId) {
		List<ProvisoSectorStgEntity> sectorList = provisoSectorStgDao.findByMainId(Optional.of(provisoMainId));
		
		getAreaFromFlag = false;
		getAreaToFlag = false;
		
		if (!sectorList.isEmpty()) {
			sectorList.stream().filter(Objects::nonNull).forEach(sector -> {
				if (Objects.nonNull(sector.getAreaFrom())) {
					getAreaFromFlag = sector.getAreaFrom().startsWith("4");
				}
				if (Objects.nonNull(sector.getAreaTo())) {
					getAreaToFlag = sector.getAreaTo().startsWith("4");
				}
				if (getAreaFromFlag || getAreaToFlag) {
					userAreaSrevice.deleteUserArea("P", sector.getCarrierNumCode(), sector.getProvisoSectorId().toString());
				}
			});
			
		}
		provisoSectorStgDao.deleteProvisoSectorByProvisoMainId(provisoMainId);
	}

	@Override
	public void deleteProvisoSectorByProvisoSectorId(Integer provisoSectorId) {
		ProvisoSectorStgEntity  sectorEntity = provisoSectorStgDao.findById(provisoSectorId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoSectorId)));
		
		getAreaFromFlag = false;
		getAreaToFlag = false;
		
		if (Objects.nonNull(sectorEntity.getAreaFrom())) {
			getAreaFromFlag = sectorEntity.getAreaFrom().startsWith("4");
		}
		if (Objects.nonNull(sectorEntity.getAreaTo())) {
			getAreaToFlag = sectorEntity.getAreaTo().startsWith("4");
		}
			if (getAreaFromFlag || getAreaToFlag) {
				userAreaSrevice.deleteUserArea("P", sectorEntity.getCarrierNumCode(), 
						sectorEntity.getProvisoSectorId().toString());
			}
			provisoSectorStgDao.deleteProvisoSectorByProvisoSectorId(provisoSectorId);
		
	}
}
