package com.sgl.smartpra.global.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sgl.smartpra.global.master.app.dao.entity.TicketOverwriteEntity;

public interface TicketOverwriteRepository extends JpaRepository<TicketOverwriteEntity, Long> {

}
