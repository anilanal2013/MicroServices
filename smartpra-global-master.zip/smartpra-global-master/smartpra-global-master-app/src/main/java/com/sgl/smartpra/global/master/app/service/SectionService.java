package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.Section;
import com.sgl.smartpra.global.master.model.SectionDto;

public interface SectionService {

	public List<Section> getAllSection(Optional<String> chargeCode, Optional<String> sectionCode,
			Optional<String> sectionName, Optional<Boolean> activate);

	public Section findSectionBySectionMasterId(Optional<String> chargeCode, Integer sectionMasterId);

	public Section createSection(Optional<String> chargeCode,Section section);

	public List<Section> updateSection(List<Section> section);

	public void deactivateSection(Optional<String> chargeCode, Integer sectionMasterId, String lastUpdatedBy);

	public void activateSection(Optional<String> chargeCode, Integer sectionMasterId, String lastUpdatedBy);

	Section findSectionBySectionMasterId(Integer sectionMasterId);
	
	public List<SectionDto> fetchSectionByChargeCode(String chargeCode, String currentBillingPeriod);

}
