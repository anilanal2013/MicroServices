package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountStgEntity;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscountStg;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoAdditionalDiscountStgMapper extends BaseMapper<ProvisoAdditionalDiscountStg, ProvisoAdditionalDiscountStgEntity>{
	ProvisoAdditionalDiscountStgEntity mapToEntity(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg,
			@MappingTarget ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity);
	@Mapping(source = "provisoAddlDiscountId", target = "provisoAddlDiscountId", ignore = true)
	ProvisoAdditionalDiscountStgEntity mapToEntity(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg);
}