package com.sgl.smartpra.global.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.CountryEntity;
import com.sgl.smartpra.global.master.model.Country;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CountryMapper extends BaseMapper<Country, CountryEntity>{

	CountryEntity mapToEntity(Country country, @MappingTarget CountryEntity countryEntity);
	
	CountryEntity mapToEntity(Country country);

}
