package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.CommonIdName;

public interface CarrierService {

	public List<Carrier> getAllCarrier(Optional<String> carrierCode, Optional<String> carrierDesignatorCode, Optional<String> carrierName1,
			Optional<String> carrierName2,Optional<Boolean> isActive,Optional<String> exceptionCall);

	public Carrier findCarrierByCarrierCode(String carrierCode);

	public Carrier createCarrier(Carrier carrier);

	public Carrier updateCarrier(String carrierCode, Carrier carrier);

	public void deactivateCarrier(String carrierCode, String lastUpdatedBy);

	public void activateCarrier(String carrierCode, String lastUpdatedBy);

	public boolean isValidCarrierCode(String carrrierCode);

	public boolean isValidCarrierDesignatorCode(String carrierDesignatorCode);

	public List<String> getValidCarrierCode(List<String> carrrierCodeList);
	
	public List<Carrier> getValidCarrierDetails(List<String> carrierCodeList);
	
	public String getCarrrierCodeByCarrierDesignatorCode(String carrierDesignatorCode);
	
	public List<CommonIdName> getCarrierList();

	public Carrier findCarrierByCarrierDesignatorCode(String carrierDesignatorCode);

	public Carrier getCarrierByCarrierCode(String carrierCode);
	
	public boolean isValidCarrier(String carrierDesignatorCode,String carrrierCode);

	public boolean isValidcarrierDesignatorCodeList(String carrierDesignatorCode);
	
}
