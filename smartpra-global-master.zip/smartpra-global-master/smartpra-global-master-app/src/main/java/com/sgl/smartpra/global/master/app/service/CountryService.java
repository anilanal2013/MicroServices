package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sgl.smartpra.global.master.model.Country;
import com.sgl.smartpra.global.master.model.CommonIdName;

@Service
public interface CountryService {

	public Country createCountry(Country country);

	public List<Country> getListOfCountries(String countryCode, String countryName);
	
	public List<Country> getListOfCountriesByIsActive(Optional<String> countryCode, Optional<String> countryName, Optional<Boolean> activate);

	public Country getCountryByCountryCode(String countryCode);

	public Country updateCountry(Country country, String countryCode);

	public void deactivateCountry(Country country);

	public void activateCountry(Country country);
	
	public boolean isValidCountryCode(String countryCode);
	
	public List<String> getValidatedCountryCodeList(List<String> countryCodeList);
	
	public List<CommonIdName> getCountryList();
	

}
