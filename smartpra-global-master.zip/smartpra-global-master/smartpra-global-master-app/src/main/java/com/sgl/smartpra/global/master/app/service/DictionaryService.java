package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.Dictionary;

public interface DictionaryService {

	List<Dictionary> getDictionaryByelementDefine(Optional<String> elementName, Optional<String> dictionarydefine);
}
