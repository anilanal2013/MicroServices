package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Map;

import com.sgl.smartpra.global.master.model.GlobalUserArea;

public interface UserAreaSrevice {

	public List<GlobalUserArea> getListOfUserArea(String userAreaCode, String userAreaName);

	public GlobalUserArea getUserAreaByUserAreaCode(Integer globalUserAreaId);

	public GlobalUserArea createUserArea(GlobalUserArea globaluserArea);

	public GlobalUserArea updateUserArea(Integer globalUserAreaId, GlobalUserArea globaluserArea);

	public void deactivateUserArea(Integer globalUserAreaId, String lastUpdatedBy);

	public void activateUserArea(Integer globalUserAreaId, String lastUpdatedBy);

	public Boolean isValidateAreaCode(String areaCode);

	public void clientSpecificUserAreaInsertOrUpdate(Map<String, String> map);

	public void deleteUserArea(String areaKey1, String areaKey2, String areaKey3);

	public GlobalUserArea getUserAreaBasedOnKeys(String userAreaCode, String areaKey1, String areaKey2, String areaKey3, String areaKey4);

}
