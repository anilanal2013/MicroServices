package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailStgEntity;
import com.sgl.smartpra.global.master.model.ProvisoDetailStgModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoDetailStgMapper extends BaseMapper<ProvisoDetailStgModel, ProvisoDetailStgEntity> {
	ProvisoDetailStgEntity mapToEntity(ProvisoDetailStgModel provisoDetailStgModel,
			@MappingTarget ProvisoDetailStgEntity provisoDetailStgEntity);

	@Mapping(source = "provisoDetailId", target = "provisoDetailId", ignore = true)
	ProvisoDetailStgEntity mapToEntity(ProvisoDetailStgModel provisoDetailStgModel);
}
