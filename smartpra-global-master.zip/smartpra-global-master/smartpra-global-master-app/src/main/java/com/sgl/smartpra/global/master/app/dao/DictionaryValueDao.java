package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.repository.entity.DictionaryValueEntity;

public interface DictionaryValueDao {

	public Optional<DictionaryValueEntity> findById(Integer dictionaryValueId);

	public DictionaryValueEntity create(DictionaryValueEntity dictionaryValueEntity);

	public DictionaryValueEntity update(DictionaryValueEntity dictionaryValueEntity);
	
	public List<DictionaryValueEntity> getDictionaryValueByDictionaryId(Integer dictionaryId);
	
	void deleteById(Integer id);
	
	
}
