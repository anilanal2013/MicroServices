package com.sgl.smartpra.global.master.app.service.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.joda.time.DateTimeComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.OneCountryDao;
import com.sgl.smartpra.global.master.app.dao.entity.OneCountryEntity;
import com.sgl.smartpra.global.master.app.dao.repository.OneCountryRepository;
import com.sgl.smartpra.global.master.app.mapper.OneCountryMapper;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.OneCountryService;
import com.sgl.smartpra.global.master.model.OneCountry;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class OneCountryServiceImpl implements OneCountryService {

	@Autowired
	OneCountryMapper oneCountryMapper;

	@Autowired
	OneCountryDao oneCountryDao;

	@Autowired
	private OneCountryRepository oneCountryRepository;

	@Autowired
	private CountryService countryService;

	private static final String DATEVALIDATION = "Record already exists";
	private static final String ONECOUNTRYINACTIVE = "OneCountry is already in deactivated state";
	private static final String ONECOUNTRYACTIVE = "OneCountry is already in activated state";
	private static final String DEACTIVATESTATE = "Record already exist in deactivated state";
	private static final String EMPTYCOUNTRYLIST = "Can not insert empty country code list";
	private static final String ONECOUNTRYIDINACTIVE = "OneCountry is not active state";
	Boolean flag = false;
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	public OneCountry createOneCountry(OneCountry oneCountry) {

		flag = true;
		int i = 0;
		validateList(oneCountry, flag, i);

		countryList(oneCountry);

		int count = oneCountryDao.verifyIfOverlapExits(oneCountry.getOneCountryCode(),
				oneCountry.getEffectiveFromDate(), oneCountry.getEffectiveToDate());

		if (count > 0) {
			throw new BusinessException(DATEVALIDATION);
		}
		validateDate(oneCountry);

		oneCountry.setIsActive(Boolean.TRUE);

		return oneCountryMapper.mapToModel(oneCountryDao.create(oneCountryMapper.mapToEntity(oneCountry)));
	}

	@Override
	public List<OneCountry> getOneCountryByEffectiveDate(Optional<String> oneCountryCode,
			Optional<String> effectiveDate) {
		return oneCountryMapper.mapToModel(oneCountryDao.getAllOneCountryEntity(effectiveDate, oneCountryCode));
	}

	@Override
	public OneCountry getOneCountryByOneCountryId(Integer oneCountryId) {
		return oneCountryMapper.mapToModel(oneCountryDao.findById(oneCountryId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(oneCountryId))));
	}

	@Override
	public OneCountry getOneCountryByOneCountryCode(Optional<String> countryCodeList,
			Optional<String> effectiveDateString) {
		Optional<OneCountryEntity> optionalOneCountryEntity = oneCountryDao.getOneCountryEntity(countryCodeList,
				effectiveDateString);
		if (!optionalOneCountryEntity.isPresent()) {
			return new OneCountry();
		}
		return oneCountryMapper.mapToModel(optionalOneCountryEntity.get());
	}

	@Override
	public OneCountry updateOneCountry(Integer oneCountryId, OneCountry oneCountry) {

		log.info("{}", oneCountry);
		OneCountryEntity oneCountryEntity = oneCountryDao.findById(oneCountry.getOneCountryId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(oneCountry.getOneCountryId())));

		if (!oneCountryEntity.getIsActive()) {
			throw new BusinessException(ONECOUNTRYIDINACTIVE);
		}
		flag = false;
		validateList(oneCountry, flag, oneCountryId);

		countryList(oneCountry);

		sameDateInActiveRecord(oneCountry.getOneCountryCode(), oneCountry.getEffectiveFromDate(),
				oneCountry.getEffectiveToDate());

		List<Integer> sameRecord = oneCountryRepository.verifyIfSameRecordExits(
				OptionalUtil.getLocalDateValue(oneCountry.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(oneCountry.getEffectiveToDate()),
				OptionalUtil.getValue(oneCountry.getOneCountryCode()));

		if (!sameRecord.isEmpty() && sameRecord.size() == 1 && sameRecord.get(0) == oneCountryId) {

			validateDate(oneCountry);

		} else {

			int count = oneCountryDao.verifyIfOverlapExits(oneCountry.getOneCountryCode(),
					oneCountry.getEffectiveFromDate(), oneCountry.getEffectiveToDate());

			if (count > 0) {
				throw new BusinessException(DATEVALIDATION);
			}

		}

		oneCountryEntity.setIsActive(true);
		oneCountryEntity.setLastUpdatedDate(LocalDateTime.now());

		return oneCountryMapper
				.mapToModel(oneCountryDao.update(oneCountryMapper.mapToEntity(oneCountry, oneCountryEntity)));
	}

	public void sameDateInActiveRecord(Optional<String> oneCountryCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate) {

		int sameRecordCount = oneCountryDao.checkSameInActiveRecord(oneCountryCode, effectiveFromDate, effectiveToDate);

		if (sameRecordCount == 1) {
			throw new BusinessException(DEACTIVATESTATE);
		}
	}

	@Override
	public void deactivateOneCountry(OneCountry oneCountry) {

		OneCountryEntity oneCountryEntity = oneCountryDao.findById(oneCountry.getOneCountryId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(oneCountry.getOneCountryId())));

		if (OptionalUtil.getValue(oneCountry.getLastUpdatedBy()).isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (OptionalUtil.getValue(oneCountry.getLastUpdatedBy()).length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (!oneCountryEntity.getIsActive()) {
			throw new BusinessException(ONECOUNTRYINACTIVE);
		}
		oneCountryEntity.setIsActive(Boolean.FALSE);

		oneCountryDao.update(oneCountryMapper.mapToEntity(oneCountry, oneCountryEntity));

	}

	@Override
	public void activateOneCountry(OneCountry oneCountry) {

		OneCountryEntity oneCountryEntity = oneCountryDao.findById(oneCountry.getOneCountryId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(oneCountry.getOneCountryId())));

		if (OptionalUtil.getValue(oneCountry.getLastUpdatedBy()).isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (OptionalUtil.getValue(oneCountry.getLastUpdatedBy()).length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		if (oneCountryEntity.getIsActive())
			throw new BusinessException(ONECOUNTRYACTIVE);

		if (oneCountryEntity.getCountryCodeList().isEmpty()) {
			throw new BusinessException(EMPTYCOUNTRYLIST + oneCountryEntity.getCountryCodeList());

		} else {
			String[] oneCountryCodeList = oneCountryEntity.getCountryCodeList().split(",");
			for (String oneCountryCode : oneCountryCodeList) {

				if (oneCountryRepository.getAllOneCountry(oneCountryCode).size() > 0) {
					throw new BusinessException("Record already exists");
				}
			}
		}

		int count = oneCountryDao.verifyRecordExits(Optional.of(oneCountryEntity.getEffectiveFromDate().toString()),
				Optional.of(oneCountryEntity.getEffectiveToDate().toString()), oneCountry.getOneCountryId(),
				Optional.of(oneCountryEntity.getOneCountryCode()));

		if (count > 0) {
			throw new BusinessException(DATEVALIDATION);
		}

		oneCountryEntity.setIsActive(Boolean.TRUE);
		oneCountryDao.update(oneCountryMapper.mapToEntity(oneCountry, oneCountryEntity));

	}

	public void validateDate(OneCountry oneCountry) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		String currentDateStr = sdf.format(new Date());

		String effectiveToDateStr = null;
		effectiveToDateStr = OptionalUtil.getValue(oneCountry.getEffectiveToDate());

		Date currentDate = null;
		Date effectiveToDate = null;
		try {
			currentDate = sdf.parse(currentDateStr);
			effectiveToDate = sdf.parse(effectiveToDateStr);
		} catch (ParseException e) {

			e.printStackTrace();
		}

		DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();

		int valid = dateTimeComparator.compare(effectiveToDate, currentDate);

		if (valid < 0) {
			throw new BusinessException("Effective To Date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}

	}

	public void countryList(OneCountry oneCountry) {
		String oneCountryCodeListStr = OptionalUtil.getValue(oneCountry.getCountryCodeList());
		String[] str1 = oneCountryCodeListStr.split(",");
		List<String> list = Arrays.asList(oneCountryCodeListStr.split(","));
		for (int i = 0; i < str1.length; i++) {
			if (list.stream().distinct().collect(Collectors.toList()).size() < list.size()) {
				throw new BusinessException("Invalid One Country Code List " + str1[i]);
			}
		}
		for (int j = 0; j < str1.length; j++) {
			if (!countryService.isValidCountryCode(str1[j])) {
				throw new BusinessException("Invalid One Country Code List " + str1[j]);
			}
		}
	}

	public void updateRecord(OneCountry oneCountry, int oneCountryId) {

		if (!oneCountry.getCountryCodeList().isPresent()) {
			throw new BusinessException(EMPTYCOUNTRYLIST + oneCountry.getCountryCodeList());
		} else {
			String[] oneCountryCodeList = OptionalUtil.getValue(oneCountry.getCountryCodeList()).split(",");
			for (String oneCountryCode : oneCountryCodeList) {
				if (oneCountryRepository.getAllOneCountryUpdated(oneCountryCode, oneCountryId).size() > 0) {
					throw new BusinessException("Record already exists");
				}
			}
		}

	}

	public void validateList(OneCountry oneCountry, Boolean flag, int oneCountryId) {

		if (flag) {
			if (!oneCountry.getCountryCodeList().isPresent()) {
				throw new BusinessException(EMPTYCOUNTRYLIST + oneCountry.getCountryCodeList());
			} else {
				// validation for duplicate record
				String[] oneCountryCodeList = OptionalUtil.getValue(oneCountry.getCountryCodeList()).split(",");

				for (String oneCountryCode : oneCountryCodeList) {

					if (oneCountryRepository.getAllOneCountry(oneCountryCode).size() > 0) {
						throw new BusinessException("Record already exists");
					}
				}
			}
		} else {
			updateRecord(oneCountry, oneCountryId);
		}
	}

	@Override
	public List<OneCountry> search(Optional<String> oneCountryCode, Optional<String> countryCodeList,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> isActive) {
		return oneCountryMapper.mapToModel(
				oneCountryDao.search(oneCountryCode, countryCodeList, effectiveFromDate, effectiveToDate, isActive));
	}
}