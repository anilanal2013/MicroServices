package com.sgl.smartpra.global.master.app.dao.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainEntity;
import com.sgl.smartpra.global.master.model.ProvisoMainModel;

@Repository
public interface ProvisoMainRepository extends JpaRepository<ProvisoMainEntity, Integer>, JpaSpecificationExecutor<ProvisoMainEntity>{

	
	@Query(value = "select a from ProvisoMainEntity a  where (:effectiveDate between a.effectiveFromDate  AND a.effectiveToDate) and a.carrierNumCode = :carrierNumCode and a.provisoSection not in ('A','B')")
	public List<ProvisoMainEntity> getProvisoMainList(@Param("carrierNumCode")String carrierNumCode,@Param("effectiveDate") LocalDate effectiveDate);
}
