package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.ProvisoDetailStgService;
import com.sgl.smartpra.global.master.model.ProvisoDetailStgModel;

@RestController
@RequestMapping("/proviso/detail/stg")
public class ProvisoDetailStgController {
	@Autowired
	private ProvisoDetailStgService provisoDetailStgService;

	@PostMapping("/{provisoMainId}/proviso-detail")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoDetailStgModel createProvisoDetail(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@Validated(Create.class) @RequestBody ProvisoDetailStgModel provisoDetailStgModel) {
		provisoDetailStgModel.setProvisoMainId(provisoMainId);
		return provisoDetailStgService.createProvisoDetail(provisoDetailStgModel);
	}

	@GetMapping("provisoMain/{provisoMainId}")
	public List<ProvisoDetailStgModel> getProvisoDetailByProvisoMainId(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId) {
		return provisoDetailStgService.getProvisoDetailByProvisoMainId(provisoMainId);
	}

	@GetMapping("/{provisoDetailId}")
	public ProvisoDetailStgModel getProvisoDetailByProvisoDetailId(
			@PathVariable(value = "provisoDetailId") Integer provisoDetailId) {
		return provisoDetailStgService.getProvisoDetailByProvisoDetailId(provisoDetailId);
	}

	@GetMapping("/proviso-deatail/{carrierNumCode}/{provisoSeqNumber}")
	public List<ProvisoDetailStgModel> searchByProvisoDetail(
			@PathVariable(value = "carrierNumCode") Optional<String> carrierNumCode,
			@PathVariable(value = "provisoSeqNumber") Optional<Integer> provisoSeqNumber) {
		return provisoDetailStgService.search(carrierNumCode, provisoSeqNumber);
	}

	@GetMapping("/search")
	public List<ProvisoDetailStgModel> search(
			@RequestParam(name = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@RequestParam(name = "provisoSeqNumber", required = false) Optional<Integer> provisoSeqNumber,
			@RequestParam(name = "fbGroupCode", required = false) Optional<String> fbGroupCode) {
		return provisoDetailStgService.search(carrierNumCode, provisoSeqNumber, fbGroupCode);
	}

	@PutMapping("/{provisoMainId}/{provisoDetailId}")
	@ResponseStatus(value = HttpStatus.OK)
	public ProvisoDetailStgModel updateProvisoDetail(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@PathVariable(value = "provisoDetailId") Integer provisoDetailId,
			@Validated(Update.class) @RequestBody ProvisoDetailStgModel provisoDetailStgModel) {
		provisoDetailStgModel.setProvisoMainId(provisoMainId);
		return provisoDetailStgService.updateProvisoDetail(provisoDetailId, provisoDetailStgModel);
	}
	@DeleteMapping("/provisoDetailDeletedById/{provisoDetailId}")
	public void deleteProvisoSectorMasterStg(@PathVariable(value = "provisoDetailId") Integer provisoDetailId) {
		provisoDetailStgService.deleteProvisoDetailByProvisoDetailId(provisoDetailId);
	}	
}
