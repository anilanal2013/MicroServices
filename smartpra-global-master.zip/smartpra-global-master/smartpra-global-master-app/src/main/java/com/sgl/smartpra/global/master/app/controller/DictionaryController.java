package com.sgl.smartpra.global.master.app.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.DictionaryService;
import com.sgl.smartpra.global.master.model.Dictionary;

@RestController
public class DictionaryController {

	@Autowired
	DictionaryService dictionaryService;
	
	@GetMapping("/dictionary")
	public List<Dictionary> getDictionaryByElementdefine(
			@RequestParam(value = "elementName" , required = false) String elementName,
			@RequestParam(value = "dictionaryDefine" , required = false) String dictionarydefine
			) {
		return dictionaryService.getDictionaryByelementDefine(Optional.ofNullable(elementName), Optional.ofNullable(dictionarydefine));
	}
}
