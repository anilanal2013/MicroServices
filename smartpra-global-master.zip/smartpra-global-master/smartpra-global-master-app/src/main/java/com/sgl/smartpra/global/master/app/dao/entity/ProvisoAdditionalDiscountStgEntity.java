package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_provi_addl_disc_stg")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class ProvisoAdditionalDiscountStgEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "proviso_addl_discount_id", nullable = false)
	private Integer provisoAddlDiscountId;

	@Column(name = "proviso_main_id", nullable = false)
	private Integer provisoMainId;

	@Column(name = "carrier_num_code", nullable = false, length = 3)
	private String carrierNumCode;

	@Column(name = "proviso_seq_number", nullable = false)
	private Integer provisoSeqNumber;

	@Column(name = "discount_rec_number", nullable = false)
	private Integer discountRecNumber;

	@Column(name = "discount_code", nullable = false, length = 2)
	private String discountCode;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
