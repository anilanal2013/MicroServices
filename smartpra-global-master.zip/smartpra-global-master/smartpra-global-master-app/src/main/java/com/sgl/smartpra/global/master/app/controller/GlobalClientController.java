package com.sgl.smartpra.global.master.app.controller;

import com.sgl.smartpra.global.master.app.service.GlobalClientService;
import com.sgl.smartpra.global.master.model.GlobalClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
public class GlobalClientController {

    @Autowired
    private GlobalClientService globalClientService;


    @GetMapping("/clientId")
    public GlobalClient getCurrentClientIdByUrl(@RequestParam(name = "appUrl", required = false) Optional<String> appUrl) {
        GlobalClient globalClient = new GlobalClient();
        globalClient.setAppUrl(appUrl);
        globalClient.setIsActive(Optional.of(true));
        return globalClientService.getCurrentClientIdByUrl(globalClient);
    }


}
