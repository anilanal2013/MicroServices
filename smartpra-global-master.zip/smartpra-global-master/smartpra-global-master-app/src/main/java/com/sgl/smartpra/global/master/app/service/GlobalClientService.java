package com.sgl.smartpra.global.master.app.service;

import com.sgl.smartpra.global.master.model.GlobalClient;

public interface GlobalClientService {

    GlobalClient getCurrentClientIdByUrl(GlobalClient globalClient);
}
