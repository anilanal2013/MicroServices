package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoDetailEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoDetailRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoDetailDaoImpl implements ProvisoDetailDao {

	@Autowired
	private ProvisoDetailRepository provisoDetailRepository;

	@Override
	public List<ProvisoDetailEntity> findByMainId(Optional<Integer> provisoMainId) {

		return provisoDetailRepository.findAll(ProvisoDetailEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	@Cacheable(value = "provisoDetailModel", key = "#id")
	public Optional<ProvisoDetailEntity> findById(Integer id) {
		log.info("Cacheable Proviso Detail Entity's ID= {}", id);
		return provisoDetailRepository.findById(id);
	}

	@Override
	public List<ProvisoDetailEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {
		return provisoDetailRepository
				.findAll(ProvisoDetailEntitySpecification.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	public List<ProvisoDetailEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> fbGroupCode) {
		return provisoDetailRepository
				.findAll(ProvisoDetailEntitySpecification.search(carrierNumCode, provisoSeqNumber, fbGroupCode));
	}
	
	@Override
	@Caching(evict = { @CacheEvict(value = "provisoDetail", key = "#provisoDetailEntity.provisoMainId") })
	public ProvisoDetailEntity create(ProvisoDetailEntity provisoDetailEntity) {
		return provisoDetailRepository.save(provisoDetailEntity);
	}

	@Override
	public List<ProvisoDetailEntity> getExceptionRecordFromProvisoDetail(Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber,Optional<String> carrierNumCode) {
		return provisoDetailRepository
				.findAll(ProvisoDetailEntitySpecification.searchExceptionRecords( provisoSeqNumber, detailRecNumber,carrierNumCode));
	}
	@Override
	public List<Integer> getListOfProvisoMainIdFromDetailDb() {
		
		return provisoDetailRepository.getListOfProvisoMainIdFromDetailDb();
	}
}
