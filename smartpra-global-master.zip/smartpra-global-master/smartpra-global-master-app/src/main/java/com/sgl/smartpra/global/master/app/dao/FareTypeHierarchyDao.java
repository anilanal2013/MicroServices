package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import com.sgl.smartpra.global.master.app.dao.entity.FareTypeHierarchyEntity;

public interface FareTypeHierarchyDao {

	public Optional<FareTypeHierarchyEntity> findById(Integer fareTypeHierarchyId);

	public FareTypeHierarchyEntity create(FareTypeHierarchyEntity fareTypeHierarchyEntity);

	public FareTypeHierarchyEntity update(FareTypeHierarchyEntity fareTypeHierarchyEntity);

	public List<FareTypeHierarchyEntity> getAllFareTypeHierarchy(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<Integer> cabinLevel, Optional<Integer> fareTypeLevel);

	void delete(Integer id);

	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String fareTypeCode,
			String cabin, Integer cabinLevel, Integer fareTypeLevel);

	public List<FareTypeHierarchyEntity> getAllFareTypeHierarchyCabin(Optional<String> effectiveDate,
			Optional<String> cabin, Optional<Integer> fareTypeLevel);

	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String fareTypeCode, String cabin, Integer cabinLevel, Integer fareTypeLevel, Integer fareTypeId);

}
