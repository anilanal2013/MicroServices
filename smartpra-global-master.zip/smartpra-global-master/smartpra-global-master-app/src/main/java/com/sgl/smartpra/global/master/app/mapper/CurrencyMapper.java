package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.CurrencyEntity;
import com.sgl.smartpra.global.master.model.Currency;


@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, 
nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)

public interface CurrencyMapper extends BaseMapper<Currency, CurrencyEntity> {

	CurrencyEntity mapToEntity(Currency currency, @MappingTarget CurrencyEntity currencyEntity);

	CurrencyEntity mapToEntity(Currency currency);

}
