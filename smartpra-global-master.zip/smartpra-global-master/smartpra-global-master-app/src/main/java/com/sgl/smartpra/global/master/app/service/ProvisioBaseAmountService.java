package com.sgl.smartpra.global.master.app.service;

import java.util.Date;
import java.util.List;

import com.sgl.smartpra.global.master.model.ProvisioBaseAmount;

public interface ProvisioBaseAmountService {

	public ProvisioBaseAmount createProvisioBaseAmount(ProvisioBaseAmount provisioBaseAmount);

	public List<ProvisioBaseAmount> getListOfProvisioBaseAmount(String fromCityCode, String toCityCode,
			String carrierCode, Boolean activate);

	public ProvisioBaseAmount getProvisioBaseAmountByTicketDate(String fromCityCode, String toCityCode,
			Date effectiveDate, String carrierCode, String classCode);

	public ProvisioBaseAmount getProvisioBaseAmountByTicketDate(String fromCityCode, String toCityCode,
			String effectiveDate, String carrierCode, String classCode);

	public ProvisioBaseAmount updateProvisioBaseAmount(Integer provisioBaseAmountId,
			ProvisioBaseAmount provisioBaseAmount);

	public void deactivateProvisioBaseAmount(Integer provisioBaseAmountId, String lastUpdatedBy);

	public void activateProvisioBaseAmount(Integer provisioBaseAmountId, String lastUpdatedBy);

	public ProvisioBaseAmount getProvisoBaseAmount(String fromCityCode, String toCityCode, String classCode,
			String carrierCode, String issueDate);

	public ProvisioBaseAmount findByProvisioBaseId(Integer provisoBaseid);

}
