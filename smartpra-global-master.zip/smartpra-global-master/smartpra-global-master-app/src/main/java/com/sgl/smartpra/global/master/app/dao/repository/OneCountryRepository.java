package com.sgl.smartpra.global.master.app.dao.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.OneCountryEntity;

@Repository
public interface OneCountryRepository
		extends JpaRepository<OneCountryEntity, Integer>, JpaSpecificationExecutor<OneCountryEntity> {

	@Query(value = "select oneCountryId from OneCountryEntity d where"
			+ " ((?1 between d.effectiveFromDate and d.effectiveToDate) or "
			+ "	(?2 between d.effectiveFromDate and d.effectiveToDate))"
			+ " and d.oneCountryCode = ?3 and d.isActive = 'Y'")
	List<Integer> verifyIfSameRecordExits(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String oneCountryCode);

	@Query(value = "select oneCountryId from OneCountryEntity a where a.isActive = 'Y' AND a.countryCodeList like %:countryCode%")
	public List<String> getAllOneCountry(@Param("countryCode") String countryCode);

	@Query(value = "select oneCountryId from OneCountryEntity a where a.isActive = 'Y' AND a.oneCountryId <> :oneCountryId "
			+ " AND a.countryCodeList like %:countryCode%")
	public List<Integer> getAllOneCountryUpdated(@Param("countryCode") String countryCode,
			@Param("oneCountryId") Integer oneCountryId);

}
