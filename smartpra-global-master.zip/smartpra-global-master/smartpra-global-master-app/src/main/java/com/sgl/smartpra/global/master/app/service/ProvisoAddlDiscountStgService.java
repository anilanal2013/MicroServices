package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscountStg;

public interface ProvisoAddlDiscountStgService {
	public ProvisoAdditionalDiscountStg createProvisoAddlDiscount(
			ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg);

	public List<ProvisoAdditionalDiscountStg> getProvisoAddlDiscountByProvisoMainId(Optional<Integer> provisoMainId);

	public ProvisoAdditionalDiscountStg getProvisoAddlDiscountByProvisoAddlDiscountId(Integer provisoAddlDiscountId);

	public List<ProvisoAdditionalDiscountStg> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber);

	public ProvisoAdditionalDiscountStg updateProvisoAddlDiscount(Integer provisoAddlDiscountId,
			ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg);
	public void deleteProvisoAddlDiscountByProvisoMainId(Integer provisoMainId);

	public void deleteProvisoAddlDiscountByProvisoAddlDiscountId(Integer provisoAddlDiscountId);
}
