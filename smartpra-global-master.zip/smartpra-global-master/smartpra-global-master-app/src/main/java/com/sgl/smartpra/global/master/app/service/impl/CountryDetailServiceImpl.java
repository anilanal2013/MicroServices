package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.CountryDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.CountryDetailEntity;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.CountryDetailMapper;
import com.sgl.smartpra.global.master.app.service.CountryDetailService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.CurrencyService;
import com.sgl.smartpra.global.master.model.Country;
import com.sgl.smartpra.global.master.model.CountryDetail;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class CountryDetailServiceImpl implements CountryDetailService {

	@Autowired
	private CountryDetailMapper countryDtlMapper;

	@Autowired
	private CountryDetailDao countryDtlDao;

	@Autowired
	private CountryService countryService;

	@Autowired
	private CurrencyService currencyService;

	private String invalidParentCountryCode = " Invalid Parent Country code ";
	private String invalidCountryCode = " Invalid Country code ";
	private static final String COUNTRY_CODE_MISMATCH = "Country code in Json should be same as URL ";
	private static final String OVERLAP_COMBINATION_EXIST = "Record already exists";

	public CountryDetail getCountryDetailByCounryDetailCode(String countryCode, Integer countryDtlId) {

		return countryDtlMapper.mapToModel(countryDtlDao.findById(countryDtlId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(countryDtlId))));
	}

	public CountryDetail createCountryDetail(CountryDetail countryDetail, String countryCode) {
		if (OptionalUtil.isPresent(countryDetail.getCountryCode())) {
			if (!countryCode.equalsIgnoreCase(OptionalUtil.getValue(countryDetail.getCountryCode()))) {
				throw new BusinessException(COUNTRY_CODE_MISMATCH);
			}
		} else {
			countryDetail.setCountryCode(Optional.of(countryCode));
		}
		validateOverlap(countryDetail);

		validateBusinessContraints(countryDetail);
		countryDetail.setCreatedDate(LocalDateTime.now());

		return countryDtlMapper.mapToModel(countryDtlDao.create(countryDtlMapper.mapToEntity(countryDetail)));
	}

	private void validateBusinessContraints(CountryDetail countryDetail) {
		if (OptionalUtil.isPresent(countryDetail.getEffectiveFromPeriod())
				&& OptionalUtil.isPresent(countryDetail.getEffectiveToPeriod())) {
			validateEffectiveToDate(OptionalUtil.getLocalDateValue(countryDetail.getEffectiveToPeriod()),
					OptionalUtil.getLocalDateValue(countryDetail.getEffectiveFromPeriod()));
		}
		validateCountryCode(countryDetail);
		validateParentCountryCode(countryDetail);
		validateBaseCurrenyCode(countryDetail);
		validateDualCurrencyCode(countryDetail);
		validateStrongCurrencyCode(countryDetail);
	}

	private void validateStrongCurrencyCode(CountryDetail countryDetail) {
		try {
			currencyService.findCurrencyByCurrencyCode(OptionalUtil.getValue(countryDetail.getStrongCurrencyCode()));
		} catch (ResourceNotFoundException rnfe) {
			throw new BusinessException("Invalid Strong Currency code " + countryDetail.getStrongCurrencyCode());
		} catch (BusinessException se) {
			throw new BusinessException("Invalid Strong Currency code " + countryDetail.getStrongCurrencyCode());
		}
	}

	private void validateDualCurrencyCode(CountryDetail countryDetail) {
		try {
			currencyService.findCurrencyByCurrencyCode(OptionalUtil.getValue(countryDetail.getDualCurrencyCode()));
		} catch (ResourceNotFoundException rnfe) {
			throw new BusinessException("Invalid Dual Currency code " + countryDetail.getDualCurrencyCode());
		} catch (BusinessException se) {
			throw new BusinessException("Invalid Dual Currency code " + countryDetail.getDualCurrencyCode());
		}

	}

	private void validateBaseCurrenyCode(CountryDetail countryDetail) {
		try {
			currencyService.findCurrencyByCurrencyCode(OptionalUtil.getValue(countryDetail.getBaseCurrencyCode()));
		} catch (ResourceNotFoundException rnfe) {
			throw new BusinessException("Invalid Base Currency code " + countryDetail.getBaseCurrencyCode());
		} catch (BusinessException se) {
			throw new BusinessException("Invalid Base Currency code " + countryDetail.getBaseCurrencyCode());
		}

	}

	private void validateParentCountryCode(CountryDetail countryDetail) {
		if (!countryService.isValidCountryCode(OptionalUtil.getValue(countryDetail.getParentCountryCode()))) {
			throw new BusinessException(
					invalidParentCountryCode + OptionalUtil.getValue(countryDetail.getParentCountryCode()));
		}
	}

	private void validateCountryCode(CountryDetail countryDetail) {
		try {
			countryService.getCountryByCountryCode(OptionalUtil.getValue(countryDetail.getCountryCode()));
		} catch (ResourceNotFoundException rnfe) {
			throw new BusinessException(invalidCountryCode + countryDetail.getCountryCode());
		} catch (BusinessException se) {
			throw new BusinessException(invalidCountryCode + countryDetail.getCountryCode());
		}
	}

	public List<CountryDetail> getListOfCountryDetails(String countryCode, Optional<String> effectiveDate) {

		List<CountryDetailEntity> countryDetailEntity;
		if (countryCode != null || !OptionalUtil.isPresent(effectiveDate)) {
			countryDetailEntity = countryDtlDao.getAllCountryEntityByEffectiveDate(Optional.of(countryCode),
					effectiveDate);
			if (countryDetailEntity != null) {
				return countryDtlMapper.mapToModel(countryDetailEntity);
			} else {
				throw new BusinessException("No Result found");
			}
		} else {
			throw new BusinessException("No Result found");
		}

	}

	public CountryDetail updateCountryDetail(Integer countryDtlId, CountryDetail countryDetail) {

		log.info("{}", countryDetail);
		CountryDetailEntity countryDetailEntity = countryDtlDao.findById(countryDtlId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(countryDtlId)));

		validateBusinessContraints(countryDetail);

		countryDetail.setLastUpdatedDate(LocalDateTime.now());
		validateOverlapForUpdate(countryDetail, countryDetailEntity);
		return countryDtlMapper
				.mapToModel(countryDtlDao.update(countryDtlMapper.mapToEntity(countryDetail, countryDetailEntity)));
	}

	/* Cabin class to be added */
	@Override
	public List<CountryDetail> findCountryCodeByCountryCodeAndCabinClass(String countryCode) {
		return countryDtlMapper.mapToModel(countryDtlDao.findByCountryCode(Optional.of(countryCode)));
	}

	@Override
	public void deleteCountryDetail(String countryCode, Integer countryDtlId) {
		// TODO Auto-generated method stub

	}

	private void validateEffectiveToDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To Date[" + effectiveToDate
					+ "] should be greater than Effective From Date[" + effectiveFromDate + "]");
		}
	}

	private void validateOverlap(CountryDetail countryDetail) {
		if (countryDtlDao.getOverLapRecordCount(OptionalUtil.getLocalDateValue(countryDetail.getEffectiveFromPeriod()),
				OptionalUtil.getLocalDateValue(countryDetail.getEffectiveToPeriod()),
				OptionalUtil.getValue(countryDetail.getCountryCode())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

	private void validateOverlapForUpdate(CountryDetail countryDetail, CountryDetailEntity countryDetailEntity) {
		if (countryDtlDao.getOverLapRecordCountForUpdate(
				OptionalUtil.getLocalDateValue(countryDetail.getEffectiveFromPeriod()),
				OptionalUtil.getLocalDateValue(countryDetail.getEffectiveToPeriod()),
				OptionalUtil.getValue(countryDetail.getCountryCode()), countryDetailEntity.getCountryDtlId()) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

	@Override
	public List<CountryDetail> copyCountryDetailsRecordByCountryCode(Country country) {
		List<CountryDetail> countryDtl = countryDtlMapper
				.mapToModel(countryDtlDao.findByCountryCode(country.getCopyRecordId()));
		if (!countryDtl.isEmpty()) {
			countryDtl.forEach(f -> {
				f.setCountryCode(Optional.of(country.getCountryCode()));
				f.setCountryDtlId(null);
			});
			return countryDtlMapper.mapToModel(countryDtlDao.createAll(countryDtlMapper.mapToEntity(countryDtl)));
		}

		return countryDtl;
	}

	@Override
	public CountryDetail getCountryDetailsByEffectiveDate(String countryCode, String effectiveDate) {
		Optional<String> issueDate = Optional.of(effectiveDate);
		return countryDtlMapper.mapToModel(countryDtlDao.getCountryDetailsByEffectiveDate(countryCode, issueDate));
	}

}