package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.InvolIndicatorDao;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.InvolIndicatorMapper;
import com.sgl.smartpra.global.master.app.repository.entity.InvolIndicatorEntity;
import com.sgl.smartpra.global.master.app.service.InvolIndicatorService;
import com.sgl.smartpra.global.master.model.InvolIndicator;
import com.sgl.smartpra.global.master.model.InvolIndicatorResponse;

@Service
@Transactional
public class InvolIndicatorServiceImpl implements InvolIndicatorService {

	@Autowired
	private InvolIndicatorMapper involIndicatorMapper;

	@Autowired
	private InvolIndicatorDao involIndicatorDao;

	@Autowired
	private MasterFeignClient masterFeignClient;

	public static final String INVOLINDICATOR_ACTIVE = "Invol Indicator is already in active state";
	public static final String INVOLINDICATOR_ALREADY_INACTIVE = "Invol Indicator is already in deactivated state";
	public static final String INVOLINDICATOR = "Invol Indicator";
	public static final String LAST_UPDATEDBY_MSG = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	public static final String LASTUPDATED_BY_MENDATORY_MSG = "Please provide last updated by";
	public static final String INVOLINDICATOR_IS_NOT_ACTIVE = "Invol Indicator is not active with  ";
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String TICKECT_FIELD = LOVEnum.TICKECT_FIELD.getLOVEnum();
	public static final String SEARCH_TYPE = LOVEnum.SEARCH_TYPE.getLOVEnum();
	public static final String INDICATOR_TYPE = LOVEnum.INDICATOR_TYPE.getLOVEnum();
	public static final String IS_NOT_VALID = "] is Not Valid";

	String hostCarrDesigCode;

	@Override
	public List<InvolIndicator> getListOfInvolIndicator(Optional<String> effectiveDate,
			Optional<String> indicatorType) {
		if (OptionalUtil.isPresent(effectiveDate) && OptionalUtil.isPresent(indicatorType)) {
			return involIndicatorMapper.mapToModel(involIndicatorDao.findAll(effectiveDate, indicatorType));
		}
		throw new ServiceException("Record not found");
	}

	@Override
	public List<InvolIndicator> getListOfAllInvol(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> indicatorType, Optional<String> ticketField, Optional<Boolean> activate) {
		return involIndicatorMapper.mapToModel(
				involIndicatorDao.search(effectiveFromDate, effectiveToDate, indicatorType, ticketField, activate));
	}

	@Override
	public InvolIndicator getInvolIndicatorByInvolIndicatorId(int involIndicatorId) {
		Optional<InvolIndicatorEntity> involIndicatorEntity = involIndicatorDao.findById(involIndicatorId);
		if (!involIndicatorEntity.isPresent()) {
			throw new ResourceNotFoundException(INVOLINDICATOR, "code", involIndicatorId);
		}
		return involIndicatorMapper.mapToModel(involIndicatorEntity.get());
	}

	@Override
	public InvolIndicator createInvolIndicator(InvolIndicator involIndicator) {
		hostCarrDesigCode = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(involIndicator.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(involIndicator.getEffectiveToDate()));
		validateOverLap(involIndicator);
		validateTicketField(OptionalUtil.getValue(involIndicator.getTicketField()));
		validateSearchField(OptionalUtil.getValue(involIndicator.getSearchType()));
		validateIndicatorType(OptionalUtil.getValue(involIndicator.getIndicatorType()));
		involIndicator.setActivate(Boolean.TRUE);
		involIndicator.setCreatedDate(LocalDateTime.now());
		return involIndicatorMapper
				.mapToModel(involIndicatorDao.create(involIndicatorMapper.mapToEntity(involIndicator)));
	}

	@Override
	public InvolIndicator updateInvolIndicator(int involIndicatorId, InvolIndicator involIndicator) {
		InvolIndicatorEntity involEntity = involIndicatorDao.findById(involIndicatorId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(involIndicatorId)));
		if (!involEntity.getActivate())
			throw new BusinessException(INVOLINDICATOR_IS_NOT_ACTIVE);
		hostCarrDesigCode = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		validateEffectiveToDate(involIndicator, involEntity);
		validateOverLapForUpdate(involIndicator, involEntity);
		validateTicketField(involIndicator, involEntity);
		validateSearchField(involIndicator, involEntity);
		validateIndicatorType(involIndicator, involEntity);
		involEntity.setLastUpdatedDate(LocalDateTime.now());
		return involIndicatorMapper
				.mapToModel(involIndicatorDao.update(involIndicatorMapper.mapToEntity(involIndicator, involEntity)));
	}

	@Override
	public void deactivateInvolIndicator(@Valid int involIndicatorId, String lastUpdatedBy) {

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new ServiceException(LAST_UPDATEDBY_MSG);
		} else {
			throw new ServiceException(LASTUPDATED_BY_MENDATORY_MSG);
		}
		Optional<InvolIndicatorEntity> involIndicatorEntity = involIndicatorDao.findById(involIndicatorId);
		if (!involIndicatorEntity.isPresent())
			throw new ResourceNotFoundException(INVOLINDICATOR, "id", involIndicatorId);
		if (!involIndicatorEntity.get().getActivate())
			throw new ServiceException(INVOLINDICATOR_ALREADY_INACTIVE);
		involIndicatorEntity.get().setActivate(Boolean.FALSE);
		involIndicatorEntity.get().setLastUpdatedDate(LocalDateTime.now());
		involIndicatorDao.update(involIndicatorEntity.get());
	}

	@Override
	public void activateInvolIndicator(@Valid int involIndicatorId, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new ServiceException(LAST_UPDATEDBY_MSG);
		} else {
			throw new ServiceException(LAST_UPDATEDBY_MSG);
		}
		Optional<InvolIndicatorEntity> involIndicatorEntity = involIndicatorDao.findById(involIndicatorId);
		if (!involIndicatorEntity.isPresent())
			throw new ResourceNotFoundException(INVOLINDICATOR, "id", involIndicatorId);
		if (involIndicatorEntity.get().getActivate())
			throw new ServiceException(INVOLINDICATOR_ACTIVE);
		involIndicatorEntity.get().setActivate(Boolean.TRUE);
		involIndicatorEntity.get().setLastUpdatedDate(LocalDateTime.now());
		involIndicatorDao.update(involIndicatorEntity.get());
	}

	@Override
	public List<InvolIndicator> validateDate(Optional<String> effectiveDate) {
		List<InvolIndicator> mapToModel = null;
		if (OptionalUtil.isPresent(effectiveDate)) {
			mapToModel = involIndicatorMapper.mapToModel(involIndicatorDao.validateDate(effectiveDate));
		}
		return mapToModel;
	}

	protected void validateEffectiveToDate(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}

	private void validateTicketField(String ticketField) {
		List<String> tickeFieldLOV = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,
				TICKECT_FIELD);
		if (!(tickeFieldLOV.contains(ticketField))) {
			throw new ServiceException("Ticket Field[" + ticketField + IS_NOT_VALID);
		}

	}

	private void validateSearchField(String searchType) {
		List<String> searchTypeLOV = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,
				SEARCH_TYPE);
		if (!(searchTypeLOV.contains(searchType))) {
			throw new ServiceException("Search Type[" + searchType + IS_NOT_VALID);
		}
	}

	private void validateIndicatorType(String indicatorType) {
		List<String> indicatorTypeLOV = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,
				INDICATOR_TYPE);
		if (!(indicatorTypeLOV.contains(indicatorType))) {
			throw new ServiceException("Indicator Type[" + indicatorType + IS_NOT_VALID);
		}
	}

	private void validateOverLap(InvolIndicator involIndicator) {
		if (involIndicatorDao.getOverLapRecordCount(involIndicator.getEffectiveFromDate(),
				involIndicator.getEffectiveToDate(), involIndicator.getTicketField(),
				involIndicator.getIndicatorText()) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

	private void validateEffectiveToDate(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		if (OptionalUtil.isPresent(involIndicator.getEffectiveFromDate())
				|| OptionalUtil.isPresent(involIndicator.getEffectiveToDate())) {
			validateEffectiveToDate(getEffectiveFromDate(involIndicator, involEntity),
					getEffectiveToDate(involIndicator, involEntity));
		}
	}

	private LocalDate getEffectiveFromDate(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		return OptionalUtil.isPresent(involIndicator.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(involIndicator.getEffectiveFromDate())
				: involEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		return OptionalUtil.isPresent(involIndicator.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(involIndicator.getEffectiveToDate())
				: involEntity.getEffectiveToDate();
	}

	private void validateIndicatorType(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		if (OptionalUtil.isPresent(involIndicator.getIndicatorType()))
			validateIndicatorType(getIndicatorType(involIndicator, involEntity));
	}

	private void validateSearchField(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		if (OptionalUtil.isPresent(involIndicator.getSearchType()))
			validateSearchField(getSearchType(involIndicator, involEntity));
	}

	private void validateTicketField(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		if (OptionalUtil.isPresent(involIndicator.getTicketField()))
			validateTicketField(getTicketField(involIndicator, involEntity));
	}

	private String getTicketField(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		return OptionalUtil.isPresent(involIndicator.getTicketField())
				? OptionalUtil.getValue(involIndicator.getTicketField())
				: involEntity.getTicketField();
	}

	private String getSearchType(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		return OptionalUtil.isPresent(involIndicator.getSearchType())
				? OptionalUtil.getValue(involIndicator.getSearchType())
				: involEntity.getSearchType();
	}

	private String getIndicatorText(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		return OptionalUtil.isPresent(involIndicator.getIndicatorText())
				? OptionalUtil.getValue(involIndicator.getIndicatorText())
				: involEntity.getIndicatorText();
	}

	private String getIndicatorType(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		return OptionalUtil.isPresent(involIndicator.getIndicatorType())
				? OptionalUtil.getValue(involIndicator.getIndicatorType())
				: involEntity.getIndicatorType();
	}

	private void validateOverLapForUpdate(InvolIndicator involIndicator, InvolIndicatorEntity involEntity) {
		String ticketField = getTicketField(involIndicator, involEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(involIndicator, involEntity);
		LocalDate effectiveToDate = getEffectiveToDate(involIndicator, involEntity);
		String indicatorText = getIndicatorText(involIndicator, involEntity);
		if (!ticketField.equalsIgnoreCase(involEntity.getTicketField())
				|| !effectiveFromDate.equals(involEntity.getEffectiveFromDate())
				|| !effectiveToDate.equals(involEntity.getEffectiveToDate())
				|| !indicatorText.equalsIgnoreCase(involEntity.getIndicatorText())) {
			if (involIndicatorDao.getOverLapRecordCount(effectiveFromDate, effectiveToDate, ticketField, indicatorText,
					involEntity.getInvolIndicatorId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	@Override
	public InvolIndicatorResponse getListOfAllInvol(Pageable pageable, InvolIndicator involIndicator) {

		InvolIndicatorResponse involIndicatorResponse = new InvolIndicatorResponse();

		involIndicatorResponse
				.setTotalCount(involIndicatorDao.getCount(involIndicatorMapper.mapToEntity(involIndicator)));
		Page<InvolIndicatorEntity> data = involIndicatorDao.getData(involIndicatorMapper.mapToEntity(involIndicator),
				pageable);
		involIndicatorResponse.setData(involIndicatorMapper.mapToModel(data.getContent()));

		return involIndicatorResponse;
	}
}
