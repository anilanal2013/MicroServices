package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.FareTypeHierarchyDao;
import com.sgl.smartpra.global.master.app.dao.entity.FareTypeHierarchyEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.CarrierDetailEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.entity.spec.FareTypeHeirarchyEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.FareTypeHierarchyRepository;
import com.sgl.smartpra.global.master.model.FareTypeHierarchy;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FareTypeHeirarchyDaoImpl extends CommonSearchDao<FareTypeHierarchy> implements FareTypeHierarchyDao {

	@Autowired
	private FareTypeHierarchyRepository fareTypeHierarchyRepository;

	@Override
	public Optional<FareTypeHierarchyEntity> findById(Integer id) {
		log.info("Cacheable Fares Entity's ID= {}", id);
		return fareTypeHierarchyRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fareTypeHeirarchy", key = "#fareTypeHierarchyEntity.fareTypeHierarchyId"),
			@CacheEvict(value = "fareTypeHeirarchySearch", allEntries = true) })
	public FareTypeHierarchyEntity create(FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		return fareTypeHierarchyRepository.save(fareTypeHierarchyEntity);
	}

	@Override
	@CachePut(value = "fareTypeHierarchy", key = "#fareTypeHierarchyEntity.fareTypeHierarchyId")
	@CacheEvict(value = "fareTypeHeirarchySearch", allEntries = true)
	public FareTypeHierarchyEntity update(FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		return fareTypeHierarchyRepository.save(fareTypeHierarchyEntity);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fareTypeHeirarchy", key = "#fareTypeHeirarchyEntity.fareTypeHeirarchyId"),
			@CacheEvict(value = "fareTypeHeirarchySearch", allEntries = true) })
	public void delete(Integer id) {
		fareTypeHierarchyRepository.deleteById(id);
	}

	@Override
	public List<FareTypeHierarchyEntity> getAllFareTypeHierarchy(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<Integer> cabinLevel, Optional<Integer> fareTypeLevel) {
		return fareTypeHierarchyRepository.findAll(FareTypeHeirarchyEntitySpecification.search(effectiveFromDate,
				effectiveToDate, cabinLevel, fareTypeLevel));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String fareTypeCode,
			String cabin, Integer cabinLevel, Integer fareTypeLevel) {
		return fareTypeHierarchyRepository.count(Specification
				.where(FareTypeHeirarchyEntitySpecification.equalsFareTypeCode(fareTypeCode))
				.and(FareTypeHeirarchyEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(FareTypeHeirarchyEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(FareTypeHeirarchyEntitySpecification.equalsCabin(cabin))
				.and(FareTypeHeirarchyEntitySpecification.equalsCabinLevel(cabinLevel))
				.and(FareTypeHeirarchyEntitySpecification.equalsFareTypeLevel(fareTypeLevel)));
	}

	@Override
	public List<FareTypeHierarchyEntity> getAllFareTypeHierarchyCabin(Optional<String> effectiveDate,
			Optional<String> cabin, Optional<Integer> fareTypeLevel) {
		return fareTypeHierarchyRepository
				.findAll(FareTypeHeirarchyEntitySpecification.searchWithCabin(effectiveDate, cabin, fareTypeLevel));
	}

	@Override
	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String fareTypeCode, String cabin, Integer cabinLevel, Integer fareTypeLevel, Integer fareTypeId) {
		return fareTypeHierarchyRepository.count(Specification
				.where(FareTypeHeirarchyEntitySpecification.equalsFareTypeCode(fareTypeCode))
				.and(FareTypeHeirarchyEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(FareTypeHeirarchyEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(FareTypeHeirarchyEntitySpecification.equalsCabin(cabin))
				.and(FareTypeHeirarchyEntitySpecification.equalsCabinLevel(cabinLevel))
				.and(FareTypeHeirarchyEntitySpecification.equalsFareTypeLevel(fareTypeLevel))
				.and(FareTypeHeirarchyEntitySpecification.notEqualsFareTypeHierarchyId(fareTypeId)));
	}

}
