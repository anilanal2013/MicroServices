package com.sgl.smartpra.global.master.app.mapper;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareEntity;
import com.sgl.smartpra.global.master.model.ProvisoCodeshareStgModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoCodeshareCombinedMapper extends BaseMapper<ProvisoCodeshareStgModel, ProvisoCodeshareEntity> {
	ProvisoCodeshareEntity mapToEntity(ProvisoCodeshareStgModel provisoCodeshareStgModel,
			@MappingTarget ProvisoCodeshareEntity provisoCodeshareEntity);
	ProvisoCodeshareEntity mapToEntity(ProvisoCodeshareStgModel provisoCodeshareStgModel);
}
