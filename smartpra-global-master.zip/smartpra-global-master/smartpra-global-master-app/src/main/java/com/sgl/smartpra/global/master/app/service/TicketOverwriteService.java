package com.sgl.smartpra.global.master.app.service;


import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.model.TicketOverwrite;

@Component
public interface TicketOverwriteService {
	
	TicketOverwrite saveTicketOverwrite(TicketOverwrite ticketOverwriteDao );
	
	TicketOverwrite getTicketOverwrite(Long id);

	TicketOverwrite validateTicketOverwriteDetail(String source1, String source2, String processStatus, String transationCode);
	
	
}
