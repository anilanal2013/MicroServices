package com.sgl.smartpra.global.master.app.dao.entity.spec;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ChargeCategoryEntity;

public class ChaCatEntitySpec{

	public static Specification<ChargeCategoryEntity> search(Optional<String> chargeCategoryCode,
			Optional<String> chargeCategoryName, Optional<Boolean> activate) {
		return (chargeCategoryEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(chargeCategoryCode)) {
				predicates.add(criteriaBuilder.like(chargeCategoryEntity.get("chargeCategoryCode"),
						OptionalUtil.getValue(chargeCategoryCode) + "%"));
			}
			if (OptionalUtil.isPresent(chargeCategoryName)) {
				predicates.add(criteriaBuilder.like(chargeCategoryEntity.get("chargeCategoryName"),
						OptionalUtil.getValue(chargeCategoryName) + "%"));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(
						criteriaBuilder.equal(chargeCategoryEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ChargeCategoryEntity> findOne(Optional<String> chargeCategoryCode) {
		return (chargeCategoryEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(chargeCategoryCode)) {
				predicates.add(criteriaBuilder.like(chargeCategoryEntity.get("chargeCategoryCode"),
						OptionalUtil.getValue(chargeCategoryCode) + "%"));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}


	public static Specification<ChargeCategoryEntity> findByChargeCategoryName(Optional<String> chargeCategoryName) {
		return (chargeCategoryEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(chargeCategoryName)) {
				predicates.add(criteriaBuilder.like(chargeCategoryEntity.get("chargeCategoryName"),
						OptionalUtil.getValue(chargeCategoryName) + "%"));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}