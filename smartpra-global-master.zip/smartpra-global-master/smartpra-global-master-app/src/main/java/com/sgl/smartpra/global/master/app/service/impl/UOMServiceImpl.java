package com.sgl.smartpra.global.master.app.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.SearchCriteria;
import com.sgl.smartpra.global.master.app.dao.UOMDao;
import com.sgl.smartpra.global.master.app.dao.entity.UOMEntity;
import com.sgl.smartpra.global.master.app.dao.repository.UOMRepository;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.UOMMapper;
import com.sgl.smartpra.global.master.app.service.UOMService;
import com.sgl.smartpra.global.master.model.UOM;

@Service
@Transactional
public class UOMServiceImpl implements UOMService {

	@Autowired
	UOMMapper uomMapper;

	@Autowired
	UOMDao uomDao;

	@Autowired
	private UOMRepository uomRepository;

	private static final String UOM = "uom";

	@Override
	public List<UOM> getAllUom(String uomCode, String uomType) {

		List<SearchCriteria> params = new ArrayList<>();

		params.add(new SearchCriteria("isActive", "=", new Boolean("true")));

		if (uomCode != null && uomCode.length() > 0) {
			params.add(new SearchCriteria("uomCode", "=", uomCode));
		}

		if (uomType != null && uomType.length() > 0) {

			params.add(new SearchCriteria("uomType", "=", uomType));
		}

		return uomMapper.mapToUOMModelList(uomDao.search(params,new UOMEntity()));
	}

	@Override
	public UOM findUomByUomCode(Integer uomId) {

		Optional<UOMEntity> uomEntity = uomRepository.findById(uomId);

		if (uomEntity.isPresent()) {

			// return only if the record is active
			if (uomEntity.get().getIsActive()) {
				return uomMapper.mapToUOMModel(uomEntity.get());
			}

			throw new ServiceException("uom is not active");

		} else {
			throw new ResourceNotFoundException(UOM, "id", uomId);
		}
	}

	@Override
	public UOM createUom(UOM uom) {

		uom.setIsActive(Boolean.TRUE);
		uom.setCreatedDate(new Timestamp(new Date().getTime()));

		return uomMapper.mapToUOMModel(uomRepository.save(uomMapper.mapToUOMEntity(uom)));

	}

	@Override
	public UOM updateUom(Integer uomId, UOM uom) {

		Optional<UOMEntity> uomEntity = uomRepository.findById(uomId);

		if (!uomEntity.isPresent())
			throw new ResourceNotFoundException(UOM, "id", uomId);

		if (!uomEntity.get().getIsActive()) {
			throw new ServiceException("uom is not active");
		}

		uomEntity.get().setUomCode(uom.getUomCode());
		uomEntity.get().setUomType(uom.getUomType());
		uomEntity.get().setUomValue(uom.getUomValue());
		uomEntity.get().setLastUpdatedBy(uom.getLastUpdatedBy());
		uomEntity.get().setLastUpdatedDate(new Timestamp(new Date().getTime()));
		return uomMapper.mapToUOMModel(uomRepository.save(uomEntity.get()));
	}

	@Override
	public void deactivateUom(Integer uomId, String lastUpdatedBy) {

		Optional<UOMEntity> uomEntity = uomRepository.findById(uomId);

		if (!uomEntity.isPresent())
			throw new ResourceNotFoundException(UOM, "id", uomId);

		if (!uomEntity.get().getIsActive())
			throw new ServiceException("uom is already in deactivated state");

		uomEntity.get().setLastUpdatedBy(lastUpdatedBy);
		uomEntity.get().setLastUpdatedDate(new Timestamp(new Date().getTime()));
		uomEntity.get().setIsActive(Boolean.FALSE);

		uomRepository.save(uomEntity.get());

	}

	@Override
	public void activateUom(Integer uomId, String lastUpdatedBy) {

		Optional<UOMEntity> uomEntity = uomRepository.findById(uomId);

		if (!uomEntity.isPresent())
			throw new ResourceNotFoundException(UOM, "code", uomId);

		if (uomEntity.get().getIsActive())
			throw new ServiceException("uom is already in active state");

		uomEntity.get().setLastUpdatedBy(lastUpdatedBy);
		uomEntity.get().setLastUpdatedDate(new Timestamp(new Date().getTime()));
		uomEntity.get().setIsActive(Boolean.TRUE);
		uomRepository.save(uomEntity.get());
	}

	@Override
	public boolean isValidUomType(String uomType) {
		List<SearchCriteria> params = new ArrayList<>();

		params.add(new SearchCriteria("isActive", "=", new Boolean("true")));

		if (uomType != null && uomType.length() > 0) {

			params.add(new SearchCriteria("uomType", "=", uomType));
		}

		if (uomMapper.mapToUOMModelList(uomDao.search(params,new UOMEntity())).size() > 0)
			return true;
		else
			return false;

	}

}
