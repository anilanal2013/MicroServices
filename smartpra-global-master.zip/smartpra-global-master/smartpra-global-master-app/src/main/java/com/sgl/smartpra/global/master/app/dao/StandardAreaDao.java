package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.StandardAreaEntity;

@Repository
public interface StandardAreaDao {

	public Optional<StandardAreaEntity> findById(String standardAreaCode);

	public List<StandardAreaEntity> search(Optional<String> standardAreaCode, Optional<String> standardAreaName,
			Boolean activate);

	public StandardAreaEntity create(StandardAreaEntity mapToEntity);

	public StandardAreaEntity update(StandardAreaEntity standardAreaEntity);

	public List<StandardAreaEntity> findByStandardAreaList(String cityCode, String stateCode, String countryCode);

	public long isValidateStandardArea(String standardAreaCode);
	
	public List<StandardAreaEntity> findDistinctByStandardAreaCodeIsNotNullAndIsActiveTrueOrderByStandardAreaCode();

	public StandardAreaEntity findByStandardAreaCodeAndActivate(String standardAreaCode);

}
