package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoRoutingStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoRoutingStgEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoRoutingStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoRoutingStgDaoImpl implements ProvisoRoutingStgDao {
	@Autowired
	private ProvisoRoutingStgRepository provisoRoutingStgRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "provisoRoutingStg", key = "#provisoRoutingStgEntity.provisoRoutingId") })
	public ProvisoRoutingStgEntity create(ProvisoRoutingStgEntity provisoRoutingStgEntity) {
		return provisoRoutingStgRepository.save(provisoRoutingStgEntity);
	}

	@Override
	public List<ProvisoRoutingStgEntity> findByMainId(Optional<Integer> provisoMainId) {
		return provisoRoutingStgRepository.findAll(ProvisoRoutingStgEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	@Cacheable(value = "provisoRoutingStg", key = "#id")
	public Optional<ProvisoRoutingStgEntity> findById(Integer id) {
		log.info("Cacheable Proviso Routing Entity's ID= {}", id);
		return provisoRoutingStgRepository.findById(id);
	}

	@Override
	public List<ProvisoRoutingStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber) {
		return provisoRoutingStgRepository.findAll(
				ProvisoRoutingStgEntitySpecification.search(carrierNumCode, provisoSeqNumber, detailRecNumber));
	}

	@Override
	@CachePut(value = "provisoRoutingStg", key = "#provisoRoutingStgEntity.provisoRoutingId")
	@CacheEvict(value = "ProvisoRoutingSearch", allEntries = true)
	public ProvisoRoutingStgEntity update(ProvisoRoutingStgEntity provisoRoutingStgEntity) {
		return provisoRoutingStgRepository.save(provisoRoutingStgEntity);
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer detailRecNumber,
			Integer routingRecNumber) {

		return provisoRoutingStgRepository
				.count(Specification.where(ProvisoRoutingStgEntitySpecification.equalsCarrierNumCode(carrierNumCode)
						.and(ProvisoRoutingStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
						.and(ProvisoRoutingStgEntitySpecification.equalsDetailRecNumber(detailRecNumber)))
						.and(ProvisoRoutingStgEntitySpecification.equalsRoutingRecNumber(routingRecNumber)));
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer detailRecNumber,
			Integer routingRecNumber, Integer provisoRoutingId) {

		return provisoRoutingStgRepository
				.count(Specification.where(ProvisoRoutingStgEntitySpecification.equalsCarrierNumCode(carrierNumCode)
						.and(ProvisoRoutingStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
						.and(ProvisoRoutingStgEntitySpecification.equalsDetailRecNumber(detailRecNumber))
						.and(ProvisoRoutingStgEntitySpecification.equalsRoutingRecNumber(routingRecNumber))
						.and(ProvisoRoutingStgEntitySpecification.notEqualsProvisoRoutingId(provisoRoutingId))));
	}

	@Override
	public List<Integer> getListOfProvisoMainIdFromRoutingStgDb() {

		return provisoRoutingStgRepository.getListOfProvisoMainIdFromRoutingStgDb();
	}

	@Override
	public void deleteProvisoRoutingByProvisoMainId(Integer provisoMainId) {
		provisoRoutingStgRepository.deleteProvisoRoutingByProvisoMainId(provisoMainId);
	}

	@Override
	public void deleteProvisoRoutingByProvisoRoutingId(Integer provisoRoutingId) {
		provisoRoutingStgRepository.deleteById(provisoRoutingId);
	}

	@Override
	public void deleteProvisoRoutingByCarrierNumSeqRecNumber(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<Integer> detailRecNumber) {
		provisoRoutingStgRepository.deleteProvisoRoutingByCarrierNumSeqRecNumber(carrierNumCode, provisoSeqNumber,
				detailRecNumber);
	}

	@Override
	public Integer getMaxOfProvisoRoutingRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber) {
		return provisoRoutingStgRepository.getMaxOfProvisoRoutingRecNumber(carrierNumCode, provisoSeqNumber,
				detailRecNumber);
	}
}
