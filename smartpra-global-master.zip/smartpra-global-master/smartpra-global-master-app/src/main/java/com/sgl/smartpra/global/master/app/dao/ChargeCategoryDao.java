package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ChargeCategoryEntity;

@Repository
public interface ChargeCategoryDao {

	public List<ChargeCategoryEntity> findAll(Optional<String> chargeCategoryCode, Optional<String> chargeCategoryName,
			Optional<Boolean> activate);

	public Optional<ChargeCategoryEntity> findOne(Optional<String> chargeCategoryCode);
	
	public Optional<ChargeCategoryEntity> findId(Optional<String> chargeCategoryCode);

	public ChargeCategoryEntity create(ChargeCategoryEntity chargeCategoryEntity);
	
	public Optional<ChargeCategoryEntity> findByChargeCategoryName(Optional<String> chargeCategoryName);

	public List<ChargeCategoryEntity> update(List<ChargeCategoryEntity> chargeEntity);

	public ChargeCategoryEntity update(ChargeCategoryEntity chargeEntity);
	
	public List<String> getChargeCatCodeFromChargeCatMaster();

}
