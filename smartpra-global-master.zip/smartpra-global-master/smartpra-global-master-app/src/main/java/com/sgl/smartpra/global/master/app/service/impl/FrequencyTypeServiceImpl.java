package com.sgl.smartpra.global.master.app.service.impl;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.FrequencyTypeMapper;
import com.sgl.smartpra.global.master.app.repository.FrequencyTypeRepository;
import com.sgl.smartpra.global.master.app.repository.entity.FrequencyType;
import com.sgl.smartpra.global.master.app.service.FrequencyTypeService;
import com.sgl.smartpra.global.master.model.FrequencyTypeDTO;

/**
 * Service Implementation for managing FrequencyType.
 */
@Service
@Transactional
public class FrequencyTypeServiceImpl implements FrequencyTypeService {

    private final Logger log = LoggerFactory.getLogger(FrequencyTypeServiceImpl.class);

    @Autowired
    FrequencyTypeRepository frequencyTypeRepository;

    @Autowired
    FrequencyTypeMapper frequencyTypeMapper;

    public FrequencyTypeServiceImpl(FrequencyTypeRepository frequencyTypeRepository, FrequencyTypeMapper frequencyTypeMapper) {
        this.frequencyTypeRepository = frequencyTypeRepository;
        this.frequencyTypeMapper = frequencyTypeMapper;
    }

    /**
     * Save a frequencyType.
     *
     * @param frequencyTypeDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public FrequencyTypeDTO save(FrequencyTypeDTO frequencyTypeDTO) {
        log.debug("Request to save FrequencyType : {}", frequencyTypeDTO);
        FrequencyType frequencyType = frequencyTypeMapper.toEntity(frequencyTypeDTO);
        frequencyType = frequencyTypeRepository.save(frequencyType);
        return frequencyTypeMapper.toDto(frequencyType);
    }

    /**
     * Get all the frequencyTypes.
     *
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public List<FrequencyTypeDTO> findAll() {
        log.debug("Request to get all FrequencyTypes");
        return frequencyTypeRepository.findAll().stream()
            .map(frequencyTypeMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one frequencyType by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public FrequencyTypeDTO findOne(Long id) {
        log.debug("Request to get FrequencyType : {}", id);
        
        Optional<FrequencyTypeDTO> frequencyTypeDTO = frequencyTypeRepository.findById(id).map(frequencyTypeMapper::toDto);
        if(frequencyTypeDTO.isPresent()) {
        	return frequencyTypeDTO.get();
        }else {
			throw new ResourceNotFoundException("FrequencyType", "code", id);
		}
         
    }

    /**
     * Delete the frequencyType by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete FrequencyType : {}", id);        frequencyTypeRepository.deleteById(id);
    }
}
