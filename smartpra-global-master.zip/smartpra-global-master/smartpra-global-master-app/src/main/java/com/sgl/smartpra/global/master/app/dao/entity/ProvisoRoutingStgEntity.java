package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_proviso_routing_stg")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class ProvisoRoutingStgEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "proviso_routing_id", nullable = false)
	private Integer provisoRoutingId;

	@Column(name = "proviso_main_id", nullable = false)
	private Integer provisoMainId;

	@Column(name = "carrier_num_code", nullable = false, length = 3)
	private String carrierNumCode;

	@Column(name = "proviso_seq_number", nullable = false)
	private Integer provisoSeqNumber;

	@Column(name = "detail_rec_number", nullable = false)
	private Integer detailRecNumber;

	@Column(name = "routing_rec_number", nullable = false)
	private Integer routingRecNumber;

	@Column(name = "area_type_flag", nullable = false, length = 1)
	private String areaTypeFlag;

	@Column(name = "area_check_type", nullable = false, length = 1)
	private String areaCheckType;

	@Column(name = "area_from", nullable = false, length = 4)
	private String areaFrom;

	@Column(name = "area_to", length = 4)
	private String areaTo;

	@Column(name = "area_via", length = 4)
	private String areaVia;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}