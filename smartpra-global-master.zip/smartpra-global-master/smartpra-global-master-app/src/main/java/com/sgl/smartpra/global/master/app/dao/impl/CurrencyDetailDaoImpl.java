package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.CurrencyDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.CurrencyDetailEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.CurrencyDetailEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.CurrencyDetailRepository;
import com.sgl.smartpra.global.master.model.Currency;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CurrencyDetailDaoImpl extends CommonSearchDao<Currency> implements CurrencyDetailDao {
	
	@Autowired
	private CurrencyDetailRepository currencyDetailRepository;
	
	@Override
	@Cacheable(value = "currencyDetail", key = "#currencyDetailId")
	public Optional<CurrencyDetailEntity> findById(Integer currencyDetailId) {
		log.info("Cacheable Currency Detail Entity's ID= {}", currencyDetailId);
		return currencyDetailRepository.findById(currencyDetailId);
	}	
	
	@Override
	@Caching(evict = { @CacheEvict(value = "currencyDetail", key = "#currencyDetailEntity.currencyDetailId"),
			@CacheEvict(value = "currencyCode", allEntries = true),@CacheEvict(value = "effectiveDate", allEntries = true) })
	public CurrencyDetailEntity create(CurrencyDetailEntity currencyDetailEntity) {
		return currencyDetailRepository.save(currencyDetailEntity);
	}
	 
	@Override
	@CachePut(value = "currencyDetail", key = "#currencyDetailEntity.currencyDetailId")
	@Caching(evict = { @CacheEvict(value = "currencyCode", allEntries = true),@CacheEvict(value = "effectiveDate", allEntries = true)})
	public CurrencyDetailEntity update(CurrencyDetailEntity currencyDetailEntity) {
		return currencyDetailRepository.save(currencyDetailEntity);
	}
	
	@Override
	@Caching(evict = { @CacheEvict(value = "currencyDetail", key = "#currencyDetailId"), 
			@CacheEvict(value = "currencyCode", allEntries = true),@CacheEvict(value = "effectiveDate", allEntries = true)})
	public void deleteById(Integer currencyDetailId) {
		currencyDetailRepository.deleteById(currencyDetailId);
	}	
	
	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String currencyCode) {
		return currencyDetailRepository.count(Specification.where(CurrencyDetailEntitySpecification.equalsCurrencyCode(currencyCode))
				.and(CurrencyDetailEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(CurrencyDetailEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.or(CurrencyDetailEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate))));
	}

	@Override
	public List<CurrencyDetailEntity> getAllCurrencyDetails(Optional<String> currencyCode,
			Optional<String> effectiveDate) {
		return currencyDetailRepository.findAll(CurrencyDetailEntitySpecification.search(currencyCode, effectiveDate));
	}

	@Override
	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, String currencyCode,
			Integer currencyDtlId) {
		return currencyDetailRepository.count(Specification.where(CurrencyDetailEntitySpecification.equalsCurrencyCode(currencyCode))
				.and(CurrencyDetailEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(CurrencyDetailEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.or(CurrencyDetailEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate)))
				.and(CurrencyDetailEntitySpecification.notEqualsCurrencyDtlId(currencyDtlId)));
	}

	@Override
	@Cacheable({"currencyCode","effectiveDate"})
	public CurrencyDetailEntity getCurrencyByCurrencyCodeAndEffectiveDate(String currencyCode, Optional<String> effectiveDate) {
		return currencyDetailRepository.findOne(CurrencyDetailEntitySpecification.equalsCurrencyCode(currencyCode)
				.and(CurrencyDetailEntitySpecification.betweenEffectiveFromAndEffectiveToDate(OptionalUtil.getLocalDateValue(effectiveDate))))
				.orElse(new CurrencyDetailEntity());
	}
		
}
