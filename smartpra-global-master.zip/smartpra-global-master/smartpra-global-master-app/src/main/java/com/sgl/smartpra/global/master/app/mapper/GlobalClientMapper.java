package com.sgl.smartpra.global.master.app.mapper;

import com.sgl.smartpra.global.master.app.dao.entity.GlobalClientEntity;
import com.sgl.smartpra.global.master.model.GlobalClient;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface GlobalClientMapper extends BaseMapper<GlobalClient, GlobalClientEntity> {

    GlobalClientEntity mapToEntity(GlobalClient globalClient, @MappingTarget GlobalClientEntity globalClientEntity);

    GlobalClientEntity mapToEntity(GlobalClient globalClient);
}
