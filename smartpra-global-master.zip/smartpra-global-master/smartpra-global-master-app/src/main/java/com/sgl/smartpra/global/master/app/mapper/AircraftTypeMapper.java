package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.AircraftTypeEntity;
import com.sgl.smartpra.global.master.model.AircraftType;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AircraftTypeMapper extends BaseMapper<AircraftType, AircraftTypeEntity>{

	AircraftTypeEntity mapToEntity(AircraftType aircraftType, @MappingTarget AircraftTypeEntity aircraftTypeEntity);

	AircraftTypeEntity mapToEntity(AircraftType aircraftType);
}
