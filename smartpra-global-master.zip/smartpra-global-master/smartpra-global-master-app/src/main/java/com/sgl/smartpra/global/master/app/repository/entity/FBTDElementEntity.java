package com.sgl.smartpra.global.master.app.repository.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.global.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_fbtd_element")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class FBTDElementEntity extends BaseEntity {
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "fbtd_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer fbtdId;

	@Column(name = "element_type", nullable = false)
	private Integer elementType;

	@Column(name = "element_code", nullable = false, length = 2)
	private String elementCode;

	@Column(name = "element_description", length = 60)
	private String elementDescription;

	@Column(name = "additional_info", length = 1)
	private String additionalInfo;

	@Column(name = "other_info", length = 1)
	private String otherInfo;

	@Column(name = "normal_special", length = 1)
	private String normalSpecial;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
