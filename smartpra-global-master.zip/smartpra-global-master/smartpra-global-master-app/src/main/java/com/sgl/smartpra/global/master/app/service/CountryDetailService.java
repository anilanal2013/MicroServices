package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.Country;
import com.sgl.smartpra.global.master.model.CountryDetail;

public interface CountryDetailService {

	public CountryDetail getCountryDetailByCounryDetailCode(String countryCode, Integer countryDtlId);

	public CountryDetail createCountryDetail(CountryDetail countryDetail, String countryCode);

	public List<CountryDetail> getListOfCountryDetails(String countryCode, Optional<String> effectiveDate);

	public CountryDetail updateCountryDetail(Integer countryDtlId, CountryDetail countryDetail);

	public void deleteCountryDetail(String countryCode, Integer countryDtlId);

	public List<CountryDetail> findCountryCodeByCountryCodeAndCabinClass(String countryCode);
	
	public List<CountryDetail> copyCountryDetailsRecordByCountryCode(Country country);
	
	public CountryDetail getCountryDetailsByEffectiveDate(String countryCode, String effectiveDate);

}