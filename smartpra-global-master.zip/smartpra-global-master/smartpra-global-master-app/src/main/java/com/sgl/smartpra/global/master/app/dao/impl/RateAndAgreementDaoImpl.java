package com.sgl.smartpra.global.master.app.dao.impl;

import com.sgl.smartpra.global.master.app.dao.RateAndAgreementDao;
import com.sgl.smartpra.global.master.app.dao.entity.RateAndAgreementEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.RateAndAgreementEntitySpecifcation;
import com.sgl.smartpra.global.master.app.dao.repository.RateAndAgreementRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;


@Component
@Slf4j
public class RateAndAgreementDaoImpl implements RateAndAgreementDao {

    @Autowired
    private RateAndAgreementRepository rateAndAgreementRepository;

    @Override
    @Caching(evict= {@CacheEvict(value="rateAndAgreementEntity",key = "#rateAndAgreementEntity.rateAgreementId")})
    public RateAndAgreementEntity create(RateAndAgreementEntity rateAndAgreementEntity) {
        return rateAndAgreementRepository.save(rateAndAgreementEntity);
    }

    @Override
    @CachePut(value = "rateAndAgreementEntity", key = "#rateAndAgreementEntity.rateAgreementId")
    @CacheEvict(value = "rateAndAgreementEntitySearch", allEntries = true)
    public RateAndAgreementEntity update(RateAndAgreementEntity rateAndAgreementEntity) {
        return rateAndAgreementRepository.save(rateAndAgreementEntity);
    }

    @Override
    public Optional<RateAndAgreementEntity> findById(Integer id) {
        return rateAndAgreementRepository.findById(id);
    }

    @Override
    public List<RateAndAgreementEntity> fetchAll(Optional<String> supplierCode, Optional<String> baseLocation, Optional<String> chargeCategory, Optional<String> chargeCode, Optional<String> effectivePeriodFrom, Optional<String> effectivePeriodTo, Optional<String> airport) {
        return rateAndAgreementRepository.findAll(RateAndAgreementEntitySpecifcation.search(supplierCode,baseLocation,chargeCategory,chargeCode,effectivePeriodFrom,effectivePeriodTo,airport));
    }

    @Override
    @CacheEvict(value = "rateAndAgreementEntity" , key = "#rateAgreementId")
    public Boolean delete(Integer rateAgreementId) {
        Boolean flag = Boolean.FALSE;
        try {
            rateAndAgreementRepository.deleteById(rateAgreementId);
            flag = Boolean.TRUE;
        } catch(Exception e){
        	flag = Boolean.FALSE;
            log.error("Exc : ",e);
        }
        return flag;
    }
}
