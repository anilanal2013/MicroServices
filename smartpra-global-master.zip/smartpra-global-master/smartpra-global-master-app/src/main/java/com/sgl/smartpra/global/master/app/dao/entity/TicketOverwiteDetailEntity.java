package com.sgl.smartpra.global.master.app.dao.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;


/**
 * The persistent class for the global_mas_tkt_overwite_detail database table.
 * 
 */
@Entity
@Table(name="global_mas_tkt_overwite_detail")
@NamedQuery(name="TicketOverwiteDetailEntity.findAll", query="SELECT g FROM TicketOverwiteDetailEntity g")
public class TicketOverwiteDetailEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="scenrio_dtl_id")
	private Long scenrioDtlId;

	@Column(name="column_name")
	private String columnName;

	@Column(name="table_name")
	private String tableName;

	//bi-directional many-to-one association to TicketOverwrite
	@ManyToOne
	@JoinColumn(name="scenario_no")
	private TicketOverwriteEntity ticketOverwrite;

	public TicketOverwiteDetailEntity() {
	}

	public Long getScenrioDtlId() {
		return this.scenrioDtlId;
	}

	public void setScenrioDtlId(Long scenrioDtlId) {
		this.scenrioDtlId = scenrioDtlId;
	}

	public String getColumnName() {
		return this.columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getTableName() {
		return this.tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public TicketOverwriteEntity getTicketOverwrite() {
		return this.ticketOverwrite;
	}

	public void setTicketOverwrite(TicketOverwriteEntity ticketOverwrite) {
		this.ticketOverwrite = ticketOverwrite;
	}
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
		setCreatedBy("ADMIN");
	}

	@PreUpdate
	public void preUpdate() {
		setCreatedDate(LocalDateTime.now());
		setCreatedBy("ADMIN");
	}

}