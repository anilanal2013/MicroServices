package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoCodeshareDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoCodeshareEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoCodeshareRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoCodeshareDaoImpl implements ProvisoCodeshareDao {
	@Autowired
	private ProvisoCodeshareRepository provisoCodeshareRepository;

	SessionFactory sessionFactory;
	Session session;

	@Override
	@Cacheable(value = "provisoCodeshareModel", key = "#id")
	public Optional<ProvisoCodeshareEntity> findById(Integer id) {
		log.info("Cacheable Proviso Main Entity's ID= {}", id);
		return provisoCodeshareRepository.findById(id);
	}

	@Override
	public List<ProvisoCodeshareEntity> searchByProvisoMain(Optional<Integer> provisoMainId, Optional<String> areaFrom,
			Optional<String> areaTo) {

		return provisoCodeshareRepository
				.findAll(ProvisoCodeshareEntitySpecification.search(provisoMainId, areaFrom, areaTo));
	}

	@Override
	public List<ProvisoCodeshareEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> provisoSection, Optional<String> areaFrom, Optional<String> areaTo) {

		return provisoCodeshareRepository.findAll(ProvisoCodeshareEntitySpecification.search(carrierNumCode,
				provisoSeqNumber, provisoSection, areaFrom, areaTo));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "provisoCodeshareModel", key = "#provisoCodeshareEntity.provisoMainId") })
	public ProvisoCodeshareEntity create(ProvisoCodeshareEntity provisoCodeshareEntity) {
		return provisoCodeshareRepository.save(provisoCodeshareEntity);
	}

	@Override
	public List<ProvisoCodeshareEntity> findByMainId(Optional<Integer> provisoMainId) {
		log.info("Cacheable Proviso Codeshare Entity's ID= {}", provisoMainId);
		return provisoCodeshareRepository.findAll(ProvisoCodeshareEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	public List<Integer> getListOfProvisoMainIdFromRoutingDb() {

		return provisoCodeshareRepository.getListOfProvisoMainIdFromCodeshareDb();
	}
}
