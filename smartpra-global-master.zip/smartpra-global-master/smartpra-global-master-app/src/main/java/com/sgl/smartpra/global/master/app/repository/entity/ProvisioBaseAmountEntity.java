package com.sgl.smartpra.global.master.app.repository.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.global.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "global_mas_provisio_baseamount ")
public class ProvisioBaseAmountEntity extends BaseEntity {

	@Id
	@Column(name = "provisio_base_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer provisoBaseid;

	@Column(name = "change_ind")
	private String changeIndicator;

	@Column(name = "addendum_file_id")
	private Integer addendumFileId;

	@Column(name = "inbound_file_id")
	private Integer inboundFileId;

	@Column(name = "from_city_code", nullable = false, length = 3)
	private String fromCityCode;

	@Column(name = "to_city_code", nullable = false, length = 3)
	private String toCityCode;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;

	@Column(name = "class_code", nullable = false, length = 1)
	private String classCode;

	@Column(name = "carrier_code", nullable = false, length = 2)
	private String carrierCode;

	@Column(name = "alpha_currency_code", nullable = false, length = 3)
	private String alphaCurrencyCode;

	@Column(name = "provisio_base_amount", nullable = false)
	private BigDecimal provisoBaseAmount;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void setCreatedDate() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void setLastUpdatedDate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
