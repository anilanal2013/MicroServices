package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.FrequencyTypeDTO;

/**
 * Service Interface for managing FrequencyType.
 */
public interface FrequencyTypeService {

    /**
     * Save a frequencyType.
     *
     * @param frequencyTypeDTO the entity to save
     * @return the persisted entity
     */
    FrequencyTypeDTO save(FrequencyTypeDTO frequencyTypeDTO);

    /**
     * Get all the frequencyTypes.
     *
     * @return the list of entities
     */
    List<FrequencyTypeDTO> findAll();


    /**
     * Get the "id" frequencyType.
     *
     * @param id the id of the entity
     * @return the entity
     */
   FrequencyTypeDTO findOne(Long id);

    /**
     * Delete the "id" frequencyType.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
