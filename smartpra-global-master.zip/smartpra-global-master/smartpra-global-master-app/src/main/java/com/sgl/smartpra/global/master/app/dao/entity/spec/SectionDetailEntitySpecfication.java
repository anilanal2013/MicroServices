package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.SectionDetailEntity;

public class SectionDetailEntitySpecfication {

	public static Specification<SectionDetailEntity> search(Integer sectionMasterId, Integer sectionDetailId,
			Optional<String> sectionElementName, Optional<Boolean> activate) {

		return (sectionDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (sectionMasterId != null) {
				predicates.add(criteriaBuilder.equal(sectionDetailEntity.get("sectionMasterId"), sectionMasterId));
			}

			if (OptionalUtil.isPresent(sectionElementName)) {
				predicates.add(criteriaBuilder.like(sectionDetailEntity.get("sectionElementName"),
						OptionalUtil.getValue(sectionElementName) + "%"));
			}

			if (OptionalUtil.isPresent(activate)) {
				predicates.add(
						criteriaBuilder.equal(sectionDetailEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(sectionDetailEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<SectionDetailEntity> getOrderNumber(Optional<String> orderNumber) {

		return (sectionDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(sectionDetailEntity.get("orderNumber"), OptionalUtil.getValue(orderNumber));
	}

	public static Specification<SectionDetailEntity> getByDisplayOrderNumber(Integer sectionMasterId, Integer sectionDetailId, Optional<String> displayOrderNumber) {

		return (sectionDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			predicates.add(criteriaBuilder.equal(sectionDetailEntity.get("sectionMasterId"), sectionMasterId));
			predicates.add(criteriaBuilder.notEqual(sectionDetailEntity.get("sectionDetailId"), sectionDetailId));
			predicates.add(criteriaBuilder.equal(sectionDetailEntity.get("displayOrderNumber"), OptionalUtil.getValue(displayOrderNumber)));
			predicates.add(criteriaBuilder.equal(sectionDetailEntity.get("displayIndicator"), true));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<SectionDetailEntity> getListOfSectionDetailsByChargeCode(List<Integer> sections, Optional<String> sectionElementName, Optional<Boolean> activate) {
		return (sectionDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			predicates.add(sectionDetailEntity.get("sectionMasterId").in(sections));
			if (sectionElementName != null && sectionElementName.isPresent()) {
				predicates.add(criteriaBuilder.like(sectionDetailEntity.get("sectionElementName"), sectionElementName.get()+ "%"));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(sectionDetailEntity.get("activate"), activate.get()));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
		
	}

}
