package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.CarrierDetailEntity;

public interface CarrierDetailDao {
	
	public Optional<CarrierDetailEntity> findById(Integer carrierDetailId);

	public CarrierDetailEntity create(CarrierDetailEntity carrierEntity);

	public CarrierDetailEntity update(CarrierDetailEntity carrierEntity);

	public List<CarrierDetailEntity> findAll(Optional<String> carrierCode, Optional<String> effectiveDate);
	
	void deleteById(Integer id);
	
    public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String carrierCode);
	
	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, String carrierCode, Integer carrierDetailId);
}
