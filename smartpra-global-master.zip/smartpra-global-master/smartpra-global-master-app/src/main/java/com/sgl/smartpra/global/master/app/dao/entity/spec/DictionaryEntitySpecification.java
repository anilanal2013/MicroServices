package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.repository.entity.DictionaryEntity;

public class DictionaryEntitySpecification {

	public static Specification<DictionaryEntity> search(Optional<String> elementName, Optional<String> dictionaryDefine) {
		return (dictionaryEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(elementName)) {
				predicates.add(
						criteriaBuilder.like(dictionaryEntity.get("elementName"), OptionalUtil.getValue(elementName)+"%"));
			}
			
			if (OptionalUtil.isPresent(dictionaryDefine)) {
				predicates.add(
						criteriaBuilder.like(dictionaryEntity.get("dictionaryDefine"), OptionalUtil.getValue(dictionaryDefine)+"%"));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
