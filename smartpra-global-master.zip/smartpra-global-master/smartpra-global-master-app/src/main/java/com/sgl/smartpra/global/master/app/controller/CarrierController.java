package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.CarrierService;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.CommonIdName;

@RestController
public class CarrierController {

	@Autowired
	CarrierService carrierService;

	@GetMapping("/carriers")
	public List<Carrier> getAllCarrier(@RequestParam(value = "carrierCode", required = false) @Valid Optional<String> carrierCode,
			@RequestParam(value = "carrierDesignatorCode", required = false) Optional<String> carrierDesignatorCode,
			@RequestParam(value = "carrierName1", required = false) Optional<String> carrierName1,
			@RequestParam(value = "carrierName2", required = false) Optional<String> carrierName2,
			@RequestParam(value = "isActive", required = false) Optional<Boolean> isActive,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {
		return carrierService.getAllCarrier(carrierCode, carrierDesignatorCode, carrierName1, carrierName2,isActive, exceptionCall);
	}

	@GetMapping("/carriers/{carrierCode}")
	public Carrier getCarrierByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode) {
		return carrierService.findCarrierByCarrierCode(carrierCode);
	}
	
	@GetMapping("/carriers/active-carrierCode")
	public Carrier getActiveCarrierByCarrierCode(
			@RequestParam(value = "carrierCode", required = true) String carrierCode) {
		return carrierService.getCarrierByCarrierCode(carrierCode);
	}
	
	@GetMapping("/carriers/active-carrierDesignatorCode")
	public Carrier getCarrierByCarrierDesignatorCode(
			@RequestParam(value = "carrierDesignatorCode",required=true) String carrierDesignatorCode) {
		return carrierService.findCarrierByCarrierDesignatorCode(carrierDesignatorCode);
	}

	@PostMapping("/carriers")
	public Carrier createCarrier(@Validated(Create.class) @RequestBody Carrier carrier) {
		return carrierService.createCarrier(carrier);
	}

	@PutMapping("/carriers/{carrierCode}")
	public Carrier updateCarrier(@PathVariable(value = "carrierCode") String carrierCode,
			@Validated(Update.class) @RequestBody Carrier carrier) {
		return carrierService.updateCarrier(carrierCode, carrier);
	}

	@PutMapping("/carriers/{carrierCode}/deactivate")
	public void deactivateCarrier(@Valid @PathVariable(value = "carrierCode") String carrierCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		carrierService.deactivateCarrier(carrierCode, lastUpdatedBy);
	}

	@PutMapping("/carriers/{carrierCode}/activate")
	public void activateCarrier(@Valid @PathVariable(value = "carrierCode") String carrierCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		carrierService.activateCarrier(carrierCode, lastUpdatedBy);

	}

	@GetMapping("/carriers/{carrierCode}/validate")
	public boolean validatCarrierCode(@Valid @PathVariable(value = "carrierCode") String carrierCode) {
		return carrierService.isValidCarrierCode(carrierCode);
	}

	@GetMapping("/carriers/carrierDesignatorCode/validate/{carrierDesignatorCode}")
	public boolean isValidCarrierDesignatorCode(@PathVariable("carrierDesignatorCode") String carrierDesignatorCode) {
		return carrierService.isValidCarrierDesignatorCode(carrierDesignatorCode);
	}
	
	@GetMapping("/carriers/carrierDesignatorCodeList/validate/{carrierDesignatorCode}")
	public boolean isValidcarrierDesignatorCodeList(@PathVariable("carrierDesignatorCode") String carrierDesignatorCode) {
		return carrierService.isValidcarrierDesignatorCodeList(carrierDesignatorCode);
	}
	
	@PostMapping("/carriers/validate")
	public List<String> validateCarrrierCodeList(@RequestBody List<String> carrierCodeList) {
		return carrierService.getValidCarrierCode(carrierCodeList);
	}
	
	@PostMapping("/carriers/carrierDetails")
	public List<Carrier> carrierDetails(@RequestBody List<String> carrierCodeList) {
		return carrierService.getValidCarrierDetails(carrierCodeList);
	}
	

	@GetMapping("/carriers/getCarrierCode/{carrierDesignatorCode}")
	public String getCarrrierCodeByCarrierDesignatorCode(
			@PathVariable(value = "carrierDesignatorCode") String carrierDesignatorCode) {
		return carrierService.getCarrrierCodeByCarrierDesignatorCode(carrierDesignatorCode);
	}
	
	@GetMapping("/carriers/carrier-list")
	public List<CommonIdName> getCarrierList() {
		return carrierService.getCarrierList();
	}
	
	@GetMapping("/carriers/validate/{carrierDesignatorCode}/{carrierCode}")
	public boolean isValidCarrier(@Valid @PathVariable("carrierDesignatorCode") String carrierDesignatorCode,@Valid @PathVariable(value = "carrierCode") String carrierCode) {
		return carrierService.isValidCarrier(carrierDesignatorCode,carrierCode);
	}
}
