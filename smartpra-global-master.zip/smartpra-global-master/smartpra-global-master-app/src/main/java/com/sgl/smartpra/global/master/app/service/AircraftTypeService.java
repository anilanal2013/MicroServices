package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.AircraftType;

public interface AircraftTypeService {

	AircraftType findAircraftTypeById(Optional<String> aircraftTypeCode);

    List<AircraftType> findAircraftType();
}
