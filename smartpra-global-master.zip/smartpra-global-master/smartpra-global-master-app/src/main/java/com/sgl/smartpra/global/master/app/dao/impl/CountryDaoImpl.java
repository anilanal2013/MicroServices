package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.CountryDao;
import com.sgl.smartpra.global.master.app.dao.entity.CountryEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.CountryEntitySpecification;
import com.sgl.smartpra.global.master.app.repository.CountryRepository;
import com.sgl.smartpra.global.master.model.Country;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CountryDaoImpl extends CommonSearchDao<Country> implements CountryDao {

	@Autowired
	private CountryRepository countryRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "country", key = "#countryEntity.countryCode"),
			@CacheEvict(value = "countrySearch", allEntries = true) })
	public CountryEntity create(CountryEntity countryEntity) {
		return countryRepository.save(countryEntity);
	}

	@Override
	@CachePut(value = "country", key = "#countryEntity.countryCode")
	@CacheEvict(value = "countrySearch", allEntries = true)
	public CountryEntity update(CountryEntity countryEntity) {
		return countryRepository.save(countryEntity);
	}

	@Override
	@Cacheable(value = "country", key = "#countryCode")
	public Optional<CountryEntity> findByCountryCode(String countryCode) {
		log.info("Cacheable country Entity's ID= {}", countryCode);
		return countryRepository.findById(countryCode);
	}

	@Override
	public List<CountryEntity> getListOfCountries(Optional<String> countryCode, Optional<String> countryName) {
		return countryRepository.findAll(CountryEntitySpecification.getListOfCountries(countryCode, countryName));
	}

	@Override
	public List<CountryEntity> getListOfCountriesByIsActive(Optional<String> countryCode, Optional<String> countryName,
			Optional<Boolean> activate) {
		return countryRepository
				.findAll(CountryEntitySpecification.getListOfCountriesByIsActive(countryCode, countryName, activate));
	}

	@Override
	public List<CountryEntity> findDistinctByCountryCodeIsNotNullAndIsActiveTrueOrderByCountryCode() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Long getCountryCode(String countryCode) {
		return countryRepository.count(CountryEntitySpecification.equalCountryCode(countryCode)
				.and(CountryEntitySpecification.equalsActivate(true)));
	}

	@Override
	public List<String> getCountryCodeList(List<String> countryCodeList) {
		// return countryRepository.findByIdIn(countryCodeList);
		return countryRepository.getCountryCodeList(countryCodeList);
	}

	@Override
	public long validateISOCountryCode(String isoCountryCode) {
		return countryRepository
				.count(Specification.where(CountryEntitySpecification.equalsISOAlpha3CountryCode(isoCountryCode)));
	}

	@Override
	public long validateISOCountryCodeForUpdate(String isoCountryCode, String countryCode) {
		return countryRepository
				.count(Specification.where(CountryEntitySpecification.equalsISOAlpha3CountryCode(isoCountryCode))
						.and(CountryEntitySpecification.notEqualsCountryCode(countryCode)));
	}

	@Override
	public long validateCountryNumber(Integer countryNumber) {
		return countryRepository
				.count(Specification.where(CountryEntitySpecification.equalsCountryNumber(countryNumber)));
	}

	@Override
	public long validateCountryNumberForUpdate(Integer countryNumber, String countryCode) {
		return countryRepository
				.count(Specification.where(CountryEntitySpecification.equalsCountryNumber(countryNumber))
						.and(CountryEntitySpecification.notEqualsCountryCode(countryCode)));
	}

	@Override
	public List<CountryEntity> findDistinctByCountryCodeIsNotNullAndActivateTrueOrderByCountryCode() {

		return countryRepository.findDistinctByCountryCodeIsNotNullAndActivateTrueOrderByCountryCode();
	}
}
