package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.service.UserAreaSrevice;
import com.sgl.smartpra.global.master.model.GlobalUserArea;

@RestController
public class UserAreaController {

	@Autowired
	private UserAreaSrevice userAreaService;
	int parseGlobalUserAreaId = 0;
	private static final String GLOBALUSERDIDCHECK = "globalUserAreaId should be in digit";

	@GetMapping("/user-areas")
	public List<GlobalUserArea> getListOfUserArea(
			@RequestParam(value = "userAreaCode", required = false) String userAreaCode,
			@RequestParam(value = "userAreaName", required = false) String userAreaName) {
		return userAreaService.getListOfUserArea(userAreaCode, userAreaName);
	}

	@GetMapping("/user-area/key-search")
	public GlobalUserArea getUserAreaBasedOnKeys(
			@RequestParam(value = "userAreaCode", required = true) String userAreaCode,
			@RequestParam(value = "areaKey1", required = true) String areaKey1,
			@RequestParam(value = "areaKey2", required = true) String areaKey2,
			@RequestParam(value = "areaKey3", required = true) String areaKey3,
			@RequestParam(value = "areaKey4", required = false) String areaKey4) {
		return userAreaService.getUserAreaBasedOnKeys(userAreaCode,areaKey1,areaKey2,areaKey3,areaKey4);
	}
	
	
	@GetMapping("/user-areas/{globalUserAreaId}")
	public GlobalUserArea getUserAreaByUserAreaCode(@PathVariable(value = "globalUserAreaId") String globalUserAreaId) {
		try {
			parseGlobalUserAreaId = Integer.parseInt(globalUserAreaId);
		} catch (NumberFormatException nfe) {
			throw new ServiceException(GLOBALUSERDIDCHECK);
		}
		return userAreaService.getUserAreaByUserAreaCode(parseGlobalUserAreaId);
	}

	@PostMapping("/user-areas")
	public GlobalUserArea createUserArea(@Validated(Create.class) @RequestBody GlobalUserArea userArea) {
		return userAreaService.createUserArea(userArea);
	}

	@PutMapping("/user-areas/{globalUserAreaId}")
	public GlobalUserArea updateUserArea(@PathVariable(value = "globalUserAreaId") String globalUserAreaId,
			@Validated(Update.class) @RequestBody GlobalUserArea userArea) {
		try {
			parseGlobalUserAreaId = Integer.parseInt(globalUserAreaId);
		} catch (NumberFormatException nfe) {
			throw new ServiceException(GLOBALUSERDIDCHECK);
		}
		return userAreaService.updateUserArea(parseGlobalUserAreaId, userArea);
	}

	@PutMapping("/user-areas/{globalUserAreaId}/deactivate")
	public void deactivateUserArea(@Valid @PathVariable(value = "globalUserAreaId") String globalUserAreaId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		try {
			parseGlobalUserAreaId = Integer.parseInt(globalUserAreaId);
		} catch (NumberFormatException nfe) {
			throw new ServiceException(GLOBALUSERDIDCHECK);
		}
		userAreaService.deactivateUserArea(parseGlobalUserAreaId, lastUpdatedBy);

	}

	@PutMapping("/user-areas/{globalUserAreaId}/activate")
	public void activateUserArea(@Valid @PathVariable(value = "globalUserAreaId") String globalUserAreaId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		try {
			parseGlobalUserAreaId = Integer.parseInt(globalUserAreaId);
		} catch (NumberFormatException nfe) {
			throw new ServiceException(GLOBALUSERDIDCHECK);
		}
		userAreaService.activateUserArea(parseGlobalUserAreaId, lastUpdatedBy);
	}

	@PostMapping("/user-area/insert")
	public void clientSpecificUserAreaInsertOrUpdate(@RequestBody Map<String, String> map) {
		userAreaService.clientSpecificUserAreaInsertOrUpdate(map);
	}

	@GetMapping("/user-area/validate/{areaCode}")
	public boolean isAreaCode(@PathVariable(value = "areaCode") String areaCode) {
		return userAreaService.isValidateAreaCode(areaCode);
	}

}