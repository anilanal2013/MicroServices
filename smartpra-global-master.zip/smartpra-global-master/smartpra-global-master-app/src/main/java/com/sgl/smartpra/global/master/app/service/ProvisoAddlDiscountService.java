package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscount;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscountStg;

public interface ProvisoAddlDiscountService {
	
	public List<ProvisoAdditionalDiscount> getProvisoAddlDiscountByProvisoMainId(Optional<Integer> provisoMainId);

	public ProvisoAdditionalDiscount getProvisoAddlDiscountByProvisoAddlDiscountId(Integer provisoAddlDiscountId);

	public List<ProvisoAdditionalDiscount> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,Optional<String> discountCode);

	public ProvisoAdditionalDiscountStg saveProvisoAddlDiscount(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg);
}
