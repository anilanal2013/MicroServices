package com.sgl.smartpra.global.master.app.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.joda.time.DateTimeComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.MPRDao;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.MPRMapper;
import com.sgl.smartpra.global.master.app.repository.MPRRepository;
import com.sgl.smartpra.global.master.app.repository.entity.MPREntity;
import com.sgl.smartpra.global.master.app.service.MPRService;
import com.sgl.smartpra.global.master.model.MPR;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class MPRServiceImpl implements MPRService {

	@Autowired
	MPRMapper mprMapper;

	@Autowired
	MPRDao mprDao;

	@Autowired
	private MPRRepository mprRepository;

	private static final String LASTUPDATEDBYVALIDLENGTH = "LastUpdatedBy should be minimum of 1 and maximum of 15 characters";
	private static final String MANDATORYLASTUPDATEDBY = "Please provide LastUpdatedBy";
	private static final String MPR = "MPR";
	private static final String MPRINACTIVE = "MPR is already in deactivated state";
	private static final String MPRACTIVE = "MPR is already in activated state";
	public static final String DATE_VALIDATION = "Effective date gets Overlaps";
	public static final String MPR_ALREADY_INACTIVE = "MPR is already in deactivated state";
	public static final String MPR_IS_NOT_ACTIVE = "MPR is not active with  ";

	@Override
	public MPR getMprDetail(Optional<String> effectiveDate) {
		return mprMapper.mapToModel(mprDao.getMprDetails(effectiveDate).get());
	}

	@Override
	public MPR getMprByMinimumProrateRuleId(Integer minimumProrateRuleId) {

		Optional<MPREntity> mprEntity = mprDao.findById(minimumProrateRuleId);
		if (mprEntity.isPresent()) {
			// return only if the record is active
			if (mprEntity.get().getActivate()) {
				return mprMapper.mapToModel(mprEntity.get());
			}
			throw new BusinessException(MPR_IS_NOT_ACTIVE + "id : " + minimumProrateRuleId);
		}
		throw new ResourceNotFoundException("MPR", "id", minimumProrateRuleId);

	}

	public MPR createMpr(MPR mpr) {

		validateMPQValue(mpr.getMpqValue());

		validateMPRPercentage(mpr.getMprPercentage());

		if (OptionalUtil.isPresent(mpr.getEffectiveFromDate()) && OptionalUtil.isPresent(mpr.getEffectiveToDate())) {
			validateEffectiveToDate(OptionalUtil.getLocalDateValue(mpr.getEffectiveFromDate()),
					OptionalUtil.getLocalDateValue(mpr.getEffectiveToDate()));
		}

		if (OptionalUtil.isPresent(mpr.getEffectiveFromDate()) && OptionalUtil.isPresent(mpr.getEffectiveToDate())) {
			validateEffectiveDateForCreate(mpr);
		}

		mpr.setCreatedDate(LocalDateTime.now());
		mpr.setActivate(Boolean.TRUE);
		return mprMapper.mapToModel(mprRepository.save(mprMapper.mapToEntity(mpr)));
	}

	@Override
	public MPR updateMpr(Integer minimumProrateRuleId, MPR mpr) {

		MPREntity mprEntity = mprRepository.findById(minimumProrateRuleId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(minimumProrateRuleId)));
		if (!mprEntity.getActivate())
			throw new BusinessException(MPR_ALREADY_INACTIVE);

		mpr.setMinimumProrateRuleId(minimumProrateRuleId);
		if (OptionalUtil.isPresent(mpr.getMpqValue())) {
			validateMPQValue(mpr.getMpqValue());
		}
		if (OptionalUtil.isPresent(mpr.getMprPercentage())) {
			validateMPRPercentage(mpr.getMprPercentage());
		}
		if (OptionalUtil.isPresent(mpr.getEffectiveFromDate()) && OptionalUtil.isPresent(mpr.getEffectiveToDate())) {
			validateEffectiveToDate(OptionalUtil.getLocalDateValue(mpr.getEffectiveFromDate()),
					OptionalUtil.getLocalDateValue(mpr.getEffectiveToDate()));
		}

		if (OptionalUtil.isPresent(mpr.getEffectiveFromDate()) && OptionalUtil.isPresent(mpr.getEffectiveToDate())) {
			validateEffectiveDateForUpdate(minimumProrateRuleId, mpr, mprEntity);
		}

		mpr.setActivate(Boolean.TRUE);
		mpr.setLastUpdatedDate(LocalDateTime.now());

		return mprMapper.mapToModel(mprDao.update(mprMapper.mapToEntity(mpr, mprEntity)));
	}

	@Override
	public void deactivateMpr(Integer minimumProrateRuleId, String lastUpdatedBy) {
		Optional<MPREntity> mprEntity = mprRepository.findById(minimumProrateRuleId);

		if (!mprEntity.isPresent())
			throw new ResourceNotFoundException(MPR, "id", minimumProrateRuleId);

		if (!mprEntity.get().getActivate())
			throw new BusinessException(MPRINACTIVE);

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		mprEntity.get().setLastUpdatedBy(lastUpdatedBy);
		mprEntity.get().setLastUpdatedDate(LocalDateTime.now());
		mprEntity.get().setActivate(Boolean.FALSE);
		mprRepository.save(mprEntity.get());
	}

	@Override
	public void activateMpr(Integer minimumProrateRuleId, String lastUpdatedBy) {
		Optional<MPREntity> mprEntity = mprRepository.findById(minimumProrateRuleId);

		if (!mprEntity.isPresent())
			throw new ResourceNotFoundException(MPR, "id", minimumProrateRuleId);

		if (mprEntity.get().getActivate())
			throw new BusinessException(MPRACTIVE);

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		mprEntity.get().setActivate(Boolean.TRUE);
		mprEntity.get().setLastUpdatedBy(lastUpdatedBy);
		mprEntity.get().setLastUpdatedDate(LocalDateTime.now());
		mprRepository.save(mprEntity.get());
	}

	public void validateDate(MPR mpr) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		String currentDateStr = sdf.format(new Date());

		String effectiveToDateStr = sdf.format(mpr.getEffectiveToDate());

		Date currentDate = null;
		Date effectiveToDate = null;
		try {
			currentDate = sdf.parse(currentDateStr);
			effectiveToDate = sdf.parse(effectiveToDateStr);
		} catch (ParseException e) {

			log.error("CONTEXT ", e);
		}

		DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();

		int valid = dateTimeComparator.compare(effectiveToDate, currentDate);

		if (valid < 0) {
			throw new BusinessException("Effective To date [" + effectiveToDate
					+ "] should be greater than or equal to the current date [" + currentDate + "]");
		}

	}

	private void validateMPQValue(Optional<String> mpqValue) {
		String value = OptionalUtil.getValue(mpqValue);
		double mprPer = Double.parseDouble(value);
		if (mprPer >= 1 || mprPer <= 0) {
			throw new BusinessException("Invalid" + mprPer);
		}

	}

	private void validateMPRPercentage(Optional<String> mprPercentage) {
		String value = OptionalUtil.getValue(mprPercentage);
		double mprPer = Double.parseDouble(value);
		if (mprPer < 0 || mprPer > 100) {
			throw new BusinessException("Invalid MPR Percentage " + mprPer);
		}
	}

	protected void validateEffectiveToDate(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}

	private void validateEffectiveDateForCreate(MPR mpr) {
		List<MPREntity> aircraftEntity = mprDao.verifyIfOverlapForUtilDateExists(
				OptionalUtil.getLocalDateValue(mpr.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(mpr.getEffectiveToDate()));
		int size = aircraftEntity.size();
		if (size > 0) {
			throw new BusinessException(DATE_VALIDATION);
		}
	}

	private void validateEffectiveDateForUpdate(Integer minimumProrateRuleId, MPR mpr, MPREntity mprEntity) {
		List<MPREntity> mprEntities = mprDao.verifyIfOverlapForUtilDateExists(getEffectiveFromDate(mpr, mprEntity),
				getEffectiveToDate(mpr, mprEntity));
		if (!(!mprEntities.isEmpty() && mprEntities.get(0).getMinimumProrateRuleId() == minimumProrateRuleId)) {
			if (mprEntities.size() > 0) {
				throw new BusinessException(DATE_VALIDATION);
			}
		}
	}

	private LocalDate getEffectiveFromDate(MPR mpr, MPREntity mprEntity) {
		return OptionalUtil.isPresent(mpr.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(mpr.getEffectiveFromDate())
				: mprEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(MPR mpr, MPREntity mprEntity) {
		return OptionalUtil.isPresent(mpr.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(mpr.getEffectiveToDate())
				: mprEntity.getEffectiveToDate();
	}

	@Override
	public List<com.sgl.smartpra.global.master.model.MPR> getMPR(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<Boolean> activate) {
		return mprMapper.mapToModel(mprDao.getMPR(effectiveFromDate, effectiveToDate, activate));
	}
}
