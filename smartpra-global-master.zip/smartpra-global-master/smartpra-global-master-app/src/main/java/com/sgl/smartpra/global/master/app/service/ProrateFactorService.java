package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProrateFactor;

public interface ProrateFactorService {

	public ProrateFactor createProrateFactor(ProrateFactor prorateFactor);

	public List<ProrateFactor> getListOfProrateFactor(Optional<String> fromCityCode, Optional<String> toCityCode, Optional<Boolean> activate);

	public List<ProrateFactor> getProrateFactorByTicketDate(Optional<String> fromCityCode, Optional<String> toCityCode, Optional<String> effectiveDate);

	//public ProrateFactor getProrateFactorByTicketDateFTE(Optional<String> fromCityCode, Optional<String> toCityCode, String effectiveDate);

	public ProrateFactor updateProrateFactor(Integer prorateFactorId, ProrateFactor prorateFactor);

	public void deactivateProrateFactor(Integer prorateFactorId, String lastUpdatedBy);

	public void activateProrateFactor(Integer prorateFactorId, String lastUpdatedBy);

	public ProrateFactor getProrateFactorByTicketDateFTE(Optional<String> fromCityCode, Optional<String> toCityCode,
			Optional<String> effectiveDate);

}
