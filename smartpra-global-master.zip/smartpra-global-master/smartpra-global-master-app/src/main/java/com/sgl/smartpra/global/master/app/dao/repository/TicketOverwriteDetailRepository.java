package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.TicketOverwiteDetailEntity;
import com.sgl.smartpra.global.master.app.dao.entity.TicketOverwriteEntity;
import com.sgl.smartpra.global.master.model.TicketOverwriteDetail;

@Repository
public interface TicketOverwriteDetailRepository extends JpaRepository<TicketOverwiteDetailEntity, Long>{

	List<TicketOverwiteDetailEntity> findByTicketOverwriteAndTableName(TicketOverwriteEntity ticketOverwrite,String tableName);
}
