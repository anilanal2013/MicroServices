package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.YQYRGlobalMasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.FaresDao;
import com.sgl.smartpra.global.master.app.dao.entity.FaresEntity;
import com.sgl.smartpra.global.master.app.dao.impl.FaresDaoImpl;
import com.sgl.smartpra.global.master.app.mapper.FaresMapper;
import com.sgl.smartpra.global.master.app.service.FaresService;
import com.sgl.smartpra.global.master.model.Fares;

import lombok.extern.slf4j.Slf4j;

@Service(value = "FaresService")
@Transactional
@Slf4j
public class FaresServiceImpl implements FaresService {

	@Autowired
	protected FaresMapper faresMapper;

	@Autowired
	protected FaresDao faresDao;

	@Autowired
	protected FaresDaoImpl faresDaoImpl;

	@Autowired
	private MasterFeignClient masterFeignClient;

	@Autowired
	private YQYRGlobalMasterFeignClient yqyrGlobalMasterFeignClient;

	@Autowired
	private AirportServiceImpl airportServiceImpl;

	@Autowired
	private CarrierServiceImpl carrierServiceImpl;

	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String CONSTRUCTION_LOV_COLUMN_VALUE = LOVEnum.CONSTRUCTION.getLOVEnum();
	public static final String PRORATE_LOV_COLUMN_NAME = LOVEnum.PRORATE.getLOVEnum();
	public static final String DIFFERENTIAL_LOV_COLUMN_NAME = LOVEnum.DIFFERENTIAL.getLOVEnum();
	public static final String PROPORTIONAL_LOV_COLUMN_NAME = LOVEnum.PROPORTIONAL.getLOVEnum();
	public static final String OW_RT_INDICATOR_LOV_COLUMN_NAME = LOVEnum.OW_RT_INDICATOR.getLOVEnum();
	public static final String FARE_CURRENCY_LOV_COLUMN_NAME = LOVEnum.FARE_CURRENCY.getLOVEnum();
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exist";
	private static final String INACTIVE_FARE = "Given Fare record is not active";
	private static final String ACTIVE_FARE = "Given Fare record is already active";
	private Boolean operationCheck = false;
	public static final String DATE_VALIDATION = "Effective date gets Overlaps";
	public static final String NOT_VALID = "] is Not Valid";
	private static final String INVALID_SEQUENCE_NUMBER = "Sequence Number should between 00001-99999";
	private static final String INVALID_LINK_NUMBER = "Link Number should between 001-999";
	private static final String INVALID_ROUTING_NUMBER = "Routing Number should between 0001-9999";
	private static final String INVALID_OLD_MCN = "Old MCN should between 00001-99999";
	private static final String INVALID_NEW_MCN = "New MCN should between 00001-99999";
	private static final String INVALID_NUMERIC_VALUE = "should be numeric value";
	String hostCarrDesigCode;

	@Override
	public Fares createFares(Fares fares) {
		hostCarrDesigCode = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		log.info("{}", fares);
		fares.setActivate(Optional.of(Boolean.TRUE));
		validateBusinessConstraintsForCreate(fares);
		return faresMapper.mapToModel(faresDao.create(faresMapper.mapToEntity(fares)));
	}

	@Override
	public Fares updateFares(Fares fares) {
		hostCarrDesigCode = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		log.info("{}", fares);
		FaresEntity faresEntity = faresDao.findById(fares.getFareId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(fares.getFareId())));
		validateBusinessConstraintsForUpdate(fares, faresEntity);
		fares.setLastUpdatedDate(LocalDateTime.now());
		return faresMapper.mapToModel(faresDao.update(faresMapper.mapToEntity(fares, faresEntity)));
	}

	@Override
	public Fares getFaresByFareId(Integer fareId) {
		return faresMapper.mapToModel(
				faresDao.findById(fareId).orElseThrow(() -> new RecordNotFoundException(String.valueOf(fareId))));
	}

	@Override
	public List<Fares> getFareForFareSelectionProcessing(Optional<String> cxrCode, Optional<String> originCity,
			Optional<String> destinationCity, Optional<String> effectiveDate) {
		return faresMapper.mapToModel(
				faresDao.getFareForFareSelectionProcessing(cxrCode, originCity, destinationCity, effectiveDate));
	}

	@Override
	public List<Fares> findAll() {
		return faresMapper.mapToModel(faresDao.findAll());
	}

	@Override
	public List<Fares> getFareBySearch(Optional<String> cxrCode, Optional<String> originCity,
			Optional<String> destinationCity, Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return faresMapper.mapToModel(faresDao.search(cxrCode, originCity, destinationCity, effectiveFromDate, effectiveToDate));

	}

	@Override
	public void deactivateFare(Fares fares) {
		FaresEntity faresEntity = faresDao.findById(fares.getFareId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(fares.getFareId())));
		if (!faresEntity.getActivate()) {
			throw new BusinessException(INACTIVE_FARE);
		}
		faresEntity.setActivate(Boolean.FALSE);
		faresDao.update(faresMapper.mapToEntity(fares, faresEntity));
	}

	@Override
	public void activateFare(Fares fares) {
		FaresEntity faresEntity = faresDao.findById(fares.getFareId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(fares.getFareId())));
		if (faresEntity.getActivate()) {
			throw new BusinessException(ACTIVE_FARE);
		}
		faresEntity.setActivate(Boolean.TRUE);
		faresDao.update(faresMapper.mapToEntity(fares, faresEntity));

	}

	private void validateBusinessConstraintsForCreate(Fares fares) {
		validateEffectiveToDate(fares);
		validateOverlap(fares);
		validateCarrierDesignatorCode(fares);
		validateOriginCity(fares);
		validateDesitnationCity(fares);
		validateOriginAndDesitnationCity(fares);
		validateFareBasis(fares);
		validateRoutingNumber(fares);
		validateFareValue(fares);
		validateAtpcoFareType(fares);
		validateOwrtIndicator(fares);
		validateConstruction(fares);
		validateDifferential(fares);
		validateProrate(fares);
		validateProportional(fares);
		validateFareCurrency(fares);
		validateSequenceNoAndOldMCNAndNewMCN(OptionalUtil.getValue(fares.getSequenceNumber()), INVALID_SEQUENCE_NUMBER);
		validateSequenceNoAndOldMCNAndNewMCN(OptionalUtil.getValue(fares.getOldMCN()), INVALID_OLD_MCN);
		validateSequenceNoAndOldMCNAndNewMCN(OptionalUtil.getValue(fares.getNewMCN()), INVALID_NEW_MCN);
		validateLinkNumber(OptionalUtil.getValue(fares.getLinkNumber()));
		validateRoutingNumber(OptionalUtil.getValue(fares.getRoutingNumber()));
	}

	private void validateBusinessConstraintsForUpdate(Fares fares, FaresEntity faresEntity) {
		validateEffectiveToDate(fares, faresEntity);
		validateOverlap(fares, faresEntity);
		validateCarrierDesignatorCode(fares);
		validateOriginCity(fares);
		validateDesitnationCity(fares);
		validateOriginAndDesitnationCity(fares,faresEntity);
		validateFareBasis(fares);
		validateRoutingNumber(fares);
		validateFareValue(fares);
		validateAtpcoFareType(fares);
		validateOwrtIndicator(fares);
		validateConstruction(fares);
		validateDifferential(fares);
		validateProrate(fares);
		validateProportional(fares);
		validateRoutingNumber(fares);
		validateFareCurrency(fares);
		validateSequenceNoAndOldMCNAndNewMCN(OptionalUtil.getValue(fares.getSequenceNumber()), INVALID_SEQUENCE_NUMBER);
		validateSequenceNoAndOldMCNAndNewMCN(OptionalUtil.getValue(fares.getOldMCN()), INVALID_OLD_MCN);
		validateSequenceNoAndOldMCNAndNewMCN(OptionalUtil.getValue(fares.getNewMCN()), INVALID_NEW_MCN);
		validateLinkNumber(OptionalUtil.getValue(fares.getLinkNumber()));
		validateRoutingNumber(OptionalUtil.getValue(fares.getRoutingNumber()));
	}

	private void validateEffectiveToDate(Fares fares) {
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(fares.getEffectiveToDate()),
				OptionalUtil.getLocalDateValue(fares.getEffectiveFromDate()));
	}
	
    protected void validateSequenceNoAndOldMCNAndNewMCN(String value,String message) {
    	try{
    	if(value != null && StringUtils.isNotEmpty(value) && Integer.parseInt(value) == 0) {
    	    throw new BusinessException(message);
    	}
    	}catch(NumberFormatException e) {
    		throw new BusinessException(message);	
    	}
	}
    
    protected void validateLinkNumber(String value) {
    	try{
    	if(value != null && StringUtils.isNotEmpty(value) && Integer.parseInt(value) == 0) {
    	    throw new BusinessException(INVALID_LINK_NUMBER);
    	}
    	}catch(NumberFormatException e) {
    		throw new BusinessException(INVALID_LINK_NUMBER);	
    	}
	}
    
    protected void validateRoutingNumber(String value) {
    	try{
    	if(value != null && StringUtils.isNotEmpty(value) && Integer.parseInt(value) == 0) {
    	    throw new BusinessException(INVALID_ROUTING_NUMBER);
    	}
    	}catch(NumberFormatException e) {
    		throw new BusinessException(INVALID_ROUTING_NUMBER);	
    	}
	}

	private void validateOverlap(Fares fares) {
		if (faresDao.getOverLapRecordCount(OptionalUtil.getLocalDateValue(fares.getEffectiveFromDate()),OptionalUtil.getLocalDateValue(fares.getEffectiveToDate()),OptionalUtil.getValue(fares.getTariffCode()),
				OptionalUtil.getValue(fares.getCxrCode()), OptionalUtil.getValue(fares.getOriginCity()),
				OptionalUtil.getValue(fares.getDestinationCity()), OptionalUtil.getValue(fares.getFareBasis())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);
		}
	}

	private void validateEffectiveDateForCreate(Fares fares) {
		List<FaresEntity> faresEntity = faresDao.verifyIfOverlapForUtilDateExists(
				OptionalUtil.getLocalDateValue(fares.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(fares.getEffectiveToDate()));
		int size = faresEntity.size();
		if (size > 0) {
			if (faresEntity.get(0).getCxrCode().equals(OptionalUtil.getValue(fares.getCxrCode()))) {
				throw new BusinessException(DATE_VALIDATION);
			}
		}
	}

	protected void validateEffectiveToDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("EffectiveToDate[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("EffectiveToDate[" + effectiveToDate
					+ "] should be greater than EffectiveFromDate[" + effectiveFromDate + "]");
		}
	}

	protected void validateCarrierDesignatorCode(Fares fares) {
		if (OptionalUtil.isPresent(fares.getCxrCode())) {
			String carrierDesignatorCode = OptionalUtil.getValue(fares.getCxrCode());
			if (!carrierServiceImpl.isValidCarrierDesignatorCode(carrierDesignatorCode)) {
				throw new BusinessException(
						"CXR[" + carrierDesignatorCode + "] is not a valid Carrier Designator Code");
			}
		}
	}

	// validation with airport master
	protected void validateOriginCity(Fares fares) {
		if (OptionalUtil.isPresent(fares.getOriginCity())) {
			String originCity = OptionalUtil.getValue(fares.getOriginCity());
			if (!airportServiceImpl.isValidCityCode(originCity)) {
				throw new BusinessException("Origin City[" + originCity + "] is not a valid Origin City Code");
			}
		}
	}

	// validation with airport master
	protected void validateDesitnationCity(Fares fares) {
		if (OptionalUtil.isPresent(fares.getDestinationCity())) {
			String destinationCity = OptionalUtil.getValue(fares.getDestinationCity());
			if (!airportServiceImpl.isValidCityCode(destinationCity)) {
				throw new BusinessException(
						"Destination city[" + destinationCity + "] is not a valid Destination City Code");
			}
		}
	}
	
	// validate origin and destination city
		protected void validateOriginAndDesitnationCity(Fares fares) {
			if (OptionalUtil.isPresent(fares.getOriginCity()) && OptionalUtil.isPresent(fares.getDestinationCity())) {
				String originCity = OptionalUtil.getValue(fares.getDestinationCity());
				String destinationCity = OptionalUtil.getValue(fares.getDestinationCity());
				if (OptionalUtil.getValue(fares.getOriginCity()).equalsIgnoreCase(OptionalUtil.getValue(fares.getDestinationCity()))) {
					throw new BusinessException(
							"Origin city [" + originCity + "] and Destination city [" + destinationCity + "] cannot be same");
				}		
		    }
	   }
	
	

	// validate against ATPCO PAX-FareType Master with Record type as F
	protected void validateAtpcoFareType(Fares fares) {
		if (OptionalUtil.isPresent(fares.getFareType())) {
			String fareType = OptionalUtil.getValue(fares.getFareType());
			if (!yqyrGlobalMasterFeignClient.validateAtpcoFareType(fareType)) {
				throw new BusinessException("Fare Type[" + fareType + "] is not a valid ATPCO PAX-FareType");
			}
		}
	}

	protected void validateFareBasis(Fares fares) {
		if (OptionalUtil.isPresent(fares.getFareBasis())) {
			String fareBasis = OptionalUtil.getValue(fares.getFareBasis());
			operationCheck = Pattern.compile("^[A-Za-z][A-Za-z0-9]*$").matcher(fareBasis).find();
			if (!operationCheck) {
				throw new BusinessException("Fare Basis[" + fareBasis + "] should be alphanumeric and start with alphabet");
			}
		}
	}

	protected void validateRoutingNumber(Fares fares) {
		if (OptionalUtil.isPresent(fares.getRoutingNumber())) {
			String routingNumber = OptionalUtil.getValue(fares.getRoutingNumber());
			operationCheck = Pattern.compile("^([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]|[0-9][1-9][0-9]{2}|[1-9][0-9]{3})$")
					.matcher(routingNumber).find();
			if (!operationCheck) {
				throw new BusinessException(
						"Routing number[" + routingNumber + "] is not valid, valid values: 0001-9999");
			}
		}
	}

	protected void validateFareValue(Fares fares) {
		if (OptionalUtil.isPresent(fares.getFareValue())) {
			String fareValue = OptionalUtil.getValue(fares.getFareValue()).toString();
			operationCheck = Pattern.compile("^(?=(\\D*\\d\\D*){0,8}$)-?([0-9]+)?(\\.?[0-9]{0,2})?$").matcher(fareValue)
					.find();
			if (!operationCheck) {
				throw new BusinessException("Fare value[" + fareValue
						+ "] is not valid, valid  values contain six whole number & two decimals");
			}
		}

	}

	protected void validateConstruction(Fares fares) {
		if (OptionalUtil.isPresent(fares.getConstruction())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,
					CONSTRUCTION_LOV_COLUMN_VALUE);
			String construction = OptionalUtil.getValue(fares.getConstruction());
			if (!(listOfValues.contains(OptionalUtil.getValue(fares.getConstruction())))) {
				throw new BusinessException("Construction[" + construction + NOT_VALID);
			}
		}

	}

	protected void validateProrate(Fares fares) {
		if (OptionalUtil.isPresent(fares.getProrate())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,
					PRORATE_LOV_COLUMN_NAME);
			String prorate = OptionalUtil.getValue(fares.getProrate());
			if (!(listOfValues.contains(OptionalUtil.getValue(fares.getProrate())))) {
				throw new BusinessException("Prorate[" + prorate + NOT_VALID);
			}
		}
	}

	protected void validateDifferential(Fares fares) {
		if (OptionalUtil.isPresent(fares.getDifferential())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,
					DIFFERENTIAL_LOV_COLUMN_NAME);
			String differential = OptionalUtil.getValue(fares.getDifferential());
			if (!(listOfValues.contains(OptionalUtil.getValue(fares.getDifferential())))) {
				throw new BusinessException("Differential[" + differential + NOT_VALID);
			}
		}
	}

	protected void validateProportional(Fares fares) {
		if (OptionalUtil.isPresent(fares.getProportional())) {
			if (!OptionalUtil.getValue(fares.getProportional()).equalsIgnoreCase("P")
					|| OptionalUtil.getValue(fares.getProportional()).equalsIgnoreCase("")) {
				throw new BusinessException("Proportional[" + fares.getProportional() + NOT_VALID);
			}
			List<String> listOfValues = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,
					PROPORTIONAL_LOV_COLUMN_NAME);
			String proportional = OptionalUtil.getValue(fares.getProportional());
			if (!(listOfValues.contains(OptionalUtil.getValue(fares.getProportional())))) {
				throw new BusinessException("Proportional[" + proportional + NOT_VALID);
			}
		}
	}

	protected void validateOwrtIndicator(Fares fares) {
		if (OptionalUtil.isPresent(fares.getOwRtIndicator())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,
					OW_RT_INDICATOR_LOV_COLUMN_NAME);
			String owRtIndicator = OptionalUtil.getValue(fares.getOwRtIndicator());
			if (!(listOfValues.contains(OptionalUtil.getValue(fares.getOwRtIndicator())))) {
				throw new BusinessException("OWRTIndicator[" + owRtIndicator + NOT_VALID);
			}
		}
	}

	protected void validateFareCurrency(Fares fares) {
		if (OptionalUtil.isPresent(fares.getFareCurrency())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,
					FARE_CURRENCY_LOV_COLUMN_NAME);
			String fareCurrency = OptionalUtil.getValue(fares.getFareCurrency());
			if (!(listOfValues.contains(OptionalUtil.getValue(fares.getFareCurrency())))) {
				throw new BusinessException("Fare Currency[" + fareCurrency + NOT_VALID);
			}
		}
	}

	private void validateEffectiveToDate(Fares fares, FaresEntity faresEntity) {
		if (OptionalUtil.isPresent(fares.getEffectiveFromDate())
				|| OptionalUtil.isPresent(fares.getEffectiveToDate())) {
			validateEffectiveToDate(getEffectiveToDate(fares, faresEntity), getEffectiveFromDate(fares, faresEntity));
		}

	}
	
	// validate origin and destination city
			protected void validateOriginAndDesitnationCity(Fares fares, FaresEntity faresEntity) {
				String originCity = getOriginCity(fares, faresEntity);
				String destinationCity = getdestinationCity(fares, faresEntity);
				if (originCity != null && destinationCity != null && originCity.equalsIgnoreCase(destinationCity)) {
						throw new BusinessException(
								"Origin city [" + originCity + "] and Destination city [" + destinationCity + "] cannot be same");
					}
		     }

	private void validateOverlap(Fares fares, FaresEntity faresEntity) {
		// During Update input for "tariffCode" can be null if the element is not
		// sent in json. if that is the case take the value from the db(entity) to
		// validate overlap
		String tariffCode = getTariffCode(fares, faresEntity);
		// During Update input for "cxrCode" can be null if the element is not
		// sent in json. if that is the case take the value from the db(entity) to
		// validate overlap
		String cxrCode = getCxrCode(fares, faresEntity);
		// During Update input for "originCity" can be null if the element is not
		// sent in json. if that is the case take the value from the db(entity) to
		// validate overlap
		String originCity = getOriginCity(fares, faresEntity);
		// During Update input for "destinationCity" can be null if the element is not
		// sent in json. if that is the case take the value from the db(entity) to
		// validate overlap
		String destinationCity = getdestinationCity(fares, faresEntity);
		// During Update input for "fareBasis" can be null if the element is not
		// sent in json. if that is the case take the value from the db(entity) to
		// validate overlap
		String fareBasis = getFareBasis(fares, faresEntity);

		if (!tariffCode.equalsIgnoreCase(faresEntity.getTariffCode())
				|| !cxrCode.equalsIgnoreCase(faresEntity.getCxrCode())
				|| !originCity.equalsIgnoreCase(faresEntity.getOriginCity())
				|| !destinationCity.equalsIgnoreCase(faresEntity.getDestinationCity())
				|| !fareBasis.equalsIgnoreCase(faresEntity.getFareBasis())) {
			if (faresDao.getOverLapRecordCount(OptionalUtil.getLocalDateValue(fares.getEffectiveFromDate()),OptionalUtil.getLocalDateValue(fares.getEffectiveToDate()), tariffCode, cxrCode, originCity, destinationCity, fareBasis,
					faresEntity.getFareId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private LocalDate getEffectiveFromDate(Fares fares, FaresEntity faresEntity) {
		return OptionalUtil.isPresent(fares.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(fares.getEffectiveFromDate())
				: faresEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(Fares fares, FaresEntity faresEntity) {
		return OptionalUtil.isPresent(fares.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(fares.getEffectiveToDate())
				: faresEntity.getEffectiveToDate();
	}

	private String getFareBasis(Fares fares, FaresEntity faresEntity) {
		return OptionalUtil.isPresent(fares.getFareBasis()) ? OptionalUtil.getValue(fares.getFareBasis())
				: faresEntity.getFareBasis();
	}

	private String getdestinationCity(Fares fares, FaresEntity faresEntity) {
		return OptionalUtil.isPresent(fares.getDestinationCity()) ? OptionalUtil.getValue(fares.getDestinationCity())
				: faresEntity.getDestinationCity();
	}

	private String getOriginCity(Fares fares, FaresEntity faresEntity) {
		return OptionalUtil.isPresent(fares.getOriginCity()) ? OptionalUtil.getValue(fares.getOriginCity())
				: faresEntity.getOriginCity();
	}

	private String getCxrCode(Fares fares, FaresEntity faresEntity) {
		return OptionalUtil.isPresent(fares.getCxrCode()) ? OptionalUtil.getValue(fares.getCxrCode())
				: faresEntity.getCxrCode();
	}

	private String getTariffCode(Fares fares, FaresEntity faresEntity) {
		return OptionalUtil.isPresent(fares.getTariffCode()) ? OptionalUtil.getValue(fares.getTariffCode())
				: faresEntity.getTariffCode();
	}

}