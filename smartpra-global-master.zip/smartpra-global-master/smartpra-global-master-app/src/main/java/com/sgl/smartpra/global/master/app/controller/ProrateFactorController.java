package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.ProrateFactorService;
import com.sgl.smartpra.global.master.model.ProrateFactor;

@RestController
public class ProrateFactorController {

	@Autowired
	private ProrateFactorService prorateFactorService;

	@PostMapping("/prorate-factor")
	public ProrateFactor createProrateFactor(@Validated(Create.class) @RequestBody ProrateFactor prorateFactor) {
		return prorateFactorService.createProrateFactor(prorateFactor);
	}

	@GetMapping("/prorate-factor")
	public List<ProrateFactor> getAllProrateFactor(
			@RequestParam(value = "fromCityCode", required = false) Optional<String> fromCityCode,
			@RequestParam(value = "toCityCode", required = false) Optional<String> toCityCode,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return prorateFactorService.getListOfProrateFactor(fromCityCode, toCityCode, activate);
	}

	@GetMapping("/prorate-factor/{fromCityCode}/{toCityCode}/{effectiveDate}")
	public List<ProrateFactor> getProrateFactorByTicketDate(
			@PathVariable(value = "fromCityCode") Optional<String> fromCityCode,
			@PathVariable(value = "toCityCode") Optional<String> toCityCode,
			@PathVariable(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return prorateFactorService.getProrateFactorByTicketDate(fromCityCode, toCityCode, effectiveDate);
	}

	@GetMapping("/prorate-factorvalue/{fromCityCode}/{toCityCode}/{effectiveDate}")
	public ProrateFactor getProrateFactorByTicketString(
			@PathVariable(value = "fromCityCode") Optional<String> fromCityCode,
			@PathVariable(value = "toCityCode") Optional<String> toCityCode,
			@PathVariable(value = "effectiveDate") Optional<String> effectiveDate) {
		return prorateFactorService.getProrateFactorByTicketDateFTE(fromCityCode, toCityCode, effectiveDate);
	}

	@PutMapping("/prorate-factor/{prorateFactorId}")
	public ProrateFactor updateProrateFactor(@PathVariable(value = "prorateFactorId") Integer prorateFactorId,
			@Validated(Update.class) @RequestBody ProrateFactor prorateFactor) {
		return prorateFactorService.updateProrateFactor(prorateFactorId, prorateFactor);
	}

	@PutMapping("/prorate-factor/{prorateFactorId}/deactivate")
	public void deactivateProrateFactor(@Valid @PathVariable(value = "prorateFactorId") Integer prorateFactorId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		prorateFactorService.deactivateProrateFactor(prorateFactorId, lastUpdatedBy);
	}

	@PutMapping("/prorate-factor/{prorateFactorId}/activate")
	public void activateProrateFactor(@Valid @PathVariable(value = "prorateFactorId") Integer prorateFactorId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		prorateFactorService.activateProrateFactor(prorateFactorId, lastUpdatedBy);
	}
}
