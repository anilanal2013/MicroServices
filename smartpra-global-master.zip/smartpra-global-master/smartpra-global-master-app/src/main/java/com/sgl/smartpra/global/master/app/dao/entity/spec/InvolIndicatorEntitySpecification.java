package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.repository.entity.InvolIndicatorEntity;

public class InvolIndicatorEntitySpecification {

	public static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";
	public static final String EFFECTIVE_TO_DATE = "effectiveToDate";
	public static final String TICKET_FIELD = "ticketField";
	public static final String INDICATOR_TYPE = "indicatorType";
	public static final String ACTIVATE = "activate";

	public static void orderByDescByEffectiveFromDateAndAscByTicketField(
			Root<InvolIndicatorEntity> involIndicatorEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String effectiveFromDate, String ticketField) {
		criteriaQuery.orderBy(criteriaBuilder.desc(involIndicatorEntity.get(effectiveFromDate)),
				criteriaBuilder.asc(involIndicatorEntity.get(ticketField)));

	}

	public static Specification<InvolIndicatorEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (involIndicatorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), involIndicatorEntity.get(EFFECTIVE_FROM_DATE),
				involIndicatorEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<InvolIndicatorEntity> isActive() {
		return (involIndicatorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(involIndicatorEntity.get(ACTIVATE), true);
	}

	public static Specification<InvolIndicatorEntity> notEqualsInvolIndicatorId(Integer involIndicatorId) {
		return (involEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(involEntity.get("involIndicatorId"), involIndicatorId);
	}

	public static Specification<InvolIndicatorEntity> equalsTicketField(String ticketField) {
		return (involIndicatorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(involIndicatorEntity.get(TICKET_FIELD), ticketField);
	}

	public static Specification<InvolIndicatorEntity> equalsIndicatorText(String indicatorText) {
		return (involIndicatorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(involIndicatorEntity.get("indicatorText"), indicatorText);
	}

	public static Specification<InvolIndicatorEntity> search(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> indicatorType, Optional<String> ticketField,
			Optional<Boolean> activate) {
		return (involIndicatorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(indicatorType)) {
				predicates.add(criteriaBuilder.like(involIndicatorEntity.get(INDICATOR_TYPE),
						OptionalUtil.getValue(indicatorType) + "%"));
			}
			if (OptionalUtil.isPresent(ticketField)) {
				predicates.add(criteriaBuilder.like(involIndicatorEntity.get(TICKET_FIELD),
						OptionalUtil.getValue(ticketField) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
						involIndicatorEntity.get(EFFECTIVE_FROM_DATE), involIndicatorEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								involIndicatorEntity.get(EFFECTIVE_FROM_DATE),
								involIndicatorEntity.get(EFFECTIVE_TO_DATE))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							involIndicatorEntity.get(EFFECTIVE_FROM_DATE),
							involIndicatorEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							involIndicatorEntity.get(EFFECTIVE_FROM_DATE),
							involIndicatorEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(
						criteriaBuilder.equal(involIndicatorEntity.get(ACTIVATE), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(involIndicatorEntity.get(ACTIVATE), Boolean.TRUE));
			}

			orderByDescByEffectiveFromDateAndAscByTicketField(involIndicatorEntity, criteriaQuery, criteriaBuilder,
					EFFECTIVE_FROM_DATE, TICKET_FIELD);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<InvolIndicatorEntity> findAll(Optional<String> effectiveDate,
			Optional<String> indicatorType) {
		return (involIndicatorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(indicatorType)) {
				predicates.add(criteriaBuilder.like(involIndicatorEntity.get(INDICATOR_TYPE),
						OptionalUtil.getValue(indicatorType) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
						involIndicatorEntity.get(EFFECTIVE_FROM_DATE), involIndicatorEntity.get(EFFECTIVE_TO_DATE)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<InvolIndicatorEntity> validateDate(Optional<String> effectiveDate) {
		return (involIndicatorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(effectiveDate)) {
				if (OptionalUtil.isPresent(effectiveDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
							involIndicatorEntity.get(EFFECTIVE_FROM_DATE),
							involIndicatorEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<InvolIndicatorEntity> search(InvolIndicatorEntity involIndicatorEntities) {
		return (involIndicatorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (isEmptyOrNull(involIndicatorEntities.getIndicatorType())) {
				predicates.add(criteriaBuilder.like(involIndicatorEntity.get(INDICATOR_TYPE),
						involIndicatorEntities.getIndicatorType() + "%"));
			}
			if (isEmptyOrNull(involIndicatorEntities.getTicketField())) {
				predicates.add(criteriaBuilder.like(involIndicatorEntity.get(TICKET_FIELD),
						involIndicatorEntities.getTicketField() + "%"));
			}
			if (involIndicatorEntities.getEffectiveFromDate() != null
					&& involIndicatorEntities.getEffectiveToDate() != null) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(involIndicatorEntities.getEffectiveFromDate()),
								involIndicatorEntity.get(EFFECTIVE_FROM_DATE),
								involIndicatorEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(criteriaBuilder.literal(involIndicatorEntities.getEffectiveFromDate()),
								involIndicatorEntity.get(EFFECTIVE_FROM_DATE),
								involIndicatorEntity.get(EFFECTIVE_TO_DATE))));
			} else {
				if (involIndicatorEntities.getEffectiveFromDate() != null) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(involIndicatorEntities.getEffectiveFromDate()),
							involIndicatorEntity.get(EFFECTIVE_FROM_DATE),
							involIndicatorEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (involIndicatorEntities.getEffectiveToDate() != null) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(involIndicatorEntities.getEffectiveToDate()),
							involIndicatorEntity.get(EFFECTIVE_FROM_DATE),
							involIndicatorEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			if (involIndicatorEntities.getActivate() != null) {
				predicates.add(criteriaBuilder.equal(involIndicatorEntity.get(ACTIVATE),
						involIndicatorEntities.getActivate()));
			}
			if (involIndicatorEntities.getActivate() == null) {
				predicates.add(criteriaBuilder.equal(involIndicatorEntity.get(ACTIVATE), Boolean.TRUE));
			}
			orderByDescByEffectiveFromDateAndAscByTicketField(involIndicatorEntity, criteriaQuery, criteriaBuilder,
					EFFECTIVE_FROM_DATE, TICKET_FIELD);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private static boolean isEmptyOrNull(String value) {
		return value != null && !value.isEmpty();
	}
}
