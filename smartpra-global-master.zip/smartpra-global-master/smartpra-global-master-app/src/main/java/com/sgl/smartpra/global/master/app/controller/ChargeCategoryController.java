package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.dao.entity.ChargeCategoryEntity;
import com.sgl.smartpra.global.master.app.service.ChargeCategoryService;
import com.sgl.smartpra.global.master.model.ChargeCategory;

@RestController
public class ChargeCategoryController {

	@Autowired
	private ChargeCategoryService chargeCategoryService;

	@PostMapping("/charge-categories")
	public ChargeCategory createChargeCategory(@Validated(Create.class) @RequestBody ChargeCategory chargeCategory) {
		return chargeCategoryService.createChargeCategory(chargeCategory);
	}

	@GetMapping("/charge-categories")
	public List<ChargeCategory> getAllChargeCategory(
			@RequestParam(value = "chargeCategoryCode", required = false) Optional<String> chargeCategoryCode,
			@RequestParam(value = "chargeCategoryName", required = false) Optional<String> chargeCategoryName,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return chargeCategoryService.getAllChargeCategory(chargeCategoryCode, chargeCategoryName, activate);
	}

	@GetMapping("charge-categories/{chargeCategoryCode}")
	public ChargeCategory getChargeCategoryByChargeCategoryCode(
			@PathVariable(value = "chargeCategoryCode") Optional<String> chargeCategoryCode) {
		return chargeCategoryService.getChargeCategoryByChargeCategoryCode(chargeCategoryCode);
	}

	@GetMapping("charge-category-name/{chargeCategoryName}")
	public ChargeCategory getChargeCategoryByChargeCategoryName(
			@PathVariable(value = "chargeCategoryName") String chargeCategoryName) {
		Optional<String> OpChargeCategoryName = Optional.of(chargeCategoryName);
		System.out.println(
				"chargeCategoryName: " + chargeCategoryName + ", opChargeCategoryName: " + OpChargeCategoryName);
		return chargeCategoryService.getChargeCategoryByChargeCategoryName(OpChargeCategoryName);
	}

	@PutMapping("/charge-categories")
	public List<ChargeCategory> updateChargeCategory(
			@Validated(Update.class) @RequestBody List<ChargeCategory> chargeCategory) {
		return chargeCategoryService.updateChargeCategroy(chargeCategory);
	}

	@PutMapping("/charge-categories/{chargeCategoryCode}/deactivate")
	public void deactivateChargeCategory(
			@PathVariable(value = "chargeCategoryCode") Optional<String> chargeCategoryCode,
			@RequestParam(value = "lastUpdatedBy", required = true) Optional<String> lastUpdatedBy) {
		chargeCategoryService.deactivateChargeCategory(chargeCategoryCode, lastUpdatedBy);
	}

	@PutMapping("/charge-categories/{chargeCategoryCode}/activate")
	public void activateChargeCategory(@PathVariable(value = "chargeCategoryCode") Optional<String> chargeCategoryCode,
			@RequestParam(value = "lastUpdatedBy", required = true) Optional<String> lastUpdatedBy) {
		chargeCategoryService.activateChargeCategory(chargeCategoryCode, lastUpdatedBy);
	}

	@GetMapping("/charge-categories/account-scenario")
	public List<String> getChargeCatCodeFromChargeCatMaster() {
		return chargeCategoryService.getChargeCatCodeFromChargeCatMaster();

	}
}