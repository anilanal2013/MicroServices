package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.MPR;

public interface MPRService {
	//public List<MPR> getMprDetail(Optional<String> effectiveDate);
	public MPR getMprDetail(Optional<String> effectiveDate);

	public MPR getMprByMinimumProrateRuleId(Integer minimumProrateRuleId);

	public MPR createMpr(MPR mpr);

	public MPR updateMpr(Integer minimumProrateRuleId, MPR mpr);

	public void deactivateMpr(Integer minimumProrateRuleId, String lastUpdatedBy);

	public void activateMpr(Integer minimumProrateRuleId, String lastUpdatedBy);

	public List<MPR> getMPR(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate);

}
