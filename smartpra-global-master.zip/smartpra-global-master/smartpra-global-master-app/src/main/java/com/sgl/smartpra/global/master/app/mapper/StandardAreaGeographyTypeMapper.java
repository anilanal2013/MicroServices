package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;

import com.sgl.smartpra.global.master.app.repository.entity.GeographyTypeEntity;
import com.sgl.smartpra.global.master.model.GeographyType;

@Mapper
public interface StandardAreaGeographyTypeMapper {

	GeographyType mapToStandardAreaGeographyTypeModel(GeographyTypeEntity standardAreaGeographyTypeEntity);
}
