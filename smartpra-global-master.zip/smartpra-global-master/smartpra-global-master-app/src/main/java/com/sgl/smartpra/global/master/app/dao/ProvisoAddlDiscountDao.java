package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountEntity;
@Repository
public interface ProvisoAddlDiscountDao {
	List<ProvisoAdditionalDiscountEntity> findByMainId(Optional<Integer> provisoMainId);

	Optional<ProvisoAdditionalDiscountEntity> findById(Integer id);

	public List<ProvisoAdditionalDiscountEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<String> discountCode);

	ProvisoAdditionalDiscountEntity create(ProvisoAdditionalDiscountEntity provisoAdditionalDiscountEntity);

	public List<Integer> getListOfProvisoMainIdFromAddlDiscountDb();
}
