package com.sgl.smartpra.global.master.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.DictionaryValueService;
import com.sgl.smartpra.global.master.model.DictionaryValue;

@RestController
public class DictionaryValueController {

	@Autowired
	DictionaryValueService dictionaValueService;
	
	@GetMapping(value = "/dictionary/{id}")
	public List<DictionaryValue> fetchAllDictionaryValueByElementName(
			@PathVariable(value="id" , required = true) Integer id
			) {
		return dictionaValueService.fetchAllDictionaryById(id);
	}
}
