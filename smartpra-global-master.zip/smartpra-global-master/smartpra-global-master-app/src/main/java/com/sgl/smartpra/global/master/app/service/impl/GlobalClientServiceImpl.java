package com.sgl.smartpra.global.master.app.service.impl;

import com.sgl.smartpra.global.master.app.dao.GlobalClientDao;
import com.sgl.smartpra.global.master.app.mapper.GlobalClientMapper;
import com.sgl.smartpra.global.master.app.service.GlobalClientService;
import com.sgl.smartpra.global.master.model.GlobalClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class GlobalClientServiceImpl implements GlobalClientService {

    @Autowired
    GlobalClientMapper globalClientMapper;

    @Autowired
    GlobalClientDao globalClientDao;


    @Override
    public GlobalClient getCurrentClientIdByUrl(GlobalClient globalClient) {
        return globalClientMapper.mapToModel(globalClientDao.findAll(Example.of(globalClientMapper.mapToEntity(globalClient))).get());
    }
}
