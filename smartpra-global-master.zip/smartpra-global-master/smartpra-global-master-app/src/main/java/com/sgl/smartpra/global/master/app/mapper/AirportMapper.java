package com.sgl.smartpra.global.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.AirportEntity;
import com.sgl.smartpra.global.master.model.Airport;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AirportMapper extends BaseMapper<Airport, AirportEntity> {

	Airport mapToModel(AirportEntity airportEntity);

	Airport mapToModel(AirportEntity airportEntity, @MappingTarget Airport airport);

	List<Airport> mapToModel(List<AirportEntity> airportEntityList);

	AirportEntity mapToEntity(Airport airport);

	AirportEntity mapToEntity(Airport airport, @MappingTarget AirportEntity airportEntity);

}
