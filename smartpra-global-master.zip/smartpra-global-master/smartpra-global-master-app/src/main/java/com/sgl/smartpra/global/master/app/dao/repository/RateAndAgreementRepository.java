package com.sgl.smartpra.global.master.app.dao.repository;

import com.sgl.smartpra.global.master.app.dao.entity.RateAndAgreementEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface RateAndAgreementRepository extends JpaRepository<RateAndAgreementEntity,Integer>, JpaSpecificationExecutor<RateAndAgreementEntity> {
}
