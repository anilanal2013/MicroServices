package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.joda.time.Months;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.FBTDElementDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoAddlDiscountStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoMainStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;
import com.sgl.smartpra.global.master.app.mapper.ProvisoMainStgMapper;
import com.sgl.smartpra.global.master.app.repository.entity.FBTDElementEntity;
import com.sgl.smartpra.global.master.app.service.ProvisoAddlDiscountStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoMainStgService;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscountStg;
import com.sgl.smartpra.global.master.model.ProvisoMainStgModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoMainStgServiceImpl implements ProvisoMainStgService {
	
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exist";
	public static final String PROVISO_MAIN_ALREADY_INACTIVE = "Proviso Status is already InActive for this Proviso Main Id";
	public static final String PROVISO_MAIN_MOVE_PROD = "Proviso Status M is only possible in Production Move";
	private static final String VALIDFROMDATE = "EffectiveFromDate must be 1-Dec, 1-Mar, 1-Jun or 1-Sep of the Year";
	private static final String VALIDTODATE = "EffectiveToDate must be 28/29-Feb, 31-May, 31-Aug or 30-Nov of the Year";
	private static final String QUATERLYCHECK = "Effective period not falling within the quaters";
	@Autowired
	private ProvisoMainStgMapper provisoMainStgMapper;

	@Autowired
	private ProvisoMainStgDao provisoMainStgDao;

	@Autowired
	private ProvisoAddlDiscountStgDao provisoAddlDiscountStgDao;

	@Autowired
	private ProvisoAddlDiscountStgService provisoAddlDiscountStgService;
	
	@Autowired
	private FBTDElementDao fBTDElementDao;

	@Override
	public ProvisoMainStgModel createProvisoMain(ProvisoMainStgModel provisoMainStgModel) {
		Integer provisoSeqnumber = provisoMainStgDao.getMaxOfProvisoSeqnumber(provisoMainStgModel.getCarrierNumCode());
		provisoSeqnumber = (provisoSeqnumber == null) ? Integer.valueOf(1)
				: Integer.valueOf(provisoSeqnumber.intValue() + 1);
		provisoMainStgModel.setProvisoSeqNumber(Optional.of(provisoSeqnumber));

		provisoMainStgModel.setProvisoStatus(Optional.of("D"));
		validateBusinessConstraintsForCreate(provisoMainStgModel);
		provisoMainStgModel.setCreatedDate(LocalDateTime.now());

		ProvisoMainStgModel provisoMainStgModelCreate = provisoMainStgMapper
				.mapToModel(provisoMainStgDao.create(provisoMainStgMapper.mapToEntity(provisoMainStgModel)));

		provisoMainStgModelCreate.setDiscountCode(provisoMainStgModel.getDiscountCode());
		ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg = new ProvisoAdditionalDiscountStg();
		Integer provisoMainIdFetched = provisoMainStgDao.getMaxOfProvisoMainId();
		if (Objects.nonNull(provisoMainStgModel.getAdditionalDiscountFlag()) && (provisoMainStgModel.getAdditionalDiscountFlag()
				|| provisoMainStgModel.getAdditionalDiscountFlag().toString().equals("True"))) {

			provisoAddlDiscountStgDao.deleteProvisoAddlDiscountStg(provisoMainStgModel.getProvisoMainId(),
					OptionalUtil.getValue(provisoMainStgModel.getCarrierNumCode()),
					OptionalUtil.getValue(provisoMainStgModel.getProvisoSeqNumber()));
			String discountCode = OptionalUtil.getValue(provisoMainStgModel.getDiscountCode());
			List<String> discountCodeList = Arrays.asList(discountCode.split("\\s*,\\s*"));
			int i = 1;
			for (String discountCodeitr : discountCodeList) {

				provisoAdditionalDiscountStg.setDiscountCode(Optional.of(discountCodeitr));
				provisoAdditionalDiscountStg.setCarrierNumCode(provisoMainStgModel.getCarrierNumCode());
				provisoAdditionalDiscountStg.setProvisoSeqNumber(provisoMainStgModel.getProvisoSeqNumber());

				provisoAdditionalDiscountStg.setProvisoMainId(Optional.of(provisoMainIdFetched));
				provisoAdditionalDiscountStg.setDiscountRecNumber(Optional.of(new Integer(i)));
				i++;
				provisoAdditionalDiscountStg.setCreatedBy(provisoMainStgModel.getCreatedBy());
				provisoAddlDiscountStgService.createProvisoAddlDiscount(provisoAdditionalDiscountStg);
			}

		} else {
			provisoAddlDiscountStgDao.deleteProvisoAddlDiscountStg(provisoMainIdFetched,
					OptionalUtil.getValue(provisoMainStgModel.getCarrierNumCode()),
					OptionalUtil.getValue(provisoMainStgModel.getProvisoSeqNumber()));
		}

		return provisoMainStgModelCreate;
	}

	@Override
	public ProvisoMainStgModel updateProvisoMain(ProvisoMainStgModel provisoMainStgModel) {

		log.info("{}", provisoMainStgModel);
		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(provisoMainStgModel.getProvisoMainId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoMainStgModel.getProvisoMainId())));
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgModel.setProvisoStatus(Optional.of("M"));
		}
		validateBusinessConstraintsForUpdate(provisoMainStgModel, provisoMainStgEntity);
		provisoMainStgModel.setLastUpdatedDate(LocalDateTime.now());
		ProvisoMainStgModel provisoMainStgModelUpdate = provisoMainStgMapper.mapToModel(
				provisoMainStgDao.update(provisoMainStgMapper.mapToEntity(provisoMainStgModel, provisoMainStgEntity)));
		provisoMainStgModelUpdate.setDiscountCode(provisoMainStgModel.getDiscountCode());
		ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg = new ProvisoAdditionalDiscountStg();
		if (Objects.nonNull(provisoMainStgModel.getAdditionalDiscountFlag()) && (provisoMainStgModel.getAdditionalDiscountFlag()
				|| provisoMainStgModel.getAdditionalDiscountFlag().toString().equals("True"))) {

			provisoAddlDiscountStgDao.deleteProvisoAddlDiscountStg(provisoMainStgModel.getProvisoMainId(),
					OptionalUtil.getValue(provisoMainStgModel.getCarrierNumCode()),
					OptionalUtil.getValue(provisoMainStgModel.getProvisoSeqNumber()));
			String discountCode = OptionalUtil.getValue(provisoMainStgModel.getDiscountCode());
			List<String> discountCodeList = Arrays.asList(discountCode.split("\\s*,\\s*"));
			int i = 1;
			for (String discountCodeitr : discountCodeList) {

				provisoAdditionalDiscountStg.setDiscountCode(Optional.of(discountCodeitr));
				provisoAdditionalDiscountStg.setCarrierNumCode(provisoMainStgModel.getCarrierNumCode());
				provisoAdditionalDiscountStg.setProvisoSeqNumber(provisoMainStgModel.getProvisoSeqNumber());
				provisoAdditionalDiscountStg.setProvisoMainId(Optional.of(provisoMainStgModel.getProvisoMainId()));
				provisoAdditionalDiscountStg.setDiscountRecNumber(Optional.of(new Integer(i)));
				i++;
				provisoAdditionalDiscountStg.setCreatedBy(Optional.of(provisoMainStgEntity.getCreatedBy()));
				provisoAddlDiscountStgService.createProvisoAddlDiscount(provisoAdditionalDiscountStg);
			}

		} else {
			provisoAddlDiscountStgDao.deleteProvisoAddlDiscountStg(provisoMainStgModel.getProvisoMainId(),
					OptionalUtil.getValue(provisoMainStgModel.getCarrierNumCode()),
					OptionalUtil.getValue(provisoMainStgModel.getProvisoSeqNumber()));
		}
		return provisoMainStgModelUpdate;
	}

	@Override
	public List<ProvisoMainStgModel> search(Optional<String> carrierNumCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> provisoSection, Optional<String> provisoStatus) {

		List<ProvisoMainStgModel> provisoMainStgModelList = provisoMainStgMapper.mapToModel(provisoMainStgDao
				.searchProvisoMain(carrierNumCode, effectiveFromDate, effectiveToDate, provisoSection, provisoStatus));
		for (ProvisoMainStgModel provisoMainStgModel : provisoMainStgModelList) {
			List<ProvisoAdditionalDiscountStgEntity> provisoAdditionalDiscountEntityList = provisoAddlDiscountStgDao
					.search(provisoMainStgModel.getCarrierNumCode(), provisoMainStgModel.getProvisoSeqNumber());

			if (!provisoAdditionalDiscountEntityList.isEmpty()) {
				String discountCodeList = null;
				for (ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity : provisoAdditionalDiscountEntityList) {
					discountCodeList = discountCodeList == null ? provisoAdditionalDiscountStgEntity.getDiscountCode()
							: discountCodeList + "," + provisoAdditionalDiscountStgEntity.getDiscountCode();
				}
				provisoMainStgModel.setDiscountCode(Optional.of(discountCodeList));
			}
		}
		return provisoMainStgModelList;
	}

	@Override
	public ProvisoMainStgModel getProvisoMainByprovisoMainId(Integer provisoMainId) {

		ProvisoMainStgModel provisoMainStgModel = provisoMainStgMapper.mapToModel(provisoMainStgDao
				.findById(provisoMainId).orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoMainId))));

		List<ProvisoAdditionalDiscountStgEntity> provisoAdditionalDiscountEntityList = provisoAddlDiscountStgDao
				.search(provisoMainStgModel.getCarrierNumCode(), provisoMainStgModel.getProvisoSeqNumber());

		if (!provisoAdditionalDiscountEntityList.isEmpty()) {
			String discountCodeList = null;
			for (ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity : provisoAdditionalDiscountEntityList) {
				discountCodeList = discountCodeList == null ? provisoAdditionalDiscountStgEntity.getDiscountCode()
						: discountCodeList + "," + provisoAdditionalDiscountStgEntity.getDiscountCode();
			}
			provisoMainStgModel.setDiscountCode(Optional.of(discountCodeList));
		}

		return provisoMainStgModel;
	}

	@Override
	public ProvisoMainStgModel moveProvisoMainToProd(Integer provisoMainId, ProvisoMainStgModel provisoMainStgModel) {

		return null;
	}

	@Override
	public void inActiveProvisoMain(ProvisoMainStgModel provisoMainStgModel) {

		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(provisoMainStgModel.getProvisoMainId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoMainStgModel.getProvisoMainId())));

		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("I"))) {
			throw new BusinessException(PROVISO_MAIN_ALREADY_INACTIVE);
		}
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgModel.setProvisoStatus(Optional.of("I"));
		}
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("M"))) {
			throw new BusinessException(PROVISO_MAIN_MOVE_PROD);
		}

		provisoMainStgDao.update(provisoMainStgMapper.mapToEntity(provisoMainStgModel, provisoMainStgEntity));

	}

	private LocalDate getEffectiveFromDate(ProvisoMainStgModel provisoMainStgModel,
			ProvisoMainStgEntity provisoMainStgEntity) {
		return OptionalUtil.isPresent(provisoMainStgModel.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveFromDate())
				: provisoMainStgEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(ProvisoMainStgModel provisoMainStgModel,
			ProvisoMainStgEntity provisoMainStgEntity) {
		return OptionalUtil.isPresent(provisoMainStgModel.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveToDate())
				: provisoMainStgEntity.getEffectiveToDate();
	}

	private void validateBusinessConstraintsForCreate(ProvisoMainStgModel provisoMainStgModel) {
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveToDate()),
				OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveFromDate()));
		validateOverlapForCreate(provisoMainStgModel);
		commonValidation(provisoMainStgModel);
	}

	private void commonValidation(ProvisoMainStgModel provisoMainStgModel) {

		boolean validFromFlag = false;
		boolean validToFlag = false;
		boolean openToDateValidateFlag = false;

		String fromDateValidate[] = { "12-01", "03-01", "06-01", "09-01" };
		String toDateValidate[] = { "02-28", "02-29", "05-31", "08-31", "11-30" };
		String openToDateValidate = "12-31" ;

		LocalDate effectiveFromDate = OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveFromDate());
		LocalDate effectiveToDate = OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveToDate());

		DateTimeFormatter sdf1 = DateTimeFormatter.ofPattern("MM-dd");

		try {

			for (String date : fromDateValidate) {
				if (date.equals(sdf1.format(effectiveFromDate))) {
					validFromFlag = true;
				}
			}

			for (String date : toDateValidate) {
				if (date.equals(sdf1.format(effectiveToDate))) {
					validToFlag = true;
				}
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

		if (!validFromFlag) {
			throw new BusinessException(VALIDFROMDATE);
		}
		
		if ( (effectiveToDate.getYear() > effectiveFromDate.getYear() )
				&& (openToDateValidate.equals(sdf1.format(effectiveToDate))) ) {
			openToDateValidateFlag = true;
		}

		if ( (effectiveToDate.getYear() > effectiveFromDate.getYear() ) && !openToDateValidateFlag) {
			throw new BusinessException(VALIDTODATE);
		}
		
		if (!openToDateValidateFlag && !validToFlag) {
			throw new BusinessException(VALIDTODATE);
		}

		LocalDate fromDate = OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveFromDate());
		LocalDate toDate = OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveToDate());

		Date frmDate = Date.from(fromDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Date tDate = Date.from(toDate.atStartOfDay(ZoneId.systemDefault()).toInstant());

		DateTime checkFromDate = new DateTime(frmDate);
		DateTime checkToDate = new DateTime(tDate);

		Months monthsCheck = Months.monthsBetween(checkFromDate, checkToDate);

		if (!openToDateValidateFlag && monthsCheck.getMonths() > 2) {
			throw new BusinessException(QUATERLYCHECK);
		}

	}

	private void validateOverlapForCreate(ProvisoMainStgModel provisoMainStgModel) {
		if (OptionalUtil.isPresent(provisoMainStgModel.getCarrierNumCode())
				&& OptionalUtil.isPresent(provisoMainStgModel.getEffectiveFromDate())
				&& OptionalUtil.isPresent(provisoMainStgModel.getEffectiveToDate())
				&& OptionalUtil.isPresent(provisoMainStgModel.getProvisoSection())) {
			if (provisoMainStgDao.getOverlapRecordCount(OptionalUtil.getValue(provisoMainStgModel.getCarrierNumCode()),
					OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveFromDate()),
					OptionalUtil.getLocalDateValue(provisoMainStgModel.getEffectiveToDate()),
					OptionalUtil.getValue(provisoMainStgModel.getProvisoSection())) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private void validateBusinessConstraintsForUpdate(ProvisoMainStgModel provisoMainStgModel,
			ProvisoMainStgEntity provisoMainStgEntity) {
		validateEffectiveToDate(getEffectiveToDate(provisoMainStgModel, provisoMainStgEntity),
				getEffectiveFromDate(provisoMainStgModel, provisoMainStgEntity));
		validateOverlapForUpdate(provisoMainStgModel, provisoMainStgEntity);
		commonValidation(provisoMainStgModel);
	}

	private void validateOverlapForUpdate(ProvisoMainStgModel provisoMainStgModel,
			ProvisoMainStgEntity provisoMainStgEntity) {
		String carrierNumCode = getCarrierNumCode(provisoMainStgModel, provisoMainStgEntity);
		LocalDate effectiveFromDate = getEffectiveFromDate(provisoMainStgModel, provisoMainStgEntity);
		LocalDate effectiveToDate = getEffectiveToDate(provisoMainStgModel, provisoMainStgEntity);
		String provisoSection = getProvisoSection(provisoMainStgModel, provisoMainStgEntity);
		if (!carrierNumCode.equalsIgnoreCase(provisoMainStgEntity.getCarrierNumCode())
				|| !effectiveFromDate.equals(provisoMainStgEntity.getEffectiveFromDate())
				|| !effectiveToDate.equals(provisoMainStgEntity.getEffectiveToDate())
				|| !provisoSection.equalsIgnoreCase(provisoMainStgEntity.getProvisoSection())) {
			if (provisoMainStgDao.getOverlapRecordCount(carrierNumCode, effectiveFromDate, effectiveToDate,
					provisoSection, provisoMainStgEntity.getProvisoMainId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private String getCarrierNumCode(ProvisoMainStgModel provisoMainStgModel,
			ProvisoMainStgEntity provisoMainStgEntity) {
		return OptionalUtil.isPresent(provisoMainStgModel.getCarrierNumCode())
				? OptionalUtil.getValue(provisoMainStgModel.getCarrierNumCode())
				: provisoMainStgEntity.getCarrierNumCode();
	}

	private String getProvisoSection(ProvisoMainStgModel provisoMainStgModel,
			ProvisoMainStgEntity provisoMainStgEntity) {
		return OptionalUtil.isPresent(provisoMainStgModel.getProvisoSection())
				? OptionalUtil.getValue(provisoMainStgModel.getProvisoSection())
				: provisoMainStgEntity.getProvisoSection();
	}

	private void validateEffectiveToDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("EffectiveToDate[" + effectiveToDate
					+ "] should be greater than EffectiveFromDate[" + effectiveFromDate + "]");
		}
	}

	@Override
	public void deleteProvisoMain(Integer provisoMainId) {
		Optional<ProvisoMainStgEntity> mainStgEntity = provisoMainStgDao.findById(provisoMainId);
		if (mainStgEntity.isPresent() && Objects.nonNull(mainStgEntity.get().getProvisoStatus()) && Objects.nonNull(mainStgEntity.get().getAdditionalDiscountFlag())  
				&& mainStgEntity.get().getProvisoStatus() != "T" && mainStgEntity.get().getAdditionalDiscountFlag()) {
			provisoAddlDiscountStgDao.deleteProvisoAddlDiscountStg(provisoMainId,
					mainStgEntity.get().getCarrierNumCode(), mainStgEntity.get().getProvisoSeqNumber());
		}
		provisoMainStgDao.deleteProvisoMain(provisoMainId);
	}

	@Override
	public List<CommonIdName> getDiscountList() {
		
		List<CommonIdName> discountList = new ArrayList<>();
		List<FBTDElementEntity> listOfDiscounts = fBTDElementDao
				.getDiscountCodeList();
		for (FBTDElementEntity objDiscount : listOfDiscounts) {
			CommonIdName carrier = new CommonIdName();
			carrier.setId(objDiscount.getElementCode());
			carrier.setName(objDiscount.getElementCode()+" - "+objDiscount.getElementDescription());
			discountList.add(carrier);
		}

		return discountList;
	}
}
