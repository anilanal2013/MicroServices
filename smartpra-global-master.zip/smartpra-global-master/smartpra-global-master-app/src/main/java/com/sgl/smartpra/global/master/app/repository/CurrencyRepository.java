package com.sgl.smartpra.global.master.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.CurrencyEntity;

@Repository
public interface CurrencyRepository extends JpaSpecificationExecutor<CurrencyEntity>, JpaRepository<CurrencyEntity, String>{
	
	
	@Query("select currencyCode from CurrencyEntity a  where a.currencyCode = :currencyCode AND a.isActive=TRUE")
	public String getCurrencyCode(@Param("currencyCode") String currencyCode);
	
	@Query("select currencyCode from CurrencyEntity a  where a.currencyCode IN (:currencyCodeList) AND a.isActive=TRUE")
	public List<String> getCurrencyCodeList(@Param("currencyCodeList") List<String> currencyCodeList);
	
	List<CurrencyEntity> findDistinctByCurrencyCodeIsNotNullAndIsActiveTrueOrderByCurrencyCode();
}
