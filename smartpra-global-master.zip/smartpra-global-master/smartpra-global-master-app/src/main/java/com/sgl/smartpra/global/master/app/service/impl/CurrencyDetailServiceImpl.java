package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.CurrencyDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.CurrencyDetailEntity;
import com.sgl.smartpra.global.master.app.dao.repository.CurrencyDetailRepository;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.CurrencyDetailMapper;
import com.sgl.smartpra.global.master.app.service.CurrencyDetailService;
import com.sgl.smartpra.global.master.app.service.CurrencyService;
import com.sgl.smartpra.global.master.model.CurrencyDetail;

@Service
@Transactional
public class CurrencyDetailServiceImpl implements CurrencyDetailService {

	@Autowired
	CurrencyDetailRepository currencyDetailRepository;

	@Autowired
	CurrencyDetailMapper currencyDetailMapper;

	@Autowired
	CurrencyDetailDao currencyDetailDao;

	@Autowired
	CurrencyService currencyService;

	private static final String CURRENCYDETAIL = "CurrencyDetail";
	private static final String CURRENCYCODE = "Currency Code: ";
	private static final String INVALIDCURRENCYCODE = "Invalid Currency code ";
	private static final String ISMISMATCH = " is missmatch to the given currency Detail Id:";
	private static final String OVERLAP_COMBINATION_EXIST = "Record already exists";

	private Boolean operationCheck = false;

	@Override
	public List<CurrencyDetail> getAllCurrencyDetails(String currencyCode, Optional<String> effectiveDate) {
		return currencyDetailMapper
				.mapToModel(currencyDetailDao.getAllCurrencyDetails(Optional.of(currencyCode), effectiveDate));
	}

	@Override
	public CurrencyDetail getCurrencyDetailByCurrencyDetailCode(String currencyCode, int currencyDetailId) {
		return currencyDetailMapper.mapToModel(currencyDetailDao.findById(currencyDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(currencyDetailId))));
	}

	@Override
	public CurrencyDetail createCurrencyDetail(String currencyCode, CurrencyDetail currencyDetails) {
		try {
			if (OptionalUtil.isPresent(currencyDetails.getEffectiveFromDate())
					&& OptionalUtil.isPresent(currencyDetails.getEffectiveToDate())) {
				validateEffectiveToDate(OptionalUtil.getLocalDateValue(currencyDetails.getEffectiveToDate()),
						OptionalUtil.getLocalDateValue(currencyDetails.getEffectiveFromDate()));
			}
			validateLocalCurrencyFare(currencyDetails);
			validateOtherCharges(currencyDetails);
			validateDecimalUnit(currencyDetails);
			currencyService.findCurrencyByCurrencyCode(currencyCode);
		} catch (ResourceNotFoundException rnfe) {
			throw new BusinessException(INVALIDCURRENCYCODE + OptionalUtil.getValue(currencyDetails.getCurrencyCode()));

		} /*catch (BusinessException se) {
			throw new BusinessException(INVALIDCURRENCYCODE + OptionalUtil.getValue(currencyDetails.getCurrencyCode()));
		}*/
		currencyDetails.setCreatedDate(LocalDateTime.now());
		validateOverlap(currencyDetails);
		return currencyDetailMapper
				.mapToModel(currencyDetailRepository.save(currencyDetailMapper.mapToEntity(currencyDetails)));
	}

	@Override
	public CurrencyDetail updateCurrencyDetail(String currencyCode, int currencyDetailId,
			CurrencyDetail currencyDetail) {
		if (OptionalUtil.isPresent(currencyDetail.getEffectiveFromDate())
				&& OptionalUtil.isPresent(currencyDetail.getEffectiveToDate())) {
			validateEffectiveToDate(OptionalUtil.getLocalDateValue(currencyDetail.getEffectiveToDate()),
					OptionalUtil.getLocalDateValue(currencyDetail.getEffectiveFromDate()));
		}
		currencyDetail.setCurrencyCode(Optional.of(currencyCode));
		validateLocalCurrencyFare(currencyDetail);
		validateOtherCharges(currencyDetail);
		validateDecimalUnit(currencyDetail);
		CurrencyDetailEntity currencyDetailEntity = currencyDetailDao.findById(currencyDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(currencyDetailId)));

		if (currencyDetailEntity.getCurrencyCode().equals(currencyCode)) {
			try {
				currencyService.findCurrencyByCurrencyCode(currencyCode);
			} catch (ResourceNotFoundException rnfe) {
				throw new BusinessException(INVALIDCURRENCYCODE + currencyCode);

			} catch (BusinessException se) {
				throw new BusinessException(INVALIDCURRENCYCODE + currencyCode);
			}

		} else {
			throw new BusinessException(CURRENCYCODE + currencyCode + ISMISMATCH + currencyDetailId);
		}

		currencyDetail.setLastUpdatedDate(LocalDateTime.now());
		validateOverlapForUpdate(currencyDetail, currencyDetailEntity);
		return currencyDetailMapper.mapToModel(
				currencyDetailDao.update(currencyDetailMapper.mapToEntity(currencyDetail, currencyDetailEntity)));
	}

	@Override
	public void deleteCurrencyDetail(String currencyCode, int currencyDetailId) {

		Optional<CurrencyDetailEntity> currencyDetailEntity = currencyDetailDao.findById(currencyDetailId);
		if (currencyDetailEntity.isPresent()) {
			if (currencyDetailEntity.get().getCurrencyCode() == currencyCode) {
				currencyDetailDao.deleteById(currencyDetailId);
			} else {
				throw new ResourceNotFoundException(CURRENCYCODE, "code", currencyCode);
			}
		} else {
			throw new ResourceNotFoundException(CURRENCYDETAIL, "code", currencyDetailId);
		}
	}

	private void validateOverlap(CurrencyDetail currencyDetail) {
		if (currencyDetailDao.getOverLapRecordCount(
				OptionalUtil.getLocalDateValue(currencyDetail.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(currencyDetail.getEffectiveToDate()),
				OptionalUtil.getValue(currencyDetail.getCurrencyCode())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

	private void validateOverlapForUpdate(CurrencyDetail currencyDetail, CurrencyDetailEntity currencyDetailEntity) {
		if (currencyDetailDao.getOverLapRecordCountForUpdate(
				OptionalUtil.getLocalDateValue(currencyDetail.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(currencyDetail.getEffectiveToDate()),
				OptionalUtil.getValue(currencyDetail.getCurrencyCode()),
				currencyDetailEntity.getCurrencyDetailId()) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

	private void validateEffectiveToDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To Date[" + effectiveToDate
					+ "] should be greater than Effective From Date[" + effectiveFromDate + "]");
		}
	}

	protected void validateLocalCurrencyFare(CurrencyDetail currencyDetail) {
		if (OptionalUtil.isPresent(currencyDetail.getLocalCurrencyFare())) {
			String localCurrency = OptionalUtil.getValue(currencyDetail.getLocalCurrencyFare());
			operationCheck = Pattern.compile("^[0-9]\\d{0,6}(\\.\\d{1,3})?%?$").matcher(localCurrency).find();
			if (!operationCheck) {
				throw new BusinessException("Local Currency Fare should be of 10,3 format");
			}
		}
	}

	protected void validateOtherCharges(CurrencyDetail currencyDetail) {
		if (OptionalUtil.isPresent(currencyDetail.getOtherCharges())) {
			String otherCharges = OptionalUtil.getValue(currencyDetail.getOtherCharges());
			operationCheck = Pattern.compile("^[0-9]\\d{0,6}(\\.\\d{1,3})?%?$").matcher(otherCharges).find();
			if (!operationCheck) {
				throw new BusinessException("Other Charges should be of 10,3 format");
			}
		}
	}

	protected void validateDecimalUnit(CurrencyDetail currencyDetail) {
		if (OptionalUtil.isPresent(currencyDetail.getDecimalUnit())) {
			String decimalUnit = OptionalUtil.getValue(currencyDetail.getDecimalUnit());
			operationCheck = Pattern.compile("^[0-9]\\d{0,3}(\\.\\d{1,3})?%?$").matcher(decimalUnit).find();
			if (!operationCheck) {
				throw new BusinessException("Decimal Unit should be of 7,3 format");
			}
		}
	}

	@Override
	public CurrencyDetail getCurrencyByCurrencyCodeAndEffectiveDate(String currencyCode, Optional<String> effectiveDate) {
		return currencyDetailMapper.mapToModel(currencyDetailDao.getCurrencyByCurrencyCodeAndEffectiveDate(currencyCode,effectiveDate));
	}

}
