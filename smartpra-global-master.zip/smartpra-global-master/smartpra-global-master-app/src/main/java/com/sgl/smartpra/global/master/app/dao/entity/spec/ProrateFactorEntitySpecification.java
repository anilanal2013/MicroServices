package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.repository.entity.ProrateFactorEntity;

public final class ProrateFactorEntitySpecification {

	private static final String FROM_CITY_CODE = "fromCityCode";
	private static final String TO_CITY_CODE = "toCityCode";
	private static final String ACTIVATE = "activate";
	private static final String EFFECTIVE_TO_DATE = "effectiveToDate";
	private static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";

	private static void orderByAsc(Root<ProrateFactorEntity> prorateFactorEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String effectiveToDate) {
		criteriaQuery.orderBy(criteriaBuilder.asc(prorateFactorEntity.get(effectiveToDate)));
	}

	public static Specification<ProrateFactorEntity> search(Optional<String> fromCityCode, Optional<String> toCityCode,
			Optional<Boolean> activate) {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(fromCityCode)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(FROM_CITY_CODE),
						OptionalUtil.getValue(fromCityCode)));
			}
			if (OptionalUtil.isPresent(toCityCode)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(TO_CITY_CODE),
						OptionalUtil.getValue(toCityCode)));
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates
						.add(criteriaBuilder.equal(prorateFactorEntity.get(ACTIVATE), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(ACTIVATE), true));
			}
			orderByAsc(prorateFactorEntity, criteriaQuery, criteriaBuilder, EFFECTIVE_TO_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProrateFactorEntity> getAllProrateFactorEntity(Optional<String> fromCityCode,
			Optional<String> toCityCode, Optional<String> effectiveDate) {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(fromCityCode)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(FROM_CITY_CODE),
						OptionalUtil.getValue(fromCityCode)));
			}
			if (OptionalUtil.isPresent(toCityCode)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(TO_CITY_CODE),
						OptionalUtil.getValue(toCityCode)));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
						prorateFactorEntity.get(EFFECTIVE_FROM_DATE), prorateFactorEntity.get(EFFECTIVE_TO_DATE))));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	// checkOverlapExits
	public static Specification<ProrateFactorEntity> equalsFromCityCode(String fromCityCode) {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateFactorEntity.get(FROM_CITY_CODE), fromCityCode);
	}

	public static Specification<ProrateFactorEntity> equalsToCityCode(String toCityCode) {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateFactorEntity.get(TO_CITY_CODE), toCityCode);
	}

	public static Specification<ProrateFactorEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), prorateFactorEntity.get(EFFECTIVE_FROM_DATE),
				prorateFactorEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<ProrateFactorEntity> isActive() {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateFactorEntity.get(ACTIVATE), true);
	}

	public static Specification<ProrateFactorEntity> isNotActive() {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(prorateFactorEntity.get(ACTIVATE), false);
	}

	public static Specification<ProrateFactorEntity> verifyRecordExits(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Integer prorateFactorId, Optional<String> fromCityCode,
			Optional<String> toCityCode) {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(effectiveFromDate)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(EFFECTIVE_FROM_DATE),
						OptionalUtil.getValue(effectiveFromDate)));
			}
			if (OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(EFFECTIVE_TO_DATE),
						OptionalUtil.getValue(effectiveToDate)));
			}
			if (prorateFactorId != null) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get("prorateFactorId"), prorateFactorId));
			}
			if (OptionalUtil.isPresent(fromCityCode)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(FROM_CITY_CODE),
						OptionalUtil.getValue(fromCityCode)));
			}
			if (OptionalUtil.isPresent(toCityCode)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(TO_CITY_CODE),
						OptionalUtil.getValue(toCityCode)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProrateFactorEntity> getAllProrateFactorEntityFTE(Optional<String> fromCityCode,
			Optional<String> toCityCode, Optional<String> effectiveDate) {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(fromCityCode)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(FROM_CITY_CODE),
						OptionalUtil.getValue(fromCityCode)));
			}
			if (OptionalUtil.isPresent(toCityCode)) {
				predicates.add(criteriaBuilder.equal(prorateFactorEntity.get(TO_CITY_CODE),
						OptionalUtil.getValue(toCityCode)));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
						prorateFactorEntity.get(EFFECTIVE_FROM_DATE), prorateFactorEntity.get(EFFECTIVE_TO_DATE))));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProrateFactorEntity> notEqualsToProrateFactorId(Integer prorateFactorId) {
		return (prorateFactorEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(prorateFactorEntity.get("prorateFactorId"), prorateFactorId);
	}
}
