package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.repository.entity.FBTDElementEntity;

public final class FBTDElementSpecification {
	
	public static Specification<FBTDElementEntity> notEqualsfbtdId(Integer fbtdId) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(fbtdElementEntity.get("fbtdId"), fbtdId);
	}
	
	public static Specification<FBTDElementEntity> search(Optional<Integer> elementType, Optional<String> elementCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(elementType)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("elementType"),
						OptionalUtil.getValue(elementType)));
			}
			if (OptionalUtil.isPresent(elementCode)) {
				predicates.add(criteriaBuilder.like(fbtdElementEntity.get("elementCode"),
						OptionalUtil.getValue(elementCode) +"%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								fbtdElementEntity.get("effectiveFromDate"), fbtdElementEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								fbtdElementEntity.get("effectiveFromDate"), fbtdElementEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							fbtdElementEntity.get("effectiveFromDate"), fbtdElementEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							fbtdElementEntity.get("effectiveFromDate"), fbtdElementEntity.get("effectiveToDate")));
				}
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("activate"), true));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<FBTDElementEntity> equalsClientId(Optional<String> elementCode) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), OptionalUtil.getValue(elementCode));
	}

	public static Specification<FBTDElementEntity> equalsCarrierCode(Optional<Integer> elementType) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementType"), OptionalUtil.getValue(elementType));
	}

	public static Specification<FBTDElementEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), fbtdElementEntity.get("effectiveFromDate"),
				fbtdElementEntity.get("effectiveToDate"));
	}

	public static Specification<FBTDElementEntity> getAllFBTDEntity(Optional<Integer> elementType, Optional<String> elementCode,
			Optional<String> effectiveDate) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(elementType)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("elementType"),
						OptionalUtil.getValue(elementType)));
			}
			if (OptionalUtil.isPresent(elementCode)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("elementCode"),
						OptionalUtil.getValue(elementCode)));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								fbtdElementEntity.get("effectiveFromDate"), fbtdElementEntity.get("effectiveToDate"))));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FBTDElementEntity> findByElementType(Integer elementType) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementType"), elementType);
	}
	
	public static Specification<FBTDElementEntity> isActive() {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("activate"), true);
	}

	// findByElementCode
	public static Specification<FBTDElementEntity> findByElementCode(String elementCode) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), elementCode);
	}

	// getFBTDElementByElementCodeBasedOnPrimeCode
	public static Specification<FBTDElementEntity> findByElementBasedOnPrimeCode(String elementCode) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), elementCode);
	}
	
	public static Specification<FBTDElementEntity> findByElementTypePrimeCode(Integer elementType) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementType"), elementType);
	}
	
	// validateCabin
	public static Specification<FBTDElementEntity> validateCabin(String cabin) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), cabin);
	}
	
	// validateOtherInfo
	public static Specification<FBTDElementEntity> validateOtherInfo(String otherInfo) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("otherInfo"), otherInfo);
	}
	
	public static Specification<FBTDElementEntity> findAddInfo(String additionalInfo) { 
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("additionalInfo"), additionalInfo); 
	}

	public static Specification<FBTDElementEntity> validateElementCode(String elementCode) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), elementCode);
	}

	public static Specification<FBTDElementEntity> notEqualJAndD(String additionalInfoJ, String additionalInfoD ) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.not(fbtdElementEntity.get("additionalInfo").in(additionalInfoJ,additionalInfoD));
	}

	public static Specification<FBTDElementEntity> isAdditionalInfoNull() {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.isNull(fbtdElementEntity.get("additionalInfo"));
	}
	// validateSeasonalCode
	public static Specification<FBTDElementEntity> validateSeasonalCode(String seasonalCode) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), seasonalCode);
	}
	
	// validateDayOfWeek
	public static Specification<FBTDElementEntity> validateDayOfWeek(String dayOfWeek) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), dayOfWeek);
	}

	// validateDiscountCode
	public static Specification<FBTDElementEntity> validateDiscountCode(String discountCode) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), discountCode);
	}
	public static Specification<FBTDElementEntity> findAddInfoD(String additionalInfo) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("additionalInfo"), additionalInfo);
	}
	
	public static Specification<FBTDElementEntity> equalsEffectiveToDateGreaterThanEqual() {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(fbtdElementEntity.get("effectiveToDate"), LocalDate.now());
	}
	
	// validateJourneyType
	public static Specification<FBTDElementEntity> validateJourneyType(String journeyType) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), journeyType);
	}
	public static Specification<FBTDElementEntity> findAddInfoJ(String journeyType) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("additionalInfo"), journeyType);
	}

	// validateZedIdentifier
	public static Specification<FBTDElementEntity> validateZedIdentifier(String zedIdentifier) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fbtdElementEntity.get("elementCode"), zedIdentifier);
	}
	
	public static Specification<FBTDElementEntity> getAllFBTDEntity1(Optional<String> date,
			Optional<Integer> elementType, Optional<String> elementCode) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(date)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("date"), OptionalUtil.getValue(date)));
			}
			if (OptionalUtil.isPresent(elementType)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("elementType"),
						OptionalUtil.getValue(elementType)));
			}
			if (OptionalUtil.isPresent(elementCode)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("elementCode"),
						OptionalUtil.getValue(elementCode)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FBTDElementEntity> verifyRecordExits(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Integer fbtdId, Optional<Integer> elementType,
			Optional<String> elementCode) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(effectiveFromDate)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("effectiveFromDate"),
						OptionalUtil.getValue(effectiveFromDate)));
			}
			if (OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("effectiveToDate"),
						OptionalUtil.getValue(effectiveToDate)));
			}
			if (fbtdId != null) {
				predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("fbtdId"), fbtdId));
			}
			if (OptionalUtil.isPresent(elementType)) {
				predicates.add(
						criteriaBuilder.equal(fbtdElementEntity.get("elementType"), OptionalUtil.getValue(elementType)));
			}
			if (OptionalUtil.isPresent(elementCode)) {
				predicates.add(
						criteriaBuilder.equal(fbtdElementEntity.get("elementCode"), OptionalUtil.getValue(elementCode)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FBTDElementEntity> verifyIfSameRecordExits(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Integer> elementType, Optional<String> elementCode) {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								fbtdElementEntity.get("effectiveFromDate"), fbtdElementEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								fbtdElementEntity.get("effectiveFromDate"), fbtdElementEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							fbtdElementEntity.get("effectiveFromDate"), fbtdElementEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							fbtdElementEntity.get("effectiveFromDate"), fbtdElementEntity.get("effectiveToDate")));
				}
			}
			if (OptionalUtil.isPresent(elementType)) {
				predicates.add(
						criteriaBuilder.equal(fbtdElementEntity.get("elementType"), OptionalUtil.getValue(elementType)));
			}
			if (OptionalUtil.isPresent(elementCode)) {
				predicates.add(
						criteriaBuilder.equal(fbtdElementEntity.get("elementCode"), OptionalUtil.getValue(elementCode)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<FBTDElementEntity> equalCheckElementCodeWithAdditionalInfo() {
		return (fbtdElementEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			predicates.add(criteriaBuilder.equal(fbtdElementEntity.get("elementCode"), fbtdElementEntity.get("additionalInfo")));
			orderByAsc(fbtdElementEntity, criteriaQuery, criteriaBuilder);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
			
			
		
	}
	
	public static void orderByAsc(Root<FBTDElementEntity>fbtdElementEntity,CriteriaQuery<?> criteriaQuery,CriteriaBuilder criteriaBuilder) {
		criteriaQuery.orderBy(criteriaBuilder.asc(fbtdElementEntity.get("otherInfo")));
	}

	
}
