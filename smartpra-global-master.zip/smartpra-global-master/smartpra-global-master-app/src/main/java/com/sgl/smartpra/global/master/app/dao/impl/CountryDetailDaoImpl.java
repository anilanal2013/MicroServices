package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.CountryDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.CountryDetailEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.CountryDetailEntitySpecification;
import com.sgl.smartpra.global.master.app.repository.CountryDetailRepository;
import com.sgl.smartpra.global.master.model.CountryDetail;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CountryDetailDaoImpl extends CommonSearchDao<CountryDetail> implements CountryDetailDao{
	
	@Autowired
	private CountryDetailRepository countryDetailRepository;

	@Override
	@Cacheable(value = "country", key = "#id")
	public Optional<CountryDetailEntity> findById(Integer id) {
		log.info("Cacheable countryDetail Entity's ID= {}", id);
		return countryDetailRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "countryDetail", key = "#countryDetailEntity.countryDtlId"),
			@CacheEvict(value = "countryDetailSearch", allEntries = true) })
	public CountryDetailEntity create(CountryDetailEntity countryDetailEntity) {
		return countryDetailRepository.save(countryDetailEntity);
	}

	@Override
	@CachePut(value = "countryDetail", key = "#countryDetailEntity.countryDtlId")
	@CacheEvict(value = "countryDetailSearch", allEntries = true)
	public CountryDetailEntity update(CountryDetailEntity countryDetailEntity) {
		return countryDetailRepository.save(countryDetailEntity);
	}
	
	public List<CountryDetailEntity> createAll(List<CountryDetailEntity> countryDetailEntity) {
		return countryDetailRepository.saveAll(countryDetailEntity);
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub		
	}

	@Override	
	public List<CountryDetailEntity> findAll() {
		return countryDetailRepository.findAll();
	}

	@Override
	public List<CountryDetailEntity> getAllCountryEntityByEffectiveDate(Optional<String> countryCode,
			Optional<String> effectiveDate) {
		return countryDetailRepository.findAll(CountryDetailEntitySpecification.getAllCountryEntityByEffectiveDate(countryCode, effectiveDate));
	}

	@Override
	public List<CountryDetailEntity> findByCountryCode(Optional<String> countryCode) {
		return countryDetailRepository.findAll(Specification.where(CountryDetailEntitySpecification.likeCountryCode(countryCode)));
	}
	
	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String countryCode) {
		return countryDetailRepository.count(Specification.where(CountryDetailEntitySpecification.equalsCountryCode(countryCode))
				.and((CountryDetailEntitySpecification.betweenEffectiveFromPeriodAndEffectiveToPeriod(effectiveFromDate)
				.or(CountryDetailEntitySpecification.betweenEffectiveFromPeriodAndEffectiveToPeriod(effectiveToDate)))
				.or((CountryDetailEntitySpecification.greaterThanOrEqualToEffectiveFromDate(effectiveFromDate)
				.and(CountryDetailEntitySpecification.lessThanOrEqualToEffectiveToDate(effectiveToDate)))))
				);
	}

	@Override
	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String countryCode, Integer countryDtlId) {
		return countryDetailRepository.count(Specification.where(CountryDetailEntitySpecification.equalsCountryCode(countryCode))
				.and(CountryDetailEntitySpecification.betweenEffectiveFromPeriodAndEffectiveToPeriod(effectiveFromDate)
				.or(CountryDetailEntitySpecification.betweenEffectiveFromPeriodAndEffectiveToPeriod(effectiveToDate)))
				.and(CountryDetailEntitySpecification.notEqualsCountryDtlId(countryDtlId))
				.or((CountryDetailEntitySpecification.greaterThanOrEqualToEffectiveFromDate(effectiveFromDate)
				.and(CountryDetailEntitySpecification.lessThanOrEqualToEffectiveToDate(effectiveToDate))))
				);
	}
	
	@Override
	public List<CountryDetailEntity> findByCountryCode(String countryCode) {
		return countryDetailRepository.findAll(Specification.where(CountryDetailEntitySpecification.equalsCountryCode(countryCode)));
	}

	@Override
	public CountryDetailEntity getCountryDetailsByEffectiveDate(String countryCode, Optional<String> issueDate) {
		return countryDetailRepository.findOne(Specification.where(CountryDetailEntitySpecification.equalsCountryCode(countryCode))
				.and(CountryDetailEntitySpecification.betweenEffectiveFromPeriodAndEffectiveToPeriod(OptionalUtil.getLocalDateValue(issueDate)))
				.or((CountryDetailEntitySpecification.greaterThanOrEqualToEffectiveFromDate(OptionalUtil.getLocalDateValue(issueDate))
				.and(CountryDetailEntitySpecification.lessThanOrEqualToEffectiveToDate(OptionalUtil.getLocalDateValue(issueDate))))))
				.orElse(new CountryDetailEntity());
	}

}
