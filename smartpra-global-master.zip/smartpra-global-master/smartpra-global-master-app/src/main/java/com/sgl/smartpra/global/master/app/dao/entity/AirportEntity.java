package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper=false)
@DynamicUpdate
@DynamicInsert
@Table(name = "global_mas_airport")
public class AirportEntity extends BaseEntity{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "airport_code", nullable = false, length = 3)
	private String airportCode;

	@Column(name = "airport_name", nullable = false, length = 30)
	private String airportName;

	@Column(name = "city_code", nullable = false, length = 3)
	private String cityCode;

	@Column(name = "city_name", nullable = false, length = 30)
	private String cityName;

	@Column(name = "country_code", nullable = false, length = 2)
	private String countryCode;

	@Column(name = "state_code", nullable = false, length = 4)
	private String stateCode;

	@Column(name = "eu_vat_exempted", nullable = false, length = 1)
	private String euVatExempted;

	@Column(name = "longitude", nullable = false, length = 10)
	private String longitude;

	@Column(name = "lattitude", nullable = false, length = 10)
	private String lattitude;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
