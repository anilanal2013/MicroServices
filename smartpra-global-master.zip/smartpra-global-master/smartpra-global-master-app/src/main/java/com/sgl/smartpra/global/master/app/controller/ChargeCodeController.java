package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.repository.entity.ChargeCodeEntity;
import com.sgl.smartpra.global.master.app.service.ChargeCodeService;
import com.sgl.smartpra.global.master.model.ChargeCode;

@RestController
public class ChargeCodeController {

	@Autowired
	private ChargeCodeService chargeCodeService;

	@PostMapping("/charge-categories/{chargeCategoryCode}/charge-codes")
	public ChargeCode createChargeCode(@PathVariable(value = "chargeCategoryCode") Optional<String> chargeCategoryCode,
			@Validated(Create.class) @RequestBody ChargeCode chargeCodeModel) {

		return chargeCodeService.createChargeCode(chargeCategoryCode, chargeCodeModel);
	}

	@GetMapping("/charge-categories/{chargeCategoryCode}/charge-codes/{chargeCode}")
	public ChargeCode getChargeCodeByChargeCode(
			@PathVariable(value = "chargeCategoryCode") Optional<String> chargeCategoryCode,
			@PathVariable(value = "chargeCode") Optional<String> chargeCode) {
		return chargeCodeService.getChargeCodeByChargeCode(chargeCategoryCode, chargeCode);
	}

	@GetMapping("/charge-categories/{chargeCategoryCode}/charge-codes")
	public List<ChargeCode> getAllChargeCode(
			@PathVariable(value = "chargeCategoryCode", required = true) Optional<String> chargeCategoryCode,
			@RequestParam(value = "chargeCode", required = false) Optional<String> chargeCode,
			@RequestParam(value = "chargeCodeName", required = false) Optional<String> chargeCodeName) {
		return chargeCodeService.getAllChargeCode(chargeCategoryCode, chargeCode, chargeCodeName);
	}
	
	@GetMapping("/charge-codes")
	public List<ChargeCode> getAllChargeCodesFromChargeCategory(
			@RequestParam(value = "chargeCategoryCode", required = true) String chargeCategoryCode){
		return chargeCodeService.getAllChargeCode(Optional.of(chargeCategoryCode), null, null);
	}

	@PutMapping("/update-charge-codes")
	public List<ChargeCodeEntity> updateChargeCode(
			@Validated(Update.class) @RequestBody List<ChargeCode> chargeCodeModel) {
		return chargeCodeService.updateChargeCode(chargeCodeModel);
	}

	@PutMapping("/charge-categories/{chargeCategoryCode}/charge-codes/{chargeCode}/deactivate") 
	public void deactivateChargeCode(
			@Valid @PathVariable(value = "chargeCategoryCode", required = true) Optional<String> chargeCategoryCode,
			@PathVariable(value = "chargeCode", required = true) Optional<String> chargeCode,
			@RequestParam(value = "lastUpdatedBy", required = true) Optional<String> lastUpdatedBy) {

		chargeCodeService.deactivateChargeCode(chargeCategoryCode, chargeCode, lastUpdatedBy);

	}

	@PutMapping("/charge-categories/{chargeCategoryCode}/charge-codes/{chargeCode}/activate")
	public void activateChargeCode(
			@Valid @PathVariable(value = "chargeCategoryCode", required = true) Optional<String> chargeCategoryCode,
			@PathVariable(value = "chargeCode", required = true) Optional<String> chargeCode,
			@RequestParam(value = "lastUpdatedBy", required = true) Optional<String> lastUpdatedBy) {

		chargeCodeService.activateChargeCode(chargeCategoryCode, chargeCode, lastUpdatedBy);

	}
	
	@GetMapping("/charge-codes/account-scenario")
	public List<String> getChargeCodeFromChargeCodeMaster(){
		return chargeCodeService.getChargeCodeFromChargeCodeMaster();
	}
}
