package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.service.CarrierDetailService;
import com.sgl.smartpra.global.master.model.CarrierDetail;

@RestController
public class CarrierDetailController {

	@Autowired
	CarrierDetailService carrierDetailService;


	private static final String CARRIERDETAILIDVALIDATION = "Carrier Detail Id should be a digit ";  

	private static final String DIGITVALIDATION = "^[0-9]+$";
	
	private static final String CARRIERCODELENGHT="carrierCode should be  3 characters";

	@GetMapping("/carriers/{carrierCode}/details")
	public List<CarrierDetail> getListOfCarrierDetailsByEffectiveDate(@PathVariable(value = "carrierCode") String carrierCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate) {
		if(!(carrierCode.length()==3)) {
			 throw new ServiceException(CARRIERCODELENGHT);
		}
			return carrierDetailService.getListOfCarrierDetailsByEffectiveDate(Optional.of(carrierCode), effectiveFromDate);	
	}

	@GetMapping("/carriers/{carrierCode}/details/{carrierDetailId}")
	public CarrierDetail getCarrierDetailByCarrierDetailCode(@PathVariable(value = "carrierCode") String carrierCode,
			@PathVariable(value = "carrierDetailId") String carrierDetailId) {
		if(!(carrierCode.length()==3)) {
			 throw new ServiceException(CARRIERCODELENGHT);
		}
		int carrierDetailIdParse=0;
		try {
			carrierDetailIdParse=Integer.parseInt(carrierDetailId);
		}catch(NumberFormatException nfe) {
			throw new ServiceException(CARRIERDETAILIDVALIDATION+carrierDetailId);
		}
			return carrierDetailService.getCarrierDetailByCarrierDetailCode(carrierCode, carrierDetailIdParse);	
	}

	@PostMapping("/carriers/{carrierCode}/details")
	public CarrierDetail createCarrierDetail(@PathVariable(value = "carrierCode") String carrierCode,
			@Validated(Create.class) @RequestBody CarrierDetail carrierDetails) {
		if(!(carrierCode.length()>=1&&carrierCode.length()<=3)) {
			 throw new ServiceException(CARRIERCODELENGHT);
		}
			return carrierDetailService.createCarrierDetail(carrierCode, carrierDetails);
	}

	@PutMapping("/carriers/{carrierCode}/details/{carrierDetailId}")
	public CarrierDetail updateCarrierdetails(@PathVariable(value = "carrierCode") String carrierCode,
			@PathVariable(value = "carrierDetailId") String carrierDetailId,
			@Validated(Update.class) @RequestBody CarrierDetail carrierDetails) {
		int carrierDetailIdParse = 0;
		if(!(carrierCode.length()>=1&&carrierCode.length()<=3)) {
			 throw new ServiceException(CARRIERCODELENGHT);
		}
		if (Pattern.compile(DIGITVALIDATION).matcher(carrierDetailId).find()) {
			carrierDetailIdParse = Integer.parseInt(carrierDetailId);
		} else {
			throw new ServiceException(CARRIERDETAILIDVALIDATION+carrierDetailId);
		}
		return carrierDetailService.updateCarrierDetail(carrierCode, carrierDetailIdParse, carrierDetails);
	}

	@DeleteMapping("/carriers/{carrierCode}/details/{carrierDetailId}")
	public void deleteCarrierDetail(@PathVariable(value = "carrierCode") String carrierCode,
			@PathVariable(value = "carrierDetailId") String carrierDetailId) {
		int carrierDetailIdParse = 0;
		if (Pattern.compile(DIGITVALIDATION).matcher(carrierDetailId).find()) {
			carrierDetailIdParse = Integer.parseInt(carrierDetailId);
		} else {
			throw new ServiceException(CARRIERDETAILIDVALIDATION+carrierDetailId);
		}
		carrierDetailService.deleteCarrierDetail(carrierCode, carrierDetailIdParse);
	}
	
	
	@GetMapping("/carriers/details/{carrierDesignatorCode}/{effectiveDate}")
	public CarrierDetail getCarrierType(@PathVariable(value = "carrierDesignatorCode") String carrierDesignatorCode,@PathVariable(value = "effectiveDate") String effectiveDate) {
		return carrierDetailService.getCarrierType(carrierDesignatorCode,effectiveDate);
	}

	@GetMapping("/carriers/details/carrierType/{carrierCode}/{effectiveDate}")
	public CarrierDetail getCarrierTypeByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode,
			@PathVariable(value = "effectiveDate") String effectiveDate) {
		if(!(carrierCode.length()>=1&&carrierCode.length()<=3)) {
			 throw new ServiceException(CARRIERCODELENGHT);
		}
		return carrierDetailService.getCarrierTypeByCarrierCode(carrierCode, effectiveDate);
	}
}
