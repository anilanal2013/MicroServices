package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ChargeCategoryEntity;
import com.sgl.smartpra.global.master.model.ChargeCategory;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ChargeCategoryMapper extends BaseMapper<ChargeCategory, ChargeCategoryEntity> {

	ChargeCategoryEntity mapToEntity(ChargeCategory chargeCate, @MappingTarget ChargeCategoryEntity categoryEntity);

	// @Mapping(source = "chargeCategoryCode", target = "chargeCategoryCode", ignore
	// = true)
	ChargeCategoryEntity mapToEntity(ChargeCategory chargeCategory);
}