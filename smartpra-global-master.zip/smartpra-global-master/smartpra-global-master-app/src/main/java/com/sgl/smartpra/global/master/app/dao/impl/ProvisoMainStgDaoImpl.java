package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.global.master.app.dao.ProvisoMainStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoMainStgEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoMainStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoMainStgDaoImpl implements ProvisoMainStgDao {

	@Autowired
	private ProvisoMainStgRepository provisoMainStgRepository;
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@Cacheable(value = "provisoMainStgModel", key = "#id")
	public Optional<ProvisoMainStgEntity> findById(Integer id) {

		log.info("Cacheable Proviso Main Entity's ID= {}", id);
		return provisoMainStgRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "provisoMainStgModel", key = "#provisoMainStgEntity.provisoMainId") })
	public ProvisoMainStgEntity create(ProvisoMainStgEntity provisoMainStgEntity) {

		return provisoMainStgRepository.save(provisoMainStgEntity);
	}

	@Override
	@CachePut(value = "provisoMainStgModel", key = "#provisoMainStgEntity.provisoMainId")
	public ProvisoMainStgEntity update(ProvisoMainStgEntity provisoMainStgEntity) {

		return provisoMainStgRepository.save(provisoMainStgEntity);
	}

	@Override
	public List<ProvisoMainStgEntity> searchProvisoMain(Optional<String> carrierNumCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> provisoSection,
			Optional<String> provisoStatus) {

		return provisoMainStgRepository.findAll(ProvisoMainStgEntitySpecification.search(carrierNumCode,
				effectiveFromDate, effectiveToDate, provisoSection, provisoStatus));
	}

	@Override
	public ProvisoMainStgEntity moveProvisoMainToProd(Integer provisoMainId,
			ProvisoMainStgEntity provisoMainStgEntity) {

		return null;
	}

	@Override
	public ProvisoMainStgEntity inactivateProvisoMain(Integer provisoMainId,
			ProvisoMainStgEntity provisoMainStgEntity) {

		return null;
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String provisoSection) {
		return provisoMainStgRepository.count(Specification.where(ProvisoMainStgEntitySpecification
				.equalsCarrierNumCode(carrierNumCode)
				.and(ProvisoMainStgEntitySpecification.equalsProvisoSection(provisoSection))
				.and(ProvisoMainStgEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate).or(
						ProvisoMainStgEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))));
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String provisoSection, Integer provisoMainId) {
		return provisoMainStgRepository.count(Specification.where(ProvisoMainStgEntitySpecification
				.equalsCarrierNumCode(carrierNumCode)
				.and(ProvisoMainStgEntitySpecification.equalsProvisoSection(provisoSection))
				.and(ProvisoMainStgEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProvisoMainStgEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(ProvisoMainStgEntitySpecification.notEqualsfopId(provisoMainId))));
	}

	@Override
	public void deleteProvisoMain(Integer provisoMainId) {
		provisoMainStgRepository.deleteProvisoMainRecordFromDb(provisoMainId);
	}

	@Override
	public Integer getMaxOfProvisoSeqnumber(Optional<String> carrierNumCode) {
		return provisoMainStgRepository.getMaxOfProvisoSeqNumber(carrierNumCode);
	}

	@Override
	public Integer getMaxOfProvisoMainId() {
		return provisoMainStgRepository.getMaxOfProvisoMainId();
	}
	
	@Override
	@Transactional(rollbackFor = BusinessException.class)
	public void updateProvisoMainStg(ProvisoMainStgEntity entity) {
		String q = "Update ProvisoMainStgEntity s set s.provisoStatus=:provisoStatus "
				+ "where s.provisoMainId=:provisoMainId ";
		Query query = entityManager.createQuery(q);
		query.setParameter("lastUpdatedDate", LocalDateTime.now());
		query.setParameter("provisoMainId", entity.getProvisoMainId());
		query.setParameter("provisoStatus", entity.getProvisoStatus());
		query.executeUpdate();
	}
	
}
