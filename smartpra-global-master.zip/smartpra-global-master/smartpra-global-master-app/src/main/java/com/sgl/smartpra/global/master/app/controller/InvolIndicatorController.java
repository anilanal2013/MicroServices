package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.InvolIndicatorService;
import com.sgl.smartpra.global.master.model.InvolIndicator;
import com.sgl.smartpra.global.master.model.InvolIndicatorResponse;

@RestController
public class InvolIndicatorController {

	@Autowired
	private InvolIndicatorService involIndicatorService;

	@GetMapping("/involindicator/get-all")
	public List<InvolIndicator> getListOfAllInvolIndicator(
			@RequestParam(value = "effectiveFromDate", required = false) Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) Optional<String> effectiveToDate,
			@RequestParam(value = "indicatorType", required = false) Optional<String> indicatorType,
			@RequestParam(value = "ticketField", required = false) Optional<String> ticketField,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return involIndicatorService.getListOfAllInvol(effectiveFromDate, effectiveToDate, indicatorType, ticketField,
				activate);
	}

	@GetMapping("/invol-indicator")
	public List<InvolIndicator> getListOfInvolIndicator(
			@RequestParam(value = "effectiveDate", required = false) Optional<String> effectiveDate,
			@RequestParam(value = "indicatorType", required = false) Optional<String> indicatorType) {
		return involIndicatorService.getListOfInvolIndicator(effectiveDate, indicatorType);
	}

	@GetMapping("/invol-indicator/{involIndicatorId}")
	public InvolIndicator getInvolIndicatorByInvolIndicatorId(
			@PathVariable(value = "involIndicatorId") int involIndicatorId) {
		return involIndicatorService.getInvolIndicatorByInvolIndicatorId(involIndicatorId);
	}

	@PostMapping("/invol-indicator")
	public InvolIndicator createInvolIndicator(@Validated(Create.class) @RequestBody InvolIndicator involIndicator) {
		return involIndicatorService.createInvolIndicator(involIndicator);
	}

	@PutMapping("/invol-indicator/{involIndicatorId}")
	public InvolIndicator updateInvolIndicator(@PathVariable(value = "involIndicatorId") int involIndicatorId,
			@Validated(Update.class) @RequestBody InvolIndicator involIndicator) {
		return involIndicatorService.updateInvolIndicator(involIndicatorId, involIndicator);
	}

	@PutMapping("/invol-indicator/{involIndicatorId}/deactivate")
	public void deactivateInvolIndicator(@Valid @PathVariable(value = "involIndicatorId") int involIndicatorId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		involIndicatorService.deactivateInvolIndicator(involIndicatorId, lastUpdatedBy);
	}

	@PutMapping("/invol-indicator/{involIndicatorId}/activate")
	public void activateInvolIndicator(@Valid @PathVariable(value = "involIndicatorId") int involIndicatorId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		involIndicatorService.activateInvolIndicator(involIndicatorId, lastUpdatedBy);
	}

	// validate the issueing date
	@GetMapping("/invol-indicator-date")
	public List<InvolIndicator> validateDate(
			@RequestParam(value = "effectiveDate", required = false) Optional<String> effectiveDate) {
		return involIndicatorService.validateDate(effectiveDate);
	}

	@GetMapping("/involindicator/list")
	public InvolIndicatorResponse getListOfAllInvolIndicator(Pageable pageable,
			@RequestParam(value = "effectiveFromDate", required = false) Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) Optional<String> effectiveToDate,
			@RequestParam(value = "indicatorType", required = false) Optional<String> indicatorType,
			@RequestParam(value = "ticketField", required = false) Optional<String> ticketField,
			@RequestParam(value = "activate", required = false) Boolean activate) {

		InvolIndicator involIndicator = new InvolIndicator();
		if (OptionalUtil.isPresent(effectiveFromDate)) {
			involIndicator.setEffectiveFromDate(effectiveFromDate);
		}
		if (OptionalUtil.isPresent(effectiveToDate)) {
			involIndicator.setEffectiveToDate(effectiveToDate);
		}
		involIndicator.setIndicatorType(indicatorType);
		involIndicator.setTicketField(ticketField);
		involIndicator.setActivate(activate);

		return involIndicatorService.getListOfAllInvol(pageable, involIndicator);
	}

}
