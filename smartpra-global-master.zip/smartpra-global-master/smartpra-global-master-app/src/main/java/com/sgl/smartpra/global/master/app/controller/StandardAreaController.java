package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.StandardAreaSrevice;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.StandardArea;

@RestController
public class StandardAreaController {

	@Autowired
	private StandardAreaSrevice standardAreaService;

	@GetMapping("/standard-areas")
	public List<StandardArea> getListOfStandardArea(
			@RequestParam(value = "standardAreaCode", required = false) Optional<String> standardAreaCode,
			@RequestParam(value = "standardAreaName", required = false) Optional<String> standardAreaName,
			@RequestParam(value = "activate", required = false) Boolean activate) {
		return standardAreaService.getListOfStandardArea(standardAreaCode, standardAreaName, activate);
	}

	@GetMapping("/standard-areas/{standardAreaCode}")
	public StandardArea getStandardAreaByStandardAreaCode(
			@PathVariable(value = "standardAreaCode") String standardAreaCode) {
		return standardAreaService.getStandardAreaByStandardAreaCode(standardAreaCode);
	}

	@PostMapping("/standard-areas")
	public StandardArea createStandardArea(@Validated(Create.class) @RequestBody StandardArea standardarea) {
		return standardAreaService.createStandardArea(standardarea);
	}

	@PutMapping("/standard-areas/{standardAreaCode}")
	public StandardArea updateStandardArea(@PathVariable(value = "standardAreaCode") String standardAreaCode,
			@Validated(Update.class) @RequestBody StandardArea standardarea) {
		return standardAreaService.updateStandardArea(standardAreaCode, standardarea);
	}

	@PutMapping("/standard-areas/{standardAreaCode}/deactivate")
	public void deactivateStandardArea(@Valid @PathVariable(value = "standardAreaCode") String standardAreaCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		standardAreaService.deactivateStandardArea(standardAreaCode, lastUpdatedBy);

	}

	@PutMapping("/standard-areas/{standardAreaCode}/activate")
	public void activateStandardArea(@Valid @PathVariable(value = "standardAreaCode") String standardAreaCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		standardAreaService.activateStandardArea(standardAreaCode, lastUpdatedBy);
	}

	// get standard area list
	@PostMapping("/standard-areas/standard-area-list")
	public List<String> createGetStandardAreaList(@RequestBody Airport airport) {
		return standardAreaService.getStandardAreaList(airport);
	}

	@GetMapping("/standard-areas/validate/{standardAreaCode}")
	public boolean validateStandardArea(@PathVariable(value = "standardAreaCode") String standardAreaCode) {
		return standardAreaService.isValidateStandardArea(standardAreaCode);
	}
	
	@GetMapping("/standard-areas/standardarea-list")
	public List<CommonIdName> getStandardAreaList() {
		return standardAreaService.getStandardAreaList();
	}
	
	@GetMapping("/standard-areas/area-validate/{standardAreaCode}")
	public Boolean getActiveStandardAreaByStandardAreaCode(
			@PathVariable(value = "standardAreaCode") String standardAreaCode) {
		return standardAreaService.getActiveStandardAreaByStandardAreaCode(standardAreaCode);
	}
}