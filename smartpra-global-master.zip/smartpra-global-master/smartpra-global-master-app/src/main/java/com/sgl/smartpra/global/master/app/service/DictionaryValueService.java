package com.sgl.smartpra.global.master.app.service;

import java.util.List;

import com.sgl.smartpra.global.master.model.DictionaryValue;

public interface DictionaryValueService {

	List<DictionaryValue> fetchAllDictionaryById(Integer id);
}
