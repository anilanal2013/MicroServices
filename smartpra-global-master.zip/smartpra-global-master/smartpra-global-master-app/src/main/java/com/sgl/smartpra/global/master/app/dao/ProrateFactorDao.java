package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.ProrateFactorEntity;

@Repository
public interface ProrateFactorDao {

	public ProrateFactorEntity create(ProrateFactorEntity mapToEntity);

	public long checkOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate, String fromCityCode,
			String toCityCode);

	public List<ProrateFactorEntity> search(Optional<String> fromCityCode, Optional<String> toCityCode,
			Optional<Boolean> activate);

	public List<ProrateFactorEntity> getAllProrateFactorEntity(Optional<String> fromCityCode,
			Optional<String> toCityCode, Optional<String> effectiveDate);

	public long verifyIfOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate, String fromCityCode,
			String toCityCode, Integer prorateFactorId);

	public ProrateFactorEntity update(ProrateFactorEntity prorateFactorEntity);

	public Optional<ProrateFactorEntity> findById(Integer prorateFactorId);

	public List<ProrateFactorEntity> verifyRecordExits(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Integer prorateFactorId, Optional<String> fromCityCode,
			Optional<String> toCityCode);

	public long checkSameInActiveRecord(String fromCityCode, String toCityCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate);

	public Optional<ProrateFactorEntity> getAllProrateFactorEntityFTE(Optional<String> fromCityCode,
			Optional<String> toCityCode, Optional<String> effectiveDate);

}
