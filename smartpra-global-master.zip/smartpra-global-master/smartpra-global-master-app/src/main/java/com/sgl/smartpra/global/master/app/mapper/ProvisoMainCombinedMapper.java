package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainEntity;
import com.sgl.smartpra.global.master.model.ProvisoMainStgModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoMainCombinedMapper extends BaseMapper<ProvisoMainStgModel, ProvisoMainEntity>{
	ProvisoMainEntity mapToEntity(ProvisoMainStgModel provisoMainStgModel, @MappingTarget ProvisoMainEntity provisoMainEntity);
	ProvisoMainEntity mapToEntity(ProvisoMainStgModel provisoMainStgModel);
}
