package com.sgl.smartpra.global.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_proviso_detail")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class ProvisoDetailEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "proviso_detail_id", nullable = false)
	private Integer provisoDetailId;

	@Column(name = "proviso_main_id", nullable = false)
	private Integer provisoMainId;

	@Column(name = "carrier_num_code", nullable = false, length = 3)
	private String carrierNumCode;

	@Column(name = "proviso_seq_number", nullable = false)
	private Integer provisoSeqNumber;

	@Column(name = "detail_rec_number", nullable = false)
	private Integer detailRecNumber;

	@Column(name = "fb_groupcode", nullable = false, length = 5)
	private String fbGroupCode;

	@Column(name = "sector_fb_flag", length = 1)
	private String sectorFbFlag;

	@Column(name = "sector_from", length = 4)
	private String sectorFrom;

	@Column(name = "sector_to", length = 4)
	private String sectorTo;

	@Column(name = "percentage")
	private BigDecimal percentage;

	@Column(name = "article_c", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean articleC;

	@Column(name = "exception_indicator", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean exceptionIndicator;

	@Column(name = "exception_from_record")
	private Integer exceptionFromRecord;

	@Column(name = "exception_to_record")
	private Integer exceptionToRecord;

	@Column(name = "sub_para_reference", length = 15)
	private String subParaReference;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
