package com.sgl.smartpra.global.master.app.dao.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;


/**
 * The persistent class for the global_mas_ticket_overwrite database table.
 * 
 */
@Entity
@Table(name="global_mas_ticket_overwrite")
@NamedQuery(name="TicketOverwriteEntity.findAll", query="SELECT g FROM TicketOverwriteEntity g")
public class TicketOverwriteEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="scenario_no")
	private Long scenarioNo;

	@Column(name="audit_trail")
	private String auditTrail;

	@Column(name="is_active")
	private String isActive;

	@Column(name="process_status")
	private String processStatus;

	@Column(name="result")
	private String result;

	@Column(name="source_1")
	private String source1;

	@Column(name="source_2")
	private String source2;

	@Column(name="transation_code")
	private String transationCode;

	//bi-directional many-to-one association to TicketOverwiteDetail
	@OneToMany(mappedBy="ticketOverwrite")
	private List<TicketOverwiteDetailEntity> ticketOverwiteDetails;

	public TicketOverwriteEntity() {
	}

	public Long getScenarioNo() {
		return this.scenarioNo;
	}

	public void setScenarioNo(Long scenarioNo) {
		this.scenarioNo = scenarioNo;
	}

	public String getAuditTrail() {
		return this.auditTrail;
	}

	public void setAuditTrail(String auditTrail) {
		this.auditTrail = auditTrail;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public String getResult() {
		return this.result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getSource1() {
		return this.source1;
	}

	public void setSource1(String source1) {
		this.source1 = source1;
	}

	public String getSource2() {
		return this.source2;
	}

	public void setSource2(String source2) {
		this.source2 = source2;
	}

	public String getTransationCode() {
		return this.transationCode;
	}

	public void setTransationCode(String transationCode) {
		this.transationCode = transationCode;
	}

	public List<TicketOverwiteDetailEntity> getTicketOverwiteDetails() {
		return this.ticketOverwiteDetails;
	}

	public void setTicketOverwiteDetails(List<TicketOverwiteDetailEntity> ticketOverwiteDetails) {
		this.ticketOverwiteDetails = ticketOverwiteDetails;
	}

	public TicketOverwiteDetailEntity addTicketOverwiteDetail(TicketOverwiteDetailEntity ticketOverwiteDetail) {
		getTicketOverwiteDetails().add(ticketOverwiteDetail);
		ticketOverwiteDetail.setTicketOverwrite(this);

		return ticketOverwiteDetail;
	}

	public TicketOverwiteDetailEntity removeTicketOverwiteDetail(TicketOverwiteDetailEntity ticketOverwiteDetail) {
		getTicketOverwiteDetails().remove(ticketOverwiteDetail);
		ticketOverwiteDetail.setTicketOverwrite(null);

		return ticketOverwiteDetail;
	}
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
		setCreatedBy("ADMIN");
	}

	@PreUpdate
	public void preUpdate() {
		setCreatedDate(LocalDateTime.now());
		setCreatedBy("ADMIN");
	}

}