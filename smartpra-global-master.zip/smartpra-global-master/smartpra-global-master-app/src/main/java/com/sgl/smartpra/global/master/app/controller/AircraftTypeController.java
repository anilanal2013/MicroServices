package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.AircraftTypeService;
import com.sgl.smartpra.global.master.model.AircraftType;

@RestController
public class AircraftTypeController {
	
	@Autowired
	AircraftTypeService airCraftTypeService;
	
	@GetMapping("/aircraftType/{aircraftTypeCode}")
	public AircraftType getAircraftTypeByTypeCode(@PathVariable("aircraftTypeCode") Optional<String> aircraftTypeCode) {
		return airCraftTypeService.findAircraftTypeById(aircraftTypeCode);
	}

	@GetMapping("/aircraftType")
	public List<AircraftType> getAircraftType() {
		return airCraftTypeService.findAircraftType();
	}

}
