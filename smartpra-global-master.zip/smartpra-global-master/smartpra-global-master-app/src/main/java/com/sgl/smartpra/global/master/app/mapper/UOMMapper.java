package com.sgl.smartpra.global.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.global.master.app.dao.entity.UOMEntity;
import com.sgl.smartpra.global.master.model.UOM;

@Mapper
public interface UOMMapper {

	UOM mapToUOMModel(UOMEntity uomEntity);

	List<UOM> mapToUOMModelList(List<UOMEntity> uomEntityList);

	UOMEntity mapToUOMEntity(UOM uom);

	List<UOMEntity> mapToUOMEntityList(List<UOM> uomList);
}
