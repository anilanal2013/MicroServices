package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.RejectionReasonCodeDao;
import com.sgl.smartpra.global.master.app.dao.entity.RejectionReasonCodeEntity;
import com.sgl.smartpra.global.master.app.dao.repository.RejectionReasonCodeRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RejectionReasonCodeDaoImpl implements RejectionReasonCodeDao {

	@Autowired
	private RejectionReasonCodeRepository  rejectionReasonCodeRepository;
	
	@Override
	@Cacheable(value = "rejectionReasonCodeEntity", key="#id")
	public Optional<RejectionReasonCodeEntity> findById(String id) {
		log.info("Cacheable entity RejectionReasonCode {}", id);
		return rejectionReasonCodeRepository.findById(id);
	}

	@Override
	@Caching(evict= {@CacheEvict(value="rejectionReasonCodeEntity",key = "#rejectionReasonCodeEntity.rejectionReasonCode")})
	public RejectionReasonCodeEntity create(RejectionReasonCodeEntity rejectionReasonCodeEntity) {
		// TODO Auto-generated method stub
		return rejectionReasonCodeRepository.save(rejectionReasonCodeEntity);
	}

	@Override
	@CachePut(value = "rejectionReasonCodeEntity",key = "#rejectionReasonCodeEntity.rejectionReasonCode")
	public RejectionReasonCodeEntity update(RejectionReasonCodeEntity rejectionReasonCodeEntity) {
		// TODO Auto-generated method stub
		return rejectionReasonCodeRepository.save(rejectionReasonCodeEntity);
	}

	@Override
	public List<RejectionReasonCodeEntity> update(List<RejectionReasonCodeEntity> rejectionReasonCodeEntity) {
		// TODO Auto-generated method stub
		return rejectionReasonCodeRepository.saveAll(rejectionReasonCodeEntity);
	}

	@Override
	public Optional<RejectionReasonCodeEntity> findOne(String id) {
		Optional<RejectionReasonCodeEntity> entity = rejectionReasonCodeRepository.findById(id);
		return entity;
	}

	@Override
	public List<RejectionReasonCodeEntity> findAll() {
		return rejectionReasonCodeRepository.findAll();
	}
}
