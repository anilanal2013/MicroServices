package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.StandardArea;

public interface StandardAreaSrevice {

	public List<StandardArea> getListOfStandardArea(Optional<String> standardAreaCode,
			Optional<String> standardAreaName, Boolean activate);

	public StandardArea getStandardAreaByStandardAreaCode(String standardAreaCode);

	public StandardArea createStandardArea(StandardArea standardarea);

	public StandardArea updateStandardArea(String standardAreaCode, StandardArea standardarea);

	public void deactivateStandardArea(String standardAreaCode, String lastUpdatedBy);

	public void activateStandardArea(String standardAreaCode, String lastUpdatedBy);

	public List<String> getStandardAreaList(Airport airport);

	public boolean isValidateStandardArea(String standardAreaCode);

	List<CommonIdName> getStandardAreaList();

	public Boolean getActiveStandardAreaByStandardAreaCode(String standardAreaCode); 

}
