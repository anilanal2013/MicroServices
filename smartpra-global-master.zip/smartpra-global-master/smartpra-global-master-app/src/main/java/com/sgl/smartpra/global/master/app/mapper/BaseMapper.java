package com.sgl.smartpra.global.master.app.mapper;

import java.util.List;
import java.util.Optional;

public interface BaseMapper<Model, Entity> {

	Entity mapToEntity(Model model);

	Model mapToModel(Entity entity);

	List<Entity> mapToEntity(List<Model> modelList);

	List<Model> mapToModel(List<Entity> entityList);

	default <T> T unwrapOptional(Optional<T> optional) {
		return optional.orElse(null);
	}

	default Optional<String> wrapOptional(String string) {
		return Optional.of(string);
	}

	default Optional<Long> wrapOptional(Long l) {
		return Optional.of(l);
	}

	default Optional<Integer> wrapOptional(Integer integer) {
		return Optional.of(integer);
	}

	default Optional<Boolean> wrapOptional(Boolean b) {
		return Optional.of(b);
	}
	
	default Optional<Double> wrapOptional(Double d) {
		return Optional.of(d);
	}

}
