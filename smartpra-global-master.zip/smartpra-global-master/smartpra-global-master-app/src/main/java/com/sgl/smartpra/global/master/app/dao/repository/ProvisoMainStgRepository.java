package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;

@Repository
public interface ProvisoMainStgRepository
		extends JpaRepository<ProvisoMainStgEntity, Integer>, JpaSpecificationExecutor<ProvisoMainStgEntity> {
	@Transactional
	@Modifying
	@Query("delete from ProvisoMainStgEntity pmse where pmse.provisoMainId= ?1")
	void deleteProvisoMainRecordFromDb(Integer provisoMainId);
	
	@Query(value="select max(pms.provisoSeqNumber) from ProvisoMainStgEntity pms where pms.carrierNumCode=?1")
	Integer getMaxOfProvisoSeqNumber(Optional<String> carrierNumCode);

	@Query(value="select max(pms.provisoMainId) from ProvisoMainStgEntity pms")
	Integer getMaxOfProvisoMainId();
}
