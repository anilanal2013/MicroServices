package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.FareTypeHierarchyService;
import com.sgl.smartpra.global.master.model.FareTypeHierarchy;

@RestController
public class FareTypeHierarchyController {

	@Autowired
	@Qualifier("FareTypeHierarchyService")
	private FareTypeHierarchyService fareTypeHierarchyService;

	@GetMapping("/fare-type/{fareTypeHierarchyId}")
	public FareTypeHierarchy getFareTypeHierarchyByFareTypeHierarchyId(
			@PathVariable(value = "fareTypeHierarchyId") Integer fareTypeHierarchyId) {
		return fareTypeHierarchyService.getFareTypeHierarchyByfareTypeHierarchyId(fareTypeHierarchyId);
	}

	@GetMapping("/fare-type")
	public List<FareTypeHierarchy> getAllFareTypeHierarchy(
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") String effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") String effectiveToDate,
			@RequestParam(value = "cabinLevel", required = false) Integer cabinLevel,
			@RequestParam(value = "fareTypeLevel", required = false) Integer fareTypeLevel) {
		return fareTypeHierarchyService.getAllFareTypeHierarchy(effectiveFromDate, effectiveToDate, cabinLevel,
				fareTypeLevel);
	}

	@GetMapping("/fare-type/fare-type-cabin")
	public List<FareTypeHierarchy> getAllFareTypeHierarchyWithCabin(
			@RequestParam(value = "effectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") String effectiveDate,
			@RequestParam(value = "cabin", required = false) String cabin,
			@RequestParam(value = "fareTypeLevel", required = false) Integer fareTypeLevel) {
		return fareTypeHierarchyService.getAllFareTypeHierarchyWithCabin(effectiveDate, cabin, fareTypeLevel);
	}

	@PostMapping("/fare-type")
	@ResponseStatus(value = HttpStatus.CREATED)
	public FareTypeHierarchy createFareTypeHierarchy(
			@Validated(Create.class) @RequestBody FareTypeHierarchy fareTypeHierarchy) {
		return fareTypeHierarchyService.createFareTypeHierarchy(fareTypeHierarchy);
	}

	@PutMapping("/fare-type/{fareTypeHierarchyId}")
	@ResponseStatus(value = HttpStatus.OK)
	public FareTypeHierarchy updateFareTypeHierarchy(
			@PathVariable(value = "fareTypeHierarchyId") Integer fareTypeHierarchyId,
			@Validated(Update.class) @RequestBody FareTypeHierarchy fareTypeHierarchy) {
		fareTypeHierarchy.setFareTypeHierarchyId(fareTypeHierarchyId);
		return fareTypeHierarchyService.updateFareTypeHierarchy(fareTypeHierarchy);
	}

	@PutMapping("/fare-type/{fareTypeHierarchyId}/deactivate")
	public void deactivateFareTypeHierarchyId(
			@Valid @PathVariable(value = "fareTypeHierarchyId") Integer fareTypeHierarchyId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		FareTypeHierarchy fareTypeHierarchy = new FareTypeHierarchy();
		fareTypeHierarchy.setFareTypeHierarchyId(fareTypeHierarchyId);
		fareTypeHierarchy.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		fareTypeHierarchyService.deactivateFareTypeHierarchy(fareTypeHierarchy);
	}

	@PutMapping("/fare-type/{fareTypeHierarchyId}/activate")
	public void activateFareTypeHierarchy(
			@Valid @PathVariable(value = "fareTypeHierarchyId") Integer fareTypeHierarchyId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		FareTypeHierarchy fareTypeHierarchy = new FareTypeHierarchy();
		fareTypeHierarchy.setFareTypeHierarchyId(fareTypeHierarchyId);
		fareTypeHierarchy.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		fareTypeHierarchyService.activateFareTypeHierarchy(fareTypeHierarchy);
	}

}
