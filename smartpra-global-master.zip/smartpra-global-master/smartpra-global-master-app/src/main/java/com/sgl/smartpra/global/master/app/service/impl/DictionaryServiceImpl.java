package com.sgl.smartpra.global.master.app.service.impl;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.global.master.app.dao.DictionaryDao;
import com.sgl.smartpra.global.master.app.mapper.DictionaryMapper;
import com.sgl.smartpra.global.master.app.service.DictionaryService;
import com.sgl.smartpra.global.master.model.Dictionary;

@Service
@Transactional
public class DictionaryServiceImpl implements DictionaryService {

	@Autowired
	DictionaryMapper dictionaryMapper;
	
	@Autowired
	DictionaryDao dictionaryDao;
	
	@Override
	public List<Dictionary> getDictionaryByelementDefine(Optional<String> elementName, Optional<String> dictionarydefine) {
		return dictionaryMapper.mapToModel(dictionaryDao.getAllDictionarys(elementName, dictionarydefine));
	}
}
