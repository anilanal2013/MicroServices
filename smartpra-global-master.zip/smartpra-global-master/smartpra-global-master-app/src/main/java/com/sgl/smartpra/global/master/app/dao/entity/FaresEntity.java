package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_fares", schema = "smartpraglobal")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class FaresEntity extends BaseEntity {
 
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "fare_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer fareId;

	@Column(name = "tariff_code", unique = true, nullable = false, length = 3)
	private String tariffCode;

	@Column(name = "cxr_code", unique = true, nullable = false, length = 2)
	private String cxrCode;

	@Column(name = "origin_city", unique = true, nullable = false, length = 3)
	private String originCity;

	@Column(name = "destination_city", unique = true, nullable = false, length = 3)
	private String destinationCity;

	@Column(name = "fare_basis", unique = true, nullable = false, length = 8)
	private String fareBasis;

	@Column(name = "effective_from_date", unique = true, nullable = false)
	@NotNull
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", unique = true, nullable = false)
	@NotNull
	private LocalDate effectiveToDate;

	@Column(name = "rule_number", length = 4)
	private String ruleNumber;

	@Column(name = "routing_number", length = 4)
	private String routingNumber;

	@Column(name = "ow_rt_indicator", nullable = false, length = 1)
	private String owRtIndicator;

	@Column(name = "fare_currency", nullable = false, length = 3)
	private String fareCurrency;

	@Column(name = "fare_value", precision = 8, scale = 2)
	private Double fareValue;

	@Column(name = "fare_type", nullable = false, length = 3)
	private String fareType;

	@Column(name = "construction", length = 1)
	private String construction;

	@Column(name = "prorate", length = 1)
	private String prorate;

	@Column(name = "differential", length = 1)
	private String differential;

	@Column(name = "proportional", length = 1)
	private String proportional;

	@Column(name = "fare_footnote", length = 2)
	private String fareFootNote;

	@Column(name = "action", length = 1)
	private String action;

	@Column(name = "link_number", length = 3)
	private String linkNumber;

	@Column(name = "sequence_number", length = 5)
	private String sequenceNumber;

	@Column(name = "old_mcn", length = 5)
	private String oldMCN;

	@Column(name = "new_mcn", length = 5)
	private String newMCN;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
