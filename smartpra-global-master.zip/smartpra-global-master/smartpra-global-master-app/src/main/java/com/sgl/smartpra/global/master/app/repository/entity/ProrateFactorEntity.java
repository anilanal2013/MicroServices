package com.sgl.smartpra.global.master.app.repository.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.global.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_prorate_factors")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class ProrateFactorEntity extends BaseEntity {

	@Id
	@Column(name = "prorate_factor_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer prorateFactorId;

	@Column(name = "change_ind")
	private String changeIndicator;

	@Column(name = "addendum_file_id")
	private Integer addendumFileId;

	@Column(name = "inbound_file_id")
	private Integer inboundFileId;

	@Column(name = "from_city_code", nullable = false, length = 3)
	private String fromCityCode;

	@Column(name = "to_city_code", nullable = false, length = 3)
	private String toCityCode;

	@Column(name = "prorate_factor", nullable = false)
	private Integer prorateFactor;

	@Column(name = "effective_from_date", nullable = false)
	// @Temporal(TemporalType.DATE)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	// @Temporal(TemporalType.DATE)
	private LocalDate effectiveToDate;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

	public String getChangeIndicator() {
		if (changeIndicator != null) {
			return changeIndicator.trim();
		}
		return changeIndicator;
	}

	public void setChangeIndicator(String changeIndicator) {
		if (changeIndicator != null) {
			this.changeIndicator = changeIndicator.trim();
		}
		this.changeIndicator = changeIndicator;
	}

}
