package com.sgl.smartpra.global.master.app.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.model.TicketOverwrite;
import com.sgl.smartpra.global.master.model.TicketOverwriteDetail;

@Component
public interface TicketOverwriteDetailService {

	TicketOverwriteDetail saveTicketOverwriteDetail(TicketOverwriteDetail ticketOverwiteDetailDao );
		
	void deleteTicketOverwriteDetail(Long id);
	
	void activateOrDeactiveTicketDetail(Long id);

	TicketOverwriteDetail getTicketOverwriteDetail(Long id);
	
	List<TicketOverwriteDetail> getTicketOverwriteDetail(TicketOverwrite ticketOverwrite,String tableName);


}
