package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.global.master.model.SIRSRates;
import com.sgl.smartpra.global.master.model.SIRSRatesResponse;

public interface SIRSRatesService {

	public SIRSRates createSIRSRates(SIRSRates sirsRates);

	public SIRSRates updateSIRSRates(SIRSRates sirsRates);

	public SIRSRates getSIRSRatesBySIRSRatesId(Integer sirsRateId);

	public void deactivateSIRSRates(Integer sirsRateId, String lastUpdatedBy);

	public void activateSIRSRates(Integer sirsRateId, String lastUpdatedBy);

	public List<SIRSRates> getAllSIRSRates(Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> globalRegion);

	public List<SIRSRates> getAllSIRSRatesDate(String effectiveDate);

	public SIRSRatesResponse getAllSIRSRates(Pageable pageable, SIRSRates sirsRates); 

}
