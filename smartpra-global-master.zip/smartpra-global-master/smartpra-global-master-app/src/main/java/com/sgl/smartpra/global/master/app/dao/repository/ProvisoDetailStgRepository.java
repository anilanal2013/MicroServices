package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailStgEntity;

@Repository
public interface ProvisoDetailStgRepository
		extends JpaRepository<ProvisoDetailStgEntity, Integer>, JpaSpecificationExecutor<ProvisoDetailStgEntity> {
	@Query(value = "select pds.provisoMainId from ProvisoDetailStgEntity pds")
	List<Integer> getListOfProvisoMainIdFromDetailStgDb();

	@Transactional
	@Modifying
	@Query("delete from ProvisoDetailStgEntity pdse where pdse.provisoMainId= ?1")
	void deleteProvisoDetailByProvisoMainId(Integer provisoMainId);

	@Query(value = "select max(pds.detailRecNumber) from ProvisoDetailStgEntity pds where pds.carrierNumCode=?1 AND pds.provisoSeqNumber=?2")
	Integer getMaxOfProvisoDetailRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);
}
