package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_proviso_main")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class ProvisoMainEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "proviso_main_id", nullable = false)
	private Integer provisoMainId;

	@Column(name = "carrier_num_code", nullable = false, length = 3)
	private String carrierNumCode;

	@Column(name = "proviso_seq_number", nullable = false)
	private Integer provisoSeqNumber;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;

	@Column(name = "description", nullable = false, length = 60)
	private String description;

	@Column(name = "proviso_section", nullable = false, length = 2)
	private String provisoSection;

	@Column(name = "additional_discount_flg", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean additionalDiscountFlag;

	@Column(name = "proviso_status", nullable = false, length = 1)
	private String provisoStatus;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
