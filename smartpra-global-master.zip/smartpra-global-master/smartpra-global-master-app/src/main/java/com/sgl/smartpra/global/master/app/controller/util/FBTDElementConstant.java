package com.sgl.smartpra.global.master.app.controller.util;

public class FBTDElementConstant {
	
	// hide public constructor
	private FBTDElementConstant() {
		super();
	}

	public static final Integer ELEMENT_1 = 1;
	public static final Integer ELEMENT_2 = 2;
	public static final Integer ELEMENT_3 = 3;
	public static final Integer ELEMENT_4 = 4;
	public static final Integer ELEMENT_5 = 5;
	public static final Integer ELEMENT_6 = 6;
	public static final Integer ELEMENT_11 = 11;
	public static final Integer ELEMENT_12 = 12;
	public static final Integer ELEMENT_13 = 13;
	public static final Integer ELEMENT_14 = 14;
	public static final Integer ELEMENT_15 = 15;
	public static final Integer ELEMENT_16 = 16;
	
	public static final String ADDITIONAL_INFO_F = "F";
	public static final String ADDITIONAL_INFO_C = "C";
	public static final String ADDITIONAL_INFO_Y = "Y";
	
	public static final String ADDITIONAL_INFO_J = "J";
	public static final String ADDITIONAL_INFO_D = "D";
}
