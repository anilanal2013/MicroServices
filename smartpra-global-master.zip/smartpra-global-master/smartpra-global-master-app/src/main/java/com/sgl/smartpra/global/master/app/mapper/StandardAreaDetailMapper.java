package com.sgl.smartpra.global.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.global.master.app.repository.entity.StandardAreaDetailEntity;
import com.sgl.smartpra.global.master.model.StandardAreaDetail;

@Mapper
public interface StandardAreaDetailMapper {
	StandardAreaDetail mapToStandardAreaDetailModel(StandardAreaDetailEntity standardareaDetailEntity);

	List<StandardAreaDetail> mapToStandardAreaDetailModelList(
			List<StandardAreaDetailEntity> standardareaDetailEntityList);

	StandardAreaDetailEntity mapToStandardAreaDetailEntity(StandardAreaDetail standardareaDetail);

	List<StandardAreaDetailEntity> mapToStandardAreaDetailEntityList(List<StandardAreaDetail> standardareaDetailList);
}
