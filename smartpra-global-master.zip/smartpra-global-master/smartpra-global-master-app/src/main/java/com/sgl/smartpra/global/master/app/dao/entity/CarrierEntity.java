package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
@Table(name = "global_mas_carrier")
public class CarrierEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "carrier_code", nullable = false,length = 3)
	private String carrierCode;

	@Column(name = "carrier_designator_code", nullable = false, length = 2)
	private String carrierDesignatorCode;
	
	@Column(name = "location_id", length = 7)
	private String locationId; 
	
	@Column(name = "carrier_name1", length = 50)
	private String carrierName1;
	
	@Column(name = "carrier_name2", length = 50)
	private String carrierName2;

	@Column(name = "carrier_address_1", length = 70)
	private String carrierAddress1;

	@Column(name = "carrier_address_2", length = 70)
	private String carrierAddress2;

	@Column(name = "carrier_address_3", length = 70)
	private String carrierAddress3;
	
	@Column(name = "city_code", length = 3)
	private String cityCode;
	
	@Column(name = "sub_division_code", length = 3)
	private String subDivisionCode;
	
	@Column(name = "sub_division_name", length = 50)
	private String subDivisionName;
	
	@Column(name = "country_code",nullable=false, length = 2)
	private String countryCode;
	
	@Column(name = "postal_code", length = 50)
	private String postalCode;
	
	@Column(name = "interline_address_1", length = 30)
	private String interlineAddress1;

	@Column(name = "interline_address_2", length = 30)
	private String interlineAddress2;

	@Column(name = "interline_address_3", length = 30)
	private String interlineAddress3;

	@Column(name = "tax_registration_id", length = 25)
	private String taxRegistrationId;
	
	@Column(name = "addl_tax_registration_id", length = 25)
	private String addlTaxRegistrationId;
	
	@Column(name = "company_registration_id", length = 25)
	private String companyRegistrationId;
	
	@Column(name = "contact_name", length = 50)
	private String contactName;
	
	@Column(name = "telephone_number", length = 25)
	private String telephoneNumber;
	
	@Column(name = "fax_number", length = 25)
	private String faxNumber;
	
	@Column(name = "telex", length = 255)
	private String telex;
	
	@Column(name = "aftn", length = 255)
	private String aftn;
	
	@Column(name = "sita", length = 255)
	private String sita;
	
	@Column(name = "email", length = 255)
	private String email;
	
	@Column(name = "website", length = 255)
	private String website;
	
	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
