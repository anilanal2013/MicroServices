package com.sgl.smartpra.global.master.app.service;

import java.util.List;

import com.sgl.smartpra.global.master.model.UOM;

public interface UOMService {

	public List<UOM> getAllUom(String uomCode, String uomType);

	public UOM findUomByUomCode(Integer uomId);

	public UOM createUom(UOM uom);

	public UOM updateUom(Integer uomId, UOM uom);

	public void deactivateUom(Integer uomId, String lastUpdatedBy);

	public void activateUom(Integer uomId, String lastUpdatedBy);
	
	public boolean isValidUomType(String uomType);	

}
