package com.sgl.smartpra.global.master.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.CountryEntity;

@Repository
public interface CountryRepository 
		extends JpaRepository<CountryEntity, String>, JpaSpecificationExecutor<CountryEntity> , CrudRepository<CountryEntity, String>{
		
	/* List<CountryEntity> findByIdIn(List<String> countryCodeList); */
	
	@Query("select countryCode from CountryEntity a  where a.countryCode = :countryCode AND a.activate= TRUE")
	public String getCountryCode(@Param("countryCode") String countryCode);

	@Query("select countryCode from CountryEntity a  where a.countryCode IN (:countryCodeList) AND a.activate= TRUE")
	public List<String> getCountryCodeList(@Param("countryCodeList") List<String> countryCodeList);

	List<CountryEntity> findDistinctByCountryCodeIsNotNullAndActivateTrueOrderByCountryCode();
	
}
