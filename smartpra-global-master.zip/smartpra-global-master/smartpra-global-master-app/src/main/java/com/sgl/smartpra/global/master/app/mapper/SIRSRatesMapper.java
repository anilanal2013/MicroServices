package com.sgl.smartpra.global.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.SIRSRatesEntity;
import com.sgl.smartpra.global.master.model.SIRSRates;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SIRSRatesMapper extends BaseMapper<SIRSRates, SIRSRatesEntity> {

	SIRSRatesEntity mapToEntity(SIRSRates sirsRates, @MappingTarget SIRSRatesEntity sirsRatesEntity);

	@Mapping(source = "sirsRateId", target = "sirsRateId", ignore = true)
	SIRSRatesEntity mapToEntity(SIRSRates sirsRates);

	List<SIRSRates> mapToSIRSRatesModelList(List<SIRSRatesEntity> sirsRatesEntityList);

}
