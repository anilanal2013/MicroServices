package com.sgl.smartpra.global.master.app.service;

import javax.validation.Valid;

import com.sgl.smartpra.global.master.model.RejectionReasonCode;

import java.util.List;


public interface RejectionReasonCodeService {

	RejectionReasonCode getRejectionReasonCode(@Valid String id);

    List<RejectionReasonCode> fetchAllRejectionCode();
}
