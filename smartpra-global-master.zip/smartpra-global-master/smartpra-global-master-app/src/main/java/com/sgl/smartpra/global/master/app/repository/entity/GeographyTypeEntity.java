package com.sgl.smartpra.global.master.app.repository.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "global_mas_std_geo_type")
public class GeographyTypeEntity {

	@Id
	@Column(name = "geo_type_id", nullable = false, length = 3)
	private Integer geographicalTypeId;

	@Column(name = "geo_type", nullable = false, length = 20)
	private String geoType;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "created_by", nullable = false, length = 15)
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;

	@Column(name = "last_updated_by", nullable = true, length = 15)
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	public GeographyTypeEntity() {
		super();

	}

	public GeographyTypeEntity(Integer geographicalTypeId, String geoType, Boolean isActive, String createdBy,
			Timestamp createdDate, String lastUpdatedBy, Timestamp lastUpdatedDate) {
		super();
		this.geographicalTypeId = geographicalTypeId;
		this.geoType = geoType;
		this.isActive = isActive;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Integer getGeographicalTypeId() {
		return geographicalTypeId;
	}

	public void setGeographicalTypeId(Integer geographicalTypeId) {
		this.geographicalTypeId = geographicalTypeId;
	}

	public String getGeoType() {
		return geoType;
	}

	public void setGeoType(String geoType) {
		this.geoType = geoType;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
