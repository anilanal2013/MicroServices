package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.CurrencyEntity;

public interface CurrencyDao {
	
    public Optional<CurrencyEntity> findById(String currencyCode);
	
	public CurrencyEntity create(CurrencyEntity currencyEntity);
	
	public CurrencyEntity update(CurrencyEntity currencyEntity);
	
	public List<CurrencyEntity> getAllCurrency(Optional<String> currencyCode, Optional<String> currencyName, Optional<Boolean> isActive);

	public long validateNumericCode(Integer currencyNumericCode);

	public long validateNumericCodeForUpdate(Integer currencyNumericCode, String currencyCode);

	public List<CurrencyEntity> findDistinctByCurrencyCodeIsNotNullAndIsActiveTrueOrderByCurrencyCode();

	public Optional<CurrencyEntity> getCurrencyByCurrencyNumericCode(Integer currencyNumericCode);
    
}
