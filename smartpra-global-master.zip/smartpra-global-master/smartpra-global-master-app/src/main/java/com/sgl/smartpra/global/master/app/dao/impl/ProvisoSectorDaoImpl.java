package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoSectorDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoSectorEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoSectorRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoSectorDaoImpl implements ProvisoSectorDao {
	@Autowired
	private ProvisoSectorRepository provisoSectorRepository;

	@Override
	public List<ProvisoSectorEntity> findByMainId(Optional<Integer> provisoMainId) {
		log.info("Cacheable Proviso Sector Entity's ID= {}", provisoMainId);
        
		return provisoSectorRepository.findAll(ProvisoSectorEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	@Cacheable(value = "provisoSectorModel", key = "#provisoSectorId")
	public Optional<ProvisoSectorEntity> findById(Integer provisoSectorId) {
		log.info("Cacheable Proviso Sector Entity's ID= {}", provisoSectorId);
		return provisoSectorRepository.findById(provisoSectorId);
	}

	@Override
	public List<ProvisoSectorEntity> searchByProvisoInMain(Optional<Integer> provisoMainId, Optional<String> areaFrom) {
		return provisoSectorRepository
				.findAll(ProvisoSectorEntitySpecification.searchByProMain(provisoMainId, areaFrom));
	}

	@Override
	public List<ProvisoSectorEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {

		return provisoSectorRepository
				.findAll(ProvisoSectorEntitySpecification.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	public List<ProvisoSectorEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> sectionRecNumber) {

		return provisoSectorRepository
				.findAll(ProvisoSectorEntitySpecification.search(carrierNumCode, provisoSeqNumber, sectionRecNumber));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "provisoSectorModel", key = "#provisoSectorEntity.provisoMainId") })
	public ProvisoSectorEntity create(ProvisoSectorEntity provisoSectorEntity) {
		return provisoSectorRepository.save(provisoSectorEntity);
	}
	
	@Override
	public List<Integer> getListOfProvisoMainIdFromSectorDb() {

		return provisoSectorRepository.getListOfProvisoMainIdFromSectorDb();
	}
}
