package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.AirportEntity;


public final class AirportEntitySpecification {

	private AirportEntitySpecification() {
	}
	
	private static final String AIRPORTCODE = "airportCode";
	private static final String AIRPORTNAME = "airportName";
	private static final String CITYCODE = "cityCode";
	private static final String CITYNAME = "cityName";
	private static final String COUNTRYCODE = "countryCode";
	private static final String ISACTIVE = "isActive";
	private static final String STATECODE = "stateCode";
	
	public static Specification<AirportEntity> likeAirportCode(String airportCode) {
		return (airportEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(airportEntity.get(AIRPORTCODE), airportCode+"%");
	}
	
	public static Specification<AirportEntity> equalAirportCode(Optional<String> airportCode) {
		return (airportEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(airportEntity.get(AIRPORTCODE), OptionalUtil.getValue(airportCode));
	}

	public static Specification<AirportEntity> likeAirportName(String airportName) {
		return (airportEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(airportEntity.get(AIRPORTNAME), airportName+"%");
	}

	public static Specification<AirportEntity> equalCityCode(Optional<String> cityCode) {
		return (airportEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(airportEntity.get(CITYCODE), OptionalUtil.getValue(cityCode));
	}
	
	public static Specification<AirportEntity> likeCityCode(String cityCode) {
		return (airportEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(airportEntity.get(CITYCODE), cityCode+"%");
	}
	
	public static Specification<AirportEntity> likeCityName(String cityName) {
		return (airportEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(airportEntity.get(CITYNAME), cityName+"%");
	}
	
	public static Specification<AirportEntity> likeCountryCode(String countryCode) {
		return (airportEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(airportEntity.get(COUNTRYCODE), countryCode+"%");
	}
	
	public static Specification<AirportEntity> isActive(Boolean isActive) {
		return (airportEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(airportEntity.get(ISACTIVE), isActive);
	}
	
	public static Specification<AirportEntity> equalStateCode(Optional<String> stateCode) {
		return (airportEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(airportEntity.get(STATECODE), OptionalUtil.getValue(stateCode));
	}
	
	public static Specification<AirportEntity> search(AirportEntity airportEntity,Optional<String> exceptionCall) {
		return (airport, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (isEmptyOrNull(airportEntity.getAirportCode())) {
				predicates.add(criteriaBuilder.like(airport.get(AIRPORTCODE), airportEntity.getAirportCode()+"%"));
			}
			if (isEmptyOrNull(airportEntity.getAirportName())) {
				predicates.add(criteriaBuilder.like(airport.get(AIRPORTNAME), airportEntity.getAirportName()+"%"));
			}
			if (isEmptyOrNull(airportEntity.getCityCode())) {
				predicates.add(criteriaBuilder.like(airport.get(CITYCODE),
						airportEntity.getCityCode()+"%"));
			}
			if (isEmptyOrNull(airportEntity.getCityName())) {
				predicates.add(criteriaBuilder.like(airport.get(CITYNAME),
						airportEntity.getCityName()+"%"));
			}
			if (isEmptyOrNull(airportEntity.getCountryCode())) {
				predicates.add(criteriaBuilder.like(airport.get(COUNTRYCODE),
						airportEntity.getCountryCode()+"%"));
			}
			if(!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (airportEntity.getIsActive() == null || airportEntity.getIsActive()) {
					predicates.add(criteriaBuilder.isTrue(airport.get(ISACTIVE)));
				} else {
					predicates.add(criteriaBuilder.isFalse(airport.get(ISACTIVE)));
				}
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<AirportEntity> searchAll(Optional<String> airportCode, Optional<String> airportName,
			Optional<String> cityCode, Optional<String> cityName, Optional<String> countryCode) {
		return (airport, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(airportCode)) {
				predicates.add(criteriaBuilder.equal(airport.get(AIRPORTCODE), OptionalUtil.getValue(airportCode)));
			}
			if (OptionalUtil.isPresent(airportName)) {
				predicates.add(criteriaBuilder.equal(airport.get(AIRPORTNAME), OptionalUtil.getValue(airportName)));
			}
			if (OptionalUtil.isPresent(cityCode)) {
				predicates.add(criteriaBuilder.equal(airport.get(CITYCODE), OptionalUtil.getValue(cityCode)));
			}
			if (OptionalUtil.isPresent(cityName)) {
				predicates.add(criteriaBuilder.equal(airport.get(CITYNAME), OptionalUtil.getValue(cityName)));
			}
			if (OptionalUtil.isPresent(countryCode)) {
				predicates.add(criteriaBuilder.equal(airport.get(COUNTRYCODE), OptionalUtil.getValue(countryCode)));
			}
			predicates.add(criteriaBuilder.equal(airport.get(ISACTIVE), Boolean.TRUE));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	private static boolean isEmptyOrNull(String value) {
		return value != null && !value.isEmpty();
	}
	
	public static Specification<AirportEntity> isValidAirportCodeOrCityCode(Optional<String> airportOrCityCode) {
		return (airport, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(airportOrCityCode)) {
				predicates.add(criteriaBuilder.equal(airport.get(AIRPORTCODE), OptionalUtil.getValue(airportOrCityCode)));
			}
			if (OptionalUtil.isPresent(airportOrCityCode)) {
				predicates.add(criteriaBuilder.equal(airport.get(CITYCODE), OptionalUtil.getValue(airportOrCityCode)));
			}
			predicates.add(criteriaBuilder.equal(airport.get(ISACTIVE), Boolean.TRUE));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<AirportEntity> searchByCityOrStateOrCountry(Optional<String> airportCode, Optional<String> stateCode,
			Optional<String> cityCode, Optional<String> countryCode) {
		return (airport, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(airportCode)) {
				predicates.add(criteriaBuilder.equal(airport.get(AIRPORTCODE), OptionalUtil.getValue(airportCode)));
			}
			if (OptionalUtil.isPresent(stateCode)) {
				predicates.add(criteriaBuilder.equal(airport.get(STATECODE), OptionalUtil.getValue(stateCode)));
			}
			if (OptionalUtil.isPresent(cityCode)) {
				predicates.add(criteriaBuilder.equal(airport.get(CITYCODE), OptionalUtil.getValue(cityCode)));
			}
			if (OptionalUtil.isPresent(countryCode)) {
				predicates.add(criteriaBuilder.equal(airport.get(COUNTRYCODE), OptionalUtil.getValue(countryCode)));
			}
			predicates.add(criteriaBuilder.equal(airport.get(ISACTIVE), Boolean.TRUE));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
