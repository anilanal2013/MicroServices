package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;
@Repository
public interface ProvisoMainStgDao {
	public Optional<ProvisoMainStgEntity> findById(Integer id);

	public ProvisoMainStgEntity create(ProvisoMainStgEntity provisoMainStgEntity);

	public ProvisoMainStgEntity update(ProvisoMainStgEntity provisoMainStgEntity);

	public ProvisoMainStgEntity moveProvisoMainToProd(Integer provisoMainId, ProvisoMainStgEntity provisoMainStgEntity);

	public ProvisoMainStgEntity inactivateProvisoMain(Integer provisoMainId, ProvisoMainStgEntity provisoMainStgEntity);

	public List<ProvisoMainStgEntity> searchProvisoMain(Optional<String> carrierNumCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> provisoSection,
			Optional<String> provisoStatus);

	public long getOverlapRecordCount(String carrierNumCode, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String provisoSection);

	public long getOverlapRecordCount(String carrierNumCode, LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String provisoSection, Integer provisoMainId);

	public void deleteProvisoMain(Integer provisoMainId);
	
	public Integer getMaxOfProvisoSeqnumber(Optional<String> carrierNumCode);

	public Integer getMaxOfProvisoMainId();

	public void updateProvisoMainStg(ProvisoMainStgEntity entity);
}
