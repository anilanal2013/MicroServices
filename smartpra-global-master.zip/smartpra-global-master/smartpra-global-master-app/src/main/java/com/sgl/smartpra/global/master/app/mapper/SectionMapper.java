package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.SectionEntity;
import com.sgl.smartpra.global.master.model.Section;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SectionMapper extends BaseMapper<Section, SectionEntity> {

	SectionEntity mapToEntity(Section section, @MappingTarget SectionEntity sectionEntity);

	@Mapping(source = "sectionMasterId", target = "sectionMasterId", ignore = true)
	SectionEntity mapToEntity(Section section);
}