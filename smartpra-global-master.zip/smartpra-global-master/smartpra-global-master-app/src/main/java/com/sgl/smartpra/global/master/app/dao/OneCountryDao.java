package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.OneCountryEntity;

@Repository
public interface OneCountryDao {

	public Optional<OneCountryEntity> findById(Integer id);

	public OneCountryEntity create(OneCountryEntity oneCountryEntity);

	public OneCountryEntity update(OneCountryEntity oneCountryEntity);

	public void delete(Integer id);

	int verifyIfOverlapExits(Optional<String> countryCode,Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	int verifyRecordExits(Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Integer oneCountryId,
			Optional<String> oneCountryCode);

	int checkSameInActiveRecord(Optional<String> oneCountryCode, Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	public List<OneCountryEntity> getAllOneCountryEntity(Optional<String> effectiveDate, Optional<String> oneCountryCode);

	public Optional<OneCountryEntity> getOneCountryEntity(Optional<String> effectiveDate, Optional<String> countryCode);

	public List<OneCountryEntity> search(Optional<String> countryCode,Optional<String> countryCodeList,Optional<String> effectiveFromDate,	Optional<String> effectiveToDate,
			Optional<Boolean> isActive);

}
