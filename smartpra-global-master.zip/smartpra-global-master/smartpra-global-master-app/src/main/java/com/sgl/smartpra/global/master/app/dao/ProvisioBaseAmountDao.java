package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.ProvisioBaseAmountEntity;

@Repository
public interface ProvisioBaseAmountDao {

	ProvisioBaseAmountEntity createProvisioBaseAmount(ProvisioBaseAmountEntity mapToProvisioBaseAmountEntity);

	ProvisioBaseAmountEntity updateProvisioBaseAmount(ProvisioBaseAmountEntity provisioBaseAmountEntity);

	List<ProvisioBaseAmountEntity> getListOfProvisioBaseAmount(String fromCityCode, String toCityCode,
			String carrierCode, Boolean activate);

	List<ProvisioBaseAmountEntity> getOverLapForCreate(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String fromCityCode, String toCityCode, String carrierCode, String classCode);

	List<ProvisioBaseAmountEntity> getOverLapForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String fromCityCode, String toCityCode, String carrierCode, String classCode, Integer provisoBaseid);

	ProvisioBaseAmountEntity getAllProvisioBaseAmountEntity(LocalDate effectiveDate, String fromCityCode,
			String toCityCode, String carrierCode, String classCode);

	Optional<ProvisioBaseAmountEntity> findById(Integer provisioBaseAmountId);

	ProvisioBaseAmountEntity getProvisoBaseAmount(String fromCityCode, String toCityCode, String classCode,
			String carrierCode, LocalDate date);

}
