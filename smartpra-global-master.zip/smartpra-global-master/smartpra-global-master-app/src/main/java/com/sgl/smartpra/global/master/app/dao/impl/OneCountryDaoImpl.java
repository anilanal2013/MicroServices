package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.OneCountryDao;
import com.sgl.smartpra.global.master.app.dao.entity.OneCountryEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.OneCountryEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.OneCountryRepository;
import com.sgl.smartpra.global.master.model.OneCountry;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class OneCountryDaoImpl extends CommonSearchDao<OneCountry> implements OneCountryDao {

	@Autowired
	private OneCountryRepository oneCountryRepository;

	@Override
	@Cacheable(value = "oneCountryCode", key = "#oneCountryId")
	public Optional<OneCountryEntity> findById(Integer oneCountryId) {
		log.info("Cacheable oneCountry Entity's ID= {}", oneCountryId);
		return oneCountryRepository.findById(oneCountryId);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "oneCountryCode", key = "#oneCountryEntity.oneCountryId"),
			@CacheEvict(value = "oneCountrySearch", allEntries = true) })
	public OneCountryEntity create(OneCountryEntity oneCountryEntity) {
		return oneCountryRepository.save(oneCountryEntity);
	}

	@Override
	@CachePut(value = "oneCountryCode", key = "#oneCountryEntity.oneCountryId")
	@CacheEvict(value = "oneCountrySearch", allEntries = true)
	public OneCountryEntity update(OneCountryEntity oneCountryEntity) {
		return oneCountryRepository.save(oneCountryEntity);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "oneCountryCode", key = "#oneCountryId") })
	public void delete(Integer oneCountryId) {
		oneCountryRepository.deleteById(oneCountryId);
	}

	@Override
	public int verifyIfOverlapExits(Optional<String> oneCountryCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate) {
		return (int) oneCountryRepository
				.count(Specification.where(
							(OneCountryEntitySpecification.betweenEffectiveAndFromDate(effectiveFromDate)
							.or(OneCountryEntitySpecification.betweenEffectiveDateAndToDate(effectiveToDate)))
							.and(OneCountryEntitySpecification.equalCountryCode(oneCountryCode))
							.and(OneCountryEntitySpecification.isActive())));

	}

	@Override
	public int verifyRecordExits(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Integer oneCountryId, Optional<String> oneCountryCode) {
		return (int) oneCountryRepository
				.count(Specification.where(
						(OneCountryEntitySpecification.betweenEffectiveAndFromDate(effectiveFromDate)
						.or(OneCountryEntitySpecification.betweenEffectiveDateAndToDate(effectiveToDate)))
						.and(OneCountryEntitySpecification.equalCountryCode(oneCountryCode))
						.and(OneCountryEntitySpecification.notEqualOneCountryId(oneCountryId))
						.and(OneCountryEntitySpecification.isActive())));
	}

	@Override
	public int checkSameInActiveRecord(Optional<String> oneCountryCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate) {
		return (int) oneCountryRepository
				.count(Specification.where(
						(OneCountryEntitySpecification.equalEffectiveFromDate(effectiveFromDate))
						.and(OneCountryEntitySpecification.equalEffectiveToDate(effectiveToDate))
						.and(OneCountryEntitySpecification.equalCountryCode(oneCountryCode))
						.and(OneCountryEntitySpecification.isNotActive())));
	}

	@Override
	public List<OneCountryEntity> getAllOneCountryEntity(Optional<String> effectiveDate,
			Optional<String> oneCountryCode) {
		return oneCountryRepository
				.findAll(Specification.where(
						(OneCountryEntitySpecification.betweenEffectiveAndFromDate(effectiveDate)
						.or(OneCountryEntitySpecification.greaterThanOrEqualToEffectiveDate(effectiveDate)))
						.and(OneCountryEntitySpecification.lessThanOrEqualToEffectiveDate(effectiveDate))
						.and(OneCountryEntitySpecification.equalCountryCode(oneCountryCode))
						.and(OneCountryEntitySpecification.isActive())));
	}

	@Override
	public Optional<OneCountryEntity> getOneCountryEntity(Optional<String> countryCodeList,
			Optional<String> effectiveDate) {
		return oneCountryRepository
				.findOne(Specification.where(
						(OneCountryEntitySpecification.betweenEffectiveAndFromDate(effectiveDate)
						.or(OneCountryEntitySpecification.greaterThanOrEqualToEffectiveDate(effectiveDate)))
						.and(OneCountryEntitySpecification.lessThanOrEqualToEffectiveDate(effectiveDate))
						.and(OneCountryEntitySpecification.likeCountryCodeList(countryCodeList))
						.and(OneCountryEntitySpecification.isActive())));
	}

	@Override
	public List<OneCountryEntity> search(Optional<String> oneCountryCode, Optional<String> countryCodeList,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> isActive) {
		return oneCountryRepository.findAll(Specification.where(OneCountryEntitySpecification.search(oneCountryCode,
				countryCodeList, effectiveFromDate, effectiveToDate, isActive)));
	}

}
