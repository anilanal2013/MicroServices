package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.ProrateFactorDao;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProrateFactorEntitySpecification;
import com.sgl.smartpra.global.master.app.repository.ProrateFactorRepository;
import com.sgl.smartpra.global.master.app.repository.entity.ProrateFactorEntity;
import com.sgl.smartpra.global.master.model.Currency;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProrateFactorDaoImpl extends CommonSearchDao<Currency> implements ProrateFactorDao {

	@Autowired
	private ProrateFactorRepository prorateFactorRepository;

	// Create Service
	@Override
	@Caching(evict = { @CacheEvict(value = "prorateFactor", key = "#prorateFactorEntity.prorateFactorId") })
	public ProrateFactorEntity create(ProrateFactorEntity prorateFactorEntity) {
		return prorateFactorRepository.save(prorateFactorEntity);
	}

	// Update Service
	@Override
	@CachePut(value = "prorateFactor", key = "#prorateFactorEntity.prorateFactorId")
	public ProrateFactorEntity update(ProrateFactorEntity prorateFactorEntity) {
		return prorateFactorRepository.save(prorateFactorEntity);
	}

	// Update, activate, deactivate
	@Override
	@Cacheable(value = "prorateFactor", key = "#prorateFactorId")
	public Optional<ProrateFactorEntity> findById(Integer prorateFactorId) {
		return prorateFactorRepository.findById(prorateFactorId);
	}

	// getAll --> Search
	@Override
	public List<ProrateFactorEntity> search(Optional<String> fromCityCode, Optional<String> toCityCode,
			Optional<Boolean> activate) {
		return prorateFactorRepository
				.findAll(ProrateFactorEntitySpecification.search(fromCityCode, toCityCode, activate));
	}

	@Override
	public long checkOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate, String fromCityCode,
			String toCityCode) {
		return prorateFactorRepository.count(Specification
				.where(ProrateFactorEntitySpecification.equalsFromCityCode(fromCityCode))
				.and(ProrateFactorEntitySpecification.equalsToCityCode(toCityCode))
				.and(ProrateFactorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProrateFactorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))));
	}

	@Override
	public List<ProrateFactorEntity> getAllProrateFactorEntity(Optional<String> fromCityCode,
			Optional<String> toCityCode, Optional<String> effectiveDate) {
		return prorateFactorRepository.findAll(
				ProrateFactorEntitySpecification.getAllProrateFactorEntity(fromCityCode, toCityCode, effectiveDate));
	}

	@Override
	public long verifyIfOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate, String fromCityCode,
			String toCityCode, Integer prorateFactorId) {

		return prorateFactorRepository.count(Specification
				.where(ProrateFactorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProrateFactorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(ProrateFactorEntitySpecification.equalsFromCityCode(fromCityCode))
						.and(ProrateFactorEntitySpecification.equalsToCityCode(toCityCode))
						.and(ProrateFactorEntitySpecification.notEqualsToProrateFactorId(prorateFactorId))
						.and(ProrateFactorEntitySpecification.isActive())));
	}

	@Override
	public List<ProrateFactorEntity> verifyRecordExits(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Integer prorateFactorId, Optional<String> fromCityCode,
			Optional<String> toCityCode) {
		return prorateFactorRepository.findAll(ProrateFactorEntitySpecification.verifyRecordExits(effectiveFromDate,
				effectiveToDate, prorateFactorId, fromCityCode, toCityCode));
	}

	@Override
	public long checkSameInActiveRecord(String fromCityCode, String toCityCode, LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return prorateFactorRepository.count(Specification
				.where(ProrateFactorEntitySpecification.equalsFromCityCode(fromCityCode))
				.and(ProrateFactorEntitySpecification.equalsToCityCode(toCityCode))
				.and(ProrateFactorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.and(ProrateFactorEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.and(ProrateFactorEntitySpecification.isNotActive())));
	}

	@Override
	public Optional<ProrateFactorEntity> getAllProrateFactorEntityFTE(Optional<String> fromCityCode,
			Optional<String> toCityCode, Optional<String> effectiveDate) {
		return prorateFactorRepository.findOne(Specification.where(ProrateFactorEntitySpecification
				.getAllProrateFactorEntityFTE(fromCityCode, toCityCode, effectiveDate)));
	}

}
