package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.AirportDao;
import com.sgl.smartpra.global.master.app.dao.entity.AirportEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.AirportEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.AirportRepository;
import com.sgl.smartpra.global.master.model.Airport;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AirportDaoImpl extends CommonSearchDao<Airport> implements AirportDao {

	@Autowired
	private AirportRepository airportRepository;

	@Override
	@Cacheable(value = "airport", key = "#id")
	public Optional<AirportEntity> findById(String id) {
		log.info("Cacheable Airport Entity's ID = {}", id);
		return airportRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "airport", key = "#airportEntity.airportCode"),
			@CacheEvict(value = "airportSearch", allEntries = true) })
	public AirportEntity create(AirportEntity airportEntity) {
		return airportRepository.save(airportEntity);
	}

	@Override
	@CachePut(value = "airport", key = "#airportEntity.airportCode")
	@CacheEvict(value = "airportSearch", allEntries = true)
	public AirportEntity update(AirportEntity airportEntity) {
		return airportRepository.save(airportEntity);
	}
	
	@Override
	public Page<AirportEntity> findAll(AirportEntity airportEntity, Optional<String> exceptionCall, Pageable pageable) {
		return airportRepository.findAll(AirportEntitySpecification.search(airportEntity, exceptionCall), pageable);
	}
	
	@Override
	public long getCount(AirportEntity airportEntity, Optional<String> exceptionCall) {
		return airportRepository.count(AirportEntitySpecification.search(airportEntity, exceptionCall));
	}
	
	@Override
	public List<AirportEntity> searchAll(Optional<String> airportCode, Optional<String> airportName,
			Optional<String> cityCode, Optional<String> cityName, Optional<String> countryCode) {
		return airportRepository.findAll(AirportEntitySpecification.searchAll(airportCode, airportName, cityCode, cityName, countryCode));
	}

	@Override
	public Optional<AirportEntity> isValidAirportCode(Optional<String> airportOrCity) {
		return airportRepository.findOne(Specification.where(AirportEntitySpecification.equalAirportCode(airportOrCity)
				.and(AirportEntitySpecification.isActive(true))));
	}
	

	@Override
	public List<AirportEntity> isValidCityCodeList(Optional<String> cityCode) {
		return airportRepository.findAll(Specification.where(AirportEntitySpecification.equalCityCode(cityCode)
				.and(AirportEntitySpecification.isActive(true))));
	}
	
	@Override
	public List<AirportEntity> isValidAirportCodeList(Optional<String> airportCode) {
		return airportRepository.findAll(Specification.where(AirportEntitySpecification.equalAirportCode(airportCode)
				.and(AirportEntitySpecification.isActive(true))));
	}
	
	@Override
	public List<AirportEntity> isValidStateCode(Optional<String> stateCode) {
		return airportRepository.findAll(Specification.where(AirportEntitySpecification.equalStateCode(stateCode)
				.and(AirportEntitySpecification.isActive(true))));
	}

	@Override
	public List<AirportEntity> searchByCityOrStateOrCountry(Optional<String> airportCode, Optional<String> stateCode,
			Optional<String> cityCode, Optional<String> countryCode) {
		return airportRepository.findAll(AirportEntitySpecification.searchByCityOrStateOrCountry(airportCode, stateCode, cityCode, countryCode));
	}
	
}
