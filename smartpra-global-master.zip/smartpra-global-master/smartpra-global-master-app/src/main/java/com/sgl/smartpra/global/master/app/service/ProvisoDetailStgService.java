package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoDetailStgModel;

public interface ProvisoDetailStgService {
	public ProvisoDetailStgModel createProvisoDetail(ProvisoDetailStgModel provisoDetailStgModel);

	public List<ProvisoDetailStgModel> getProvisoDetailByProvisoMainId(Optional<Integer> provisoMainId);

	public ProvisoDetailStgModel getProvisoDetailByProvisoDetailId(Integer provisoDetailId);

	public List<ProvisoDetailStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);

	public ProvisoDetailStgModel updateProvisoDetail(Integer provisoDetailId,
			ProvisoDetailStgModel provisoDetailStgModel);

	public List<ProvisoDetailStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> fbGroupCode);

	public void deleteProvisoDetailByProvisoMainId(Integer provisoMainId);

	public void deleteProvisoDetailByProvisoDetailId(Integer provisoDetailId);
}
