package com.sgl.smartpra.global.master.app.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.CurrencyDetailService;
import com.sgl.smartpra.global.master.model.CurrencyDetail;

@RestController
public class CurrencyDetailController {

	@Autowired
	CurrencyDetailService currencyDetailService;

	@GetMapping("/currencies/{currencyCode}/details")
	public List<CurrencyDetail> getListOfCurrencyDetails(@PathVariable(value = "currencyCode") String currencyCode,
			@RequestParam(value = "effectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return currencyDetailService.getAllCurrencyDetails(currencyCode, effectiveDate);
	}
	
	@GetMapping("/currencies/{currencyCode}/details/effectiveDate/{effectiveDate}")
	public CurrencyDetail getCurrencyByCurrencyCodeAndEffectiveDate(
			@PathVariable(value = "currencyCode") String currencyCode,
			@PathVariable(value = "effectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return currencyDetailService.getCurrencyByCurrencyCodeAndEffectiveDate(currencyCode, effectiveDate);
	}

	@GetMapping("/currencies/{currencyCode}/details/isValid")
	public boolean isValidCurrencyCode(@PathVariable(value = "currencyCode") String currencyCode,
			@RequestParam(value = "effectiveDate") String effectiveDate) {
		Date effectiveDateObject = new Date();
		try {
			effectiveDateObject = new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<CurrencyDetail> currencyDetails = null;
		try {
			 currencyDetails = currencyDetailService.getAllCurrencyDetails(currencyCode,
					Optional.of(effectiveDate));

		}
		catch(Exception ex) {
			return false;
		}
	
		if (currencyDetails == null || currencyDetails.isEmpty())
			return false;
		else
			return true;
	}

	@GetMapping("/currencies/{currencyCode}/details/{currencyDetailId}")
	public CurrencyDetail getCurrencyDetailByCurrencyDetailCode(
			@PathVariable(value = "currencyCode") String currencyCode,
			@PathVariable(value = "currencyDetailId") int currencyDetailId) {
		return currencyDetailService.getCurrencyDetailByCurrencyDetailCode(currencyCode, currencyDetailId);
	}

	@PostMapping("/currencies/{currencyCode}/details")
	public CurrencyDetail createCurrencyDetail(@PathVariable(value = "currencyCode") String currencyCode,
			@Validated(Create.class) @RequestBody CurrencyDetail currencyDetails) {
		return currencyDetailService.createCurrencyDetail(currencyCode, currencyDetails);
	}

	@PutMapping("/currencies/{currencyCode}/details/{currencyDetailId}")
	public CurrencyDetail updateCurrencydetails(@PathVariable(value = "currencyCode") String currencyCode,
			@PathVariable(value = "currencyDetailId") int currencyDetailId,
			@Validated(Update.class) @RequestBody CurrencyDetail currencyDetails) {
		return currencyDetailService.updateCurrencyDetail(currencyCode, currencyDetailId, currencyDetails);
	}

	@DeleteMapping("/currencies/{currencyCode}/details/{currencyDetailId}")
	public void deleteCurrencyDetail(@PathVariable(value = "currencyCode") String currencyCode,
			@PathVariable(value = "currencyDetailId") int currencyDetailId) {
		currencyDetailService.deleteCurrencyDetail(currencyCode, currencyDetailId);
	}

}
