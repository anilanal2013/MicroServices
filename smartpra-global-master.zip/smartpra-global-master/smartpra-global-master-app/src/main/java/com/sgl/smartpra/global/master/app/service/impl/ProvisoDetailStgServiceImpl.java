package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.ProvisoDetailStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoMainStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoRoutingStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingStgEntity;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.ProvisoDetailStgMapper;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CarrierService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.ProvisoDetailStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoMainStgService;
import com.sgl.smartpra.global.master.app.service.StandardAreaSrevice;
import com.sgl.smartpra.global.master.app.service.UserAreaSrevice;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.Geo;
import com.sgl.smartpra.global.master.model.ProvisoDetailStgModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoDetailStgServiceImpl implements ProvisoDetailStgService {
	
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exist";
	private static final String AIRPORTCITY = "Only alphabets are allowed for Airport/City";
	private static final String PATTERN = "^[a-zA-Z]*$";
	private static final String AIRPORTCITYINVALID = "Invalid  Airport/City code : ";
	private static final String COUNTRYCODEALPHA = "Only alphabets are allowed for country code";
	private static final String COUNTRYCODEINVALID = "Invalid  country code : ";
	private static final String INVALIDSTDAREACODE = "Invalid  standard area code : ";
	private static final String GLOBAL = "global";
	private static final String FROMAREAINCLUDEMENDATORY = "Please provide AreaFromInclude";
	private static final String STATECODEALPHA = "Only alphabets are allowed for state code";
	private static final String INVALIDSTATECODE = "Invalid state code : ";
	private static final String MANDATORYGEOTYPEVALUE = "Please provide Geo Type Value";
	private static final String DOESNOTEXIST = " Does not exist";
	private static final String ISNOTACTIVE = " is not active";
	private static final String PROVISO_DETAIL_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN = "CarierNumCode of Proviso Detail should be similar to CarierNumCode of Proviso Main Corresponding to Proviso Main Id";
	private static final String DETAIL_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso Detail data not available for selected Proviso Main record";
	private static final String PROVISO_DETAIL_SINGLE_RECORD = "Please delete Proviso Main record";
	private static final String SUBPARA = "Sub Para Reference should start with ";
	public static final String REGEX_PATTERN_AVERAGE = "^\\d{0,3}(\\.\\d{0,3})?$";
	
	
	@Autowired
	private ProvisoDetailStgDao provisoDetailStgDao;
	@Autowired
	private ProvisoDetailStgMapper provisoDetailStgMapper;
	@Autowired
	private MasterFeignClient masterFeignClient;
	@Autowired
	private CarrierService carrierService;

	@Autowired
	private UserAreaSrevice userAreaSrevice;

	@Autowired
	private AirportService airportService;

	@Autowired
	private CountryService countryService;

	@Autowired
	StandardAreaSrevice standardAreaSrevice;

	@Autowired
	private ProvisoMainStgService provisoMainStgService;

	@Autowired
	private ProvisoRoutingStgDao provisoRoutingStgDao;
	
	@Autowired
	private ProvisoMainStgDao provisoMainStgDao;

	List<String> typeValueList = new ArrayList<>();

	String clientId = null;
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String SECTORFBFLAG_LOV_COLUMN_VALUE = LOVEnum.SECTOR_FB_FLAG.getLOVEnum();
	Boolean getSectorFromFlag = false;
	Boolean getSectorToFlag = false;

	@Override
	public List<ProvisoDetailStgModel> getProvisoDetailByProvisoMainId(Optional<Integer> provisoMainId) {
		List<Integer> provisoMainIdFromDb = provisoDetailStgDao.getListOfProvisoMainIdFromDetailStgDb();
		if (!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))) {
			throw new BusinessException(DETAIL_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		return provisoDetailStgMapper.mapToModel(provisoDetailStgDao.findByMainId(provisoMainId));
	}

	@Override
	@Transactional(rollbackOn = BusinessException.class)
	public ProvisoDetailStgModel createProvisoDetail(ProvisoDetailStgModel provisoDetailStgModel) {
		
		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(OptionalUtil.getValue(provisoDetailStgModel.getProvisoMainId()))
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(OptionalUtil.getValue(provisoDetailStgModel.getProvisoMainId()))));
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("D"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}
		if (OptionalUtil.isPresent(provisoDetailStgModel.getPercentage())) {
			validatePercentage(provisoDetailStgModel.getPercentage());
		}

		Integer detailRecNumber = provisoDetailStgDao.getMaxOfProvisoDetailRecNumber(
				provisoDetailStgModel.getCarrierNumCode(), provisoDetailStgModel.getProvisoSeqNumber());
		detailRecNumber = (detailRecNumber == null) ? Integer.valueOf(1)
				: Integer.valueOf(detailRecNumber.intValue() + 1);
		provisoDetailStgModel.setDetailRecNumber(Optional.of(detailRecNumber));

		provisoDetailStgModel.setCreatedDate(LocalDateTime.now());
		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		String sectorFromInclude = null;
		String sectorFromExclude = null;
		String sectorToInclude = null;
		String sectorToExclude = null;
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()))) {
			String[] fromAreaArray = validateArea(provisoDetailStgModel.getSectorFrom(),
					provisoDetailStgModel.getSectorFromInclude(), provisoDetailStgModel.getSectorFromExclude(),
					provisoDetailStgModel.getFromUserSectorName(), GLOBAL);
			sectorFromInclude = fromAreaArray[0];
			sectorFromExclude = fromAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()))) {
			String[] toAreaArray = validateArea(provisoDetailStgModel.getSectorTo(),
					provisoDetailStgModel.getSectorToInclude(), provisoDetailStgModel.getSectorToExclude(),
					provisoDetailStgModel.getToUserSectorName(), GLOBAL);
			sectorToInclude = toAreaArray[0];
			sectorToExclude = toAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		boolean fromSectorStandardSectorFlag = false;
		boolean toSectorStandardSectorFlag = false;
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom())))
			fromSectorStandardSectorFlag = OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo())))
			toSectorStandardSectorFlag = OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()))) {
			provisoDetailStgModel
					.setSectorFrom(Optional.of(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom())));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()))) {
			provisoDetailStgModel.setSectorTo(Optional.of(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo())));
		}
		validateBusinessConstraintsForCreate(provisoDetailStgModel);
		ProvisoDetailStgModel provisoDetailStgRecord = provisoDetailStgMapper
				.mapToModel(provisoDetailStgDao.create(provisoDetailStgMapper.mapToEntity(provisoDetailStgModel)));
		Boolean updateFlag = false;
		String areaKey1 = "P";
		Carrier carrier = carrierService
				.findCarrierByCarrierCode(OptionalUtil.getValue(provisoDetailStgModel.getCarrierNumCode()));
		String areaKey2 = OptionalUtil.getValue(carrier.getCarrierCode());
		String areaKey3 = provisoDetailStgRecord.getProvisoDetailId().toString();
		String areaKey4 = "GLB";
		Map<String, String> map = new HashMap<>();
		map.put("areaKey1", areaKey1);
		map.put("areaKey2", areaKey2);
		map.put("areaKey3", areaKey3);
		map.put("areaKey4", areaKey4);
		map.put("userFromAreaName", provisoDetailStgModel.getFromUserSectorName());
		map.put("areaFromInclude", sectorFromInclude);
		map.put("areaFromExclude", sectorFromExclude);
		map.put("createdBy", OptionalUtil.getValue(provisoDetailStgModel.getCreatedBy()));
		if(OptionalUtil.isPresent(provisoDetailStgModel.getSectorFrom())) {
		map.put("userFromArea", OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()).substring(1,
				OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()).length()));
		}
		map.put("updateFlag", updateFlag.toString());

		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom())) && fromSectorStandardSectorFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo())) && toSectorStandardSectorFlag) {
			map.put("areaToInclude", sectorToInclude);
			map.put("areaToExclude", sectorToExclude);
			map.put("userToAreaName", provisoDetailStgModel.getToUserSectorName());
			map.put("userToArea", OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()).substring(1,
					OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()).length()));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo())) && toSectorStandardSectorFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		updateMainProvisoStatus(provisoMainStgEntity);
		return provisoDetailStgRecord;	
	}

	
	@Transactional(rollbackOn = BusinessException.class)
	private void updateMainProvisoStatus(ProvisoMainStgEntity provisoMainStgEntity) {
		provisoMainStgDao.updateProvisoMainStg(provisoMainStgEntity);		
	}

	private void validateBusinessConstraintsForCreate(ProvisoDetailStgModel provisoDetailStgModel) {
		validateOverlapForCreate(provisoDetailStgModel);
		validateByComparingPerAndArticleC(provisoDetailStgModel);
		validateExcepFrom(provisoDetailStgModel);
		validateExcepTo(provisoDetailStgModel);
		validateSectFromSectToForSectFbFlag(provisoDetailStgModel);
		validateCarrierNumCodeByProvisoMainId(provisoDetailStgModel);
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSubParaReference()))) {
			validateSubPara(OptionalUtil.getValue(provisoDetailStgModel.getProvisoMainId()),
				OptionalUtil.getValue(provisoDetailStgModel.getSubParaReference()));
		}
	}
	
	private void validateSubPara(Integer provisoMainId, String subParaReference) {
		ProvisoMainStgEntity mainEntity =provisoMainStgDao.findById(provisoMainId)
		.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoMainId)));
		
		if (Objects.nonNull(mainEntity.getProvisoSection()) && Objects.nonNull(subParaReference)) {
			String mainPara = mainEntity.getProvisoSection().trim();
			
			char firstLetter = subParaReference.charAt(0);
			if (!mainPara.equalsIgnoreCase(String.valueOf(firstLetter))) {
				throw new BusinessException(SUBPARA+mainPara);
			}
			
		}
	}

	private void validateCarrierNumCodeByProvisoMainId(ProvisoDetailStgModel provisoDetailStgModel) {

		String carrierNumCode = OptionalUtil.getValue((provisoMainStgService
				.getProvisoMainByprovisoMainId(OptionalUtil.getValue(provisoDetailStgModel.getProvisoMainId())))
						.getCarrierNumCode());

		if (!(OptionalUtil.getValue(provisoDetailStgModel.getCarrierNumCode()).equalsIgnoreCase(carrierNumCode))) {
			throw new BusinessException(PROVISO_DETAIL_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN);
		}

	}

	private void validateSectFromSectToForSectFbFlag(ProvisoDetailStgModel provisoDetailStgModel) {
		if (OptionalUtil.isPresent(provisoDetailStgModel.getSectorFbFlag())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, TABLENAME,
					SECTORFBFLAG_LOV_COLUMN_VALUE);

			if (!(listOfValues.contains(OptionalUtil.getValue(provisoDetailStgModel.getSectorFbFlag())))) {
				if (OptionalUtil.isPresent(provisoDetailStgModel.getSectorFrom())) {
					throw new BusinessException("Sector From and Sector To both should be empty");
				}
			}
			if (listOfValues.contains(OptionalUtil.getValue(provisoDetailStgModel.getSectorFbFlag()))) {
				if (!(OptionalUtil.isPresent(provisoDetailStgModel.getSectorFrom()))) {
					throw new BusinessException("Sector From should not be Empty");
				}
				if (OptionalUtil.isPresent(provisoDetailStgModel.getSectorFrom())
						&& !(OptionalUtil.isPresent(provisoDetailStgModel.getSectorTo()))) {
					throw new BusinessException("Sector To is mandatory");
				}
			}
		}
	}

	private void validateExcepTo(ProvisoDetailStgModel provisoDetailStgModel) {
		Boolean excepInd = provisoDetailStgModel.getExceptionIndicator();
		Integer srNum = OptionalUtil.getValue(provisoDetailStgModel.getProvisoSeqNumber());
		Integer excepFromRecord = OptionalUtil.getValue(provisoDetailStgModel.getExceptionFromRecord());
		Integer excepToRecord = OptionalUtil.getValue(provisoDetailStgModel.getExceptionToRecord());
		if (Objects.nonNull(excepInd) && Objects.nonNull(excepToRecord) && Objects.nonNull(srNum) &&
				excepInd.equals(true) && excepToRecord >= srNum) {
			throw new BusinessException("ExceptionToRecord should be lower than ProvisoSeqNumber");
		}
		if (Objects.nonNull(excepInd) && Objects.nonNull(excepFromRecord) && Objects.nonNull(excepToRecord) &&
				excepInd.equals(true) && excepFromRecord > excepToRecord) {
			throw new BusinessException("ExceptionToRecord should be greater than or equal to ExceptionFromRecord");
		}
	}

	private void validateExcepFrom(ProvisoDetailStgModel provisoDetailStgModel) {
		Boolean excepInd = provisoDetailStgModel.getExceptionIndicator();
		Integer srNum = OptionalUtil.getValue(provisoDetailStgModel.getProvisoSeqNumber());
		Integer excepFromRecord = OptionalUtil.getValue(provisoDetailStgModel.getExceptionFromRecord());
		if (Objects.nonNull(excepInd) && Objects.nonNull(excepFromRecord) && Objects.nonNull(srNum) &&
				excepInd.equals(true) && excepFromRecord >= srNum) {
			throw new BusinessException("ExceptionFromRecord should be lower than ProvisoSeqNumber");
		}
	}

	private void validateByComparingPerAndArticleC(ProvisoDetailStgModel provisoDetailStgModel) {
		String per = null;
		if (OptionalUtil.isPresent(provisoDetailStgModel.getPercentage())) {
			per = OptionalUtil.getValue(provisoDetailStgModel.getPercentage());
		}
		Boolean articleC = provisoDetailStgModel.getArticleC(); 
		if (per != null && articleC != null) {
			throw new BusinessException("Either Percentage or ArtcleC should be Empty");
		}

	}

	private void validateOverlapForCreate(ProvisoDetailStgModel provisoDetailStgModel) {
		if (OptionalUtil.isPresent(provisoDetailStgModel.getCarrierNumCode())
				&& OptionalUtil.isPresent(provisoDetailStgModel.getProvisoSeqNumber())
				&& OptionalUtil.isPresent(provisoDetailStgModel.getDetailRecNumber())) {
			if (provisoDetailStgDao.getOverlapRecordCount(
					OptionalUtil.getValue(provisoDetailStgModel.getCarrierNumCode()),
					OptionalUtil.getValue(provisoDetailStgModel.getProvisoSeqNumber()),
					OptionalUtil.getValue(provisoDetailStgModel.getDetailRecNumber())) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}

	}

	@Override
	public ProvisoDetailStgModel getProvisoDetailByProvisoDetailId(Integer provisoDetailId) {

		return provisoDetailStgMapper.mapToModel(provisoDetailStgDao.findById(provisoDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoDetailId))));
	}

	@Override
	public List<ProvisoDetailStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {
		return provisoDetailStgMapper.mapToModel(provisoDetailStgDao.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	@Transactional(rollbackOn = BusinessException.class)
	public ProvisoDetailStgModel updateProvisoDetail(Integer provisoDetailId,
			ProvisoDetailStgModel provisoDetailStgModel) {
		
		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(OptionalUtil.getValue(provisoDetailStgModel.getProvisoMainId()))
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(OptionalUtil.getValue(provisoDetailStgModel.getProvisoMainId()))));
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}
		
		if (OptionalUtil.isPresent(provisoDetailStgModel.getPercentage())) {
			validatePercentage(provisoDetailStgModel.getPercentage());
		}

		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		String sectorFromInclude = null;
		String sectorFromExclude = null;
		String sectorToInclude = null;
		String sectorToExclude = null;

		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()))) {
			String[] fromAreaArray = validateArea(provisoDetailStgModel.getSectorFrom(),
					provisoDetailStgModel.getSectorFromInclude(), provisoDetailStgModel.getSectorFromExclude(),
					provisoDetailStgModel.getFromUserSectorName(), GLOBAL);
			sectorFromInclude = fromAreaArray[0];
			sectorFromExclude = fromAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()))) {
			String[] toAreaArray = validateArea(provisoDetailStgModel.getSectorTo(),
					provisoDetailStgModel.getSectorToInclude(), provisoDetailStgModel.getSectorToExclude(),
					provisoDetailStgModel.getToUserSectorName(), GLOBAL);
			sectorToInclude = toAreaArray[0];
			sectorToExclude = toAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		boolean fromSectorStandardSectorFlag = false;
		boolean toSectorStandardSectorFlag = false;
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom())))
			fromSectorStandardSectorFlag = OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo())))
			toSectorStandardSectorFlag = OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()))) {
			provisoDetailStgModel
					.setSectorFrom(Optional.of(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom())));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()))) {
			provisoDetailStgModel.setSectorTo(Optional.of(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo())));
		}

		log.info("{}", provisoDetailStgModel);
		ProvisoDetailStgEntity provisoDetailStgEntity = provisoDetailStgDao.findById(provisoDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoDetailId)));
		validateBusinessConstraintsForUpdate(provisoDetailStgModel, provisoDetailStgEntity);
		provisoDetailStgModel.setLastUpdatedDate(LocalDateTime.now());
		ProvisoDetailStgModel provisoDetailStgUpdatedRecord = provisoDetailStgMapper.mapToModel(provisoDetailStgDao
				.update(provisoDetailStgMapper.mapToEntity(provisoDetailStgModel, provisoDetailStgEntity)));

		Boolean updateFlag = false;
		String areaKey1 = "P";
		Carrier carrier = carrierService
				.findCarrierByCarrierCode(OptionalUtil.getValue(provisoDetailStgModel.getCarrierNumCode()));
		String areaKey2 = OptionalUtil.getValue(carrier.getCarrierCode());
		String areaKey3 = provisoDetailStgUpdatedRecord.getProvisoDetailId().toString();
		String areaKey4 = "GLB";
		Map<String, String> map = new HashMap<>();
		map.put("areaKey1", areaKey1);
		map.put("areaKey2", areaKey2);
		map.put("areaKey3", areaKey3);
		map.put("areaKey4", areaKey4);
		map.put("userFromAreaName", provisoDetailStgModel.getFromUserSectorName());
		map.put("areaFromInclude", sectorFromInclude);
		map.put("areaFromExclude", sectorFromExclude);
		map.put("createdBy", provisoDetailStgEntity.getCreatedBy());
		if(OptionalUtil.isPresent(provisoDetailStgModel.getSectorFrom())) {
		map.put("userFromArea", OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()).substring(1,
				OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom()).length()));
		}
		map.put("updateFlag", updateFlag.toString());
		map.put("lastUpdatedBy", OptionalUtil.getValue(provisoDetailStgModel.getLastUpdatedBy()));
		provisoDetailStgModel.setLastUpdatedDate(LocalDateTime.now());
		map.put("lastUpdatedDate", provisoDetailStgModel.getLastUpdatedDate().toString());

		userAreaSrevice.deleteUserArea(areaKey1, areaKey2, areaKey3);

		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorFrom())) && fromSectorStandardSectorFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo())) && toSectorStandardSectorFlag) {
			map.put("areaToInclude", sectorToInclude);
			map.put("areaToExclude", sectorToExclude);
			map.put("userToAreaName", provisoDetailStgModel.getToUserSectorName());
			map.put("userToArea", OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()).substring(1,
					OptionalUtil.getValue(provisoDetailStgModel.getSectorTo()).length()));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSectorTo())) && toSectorStandardSectorFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		updateMainProvisoStatus(provisoMainStgEntity);
		return provisoDetailStgUpdatedRecord;
	}

	private void validateBusinessConstraintsForUpdate(ProvisoDetailStgModel provisoDetailStgModel,
			ProvisoDetailStgEntity provisoDetailStgEntity) {
		validateOverlapForUpdate(provisoDetailStgModel, provisoDetailStgEntity);
		validateByComparingPerAndArticleCForUpdate(provisoDetailStgModel);
		validateExcepFromForUpdate(provisoDetailStgModel);
		validateExcepToForUpdate(provisoDetailStgModel);
		validateSectFromSectToForSectFbFlagForUpdate(provisoDetailStgModel);
		validateCarrierNumCodeByProvisoMainId(provisoDetailStgModel);
		if (Objects.nonNull(OptionalUtil.getValue(provisoDetailStgModel.getSubParaReference())) || 
				Objects.nonNull(provisoDetailStgEntity.getSubParaReference()) ) {
			validateSubPara(getProvisoMainId(provisoDetailStgModel, provisoDetailStgEntity),
					getSubParaReference(provisoDetailStgModel, provisoDetailStgEntity));
		}
	}

	private void validateSectFromSectToForSectFbFlagForUpdate(ProvisoDetailStgModel provisoDetailStgModel) {
		if (OptionalUtil.isPresent(provisoDetailStgModel.getSectorFbFlag())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, TABLENAME,
					SECTORFBFLAG_LOV_COLUMN_VALUE);

			if (!(listOfValues.contains(OptionalUtil.getValue(provisoDetailStgModel.getSectorFbFlag())))) {
				if (OptionalUtil.isPresent(provisoDetailStgModel.getSectorFrom())) {
					throw new BusinessException("Sector From and Sector To both should be empty");
				}
			}
			if (listOfValues.contains(OptionalUtil.getValue(provisoDetailStgModel.getSectorFbFlag()))) {
				if (!(OptionalUtil.isPresent(provisoDetailStgModel.getSectorFrom()))) {
					throw new BusinessException("Sector From should not be Empty");
				}
				if (OptionalUtil.isPresent(provisoDetailStgModel.getSectorFrom())
						&& !(OptionalUtil.isPresent(provisoDetailStgModel.getSectorTo()))) {
					throw new BusinessException("Sector To is mandatory");
				}
			}
		}
	}

	private void validateExcepToForUpdate(ProvisoDetailStgModel provisoDetailStgModel) {
		Boolean excepInd = provisoDetailStgModel.getExceptionIndicator();
		Integer srNum = OptionalUtil.getValue(provisoDetailStgModel.getProvisoSeqNumber());
		Integer excepFromRecord = OptionalUtil.getValue(provisoDetailStgModel.getExceptionFromRecord());
		Integer excepToRecord = OptionalUtil.getValue(provisoDetailStgModel.getExceptionToRecord());
		if (Objects.nonNull(excepInd) && Objects.nonNull(excepToRecord) && Objects.nonNull(srNum) &&
				excepInd.equals(true) && excepToRecord >= srNum) {
			throw new BusinessException("ExceptionToRecord should be lower than ProvisoSeqNumber");
		}
		if (Objects.nonNull(excepInd) && Objects.nonNull(excepFromRecord) && Objects.nonNull(excepToRecord) &&
				excepInd.equals(true) && excepFromRecord > excepToRecord) {
			throw new BusinessException("ExceptionToRecord should be greater than or equal to ExceptionFromRecord");
		}
	}

	private void validateExcepFromForUpdate(ProvisoDetailStgModel provisoDetailStgModel) {
		Boolean excepInd = provisoDetailStgModel.getExceptionIndicator();
		Integer srNum = OptionalUtil.getValue(provisoDetailStgModel.getProvisoSeqNumber());
		Integer excepFromRecord = OptionalUtil.getValue(provisoDetailStgModel.getExceptionFromRecord());
		if (Objects.nonNull(excepInd) && Objects.nonNull(excepFromRecord) && Objects.nonNull(srNum) &&
				excepInd.equals(true) && excepFromRecord >= srNum) {
			throw new BusinessException("ExceptionFromRecord should be lower than ProvisoSeqNumber");
		}
	}

	private void validateByComparingPerAndArticleCForUpdate(ProvisoDetailStgModel provisoDetailStgModel) {
		String per = null;
		if (OptionalUtil.isPresent(provisoDetailStgModel.getPercentage())) {
			per = OptionalUtil.getValue(provisoDetailStgModel.getPercentage());
		}
		Boolean articleC = provisoDetailStgModel.getArticleC();
		if (Objects.nonNull(per) && Objects.nonNull(articleC)) {
			throw new BusinessException("Either Percentage or ArtcleC should be Empty");
		}
	}

	private void validateOverlapForUpdate(ProvisoDetailStgModel provisoDetailStgModel,
			ProvisoDetailStgEntity provisoDetailStgEntity) {
		String carrierNumCode = getCarrierNumCode(provisoDetailStgModel, provisoDetailStgEntity);
		Integer provisoSeqNumber = getProvisoSeqNumber(provisoDetailStgModel, provisoDetailStgEntity);
		Integer detailRecNumber = getDetailRecNumber(provisoDetailStgModel, provisoDetailStgEntity);

		if (!carrierNumCode.equalsIgnoreCase(provisoDetailStgEntity.getCarrierNumCode())
				|| !provisoSeqNumber.equals(provisoDetailStgEntity.getProvisoSeqNumber())
				|| !detailRecNumber.equals(provisoDetailStgEntity.getDetailRecNumber())) {
			if (provisoDetailStgDao.getOverlapRecordCount(carrierNumCode, provisoSeqNumber, detailRecNumber,
					provisoDetailStgEntity.getProvisoDetailId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}

	}

	private String getCarrierNumCode(ProvisoDetailStgModel provisoDetailStgModel,
			ProvisoDetailStgEntity provisoDetailStgEntity) {
		return OptionalUtil.isPresent(provisoDetailStgModel.getCarrierNumCode())
				? OptionalUtil.getValue(provisoDetailStgModel.getCarrierNumCode())
				: provisoDetailStgEntity.getCarrierNumCode();
	}

	private Integer getProvisoSeqNumber(ProvisoDetailStgModel provisoDetailStgModel,
			ProvisoDetailStgEntity provisoDetailStgEntity) {
		return OptionalUtil.isPresent(provisoDetailStgModel.getProvisoSeqNumber())
				? OptionalUtil.getValue(provisoDetailStgModel.getProvisoSeqNumber())
				: provisoDetailStgEntity.getProvisoSeqNumber();
	}

	private Integer getDetailRecNumber(ProvisoDetailStgModel provisoDetailStgModel,
			ProvisoDetailStgEntity provisoDetailStgEntity) {
		return OptionalUtil.isPresent(provisoDetailStgModel.getDetailRecNumber())
				? OptionalUtil.getValue(provisoDetailStgModel.getDetailRecNumber())
				: provisoDetailStgEntity.getDetailRecNumber();
	}
	
	private Integer getProvisoMainId(ProvisoDetailStgModel provisoDetailStgModel,
			ProvisoDetailStgEntity provisoDetailStgEntity) {
		return OptionalUtil.isPresent(provisoDetailStgModel.getProvisoMainId())
				? OptionalUtil.getValue(provisoDetailStgModel.getProvisoMainId())
				: provisoDetailStgEntity.getProvisoMainId();
	}
	
	private String getSubParaReference(ProvisoDetailStgModel provisoDetailStgModel,
			ProvisoDetailStgEntity provisoDetailStgEntity) {
		return OptionalUtil.isPresent(provisoDetailStgModel.getSubParaReference())
				? OptionalUtil.getValue(provisoDetailStgModel.getSubParaReference())
				: provisoDetailStgEntity.getSubParaReference();
	}

	@Override
	public List<ProvisoDetailStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> fbGroupCode) {

		return provisoDetailStgMapper
				.mapToModel(provisoDetailStgDao.search(carrierNumCode, provisoSeqNumber, fbGroupCode));
	}

	private StringBuilder userGeoList(List<Geo> l, StringBuilder geoString, boolean flag) {
		for (Geo geo : l) {

			if (geo.getGeoTypeId() == null)
				throw new BusinessException("GeoTypeId should be 1,2,3 or 5 ");
			if (geo.getGeoTypeId() == 1 || geo.getGeoTypeId() == 2 || geo.getGeoTypeId() == 3
					|| geo.getGeoTypeId() == 5) {

				if (geo.getGeoTypeId() == 1
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"GeoTypeValue should be maximum of 3 characters for  Airport/City Code");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					if (!airportService.isValidAirportCodeOrCityCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. Airport/City Code : "
								+ geo.getGeoTypeValue().toUpperCase() + "Does not exist or not active");
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 2
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 2) {
							typeValueList.clear();
							throw new BusinessException(
									"GeoTypeValue should be maximum of 2 characters for countryCode");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					try {
						countryService.getCountryByCountryCode(geo.getGeoTypeValue().toUpperCase());
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. Country Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					} catch (BusinessException se) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. Country Code :"
								+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 3
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (flag) {
						typeValueList.clear();
						throw new BusinessException("Geo Type Id 3 is not applicable for excludeGeoList");
					}
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"GeoTypeValue should be maximum of 3 characters for standardAreaCode");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					try {
						if (!standardAreaSrevice.isValidateStandardArea(geo.getGeoTypeValue().toUpperCase())) {
							typeValueList.clear();
							throw new BusinessException("Invalid Geo Type Value. standardArea Code : "
									+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
						}
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. standardArea Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					} catch (BusinessException se) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. standardArea Code : "
								+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 5
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 4) {
							typeValueList.clear();
							throw new BusinessException("GeoTypeValue should be maximum of 4 characters for stateCode");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					if (!airportService.isValidStateCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. State Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST + " or " + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					typeValueList.clear();
					throw new BusinessException("Duplicate Geotype Value: " + geo.getGeoTypeValue().toUpperCase());
				}

			} else {
				typeValueList.clear();
				throw new BusinessException(
						"invalid Geo type id :" + geo.getGeoTypeId() + " Only 1,2,3,5 are the valid Geo type id ");
			}

		} // enf of for loop
		if (geoString.length() > 1000) {
			typeValueList.clear();
			throw new BusinessException(
					"area_include_list or area_exclude_list length must be less than 1000 charecters");
		}
		if (geoString.length() != 0) {
			geoString.delete(geoString.length() - 1, geoString.length());
		}
		return geoString;

	}

	public String[] validateArea(Optional<String> geoArea, List<Geo> list, List<Geo> list2, String userAreaName,
			String area) {

		String[] array = new String[2];
		String areaInclude = "";
		String areaExclude = "";

		if (OptionalUtil.getValue(geoArea).startsWith("1") || OptionalUtil.getValue(geoArea).startsWith("2")
				|| OptionalUtil.getValue(geoArea).startsWith("3") || OptionalUtil.getValue(geoArea).startsWith("5")) {
			if (list != null || list2 != null || userAreaName != null) {
				throw new BusinessException("For " + OptionalUtil.getValue(geoArea)
						+ " IncludeArea, ExcludeArea and userAreaName not required for non User Defined Area");
			}
		}
		if (OptionalUtil.getValue(geoArea) != null) {
			if (OptionalUtil.getValue(geoArea).startsWith("1")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(AIRPORTCITY);
				} else {
					if (!airportService.isValidAirportCodeOrCityCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(AIRPORTCITYINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("2")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(COUNTRYCODEALPHA);
				} else {
					if (!countryService.isValidCountryCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(COUNTRYCODEINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("3")) {
				if (!standardAreaSrevice.getActiveStandardAreaByStandardAreaCode(
						OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
					throw new BusinessException(INVALIDSTDAREACODE
							+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("4") && area.equals(GLOBAL)) {
				boolean flag = false;
				List<Geo> geoFromAreaInclude = list;
				if (list != null && !list.isEmpty()) {

					if (userAreaName == null) {
						throw new BusinessException("Please provide User Area Name");
					}

					StringBuilder geoString = new StringBuilder();
					StringBuilder strareaIncludeList = userGeoList(geoFromAreaInclude, geoString, flag);
					areaInclude = strareaIncludeList.toString();
					if (list2 != null) {
						List<Geo> geoFromAreaExclude = list2;
						StringBuilder geoString1 = new StringBuilder();
						flag = true;
						StringBuilder strAreaExcludeList = userGeoList(geoFromAreaExclude, geoString1, flag);

						areaExclude = strAreaExcludeList.toString();
					}
					array[0] = areaInclude;
					array[1] = areaExclude;

				} else {
					throw new BusinessException(FROMAREAINCLUDEMENDATORY);
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("5")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(STATECODEALPHA);
				} else {
					if (!airportService.isValidStateCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(INVALIDSTATECODE
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			}
		}
		return array;
	}

	@Override
	public void deleteProvisoDetailByProvisoMainId(Integer provisoMainId) {
		List<ProvisoDetailStgEntity> detailList = provisoDetailStgDao.findByMainId(Optional.of(provisoMainId));
		
		getSectorFromFlag = false;
		getSectorToFlag = false;
		
		if (!detailList.isEmpty()) {
			detailList.stream().filter(Objects::nonNull).forEach(detail -> {
				if (Objects.nonNull(detail.getSectorFrom())) {
					getSectorFromFlag = detail.getSectorFrom().startsWith("4");
				}
				if (Objects.nonNull(detail.getSectorTo())) {
					getSectorToFlag = detail.getSectorTo().startsWith("4");
				}
				if (getSectorFromFlag || getSectorToFlag) {
					userAreaSrevice.deleteUserArea("P", detail.getCarrierNumCode(), detail.getProvisoDetailId().toString());
				}
			});
			
		}
		provisoDetailStgDao.deleteProvisoDetailByProvisoMainId(provisoMainId);
	}

	@Override
	public void deleteProvisoDetailByProvisoDetailId(Integer provisoDetailId) {
		ProvisoDetailStgEntity provisoDetailStgEntity = provisoDetailStgDao.findById(provisoDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoDetailId)));
		
		Integer mainId = provisoDetailStgEntity.getProvisoMainId();
		List<ProvisoDetailStgEntity>  detailStgEntities = provisoDetailStgDao.findByMainId(Optional.of(mainId));
		
		if (Objects.nonNull(detailStgEntities) && detailStgEntities.size() > 1) {
			
			getSectorFromFlag = false;
			getSectorToFlag = false;
			
			if (Objects.nonNull(provisoDetailStgEntity.getSectorFrom())) {
				getSectorFromFlag = provisoDetailStgEntity.getSectorFrom().startsWith("4");
			}
			if (Objects.nonNull(provisoDetailStgEntity.getSectorTo())) {
				getSectorToFlag = provisoDetailStgEntity.getSectorTo().startsWith("4");
			}
			if (getSectorFromFlag || getSectorToFlag) {
				userAreaSrevice.deleteUserArea("P", provisoDetailStgEntity.getCarrierNumCode(), 
						provisoDetailStgEntity.getProvisoDetailId().toString());
			}
			
		
			if (Optional.of(provisoDetailStgEntity.getCarrierNumCode()).isPresent()
					&& Optional.of(provisoDetailStgEntity.getProvisoSeqNumber()).isPresent()
					&& Optional.of(provisoDetailStgEntity.getDetailRecNumber()).isPresent()) {
				List<ProvisoRoutingStgEntity> provisoRoutingStgEntityList = provisoRoutingStgDao.search(
						Optional.of(provisoDetailStgEntity.getCarrierNumCode()),
						Optional.of(provisoDetailStgEntity.getProvisoSeqNumber()),
						Optional.of(provisoDetailStgEntity.getDetailRecNumber()));
				if (provisoRoutingStgEntityList.size() > 1) {
					provisoRoutingStgDao.deleteProvisoRoutingByCarrierNumSeqRecNumber(
							Optional.of(provisoDetailStgEntity.getCarrierNumCode()),
							Optional.of(provisoDetailStgEntity.getProvisoSeqNumber()),
							Optional.of(provisoDetailStgEntity.getDetailRecNumber()));
				}
			}
			provisoDetailStgDao.deleteProvisoDetailByProvisoDetailId(provisoDetailId);
		} else {
			throw new BusinessException(PROVISO_DETAIL_SINGLE_RECORD);
		}
	}
	
	private void validatePercentage(Optional<String> percentage) {
		if (OptionalUtil.isPresent(percentage)) {
			Pattern digitPattern = Pattern.compile(REGEX_PATTERN_AVERAGE);
			if (!digitPattern.matcher(OptionalUtil.getValue(percentage)).matches()) {
				throw new BusinessException("Invalid Percentage " + OptionalUtil.getValue(percentage));
			}
		}
	}
}