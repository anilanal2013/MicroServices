package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.SIRSRatesEntity;

public class SIRSRatesEntitySpecification {

	public static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";
	public static final String EFFECTIVE_TO_DATE = "effectiveToDate";
	public static final String GLOBAL_REGION = "globalRegion";
	public static final String ACTIVATE = "activate";
	
	public static void orderByAsc(Root<SIRSRatesEntity> sirsRatesEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(sirsRatesEntity.get(orderByString)));
	}

	public static Specification<SIRSRatesEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (sirsRatesEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), sirsRatesEntity.get("effectiveFromDate"),
				sirsRatesEntity.get("effectiveToDate"));
	}

	public static Specification<SIRSRatesEntity> equalsGlobalRegion(String globalRegion) {
		return (sirsRatesEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(sirsRatesEntity.get("globalRegion"), globalRegion);
	}

	public static Specification<SIRSRatesEntity> notEqualsSIRSRateId(Integer sirsRateId) {
		return (sirsRatesEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(sirsRatesEntity.get("sirsRateId"), sirsRateId);
	}

	public static void orderByEffectiveDate(Root<SIRSRatesEntity> sirsRatesEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String effectiveDate, String globalRegion) {
		criteriaQuery.orderBy(criteriaBuilder.desc(sirsRatesEntity.get(effectiveDate)),
				criteriaBuilder.asc(sirsRatesEntity.get(globalRegion)));
	}

	public static Specification<SIRSRatesEntity> search(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> globalRegion) {
		return (sirsRatesEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(globalRegion)) {
				predicates.add(criteriaBuilder.like(sirsRatesEntity.get(GLOBAL_REGION),
						OptionalUtil.getValue(globalRegion) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)
					&& OptionalUtil.getValue(effectiveFromDate) != null
					&& OptionalUtil.getValue(effectiveToDate) != null
					&& !OptionalUtil.getValue(effectiveFromDate).isEmpty()
					&& !OptionalUtil.getValue(effectiveToDate).isEmpty()) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								sirsRatesEntity.get(EFFECTIVE_FROM_DATE), sirsRatesEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								sirsRatesEntity.get(EFFECTIVE_FROM_DATE), sirsRatesEntity.get(EFFECTIVE_TO_DATE))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.getValue(effectiveFromDate) != null
						&& !OptionalUtil.getValue(effectiveFromDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							sirsRatesEntity.get(EFFECTIVE_FROM_DATE), sirsRatesEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (OptionalUtil.isPresent(effectiveToDate) && OptionalUtil.getValue(effectiveToDate) != null
						&& !OptionalUtil.getValue(effectiveToDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							sirsRatesEntity.get(EFFECTIVE_FROM_DATE), sirsRatesEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			predicates.add(criteriaBuilder.equal(sirsRatesEntity.get(ACTIVATE), true));
			orderByEffectiveDate(sirsRatesEntity, criteriaQuery, criteriaBuilder, EFFECTIVE_FROM_DATE, GLOBAL_REGION);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<SIRSRatesEntity> search(SIRSRatesEntity mapToEntity) {
		return (sirsRatesEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			
			  if (isEmptyOrNull(mapToEntity.getGlobalRegion())) { predicates.add(
			  criteriaBuilder.like(sirsRatesEntity.get(GLOBAL_REGION),
			  mapToEntity.getGlobalRegion() + "%")); }
			 
			if (mapToEntity.getEffectiveFromDate() != null && mapToEntity.getEffectiveToDate() != null) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveFromDate()),
								sirsRatesEntity.get(EFFECTIVE_FROM_DATE), sirsRatesEntity.get(EFFECTIVE_TO_DATE)),
						criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveToDate()),
								sirsRatesEntity.get(EFFECTIVE_FROM_DATE), sirsRatesEntity.get(EFFECTIVE_TO_DATE))));
			} else {
				if (mapToEntity.getEffectiveFromDate() != null) {
					predicates.add(criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveFromDate()),
							sirsRatesEntity.get(EFFECTIVE_FROM_DATE), sirsRatesEntity.get(EFFECTIVE_TO_DATE)));
				}
				if (mapToEntity.getEffectiveToDate() != null) {
					predicates.add(criteriaBuilder.between(criteriaBuilder.literal(mapToEntity.getEffectiveToDate()),
							sirsRatesEntity.get(EFFECTIVE_FROM_DATE), sirsRatesEntity.get(EFFECTIVE_TO_DATE)));
				}
			}
			predicates.add(criteriaBuilder.equal(sirsRatesEntity.get(ACTIVATE), true));
			orderByEffectiveDate(sirsRatesEntity, criteriaQuery, criteriaBuilder, EFFECTIVE_FROM_DATE, GLOBAL_REGION);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<SIRSRatesEntity> search(LocalDate dateString) {
		return (sirsRatesEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (dateString != null) {
				predicates.add(criteriaBuilder.between(criteriaBuilder.literal(dateString),
						sirsRatesEntity.get(EFFECTIVE_FROM_DATE), sirsRatesEntity.get(EFFECTIVE_TO_DATE)));
			}
			orderByAsc(sirsRatesEntity, criteriaQuery, criteriaBuilder, "effectiveToDate");

			predicates.add(criteriaBuilder.equal(sirsRatesEntity.get(ACTIVATE), true));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	private static boolean isEmptyOrNull(String value) {
		return value != null && !value.isEmpty();
	} 
}
