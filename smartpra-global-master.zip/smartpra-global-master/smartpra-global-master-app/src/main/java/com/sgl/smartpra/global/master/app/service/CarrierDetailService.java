package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.sgl.smartpra.global.master.model.CarrierDetail;

public interface CarrierDetailService {

	CarrierDetail createCarrierDetail(String carrierCode, @Valid CarrierDetail carrierDetails);

	List<CarrierDetail> getListOfCarrierDetailsByEffectiveDate(Optional<String> carrierCode,
			Optional<String> effectiveFromDate);

	CarrierDetail getCarrierDetailByCarrierDetailCode(String carrierCode, int carrierDetailId);

	CarrierDetail updateCarrierDetail(String carrierCode, int carrierDetailId, @Valid CarrierDetail carrierDetails);

	void deleteCarrierDetail(String carrierCode, int carrierDetailId);

	CarrierDetail getCarrierType(String carrierDesignatorCode, String effectiveDate);
	CarrierDetail getCarrierTypeByCarrierCode(String carrierCode, String effectiveDate);

}
