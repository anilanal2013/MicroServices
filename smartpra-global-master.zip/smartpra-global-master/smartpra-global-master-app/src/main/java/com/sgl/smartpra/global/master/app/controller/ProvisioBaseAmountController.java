package com.sgl.smartpra.global.master.app.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.ProvisioBaseAmountService;
import com.sgl.smartpra.global.master.model.ProvisioBaseAmount;

@RestController
public class ProvisioBaseAmountController {

	@Autowired
	private ProvisioBaseAmountService provisioBaseAmountService;

	@PostMapping("/proviso")
	public ProvisioBaseAmount createProvisioBaseAmount(
			@Validated(Create.class) @RequestBody ProvisioBaseAmount provisioBaseAmount) {
		return provisioBaseAmountService.createProvisioBaseAmount(provisioBaseAmount);
	}

	@GetMapping("/proviso")
	public List<ProvisioBaseAmount> getAllProvisioBaseAmount(
			@RequestParam(value = "fromCityCode", required = false) String fromCityCode,
			@RequestParam(value = "carrierCode", required = false) String carrierCode,
			@RequestParam(value = "toCityCode", required = false) String toCityCode,
			@RequestParam(value = "activate", required = false) Boolean activate) {
		return provisioBaseAmountService.getListOfProvisioBaseAmount(fromCityCode, toCityCode, carrierCode, activate);
	}

	@GetMapping("/proviso/{fromCityCode}/{toCityCode}/{carrierCode}/{effectiveDate}/{classCode}")
	public ProvisioBaseAmount getProvisioBaseAmountByTicketDate(
			@PathVariable(value = "fromCityCode") String fromCityCode,
			@PathVariable(value = "toCityCode") String toCityCode,
			@PathVariable(value = "carrierCode") String carrierCode,
			@PathVariable(value = "classCode") String classCode,
			@PathVariable(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date effectiveDate) {
		return provisioBaseAmountService.getProvisioBaseAmountByTicketDate(fromCityCode, toCityCode, effectiveDate,
				carrierCode, classCode);
	}

	@GetMapping("/provisovalue/{fromCityCode}/{toCityCode}/{carrierCode}/{effectiveDate}/{classCode}")
	public ProvisioBaseAmount getProvisioBaseAmountByTicketString(
			@PathVariable(value = "fromCityCode") String fromCityCode,
			@PathVariable(value = "toCityCode") String toCityCode,
			@PathVariable(value = "carrierCode") String carrierCode,
			@PathVariable(value = "classCode") String classCode,
			@PathVariable(value = "effectiveDate") String effectiveDate) {
		return provisioBaseAmountService.getProvisioBaseAmountByTicketDate(fromCityCode, toCityCode, effectiveDate,
				carrierCode, classCode);

	}

	@GetMapping("/proviso-base-amount/{fromCityCode}/{toCityCode}/{classCode}/{carrierCode}/{issueDate}")
	public ProvisioBaseAmount getProvisoBaseAmount(
			@PathVariable(value = "fromCityCode", required = true) String fromCityCode,
			@PathVariable(value = "toCityCode", required = true) String toCityCode,
			@PathVariable(value = "classCode", required = true) String classCode,
			@PathVariable(value = "carrierCode", required = true) String carrierCode,
			@PathVariable(value = "issueDate") @DateTimeFormat(pattern = "yyyy-MM-dd") String issueDate) {
		return provisioBaseAmountService.getProvisoBaseAmount(fromCityCode, toCityCode, classCode, carrierCode,
				issueDate);
	}

	@PutMapping("/proviso/{provisoBaseid}")
	public ProvisioBaseAmount updateProvisioBaseAmount(@PathVariable(value = "provisoBaseid") Integer provisoBaseid,
			@Validated(Update.class) @RequestBody ProvisioBaseAmount prorateFactor) {
		return provisioBaseAmountService.updateProvisioBaseAmount(provisoBaseid, prorateFactor);
	}

	@PutMapping("/proviso/{provisoBaseid}/deactivate")
	public void deactivateProvisioBaseAmount(@Valid @PathVariable(value = "provisoBaseid") Integer provisoBaseid,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		provisioBaseAmountService.deactivateProvisioBaseAmount(provisoBaseid, lastUpdatedBy);
	}

	@PutMapping("/proviso/{provisoBaseid}/activate")
	public void activateProvisioBaseAmount(@Valid @PathVariable(value = "provisoBaseid") Integer provisoBaseid,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		provisioBaseAmountService.activateProvisioBaseAmount(provisoBaseid, lastUpdatedBy);
	}

	@GetMapping("/proviso/{provisoBaseid}")
	public ProvisioBaseAmount findByProvisioBaseId(@PathVariable(value = "provisoBaseid") Integer provisoBaseid) {
		return provisioBaseAmountService.findByProvisioBaseId(provisoBaseid);
	}

}
