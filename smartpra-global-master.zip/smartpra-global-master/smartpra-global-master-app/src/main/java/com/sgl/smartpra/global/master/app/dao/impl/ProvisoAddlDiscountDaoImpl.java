package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoAddlDiscountDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoAddlDiscountEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoAddlDiscountRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoAddlDiscountDaoImpl implements ProvisoAddlDiscountDao {

	@Autowired
	private ProvisoAddlDiscountRepository provisoAddlDiscountRepository;

	@Override
	public List<ProvisoAdditionalDiscountEntity> findByMainId(Optional<Integer> provisoMainId) {
		return provisoAddlDiscountRepository
				.findAll(ProvisoAddlDiscountEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	@Cacheable(value = "provisoAdditionalDiscount", key = "#id")
	public Optional<ProvisoAdditionalDiscountEntity> findById(Integer id) {

		log.info("Cacheable Proviso Routing Entity's ID= {}", id);
		return provisoAddlDiscountRepository.findById(id);
	}

	@Override
	public List<ProvisoAdditionalDiscountEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<String> discountCode) {

		return provisoAddlDiscountRepository
				.findAll(ProvisoAddlDiscountEntitySpecification.search(carrierNumCode, provisoSeqNumber, discountCode));
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "provisoAdditionalDiscount", key = "#provisoAdditionalDiscountEntity.provisoMainId") })
	public ProvisoAdditionalDiscountEntity create(ProvisoAdditionalDiscountEntity provisoAdditionalDiscountEntity) {
		return provisoAddlDiscountRepository.save(provisoAdditionalDiscountEntity);
	}

	@Override
	public List<Integer> getListOfProvisoMainIdFromAddlDiscountDb() {
		return provisoAddlDiscountRepository.getListOfProvisoMainIdFromAddlDistcountDb();
	}
}
