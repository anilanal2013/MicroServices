package com.sgl.smartpra.global.master.app.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.StandardAreaEntity;

@Repository
public interface StandardAreaRepository
		extends JpaRepository<StandardAreaEntity, String>, JpaSpecificationExecutor<StandardAreaEntity> {

	List<StandardAreaEntity> findDistinctByStandardAreaCodeIsNotNullAndActivateTrueOrderByStandardAreaCode();

	StandardAreaEntity findByStandardAreaCodeAndActivate(String standardAreaCode,Boolean activate);
}
