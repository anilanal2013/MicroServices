package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingStgEntity;

@Repository
public interface ProvisoRoutingStgRepository
		extends JpaRepository<ProvisoRoutingStgEntity, Integer>, JpaSpecificationExecutor<ProvisoRoutingStgEntity> {
	@Query(value = "select prs.provisoMainId from ProvisoRoutingStgEntity prs")
	List<Integer> getListOfProvisoMainIdFromRoutingStgDb();

	@Transactional
	@Modifying
	@Query("delete from ProvisoRoutingStgEntity prse where prse.provisoMainId= ?1")
	void deleteProvisoRoutingByProvisoMainId(Integer provisoMainId);

	@Transactional
	@Modifying
	@Query("delete from ProvisoRoutingStgEntity prse where prse.carrierNumCode= ?1 AND prse.provisoSeqNumber=?2 AND prse.detailRecNumber=?3")
	void deleteProvisoRoutingByCarrierNumSeqRecNumber(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<Integer> detailRecNumber);

	@Query(value = "select max(prs.routingRecNumber) from ProvisoRoutingStgEntity prs where prs.carrierNumCode=?1 AND prs.provisoSeqNumber=?2 AND prs.detailRecNumber=?3")
	Integer getMaxOfProvisoRoutingRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber);
}
