package com.sgl.smartpra.global.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.global.master.app.repository.entity.UserAreaEntity;
import com.sgl.smartpra.global.master.model.GlobalUserArea;

@Mapper
public interface UserAreaMapper {

	GlobalUserArea mapToUserAreaModel(UserAreaEntity userAreaEntity);

	List<GlobalUserArea> mapToUserAreaModelList(List<UserAreaEntity> userAreaEntityList);

	UserAreaEntity mapToUserAreaEntity(GlobalUserArea userArea);

	List<UserAreaEntity> mapToUserAreaEntityList(List<GlobalUserArea> userAreaList);

}
