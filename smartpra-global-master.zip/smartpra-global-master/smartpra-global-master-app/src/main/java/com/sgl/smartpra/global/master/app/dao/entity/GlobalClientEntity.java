package com.sgl.smartpra.global.master.app.dao.entity;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "global_mas_client")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class GlobalClientEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    private String clientId;

    private String clientName;

    private String clientTitle;

    private String appUrl;

    private String ipRange;

    private String clientAddress;

    private String city;

    private String region;

    private String phone;

    private String fax;

    @Convert(converter = BooleanToStringConverter.class)
    private Boolean isActive;

    @PrePersist
    public void prePersist() {
        setCreatedDate(LocalDateTime.now());
    }

    @PreUpdate
    public void preUpdate() {
        setLastUpdatedDate(LocalDateTime.now());
    }


}
