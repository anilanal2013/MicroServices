package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorStgEntity;

public class ProvisoCodeshareStgEntitySpecification {
	ProvisoCodeshareStgEntitySpecification(){
	}

	public static Specification<ProvisoCodeshareStgEntity> equalsCarrierNumCode(String carrierNumCode) {
		return (provisoCodeshareStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoCodeshareStgEntity.get("carrierNumCode"), carrierNumCode);
	}

	public static Specification<ProvisoCodeshareStgEntity> equalsProvisoSeqNumber(Integer provisoSeqNumber) {
		return (provisoCodeshareStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoCodeshareStgEntity.get("provisoSeqNumber"), provisoSeqNumber);
	}

	public static Specification<ProvisoCodeshareStgEntity> equalsProvisoSection(String provisoSection) {
		return (provisoCodeshareStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoCodeshareStgEntity.get("provisoSection"), provisoSection);
	}

	public static Specification<ProvisoCodeshareStgEntity> equalsAreaFrom(String areaFrom) {
		return (provisoCodeshareStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoCodeshareStgEntity.get("areaFrom"), areaFrom);
	}

	public static Specification<ProvisoCodeshareStgEntity> equalsAreaTo(String areaTo) {
		return (provisoCodeshareStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoCodeshareStgEntity.get("areaTo"), areaTo);
	}
	
	public static Specification<ProvisoCodeshareStgEntity> notEqualsProvisoCodeshareId(Integer provisoCodeshareId) {
		return (provisoCodeshareStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(provisoCodeshareStgEntity.get("provisoCodeshareId"), provisoCodeshareId);
	}
	
	public static Specification<ProvisoCodeshareStgEntity> search(Optional<Integer> provisoMainId,
			Optional<String> areaFrom, Optional<String> areaTo) {
		return (provisoCodeshareStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareStgEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}
			if (OptionalUtil.isPresent(areaFrom)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareStgEntity.get("areaFrom"),
						OptionalUtil.getValue(areaFrom)));
			}
			if (OptionalUtil.isPresent(areaTo)) {
				predicates.add(
						criteriaBuilder.equal(provisoCodeshareStgEntity.get("areaTo"), OptionalUtil.getValue(areaTo)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<ProvisoCodeshareStgEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<String> provisoSection, Optional<String> areaFrom,
			Optional<String> areaTo) {
		return (provisoCodeshareStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareStgEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareStgEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			if (OptionalUtil.isPresent(provisoSection)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareStgEntity.get("provisoSection"),
						OptionalUtil.getValue(provisoSection)));
			}
			if (OptionalUtil.isPresent(areaFrom)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareStgEntity.get("areaFrom"),
						OptionalUtil.getValue(areaFrom)));
			}
			if (OptionalUtil.isPresent(areaTo)) {
				predicates.add(
						criteriaBuilder.equal(provisoCodeshareStgEntity.get("areaTo"), OptionalUtil.getValue(areaTo)));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
	public static Specification<ProvisoCodeshareStgEntity> findByMainId(Optional<Integer> provisoMainId) {
		return (provisoCodeshareStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareStgEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
