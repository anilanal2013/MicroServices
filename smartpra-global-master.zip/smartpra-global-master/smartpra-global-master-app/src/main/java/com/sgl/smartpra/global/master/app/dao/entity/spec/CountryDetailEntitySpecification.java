package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.CountryDetailEntity;
import com.sgl.smartpra.global.master.app.dao.entity.FaresEntity;

public class CountryDetailEntitySpecification {

	private CountryDetailEntitySpecification() {
	}

	public static Specification<CountryDetailEntity> equalsCountryCode(String countryCode) {
		return (countryDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(countryDetailEntity.get("countryCode"), countryCode);
	}

	public static Specification<CountryDetailEntity> notEqualsCountryDtlId(Integer countryDtlId) {
		return (countryDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(countryDetailEntity.get("countryDtlId"), countryDtlId);
	}
	
	public static Specification<CountryDetailEntity> greaterThanOrEqualToEffectiveFromDate(LocalDate effectiveDate) {
		return (countryDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(countryDetailEntity.get("effectiveFromPeriod"), effectiveDate);
	}
	
	public static Specification<CountryDetailEntity> lessThanOrEqualToEffectiveToDate(LocalDate effectiveDate) {
		return (countryDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(countryDetailEntity.get("effectiveToPeriod"), effectiveDate);
	}

	public static Specification<CountryDetailEntity> betweenEffectiveFromPeriodAndEffectiveToPeriod(
			LocalDate effectiveDate) {
		return (countryDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), countryDetailEntity.get("effectiveFromPeriod"),
				countryDetailEntity.get("effectiveToPeriod"));
	}

	public static Specification<CountryDetailEntity> likeCountryCode(Optional<String> countryCode) {
		return (countryDetailEntity, CriteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(countryDetailEntity.get("countryCode"), OptionalUtil.getValue(countryCode) + "%");
	}

	public static Specification<FaresEntity> equalsTariffCode(String tariffCode) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("tariffCode"),
				tariffCode);
	}

	public static void orderByAsc(Root<CountryDetailEntity> countryDetailEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(countryDetailEntity.get(orderByString)));
	}

	public static Specification<CountryDetailEntity> getAllCountryEntityByEffectiveDate(Optional<String> countryCode,
			Optional<String> effectiveDate) {
		return (countryDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(countryCode)) {
				predicates.add(criteriaBuilder.equal(countryDetailEntity.get("countryCode"),
						OptionalUtil.getValue(countryCode)));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
						countryDetailEntity.get("effectiveFromPeriod"), countryDetailEntity.get("effectiveToPeriod")));
			}
			orderByAsc(countryDetailEntity, criteriaQuery, criteriaBuilder, "countryCode");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
