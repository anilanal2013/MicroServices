package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.CarrierDetailEntity;
import com.sgl.smartpra.global.master.model.CarrierDetail;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CarrierDetailMapper extends BaseMapper<CarrierDetail, CarrierDetailEntity>{

	CarrierDetailEntity mapToEntity(CarrierDetail carrierDetail, @MappingTarget CarrierDetailEntity carrierDetailEntity);

	@Mapping(source = "carrierDetailId", target = "carrierDetailId", ignore = true)
	CarrierDetailEntity mapToEntity(CarrierDetail carrierDetail);

}
