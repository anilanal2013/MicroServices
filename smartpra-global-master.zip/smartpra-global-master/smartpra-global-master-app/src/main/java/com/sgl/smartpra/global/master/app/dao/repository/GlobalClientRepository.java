package com.sgl.smartpra.global.master.app.dao.repository;

import com.sgl.smartpra.global.master.app.dao.entity.GlobalClientEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface GlobalClientRepository extends JpaRepository<GlobalClientEntity, String>, JpaSpecificationExecutor<GlobalClientEntity> {


}
