package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;

public class ProvisoMainStgEntitySpecification {
	ProvisoMainStgEntitySpecification(){
	}
	
	public static Specification<ProvisoMainStgEntity> equalsCarrierNumCode(String carrierNumCode) {
		return (provisoMainStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoMainStgEntity.get("carrierNumCode"), carrierNumCode);
	}

	public static Specification<ProvisoMainStgEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (provisoMainStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), provisoMainStgEntity.get("effectiveFromDate"),
				provisoMainStgEntity.get("effectiveToDate"));
	}
    
	public static Specification<ProvisoMainStgEntity> equalsProvisoSection(String provisoSection) {
		return (provisoMainStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoMainStgEntity.get("provisoSection"), provisoSection);
	}
	
	public static Specification<ProvisoMainStgEntity> notEqualsfopId(Integer provisoMainId) {
		return (provisoMainStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(provisoMainStgEntity.get("provisoMainId"), provisoMainId);
	}
    
	public static Specification<ProvisoMainStgEntity> search(Optional<String> carrierNumCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> provisoSection,
			Optional<String> provisoStatus){
		return (provisoMainStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoMainStgEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSection)) {
				predicates.add(criteriaBuilder.equal(provisoMainStgEntity.get("provisoSection"),
						OptionalUtil.getValue(provisoSection)));
			}
			if (OptionalUtil.isPresent(provisoStatus)) {
				predicates.add(criteriaBuilder.equal(provisoMainStgEntity.get("provisoStatus"),
						OptionalUtil.getValue(provisoStatus)));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(criteriaBuilder.between(
						criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
						provisoMainStgEntity.get("effectiveFromDate"), provisoMainStgEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								provisoMainStgEntity.get("effectiveFromDate"),
								provisoMainStgEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							provisoMainStgEntity.get("effectiveFromDate"),
							provisoMainStgEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							provisoMainStgEntity.get("effectiveFromDate"),
							provisoMainStgEntity.get("effectiveToDate")));
				}
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
}
