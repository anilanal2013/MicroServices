package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_proviso_sector")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class ProvisoSectorEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "proviso_sector_id", nullable = false)
	private Integer provisoSectorId;

	@Column(name = "proviso_main_id", nullable = false)
	private Integer provisoMainId;

	@Column(name = "carrier_num_code", nullable = false, length = 3)
	private String carrierNumCode;

	@Column(name = "proviso_seq_number", nullable = false)
	private Integer provisoSeqNumber;

	@Column(name = "section_rec_number", nullable = false)
	private Integer sectionRecNumber;

	@Column(name = "area_check_flag", nullable = false, length = 1)
	private String areaCheckFlag;

	@Column(name = "area_from", nullable = false, length = 4)
	private String areaFrom;

	@Column(name = "area_to", length = 4)
	private String areaTo;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
