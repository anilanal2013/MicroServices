package com.sgl.smartpra.global.master.app.service;

import com.sgl.smartpra.global.master.model.ChargeCodeType;

import java.util.List;
import java.util.Optional;

public interface ChargeCodeTypeService {

	List<ChargeCodeType> getAllChargeCodeTypeByCodeandCat(Optional<String> chargeCode, Optional<String> chargeCatCode);
	
	ChargeCodeType getChargeCodeById(Integer id);

	ChargeCodeType getChargeCodeTypeByChargeCatAndChargeCodeAndChargeCodeType(
			Optional<String> chargeCodeCategory,Optional<String> chargeCode, Optional<String> chargeType);
}
