package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.FaresEntity;

public final class FaresEntitySpecification {

	private FaresEntitySpecification() {
	}

	public static void orderByAsc(Root<FaresEntity> faresEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(faresEntity.get(orderByString)));
	}
	
	public static Specification<FaresEntity> equalsTariffCode(String tariffCode) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("tariffCode"),
				tariffCode);
	}

	public static Specification<FaresEntity> isActive() {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("activate"),
				true);
	}

	public static Specification<FaresEntity> equalsCxrCode(String cxrCode) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("cxrCode"),
				cxrCode);
	}

	public static Specification<FaresEntity> equalsOriginCity(String originCity) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("originCity"),
				originCity);
	}

	public static Specification<FaresEntity> equalsDestinationCity(String destinationCity) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(faresEntity.get("destinationCity"), destinationCity);
	}

	public static Specification<FaresEntity> equalsFareBasis(String fareBasis) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("fareBasis"),
				fareBasis);
	}

	public static Specification<FaresEntity> equalsEffectiveFromDate(LocalDate effectiveFromDate) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(faresEntity.get("effectiveFromDate"), effectiveFromDate);
	}

	public static Specification<FaresEntity> equalsEffectiveToDate(String effectiveToDate) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(faresEntity.get("effectiveToDate"), effectiveToDate);
	}

	public static Specification<FaresEntity> equalsRuleNumber(String ruleNumber) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("ruleNumber"),
				ruleNumber);
	}

	public static Specification<FaresEntity> equalsRoutingNumber(String routingNumber) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("routingNumber"),
				routingNumber);
	}

	public static Specification<FaresEntity> equalsOwRtIndicator(String owRtIndicator) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("owRtIndicator"),
				owRtIndicator);
	}

	public static Specification<FaresEntity> equalsFareCurrency(String fareCurrency) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("fareCurrency"),
				fareCurrency);
	}

	public static Specification<FaresEntity> equalsFareValue(String fareValue) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("fareValue"),
				fareValue);
	}

	public static Specification<FaresEntity> equalsFareType(String fareType) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("fareType"),
				fareType);
	}

	public static Specification<FaresEntity> equalsConstruction(String construction) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("construction"),
				construction);
	}

	public static Specification<FaresEntity> equalsProrate(String prorate) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("prorate"),
				prorate);
	}

	public static Specification<FaresEntity> equalsDifferential(String differential) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("differential"),
				differential);
	}

	public static Specification<FaresEntity> equalsProportional(String proportional) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("proportional"),
				proportional);
	}

	public static Specification<FaresEntity> equalsFareFootNote(String fareFootNote) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("fareFootNote"),
				fareFootNote);
	}

	public static Specification<FaresEntity> equalsaction(String action) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("action"),
				action);
	}

	public static Specification<FaresEntity> equalsLinkNumber(String linkNumber) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("linkNumber"),
				linkNumber);
	}

	public static Specification<FaresEntity> equalsSequenceNumber(String sequenceNumber) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("sequenceNumber"),
				sequenceNumber);
	}

	public static Specification<FaresEntity> equalsOldMCN(String oldMCN) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("oldMCN"),
				oldMCN);
	}

	public static Specification<FaresEntity> equalsNewMCN(String newMCN) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("newMCN"),
				newMCN);
	}

	public static Specification<FaresEntity> equalsIsActive() {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(faresEntity.get("isActive"),
				true);
	}

	public static Specification<FaresEntity> notEqualsFaresId(Integer fareId) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.notEqual(faresEntity.get("fareId"),
				fareId);
	}

	public static Specification<FaresEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), faresEntity.get("effectiveFromDate"),
				faresEntity.get("effectiveToDate"));
	}

	public static Specification<FaresEntity> betweenEffectiveFrom(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				faresEntity.get("effectiveFromDate"), criteriaBuilder.literal(effectiveFromDate),
				criteriaBuilder.literal(effectiveToDate));

	}

	public static Specification<FaresEntity> search(Optional<String> cxrCode, Optional<String> originCity,
			Optional<String> destinationCity, Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(cxrCode)) {
				predicates.add(criteriaBuilder.equal(faresEntity.get("cxrCode"), OptionalUtil.getValue(cxrCode)));
			}
			if (OptionalUtil.isPresent(originCity)) {
				predicates.add(criteriaBuilder.equal(faresEntity.get("originCity"), OptionalUtil.getValue(originCity)));
			}
			if (OptionalUtil.isPresent(destinationCity)) {
				predicates.add(criteriaBuilder.equal(faresEntity.get("destinationCity"),
						OptionalUtil.getValue(destinationCity)));
			}
			
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)
				&& OptionalUtil.getValue(effectiveFromDate) != null && OptionalUtil.getValue(effectiveToDate) != null
				&& !OptionalUtil.getValue(effectiveFromDate).isEmpty() && !OptionalUtil.getValue(effectiveToDate).isEmpty()) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								faresEntity.get("effectiveFromDate"), faresEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								faresEntity.get("effectiveFromDate"), faresEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.getValue(effectiveFromDate) != null
						&& !OptionalUtil.getValue(effectiveFromDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							faresEntity.get("effectiveFromDate"), faresEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate) && OptionalUtil.getValue(effectiveToDate) != null
						&& !OptionalUtil.getValue(effectiveToDate).isEmpty()) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							faresEntity.get("effectiveFromDate"), faresEntity.get("effectiveToDate")));
				}
			}
			orderByAsc(faresEntity, criteriaQuery, criteriaBuilder, "cxrCode");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<FaresEntity> getFareForFareSelectionProcessing(Optional<String> cxrCode,
			Optional<String> originCity, Optional<String> destinationCity, Optional<String> effectiveDate) {
		return (faresEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(cxrCode)) {
				predicates.add(criteriaBuilder.equal(faresEntity.get("cxrCode"), OptionalUtil.getValue(cxrCode)));
			}
			if (OptionalUtil.isPresent(originCity)) {
				predicates.add(criteriaBuilder.equal(faresEntity.get("originCity"), OptionalUtil.getValue(originCity)));
			}
			if (OptionalUtil.isPresent(destinationCity)) {
				predicates.add(criteriaBuilder.equal(faresEntity.get("destinationCity"),
						OptionalUtil.getValue(destinationCity)));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								faresEntity.get("effectiveFromDate"), faresEntity.get("effectiveToDate")));
			}
			predicates.add(criteriaBuilder.or(criteriaBuilder.notEqual(faresEntity.get("prorate"), "N"),
					criteriaBuilder.isNull(faresEntity.get("prorate"))));
			predicates.add(criteriaBuilder.or(criteriaBuilder.notEqual(faresEntity.get("construction"), "R"),
					criteriaBuilder.isNull(faresEntity.get("construction"))));
			predicates.add(criteriaBuilder.or(criteriaBuilder.notEqual(faresEntity.get("proportional"), "P"),
					criteriaBuilder.isNull(faresEntity.get("proportional"))));
			predicates.add(criteriaBuilder.equal(faresEntity.get("activate"), Boolean.TRUE));
			orderByAsc(faresEntity, criteriaQuery, criteriaBuilder, "cxrCode");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
