package com.sgl.smartpra.global.master.app.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.controller.util.HeaderUtil;
import com.sgl.smartpra.global.master.app.service.TicketOverwriteDetailService;
import com.sgl.smartpra.global.master.model.TicketOverwriteDetail;

@RestController
public class TicketOverwriteDetailController {

	@Autowired
	private TicketOverwriteDetailService ticketOverwriteDetailService;
	
	@PostMapping("/saveTicketOverwriteDetail")
	public TicketOverwriteDetail saveTicketOverwriteDetail(@Valid @RequestBody TicketOverwriteDetail ticketOverwriteDetailDao) {
		return ticketOverwriteDetailService.saveTicketOverwriteDetail(ticketOverwriteDetailDao);
	}
	
	@GetMapping("/getTicketOverwriteDetail/{id}")
	public TicketOverwriteDetail getTicketOverwriteDetail(@PathVariable Long id) {
		return ticketOverwriteDetailService.getTicketOverwriteDetail(id);
	}
	
	@DeleteMapping("/deleteTicketOverwrite/{id}")
	public ResponseEntity<Void> deleteTicketOverwrite(@PathVariable Long id){
		ticketOverwriteDetailService.deleteTicketOverwriteDetail(id);
		return ResponseEntity.ok().headers(HeaderUtil.createAlert("Ticket.deleted", String.valueOf(id))).build();
	}
	
	@PutMapping("/activateOrDeactiveTicket/{id}")
	public ResponseEntity<Void> activateOrDeactiveTicket(@PathVariable Long id){
		ticketOverwriteDetailService.activateOrDeactiveTicketDetail(id);
		return ResponseEntity.ok().headers(HeaderUtil.createAlert("Ticket.activateOrDeactiveTicket", String.valueOf(id))).build();
	}
	
	
}
