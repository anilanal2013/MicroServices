package com.sgl.smartpra.global.master.app.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.controller.AirportController;
import com.sgl.smartpra.global.master.app.controller.CountryController;
import com.sgl.smartpra.global.master.app.controller.StandardAreaController;
import com.sgl.smartpra.global.master.app.controller.UserAreaController;
import com.sgl.smartpra.global.master.app.dao.SIRSRatesDao;
import com.sgl.smartpra.global.master.app.dao.entity.SIRSRatesEntity;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.SIRSRatesMapper;
import com.sgl.smartpra.global.master.app.service.SIRSRatesService;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.Country;
import com.sgl.smartpra.global.master.model.Geo;
import com.sgl.smartpra.global.master.model.SIRSRates;
import com.sgl.smartpra.global.master.model.SIRSRatesResponse;
import com.sgl.smartpra.global.master.model.StandardArea;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class SIRSRatesServiceImpl implements SIRSRatesService {

	@Autowired
	protected SIRSRatesMapper sirsRatesMapper;

	@Autowired
	protected SIRSRatesDao sirsRatesDao;

	@Autowired
	private MasterFeignClient masterFeignClient;

	@Autowired
	private AirportController airportController;

	@Autowired
	private CountryController countryController;

	@Autowired
	private StandardAreaController standardArea;

	@Autowired
	private UserAreaController userAreaController;

	@Autowired
	private UserAreaServiceImpl userAreaServiceImpl;

	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String GLOBAL_REGION_LOV_COLUMN_VALUE = LOVEnum.GLOBAL_REGION.getLOVEnum();
	public static final String GEO_AREA_INDICATOR_LOV_COLUMN_VALUE = LOVEnum.GEO_AREA_INDICATOR.getLOVEnum();
	String clientId = null;
	protected static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	private static final String INACTIVE_FOP = "Given SIRSRates record is not active";
	private static final String ACTIVE_FOP = "Given SIRSRates record is already active";
	private static final String GEO_AREA_INDICATOR = "Only valid values for GEO Area Indicator field is 'B'|W ";
	private static final String AREA_INDICATOR = "For GEO Area Indicator W ToArea field is not allowed";
	private static final String INVALIDFROMAREA = "Invalid From Area starts with ";
	private static final String INVALIDTOAREA = "Invalid To Area starts with ";
	private static final String PATTERN = "^[a-zA-Z]*$";
	private static final String AIRPORTCITY = "Only alphabets are allowed for Airport/City";
	private static final String AIRPORTCITYINVALID = "Invalid Airport/City Code ";
	private static final String COUNTRYCODEALPHA = "Only alphabets are allowed for Country Code";
	private static final String COUNTRYCODEINVALID = "Invalid Country Code ";
	private static final String INVALIDSTDAREACODE = "Invalid Standard Area Code ";
	private static final String STATECODEALPHA = "Only alphabets are allowed for State Code";
	private static final String INVALIDSTATECODE = "Invalid State Code ";
	private static final String FROMAREAINCLUDEMENDATORY = "Please provide From Area Include";
	private static final String MANDATORYGEOTYPEVALUE = "Please provide Geo Type Value";
	private static final String DOESNOTEXIST = " Does not exist";
	private static final String ISNOTACTIVE = " is not active";
	private static final String SIRS_ALREADY_INACTIVE = "SIRS Rates is already in deactive state";
	private static final String VALID_FROM_AREA = "Please provide valid From Area";
	public static final String REGEX_PATTERN_AVERAGE = "^\\d{0,3}(\\.\\d{0,3})?$";
	public static final String CLIENT = "client";
	public static final String USER_FROM_AREA_NAME = "userFromAreaName";

	public boolean checkIsStrtWithOrNot(Optional<String> toArea) {
		if (null != toArea) {
			if ((OptionalUtil.getValue(toArea).startsWith("4"))) {
				return true;
			}
		}
		return false;
	}

	@Override
	public SIRSRates createSIRSRates(SIRSRates sirsRates) {
		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		sirsRates.setActivate(Boolean.TRUE);

		commonValidation(sirsRates);
		// ToArea validation
		if (OptionalUtil.isPresent(sirsRates.getGeoAreaIndicator())) {
			validateGeoAreaIndicator(sirsRates);
		}
		// date validation
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(sirsRates.getEffectiveToDate()),
				OptionalUtil.getLocalDateValue(sirsRates.getEffectiveFromDate()));
		validateGlobalRegion(sirsRates);
		validateOverLap(sirsRates);
		bussinesValidation(sirsRates);
		// inserting data to user defined area
		String areaFromInclude = null;
		String areaFromExclude = null;
		String areaToInclude = null;
		String areaToExclude = null;

		if (OptionalUtil.getValue(sirsRates.getFromArea()).startsWith("4")
				|| checkIsStrtWithOrNot(sirsRates.getToArea())) {
			String[] fromAreaArray = validateArea(sirsRates.getFromArea(), sirsRates.getFromAreaInclude(),
					sirsRates.getFromAreaExclude(), sirsRates.getUserFromAreaName(), CLIENT);
			areaFromInclude = fromAreaArray[0];
			areaFromExclude = fromAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
			String[] toAreaArray = validateArea(sirsRates.getToArea(), sirsRates.getToAreaInclude(),
					sirsRates.getToAreaExclude(), sirsRates.getUserToAreaName(), CLIENT);
			areaToInclude = toAreaArray[0];
			areaToExclude = toAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
			// From Area Include validation
			String[] includeListArray = null;
			ArrayList<String> fromIncludeList = new ArrayList<>();
			fromIncludeList.add(areaFromInclude);
			for (int i = 0; i < fromIncludeList.size(); i++) {
				String includeList = fromIncludeList.get(i);
				if (includeList != null) {
					includeListArray = includeList.split(",");
				}
			}
			String[] excludeListArray = null;
			ArrayList<String> fromExcludeList = new ArrayList<>();
			fromExcludeList.add(areaFromExclude);

			for (int i = 0; i < fromExcludeList.size(); i++) {
				String excludeList = fromExcludeList.get(i);
				if (excludeList != null) {
					excludeListArray = excludeList.split(",");
				}
			}
			if (includeListArray != null) {
				for (int k = 0; k < includeListArray.length; k++) {
					String include = includeListArray[k];
					Stream<String> stream1 = Stream.of(excludeListArray);
					boolean anyMatch1 = stream1.anyMatch(s -> s.contains(include));
					if ((anyMatch1)) {
						throw new BusinessException("From Include List And From Exclude List should not be the same ");
					}
				}
			}

			// To Area Include validation
			if (OptionalUtil.isPresent(sirsRates.getToArea())) {
				String[] toincludeListArray = null;
				ArrayList<String> toIncludeList = new ArrayList<>();
				toIncludeList.add(areaToInclude);
				for (int i = 0; i < toIncludeList.size(); i++) {
					String includeList = toIncludeList.get(i);
					if (includeList != null) {
						toincludeListArray = includeList.split(",");
					}
				}
				String[] toExcludeListArray = null;
				ArrayList<String> toExcludeList = new ArrayList<>();
				toExcludeList.add(areaToExclude);
				for (int i = 0; i < toExcludeList.size(); i++) {
					String excludeList = toExcludeList.get(i);
					if (excludeList != null) {
						toExcludeListArray = excludeList.split(",");
					}
				}
				if (toExcludeListArray != null) {
					for (int k = 0; k < toincludeListArray.length; k++) {
						String include = toincludeListArray[k];
						Stream<String> stream1 = Stream.of(toExcludeListArray);
						boolean anyMatch1 = stream1.anyMatch(s -> s.contains(include));
						if ((anyMatch1)) {
							throw new BusinessException("To Include List And To Exclude List should not be the same ");
						}
					}
				}
			}
		}
		if (OptionalUtil.isPresent(sirsRates.getFromArea())) {
			OptionalUtil.getValue(sirsRates.getFromArea());
		}
		if (!OptionalUtil.isPresent(sirsRates.getToArea())) {
			sirsRates.setToArea(Optional.ofNullable(" "));
		}
		SIRSRates sirsRateRecord = sirsRatesMapper
				.mapToModel(sirsRatesDao.create(sirsRatesMapper.mapToEntity(sirsRates)));

		// User defined area validation
		if (OptionalUtil.getValue(sirsRates.getFromArea()).startsWith("4")
				|| OptionalUtil.getValue(sirsRates.getToArea()).startsWith("4")) {
			Boolean updateFlag = false;
			String areaKey1 = "V";
			String areaKey2 = "SIRS";
			String areaKey3 = sirsRateRecord.getSirsRateId().toString();
			String areaKey4 = clientId;
			Map<String, String> map = new HashMap<>();
			map.put("areaKey1", areaKey1);
			map.put("areaKey2", areaKey2);
			map.put("areaKey3", areaKey3);
			map.put("areaKey4", areaKey4);
			map.put(USER_FROM_AREA_NAME, sirsRates.getUserFromAreaName());
			map.put("areaFromInclude", areaFromInclude);
			map.put("areaFromExclude", areaFromExclude);
			map.put("createdBy", OptionalUtil.getValue(sirsRates.getCreatedBy()));
			map.put("userFromArea", OptionalUtil.getValue(sirsRates.getFromArea()).substring(1));
			map.put("updateFlag", updateFlag.toString());
			if (OptionalUtil.getValue(sirsRates.getFromArea()).startsWith("4")) {
				userAreaController.clientSpecificUserAreaInsertOrUpdate(map);
			}
			if (OptionalUtil.isPresent(sirsRates.getToArea())) {
				map.put("areaToInclude", areaToInclude);
				map.put("areaToExclude", areaToExclude);
				map.put(USER_FROM_AREA_NAME, sirsRates.getUserToAreaName());
				map.put("userToArea", OptionalUtil.getValue(sirsRates.getToArea()).substring(1));
			}
			try {
				if ((OptionalUtil.isPresent(sirsRates.getToArea())
						&& OptionalUtil.getValue(sirsRates.getToArea()).startsWith("4"))) {
					if (!(sirsRates.getToArea().equals(Optional.ofNullable(" ")))) {
						userAreaController.clientSpecificUserAreaInsertOrUpdate(map);
					}
				}
			} catch (DataIntegrityViolationException e) {
				log.error("context", e);
			}
		}
		return sirsRateRecord;
	}

	@Override
	public SIRSRates updateSIRSRates(SIRSRates sirsRates) {
		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		SIRSRatesEntity sirsEntity = sirsRatesDao.findById(sirsRates.getSirsRateId())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sirsRates.getSirsRateId())));
		if (!sirsEntity.getActivate())
			throw new BusinessException(SIRS_ALREADY_INACTIVE);
		validateBusinessConstraintsForUpdate(sirsRates, sirsEntity);
		if (OptionalUtil.isPresent(sirsRates.getGeoAreaIndicator())) {
			validateGeoAreaIndicator(sirsRates);
		}
		if (OptionalUtil.isPresent(sirsRates.getGlobalRegion())) {
			validateGlobalRegion(sirsRates);
		}
		commonValidation(sirsRates);
		if (OptionalUtil.isPresent(sirsRates.getFromArea())) {
			bussinesValidation(sirsRates);
		}
		validateOverlapForUpdate(sirsRates, sirsEntity);

		// inserting data to user defined area
		String areaFromInclude = null;
		String areaFromExclude = null;
		String areaToInclude = null;
		String areaToExclude = null;

		String[] fromAreaArray = validateArea(sirsRates.getFromArea(), sirsRates.getFromAreaInclude(),
				sirsRates.getFromAreaExclude(), sirsRates.getUserFromAreaName(), CLIENT);
		areaFromInclude = fromAreaArray[0];
		areaFromExclude = fromAreaArray[1];
		typeValueList = new ArrayList<>();
		typeValueList.clear();
		String[] toAreaArray = validateArea(sirsRates.getToArea(), sirsRates.getToAreaInclude(),
				sirsRates.getToAreaExclude(), sirsRates.getUserToAreaName(), CLIENT);

		areaToInclude = toAreaArray[0];
		areaToExclude = toAreaArray[1];
		typeValueList = new ArrayList<>();
		typeValueList.clear();

		boolean fromAreaStandardAreaFlag = false;
		boolean toAreaStandardAreaFlag = false;
		// From Area Include validation
		if (areaFromInclude != null || areaFromExclude != null) {
			String[] includeListArray = null;
			ArrayList<String> fromIncludeList = new ArrayList<>();
			fromIncludeList.add(areaFromInclude);
			for (int i = 0; i < fromIncludeList.size(); i++) {
				String includeList = fromIncludeList.get(i);
				if (includeList != null) {
					includeListArray = includeList.split(",");
				}
			}
			String[] excludeListArray = null;
			ArrayList<String> fromExcludeList = new ArrayList<>();
			fromExcludeList.add(areaFromExclude);
			for (int i = 0; i < fromExcludeList.size(); i++) {
				String excludeList = fromExcludeList.get(i);
				if (excludeList != null) {
					excludeListArray = excludeList.split(",");
				}
			}
			if (includeListArray != null) {
				for (int k = 0; k < includeListArray.length; k++) {
					String include = includeListArray[k];
					Stream<String> stream1 = Stream.of(excludeListArray);
					boolean anyMatch1 = stream1.anyMatch(s -> s.contains(include));

					if ((anyMatch1)) {
						throw new BusinessException("From Include List And From Exclude List should not be the same ");
					}
				}
			}
		}

		// To Area Include validation
		if (OptionalUtil.isPresent(sirsRates.getToArea())) {
			if (areaToInclude != null || areaToExclude != null) {
				String[] toincludeListArray = null;
				ArrayList<String> toIncludeList = new ArrayList<>();
				toIncludeList.add(areaToInclude);
				for (int i = 0; i < toIncludeList.size(); i++) {
					String includeList = toIncludeList.get(i);
					if (includeList != null) {
						toincludeListArray = includeList.split(",");
					}
				}
				String[] toExcludeListArray = null;
				ArrayList<String> toExcludeList = new ArrayList<>();
				toExcludeList.add(areaToExclude);
				for (int i = 0; i < toExcludeList.size(); i++) {
					String excludeList = toExcludeList.get(i);
					if (excludeList != null) {
						toExcludeListArray = excludeList.split(",");
					}
				}
				if (toincludeListArray != null) {
					for (int k = 0; k < toincludeListArray.length; k++) {
						String include = toincludeListArray[k];
						Stream<String> stream1 = Stream.of(toExcludeListArray);
						boolean anyMatch1 = stream1.anyMatch(s -> s.contains(include));
						if ((anyMatch1)) {
							throw new BusinessException("To Include List And To Exclude List should not be the same ");
						}
					}
				}
			}
		}

		if (OptionalUtil.isPresent(sirsRates.getFromArea())) {
			OptionalUtil.getValue(sirsRates.getFromArea());
		}
		if (OptionalUtil.isPresent(sirsRates.getToArea())) {
			OptionalUtil.getValue(sirsRates.getToArea());
		}

		sirsRates.setLastUpdatedDate(LocalDateTime.now());
		SIRSRates sirsRateRecord = sirsRatesMapper
				.mapToModel(sirsRatesDao.update(sirsRatesMapper.mapToEntity(sirsRates, sirsEntity)));
		// delete the user area record
		userAreaServiceImpl.deleteUserArea("V", "SIRS", sirsRateRecord.getSirsRateId().toString());
		// User defined area validation
		boolean startsWith = false;
		if (OptionalUtil.isPresent(sirsRates.getFromArea())) {
			startsWith = OptionalUtil.getValue(sirsRates.getFromArea()).startsWith("4");
		}
		if (startsWith || checkIsStrtWithOrNot(sirsRates.getToArea())) {
			Boolean updateFlag = false;
			String areaKey1 = "V";
			String areaKey2 = "SIRS";
			String areaKey3 = sirsRateRecord.getSirsRateId().toString();
			String areaKey4 = "QR";
			Map<String, String> map = new HashMap<>();
			map.put("areaKey1", areaKey1);
			map.put("areaKey2", areaKey2);
			map.put("areaKey3", areaKey3);
			map.put("areaKey4", areaKey4);
			map.put(USER_FROM_AREA_NAME, sirsRates.getUserFromAreaName());
			map.put("areaFromInclude", areaFromInclude);
			map.put("areaFromExclude", areaFromExclude);
			map.put("lastUpdatedBy", OptionalUtil.getValue(sirsRates.getLastUpdatedBy()));
			map.put("createdBy", OptionalUtil.getValue(sirsRates.getLastUpdatedBy()));
			map.put("userFromArea", OptionalUtil.getValue(sirsRates.getFromArea()).substring(1));
			map.put("updateFlag", updateFlag.toString());
			if (OptionalUtil.getValue(sirsRates.getFromArea()).startsWith("4")) {
				userAreaController.clientSpecificUserAreaInsertOrUpdate(map);
			}
			if (OptionalUtil.isPresent(sirsRates.getToArea())) {
				map.put("areaToInclude", areaToInclude);
				map.put("areaToExclude", areaToExclude);
				map.put(USER_FROM_AREA_NAME, sirsRates.getUserToAreaName());
				map.put("userToArea", OptionalUtil.getValue(sirsRates.getToArea()).substring(1));
			}
			try {
				if ((OptionalUtil.isPresent(sirsRates.getToArea())
						&& OptionalUtil.getValue(sirsRates.getToArea()).startsWith("4"))) {
					if (!(sirsRates.getToArea().equals(Optional.ofNullable(" ")))) {
						userAreaController.clientSpecificUserAreaInsertOrUpdate(map);
					}
				}
			} catch (DataIntegrityViolationException e) {
				log.error("context ", e);
			}
		}
		return sirsRateRecord;
	}

	@Override
	public SIRSRates getSIRSRatesBySIRSRatesId(Integer sirsRateId) {
		return sirsRatesMapper.mapToModel(sirsRatesDao.findById(sirsRateId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sirsRateId))));
	}

	@Override
	public List<SIRSRates> getAllSIRSRates(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> globalRegion) {
		return sirsRatesMapper.mapToModel(sirsRatesDao.search(effectiveFromDate, effectiveToDate, globalRegion));
	}

	@Override
	public void deactivateSIRSRates(Integer sirsRateId, String lastUpdatedBy) {
		Optional<SIRSRatesEntity> sirsRatesEntity = sirsRatesDao.findById(sirsRateId);
		if (!sirsRatesEntity.isPresent()) {
			throw new RecordNotFoundException(String.valueOf(sirsRateId));
		}

		if (lastUpdatedBy.length() > 15) {
			throw new ServiceException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}
		if (!sirsRatesEntity.get().getActivate())
			throw new BusinessException(INACTIVE_FOP);

		sirsRatesEntity.get().setActivate(Boolean.FALSE);
		sirsRatesEntity.get().setLastUpdatedBy(lastUpdatedBy);
		sirsRatesEntity.get().setLastUpdatedDate(LocalDateTime.now());
		sirsRatesDao.update(sirsRatesEntity.get());
	}

	@Override
	public void activateSIRSRates(Integer sirsRateId, String lastUpdatedBy) {
		Optional<SIRSRatesEntity> sirsRatesEntity = sirsRatesDao.findById(sirsRateId);
		if (!sirsRatesEntity.isPresent()) {
			throw new RecordNotFoundException(String.valueOf(sirsRateId));
		}
		if (lastUpdatedBy.length() > 15) {
			throw new ServiceException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}
		if (sirsRatesEntity.get().getActivate())
			throw new BusinessException(ACTIVE_FOP);

		sirsRatesEntity.get().setActivate(Boolean.TRUE);
		sirsRatesEntity.get().setLastUpdatedBy(lastUpdatedBy);
		sirsRatesEntity.get().setLastUpdatedDate(LocalDateTime.now());

		sirsRatesDao.update(sirsRatesEntity.get());

	}

	// validate EffectiveDate
	protected void validateEffectiveToDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "] should be greater than Effective From date[" + effectiveFromDate + "]");
		}
	}

	// Validate Global Region in LOV
	private void validateGlobalRegion(SIRSRates sirsRates) {
		if (OptionalUtil.isPresent(sirsRates.getGlobalRegion())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, TABLENAME,
					GLOBAL_REGION_LOV_COLUMN_VALUE);

			if (!(listOfValues.contains(OptionalUtil.getValue(sirsRates.getGlobalRegion())))) {
				throw new BusinessException(
						"Global Region[" + OptionalUtil.getValue(sirsRates.getGlobalRegion()) + "] is Not Valid");
			}
		}
	}

	// Validate GeoAreaIndicator in LOV
	private void validateGeoAreaIndicator(SIRSRates sirsRates) {

		if (OptionalUtil.isPresent(sirsRates.getGeoAreaIndicator())) {
			if (OptionalUtil.getValue(sirsRates.getGeoAreaIndicator()).equalsIgnoreCase("B")) {
				if ((!OptionalUtil.isPresent(sirsRates.getToArea()))
						|| (OptionalUtil.getValue(sirsRates.getToArea()).trim().isEmpty())) {
					throw new BusinessException("Please provide To Area");
				}
			}
		}
		if (OptionalUtil.getValue(sirsRates.getGeoAreaIndicator()).equalsIgnoreCase("w")) {
			if (OptionalUtil.isPresent(sirsRates.getToArea())) {
				throw new BusinessException("When Geo Area Indicator is 'W' ,Only 'From Area' captured.");
			}
		}
		if (OptionalUtil.isPresent(sirsRates.getGeoAreaIndicator())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, TABLENAME,
					GEO_AREA_INDICATOR_LOV_COLUMN_VALUE);
			if (!(listOfValues.contains(OptionalUtil.getValue(sirsRates.getGeoAreaIndicator())))) {
				throw new BusinessException("Geo Area Indicator["
						+ OptionalUtil.getValue(sirsRates.getGeoAreaIndicator()) + "] is Not Valid");
			}
		} else {
			if (!OptionalUtil.isPresent(sirsRates.getToArea())) {
				sirsRates.setToArea(Optional.ofNullable(" "));
			}
		}
	}

	// validate AreaFrom To Airport Master private void
	private void validateAreaFromToAirport(SIRSRates sirsRates) {
		if (OptionalUtil.isPresent(sirsRates.getFromArea())) {
			String substring = OptionalUtil.getValue(sirsRates.getFromArea()).substring(1);
			Airport airportByAirportCode = airportController.getAirportByAirportCode(substring);
			if (!(substring.equalsIgnoreCase(OptionalUtil.getValue(airportByAirportCode.getAirportCode())))) {
				throw new BusinessException(VALID_FROM_AREA);
			}

		}
	}

	// validate AreaFrom To Country Master
	private void validateAreaFromToCountry(SIRSRates sirsRates) {
		String substring = OptionalUtil.getValue(sirsRates.getFromArea()).substring(1);
		Country countryByCountryCode = countryController.getCountryByCountryCode(substring);
		if (!(countryByCountryCode.getCountryCode().contains(substring))) {
			throw new BusinessException(VALID_FROM_AREA);
		}
	}

	// Validate AreaFrom To StateCode
	private void validateAreaFromToStateCode(SIRSRates sirsRates) {
		String substring = OptionalUtil.getValue(sirsRates.getFromArea()).substring(1);
		boolean validStateCode = airportController.isValidStateCode(substring);
		if (!(validStateCode)) {
			throw new BusinessException(VALID_FROM_AREA);
		}

	}

	// validate AreaFrom To StandardAreaCode
	private void validateAreaFromToStandardArea(SIRSRates sirsRates) {
		String substring = OptionalUtil.getValue(sirsRates.getFromArea()).substring(1);
		if(standardArea.getActiveStandardAreaByStandardAreaCode(substring)) {
			StandardArea standardAreaCode = standardArea.getStandardAreaByStandardAreaCode(substring);
			if (!(standardAreaCode.getStandardAreaCode().contains(substring))) {
				throw new BusinessException(VALID_FROM_AREA);
			}
		} else {
			throw new BusinessException(VALID_FROM_AREA);
		}
	}

	// Validate OverLap in Create Service
	private void validateOverLap(SIRSRates sirsRates) {
		if (sirsRatesDao.getOverLapRecordCount(OptionalUtil.getLocalDateValue(sirsRates.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(sirsRates.getEffectiveToDate()),
				OptionalUtil.getValue(sirsRates.getGlobalRegion())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

	// Validate OverLap in Update Service
	private void validateOverlapForUpdate(SIRSRates sirsRates, SIRSRatesEntity sirsRatesEntity) {

		LocalDate effectiveFromDate = getEffectiveFromDate(sirsRates, sirsRatesEntity);
		LocalDate effectiveToDate = getEffectiveToDate(sirsRates, sirsRatesEntity);
		String globalRegion = getGlobalRegion(sirsRates, sirsRatesEntity);

		if (!globalRegion.equalsIgnoreCase(sirsRatesEntity.getGlobalRegion())
				|| !effectiveFromDate.isEqual(sirsRatesEntity.getEffectiveFromDate())
				|| !effectiveToDate.isEqual(sirsRatesEntity.getEffectiveToDate())) {
			if (sirsRatesDao.getOverLapRecordCount(effectiveFromDate, effectiveToDate, globalRegion,
					sirsRatesEntity.getSirsRateId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private String getGlobalRegion(SIRSRates sirsRates, SIRSRatesEntity sirsRatesEntity) {
		return OptionalUtil.isPresent(sirsRates.getGlobalRegion()) ? OptionalUtil.getValue(sirsRates.getGlobalRegion())
				: sirsRatesEntity.getGlobalRegion();
	}

	private LocalDate getEffectiveFromDate(SIRSRates sirsRates, SIRSRatesEntity sirsRatesEntity) {
		return OptionalUtil.isPresent(sirsRates.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(sirsRates.getEffectiveFromDate())
				: sirsRatesEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(SIRSRates sirsRates, SIRSRatesEntity sirsRatesEntity) {
		return OptionalUtil.isPresent(sirsRates.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(sirsRates.getEffectiveToDate())
				: sirsRatesEntity.getEffectiveToDate();
	}

	private StringBuilder userGeoList(List<Geo> l, StringBuilder geoString, boolean flag) {

		typeValueList = new ArrayList<>();
		for (Geo geo : l) {

			if (geo.getGeoTypeId() == null)
				throw new ServiceException("Geo Type Id should be 1,2,3 or 5 ");
			if (geo.getGeoTypeId() == 1 || geo.getGeoTypeId() == 2 || geo.getGeoTypeId() == 3
					|| geo.getGeoTypeId() == 5) {

				if (geo.getGeoTypeId() == 1
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new ServiceException(
									"Geo Type Value should be maximum of 3 characters for  Airport/City Code");
						}
					} else {
						typeValueList.clear();
						throw new ServiceException(MANDATORYGEOTYPEVALUE);
					}
					if (!airportController.isValidAirportCodeOrCityCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. Airport/City Code : "
								+ geo.getGeoTypeValue().toUpperCase() + "Does not exist or not active");
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 2
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 2) {
							typeValueList.clear();
							throw new ServiceException(
									"Geo Type Value should be maximum of 2 characters for Country Code");
						}
					} else {
						typeValueList.clear();
						throw new ServiceException(MANDATORYGEOTYPEVALUE);
					}
					try {
						countryController.getCountryByCountryCode(geo.getGeoTypeValue().toUpperCase());
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. Country Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					} catch (ServiceException se) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. Country Code :"
								+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 3
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (flag) {
						typeValueList.clear();
						throw new ServiceException("Geo Type Id 3 is not applicable for Exclude Geo List");
					}
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new ServiceException(
									"Geo Type Value should be maximum of 3 characters for Standard Area Code");
						}
					} else {
						typeValueList.clear();
						throw new ServiceException(MANDATORYGEOTYPEVALUE);
					}
					try {
						if (!standardArea.getActiveStandardAreaByStandardAreaCode(geo.getGeoTypeValue().toUpperCase())) {
							typeValueList.clear();
							throw new ServiceException("Invalid Geo Type Value. Standard Area Code : "
									+ geo.getGeoTypeValue().toUpperCase());
						}
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. Standard Area Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					} catch (ServiceException se) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. Standard Area Code :"
								+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 5
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 4) {
							typeValueList.clear();
							throw new ServiceException(
									"Geo Type Value should be maximum of 4 characters for State Code");
						}
					} else {
						typeValueList.clear();
						throw new ServiceException(MANDATORYGEOTYPEVALUE);
					}
					if (!airportController.isValidStateCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new ServiceException("Invalid Geo Type Value. State Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST + " or" + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					typeValueList.clear();
					throw new ServiceException("Duplicate Geo Type Value: " + geo.getGeoTypeValue().toUpperCase());
				}

			} else {
				typeValueList.clear();
				throw new ServiceException(
						"Invalid Geo Type id :" + geo.getGeoTypeId() + " Only 1,2,3,5 are the valid Geo type id ");
			}

		} // enf of for loop
		if (geoString.length() > 1000) {
			typeValueList.clear();
			throw new ServiceException(
					"area_include_list or area_exclude_list length must be less than 1000 charecters");
		}
		if (geoString.length() != 0) {
			geoString.delete(geoString.length() - 1, geoString.length());
		}
		return geoString;

	}

	private String[] validateArea(Optional<String> geoArea, List<Geo> fromAreaInclude, List<Geo> fromAreaExclude,
			String userFromAreaName, String area) {
		String[] array = new String[2];
		String areaInclude = "";
		String areaExclude = "";
		if (OptionalUtil.isPresent(geoArea)) {
			if (OptionalUtil.getValue(geoArea).startsWith("1")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new ServiceException(AIRPORTCITY);
				} else {
					if (!airportController.isValidAirportCodeOrCityCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new ServiceException(AIRPORTCITYINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("2")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new ServiceException(COUNTRYCODEALPHA);
				} else {
					if (!countryController.validateCountryCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new ServiceException(COUNTRYCODEINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("3")) {
				if (!standardArea.getActiveStandardAreaByStandardAreaCode(
						OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
					throw new ServiceException(INVALIDSTDAREACODE
							+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("4") && area.equals("global")) {

				boolean flag = false;
				List<Geo> geoFromAreaInclude = fromAreaInclude;
				if (fromAreaInclude != null && !fromAreaInclude.isEmpty()) {

					if (userFromAreaName == null) {
						throw new ServiceException("Please provide User Area Name");
					}

					StringBuilder geoString = new StringBuilder();
					StringBuilder strareaIncludeList = userGeoList(geoFromAreaInclude, geoString, flag);
					areaInclude = strareaIncludeList.toString();
					if (fromAreaExclude != null) {
						List<Geo> geoFromAreaExclude = fromAreaExclude;
						StringBuilder geoString1 = new StringBuilder();
						flag = true;
						StringBuilder strAreaExcludeList = userGeoList(geoFromAreaExclude, geoString1, flag);

						areaExclude = strAreaExcludeList.toString();
					}
					array[0] = areaInclude;
					array[1] = areaExclude;

				} else {
					throw new ServiceException(FROMAREAINCLUDEMENDATORY);
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("4") && area.equals(CLIENT)) {
				boolean flag = false;
				List<Geo> geoFromAreaInclude = fromAreaInclude;
				if (fromAreaInclude != null && !fromAreaInclude.isEmpty()) {

					if (userFromAreaName == null) {
						throw new ServiceException("Please provide User Area Name");
					}

					StringBuilder geoString = new StringBuilder();
					StringBuilder strareaIncludeList = userGeoList(geoFromAreaInclude, geoString, flag);
					areaInclude = strareaIncludeList.toString();
					if (fromAreaExclude != null) {
						List<Geo> geoFromAreaExclude = fromAreaExclude;
						StringBuilder geoString1 = new StringBuilder();
						flag = true;
						StringBuilder strAreaExcludeList = userGeoList(geoFromAreaExclude, geoString1, flag);

						areaExclude = strAreaExcludeList.toString();
					}
					array[0] = areaInclude;
					array[1] = areaExclude;

				} else {
					throw new ServiceException(FROMAREAINCLUDEMENDATORY);
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("5")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new ServiceException(STATECODEALPHA);
				} else {
					if (!airportController.isValidStateCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new ServiceException(INVALIDSTATECODE
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			}
		}

		return array;
	}

	private List<String> typeValueList = null;

	private void commonValidation(SIRSRates sirsRates) {

		if (OptionalUtil.isPresent(sirsRates.getSirsPercentage())) {
			validateSirsPercentage(sirsRates.getSirsPercentage());
		}

		// Geo AREA Indicator validation
		if (OptionalUtil.isPresent(sirsRates.getGeoAreaIndicator())) {
			if (!(OptionalUtil.getValue(sirsRates.getGeoAreaIndicator()).equalsIgnoreCase("B")
					|| (OptionalUtil.getValue(sirsRates.getGeoAreaIndicator()).equalsIgnoreCase("W")))) {
				throw new BusinessException(GEO_AREA_INDICATOR);
			}
		}
		if (OptionalUtil.isPresent(sirsRates.getGeoAreaIndicator())) {
			if (OptionalUtil.getValue(sirsRates.getGeoAreaIndicator()).equalsIgnoreCase("W")
					&& OptionalUtil.isPresent(sirsRates.getToArea())) {
				throw new BusinessException(AREA_INDICATOR);
			}

		}
		// validation for fromArea and ToArea
		if (OptionalUtil.isPresent(sirsRates.getFromArea())) {
			if (OptionalUtil.isPresent(sirsRates.getFromArea())) {
				String[] fromAreaArray = OptionalUtil.getValue(sirsRates.getFromArea()).split("");
				if (!(fromAreaArray[0].startsWith("1") || fromAreaArray[0].startsWith("2")
						|| fromAreaArray[0].startsWith("3") || fromAreaArray[0].startsWith("4")
						|| fromAreaArray[0].startsWith("5"))) {
					throw new ServiceException(INVALIDFROMAREA + fromAreaArray[0]);
				}
			}
			if (OptionalUtil.isPresent(sirsRates.getToArea())) {
				if (OptionalUtil.isPresent(sirsRates.getToArea())) {
					String[] toAreaArray = OptionalUtil.getValue(sirsRates.getToArea()).split("");
					if (!(toAreaArray[0].startsWith("1") || toAreaArray[0].startsWith("2")
							|| toAreaArray[0].startsWith("3") || toAreaArray[0].startsWith("4")
							|| toAreaArray[0].startsWith("5"))) {
						throw new ServiceException(INVALIDTOAREA + toAreaArray[0]);
					}
				}
			}
		}

	}

	private void validateSirsPercentage(Optional<String> sirsPercentage) {
		if (OptionalUtil.isPresent(sirsPercentage)) {
			Pattern digitPattern = Pattern.compile(REGEX_PATTERN_AVERAGE);
			if (!digitPattern.matcher(OptionalUtil.getValue(sirsPercentage)).matches()) {
				throw new BusinessException("Invalid SIRS Percentage " + OptionalUtil.getValue(sirsPercentage));
			}
		}

	}

	@Override
	public List<SIRSRates> getAllSIRSRatesDate(String dateString) {
		LocalDate effectiveDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if (dateString != null) {
			try {
				effectiveDate = Instant.ofEpochMilli(sdf.parse(dateString).getTime()).atZone(ZoneId.systemDefault())
						.toLocalDate();
			} catch (ParseException e) {
				log.error("context ", e);
			}
		}
		return sirsRatesMapper.mapToModel(sirsRatesDao.getAllSIRSRatesDates(effectiveDate));
	}

	private void bussinesValidation(SIRSRates sirsRates) {
		if (OptionalUtil.getValue(sirsRates.getFromArea()).startsWith("1")) {
			validateAreaFromToAirport(sirsRates);
		}
		if (OptionalUtil.getValue(sirsRates.getFromArea()).startsWith("2")) {
			validateAreaFromToCountry(sirsRates);
		}
		if (OptionalUtil.getValue(sirsRates.getFromArea()).startsWith("5")) {
			validateAreaFromToStateCode(sirsRates);
		}
		if (OptionalUtil.getValue(sirsRates.getFromArea()).startsWith("3")) {
			validateAreaFromToStandardArea(sirsRates);
		}
	}

	private void validateBusinessConstraintsForUpdate(SIRSRates sirsRates, SIRSRatesEntity sirsEntity) {
		validateEffectiveToDate(getEffectiveToDate(sirsRates, sirsEntity), getEffectiveFromDate(sirsRates, sirsEntity));
	}

	@Override
	public SIRSRatesResponse getAllSIRSRates(Pageable pageable, SIRSRates sirsRates) {
		SIRSRatesResponse sirsRatesResponse = new SIRSRatesResponse();
		sirsRatesResponse.setTotalCount(sirsRatesDao.getCount(sirsRatesMapper.mapToEntity(sirsRates)));
		Page<SIRSRatesEntity> allSIRSRates = sirsRatesDao.getAllSIRSRates(sirsRatesMapper.mapToEntity(sirsRates),
				pageable);
		sirsRatesResponse.setData(sirsRatesMapper.mapToModel(allSIRSRates.getContent()));
		return sirsRatesResponse;
	}

}
