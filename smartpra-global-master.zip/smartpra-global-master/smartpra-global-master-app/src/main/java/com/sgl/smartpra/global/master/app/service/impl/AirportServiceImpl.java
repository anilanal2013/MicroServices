package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.controller.AirportController;
import com.sgl.smartpra.global.master.app.dao.AirportDao;
import com.sgl.smartpra.global.master.app.dao.entity.AirportEntity;
import com.sgl.smartpra.global.master.app.dao.impl.AirportDaoImpl;
import com.sgl.smartpra.global.master.app.dao.repository.AirportRepository;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.AirportMapper;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.AirportResponse;
import com.sgl.smartpra.global.master.model.CommonIdName;

@Service
@Transactional
public class AirportServiceImpl implements AirportService {

	@Autowired
	AirportMapper airportmapper;

	@Autowired
	AirportDao airportDao;

	@Autowired
	AirportDaoImpl airportDaoImpl;

	@Autowired
	private AirportRepository airportRepository;

	@Autowired
	AirportController airportControler;

	@Autowired
	private CountryService countryService;

	private static final String DUPLICATE_AIRPORT = "Record already exists";
	private static final String INACTIVE_AIRPORT = "Given Airport Code is not active";
	private static final String ACTIVE_AIRPORT = "Given Airport Code is already active";
	private static final String STATE_CODE = "";

	@Override
	public List<Airport> getAllAirport(Optional<String> airportCode, Optional<String> airportName,
			Optional<String> cityCode, Optional<String> cityName, Optional<String> countryCode) {

		return airportmapper
				.mapToModel(airportDao.searchAll(airportCode, airportName, cityCode, cityName, countryCode));
	}

	@Override
	public Airport findAirportByAirportCode(String airportCode) {
		return airportmapper.mapToModel(airportDao.findById(airportCode)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(airportCode))));
	}

	public Airport createAirport(Airport airport) {

		Optional<AirportEntity> airportEntity = airportDao.findById(OptionalUtil.getValue(airport.getAirportCode()));
		if (airportEntity.isPresent()) {
			throw new BusinessException(DUPLICATE_AIRPORT);
		}
		validateEmptyFile(airport);
		if (OptionalUtil.isPresent(airport.getStateCode())) {
			try {
				countryService.getCountryByCountryCode(OptionalUtil.getValue(airport.getCountryCode()));
			} catch (ResourceNotFoundException rnfe) {
				throw new RecordNotFoundException(OptionalUtil.getValue(airport.getCountryCode()));
			} catch (BusinessException se) {
				throw new BusinessException("Invalid Country Code " + OptionalUtil.getValue(airport.getCountryCode()));
			}
		}
		airport.setIsActive(Boolean.TRUE);
		airport.setCreatedDate(LocalDateTime.now());
		return airportmapper.mapToModel(airportDao.create(airportmapper.mapToEntity(airport)));
	}

	public Airport updateAirport(Airport airport) {

		AirportEntity airportEntity = airportDao.findById(OptionalUtil.getValue(airport.getAirportCode()))
				.orElseThrow(() -> new RecordNotFoundException(OptionalUtil.getValue(airport.getAirportCode())));
		if (!airportEntity.getIsActive()) {
			throw new BusinessException("Invalid Airport Code " + OptionalUtil.getValue(airport.getAirportCode()));
		}
		getStateCode(airport, airportEntity);
		getEuVatExempted(airport, airportEntity);
		if (OptionalUtil.isPresent(airport.getStateCode())) {
			try {
				countryService.getCountryByCountryCode(OptionalUtil.getValue(airport.getCountryCode()));
			} catch (ResourceNotFoundException rnfe) {
				throw new RecordNotFoundException(OptionalUtil.getValue(airport.getCountryCode()));
			} catch (BusinessException se) {
				throw new BusinessException("Invalid Country Code " + OptionalUtil.getValue(airport.getCountryCode()));
			}
		}
		airport.setLastUpdatedDate(LocalDateTime.now());
		return airportmapper.mapToModel(airportDao.update(airportmapper.mapToEntity(airport, airportEntity)));
	}

	public void deactivateAirport(String airportCode, String lastUpdatedBy) {
		AirportEntity airportEntity = airportDao.findById(airportCode)
				.orElseThrow(() -> new RecordNotFoundException(airportCode));

		if (!airportEntity.getIsActive())
			throw new BusinessException(INACTIVE_AIRPORT);

		airportEntity.setIsActive(Boolean.FALSE);
		airportEntity.setLastUpdatedBy(lastUpdatedBy);
		airportEntity.setLastUpdatedDate(LocalDateTime.now());

		airportDao.update(airportEntity);

	}

	public void activateAirport(String airportCode, String lastUpdatedBy) {
		AirportEntity airportEntity = airportDao.findById(airportCode)
				.orElseThrow(() -> new RecordNotFoundException(airportCode));

		if (airportEntity.getIsActive())
			throw new BusinessException(ACTIVE_AIRPORT);

		airportEntity.setIsActive(Boolean.TRUE);
		airportEntity.setLastUpdatedBy(lastUpdatedBy);
		airportEntity.setLastUpdatedDate(LocalDateTime.now());

		airportDao.update(airportEntity);
	}

	public boolean isValidAirportCodeOrCityCode(String airportOrCityCode) {
		Optional<String> code = Optional.of(airportOrCityCode);

		if (OptionalUtil.isEmpty(code)) {
			code = Optional.of("");
		}

		Optional<AirportEntity> airportEntity = airportDao.isValidAirportCode(code);
		if (airportEntity.isPresent()) {
			return true;
		} else {
			List<AirportEntity> cityEntity = airportDao.isValidCityCodeList(code);
			if (cityEntity.isEmpty()) {
				return false;
			} else {
				return true;
			}
		}

	}
	
	public boolean isValidAirportCode(String airportOrCityCode) {
		Optional<String> code = Optional.of(airportOrCityCode);
		if (OptionalUtil.isEmpty(code)) {
			code = Optional.of("");
		}
		List<AirportEntity> airportEntity = airportDao.isValidAirportCodeList(code);
		return !airportEntity.isEmpty();
	}
	
	public boolean isValidCityCode(String airportOrCityCode) {
		Optional<String> code = Optional.of(airportOrCityCode);
		if (OptionalUtil.isEmpty(code)) {
			code = Optional.of("");
		}
		List<AirportEntity> cityEntity = airportDao.isValidCityCodeList(code);
		return !cityEntity.isEmpty();
	}

	public boolean isValidStateCode(String stateCode) {

		Optional<String> code = Optional.of(stateCode);

		if (OptionalUtil.isEmpty(code)) {
			code = Optional.of("");
		}

		List<AirportEntity> airportEntity = airportDao.isValidStateCode(code);
		return !airportEntity.isEmpty();

	}

	public List<Airport> findCityByAirportCode(String airportCode) {
		Optional<AirportEntity> listOfAirportCode = airportRepository.findById(airportCode);
		String cityCode = null;
		if (listOfAirportCode.isPresent() && listOfAirportCode.get().getIsActive()) {
			cityCode = listOfAirportCode.get().getCityCode();
		} else {
			cityCode = airportCode;
		}
		return airportmapper.mapToModel(airportRepository.findByCityCode(cityCode));
	}

	@Override
	public List<CommonIdName> getAirportList() {
		List<CommonIdName> airportList = new ArrayList<>();
		List<AirportEntity> listOfAirports = airportRepository
				.findDistinctByAirportCodeIsNotNullAndIsActiveTrueOrderByAirportCode();
		for (AirportEntity objAirport : listOfAirports) {
			CommonIdName airport = new CommonIdName();
			airport.setId(objAirport.getAirportCode());
			airport.setName(objAirport.getAirportCode() + " - " + objAirport.getAirportName());
			airportList.add(airport);
		}

		return airportList;

	}

	@Override
	public List<CommonIdName> getCityList() {
		List<CommonIdName> cityList = new ArrayList<>();
		List<AirportEntity> listOfAirports = airportRepository
				.findDistinctByCityCodeIsNotNullAndIsActiveTrueOrderByCityCode();
		for (AirportEntity objAirport : listOfAirports) {
			CommonIdName city = new CommonIdName();
			city.setId(objAirport.getCityCode());
			city.setName(objAirport.getCityCode() + " - " + objAirport.getCityName());
			cityList.add(city);
		}
		return cityList;
	}

	@Override
	public List<CommonIdName> getStateList() {
		List<CommonIdName> stateList = new ArrayList<>();
		List<AirportEntity> listOfAirports = airportRepository
				.findDistinctByStateCodeIsNotNullAndIsActiveTrueOrderByStateCode();
		for (AirportEntity objAirport : listOfAirports) {
			CommonIdName state = new CommonIdName();
			state.setId(objAirport.getStateCode());
			stateList.add(state);
		}
		return stateList;
	}

	@Override
	public AirportResponse findAll(Airport airport, Optional<String> exceptionCall, Pageable pageable) {
		AirportResponse airportResponse = new AirportResponse();

		Page<AirportEntity> airportEntitypage = airportDao.findAll(airportmapper.mapToEntity(airport), exceptionCall, pageable);
		airportResponse.setTotalCount(airportDao.getCount(airportmapper.mapToEntity(airport), exceptionCall));
		airportResponse.setData(airportmapper.mapToModel(airportEntitypage.getContent()));
		return airportResponse;
	}

	@Override
	public String findCountryCodeByAirportCodeOrCityCode(String airportCode) {
		Optional<AirportEntity> listOfAirportCode = airportRepository.findById(airportCode);
		String countryCode = null;
		if (listOfAirportCode.isPresent() && listOfAirportCode.get().getIsActive()) {
			countryCode = listOfAirportCode.get().getCountryCode();
		} else {
			List<AirportEntity> listOfCityCode = airportRepository.findByCityCode(airportCode);
			if (!listOfCityCode.isEmpty() && listOfCityCode.size() > 1) {
				countryCode = listOfCityCode.get(0).getCountryCode();
			}
		}
		return countryCode;
	}

	public void validateEmptyFile(Airport airport) {
		if (!OptionalUtil.isPresent(airport.getStateCode())) {
			airport.setStateCode(Optional.ofNullable(STATE_CODE));
		}
		if (!OptionalUtil.isPresent(airport.getEuVatExempted())) {
			airport.setEuVatExempted(Optional.ofNullable(STATE_CODE));
		}
	}

	private String getStateCode(Airport airport, AirportEntity airportEntity) {
		return OptionalUtil.isPresent(airport.getStateCode()) ? OptionalUtil.getValue(airport.getStateCode())
				: airportEntity.getStateCode();
	}

	private String getEuVatExempted(Airport airport, AirportEntity airportEntity) {
		return OptionalUtil.isPresent(airport.getEuVatExempted()) ? OptionalUtil.getValue(airport.getEuVatExempted())
				: airportEntity.getEuVatExempted();
	}

	@Override
	public List<Airport> getAirportByCityOrStateOrCountry(Optional<String> airportCode, Optional<String> stateCode,
			Optional<String> cityCode, Optional<String> countryCode) {
		return airportmapper
				.mapToModel(airportDao.searchByCityOrStateOrCountry(airportCode, stateCode, cityCode, countryCode));
	}

	@Override
	public String getTicketTravelDetail(List<String> airportCodes) {
		List<String> countryCodes = new ArrayList<>();
		airportCodes.stream().forEach( codes-> { 
			
			Optional<AirportEntity> airport= airportDao.isValidAirportCode(Optional.of(codes));
			if (airport.isPresent()) {
				countryCodes.add(airport.get().getCountryCode());
			}
		});
		Long count = countryCodes.stream().distinct().count();
		
		if(count > 1) {
			return "International";
		} else {
			return "Domestic";
		}
	}

}
