package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.Country;

@RestController
public class CountryController {

	@Autowired
	private CountryService countryService;

	@PostMapping("/countries")
	public Country createCountry(@Validated(Create.class) @RequestBody Country country) {

		return countryService.createCountry(country);

	}

	@GetMapping("/countries")
	public List<Country> getListOfCountries(@RequestParam(value = "countryCode", required = false) String countryCode,
			@RequestParam(value = "countryName", required = false) String countryName) {
		return countryService.getListOfCountries(countryCode, countryName);

	}
	
	@GetMapping("/countries/list")
	public List<Country> getListOfCountriesByIsActive(@RequestParam(value = "countryCode", required = false) Optional<String> countryCode,
			@RequestParam(value = "countryName", required = false) Optional<String> countryName,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return countryService.getListOfCountriesByIsActive(countryCode, countryName, activate);

	}

	@GetMapping("/countries/{countryCode}")
	public Country getCountryByCountryCode(@PathVariable(value = "countryCode") String countryCode) {

		return countryService.getCountryByCountryCode(countryCode);
	}

	@PutMapping("/countries/{countryCode}")
	public Country updateCountry(@PathVariable(value = "countryCode") String countryCode,
			@Validated(Update.class) @RequestBody Country country) {		
		return countryService.updateCountry(country,countryCode);

	}

	@PutMapping("/countries/{countryCode}/deactivate")
	public void deactivateCountry(@PathVariable(value = "countryCode") String countryCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		Country country= new Country();
		country.setCountryCode(countryCode);
		country.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));		
		countryService.deactivateCountry(country);
	}

	@PutMapping("/countries/{countryCode}/activate")
	public void activateCountry(@PathVariable(value = "countryCode") String countryCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		Country country= new Country();
		country.setCountryCode(countryCode);
		country.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));		
		countryService.activateCountry(country);

	}
	
	
	@GetMapping("/countries/validate/{countryCode}")
	public boolean validateCountryCode(@PathVariable(value = "countryCode") String countryCode) {
		return countryService.isValidCountryCode(countryCode);
	}
	
	
	@PostMapping("/countries/validate")
	public List<String> getValidateCountryCodeList(@RequestBody List<String> countryCodeList) {
		return countryService.getValidatedCountryCodeList(countryCodeList);
	}
	
	@GetMapping("/countries/country-list")
	public List<CommonIdName> getCountryList() {
		return countryService.getCountryList();
	}
	
	

}
