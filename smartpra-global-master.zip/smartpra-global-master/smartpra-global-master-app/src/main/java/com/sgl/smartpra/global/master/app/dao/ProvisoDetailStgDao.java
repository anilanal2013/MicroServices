package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailStgEntity;

@Repository
public interface ProvisoDetailStgDao {
	ProvisoDetailStgEntity create(ProvisoDetailStgEntity provisoDetailStgEntity);

	List<ProvisoDetailStgEntity> findByMainId(Optional<Integer> provisoMainId);

	Optional<ProvisoDetailStgEntity> findById(Integer id);

	List<ProvisoDetailStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);

	ProvisoDetailStgEntity update(ProvisoDetailStgEntity provisoDetailStgEntity);

	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer detailRecNumber);

	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer detailRecNumber,
			Integer provisoDetailId);

	public List<ProvisoDetailStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> fbGroupCode);

	public List<Integer> getListOfProvisoMainIdFromDetailStgDb();

	void deleteProvisoDetailByProvisoMainId(Integer provisoMainId);

	void deleteProvisoDetailByProvisoDetailId(Integer provisoDetailId);

	public Integer getMaxOfProvisoDetailRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);

}
