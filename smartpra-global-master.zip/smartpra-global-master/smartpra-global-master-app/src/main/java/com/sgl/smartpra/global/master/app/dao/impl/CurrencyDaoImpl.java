package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.configuration.CacheManage;
import com.sgl.smartpra.global.master.app.dao.CurrencyDao;
import com.sgl.smartpra.global.master.app.dao.entity.CurrencyEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.CurrencyEntitySpecification;
import com.sgl.smartpra.global.master.app.repository.CurrencyRepository;
import com.sgl.smartpra.global.master.model.Currency;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CurrencyDaoImpl extends CommonSearchDao<Currency> implements CurrencyDao {

	@Autowired
	private CurrencyRepository currencyRepository;
	
	@Override
	@Cacheable(value = "currency", key = "#id")
	public Optional<CurrencyEntity> findById(String id) {
		log.info("Cacheable Fares Entity's ID= {}", id);
		return currencyRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "currency", key = "#currencyEntity.currencyCode"),
			@CacheEvict(value = "currencyNumericCode", allEntries = true) })
	public CurrencyEntity create(CurrencyEntity currencyEntity) {
		return currencyRepository.save(currencyEntity);
	}

	@Override
	@CachePut(value = "currency", key = "#currencyEntity.currencyCode")
	@CacheEvict(value = "currencyNumericCode", allEntries = true)
	public CurrencyEntity update(CurrencyEntity currencyEntity) {
		return currencyRepository.save(currencyEntity);
	}

	@Override
	public List<CurrencyEntity> getAllCurrency(Optional<String> currencyCode, Optional<String> currencyName,
			Optional<Boolean> isActive) {
		return currencyRepository.findAll(CurrencyEntitySpecification.search(currencyCode, currencyName, isActive));
	}

	@Override
	public long validateNumericCode(Integer currencyNumericCode) {
		return currencyRepository
				.count(Specification.where(CurrencyEntitySpecification.equalsCurrencyNumericCode(currencyNumericCode)));
	}

	@Override
	public long validateNumericCodeForUpdate(Integer currencyNumericCode, String currencyCode) {
		return currencyRepository
				.count(Specification.where(CurrencyEntitySpecification.equalsCurrencyNumericCode(currencyNumericCode))
						.and(CurrencyEntitySpecification.notEqualsCurrencyCode(currencyCode)));
	}

	@Override
	public List<CurrencyEntity> findDistinctByCurrencyCodeIsNotNullAndIsActiveTrueOrderByCurrencyCode() {
		return currencyRepository.findDistinctByCurrencyCodeIsNotNullAndIsActiveTrueOrderByCurrencyCode();
	}

	@Override
	@Cacheable(cacheNames={"currencyNumericCode"})
	public Optional<CurrencyEntity> getCurrencyByCurrencyNumericCode(Integer currencyNumericCode) {
		return currencyRepository.findOne(CurrencyEntitySpecification.equalsCurrencyNumericCode(currencyNumericCode)
				.and(CurrencyEntitySpecification.isActive(Boolean.TRUE)));
	}
}
