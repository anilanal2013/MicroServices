package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.global.master.app.repository.entity.ProvisioBaseAmountEntity;

public class ProvisioBaseAmountEntitySpec {

	private static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";
	private static final String EFFECTIVE_TO_DATE = "effectiveToDate";

	public static Specification<ProvisioBaseAmountEntity> search(String fromCityCode, String toCityCode,
			String carrierCode, Boolean activate) {
		return (provisioBaseAmountEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (fromCityCode != null) {
				predicates.add(criteriaBuilder.like(provisioBaseAmountEntity.get("fromCityCode"), fromCityCode));
			}
			if (toCityCode != null) {
				predicates.add(criteriaBuilder.like(provisioBaseAmountEntity.get("toCityCode"), toCityCode));
			}
			if (carrierCode != null) {
				predicates.add(criteriaBuilder.like(provisioBaseAmountEntity.get("carrierCode"), carrierCode));
			}
			if (activate != null) {
				predicates.add(criteriaBuilder.equal(provisioBaseAmountEntity.get("activate"), activate));
			}
			if (activate == null) {
				predicates.add(criteriaBuilder.equal(provisioBaseAmountEntity.get("activate"), true));
			}
			orderByAsc(provisioBaseAmountEntity, criteriaQuery, criteriaBuilder, EFFECTIVE_TO_DATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private static void orderByAsc(Root<ProvisioBaseAmountEntity> provisioBaseAmountEntity,
			CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder, String effectiveToDate) {
		criteriaQuery.orderBy(criteriaBuilder.asc(provisioBaseAmountEntity.get(effectiveToDate)));
	}

	public static Specification<ProvisioBaseAmountEntity> equalsFromCityCode(String fromCityCode) {
		return (provisioBaseAmountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisioBaseAmountEntity.get("fromCityCode"), fromCityCode);
	}

	public static Specification<ProvisioBaseAmountEntity> equalsToCityCode(String toCityCode) {
		return (provisioBaseAmountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisioBaseAmountEntity.get("toCityCode"), toCityCode);
	}

	public static Specification<ProvisioBaseAmountEntity> equalsCarrierCode(String carrierCode) {
		return (provisioBaseAmountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisioBaseAmountEntity.get("carrierCode"), carrierCode);
	}

	public static Specification<ProvisioBaseAmountEntity> equalsClassCode(String classCode) {
		return (provisioBaseAmountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisioBaseAmountEntity.get("classCode"), classCode);
	}

	public static Specification<ProvisioBaseAmountEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (provisioBaseAmountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), provisioBaseAmountEntity.get(EFFECTIVE_FROM_DATE),
				provisioBaseAmountEntity.get(EFFECTIVE_TO_DATE));
	}

	public static Specification<ProvisioBaseAmountEntity> greaterThanOrEqualTo(LocalDate effectiveFromDate) {
		return (provisioBaseAmountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.greaterThanOrEqualTo(provisioBaseAmountEntity.get(EFFECTIVE_FROM_DATE), effectiveFromDate);
	}

	public static Specification<ProvisioBaseAmountEntity> lessThanOrEqualTo(LocalDate effectiveToDate) {
		return (provisioBaseAmountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.lessThanOrEqualTo(provisioBaseAmountEntity.get(EFFECTIVE_TO_DATE), effectiveToDate);
	}

	public static Specification<ProvisioBaseAmountEntity> notEqualsProvisoBaseid(Integer provisoBaseid) {
		return (provisioBaseAmountEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(provisioBaseAmountEntity.get("provisoBaseid"), provisoBaseid);
	}

}
