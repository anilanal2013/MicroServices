package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareEntity;

public class ProvisoCodeshareEntitySpecification {
	ProvisoCodeshareEntitySpecification() {
	}

	public static Specification<ProvisoCodeshareEntity> search(Optional<Integer> provisoMainId,
			Optional<String> areaFrom, Optional<String> areaTo) {
		return (provisoCodeshareEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}
			if (OptionalUtil.isPresent(areaFrom)) {
				predicates.add(
						criteriaBuilder.equal(provisoCodeshareEntity.get("areaFrom"), OptionalUtil.getValue(areaFrom)));
			}
			if (OptionalUtil.isPresent(areaTo)) {
				predicates.add(
						criteriaBuilder.equal(provisoCodeshareEntity.get("areaTo"), OptionalUtil.getValue(areaTo)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<ProvisoCodeshareEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<String> provisoSection, Optional<String> areaFrom,
			Optional<String> areaTo) {
		return (provisoCodeshareEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			if (OptionalUtil.isPresent(provisoSection)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareEntity.get("provisoSection"),
						OptionalUtil.getValue(provisoSection)));
			}
			if (OptionalUtil.isPresent(areaFrom)) {
				predicates.add(
						criteriaBuilder.equal(provisoCodeshareEntity.get("areaFrom"), OptionalUtil.getValue(areaFrom)));
			}
			if (OptionalUtil.isPresent(areaTo)) {
				predicates.add(
						criteriaBuilder.equal(provisoCodeshareEntity.get("areaTo"), OptionalUtil.getValue(areaTo)));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<ProvisoCodeshareEntity> findByMainId(Optional<Integer> provisoMainId) {
		return (provisoCodeshareEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoCodeshareEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
