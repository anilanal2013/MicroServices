package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sgl.smartpra.global.master.app.repository.entity.ChargeCodeEntity;
import com.sgl.smartpra.global.master.model.ChargeCode;

@Service
public interface ChargeCodeService {

	public ChargeCode createChargeCode(Optional<String> chargeCategoryCode, ChargeCode chargeCodeModel);

	public ChargeCode getChargeCodeByChargeCode(Optional<String> chargeCategoryCode, Optional<String> chargeCode);
	
	public ChargeCode getChargeCodeByChargeCode(Optional<String> chargeCode);

	public List<ChargeCode> getAllChargeCode(Optional<String> chargeCategoryCode, Optional<String> chargeCode,
			Optional<String> chargeCodeName);

	public List<ChargeCodeEntity> updateChargeCode(List<ChargeCode> chargeCodeModel);

	public void deactivateChargeCode(Optional<String> chargeCategoryCode, Optional<String> chargeCode,
			Optional<String> lastUpdatedBy);

	public void activateChargeCode(Optional<String> chargeCategoryCode, Optional<String> chargeCode,
			Optional<String> lastUpdatedBy);

	public List<String> getChargeCodeFromChargeCodeMaster(); 
	


}
