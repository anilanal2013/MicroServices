package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisioBaseAmountDao;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisioBaseAmountEntitySpec;
import com.sgl.smartpra.global.master.app.repository.ProvisioBaseAmountRepository;
import com.sgl.smartpra.global.master.app.repository.entity.ProvisioBaseAmountEntity;

@Component
public class ProvisioBaseAmountDaoImpl implements ProvisioBaseAmountDao {

	@Autowired
	private ProvisioBaseAmountRepository provisioBaseAmountRepository;

	@Override
	public ProvisioBaseAmountEntity createProvisioBaseAmount(ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		return provisioBaseAmountRepository.save(provisioBaseAmountEntity);
	}

	@Override
	public ProvisioBaseAmountEntity updateProvisioBaseAmount(ProvisioBaseAmountEntity provisioBaseAmountEntity) {
		return provisioBaseAmountRepository.save(provisioBaseAmountEntity);
	}

	@Override
	public List<ProvisioBaseAmountEntity> getListOfProvisioBaseAmount(String fromCityCode, String toCityCode,
			String carrierCode, Boolean activate) {

		return provisioBaseAmountRepository
				.findAll(ProvisioBaseAmountEntitySpec.search(fromCityCode, toCityCode, carrierCode, activate));
	}

	@Override
	public List<ProvisioBaseAmountEntity> getOverLapForCreate(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String fromCityCode, String toCityCode, String carrierCode, String classCode) {
		return provisioBaseAmountRepository.findAll(Specification.where(ProvisioBaseAmountEntitySpec
				.equalsFromCityCode(fromCityCode).and(ProvisioBaseAmountEntitySpec.equalsToCityCode(toCityCode))
				.and(ProvisioBaseAmountEntitySpec.equalsCarrierCode(carrierCode))
				.and(ProvisioBaseAmountEntitySpec.equalsClassCode(classCode))
				.and((ProvisioBaseAmountEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProvisioBaseAmountEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
								.or(ProvisioBaseAmountEntitySpec.greaterThanOrEqualTo(effectiveFromDate)
										.and(ProvisioBaseAmountEntitySpec.lessThanOrEqualTo(effectiveToDate))))));
	}

	@Override
	public List<ProvisioBaseAmountEntity> getOverLapForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String fromCityCode, String toCityCode, String carrierCode, String classCode, Integer provisoBaseid) {
		return provisioBaseAmountRepository.findAll(Specification.where(ProvisioBaseAmountEntitySpec
				.equalsFromCityCode(fromCityCode).and(ProvisioBaseAmountEntitySpec.equalsToCityCode(toCityCode))
				.and(ProvisioBaseAmountEntitySpec.equalsCarrierCode(carrierCode))
				.and(ProvisioBaseAmountEntitySpec.equalsClassCode(classCode))
				.and((ProvisioBaseAmountEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(ProvisioBaseAmountEntitySpec.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
								.or(ProvisioBaseAmountEntitySpec.greaterThanOrEqualTo(effectiveFromDate)
										.and(ProvisioBaseAmountEntitySpec.lessThanOrEqualTo(effectiveToDate))))
				.and(ProvisioBaseAmountEntitySpec.notEqualsProvisoBaseid(provisoBaseid))));
	}

	@Override
	public ProvisioBaseAmountEntity getAllProvisioBaseAmountEntity(LocalDate effectiveDate, String fromCityCode,
			String toCityCode, String carrierCode, String classCode) {
		return provisioBaseAmountRepository.getAllProvisioBaseAmountEntity(effectiveDate, fromCityCode, toCityCode,
				carrierCode, classCode);
	}

	@Override
	public Optional<ProvisioBaseAmountEntity> findById(Integer provisioBaseAmountId) {
		return provisioBaseAmountRepository.findById(provisioBaseAmountId);
	}

	@Override
	public ProvisioBaseAmountEntity getProvisoBaseAmount(String fromCityCode, String toCityCode, String classCode,
			String carrierCode, LocalDate date) {
		return provisioBaseAmountRepository.getProvisoBaseAmount(fromCityCode, toCityCode, classCode, carrierCode,
				date);
	}
}
