package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainEntity;

public class ProvisoMainEntitySpecification {
	ProvisoMainEntitySpecification(){
		
	}
	public static Specification<ProvisoMainEntity> search(Optional<String> carrierNumCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> provisoSection,Optional<String> provisoStatus){
		return (provisoMainEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoMainEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSection)) {
				predicates.add(criteriaBuilder.equal(provisoMainEntity.get("provisoSection"),
						OptionalUtil.getValue(provisoSection)));
			}
			if (OptionalUtil.isPresent(provisoStatus)) {
				predicates.add(criteriaBuilder.equal(provisoMainEntity.get("provisoStatus"),
						OptionalUtil.getValue(provisoStatus)));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								provisoMainEntity.get("effectiveFromDate"), provisoMainEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								provisoMainEntity.get("effectiveFromDate"), provisoMainEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							provisoMainEntity.get("effectiveFromDate"), provisoMainEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							provisoMainEntity.get("effectiveFromDate"), provisoMainEntity.get("effectiveToDate")));
				}
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
}
