package com.sgl.smartpra.global.master.app.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.joda.time.DateTimeComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SearchCriteria;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.controller.util.FBTDElementConstant;
import com.sgl.smartpra.global.master.app.dao.FBTDElementDao;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.FBTDElementMapper;
import com.sgl.smartpra.global.master.app.repository.entity.FBTDElementEntity;
import com.sgl.smartpra.global.master.app.service.FBTDElementService;
import com.sgl.smartpra.global.master.model.FBTDElement;

@Service
@Transactional
public class FBTDElementServiceImpl implements FBTDElementService {

	@Autowired
	FBTDElementMapper fbtdElementMapper;

	@Autowired
	FBTDElementDao fbtdElementDao;

	@Autowired
	private MasterFeignClient masterFeignClient;
	String clientId = null;
	private static final String LASTUPDATEDBYVALIDLENGTH = "LastUpdatedBy should be minimum of 1 and maximum of 15 characters";
	private static final String MANDATORYLASTUPDATEDBY = "Please provide lastupdatedby";
	private static final String FBTDELEMENTINACTIVE = "fbtdElement is already in deactivated state";
	private static final String FBTDELEMENTACTIVE = "fbtdElement is already in activated state";
	private static final String FBTDELEMENT = "fbtdElement";
	private static final String DATEVALIDATION = "Effective dates are overlapping";
	private static final String DATECHECK = "Effective To date should be greater than Effective From date";
	private static final String VALIDELEMENTTYPE = "element type should be 1 to 6 or 11 to 16";
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String OTHER_INFO= LOVEnum.OTHER_INFO.getLOVEnum();
	public static final String NORMAL_SPECIAL = LOVEnum.NORMALSPECIAL.getLOVEnum();
	public static final String ELEMENT_TYPE = LOVEnum.ELEMENT_TYPE.getLOVEnum();
	public static final String ADDITIONAL_INFO = LOVEnum.ADDITIONAL_INFO.getLOVEnum();
	public static final String CARRIERINTERLINEDETAILSID = "FBTDElement details id not found";
	public static final String LASTUPDATEDBYMSG = "lastUpdatedBy should be minimum of 1 and maximum of 15 characters";
	public static final String LASTUPDATEDBYMENDATORYMSG = "please provide lastupdatedby";

	@Override
	public List<FBTDElement> getAllFBTDElementDetails(Optional<Integer> elementType, Optional<String> elementCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate) {

		return fbtdElementMapper.mapToModel(fbtdElementDao.search(elementType, elementCode,effectiveFromDate,effectiveToDate,activate));
	}

	@Override
	public FBTDElement getFBTDElementByFBTDId(Optional<Integer> elementType, Optional<String> elementCode,
			Optional<String> effectiveDate) {

		Optional<FBTDElementEntity> fbtdElement = fbtdElementDao.getAllFBTDEntity(elementType, elementCode,
				effectiveDate);
		if (fbtdElement.isPresent()) {
			return fbtdElementMapper.mapToModel(fbtdElement.get());
		} else {
			return new FBTDElement();
		}
	}

	@Override
	public FBTDElement createFBTDElement(FBTDElement fbtdElement) {
		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		if (!((OptionalUtil.getValue(fbtdElement.getElementType()) >= 1
				&& OptionalUtil.getValue(fbtdElement.getElementType()) <= 6)
				|| (OptionalUtil.getValue(fbtdElement.getElementType()) >= 11
						&& OptionalUtil.getValue(fbtdElement.getElementType()) <= 16))) {
			throw new BusinessException(VALIDELEMENTTYPE);
		}

		validInfo(fbtdElement);

		lovList(fbtdElement);

		// date validation
		boolean dateCheck = OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveToDate())
				.isAfter(OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveFromDate()));
		if (!dateCheck) {
			throw new BusinessException(DATECHECK);
		}

		long count = fbtdElementDao.checkOverlapExits(
				OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveToDate()), fbtdElement.getElementType(),
				fbtdElement.getElementCode());

		if (count > 0) {
			throw new BusinessException(DATEVALIDATION);
		}

		fbtdElement.setCreatedDate(LocalDateTime.now());
		fbtdElement.setActivate(Boolean.TRUE);

		return fbtdElementMapper.mapToModel(fbtdElementDao.save(fbtdElementMapper.mapToEntity(fbtdElement)));
	}

	@Override
	public FBTDElement updateFBTDElement(Integer fbtdId, FBTDElement fbtdElement) {
		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		if (!((OptionalUtil.getValue(fbtdElement.getElementType()) >= 1
				&& OptionalUtil.getValue(fbtdElement.getElementType()) <= 6)
				|| (OptionalUtil.getValue(fbtdElement.getElementType()) >= 11
						&& OptionalUtil.getValue(fbtdElement.getElementType()) <= 16))) {
			throw new BusinessException(VALIDELEMENTTYPE);
		}

		// date validation
		boolean dateCheck = OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveToDate())
				.isAfter(OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveFromDate()));
		if (!dateCheck) {
			throw new BusinessException(DATECHECK);
		}

		validInfo(fbtdElement);

		lovList(fbtdElement);

		Optional<FBTDElementEntity> fbtdElementEntity = fbtdElementDao.findById(fbtdId);

		if (!fbtdElementEntity.isPresent())
			throw new ResourceNotFoundException(FBTDELEMENT, "id", fbtdId);

		if (!fbtdElementEntity.get().getActivate()) {
			throw new BusinessException("fbtdElement is not active");
		}

		List<FBTDElementEntity> sameRecord = fbtdElementDao.verifyIfSameRecordExits(fbtdElement.getEffectiveFromDate(),
				fbtdElement.getEffectiveToDate(), fbtdElement.getElementType(), fbtdElement.getElementCode());

		if (!sameRecord.isEmpty() && sameRecord.size() == 1 && sameRecord.get(0).equals(fbtdId)) {

			validateDate(fbtdElement);

		} else {

			long count = fbtdElementDao.checkOverlapExitsForUpdate(
					OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveFromDate()),
					OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveToDate()), fbtdElement.getElementType(),
					fbtdElement.getElementCode(), fbtdElement.getFbtdId());

			if (count > 0) {
				throw new BusinessException(DATEVALIDATION);
			}

		}


		return fbtdElementMapper.mapToModel(fbtdElementDao.update(
				fbtdElementMapper.mapToEntity(fbtdElement, fbtdElementEntity.get())));
	}

	@Override
	public void deactivateFBTDElement(Integer fbtdId, String lastUpdatedBy) {
		Optional<FBTDElementEntity> fbtdElementEntity = Optional.ofNullable(fbtdElementDao.findById(fbtdId))
				.orElseThrow(() -> new BusinessException(CARRIERINTERLINEDETAILSID));

		if (!fbtdElementEntity.isPresent())
			throw new ResourceNotFoundException(FBTDELEMENT, "id", fbtdId);

		if (fbtdElementEntity.get().getActivate()) {
			throw new BusinessException(FBTDELEMENTINACTIVE);
		}

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException(LASTUPDATEDBYVALIDLENGTH);
		} else {
			throw new BusinessException(MANDATORYLASTUPDATEDBY);
		}

		fbtdElementEntity.get().setActivate(Boolean.FALSE);
		fbtdElementEntity.get().setLastUpdatedBy(lastUpdatedBy);
		fbtdElementEntity.get().setLastUpdatedDate(LocalDateTime.now());
		fbtdElementDao.save(fbtdElementEntity.get());

	}

	@Override
	public void activateFBTDElement(Integer fbtdId, String lastUpdatedBy) {

		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		Optional<FBTDElementEntity> fbtdElementEntity = Optional.ofNullable(fbtdElementDao.findById(fbtdId))
				.orElseThrow(() -> new BusinessException(CARRIERINTERLINEDETAILSID));

		if (!fbtdElementEntity.isPresent())
			throw new ResourceNotFoundException(FBTDELEMENT, "id", fbtdId);

		if (fbtdElementEntity.get().getActivate())
			throw new BusinessException(FBTDELEMENTACTIVE);

		FBTDElement fbtdElement = new FBTDElement();
		boolean dateCheck = OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveToDate())
				.isAfter(OptionalUtil.getLocalDateValue(fbtdElement.getEffectiveFromDate()));
		if (!dateCheck) {
			throw new BusinessException(DATECHECK);
		}

		List<FBTDElementEntity> count = fbtdElementDao.verifyRecordExits(fbtdElement.getEffectiveFromDate(),
				fbtdElement.getEffectiveToDate(), fbtdId, fbtdElement.getElementType(), fbtdElement.getElementCode());

		if (count.isEmpty()) {
			throw new BusinessException(DATEVALIDATION);
		}

		fbtdElementEntity.get().setActivate(Boolean.TRUE);
		fbtdElementEntity.get().setLastUpdatedDate(LocalDateTime.now());
		fbtdElementEntity.get().setLastUpdatedBy(lastUpdatedBy);
		fbtdElementDao.save(fbtdElementEntity.get());
	}

	@Override
	public boolean getFBTDElementByElementCode(String elementCode) {
		Integer elementType = FBTDElementConstant.ELEMENT_5;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.findByElementCode(elementCode, elementType);
		if (fBTDElement != null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean getFBTDElementByElementCodeBasedOnPrimeCode(String elementCode, Integer elementType) {
		elementType = FBTDElementConstant.ELEMENT_1;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.getFBTDElementByElementCodeBasedOnPrimeCode(elementCode,
				elementType);
		if (!(fBTDElement.isEmpty())) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public Boolean validateCabin(String cabin) {
		Integer elementType = FBTDElementConstant.ELEMENT_1;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.validateCabin(cabin, elementType);
		if (!(fBTDElement.isEmpty())) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public Boolean validateOtherInfo(String otherInfo) {
		Integer elementType = FBTDElementConstant.ELEMENT_1;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.validateOtherInfo(otherInfo, elementType);
		if (!(fBTDElement.isEmpty())) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateIATAFareType(String iataFareType) {
		Integer elementType = FBTDElementConstant.ELEMENT_5;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.validateIATAFareType(iataFareType, elementType);
		if (!fBTDElement.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateSeasonalCode(String seasonalCode) {
		Integer elementType = FBTDElementConstant.ELEMENT_2;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.validateSeasonalCode(seasonalCode, elementType);
		if (!fBTDElement.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateDayOfWeek(String dayOfWeek) {
		Integer elementType = FBTDElementConstant.ELEMENT_3;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.validateDayOfWeek(dayOfWeek, elementType);
		if (!fBTDElement.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateDiscountCode(String discountCode) {
		Integer elementType = FBTDElementConstant.ELEMENT_5;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.validateDiscountCode(discountCode, elementType);
		if (!fBTDElement.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateJourneyType(String journeyType) {
		Integer elementType = FBTDElementConstant.ELEMENT_5;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.validateJourneyType(journeyType, elementType);
		if (!fBTDElement.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateZedIdentifier(String zedIdentifier) {
		Integer elementType = FBTDElementConstant.ELEMENT_13;
		List<FBTDElementEntity> fBTDElement = fbtdElementDao.validateZedIdentifier(zedIdentifier, elementType);
		if (!fBTDElement.isEmpty()) {
			return true;
		} else {
			return false;
		}

	}

	public void lovList(FBTDElement fbtdElement) {
		
		List<String> elementTypeList2 = masterFeignClient.getListOfValues(clientId, TABLENAME, OTHER_INFO);
		boolean flag2 = false;
		for (String elementTypestr : elementTypeList2) {
			if (OptionalUtil.isPresent(fbtdElement.getOtherInfo())
					&& elementTypestr.equals(OptionalUtil.getValue(fbtdElement.getOtherInfo()))) {
				flag2 = true;
			}
		}
		if (OptionalUtil.isPresent(fbtdElement.getOtherInfo()) && !flag2) {
			throw new BusinessException("invalid other info");
		}

		List<String> elementTypeList3 = masterFeignClient.getListOfValues(clientId, TABLENAME, NORMAL_SPECIAL);
		boolean flag3 = false;
		for (String elementTypestr : elementTypeList3) {
			if (OptionalUtil.isPresent(fbtdElement.getNormalSpecial())
					&& elementTypestr.equals(OptionalUtil.getValue(fbtdElement.getNormalSpecial()))) {
				flag3 = true;
			}
		}
		if (OptionalUtil.isPresent(fbtdElement.getNormalSpecial()) && !flag3) {
			throw new BusinessException("invalid Normal/Special");
		}
	}

	public void validInfo(FBTDElement fbtdElement) {
		
		List<String> elementTypeList = masterFeignClient.getListOfValues(clientId, TABLENAME, ELEMENT_TYPE);
		boolean flag = false;
		for (String elementTypestr : elementTypeList) {
			if (elementTypestr.equals(OptionalUtil.getValue(fbtdElement.getElementType()).toString())) {
				flag = true;
			}
		}
		if (!flag) {
			throw new BusinessException("invalid elementType");
		}
		
		List<String> elementTypeList1 = masterFeignClient.getListOfValues(clientId, TABLENAME, ADDITIONAL_INFO);
		elementTypeList1.add(null);
		boolean flag1 = false;
		if (elementTypeList1.contains(OptionalUtil.getValue(fbtdElement.getAdditionalInfo()))) {
			flag1 = true;
		}
		if (!flag1) {
			throw new BusinessException("invalid Additional Info");
		}

	}

	public void validateDate(FBTDElement fbtdElement) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		String currentDateStr = sdf.format(new Date());

		String effectiveToDateStr = sdf.format(fbtdElement.getEffectiveToDate());

		Date currentDate = null;
		Date effectiveToDate = null;
		try {
			currentDate = sdf.parse(currentDateStr);
			effectiveToDate = sdf.parse(effectiveToDateStr);
		} catch (ParseException e) {

			e.printStackTrace();
		}

		DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();

		int valid = dateTimeComparator.compare(effectiveToDate, currentDate);

		if (valid < 0) {
			throw new BusinessException("Effective To date should be greater than or equal to the current date.");
		}

	}

	@Override
	public FBTDElement getFBTDElementByFBTDId(Integer fbtdId) {
		return fbtdElementMapper.mapToModel(
				fbtdElementDao.findById(fbtdId).orElseThrow(() -> new RecordNotFoundException(String.valueOf(fbtdId))));
	}

	@Override
	public List<FBTDElement> getCabinLevel() {
		Integer elementType = 1;
		return fbtdElementMapper.mapToModel(fbtdElementDao.getCabilLevel(elementType));
	}

}
