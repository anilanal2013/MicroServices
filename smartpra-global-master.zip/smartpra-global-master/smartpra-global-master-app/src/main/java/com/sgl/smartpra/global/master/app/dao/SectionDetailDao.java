package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.SectionDetailEntity;

@Repository
public interface SectionDetailDao {
	public Optional<SectionDetailEntity> findById(Integer sectionDeatilId);

	public SectionDetailEntity create(SectionDetailEntity sectionDetailEntity);

	public SectionDetailEntity update(SectionDetailEntity sectionDetailEntity);

	public List<SectionDetailEntity> findAll(Integer sectionMasterId, Integer sectionDetailId, Optional<String> sectionElementName,Optional<Boolean> activate);
	
	public List<SectionDetailEntity> getByOrderNumber(Optional<String> orderNumber);
	
	public List<SectionDetailEntity> getByDisplayOrderNumber(Integer sectionMasterId, Integer sectionDetailId, Optional<String> displayOrderNumber);
	
	List<SectionDetailEntity> update(List<SectionDetailEntity> sectionDetailEntitys);
	
	List<SectionDetailEntity> getListOfSectionDetailsByChargeCode(List<Integer> sections, Optional<String> sectionElementName, Optional<Boolean> activate);
}
