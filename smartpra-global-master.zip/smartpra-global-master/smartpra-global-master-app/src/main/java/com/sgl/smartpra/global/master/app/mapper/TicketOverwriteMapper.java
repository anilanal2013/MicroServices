package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;

import com.sgl.smartpra.global.master.app.dao.entity.TicketOverwriteEntity;
import com.sgl.smartpra.global.master.model.TicketOverwrite;

@Mapper(componentModel="Spring")
public interface TicketOverwriteMapper extends BaseMapper<TicketOverwrite, TicketOverwriteEntity> {
	
	TicketOverwriteEntity mapToEntity(TicketOverwrite ticketOverwriteDao);

	TicketOverwrite mapToModel(TicketOverwriteEntity ticketOverwriteEntity);

	default TicketOverwriteEntity fromId(Long id){
		if(id == null){
			return null;
		}
		TicketOverwriteEntity ticketOverwriteEntity = new TicketOverwriteEntity();
		ticketOverwriteEntity.setScenarioNo(id);
		return ticketOverwriteEntity;
	}
}
