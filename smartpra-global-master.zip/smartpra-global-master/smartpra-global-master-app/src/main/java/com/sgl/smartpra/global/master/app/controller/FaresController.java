package com.sgl.smartpra.global.master.app.controller;


import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.FaresService;
import com.sgl.smartpra.global.master.model.Fares;


@RestController
public class FaresController {
	
	@Autowired
	@Qualifier("FaresService")
	private FaresService faresService;
	
	 
	@GetMapping("/fares/{fareId}")
	public Fares getFaresByFareId(@PathVariable(value = "fareId")Integer fareId) {
		return faresService.getFaresByFareId(fareId);
	}
	
	@GetMapping("/fares")
	@ResponseStatus(value = HttpStatus.OK)
	public List<Fares> getFareBySearch(@RequestParam(value = "cxrCode", required = false) Optional<String> cxrCode,
			@RequestParam(value = "originCity", required = false)Optional<String> originCity,
			@RequestParam(value = "destinationCity", required = false)Optional<String> destinationCity,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate
			){
		return faresService.getFareBySearch(cxrCode, originCity, destinationCity, effectiveFromDate, effectiveToDate);		
	}
	
	@GetMapping("fares/faresForFaresSelectionProcessing")
	@ResponseStatus(value = HttpStatus.OK)
	public List<Fares> getFareForFareSelectionProcessing(@RequestParam(value = "cxrCode", required = false) Optional<String> cxrCode,
			@RequestParam(value = "originCity", required = false)Optional<String> originCity,
			@RequestParam(value = "destinationCity", required = false)Optional<String> destinationCity,
			@RequestParam(value = "effectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") 
			Optional<String> effectiveDate){
		return faresService.getFareForFareSelectionProcessing(cxrCode, originCity, destinationCity, effectiveDate);		
	}
	
	@PostMapping("/fares")
	@ResponseStatus(value = HttpStatus.CREATED)
	public Fares createFare(@Validated(Create.class)@RequestBody Fares fares) {
		return faresService.createFares(fares);
	}
	
	@PutMapping("/fares/{fareId}")
	@ResponseStatus(value = HttpStatus.OK)
	public Fares updateFares(@PathVariable(value = "fareId") Integer fareId, @Validated(Update.class) @RequestBody Fares fares) {
		fares.setFareId(fareId);
		return faresService.updateFares(fares);
	}
	
	@PutMapping("/fares/{fareId}/deactivate")
	public void deactivateFareId(
			@Valid @PathVariable(value = "fareId") Integer fareId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		Fares fares = new Fares();
		fares.setFareId(fareId);
		fares.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		faresService.deactivateFare(fares);
	}

	@PutMapping("/fares/{fareId}/activate")
	public void activateFareId(
			@Valid @PathVariable(value = "fareId") Integer fareId,
			@RequestParam(value = "lastUpdatedBy") String lastUpdatedBy) {
		Fares fares = new Fares();
		fares.setFareId(fareId);
		fares.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		faresService.activateFare(fares);
	}
	
		
}
