package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoRoutingDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoRoutingEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoRoutingRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoRoutingDaoImpl implements ProvisoRoutingDao {
	@Autowired
	private ProvisoRoutingRepository provisoRoutingRepository;

	@Override
	public List<ProvisoRoutingEntity> findByMainId(Optional<Integer> provisoMainId) {
		return provisoRoutingRepository.findAll(ProvisoRoutingEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	@Cacheable(value = "provisoRouting", key = "#id")
	public Optional<ProvisoRoutingEntity> findById(Integer id) {
		log.info("Cacheable Proviso Routing Entity's ID= {}", id);
		return provisoRoutingRepository.findById(id);
	}

	@Override
	public List<ProvisoRoutingEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber) {
		return provisoRoutingRepository
				.findAll(ProvisoRoutingEntitySpecification.search(carrierNumCode, provisoSeqNumber, detailRecNumber));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "provisoRouting", key = "#provisoRoutingEntity.provisoMainId") })
	public ProvisoRoutingEntity create(ProvisoRoutingEntity provisoRoutingEntity) {
		return provisoRoutingRepository.save(provisoRoutingEntity);
	}

	@Override
	public List<Integer> getListOfProvisoMainIdFromRoutingDb() {
		return provisoRoutingRepository.getListOfProvisoMainIdFromRoutingDb();
	}
}
