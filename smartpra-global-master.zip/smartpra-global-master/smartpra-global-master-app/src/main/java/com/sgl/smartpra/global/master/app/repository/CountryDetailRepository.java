
package com.sgl.smartpra.global.master.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.CountryDetailEntity;

@Repository
public interface CountryDetailRepository
		extends JpaRepository<CountryDetailEntity, Integer>, JpaSpecificationExecutor<CountryDetailEntity> {

	/*
	 * @Query(value =
	 * "select a from CountryDetailEntity a  where (:effectiveDate between a.effectiveFromPeriod  AND a.effectiveToPeriod) or a.countryCode = :countryCode"
	 * ) List<CountryDetailEntity>
	 * getAllCountryEntityByEffectiveDate(@Param("countryCode")String
	 * countryCode,@Param("effectiveDate") Date effectiveDate);
	 * 
	 * List<CountryDetailEntity> findByCountryCode(String countryCode);
	 */

}
