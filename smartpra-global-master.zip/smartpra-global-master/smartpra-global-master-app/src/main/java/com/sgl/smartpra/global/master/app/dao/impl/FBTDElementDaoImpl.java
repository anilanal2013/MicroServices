package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.controller.util.FBTDElementConstant;
import com.sgl.smartpra.global.master.app.dao.FBTDElementDao;
import com.sgl.smartpra.global.master.app.dao.entity.spec.FBTDElementSpecification;
import com.sgl.smartpra.global.master.app.repository.FBTDElementRepository;
import com.sgl.smartpra.global.master.app.repository.entity.FBTDElementEntity;
import com.sgl.smartpra.global.master.model.Currency;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FBTDElementDaoImpl extends CommonSearchDao<Currency> implements FBTDElementDao {

	@Autowired
	private FBTDElementRepository fbtdElementRepository;

	@Override
	public Optional<FBTDElementEntity> getAllFBTDEntity(Optional<Integer> elementType, Optional<String> elementCode,
			Optional<String> effectiveDate) {
		return fbtdElementRepository.findOne(Specification.where(FBTDElementSpecification.getAllFBTDEntity(elementType, elementCode, effectiveDate)));
	}

	@Override
	public List<FBTDElementEntity> search(Optional<Integer> elementType, Optional<String> elementCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate) {
		return fbtdElementRepository.findAll(FBTDElementSpecification.search(elementType, elementCode,effectiveFromDate,effectiveToDate,activate));
	}

	@Override
	public long checkOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate, Optional<Integer> elementType,
			Optional<String> elementCode) {
		return fbtdElementRepository
				.count(Specification.where(FBTDElementSpecification.equalsClientId(elementCode))
				.and(FBTDElementSpecification.equalsCarrierCode(elementType))
						.and(FBTDElementSpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(FBTDElementSpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))));
	}
	
	@Override
	public long checkOverlapExitsForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, Optional<Integer> elementType,
			Optional<String> elementCode, Integer fbtdId) {
		return fbtdElementRepository
				.count(Specification.where(FBTDElementSpecification.equalsClientId(elementCode))
				.and(FBTDElementSpecification.equalsCarrierCode(elementType))
						.and(FBTDElementSpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(FBTDElementSpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
						.and(FBTDElementSpecification.notEqualsfbtdId(fbtdId)));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fbtdElement", key = "#fbtdElementEntity.fbtdId") })
	public FBTDElementEntity save(FBTDElementEntity fbtdElementEntity) {
		return fbtdElementRepository.save(fbtdElementEntity);
	}

	@Override
	@CachePut(value = "fbtdElement", key = "#fbtdElementEntity.fbtdId")
	public FBTDElementEntity update(FBTDElementEntity fbtdElementEntity) {
		return fbtdElementRepository.save(fbtdElementEntity);
	}

	@Override
	@Cacheable(value = "fbtdElement", key = "#fbtdId")
	public Optional<FBTDElementEntity> findById(Integer fbtdId) {
		return fbtdElementRepository.findById(fbtdId);
	}
	
	// Update
	@Override
	public List<FBTDElementEntity> verifyIfSameRecordExits(Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Integer> elementType,
			Optional<String> elementCode) {
		return fbtdElementRepository.findAll(FBTDElementSpecification.verifyIfSameRecordExits(effectiveFromDate, effectiveToDate, elementType, elementCode));
	}

	@Override
    public List<FBTDElementEntity> findByElementCode(String elementCode, Integer elementType) {
           return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.findByElementCode(elementCode)
                        .and(FBTDElementSpecification.findByElementType(elementType))
                        .and(FBTDElementSpecification.isActive())));
    }

	@Override
	public List<FBTDElementEntity> getFBTDElementByElementCodeBasedOnPrimeCode(String elementCode, Integer elementType) {
		return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.findByElementBasedOnPrimeCode(elementCode)
                .and(FBTDElementSpecification.findByElementTypePrimeCode(elementType))
                .and(FBTDElementSpecification.isActive())));
	}

	@Override
	public List<FBTDElementEntity> validateCabin(String cabin, Integer elementType) {
		return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.validateCabin(cabin)
				  .and(FBTDElementSpecification.findByElementType(elementType))
                  .and(FBTDElementSpecification.isActive())));
	}

	@Override
    public List<FBTDElementEntity> validateOtherInfo(String otherInfo, Integer elementType) {
          return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.findByElementType(elementType)
        		  .and((FBTDElementSpecification.findAddInfo(FBTDElementConstant.ADDITIONAL_INFO_F)
                  .or(FBTDElementSpecification.findAddInfo(FBTDElementConstant.ADDITIONAL_INFO_C)
                  .or(FBTDElementSpecification.findAddInfo(FBTDElementConstant.ADDITIONAL_INFO_Y))))
                  .and(FBTDElementSpecification.validateOtherInfo(otherInfo))
                  .and(FBTDElementSpecification.isActive()))));
    }

	@Override
	public List<FBTDElementEntity> validateIATAFareType(String iataFareType, Integer elementType) {
		return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.findByElementType(elementType)
      		  .and(FBTDElementSpecification.notEqualJAndD(FBTDElementConstant.ADDITIONAL_INFO_J,FBTDElementConstant.ADDITIONAL_INFO_D)
      		  .or(FBTDElementSpecification.isAdditionalInfoNull()))
              .and(FBTDElementSpecification.validateElementCode(iataFareType))
              .and(FBTDElementSpecification.isActive())));
	}

	@Override
	public List<FBTDElementEntity> validateSeasonalCode(String seasonalCode, Integer elementType) {
		return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.validateSeasonalCode(seasonalCode)
				.and(FBTDElementSpecification.findByElementType(elementType))
                .and(FBTDElementSpecification.isActive())));
	}

	@Override
	public List<FBTDElementEntity> validateDayOfWeek(String dayOfWeek, Integer elementType) {
		return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.validateDayOfWeek(dayOfWeek)
				.and(FBTDElementSpecification.findByElementType(elementType))
                .and(FBTDElementSpecification.isActive())));
	}

	@Override
	public List<FBTDElementEntity> validateDiscountCode(String discountCode, Integer elementType) {
		return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.validateDiscountCode(discountCode)
				.and(FBTDElementSpecification.findByElementType(elementType))
				.and(FBTDElementSpecification.findAddInfoD(FBTDElementConstant.ADDITIONAL_INFO_D))
                .and(FBTDElementSpecification.isActive())));
	}
	
	@Override
	public List<FBTDElementEntity> getDiscountCodeList() {
		return fbtdElementRepository.findAll(Specification.where(
				FBTDElementSpecification.findByElementType(FBTDElementConstant.ELEMENT_5))
				.and(FBTDElementSpecification.findAddInfoD(FBTDElementConstant.ADDITIONAL_INFO_D))
                .and(FBTDElementSpecification.equalsEffectiveToDateGreaterThanEqual()));
	}

	@Override
	public List<FBTDElementEntity> validateJourneyType(String journeyType, Integer elementType) {
		return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.validateJourneyType(journeyType)
				.and(FBTDElementSpecification.findByElementType(elementType))
				.and(FBTDElementSpecification.findAddInfoJ(FBTDElementConstant.ADDITIONAL_INFO_J))));
	}

	@Override
	public List<FBTDElementEntity> validateZedIdentifier(String zedIdentifier, Integer elementType) {
		return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.validateZedIdentifier(zedIdentifier)
				.and(FBTDElementSpecification.findByElementType(elementType))
                .and(FBTDElementSpecification.isActive())));
	}

	@Override
	public List<FBTDElementEntity> getAllFBTDEntity1(Optional<String> date, Optional<Integer> elementType,
			Optional<String> elementCode) {
		return fbtdElementRepository.findAll(FBTDElementSpecification.getAllFBTDEntity1(date, elementType, elementCode));
	}

	@Override
	public List<FBTDElementEntity> verifyRecordExits(Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Integer fbtdId,
			Optional<Integer> elementType, Optional<String> elementCode) {
		return fbtdElementRepository.findAll(FBTDElementSpecification.verifyRecordExits(effectiveFromDate, effectiveToDate, fbtdId, elementType, elementCode));
	}

	@Override
	public List<FBTDElementEntity> getCabilLevel(Integer elementType) {
		return fbtdElementRepository.findAll(Specification.where(FBTDElementSpecification.findByElementTypePrimeCode(elementType))
				.and(FBTDElementSpecification.equalCheckElementCodeWithAdditionalInfo()));
	}
	
	@Override
	public List<String> getElementCodeByElementTypeAndAdditionalInfo(){
		return fbtdElementRepository.getElementCodeByElementTypeAndAdditionalInfo();
	}

}
