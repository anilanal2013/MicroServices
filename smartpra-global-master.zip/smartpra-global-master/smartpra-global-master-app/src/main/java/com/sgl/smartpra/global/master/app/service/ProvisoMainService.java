package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoMainModel;
import com.sgl.smartpra.global.master.model.ProvisoMainStgModel;

public interface ProvisoMainService {

	public List<ProvisoMainModel> search(Optional<String> carrierNumCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> provisoSection, Optional<String> provisoStatus);

	public ProvisoMainModel getProvisoMainByprovisoMainId(Integer provisoMainId);

	public ProvisoMainStgModel saveProvisoMain(ProvisoMainStgModel provisoMainStgModel);

	public List<ProvisoMainModel> getProvisoMainList(String carrierNumCode, String effectiveDate);
}
