package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorEntity;
@Repository
public interface ProvisoSectorDao {

	List<ProvisoSectorEntity> findByMainId(Optional<Integer> provisoMainId);

	Optional<ProvisoSectorEntity> findById(Integer provisioSectorId);

	List<ProvisoSectorEntity> searchByProvisoInMain(Optional<Integer> provisoMainId, Optional<String> areaFrom);

	List<ProvisoSectorEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);

	List<ProvisoSectorEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> sectionRecNumber);

	ProvisoSectorEntity create(ProvisoSectorEntity provisoSectorEntity);
	
	public List<Integer> getListOfProvisoMainIdFromSectorDb();
}
