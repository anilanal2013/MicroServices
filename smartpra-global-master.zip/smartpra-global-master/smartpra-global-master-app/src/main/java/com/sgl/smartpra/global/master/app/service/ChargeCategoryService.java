package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sgl.smartpra.global.master.model.ChargeCategory;

@Service
public interface ChargeCategoryService {

	public ChargeCategory createChargeCategory(ChargeCategory chargeCategory);

	public ChargeCategory getChargeCategoryByChargeCategoryCode(Optional<String> chargeCategoryCode);

	public ChargeCategory getChargeCategoryByChargeCategoryName(Optional<String> chargeCategoryName);

	public List<ChargeCategory> getAllChargeCategory(Optional<String> chargeCategoryCode,
			Optional<String> chargeCategoryName, Optional<Boolean> activate);

	public List<ChargeCategory> updateChargeCategroy(List<ChargeCategory> chargeCategory);

	public void deactivateChargeCategory(Optional<String> chargeCategoryCode, Optional<String> lastUpdatedBy);

	public void activateChargeCategory(Optional<String> chargeCategoryCode, Optional<String> lastUpdatedBy);

	public ChargeCategory getChargeCategoryByChargeCatCode(String chargeCategoryCode);

	public List<String> getChargeCatCodeFromChargeCatMaster();

}