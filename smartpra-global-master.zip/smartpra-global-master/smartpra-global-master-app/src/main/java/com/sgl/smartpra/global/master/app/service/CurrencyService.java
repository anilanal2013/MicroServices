package com.sgl.smartpra.global.master.app.service;

import java.util.List;

import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.Currency;

public interface CurrencyService {

	public List<Currency> getAllCurrency(String currencyCode, String currencyName, Boolean isActive);

	public Currency findCurrencyByCurrencyCode(String currencyCode);

	public Currency createCurrency(Currency currency);

	public Currency updateCurrency(String currencyCode, Currency currency);

	public void deactivateCurrency(String currencyCode, String lastUpdatedBy);

	public void activateCurrency(String currencyCode, String lastUpdatedBy);

	public boolean isValidCurrencyCode(String currencyCode);

	public List<String> getValidCurrencyCode(List<String> currencyCodeList);

	public List<CommonIdName> getCurrencyList();

	public Currency getCurrencyByCurrencyNumericCode(Integer currencyNumericCode);
}
