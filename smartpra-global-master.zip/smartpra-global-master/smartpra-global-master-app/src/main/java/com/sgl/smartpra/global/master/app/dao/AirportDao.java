package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.global.master.app.dao.entity.AirportEntity;

public interface AirportDao {

	public Optional<AirportEntity> findById(String airportCode);
	
	public AirportEntity create(AirportEntity airportEntity);
	
	public AirportEntity update(AirportEntity airportEntity);
	
	public Page<AirportEntity> findAll(AirportEntity airportEntity,Optional<String> exceptionCall,Pageable pageable);
	
	public List<AirportEntity> searchAll(Optional<String> airportCode, Optional<String> airportName, Optional<String> cityCode, Optional<String> cityName,
			Optional<String> countryCode);
	
	public long getCount(AirportEntity airportEntity, Optional<String> exceptionCall);
	
	public Optional<AirportEntity> isValidAirportCode(Optional<String> airportOrCity);
	
	public List<AirportEntity> isValidCityCodeList(Optional<String> cityCode);
	
	public List<AirportEntity> isValidAirportCodeList(Optional<String> airportCode);

	List<AirportEntity> isValidStateCode(Optional<String> stateCode);
	
	public List<AirportEntity> searchByCityOrStateOrCountry(Optional<String> airportCode,Optional<String> stateCode,Optional<String> cityCode,
			Optional<String> countryCode);
}
