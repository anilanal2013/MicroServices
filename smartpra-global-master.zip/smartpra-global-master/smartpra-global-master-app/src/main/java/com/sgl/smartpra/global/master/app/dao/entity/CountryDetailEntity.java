
package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_country_detail")
@Data
@EqualsAndHashCode(callSuper=false)
@DynamicUpdate
@DynamicInsert
public class CountryDetailEntity extends BaseEntity{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "country_dtl_id", nullable = false)
	private Integer countryDtlId;

	@Column(name = "country_code", nullable = false, length = 2)
	private String countryCode;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromPeriod;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToPeriod;

	@Column(name = "base_Currency_Code", nullable = false, length = 3)
	private String baseCurrencyCode;

	@Column(name = "dual_Currency_Code", nullable = false, length = 3)
	private String dualCurrencyCode;

	@Column(name = "strong_Currency_Code", nullable = false, length = 3)
	private String strongCurrencyCode;

	@Column(name = "attachment_a_indi", nullable = false, length = 1)
	private String attachmentAIndi;

	@Column(name = "eu_member", nullable = false, length = 1)
	private String euMember;

	@Column(name = "parent_country_code", nullable = false, length = 2)
	private String parentCountryCode;
		
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}
	
	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}
}
