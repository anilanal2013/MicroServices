package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoRouting;
import com.sgl.smartpra.global.master.model.ProvisoRoutingStg;

public interface ProvisoRoutingService {
	
	public List<ProvisoRouting> getProvisoRoutingByProvisoMainId(Optional<Integer> provisoMainId);

	public ProvisoRouting getProvisoRoutingByProvisoRoutingId(Integer provisoRoutingId);

	public List<ProvisoRouting> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber);

	public ProvisoRoutingStg saveProvisoRouting(ProvisoRoutingStg provisoRoutingStg);
}
