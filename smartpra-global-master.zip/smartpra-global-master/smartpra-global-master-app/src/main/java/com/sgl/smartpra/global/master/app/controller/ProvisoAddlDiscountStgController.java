package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.ProvisoAddlDiscountStgService;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscountStg;

@RestController
@RequestMapping("/proviso/additionalDiscount/stg")
public class ProvisoAddlDiscountStgController {

	@Autowired
	private ProvisoAddlDiscountStgService provisoAddlDiscountStgService;

	@PostMapping("/{provisoMainId}/proviso-addldiscount")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoAdditionalDiscountStg createProvisoAddlDiscount(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@Validated(Create.class) @RequestBody ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg) {
		provisoAdditionalDiscountStg.setProvisoMainId(provisoMainId);
		return provisoAddlDiscountStgService.createProvisoAddlDiscount(provisoAdditionalDiscountStg);
	}
	
	@GetMapping("provisoMain/{provisoMainId}")
	public List<ProvisoAdditionalDiscountStg> getProvisoAddlDiscountByProvisoMainId(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId) {
		return provisoAddlDiscountStgService.getProvisoAddlDiscountByProvisoMainId(provisoMainId);
	}

	@GetMapping("/{provisoAddlDiscountId}")
	public ProvisoAdditionalDiscountStg getProvisoAddlDiscountByProvisoAddlDiscountId(
			@PathVariable(value = "provisoAddlDiscountId") Integer provisoAddlDiscountId) {
		return provisoAddlDiscountStgService.getProvisoAddlDiscountByProvisoAddlDiscountId(provisoAddlDiscountId);
	}

	@GetMapping("/proviso-addldiscount/{carrierNumCode}/{provisoSeqNumber}")
	public List<ProvisoAdditionalDiscountStg> searchByProvisoAddlDiscount(
			@PathVariable(value = "carrierNumCode") Optional<String> carrierNumCode,
			@PathVariable(value = "provisoSeqNumber") Optional<Integer> provisoSeqNumber) {
		return provisoAddlDiscountStgService.search(carrierNumCode, provisoSeqNumber);
	}

	@PutMapping("/{provisoMainId}/{provisoAddlDiscountId}")
	@ResponseStatus(value = HttpStatus.OK)
	public ProvisoAdditionalDiscountStg updateProvisoAddlDiscount(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@PathVariable(value = "provisoAddlDiscountId") Integer provisoAddlDiscountId,
			@Validated(Update.class) @RequestBody ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg) {
		    provisoAdditionalDiscountStg.setProvisoMainId(provisoMainId);
		return provisoAddlDiscountStgService.updateProvisoAddlDiscount(provisoAddlDiscountId,provisoAdditionalDiscountStg);
	}
	@DeleteMapping("/provisoAddlDiscountDeletedById/{provisoAddlDiscountId}")
	public void deleteProvisoRoutingMasterStg(@PathVariable(value = "provisoAddlDiscountId") Integer provisoAddlDiscountId) {
		provisoAddlDiscountStgService.deleteProvisoAddlDiscountByProvisoAddlDiscountId(provisoAddlDiscountId);
	}	
}
