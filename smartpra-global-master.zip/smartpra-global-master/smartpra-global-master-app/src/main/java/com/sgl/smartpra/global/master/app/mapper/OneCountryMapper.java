package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.OneCountryEntity;
import com.sgl.smartpra.global.master.model.OneCountry;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface OneCountryMapper extends BaseMapper<OneCountry, OneCountryEntity> {

	OneCountryEntity mapToEntity(OneCountry oneCountry, @MappingTarget OneCountryEntity oneCountryEntity);

	@Mapping(source = "oneCountryId", target = "oneCountryId", ignore = true)
	OneCountryEntity mapToEntity(OneCountry oneCountry);

}
