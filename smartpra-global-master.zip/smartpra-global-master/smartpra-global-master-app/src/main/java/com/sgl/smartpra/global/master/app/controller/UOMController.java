package com.sgl.smartpra.global.master.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.UOMService;
import com.sgl.smartpra.global.master.model.UOM;

@RestController
public class UOMController {

	@Autowired
	private UOMService uomService;

	@GetMapping("/uom")
	public List<UOM> getAllUom(@RequestParam(value = "uomCode", required = false) String uomCode,
			@RequestParam(value = "uomType", required = false) String uomType) {
		return uomService.getAllUom(uomCode, uomType);

	}

	@GetMapping("/uom/{uomId}")
	public UOM getUOMByUOMCode(@PathVariable(value = "uomId") Integer uomId) {
		return uomService.findUomByUomCode(uomId);
	}

	@PostMapping("/uom")
	public UOM createUom(@Validated(Create.class) @RequestBody UOM uom) {
		return uomService.createUom(uom);
	}

	@PutMapping("/uom/{uomId}")
	public UOM updateUom(@PathVariable(value = "uomId") Integer uomId, @Validated(Update.class) @RequestBody UOM uom) {
		return uomService.updateUom(uomId, uom);
	}

	@PutMapping("/uom/{uomId}/deactivate")
	public void deactivateUom(@Valid @PathVariable(value = "uomId") Integer uomId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		uomService.deactivateUom(uomId, lastUpdatedBy);

	}

	@PutMapping("/uom/{uomId}/activate")
	public void activateUom(@Valid @PathVariable(value = "uomId") Integer uomId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		uomService.activateUom(uomId, lastUpdatedBy);

	}

}
