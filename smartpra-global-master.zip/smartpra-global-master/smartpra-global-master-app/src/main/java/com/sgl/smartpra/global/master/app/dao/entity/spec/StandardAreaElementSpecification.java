package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.repository.entity.StandardAreaEntity;

public final class StandardAreaElementSpecification {
	StandardAreaElementSpecification() {
	}

	public static Specification<StandardAreaEntity> search(Optional<String> standardAreaCode,
			Optional<String> standardAreaName, Boolean activate) {
		return (standardAreaEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(standardAreaCode)) {
				predicates.add(criteriaBuilder.like(standardAreaEntity.get("standardAreaCode"),
						OptionalUtil.getValue(standardAreaCode) + "%"));
			}
			if (OptionalUtil.isPresent(standardAreaName)) {
				predicates.add(criteriaBuilder.like(standardAreaEntity.get("standardAreaName"),
						OptionalUtil.getValue(standardAreaName) + "%"));
			}
			if (activate == null || activate) {
				predicates.add(criteriaBuilder.isTrue(standardAreaEntity.get("activate")));
			} else {
				predicates.add(criteriaBuilder.isFalse(standardAreaEntity.get("activate")));
			}
			orderByAsc(standardAreaEntity, criteriaQuery, criteriaBuilder, "standardAreaCode");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<StandardAreaEntity> standardAreaListcityCode(String cityCode) {
		return (standardAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(standardAreaEntity.get("standardAreaList"), cityCode + "%");
	}

	public static Specification<StandardAreaEntity> standardAreaListstateCode(String stateCode) {
		return (standardAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(standardAreaEntity.get("standardAreaList"), stateCode + "%");
	}

	public static Specification<StandardAreaEntity> standardAreaListcountryCode(String countryCode) {
		return (standardAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(standardAreaEntity.get("standardAreaList"), countryCode + "%");
	}

	public static void orderByAsc(Root<StandardAreaEntity> standardAreaEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(standardAreaEntity.get(orderByString)));
	}

	public static Specification<StandardAreaEntity> isActive() {
		return (standardAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(standardAreaEntity.get("activate"), true);
	}

	public static Specification<StandardAreaEntity> findByStandardAreaList(String cityCode, String stateCode,
			String countryCode) {
		return (standardAreaEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (StringUtils.isNotEmpty(cityCode)) {
				predicates.add(criteriaBuilder.like(standardAreaEntity.get("standardAreaList"), "%" + cityCode + "%"));
			}
			if (StringUtils.isNotEmpty(stateCode)) {
				predicates.add(criteriaBuilder.like(standardAreaEntity.get("standardAreaList"), "%" + stateCode + "%"));
			}
			if (StringUtils.isNotEmpty(countryCode)) {
				predicates
						.add(criteriaBuilder.like(standardAreaEntity.get("standardAreaList"), "%" + countryCode + "%"));
			}

			orderByAsc(standardAreaEntity, criteriaQuery, criteriaBuilder, "areaType");
			return criteriaBuilder.or(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<StandardAreaEntity> equalStandardAreaCode(String standardAreaCode) {
		return (standardAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(standardAreaEntity.get("standardAreaCode"), standardAreaCode);
	}

	public static Specification<StandardAreaEntity> equalsActivate(boolean activate) {
		return (standardAreaEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(standardAreaEntity.get("activate"), activate);
	}

}
