package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.ChargeCodeTypeEntity;


public interface ChargeCodeTypeDao {

	public Optional<ChargeCodeTypeEntity> findById(Integer id);

	public ChargeCodeTypeEntity create(ChargeCodeTypeEntity chargeCodeTypeEntity);

	public ChargeCodeTypeEntity update(ChargeCodeTypeEntity chargeCodeTypeEntity);
	
	public List<ChargeCodeTypeEntity> update(List<ChargeCodeTypeEntity> chargeCodeTypeEntity);
	
	public Optional<ChargeCodeTypeEntity> findOne(Integer id);
	
	public List<ChargeCodeTypeEntity> findAll(Optional<String> chargeCatCode, Optional<String> chargeCode) ;
}
