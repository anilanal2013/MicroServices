package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailEntity;

public class ProvisoDetailEntitySpecification {
	ProvisoDetailEntitySpecification() {
	}

	public static Specification<ProvisoDetailEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber) {
		return (provisoDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProvisoDetailEntity> findByMainId(Optional<Integer> provisoMainId) {
		return (provisoDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProvisoDetailEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<String> fbGroupCode) {
		return (provisoDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			if (OptionalUtil.isPresent(fbGroupCode)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("fbGroupCode"),
						OptionalUtil.getValue(fbGroupCode)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProvisoDetailEntity> searchExceptionRecords(Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber,Optional<String> carrierNumCode) {
		return (provisoDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(detailRecNumber)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("exceptionFromRecord"),
						OptionalUtil.getValue(detailRecNumber)));
			}
			if (OptionalUtil.isPresent(detailRecNumber)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("exceptionToRecord"),
						OptionalUtil.getValue(detailRecNumber)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoDetailEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
