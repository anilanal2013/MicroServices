package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.SIRSRatesService;
import com.sgl.smartpra.global.master.model.SIRSRates;
import com.sgl.smartpra.global.master.model.SIRSRatesResponse;

@RestController
public class SIRSRatesController {

	@Autowired
	private SIRSRatesService sirsRatesService;

	@PostMapping("/sirsRates")
	@ResponseStatus(value = HttpStatus.CREATED)
	public SIRSRates createSIRSRates(@Validated(Create.class) @RequestBody SIRSRates sirsRates) {
		return sirsRatesService.createSIRSRates(sirsRates);
	}

	@PutMapping("/sirsRates/{sirsRateId}")
	@ResponseStatus(value = HttpStatus.OK)
	public SIRSRates updateSIRSRates(@PathVariable(value = "sirsRateId") Integer sirsRateId,
			@Validated(Update.class) @RequestBody SIRSRates sirsRates) {
		sirsRates.setSirsRateId(sirsRateId);
		return sirsRatesService.updateSIRSRates(sirsRates);
	}

	@GetMapping("/sirsRates/{sirsRateId}")
	public SIRSRates getSIRSRatesBySIRSRatesId(@PathVariable(value = "sirsRateId") Integer sirsRateId) {
		return sirsRatesService.getSIRSRatesBySIRSRatesId(sirsRateId);
	}

	@GetMapping("/sirsRates")
	public List<SIRSRates> getAllSIRSRates(
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "globalRegion", required = false) Optional<String> globalRegion) {
		return sirsRatesService.getAllSIRSRates(effectiveFromDate, effectiveToDate, globalRegion);
	}

	@GetMapping("/sirsRates-date")
	public List<SIRSRates> getAllSIRSRatesDate(
			@RequestParam(value = "effectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") String effectiveDate) {
		return sirsRatesService.getAllSIRSRatesDate(effectiveDate);
	}

	@PutMapping("/sirsRates/{sirsRateId}/deactivate")
	public void deactivateSIRSRates(@Valid @PathVariable(value = "sirsRateId") Integer sirsRateId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		sirsRatesService.deactivateSIRSRates(sirsRateId, lastUpdatedBy);
	}

	@PutMapping("/sirsRates/{sirsRateId}/activate")
	public void activateSIRSRates(@Valid @PathVariable(value = "sirsRateId") Integer sirsRateId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		sirsRatesService.activateSIRSRates(sirsRateId, lastUpdatedBy);
	}

	@GetMapping("/sirsRates/list")
	public SIRSRatesResponse getAllSIRSRates(Pageable pageable,
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "globalRegion", required = false) Optional<String> globalRegion) {
		SIRSRates sirsRates = new SIRSRates();
		if (OptionalUtil.isPresent(effectiveFromDate)) {
			sirsRates.setEffectiveFromDate(effectiveFromDate);
		}
		if (OptionalUtil.isPresent(effectiveToDate)) {
			sirsRates.setEffectiveFromDate(effectiveToDate);
		}
		sirsRates.setGlobalRegion(globalRegion);
		return sirsRatesService.getAllSIRSRates(pageable, sirsRates);
	}
}
