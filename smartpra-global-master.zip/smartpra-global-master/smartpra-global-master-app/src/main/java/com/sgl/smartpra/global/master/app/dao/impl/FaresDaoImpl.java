package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.FaresDao;
import com.sgl.smartpra.global.master.app.dao.entity.FaresEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.FaresEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.FaresRepository;
import com.sgl.smartpra.global.master.model.Fares;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FaresDaoImpl extends CommonSearchDao<Fares> implements FaresDao {
 
	@Autowired
	private FaresRepository faresRepository;

	@Override
	@Cacheable(value = "fares", key = "#id")
	public Optional<FaresEntity> findById(Integer id) {
		log.info("Cacheable Fares Entity's ID= {}", id);
		return faresRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fares", key = "#faresEntity.fareId"),
			@CacheEvict(value = "faresSearch", allEntries = true) })
	public FaresEntity create(FaresEntity faresEntity) {
		return faresRepository.save(faresEntity);
	}

	@Override
	@CachePut(value = "fares", key = "#faresEntity.fareId")
	@CacheEvict(value = "faresSearch", allEntries = true)
	public FaresEntity update(FaresEntity faresEntity) {
		return faresRepository.save(faresEntity);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "fares", key = "#id"),
			@CacheEvict(value = "faresSearch", allEntries = true) })
	public void delete(Integer id) {
		faresRepository.deleteById(id);
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String tariffCode,
			String cxrCode, String originCity, String destinationCity, String fareBasis) {
		return faresRepository.count(Specification.where(FaresEntitySpecification.equalsTariffCode(tariffCode)
				.and(FaresEntitySpecification.equalsCxrCode(cxrCode))
				.and(FaresEntitySpecification.equalsOriginCity(originCity))
				.and(FaresEntitySpecification.equalsDestinationCity(destinationCity))
				.and(FaresEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(FaresEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.or(FaresEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate)))
				.and(FaresEntitySpecification.equalsFareBasis(fareBasis))
				));
	}

	@Override
	public long getOverLapRecordCount(String tariffCode, String cxrCode, String originCity, String destinationCity,
			String fareBasis) {
		return faresRepository.count(Specification.where(FaresEntitySpecification.equalsTariffCode(tariffCode)
				.and(FaresEntitySpecification.equalsCxrCode(cxrCode))
				.and(FaresEntitySpecification.equalsOriginCity(originCity))
				.and(FaresEntitySpecification.equalsDestinationCity(destinationCity))
				.and(FaresEntitySpecification.equalsFareBasis(fareBasis))));
	}

	@Override
	public List<FaresEntity> findAll() {
		return faresRepository.findAll();
	}

	@Override
	public List<FaresEntity> search(Optional<String> cxrCode, Optional<String> originCity,
			Optional<String> destinationCity, Optional<String> effectiveFromDate, Optional<String> effectiveToDate) {
		return faresRepository
				.findAll(FaresEntitySpecification.search(cxrCode, originCity, destinationCity, effectiveFromDate, effectiveToDate));
	}

	@Override
	public List<FaresEntity> getFareForFareSelectionProcessing(Optional<String> cxrCode, Optional<String> originCity,
			Optional<String> destinationCity, Optional<String> effectiveDate) {
		return faresRepository.findAll(FaresEntitySpecification.getFareForFareSelectionProcessing(cxrCode, originCity,
				destinationCity, effectiveDate));
	}

	@Override
	public List<FaresEntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate) {
		return faresRepository
				.findAll((FaresEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate))
						.or(FaresEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
						.or(FaresEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate))
						.and(FaresEntitySpecification.isActive()));

	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String tariffCode, String cxrCode, String originCity, String destinationCity,
			String fareBasis, Integer fareId) {
		return faresRepository.count(Specification.where(FaresEntitySpecification.equalsTariffCode(tariffCode)
				.and(FaresEntitySpecification.equalsCxrCode(cxrCode))
				.and(FaresEntitySpecification.equalsOriginCity(originCity))
				.and(FaresEntitySpecification.equalsDestinationCity(destinationCity))
				.and(FaresEntitySpecification.equalsFareBasis(fareBasis))
				.and(FaresEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(FaresEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.or(FaresEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate)))
				.and(FaresEntitySpecification.notEqualsFaresId(fareId))));
	}

}
