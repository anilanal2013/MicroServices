package com.sgl.smartpra.global.master.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.repository.entity.UserAreaEntity;

@Repository
public interface UserAreaRepository
		extends JpaRepository<UserAreaEntity, Integer>, JpaSpecificationExecutor<UserAreaEntity> {

	List<UserAreaEntity> findByUserAreaCode(String userAreaCode);

	@Query("select g from UserAreaEntity g  where g.userAreaCode= :userAreaCode AND g.areaKey1= :areaKey1 AND   "
			+ "g.areaKey2= :areaKey2 AND g.areaKey3= :areaKey3 AND g.areaKey4= :areaKey4 AND g.isActive=1")
	UserAreaEntity getUniqueRecord(@Param("userAreaCode") String userAreaCode, @Param("areaKey1") String areaKey1,
			@Param("areaKey2") String areaKey2, @Param("areaKey3") String areaKey3, @Param("areaKey4") String areaKey4);

	@Transactional
	@Modifying
	@Query("delete from UserAreaEntity g where g.areaKey1= ?1 AND g.areaKey2= ?2 AND g.areaKey3= ?3")
	void deleteUserArea(String areaKey1, String areaKey2, String areaKey3);

}
