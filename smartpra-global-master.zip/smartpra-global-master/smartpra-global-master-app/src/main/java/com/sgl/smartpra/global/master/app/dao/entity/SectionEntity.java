package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_misc_section")
@Data
@EqualsAndHashCode(callSuper=false)
@DynamicInsert
@DynamicUpdate
public class SectionEntity extends BaseEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "section_mas_id")
	private Integer sectionMasterId;

	@Column(name = "section_code", nullable = false, length = 6)
	@NotEmpty
	private String sectionCode;

	@Column(name = "section_name", nullable = false, length = 50)
	@NotEmpty
	private String sectionName;

	@Column(name = "charge_code", nullable = false, length = 6)
	@NotEmpty
	private String chargeCode;

	@Column(name = "section_name_actual", length = 50)
	private String sectionNameActual;

	@Column(name = "section_order_no")
	private double sectionOrderNumber;

	@Column(name = "min_occurrence")
	private Integer minOccurrence;

	@Column(name = "max_occurrence")
	private Integer maxOccurrence;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
