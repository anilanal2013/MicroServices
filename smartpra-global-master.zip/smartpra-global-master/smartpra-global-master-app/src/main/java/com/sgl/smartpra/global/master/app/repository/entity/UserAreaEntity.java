package com.sgl.smartpra.global.master.app.repository.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "global_mas_user_area")
public class UserAreaEntity {

	@Id
	@Column(name = "global_mas_user_area_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer globalUserAreaId;

	@Column(name = "user_area_code", nullable = false, length = 3)
	private String userAreaCode;

	@Column(name = "area_key1", nullable = false, length = 1)
	private String areaKey1;

	@Column(name = "area_key2", nullable = false, length = 5)
	private String areaKey2;

	@Column(name = "area_key3", nullable = false, length = 5)
	private String areaKey3;

	@Column(name = "area_key4", nullable = false, length = 5)
	private String areaKey4;

	@Column(name = "user_area_name", nullable = false, length = 30)
	private String userAreaName;

	@Column(name = "area_include_list", length = 1000)
	private String areaIncludeList;

	@Column(name = "area_exclude_list", length = 1000)
	private String areaExcludeList;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "created_by", nullable = false, length = 15)
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;

	@Column(name = "last_updated_by", nullable = true, length = 15)
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	public Integer getGlobalUserAreaId() {
		return globalUserAreaId;
	}

	public void setGlobalUserAreaId(Integer globalUserAreaId) {
		this.globalUserAreaId = globalUserAreaId;
	}

	public String getUserAreaCode() {
		return userAreaCode;
	}

	public void setUserAreaCode(String userAreaCode) {
		this.userAreaCode = userAreaCode;
	}

	public String getAreaKey1() {
		return areaKey1;
	}

	public void setAreaKey1(String areaKey1) {
		this.areaKey1 = areaKey1;
	}

	public String getAreaKey2() {
		return areaKey2;
	}

	public void setAreaKey2(String areaKey2) {
		this.areaKey2 = areaKey2;
	}

	public String getAreaKey3() {
		return areaKey3;
	}

	public void setAreaKey3(String areaKey3) {
		this.areaKey3 = areaKey3;
	}

	public String getAreaKey4() {
		return areaKey4;
	}

	public void setAreaKey4(String areaKey4) {
		this.areaKey4 = areaKey4;
	}

	public String getUserAreaName() {
		return userAreaName;
	}

	public void setUserAreaName(String userAreaName) {
		this.userAreaName = userAreaName;
	}

	public String getAreaIncludeList() {
		return areaIncludeList;
	}

	public void setAreaIncludeList(String areaIncludeList) {
		this.areaIncludeList = areaIncludeList;
	}

	public String getAreaExcludeList() {
		return areaExcludeList;
	}

	public void setAreaExcludeList(String areaExcludeList) {
		this.areaExcludeList = areaExcludeList;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}