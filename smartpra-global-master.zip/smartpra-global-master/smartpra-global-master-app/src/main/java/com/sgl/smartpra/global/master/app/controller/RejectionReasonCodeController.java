package com.sgl.smartpra.global.master.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.RejectionReasonCodeService;
import com.sgl.smartpra.global.master.model.RejectionReasonCode;

import java.util.List;


@RestController
public class RejectionReasonCodeController {

	@Autowired
	RejectionReasonCodeService rejectionReasonCodeService;
	
	@GetMapping("/rejectionReasonCode/{id}")
	public RejectionReasonCode getAllCodeId(
			@Valid @PathVariable(value = "id") String id
			){
		
		return rejectionReasonCodeService.getRejectionReasonCode(id);
	}

	@GetMapping("/rejectionReasonCode")
	public List<RejectionReasonCode> fetchAllRejectionCodes(){
		return rejectionReasonCodeService.fetchAllRejectionCode();
	}



}
