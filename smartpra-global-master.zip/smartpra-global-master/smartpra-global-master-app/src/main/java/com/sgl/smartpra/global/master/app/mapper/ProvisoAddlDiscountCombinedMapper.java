package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountEntity;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscountStg;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoAddlDiscountCombinedMapper extends BaseMapper<ProvisoAdditionalDiscountStg, ProvisoAdditionalDiscountEntity> {
	ProvisoAdditionalDiscountEntity mapToEntity(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg,
			@MappingTarget ProvisoAdditionalDiscountEntity provisoAdditionalDiscountEntity);
	ProvisoAdditionalDiscountEntity mapToEntity(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg);
}