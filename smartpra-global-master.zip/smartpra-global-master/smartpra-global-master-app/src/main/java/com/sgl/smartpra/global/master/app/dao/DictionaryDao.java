package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.repository.entity.DictionaryEntity;

public interface DictionaryDao {

	public Optional<DictionaryEntity> findById(Integer dictionaryId);

	public DictionaryEntity create(DictionaryEntity dictionaryEntity);

	public DictionaryEntity update(DictionaryEntity dictionaryEntity);
	
	public DictionaryEntity getDictionaryByElementName(String elementName);
	
	void deleteById(Integer id);
	
	public List<DictionaryEntity> getAllDictionarys(Optional<String> elementName, Optional<String> dictionaryDefine);

}
