package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.RejectionReasonCodeEntity;
import com.sgl.smartpra.global.master.model.RejectionReasonCode;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface RejectionReasonCodeMapper extends BaseMapper<RejectionReasonCode, RejectionReasonCodeEntity> {

	RejectionReasonCodeEntity mapToEntity(RejectionReasonCode rejectionReasonCode, @MappingTarget RejectionReasonCodeEntity rejectionReasonCodeEntity);

	@Mapping(source = "rejectionReasonCode", target = "rejectionReasonCode", ignore = true)
	RejectionReasonCodeEntity mapToEntity(RejectionReasonCode rejectionReasonCode);

}
