package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.OneCountryService;
import com.sgl.smartpra.global.master.model.OneCountry;

@RestController
@RequestMapping("/one-country")
public class OneCountryController {

	@Autowired
	private OneCountryService oneCountryService;

	@PostMapping
	@ResponseStatus(value = HttpStatus.CREATED)
	public OneCountry createOneCountry(@Validated(Create.class) @RequestBody OneCountry oneCountry) {
		return oneCountryService.createOneCountry(oneCountry);
	}

	@PutMapping("/{oneCountryId}")
	@ResponseStatus(value = HttpStatus.OK)
	public OneCountry updateOneCountry(@PathVariable(value = "oneCountryId") Integer oneCountryId,
			@Validated(Update.class) @RequestBody OneCountry oneCountry) {
		oneCountry.setOneCountryId(oneCountryId);
		return oneCountryService.updateOneCountry(oneCountryId, oneCountry);
	}

	@GetMapping("/{oneCountryCode}/{effectiveDate}")
	public List<OneCountry> getOneCountryByEffectiveDate(
			@PathVariable(value = "oneCountryCode") Optional<String> oneCountryCode,
			@PathVariable(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return oneCountryService.getOneCountryByEffectiveDate(oneCountryCode, effectiveDate);
	}
	
	@GetMapping("/{oneCountryId}")
	public OneCountry getOneCountryByOneCountryId(
			@PathVariable(value = "oneCountryId") Integer oneCountryId) {
		return oneCountryService.getOneCountryByOneCountryId(oneCountryId);
	}

	@GetMapping("/search")
	public List<OneCountry> search(
			@RequestParam(name = "oneCountryCode", required = false) Optional<String> oneCountryCode,
			@RequestParam(name = "countryCodeList", required = false) Optional<String> countryCodeList,
			@RequestParam(name = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(name = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(name = "isActive", required = false) Optional<Boolean> isActive) {
		return oneCountryService.search(oneCountryCode, countryCodeList, effectiveFromDate, effectiveToDate, isActive);
	}

	@GetMapping("/countryCode/{countryCode}/effectiveDate/{effectiveDate}")
	public OneCountry getOneCountryByOneCountryCode(@PathVariable(value = "countryCode") Optional<String> countryCode,
			@PathVariable(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return oneCountryService.getOneCountryByOneCountryCode(countryCode, effectiveDate);
	}

	@PutMapping("/{oneCountryId}/deactivate")
	public void deactivateOneCountry(@Valid @PathVariable(value = "oneCountryId") Integer oneCountryId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		OneCountry oneCountry = new OneCountry();
		oneCountry.setOneCountryId(oneCountryId);
		oneCountry.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		oneCountryService.deactivateOneCountry(oneCountry);
	}

	@PutMapping("/{oneCountryId}/activate")
	public void activateOneCountry(@Valid @PathVariable(value = "oneCountryId") Integer oneCountryId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		OneCountry oneCountry = new OneCountry();
		oneCountry.setOneCountryId(oneCountryId);
		oneCountry.setLastUpdatedBy(Optional.ofNullable(lastUpdatedBy));
		oneCountryService.activateOneCountry(oneCountry);
	}

}
