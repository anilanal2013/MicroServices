package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.AirportEntity;
import com.sgl.smartpra.global.master.app.dao.entity.CurrencyDetailEntity;

@Repository
public interface CurrencyDetailRepository extends JpaRepository<CurrencyDetailEntity, Integer>, JpaSpecificationExecutor<CurrencyDetailEntity> {

	@Query(value = "select a from CurrencyDetailEntity a  where  a.currencyCode = ?1")
	List<CurrencyDetailEntity> getAllCurrencyEntityByEffectiveDate(@Param("currencyCode")String currencyCode);
	
	@Query(value = "select a from CurrencyDetailEntity a  where (?2 between a.effectiveFromDate  AND a.effectiveToDate) and a.currencyCode = ?1")
	List<CurrencyDetailEntity> getAllCurrencyEntityByEffectiveDateAndCurrencyCode(@Param("currencyCode")String currencyCode, @Param("effectiveDate")Date effectiveDate);

}
