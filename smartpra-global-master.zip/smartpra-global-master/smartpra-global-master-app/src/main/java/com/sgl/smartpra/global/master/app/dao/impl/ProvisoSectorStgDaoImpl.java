package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoSectorStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoSectorStgEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoSectorStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoSectorStgDaoImpl implements ProvisoSectorStgDao {
	@Autowired
	private ProvisoSectorStgRepository provisoSectorStgRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "provisoSectorStgModel", key = "#provisoSectorStgEntity.provisoSectorId") })
	public ProvisoSectorStgEntity create(ProvisoSectorStgEntity provisoSectorStgEntity) {
		return provisoSectorStgRepository.save(provisoSectorStgEntity);
	}

	@Override
	public List<ProvisoSectorStgEntity> findByMainId(Optional<Integer> provisoMainId) {
		log.info("Cacheable Proviso Sector Entity's ID= {}", provisoMainId);

		return provisoSectorStgRepository.findAll(ProvisoSectorStgEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	@Cacheable(value = "provisoSectorStgModel", key = "#provisoSectorId")
	public Optional<ProvisoSectorStgEntity> findById(Integer provisoSectorId) {
		log.info("Cacheable Proviso Sector Entity's ID= {}", provisoSectorId);
		return provisoSectorStgRepository.findById(provisoSectorId);
	}

	@Override
	public List<ProvisoSectorStgEntity> searchByProvisoInMain(Optional<Integer> provisoMainId,
			Optional<String> areaFrom) {
		return provisoSectorStgRepository
				.findAll(ProvisoSectorStgEntitySpecification.searchByProMain(provisoMainId, areaFrom));
	}

	@Override
	public List<ProvisoSectorStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {

		return provisoSectorStgRepository
				.findAll(ProvisoSectorStgEntitySpecification.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	@CachePut(value = "provisoSectorStgModel", key = "#provisoSectorStgEntity.provisoSectorId")
	@CacheEvict(value = "ProvisoSectorSearch", allEntries = true)
	public ProvisoSectorStgEntity update(ProvisoSectorStgEntity provisoSectorStgEntity) {
		return provisoSectorStgRepository.save(provisoSectorStgEntity);
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer sectionRecNumber) {

		return provisoSectorStgRepository
				.count(Specification.where(ProvisoSectorStgEntitySpecification.equalsCarrierNumCode(carrierNumCode)
						.and(ProvisoSectorStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
						.and(ProvisoSectorStgEntitySpecification.equalsSectionRecNumber(sectionRecNumber))));
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer sectionRecNumber,
			Integer provisoSectorId) {

		return provisoSectorStgRepository
				.count(Specification.where(ProvisoSectorStgEntitySpecification.equalsCarrierNumCode(carrierNumCode)
						.and(ProvisoSectorStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
						.and(ProvisoSectorStgEntitySpecification.equalsSectionRecNumber(sectionRecNumber))
						.and(ProvisoSectorStgEntitySpecification.notEqualsProvisoSectorId(provisoSectorId))));
	}

	@Override
	public List<ProvisoSectorStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> sectionRecNumber) {

		return provisoSectorStgRepository.findAll(
				ProvisoSectorStgEntitySpecification.search(carrierNumCode, provisoSeqNumber, sectionRecNumber));
	}

	@Override
	public List<Integer> getListOfProvisoMainIdFromSectorStgDb() {

		return provisoSectorStgRepository.getListOfProvisoMainIdFromSectorStgDb();
	}

	@Override
	public void deleteProvisoSectorByProvisoMainId(Integer provisoMainId) {
		provisoSectorStgRepository.deleteProvisoSectorByProvisoMainId(provisoMainId);
	}

	@Override
	public void deleteProvisoSectorByProvisoSectorId(Integer provisoSectorId) {
		provisoSectorStgRepository.deleteById(provisoSectorId);
	}

	@Override
	public Integer getMaxOfProvisoSecRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {

		return provisoSectorStgRepository.getMaxOfProvisoSecRecNumber(carrierNumCode, provisoSeqNumber);
	}
}
