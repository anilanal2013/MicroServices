package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.repository.entity.MPREntity;
import com.sgl.smartpra.global.master.model.MPR;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface MPRMapper extends BaseMapper<MPR, MPREntity> {

	MPREntity mapToEntity(MPR mpr, @MappingTarget MPREntity mprEntity);

	MPREntity mapToEntity(MPR mpr);

}
