package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.ProvisoCodeshareService;
import com.sgl.smartpra.global.master.model.ProvisoCodeshareModel;

@RestController
@RequestMapping("/proviso/codeshare")
public class ProvisoCodeshareController {
	@Autowired
	ProvisoCodeshareService provisoCodeshareService;

	@GetMapping("/{provisoCodeshareId}")
	public ProvisoCodeshareModel getProvisoCodeshareByProvisoCodeshareId(
			@PathVariable(value = "provisoCodeshareId") Integer provisioCodeshareId) {
		return provisoCodeshareService.getProvisoCodeshareByProvisoCodeshareId(provisioCodeshareId);
	}
	
	@GetMapping("provisoMain/{provisoMainId}")
	public List<ProvisoCodeshareModel> getProvisoCodeshareByProvisoMainId(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId) {
		return provisoCodeshareService.getProvisoCodeshareByProvisoMainId(provisoMainId);
	}

	@GetMapping("/{provisoMainId}/{areaFrom}/{areaTo}")
	public List<ProvisoCodeshareModel> searchByProvisoMain(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@PathVariable(value = "areaFrom") Optional<String> areaFrom,
			@PathVariable(value = "areaTo") Optional<String> areaTo) {
		return provisoCodeshareService.searchByProvisoMain(provisoMainId, areaFrom, areaTo);
	}

	@GetMapping("/search")
	public List<ProvisoCodeshareModel> search(
			@RequestParam(name = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@RequestParam(name = "provisoSeqNumber", required = false) Optional<Integer> provisoSeqNumber,
			@RequestParam(name = "provisoSection", required = false) Optional<String> provisoSection,
			@RequestParam(name = "areaFrom", required = false) Optional<String> areaFrom,
			@RequestParam(name = "areaTo", required = false) Optional<String> areaTo) {
		return provisoCodeshareService.search(carrierNumCode, provisoSeqNumber, provisoSection, areaFrom, areaTo);
	}

}
