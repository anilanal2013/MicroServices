package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.CurrencyDao;
import com.sgl.smartpra.global.master.app.dao.entity.AirportEntity;
import com.sgl.smartpra.global.master.app.dao.entity.CurrencyEntity;
import com.sgl.smartpra.global.master.app.dao.impl.CurrencyDaoImpl;
import com.sgl.smartpra.global.master.app.mapper.CurrencyMapper;
import com.sgl.smartpra.global.master.app.repository.CurrencyRepository;
import com.sgl.smartpra.global.master.app.service.CurrencyService;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.Currency;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class CurrencyServiceImpl implements CurrencyService {

	@Autowired
	CurrencyRepository currencyRepository;

	@Autowired
	CurrencyMapper currencyMapper;

	@Autowired
	CurrencyDao currencyDao;

	@Autowired
	CurrencyDaoImpl currencyDaoImpl;

	private static final String CURRENCY_NUMERIC_CODE = "Currency Numeric Code should be unique";

	@Override
	public List<Currency> getAllCurrency(String currencyCode, String currencyName, Boolean isActive) {
		return currencyMapper.mapToModel(currencyDao.getAllCurrency(Optional.ofNullable(currencyCode),
				Optional.ofNullable(currencyName), Optional.ofNullable(isActive)));
	}

	@Override
	public Currency findCurrencyByCurrencyCode(String currencyCode) {
		return currencyMapper.mapToModel(currencyDao.findById(currencyCode)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(currencyCode))));
	}

	public Currency createCurrency(Currency currency) {
		Optional<CurrencyEntity> currencyEntity = currencyDao
				.findById(OptionalUtil.getValue(currency.getCurrencyCode()));
		if (currencyEntity.isPresent()) {
			throw new BusinessException("Record already exists");
		}
		if (currencyDao.validateNumericCode(OptionalUtil.getValue(currency.getCurrencyNumericCode())) != 0) {
			throw new BusinessException(CURRENCY_NUMERIC_CODE);
		}
		currency.setCreatedDate(LocalDateTime.now());
		currency.setIsActive(true);
		return currencyMapper.mapToModel(currencyDao.create(currencyMapper.mapToEntity(currency)));
	}

	public Currency updateCurrency(String currencyCode, Currency currency) {
		log.info("{}", currency);
		CurrencyEntity currencyEntity = currencyDao.findById(OptionalUtil.getValue(currency.getCurrencyCode()))
				.orElseThrow(() -> new RecordNotFoundException(OptionalUtil.getValue(currency.getCurrencyCode())));
		if (!currencyEntity.getIsActive()) {
			throw new BusinessException("Currency is not active");
		}
		if (currencyDao.validateNumericCodeForUpdate(OptionalUtil.getValue(currency.getCurrencyNumericCode()),
				currencyEntity.getCurrencyCode()) != 0) {
			throw new BusinessException(CURRENCY_NUMERIC_CODE);

		}
		currency.setIsActive(Boolean.TRUE);
		currency.setCreatedDate(LocalDateTime.now());
		return currencyMapper.mapToModel(currencyDao.update(currencyMapper.mapToEntity(currency, currencyEntity)));
	}

	public void deactivateCurrency(String currencyCode, String lastUpdatedBy) {
		CurrencyEntity currencyEntity = currencyDao.findById(currencyCode)
				.orElseThrow(() -> new RecordNotFoundException(currencyCode));
		if (!currencyEntity.getIsActive())
			throw new BusinessException("Currency is already in deactivated state");

		currencyEntity.setIsActive(Boolean.FALSE);
		currencyEntity.setLastUpdatedBy(lastUpdatedBy);
		currencyEntity.setLastUpdatedDate(LocalDateTime.now());
		currencyDao.update(currencyEntity);

	}

	public void activateCurrency(String currencyCode, String lastUpdatedBy) {
		CurrencyEntity currencyEntity = currencyDao.findById(currencyCode)
				.orElseThrow(() -> new RecordNotFoundException(currencyCode));
		if (currencyEntity.getIsActive())
			throw new BusinessException("Currency is already in active state");

		currencyEntity.setIsActive(Boolean.TRUE);
		currencyEntity.setLastUpdatedBy(lastUpdatedBy);
		currencyEntity.setLastUpdatedDate(LocalDateTime.now());
		currencyDao.update(currencyEntity);
	}

	@Override
	public boolean isValidCurrencyCode(String currencyCode) {
		boolean isValid = false;
		String currencyCodeDb = currencyRepository.getCurrencyCode(currencyCode);
		if (currencyCodeDb != null) {
			return true;
		}
		return isValid;
	}

	@Override
	public List<String> getValidCurrencyCode(List<String> currencyCodeList) {
		return currencyRepository.getCurrencyCodeList(currencyCodeList);
	}

	@Override
	public List<CommonIdName> getCurrencyList() {
		List<CommonIdName> currencyList = new ArrayList<>();
		List<CurrencyEntity> listOfCurrencies = currencyDao
				.findDistinctByCurrencyCodeIsNotNullAndIsActiveTrueOrderByCurrencyCode();
		for (CurrencyEntity objCurrency : listOfCurrencies) {
			CommonIdName currency = new CommonIdName();
			currency.setId(objCurrency.getCurrencyCode());
			currency.setName(objCurrency.getCurrencyCode()+" - "+objCurrency.getCurrencyName());
			currencyList.add(currency);
		}
		return currencyList;
	}

	@Override
	public Currency getCurrencyByCurrencyNumericCode(Integer currencyNumericCode) {
		return currencyMapper.mapToModel(currencyDao.getCurrencyByCurrencyNumericCode(currencyNumericCode)
				.orElseThrow(() -> new BusinessException("Record Not Found")));
	}
}
