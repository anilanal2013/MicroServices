package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.ProvisoAddlDiscountService;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscount;

@RestController
@RequestMapping("/proviso/additionalDiscount")
public class ProvisoAddlDiscountController {
	@Autowired
	private ProvisoAddlDiscountService provisoAddlDiscountService;
	
	@GetMapping("provisoMain/{provisoMainId}")
	public List<ProvisoAdditionalDiscount> getProvisoAddlDiscountByProvisoMainId(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId) {
		return provisoAddlDiscountService.getProvisoAddlDiscountByProvisoMainId(provisoMainId);
	}
	@GetMapping("/{provisoAddlDiscountId}")
	public ProvisoAdditionalDiscount getProvisoAddlDiscountByProvisoAddlDiscountId(
			@PathVariable(value = "provisoAddlDiscountId") Integer provisoAddlDiscountId) {
		return provisoAddlDiscountService.getProvisoAddlDiscountByProvisoAddlDiscountId(provisoAddlDiscountId);
	}
    
	@GetMapping("/proviso-addldiscount/{carrierNumCode}/{provisoSeqNumber}/{discountCode}")
	public List<ProvisoAdditionalDiscount> searchByProvisoAddlDiscount(
			@PathVariable(value = "carrierNumCode") Optional<String> carrierNumCode,
			@PathVariable(value = "provisoSeqNumber") Optional<Integer> provisoSeqNumber,
			@PathVariable(value = "discountCode") Optional<String> discountCode){
		return provisoAddlDiscountService.search(carrierNumCode, provisoSeqNumber,discountCode);
	}
}



