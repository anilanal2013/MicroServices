package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.AircraftType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.AircraftTypeDao;
import com.sgl.smartpra.global.master.app.dao.entity.AircraftTypeEntity;

import com.sgl.smartpra.global.master.app.dao.repository.AircraftTypeRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AircraftTypeDaoImpl implements AircraftTypeDao{

	@Autowired
	private AircraftTypeRepository  aircraftTypeRepository;
	
	@Override
	@Cacheable(value = "aircraftTypeEntity", key="#id")
	public Optional<AircraftTypeEntity> findById(String id) {
		log.info("Cacheable entity AircraftType {}", id);
		return aircraftTypeRepository.findById(id);
	}

	@Override
	@Caching(evict= {@CacheEvict(value="aircraftTypeEntity",key = "#aircraftTypeEntity.aircraftTypeCode")})
	public AircraftTypeEntity create(AircraftTypeEntity aircraftTypeEntity) {
		return aircraftTypeRepository.save(aircraftTypeEntity);
	}

	@Override
	@CachePut(value = "aircraftTypeEntity",key = "#aircraftTypeEntity.aircraftTypeCode")
	public AircraftTypeEntity update(AircraftTypeEntity aircraftTypeEntity) {
		return aircraftTypeRepository.save(aircraftTypeEntity);
	}

	@Override
	public List<AircraftTypeEntity> update(List<AircraftTypeEntity> aircraftTypeEntity) {
		return aircraftTypeRepository.saveAll(aircraftTypeEntity);
	}

	@Override
	public Optional<AircraftTypeEntity> findOne(Optional<String> id) {
		Optional<AircraftTypeEntity> entity = aircraftTypeRepository.findById(id.get());
		return entity;
	}

	@Override
	public List<AircraftTypeEntity> findAll() {
		return aircraftTypeRepository.findAll();
	}
}
