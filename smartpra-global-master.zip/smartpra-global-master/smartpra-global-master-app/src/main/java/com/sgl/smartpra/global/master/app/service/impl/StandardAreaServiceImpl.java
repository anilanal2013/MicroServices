package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.StandardAreaDao;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.StandardAreaMapper;
import com.sgl.smartpra.global.master.app.repository.entity.StandardAreaEntity;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.StandardAreaSrevice;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.Geo;
import com.sgl.smartpra.global.master.model.StandardArea;

@Service
@Transactional
public class StandardAreaServiceImpl implements StandardAreaSrevice {

	@Autowired
	StandardAreaMapper standardAreamapper;

	@Autowired
	StandardAreaDao standardAreaDao;

	@Autowired
	private AirportService airportService;

	@Autowired
	private CountryService countryService;

	@Autowired
	private MasterFeignClient masterFeignClient;

	public static final String CARRIERINTERLINEDETAILSID = "Standard Area details id not found";
	private static final String STANDARDAREA = "StandardArea";
	private static final String PROVIDEGEOTYPEVALUE = "Please provide Geo Type Value";
	private static final String VALUE_LENGTH = "Value Length: For ";
	private static final String INVALID_CODE = "Invalid Country Code ";
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();	
	public static final String AREA_TYPE = LOVEnum.AREA_TYPE.getLOVEnum();
	String hostCarrDesigCode;
	List<String> typeValueList = new ArrayList<>();

	@Override
	public List<StandardArea> getListOfStandardArea(Optional<String> standardAreaCode,
			Optional<String> standardAreaName, Boolean activate) {
		return standardAreamapper.mapToModel(standardAreaDao.search(standardAreaCode, standardAreaName, activate));
	}

	@Override
	public StandardArea getStandardAreaByStandardAreaCode(String standardAreaCode) {
		return standardAreamapper.mapToModel(standardAreaDao.findById(standardAreaCode)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(standardAreaCode))));
	}

	@Override
	public StandardArea createStandardArea(StandardArea standardarea) {
		if (standardarea.getStandardAreaGeoList().isEmpty()) {
			throw new BusinessException("Standard Area Geo List can not give empty");
		}
		hostCarrDesigCode = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		Optional<StandardAreaEntity> standardAreaEntity = standardAreaDao.findById(standardarea.getStandardAreaCode());
		if (standardAreaEntity.isPresent()) {
			throw new BusinessException("Record already exists");
		}

		List<Geo> geoList = standardarea.getStandardAreaGeoList();
		StringBuilder geoString = new StringBuilder();
		int geolistSize = geoList.size();
		for (Geo geo : geoList) {
			if (geo.getGeoTypeId() == null)
				throw new BusinessException("Invalid" + geo.getGeoTypeId());
			if (geo.getGeoTypeId() == 1 || geo.getGeoTypeId() == 2 || geo.getGeoTypeId() == 5) {
				if (geo.getGeoTypeId() == 1
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(VALUE_LENGTH + geo.getGeoTypeValue()
									+ " Element length should be 1 to 3 only - Standard Area ");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(PROVIDEGEOTYPEVALUE);
					}
					if (!airportService.isValidAirportCodeOrCityCode(geo.getGeoTypeValue())) {
						typeValueList.clear();
						throw new BusinessException("Invalid Airport/City Code " + geo.getGeoTypeValue());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
				} else if (geo.getGeoTypeId() == 2
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 2) {
							typeValueList.clear();
							throw new BusinessException(VALUE_LENGTH + geo.getGeoTypeValue()
									+ " Element length should be 1 to 2 only - Standard Area ");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(
								"This field GeoTypeValue " + geo.getGeoTypeValue() + " cannot be blank");
					}
					if (!countryService.isValidCountryCode(geo.getGeoTypeValue())) {
						typeValueList.clear();
						throw new BusinessException(INVALID_CODE + geo.getGeoTypeValue());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
				} else if (!typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 4) {
							typeValueList.clear();
							throw new BusinessException(VALUE_LENGTH + geo.getGeoTypeValue()
									+ " Element length should be 1 to 4 only - Standard Area ");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(PROVIDEGEOTYPEVALUE);
					}
					if (!airportService.isValidStateCode(geo.getGeoTypeValue())) {
						typeValueList.clear();
						throw new BusinessException("Invalid State Code " + geo.getGeoTypeValue());
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
				} else if (typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					typeValueList.clear();
					throw new BusinessException("Duplicate Geotype Value: " + geo.getGeoTypeValue().toUpperCase());
				}
			} else {
				throw new BusinessException("Invalid Geo type id " + geo.getGeoTypeId());
			}
			geoString.append(geo.toString());
			if (geolistSize != 1) {
				geoString.append(",");
			}
			geolistSize--;
		}
		String standardAreaList = geoString.toString();
		standardarea.setStandardAreaList(standardAreaList);
		if (geoString.length() > 250)
			throw new BusinessException(
					"Value Length: For area_include_list Element length should be 1000 only - Standard Area");
		validateAreaType(standardarea);
		typeValueList = new ArrayList<>();
		typeValueList.clear();
		standardarea.setActivate(Boolean.TRUE);
		standardarea.setCreatedDate(LocalDateTime.now());
		return standardAreamapper.mapToModel(standardAreaDao.create(standardAreamapper.mapToEntity(standardarea)));
	}

	@Override
	public StandardArea updateStandardArea(String standardAreaCode, StandardArea standardarea) {
		StandardAreaEntity standardAreaEntity = standardAreaDao.findById(standardAreaCode)
				.orElseThrow(() -> new RecordNotFoundException(standardAreaCode));
		if (!standardAreaEntity.getActivate()) {
			throw new BusinessException("Standard Area is not active");
		}
		hostCarrDesigCode = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		typeValueList.clear();
		List<Geo> geoList = standardarea.getStandardAreaGeoList();
		StringBuilder geoString = new StringBuilder();
		if (geoList != null) {
			for (Geo geo : geoList) {
				if (geo.getGeoTypeId() == 1 || geo.getGeoTypeId() == 2 || geo.getGeoTypeId() == 5) {
					if (geo.getGeoTypeId() == 1
							&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
						if (!geo.getGeoTypeValue().isEmpty()) {
							if (geo.getGeoTypeValue().length() > 3) {
								typeValueList.clear();
								throw new BusinessException(VALUE_LENGTH + geo.getGeoTypeValue()
										+ " Element length should be 1 to 3 only - Standard Area ");
							}
						} else {
							typeValueList.clear();
							throw new BusinessException(PROVIDEGEOTYPEVALUE);
						}
						if (!airportService.isValidAirportCodeOrCityCode(geo.getGeoTypeValue())) {
							typeValueList.clear();
							throw new BusinessException("Invalid Airport/City Code : " + geo.getGeoTypeValue());
						}
						typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					} else if (geo.getGeoTypeId() == 2
							&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
						if (!geo.getGeoTypeValue().isEmpty()) {
							if (geo.getGeoTypeValue().length() > 2) {
								typeValueList.clear();
								throw new BusinessException(VALUE_LENGTH + geo.getGeoTypeValue()
										+ " Element length should be 1 to 2 only - Standard Area ");
							}
						} else {
							typeValueList.clear();
							throw new BusinessException(PROVIDEGEOTYPEVALUE);
						}
						if (!countryService.isValidCountryCode(geo.getGeoTypeValue())) {
							typeValueList.clear();
							throw new BusinessException(INVALID_CODE + geo.getGeoTypeValue());
						}
						typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					} else if (!typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
						if (!geo.getGeoTypeValue().isEmpty()) {
							if (geo.getGeoTypeValue().length() > 4) {
								typeValueList.clear();
								throw new BusinessException(VALUE_LENGTH + geo.getGeoTypeValue()
										+ " Element length should be 1 to 4 only - Standard Area ");
							}
						} else {
							typeValueList.clear();
							throw new BusinessException(PROVIDEGEOTYPEVALUE);
						}
						if (!airportService.isValidStateCode(geo.getGeoTypeValue())) {
							typeValueList.clear();
							throw new BusinessException("Invalid State Code  " + geo.getGeoTypeValue());
						}
						typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					} else if (typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Duplicate Geotype Value: " + geo.getGeoTypeValue().toUpperCase());
					}

				} else {
					typeValueList.clear();
					throw new BusinessException("Invalid Geo type id :" + geo.getGeoTypeId());
				}
				geoString.append(geo.toString());
				geoString.append(",");
			}
		}
		String standardAreaList = geoString.toString();
		standardarea.setStandardAreaList(standardAreaList);
		if (OptionalUtil.isPresent(standardarea.getAreaType())) {
			validateAreaType(standardarea);
		}
		typeValueList = new ArrayList<>();
		typeValueList.clear();
		standardAreaEntity.setLastUpdatedBy(OptionalUtil.getValue(standardarea.getLastUpdatedBy()));
		standardAreaEntity.setLastUpdatedDate(LocalDateTime.now());
		return standardAreamapper
				.mapToModel(standardAreaDao.update(standardAreamapper.mapToEntity(standardarea, standardAreaEntity)));
	}

	@Override
	public void deactivateStandardArea(String standardAreaCode, String lastUpdatedBy) {
		Optional<StandardAreaEntity> standardAreaEntity = Optional
				.ofNullable(standardAreaDao.findById(standardAreaCode))
				.orElseThrow(() -> new BusinessException(CARRIERINTERLINEDETAILSID));
		if (!standardAreaEntity.isPresent())
			throw new ResourceNotFoundException(STANDARDAREA, "code", standardAreaCode);
		if (!standardAreaEntity.get().getActivate())
			throw new BusinessException("Standard Area is already in deactivated state");
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException("LastUpdatedBy should be minimum of 1 and maximum of 15 characters");
		} else {
			throw new BusinessException("Please provide LastUpdatedBy");
		}
		standardAreaEntity.get().setLastUpdatedBy(lastUpdatedBy);
		standardAreaEntity.get().setLastUpdatedDate(LocalDateTime.now());
		standardAreaEntity.get().setActivate(Boolean.FALSE);
		standardAreaDao.update(standardAreaEntity.get());
	}

	@Override
	public void activateStandardArea(String standardAreaCode, String lastUpdatedBy) {
		Optional<StandardAreaEntity> standardAreaEntity = standardAreaDao.findById(standardAreaCode);
		if (!standardAreaEntity.isPresent())
			throw new ResourceNotFoundException(STANDARDAREA, "code", standardAreaCode);
		if (standardAreaEntity.get().getActivate())
			throw new BusinessException("Standard Area is already in active state");
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() >= 15)
				throw new BusinessException("LastUpdatedBy should be minimum of 1 and maximum of 15 characters");
		} else {
			throw new BusinessException("Please provide lastupdatedby");
		}
		standardAreaEntity.get().setLastUpdatedBy(lastUpdatedBy);
		standardAreaEntity.get().setLastUpdatedDate(LocalDateTime.now());
		standardAreaEntity.get().setActivate(Boolean.TRUE);
		standardAreaDao.update(standardAreaEntity.get());
	}

	private void validateAreaType(StandardArea standardarea) {
		List<String> listOfValues = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME,	
				AREA_TYPE);
		String areaType = OptionalUtil.getValue(standardarea.getAreaType());
		if (!listOfValues.contains(areaType)) {
			throw new BusinessException("Area Type[" + areaType + "] is Not Valid");
		}
	}

	@Override
	public List<String> getStandardAreaList(Airport airport) {
		List<String> stdAreaCodeList = new ArrayList<>();
		String cityCode = null;

		String countryCode = null;
		String stateCode = null;
		if (!OptionalUtil.isPresent(airport.getCityCode())) {
			cityCode = "";
		} else {
			cityCode = "1" + OptionalUtil.getValue(airport.getCityCode());
		}
		if (!OptionalUtil.isPresent(airport.getCountryCode())) {
			countryCode = "";
		} else {
			countryCode = "2" + OptionalUtil.getValue(airport.getCountryCode());
		}
		if (!OptionalUtil.isPresent(airport.getStateCode())) {
			stateCode = "";
		} else {
			stateCode = "5" + OptionalUtil.getValue(airport.getStateCode());
		}
		List<StandardAreaEntity> stdAreaList = standardAreaDao.findByStandardAreaList(cityCode, stateCode, countryCode);
		for (StandardAreaEntity s : stdAreaList) {
			stdAreaCodeList.add(s.getStandardAreaCode());
		}
		return stdAreaCodeList;
	}

	@Override
	public boolean isValidateStandardArea(String standardAreaCode) {
		if ((standardAreaDao.isValidateStandardArea(standardAreaCode) > 0)) {
			return true;
		}
		return false;
	}
	
	@Override
	public List<CommonIdName> getStandardAreaList() {
		
		List<CommonIdName> standardAreaList = new ArrayList<>();
		List<StandardAreaEntity> listOfStandardArea = standardAreaDao
				.findDistinctByStandardAreaCodeIsNotNullAndIsActiveTrueOrderByStandardAreaCode();
		for (StandardAreaEntity objStandard : listOfStandardArea) {
			CommonIdName standardArr = new CommonIdName();
			standardArr.setId(objStandard.getStandardAreaCode());
			standardArr.setName(objStandard.getStandardAreaCode()+" - "+objStandard.getStandardAreaName().trim());
			standardAreaList.add(standardArr);
		}

		return standardAreaList;
	}

	@Override
	public Boolean getActiveStandardAreaByStandardAreaCode(String standardAreaCode) {
		StandardAreaEntity standardAreaEntity = standardAreaDao.findByStandardAreaCodeAndActivate(standardAreaCode);
		if(standardAreaEntity!= null) {
		return  true;
		}else {
		return false;
		}
	}

}