package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.ChargeCategoryDao;
import com.sgl.smartpra.global.master.app.dao.entity.ChargeCategoryEntity;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.ChargeCategoryMapper;
import com.sgl.smartpra.global.master.app.service.ChargeCategoryService;
import com.sgl.smartpra.global.master.model.ChargeCategory;

@Service
@Transactional
public class ChargeCategoryServiceImpl<E> implements ChargeCategoryService {

	@Autowired
	private ChargeCategoryMapper chargeCategoryMapper;

	@Autowired
	private ChargeCategoryDao chargeCategoryDao;

	@Autowired
	private MasterFeignClient masterFeignClient;

	String hostCarrDesigCode;
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String COLUMN_NAME = LOVEnum.FINANCIAL_TRN_TYPE.getLOVEnum();

	public ChargeCategory createChargeCategory(ChargeCategory chargeCategory) {
		Optional<ChargeCategoryEntity> chargeCategoryEntity = chargeCategoryDao
				.findId(chargeCategory.getChargeCategoryCode());
		if (chargeCategoryEntity.isPresent()) {
			throw new ServiceException("Charge Category code has been already created");
		}
		if (OptionalUtil.isPresent(chargeCategory.getFinancialTransactionType())) {
			validateFinancialDocType(OptionalUtil.getValue(chargeCategory.getFinancialTransactionType()));
		} else {
			chargeCategory.setFinancialTransactionType(Optional.ofNullable("INV"));
		}
		validateLocationRequiredIndicator(chargeCategory);
		validatePoNumberRequiredIndicator(chargeCategory);
		chargeCategory.setActivate(Boolean.TRUE);
		chargeCategory.setCreatedDate(LocalDateTime.now());
		return chargeCategoryMapper
				.mapToModel(chargeCategoryDao.create(chargeCategoryMapper.mapToEntity(chargeCategory)));
	}

	@Override
	public ChargeCategory getChargeCategoryByChargeCategoryCode(Optional<String> chargeCategoryCode) {
		return chargeCategoryMapper.mapToModel(chargeCategoryDao.findId(chargeCategoryCode)
				.orElseThrow(() -> new RecordNotFoundException(OptionalUtil.getValue(chargeCategoryCode))));
	}

	@Override
	public ChargeCategory getChargeCategoryByChargeCategoryName(Optional<String> chargeCategoryName) {
		return chargeCategoryMapper.mapToModel(chargeCategoryDao.findByChargeCategoryName(chargeCategoryName)
				.orElseThrow(() -> new RecordNotFoundException(OptionalUtil.getValue(chargeCategoryName))));
	}

	@Override
	public List<ChargeCategory> getAllChargeCategory(Optional<String> chargeCategoryCode,
			Optional<String> chargeCategoryName, Optional<Boolean> activate) {
		return chargeCategoryMapper
				.mapToModel(chargeCategoryDao.findAll(chargeCategoryCode, chargeCategoryName, activate));
	}

	@Override
	public List<ChargeCategory> updateChargeCategroy(List<ChargeCategory> chargeCategory) {
		List<ChargeCategoryEntity> entityList = new ArrayList<ChargeCategoryEntity>();
		for (ChargeCategory chargeCate : chargeCategory) {
			ChargeCategoryEntity chargeCategoryEntity = chargeCategoryDao.findOne(chargeCate.getChargeCategoryCode())
					.orElseThrow(() -> new RecordNotFoundException(
							OptionalUtil.getValue(chargeCate.getChargeCategoryCode())));
			ChargeCategoryEntity mapToEntity = chargeCategoryMapper.mapToEntity(chargeCate, chargeCategoryEntity);
			entityList.add(mapToEntity);
		}
		chargeCategory.stream().forEach((chargeCat) -> {
			if (OptionalUtil.isPresent(chargeCat.getFinancialTransactionType())) {
				validateFinancialDocType(OptionalUtil.getValue(chargeCat.getFinancialTransactionType()));
			}
		});
		return chargeCategoryMapper.mapToModel(chargeCategoryDao.update(entityList));
	}

	@Override
	public void deactivateChargeCategory(Optional<String> chargeCategoryCode, Optional<String> lastUpdatedBy) {
		ChargeCategoryEntity chargeCategoryEntity = chargeCategoryDao.findId(chargeCategoryCode)
				.orElseThrow(() -> new RecordNotFoundException(OptionalUtil.getValue(chargeCategoryCode)));
		if (!OptionalUtil.isPresent(lastUpdatedBy)) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (OptionalUtil.getValue(lastUpdatedBy).length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}
		if (!chargeCategoryEntity.getActivate())
			throw new ServiceException("Charge Category Code is already in deactived state");
		chargeCategoryEntity.setActivate(Boolean.FALSE);
		chargeCategoryEntity.setLastUpdatedBy(OptionalUtil.getValue(lastUpdatedBy));
		chargeCategoryEntity.setLastUpdatedDate(LocalDateTime.now());
		chargeCategoryDao.update(chargeCategoryEntity);
	}

	@Override
	public void activateChargeCategory(Optional<String> chargeCategoryCode, Optional<String> lastUpdatedBy) {
		ChargeCategoryEntity chargeCategoryEntity = chargeCategoryDao.findId(chargeCategoryCode)
				.orElseThrow(() -> new RecordNotFoundException(OptionalUtil.getValue(chargeCategoryCode)));
		if (!OptionalUtil.isPresent(lastUpdatedBy)) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (OptionalUtil.getValue(lastUpdatedBy).length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}
		if (chargeCategoryEntity.getActivate())
			throw new ServiceException("Charge Category Code is already in active state");
		chargeCategoryEntity.setActivate(Boolean.TRUE);
		chargeCategoryEntity.setLastUpdatedBy(OptionalUtil.getValue(lastUpdatedBy));
		chargeCategoryEntity.setLastUpdatedDate(LocalDateTime.now());
		chargeCategoryDao.update(chargeCategoryEntity);

	}

	private void validateFinancialDocType(String financialTranctionType) {
		hostCarrDesigCode = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		List<String> financialType = masterFeignClient.getListOfValues(hostCarrDesigCode, TABLENAME, COLUMN_NAME);
		System.out.println(financialType);
		if (!(financialType.contains(financialTranctionType))) {
			throw new ServiceException("financialTranctionType[" + financialTranctionType + "] is Not Valid");
		}
	}

	private void validatePoNumberRequiredIndicator(ChargeCategory chargeCategory) {
		if (!OptionalUtil.isPresent(chargeCategory.getPoNumberRequiredIndicator())) {
			chargeCategory.setPoNumberRequiredIndicator(Optional.ofNullable(Boolean.TRUE));
		}
	}

	private void validateLocationRequiredIndicator(ChargeCategory chargeCategory) {
		if (!OptionalUtil.isPresent(chargeCategory.getLocationRequiredIndicator())) {
			chargeCategory.setLocationRequiredIndicator(Optional.ofNullable(Boolean.FALSE));
		}
	}

	@Override
	public ChargeCategory getChargeCategoryByChargeCatCode(String chargeCategoryCode) {
		return chargeCategoryMapper.mapToModel(chargeCategoryDao.findOne(Optional.of(chargeCategoryCode))
				.orElseThrow(() -> new RecordNotFoundException(chargeCategoryCode)));
	}

	@Override
	public List<String> getChargeCatCodeFromChargeCatMaster() {
		// TODO Auto-generated method stub
		return chargeCategoryDao.getChargeCatCodeFromChargeCatMaster();
	}
}