package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ProvisoCodeshareStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoMainStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;
import com.sgl.smartpra.global.master.app.mapper.ProvisoCodeshareStgMapper;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CarrierService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.ProvisoCodeshareStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoMainStgService;
import com.sgl.smartpra.global.master.app.service.StandardAreaSrevice;
import com.sgl.smartpra.global.master.model.Geo;
import com.sgl.smartpra.global.master.model.ProvisoCodeshareStgModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoCodeshareStgServiceImpl implements ProvisoCodeshareStgService {
	
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exist";
	private static final String AIRPORTCITY = "Only alphabets are allowed for Airport/City";
	private static final String PATTERN = "^[a-zA-Z]*$";
	private static final String AIRPORTCITYINVALID = "Invalid  Airport/City code : ";
	private static final String COUNTRYCODEALPHA = "Only alphabets are allowed for country code";
	private static final String COUNTRYCODEINVALID = "Invalid  country code : ";
	private static final String CARRIER = "Invalid Code share cxr : ";
	private static final String GLOBAL = "global";
	private static final String PROVISO_CODESHARE_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN = "CarierNumCode of Proviso Codeshare should be similar to CarierNumCode of Proviso Main Corresponding to Proviso Main Id";
	private static final String CODESHARE_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso CodeShare data not available for selected Proviso Main record";
	private static final String CODESHARE_SINGLE_RECORD = "Please delete Proviso Main record";
	private static final String VALID_AREA_FROM = "Please provide valid Area From" ;
	private static final String VALID_AREA_TO = "Please provide valid Area To";
	private static final String VALIDATE_AREAFROM_TO = "Between Area From and To should not be same" ;
	
	@Autowired
	private ProvisoCodeshareStgDao provisoCodeshareStgDao;
	
	@Autowired
	private ProvisoMainStgDao provisoMainStgDao;

	@Autowired
	private ProvisoCodeshareStgMapper provisoCodeshareStgMapper;

	@Autowired
	private AirportService airportService;

	@Autowired
	private CountryService countryService;
	
	@Autowired
	private CarrierService carrierService;

	@Autowired
	StandardAreaSrevice standardAreaSrevice;

	@Autowired
	private ProvisoMainStgService provisoMainStgService;

	@Override
	@Transactional(rollbackOn = BusinessException.class)
	public ProvisoCodeshareStgModel createProvisoCodeshare(ProvisoCodeshareStgModel provisoCodeshareStgModel) {
		
		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(OptionalUtil.getValue(provisoCodeshareStgModel.getProvisoMainId()))
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(OptionalUtil.getValue(provisoCodeshareStgModel.getProvisoMainId()))));
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("D"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}
		
		
		Integer codeshareRecNumber = provisoCodeshareStgDao.getMaxOfCodeshareRecNumber(provisoCodeshareStgModel.getCarrierNumCode(),provisoCodeshareStgModel.getProvisoSeqNumber());
		codeshareRecNumber = (codeshareRecNumber == null) ? Integer.valueOf(1): Integer.valueOf(codeshareRecNumber.intValue() + 1);
		provisoCodeshareStgModel.setCodeshareRecNumber(Optional.of(codeshareRecNumber));
		
		provisoCodeshareStgModel.setCreatedDate(LocalDateTime.now());
		
		validateAreaFromTo(provisoCodeshareStgModel);
		
		if (OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom()) != null) {
			validateArea(provisoCodeshareStgModel.getAreaFrom(),
					provisoCodeshareStgModel.getAreaFromInclude(), provisoCodeshareStgModel.getAreaFromExclude(),
					provisoCodeshareStgModel.getFromUserAreaName(), GLOBAL);
		}

		if (OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo()) != null) {
			validateArea(provisoCodeshareStgModel.getAreaTo(),
					provisoCodeshareStgModel.getAreaToInclude(), provisoCodeshareStgModel.getAreaToExclude(),
					provisoCodeshareStgModel.getToUserAreaName(), GLOBAL);
		}

		if (OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom()) != null) {
			provisoCodeshareStgModel
					.setAreaFrom(Optional.of(OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom())));
		}
		if (OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo()) != null) {
			provisoCodeshareStgModel
					.setAreaTo(Optional.of(OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo())));
		}
		validateBusinessConstraintsForCreate(provisoCodeshareStgModel);
		updateMainProvisoStatus(provisoMainStgEntity);
		return provisoCodeshareStgMapper.mapToModel(
				provisoCodeshareStgDao.create(provisoCodeshareStgMapper.mapToEntity(provisoCodeshareStgModel)));

	}
	
	@Transactional(rollbackOn = BusinessException.class)
	private void updateMainProvisoStatus(ProvisoMainStgEntity provisoMainStgEntity) {
		provisoMainStgDao.updateProvisoMainStg(provisoMainStgEntity);		
	}

	private void validateBusinessConstraintsForCreate(ProvisoCodeshareStgModel provisoCodeshareStgModel) {
		validateOverlapForCreate(provisoCodeshareStgModel);
		validateCarrierNumCodeByProvisoMainId(provisoCodeshareStgModel);
		validateCodeShareCXR(provisoCodeshareStgModel);
	}
	
	private void validateCodeShareCXR(ProvisoCodeshareStgModel provisoCodeshareStgModel) {
		if (StringUtils.isNotBlank(OptionalUtil.getValue(provisoCodeshareStgModel.getCodeshareCxr())) && 
			!carrierService.isValidCarrierCode(OptionalUtil.getValue(provisoCodeshareStgModel.getCodeshareCxr()))) {
			throw new BusinessException(CARRIER + OptionalUtil.getValue(provisoCodeshareStgModel.getCodeshareCxr()));
		}
	}

	private void validateCarrierNumCodeByProvisoMainId(ProvisoCodeshareStgModel provisoCodeshareStgModel) {

		String carrierNumCode = OptionalUtil.getValue((provisoMainStgService
				.getProvisoMainByprovisoMainId(OptionalUtil.getValue(provisoCodeshareStgModel.getProvisoMainId())))
						.getCarrierNumCode());

		if (!(OptionalUtil.getValue(provisoCodeshareStgModel.getCarrierNumCode()).equalsIgnoreCase(carrierNumCode))) {
			throw new BusinessException(PROVISO_CODESHARE_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN);
		}

	}

	private void validateOverlapForCreate(ProvisoCodeshareStgModel provisoCodeshareStgModel) {
		if (OptionalUtil.isPresent(provisoCodeshareStgModel.getCarrierNumCode())
				&& OptionalUtil.isPresent(provisoCodeshareStgModel.getProvisoSeqNumber())
				&& OptionalUtil.isPresent(provisoCodeshareStgModel.getProvisoSection())
				&& OptionalUtil.isPresent(provisoCodeshareStgModel.getAreaFrom())
				&& OptionalUtil.isPresent(provisoCodeshareStgModel.getAreaTo())) {
			if (provisoCodeshareStgDao.getOverlapRecordCount(
					OptionalUtil.getValue(provisoCodeshareStgModel.getCarrierNumCode()),
					OptionalUtil.getValue(provisoCodeshareStgModel.getProvisoSeqNumber()),
					OptionalUtil.getValue(provisoCodeshareStgModel.getProvisoSection()),
					OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom()),
					OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo())) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	@Override
	@Transactional(rollbackOn = BusinessException.class)
	public ProvisoCodeshareStgModel updateProvisoCodeshare(Integer provisoCodeshareId,
			ProvisoCodeshareStgModel provisoCodeshareStgModel) {

		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(OptionalUtil.getValue(provisoCodeshareStgModel.getProvisoMainId()))
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(OptionalUtil.getValue(provisoCodeshareStgModel.getProvisoMainId()))));
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}
		
		validateAreaFromTo(provisoCodeshareStgModel);
		validateCodeShareCXR(provisoCodeshareStgModel);
		
		if (OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom()) != null) {
			validateArea(provisoCodeshareStgModel.getAreaFrom(),
					provisoCodeshareStgModel.getAreaFromInclude(), provisoCodeshareStgModel.getAreaFromExclude(),
					provisoCodeshareStgModel.getFromUserAreaName(), GLOBAL);
		}

		if (OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo()) != null) {
			validateArea(provisoCodeshareStgModel.getAreaTo(),
					provisoCodeshareStgModel.getAreaToInclude(), provisoCodeshareStgModel.getAreaToExclude(),
					provisoCodeshareStgModel.getToUserAreaName(), GLOBAL);
		}

		if (OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom()) != null) {
			provisoCodeshareStgModel
					.setAreaFrom(Optional.of(OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom())));
		}
		if (OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo()) != null) {
			provisoCodeshareStgModel
					.setAreaTo(Optional.of(OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo())));
		}

		log.info("{}", provisoCodeshareStgModel);
		ProvisoCodeshareStgEntity provisoCodeshareStgEntity = provisoCodeshareStgDao.findById(provisoCodeshareId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoCodeshareId)));
		validateBusinessConstraintsForUpdate(provisoCodeshareStgModel, provisoCodeshareStgEntity);
		provisoCodeshareStgModel.setLastUpdatedDate(LocalDateTime.now());
		updateMainProvisoStatus(provisoMainStgEntity);
		return provisoCodeshareStgMapper
				.mapToModel(provisoCodeshareStgDao.update(provisoCodeshareStgMapper
						.mapToProvisoCodeshareEntity(provisoCodeshareStgModel, provisoCodeshareStgEntity)));

	}
	
	private void validateAreaFromTo(ProvisoCodeshareStgModel provisoCodeshareStgModel) {
		if (StringUtils.isNotBlank(OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom())) &&  
				!( OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom()).startsWith("1") || 
						OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom()).startsWith("2")) ) {
			throw new BusinessException(VALID_AREA_FROM);
		}
		
		if (StringUtils.isNotBlank(OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo())) &&  
				!( OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo()).startsWith("1") || 
						OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo()).startsWith("2")) ) {
			throw new BusinessException(VALID_AREA_TO);
		}
		
		if (StringUtils.isNotBlank(OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom())) && 
				StringUtils.isNotBlank(OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo())) &&
				( StringUtils.equalsIgnoreCase(OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom()), 
						OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo())) )
				){
			throw new BusinessException(VALIDATE_AREAFROM_TO);
		}
	}

	private void validateBusinessConstraintsForUpdate(ProvisoCodeshareStgModel provisoCodeshareStgModel,
			ProvisoCodeshareStgEntity provisoCodeshareStgEntity) {
		validateOverlapForUpdate(provisoCodeshareStgModel, provisoCodeshareStgEntity);
		validateCarrierNumCodeByProvisoMainId(provisoCodeshareStgModel);
	}

	private void validateOverlapForUpdate(ProvisoCodeshareStgModel provisoCodeshareStgModel,
			ProvisoCodeshareStgEntity provisoCodeshareStgEntity) {
		String carrierNumCode = getCarrierNumCode(provisoCodeshareStgModel, provisoCodeshareStgEntity);
		Integer provisoSeqNumber = getProvisoSeqNumber(provisoCodeshareStgModel, provisoCodeshareStgEntity);
		String provisoSection = getProvisoSection(provisoCodeshareStgModel, provisoCodeshareStgEntity);
		String areaFrom = getAreaFrom(provisoCodeshareStgModel, provisoCodeshareStgEntity);
		String areaTo = getAreaTo(provisoCodeshareStgModel, provisoCodeshareStgEntity);

		if (!carrierNumCode.equalsIgnoreCase(provisoCodeshareStgEntity.getCarrierNumCode())
				|| !provisoSeqNumber.equals(provisoCodeshareStgEntity.getProvisoSeqNumber())
				|| !provisoSection.equalsIgnoreCase(provisoCodeshareStgEntity.getProvisoSection())
				|| !areaFrom.equalsIgnoreCase(provisoCodeshareStgEntity.getAreaFrom())
				|| !areaTo.equalsIgnoreCase(provisoCodeshareStgEntity.getAreaTo())) {
			if (provisoCodeshareStgDao.getOverlapRecordCount(carrierNumCode, provisoSeqNumber, provisoSection, areaFrom,
					areaTo, provisoCodeshareStgEntity.getProvisoCodeshareId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private String getCarrierNumCode(ProvisoCodeshareStgModel provisoCodeshareStgModel,
			ProvisoCodeshareStgEntity provisoCodeshareStgEntity) {
		return OptionalUtil.isPresent(provisoCodeshareStgModel.getCarrierNumCode())
				? OptionalUtil.getValue(provisoCodeshareStgModel.getCarrierNumCode())
				: provisoCodeshareStgEntity.getCarrierNumCode();
	}

	private Integer getProvisoSeqNumber(ProvisoCodeshareStgModel provisoCodeshareStgModel,
			ProvisoCodeshareStgEntity provisoCodeshareStgEntity) {
		return OptionalUtil.isPresent(provisoCodeshareStgModel.getProvisoSeqNumber())
				? OptionalUtil.getValue(provisoCodeshareStgModel.getProvisoSeqNumber())
				: provisoCodeshareStgEntity.getProvisoSeqNumber();
	}

	private String getProvisoSection(ProvisoCodeshareStgModel provisoCodeshareStgModel,
			ProvisoCodeshareStgEntity provisoCodeshareStgEntity) {
		return OptionalUtil.isPresent(provisoCodeshareStgModel.getProvisoSection())
				? OptionalUtil.getValue(provisoCodeshareStgModel.getProvisoSection())
				: provisoCodeshareStgEntity.getProvisoSection();
	}

	private String getAreaFrom(ProvisoCodeshareStgModel provisoCodeshareStgModel,
			ProvisoCodeshareStgEntity provisoCodeshareStgEntity) {

		return OptionalUtil.isPresent(provisoCodeshareStgModel.getAreaFrom())
				? OptionalUtil.getValue(provisoCodeshareStgModel.getAreaFrom())
				: provisoCodeshareStgEntity.getAreaFrom();
	}

	private String getAreaTo(ProvisoCodeshareStgModel provisoCodeshareStgModel,
			ProvisoCodeshareStgEntity provisoCodeshareStgEntity) {

		return OptionalUtil.isPresent(provisoCodeshareStgModel.getAreaTo())
				? OptionalUtil.getValue(provisoCodeshareStgModel.getAreaTo())
				: provisoCodeshareStgEntity.getAreaTo();
	}

	@Override
	public List<ProvisoCodeshareStgModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> provisoSection, Optional<String> areaFrom, Optional<String> areaTo) {

		return provisoCodeshareStgMapper.mapToModel(
				provisoCodeshareStgDao.search(carrierNumCode, provisoSeqNumber, provisoSection, areaFrom, areaTo));

	}

	@Override
	public List<ProvisoCodeshareStgModel> searchByProvisoMain(Optional<Integer> provisoMainId,
			Optional<String> areaFrom, Optional<String> areaTo) {

		return provisoCodeshareStgMapper
				.mapToModel(provisoCodeshareStgDao.searchByProvisoMain(provisoMainId, areaFrom, areaTo));

	}

	@Override
	public ProvisoCodeshareStgModel getProvisoCodeshareByProvisoCodeshareId(Integer provisoCodeshareId) {
		return provisoCodeshareStgMapper.mapToModel(provisoCodeshareStgDao.findById(provisoCodeshareId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoCodeshareId))));
	}

	@Override
	public List<ProvisoCodeshareStgModel> getProvisoCodeshareByProvisoMainId(Optional<Integer> provisoMainId) {
		List<Integer> provisoMainIdFromDb = provisoCodeshareStgDao.getListOfProvisoMainIdFromCodeshareStgDb();
		if (!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))) {
			throw new BusinessException(CODESHARE_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		return provisoCodeshareStgMapper.mapToModel(provisoCodeshareStgDao.findByMainId(provisoMainId));
	}

	
	public String[] validateArea(Optional<String> geoArea, List<Geo> list, List<Geo> list2, String userAreaName,
			String area) {

		String[] array = new String[2];

		if (OptionalUtil.getValue(geoArea).startsWith("1") || OptionalUtil.getValue(geoArea).startsWith("2")) {
			if (list != null || list2 != null || userAreaName != null) {
				throw new BusinessException("For " + OptionalUtil.getValue(geoArea)
						+ " IncludeArea, ExcludeArea and userAreaName not required for non User Defined Area");
			}
		}
		if (OptionalUtil.getValue(geoArea) != null) {
			if (OptionalUtil.getValue(geoArea).startsWith("1")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(AIRPORTCITY);
				} else {
					if (!airportService.isValidAirportCodeOrCityCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(AIRPORTCITYINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("2")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(COUNTRYCODEALPHA);
				} else {
					if (!countryService.isValidCountryCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(COUNTRYCODEINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			}
		}
		return array;
	}

	@Override
	public void deleteProvisoCodehareByProvisoMainId(Integer provisoMainId) {
		provisoCodeshareStgDao.deleteProvisoCodehareByProvisoMainId(provisoMainId);

	}

	@Override
	public void deleteProvisoCodehareByProvisoCodeshareId(Integer provisoCodeshareId) {
		ProvisoCodeshareStgEntity codeShare = provisoCodeshareStgDao.findById(provisoCodeshareId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoCodeshareId)));
		
			Integer mainId = codeShare.getProvisoMainId();
			List<ProvisoCodeshareStgEntity> codeShareList = provisoCodeshareStgDao.findByMainId(Optional.of(mainId));
			
		if (Objects.nonNull(codeShareList) && codeShareList.size() > 1) {
			provisoCodeshareStgDao.deleteProvisoCodehareByProvisoCodeshareId(provisoCodeshareId);
		} else {
			throw new BusinessException(CODESHARE_SINGLE_RECORD);
		}
		

	}
}
