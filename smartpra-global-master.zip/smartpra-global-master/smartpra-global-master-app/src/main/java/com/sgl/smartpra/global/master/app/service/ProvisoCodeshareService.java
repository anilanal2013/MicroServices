package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoCodeshareModel;
import com.sgl.smartpra.global.master.model.ProvisoCodeshareStgModel;

public interface ProvisoCodeshareService {

	public List<ProvisoCodeshareModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> provisoSection, Optional<String> areaFrom, Optional<String> areaTo);

	public List<ProvisoCodeshareModel> searchByProvisoMain(Optional<Integer> provisoMainId, Optional<String> areaFrom,
			Optional<String> areaTo);

	public ProvisoCodeshareModel getProvisoCodeshareByProvisoCodeshareId(Integer provisoCodeshareId);

	public ProvisoCodeshareStgModel saveProvisoCodeshare(ProvisoCodeshareStgModel provisoCodeshareStgModel);

	public List<ProvisoCodeshareModel> getProvisoCodeshareByProvisoMainId(Optional<Integer> provisoMainId);
}
