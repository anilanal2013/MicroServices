package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.CurrencyEntity;

public class CurrencyEntitySpecification {

	private CurrencyEntitySpecification() {
	}

	public static Specification<CurrencyEntity> likeCurrencyCode(String currencyCode) {
		return (currencyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(currencyEntity.get("currencyCode"), currencyCode + "%");
	}

	public static Specification<CurrencyEntity> notEqualsCurrencyCode(String currencyCode) {
		return (currencyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(currencyEntity.get("currencyCode"), currencyCode);
	}

	public static Specification<CurrencyEntity> likeCurrencyName(String currencyName) {
		return (currencyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(currencyEntity.get("currencyName"), currencyName + "%");
	}

	public static Specification<CurrencyEntity> equalsCurrencyNumericCode(Integer currencyNumericCode) {
		return (currencyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(currencyEntity.get("currencyNumericCode"), currencyNumericCode);
	}

	public static Specification<CurrencyEntity> isActive(Boolean isActive) {
		return (currencyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(currencyEntity.get("isActive"),
				isActive);
	}

	public static Specification<CurrencyEntity> search(Optional<String> currencyCode, Optional<String> currencyName,
			Optional<Boolean> isActive) {
		return (currencyEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(currencyCode)) {
				predicates.add(criteriaBuilder.like(currencyEntity.get("currencyCode"),
						OptionalUtil.getValue(currencyCode) + "%"));
			}

			if (OptionalUtil.isPresent(currencyName)) {
				predicates.add(criteriaBuilder.like(currencyEntity.get("currencyName"),
						OptionalUtil.getValue(currencyName) + "%"));
			}

			if (OptionalUtil.getValue(isActive) == null || OptionalUtil.getValue(isActive)) {
				predicates.add(criteriaBuilder.isTrue(currencyEntity.get("isActive")));
			} else {
				predicates.add(criteriaBuilder.isFalse(currencyEntity.get("isActive")));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

}
