package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ChargeCodeTypeDao;
import com.sgl.smartpra.global.master.app.dao.entity.ChargeCodeTypeEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ChargeCodeTypeSpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ChargeCodeTypeRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ChargeCodeTypeDaoImpl implements ChargeCodeTypeDao {

	@Autowired
	private ChargeCodeTypeRepository chargeCodeTypeRepository;
	
	@Override
	@Cacheable(value = "chargeCodeTypeEntity", key="#id")
	public Optional<ChargeCodeTypeEntity> findById(Integer id) {
		log.info("Cacheable entity ChargeCodeType {} ",id);
		return chargeCodeTypeRepository.findById(id);
	}

	@Override
	@Caching(evict= {@CacheEvict(value="chargeCodeTypeEntity",key = "#chargeCodeTypeEntity.chargeCodeTypeId")})
	public ChargeCodeTypeEntity create(ChargeCodeTypeEntity chargeCodeTypeEntity) {
		return chargeCodeTypeRepository.save(chargeCodeTypeEntity);
	}

	@Override
	@Caching(evict= {@CacheEvict(value="chargeCodeTypeEntity",key = "#chargeCodeTypeEntity.chargeCodeTypeId")})
	public ChargeCodeTypeEntity update(ChargeCodeTypeEntity chargeCodeTypeEntity) {
		return chargeCodeTypeRepository.save(chargeCodeTypeEntity);
	}

	@Override
	public List<ChargeCodeTypeEntity> update(List<ChargeCodeTypeEntity> chargeCodeTypeEntity) {
		return chargeCodeTypeRepository.saveAll(chargeCodeTypeEntity);
	}

	@Override
	public Optional<ChargeCodeTypeEntity> findOne(Integer id) {
		Optional<ChargeCodeTypeEntity> entity = chargeCodeTypeRepository.findById(id);
		return entity;
	}

	@Override
	public List<ChargeCodeTypeEntity> findAll(Optional<String> chargeCatCode, Optional<String> chargeCode) {
		return chargeCodeTypeRepository.findAll(ChargeCodeTypeSpecification.search(chargeCatCode,chargeCode));
	}

}
