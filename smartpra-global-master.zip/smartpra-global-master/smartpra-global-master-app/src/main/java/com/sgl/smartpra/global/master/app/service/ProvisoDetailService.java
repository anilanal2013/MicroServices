package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoDetailModel;
import com.sgl.smartpra.global.master.model.ProvisoDetailStgModel;

public interface ProvisoDetailService {
	
	public List<ProvisoDetailModel> getProvisoDetailByProvisoMainId(Optional<Integer> provisoMainId);

	public ProvisoDetailModel getProvisoDetailByProvisoDetailId(Integer provisoDetailId);

	public List<ProvisoDetailModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);

	public List<ProvisoDetailModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> fbGroupCode);

	public ProvisoDetailStgModel saveProvisoDetail(ProvisoDetailStgModel provisoDetailStgModel);

	public List<ProvisoDetailModel> getExceptionRecordFromProvisoDetail(Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber,Optional<String> carrierNumCode);
}
