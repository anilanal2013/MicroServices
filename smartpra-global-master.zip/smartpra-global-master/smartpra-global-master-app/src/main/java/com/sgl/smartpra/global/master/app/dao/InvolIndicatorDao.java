package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.InvolIndicatorEntity;

@Repository
public interface InvolIndicatorDao {

	public Optional<InvolIndicatorEntity> findById(Integer involIndicatorId);

	public InvolIndicatorEntity create(InvolIndicatorEntity involEntity);

	public InvolIndicatorEntity update(InvolIndicatorEntity mapToEntity);

	public List<InvolIndicatorEntity> search(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> indicatorType, Optional<String> ticketField, Optional<Boolean> activate);

	public List<InvolIndicatorEntity> findAll(Optional<String> effectiveDate, Optional<String> indicatorType);

	public long getOverLapRecordCount(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> ticketField, Optional<String> indicatorText);

	public List<InvolIndicatorEntity> verifyIfOverlapForUtilDateExists(LocalDate localDateValue,
			LocalDate localDateValue2);

	public List<InvolIndicatorEntity> validateDate(Optional<String> effectiveDate);

	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String ticketField,
			String indicatorText, Integer involIndicatorId);

	public long getCount(InvolIndicatorEntity involIndicator);

	public Page<InvolIndicatorEntity> getData(InvolIndicatorEntity mapToEntity, Pageable pageable);
}
