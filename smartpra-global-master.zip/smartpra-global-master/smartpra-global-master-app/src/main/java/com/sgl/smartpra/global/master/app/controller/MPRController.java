package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.MPRService;
import com.sgl.smartpra.global.master.model.MPR;

@RestController
public class MPRController {

	@Autowired
	private MPRService mprService;

	@PostMapping("/mpr")
	public MPR createMpr(@Validated(Create.class) @RequestBody MPR mpr) {
		return mprService.createMpr(mpr);
	}

	@GetMapping("/mpr")
	public List<MPR> getMPR(
			@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return mprService.getMPR(effectiveFromDate, effectiveToDate, activate);
	}

	/*
	 * @GetMapping("/mprvalue") public List<MPR> getMpr(@RequestParam(value =
	 * "effectiveDate", required = false) Optional<String> effectiveDate) { return
	 * mprService.getMprDetail(effectiveDate); }
	 */
	
	@GetMapping("/mprvalue")
	public MPR getMpr(@RequestParam(value = "effectiveDate", required = false) Optional<String> effectiveDate) {
		return mprService.getMprDetail(effectiveDate);
	}

	@GetMapping("/mpr/{minimumProrateRuleId}")
	public MPR getMprByMinimumProrateRuleId(
			@PathVariable(value = "minimumProrateRuleId") Integer minimumProrateRuleId) {
		return mprService.getMprByMinimumProrateRuleId(minimumProrateRuleId);
	}

	@PutMapping("/mpr/{minimumProrateRuleId}")
	public MPR updateMpr(@PathVariable(value = "minimumProrateRuleId") Integer minimumProrateRuleId,
			@Validated(Update.class) @RequestBody MPR mpr) {
		return mprService.updateMpr(minimumProrateRuleId, mpr);
	}

	@PutMapping("/mpr/{minimumProrateRuleId}/deactivate")
	public void deactivateMpr(@Valid @PathVariable(value = "minimumProrateRuleId") Integer minimumProrateRuleId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		mprService.deactivateMpr(minimumProrateRuleId, lastUpdatedBy);
	}

	@PutMapping("/mpr/{minimumProrateRuleId}/activate")
	public void activateMpr(@Valid @PathVariable(value = "minimumProrateRuleId") Integer minimumProrateRuleId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		mprService.activateMpr(minimumProrateRuleId, lastUpdatedBy);
	}

}
