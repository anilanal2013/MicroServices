package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.FBTDElementService;
import com.sgl.smartpra.global.master.model.FBTDElement;

@RestController
public class FBTDElementController {

	@Autowired
	private FBTDElementService fbtdElementService;

	@GetMapping("/fbtd-elements")
	public List<FBTDElement> getAllFBTDElement(
			@RequestParam(value = "elementType", required = false) Optional<Integer> elementType,
			@RequestParam(value = "elementCode", required = false) Optional<String> elementCode,
			@RequestParam(value = "effectiveFromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
			@RequestParam(value = "effectiveToDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate,
			@RequestParam(value = "activate", required=false) Optional<Boolean> activate) {
		return fbtdElementService.getAllFBTDElementDetails(elementType, elementCode,effectiveFromDate,effectiveToDate,activate);
	}

	@GetMapping("/fbtd-elements/{elementType}/{elementCode}/{effectiveDate}")
	public FBTDElement getFBTDElementByFBTDId(@PathVariable(value = "elementCode") Optional<String> elementCode,
			@PathVariable(value = "elementType") Optional<Integer> elementType,
			@PathVariable(value = "effectiveDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return fbtdElementService.getFBTDElementByFBTDId(elementType, elementCode, effectiveDate);
	}

	@GetMapping("/fbtd-elementsvalue/{elementType}/{elementCode}/{effectiveDate}")
	public FBTDElement getFBTDElementByFBTDIdValue(@PathVariable(value = "elementCode") Optional<String> elementCode,
			@PathVariable(value = "elementType") Optional<Integer> elementType,
			@PathVariable(value = "effectiveDate") Optional<String> effectiveDate) {
		return fbtdElementService.getFBTDElementByFBTDId(elementType, elementCode, effectiveDate);
	}

	@GetMapping("/fbtd-elements/{fbtdId}")
	public FBTDElement getFBTDElementByFBTDId(@PathVariable(value = "fbtdId") Integer fbtdId) {
		return fbtdElementService.getFBTDElementByFBTDId(fbtdId);
	}

	@PostMapping("/fbtd-elements")
	public FBTDElement createFBTDElement(@Validated(Create.class) @RequestBody FBTDElement fbtdElement) {
		return fbtdElementService.createFBTDElement(fbtdElement);
	}

	@PutMapping("/fbtd-elements/{fbtdId}")
	public FBTDElement updateProrateFactor(@PathVariable(value = "fbtdId") Integer fbtdId,
			@Validated(Update.class) @RequestBody FBTDElement fbtdElement) {
		return fbtdElementService.updateFBTDElement(fbtdId, fbtdElement);
	}

	@PutMapping("/fbtd-elements/{fbtdId}/deactivate")
	public void deactivateFBTDElement(@Valid @PathVariable(value = "fbtdId") Integer fbtdId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		fbtdElementService.deactivateFBTDElement(fbtdId, lastUpdatedBy);
	}

	@PutMapping("/fbtd-elements/{fbtdId}/activate")
	public void activateFBTDElement(@Valid @PathVariable(value = "fbtdId") Integer fbtdId,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		fbtdElementService.activateFBTDElement(fbtdId, lastUpdatedBy);
	}

	@GetMapping("/fbtd-elementsvalue/{elementCode}")
	public boolean getFBTDElementByElementCode(@PathVariable(value = "elementCode") String elementCode) {
		return fbtdElementService.getFBTDElementByElementCode(elementCode);
	}

	// call from master application to validate the element code available or not
	@GetMapping("/fbtd-elementsvalue/{elementCode}/{elementType}")
	public boolean getFBTDElementByElementCodeBasedOnPrimeCode(@PathVariable(value = "elementCode") String elementCode,
			@PathVariable(value = "elementType") Integer elementType) {
		return fbtdElementService.getFBTDElementByElementCodeBasedOnPrimeCode(elementCode, elementType);
	}

	// call from master application to validate the cabin available or not
	@GetMapping("/fbtd-element-cabin/{cabin}")
	public Boolean validateCabin(@PathVariable(value = "cabin") String cabin) {
		return fbtdElementService.validateCabin(cabin);
	}

	// call from master application to validate the cabin level available or not
	@GetMapping("/fbtd-element-otherInfo/{otherInfo}")
	public Boolean validateOtherInfo(@PathVariable(value = "otherInfo") String otherInfo) {
		return fbtdElementService.validateOtherInfo(otherInfo);
	}

	// call from master application to validate the cabin available or not
	@GetMapping("/fbtd-element-iataFareType/{iataFareType}")
	public boolean validateIATAFareType(@PathVariable(value = "iataFareType") String iataFareType) {
		return fbtdElementService.validateIATAFareType(iataFareType);
	}

	// call from master application to validate the seasonalCode available or not
	@GetMapping("/fbtd-element-seasonal/{seasonalCode}")
	public boolean validateSeasonalCode(@PathVariable(value = "seasonalCode") String seasonalCode) {
		return fbtdElementService.validateSeasonalCode(seasonalCode);
	}

	// call from master application to validate the dayOfWeek available or not
	@GetMapping("/fbtd-element-dayOfWeek/{dayOfWeek}")
	public boolean validateDayOfWeek(@PathVariable(value = "dayOfWeek") String dayOfWeek) {
		return fbtdElementService.validateDayOfWeek(dayOfWeek);
	}

	// call from master application to validate the discountCode available or not
	@GetMapping("/fbtd-element-discountCode/{discountCode}")
	public boolean validateDiscountCode(@PathVariable(value = "discountCode") String discountCode) {
		return fbtdElementService.validateDiscountCode(discountCode);
	}

	// call from master application to validate the journeyType available or not
	@GetMapping("/fbtd-element-journeyType/{journeyType}")
	public boolean validateJourneyType(@PathVariable(value = "journeyType") String journeyType) {
		return fbtdElementService.validateJourneyType(journeyType);
	}

	// call from master application to validate the zedIdentifier available or not
	@GetMapping("/fbtd-element-zedidentifier/{zedIdentifier}")
	public boolean validateZedIdentifier(@PathVariable(value = "zedIdentifier") String zedIdentifier) {
		return fbtdElementService.validateZedIdentifier(zedIdentifier);
	}
	
	// call from master application to validate the journeyType available or not
		@GetMapping("/fbtd-element-cabin-level")
		public List<FBTDElement> getCabinLevel() {
			return fbtdElementService.getCabinLevel();
		}
	
	
}
