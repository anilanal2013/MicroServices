package com.sgl.smartpra.global.master.app.dao.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The persistent class for the global_mas_sirs_rates database table.
 * 
 */
@Entity
@Table(name = "global_mas_sirs_rates")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class SIRSRatesEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sirs_rate_id")
	private Integer sirsRateId;

	@Column(name = "effective_from_date")
	@NotNull
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date")
	@NotNull
	private LocalDate effectiveToDate;

	@Column(name = "from_area")
	@NotEmpty
	private String fromArea;

	@Column(name = "geo_area_indicator")
	@NotEmpty
	private String geoAreaIndicator;

	@Column(name = "global_region")
	@NotEmpty
	private String globalRegion;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "sirs_percentage")
	private BigDecimal sirsPercentage;

	@Column(name = "to_area")
	@NotEmpty
	private String toArea;

	public SIRSRatesEntity() {
	}

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setCreatedDate(LocalDateTime.now());
	}

}
