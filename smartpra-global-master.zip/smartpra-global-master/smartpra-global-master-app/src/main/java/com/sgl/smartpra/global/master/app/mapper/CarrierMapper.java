package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.CarrierEntity;
import com.sgl.smartpra.global.master.model.Carrier;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CarrierMapper extends BaseMapper<Carrier, CarrierEntity>{

	CarrierEntity mapToEntity(Carrier carrier, @MappingTarget CarrierEntity carrierEntity);

	CarrierEntity mapToEntity(Carrier carrier);

}