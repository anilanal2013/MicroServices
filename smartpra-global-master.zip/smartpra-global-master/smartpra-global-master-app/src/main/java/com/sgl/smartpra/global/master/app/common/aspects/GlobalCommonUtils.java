package com.sgl.smartpra.global.master.app.common.aspects;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.master.model.SystemParameter;

@Component
public class GlobalCommonUtils {

	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";

	public static String getHostCarrierDesigCode(MasterFeignClient masterFeignClient) {
		String hostCarrierDesigCode = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) masterFeignClient
				.getSystemParameterByparameterName(PARAM_DEFAULT_CARRIER_ALPHA_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			for (SystemParameter systemParameter : systemParameterList) {
				Optional<String> parameterRangeFrom = systemParameter.getParameterRangeFrom();
				if (OptionalUtil.getValue(parameterRangeFrom).equalsIgnoreCase("QR")) {
					hostCarrierDesigCode = OptionalUtil.getValue(parameterRangeFrom);
				}
			}
		//	hostCarrierDesigCode = OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());
		}
		return hostCarrierDesigCode;
	}
}
