package com.sgl.smartpra.global.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sgl.smartpra.global.master.app.dao.entity.RejectionReasonCodeEntity;

@Repository
public interface RejectionReasonCodeRepository extends JpaRepository<RejectionReasonCodeEntity, String>, JpaSpecificationExecutor<RejectionReasonCodeEntity>{

}
