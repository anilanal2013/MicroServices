package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingStgEntity;

@Repository
public interface ProvisoRoutingStgDao {
	ProvisoRoutingStgEntity create(ProvisoRoutingStgEntity provisoRoutingStgEntity);

	List<ProvisoRoutingStgEntity> findByMainId(Optional<Integer> provisoMainId);

	Optional<ProvisoRoutingStgEntity> findById(Integer id);

	public List<ProvisoRoutingStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber);

	ProvisoRoutingStgEntity update(ProvisoRoutingStgEntity provisoRoutingStgEntity);

	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer detailRecNumber,Integer routingRecNumber);

	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer detailRecNumber,Integer routingRecNumber,
			Integer provisoRoutingId);

	public List<Integer> getListOfProvisoMainIdFromRoutingStgDb();

	void deleteProvisoRoutingByProvisoMainId(Integer provisoMainId);

	void deleteProvisoRoutingByProvisoRoutingId(Integer provisoRoutingId);

	void deleteProvisoRoutingByCarrierNumSeqRecNumber(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<Integer> detailRecNumber);

	public Integer getMaxOfProvisoRoutingRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber);
}
