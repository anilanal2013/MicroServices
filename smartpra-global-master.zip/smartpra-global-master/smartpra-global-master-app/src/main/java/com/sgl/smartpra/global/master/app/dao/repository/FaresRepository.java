package com.sgl.smartpra.global.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.FaresEntity;

@Repository
public interface FaresRepository extends JpaRepository<FaresEntity, Integer>, JpaSpecificationExecutor<FaresEntity> {

}
