package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.FaresEntity;
import com.sgl.smartpra.global.master.model.Fares;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FaresMapper extends BaseMapper<Fares, FaresEntity> {
	 
	FaresEntity mapToEntity(Fares fares, @MappingTarget FaresEntity faresEntity);

	@Mapping(source = "fareId", target = "fareId", ignore = true)
	FaresEntity mapToEntity(Fares fares);

}
