package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoCodeshareStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoCodeshareStgEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoCodeshareStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoCodeshareStgDaoImpl implements ProvisoCodeshareStgDao {
	@Autowired
	private ProvisoCodeshareStgRepository provisoCodeshareStgRepository;

	@Override
	@Caching(evict = {
			@CacheEvict(value = "provisoCodeshareStgModel", key = "#provisoCodeshareStgEntity.provisoCodeshareId") })
	public ProvisoCodeshareStgEntity create(ProvisoCodeshareStgEntity provisoCodeshareStgEntity) {

		return provisoCodeshareStgRepository.save(provisoCodeshareStgEntity);
	}

	@Override
	@Cacheable(value = "provisoCodeshareStgModel", key = "#id")
	public Optional<ProvisoCodeshareStgEntity> findById(Integer id) {

		log.info("Cacheable Proviso Main Entity's ID= {}", id);
		return provisoCodeshareStgRepository.findById(id);
	}

	@Override
	@CachePut(value = "provisoCodeshareStgModel", key = "#provisoCodeshareStgEntity.provisoCodeshareId")
	@CacheEvict(value = "ProvisoCodeshareSearch", allEntries = true)
	public ProvisoCodeshareStgEntity update(ProvisoCodeshareStgEntity provisoCodeshareStgEntity) {

		return provisoCodeshareStgRepository.save(provisoCodeshareStgEntity);
	}

	@Override
	public List<ProvisoCodeshareStgEntity> searchByProvisoMain(Optional<Integer> provisoMainId,
			Optional<String> areaFrom, Optional<String> areaTo) {

		return provisoCodeshareStgRepository
				.findAll(ProvisoCodeshareStgEntitySpecification.search(provisoMainId, areaFrom, areaTo));
	}

	@Override
	public List<ProvisoCodeshareStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> provisoSection, Optional<String> areaFrom, Optional<String> areaTo) {

		return provisoCodeshareStgRepository.findAll(ProvisoCodeshareStgEntitySpecification.search(carrierNumCode,
				provisoSeqNumber, provisoSection, areaFrom, areaTo));
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, String provisoSection,
			String areaFrom, String areaTo) {
		return provisoCodeshareStgRepository
				.count(Specification.where(ProvisoCodeshareStgEntitySpecification.equalsCarrierNumCode(carrierNumCode)
						.and(ProvisoCodeshareStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
						.and(ProvisoCodeshareStgEntitySpecification.equalsProvisoSection(provisoSection))
						.and(ProvisoCodeshareStgEntitySpecification.equalsAreaFrom(areaFrom))
						.and(ProvisoCodeshareStgEntitySpecification.equalsAreaTo(areaTo))));
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, String provisoSection,
			String areaFrom, String areaTo, Integer provisoCodeshareId) {
		return provisoCodeshareStgRepository
				.count(Specification.where(ProvisoCodeshareStgEntitySpecification.equalsCarrierNumCode(carrierNumCode)
						.and(ProvisoCodeshareStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
						.and(ProvisoCodeshareStgEntitySpecification.equalsProvisoSection(provisoSection))
						.and(ProvisoCodeshareStgEntitySpecification.equalsAreaFrom(areaFrom))
						.and(ProvisoCodeshareStgEntitySpecification.equalsAreaTo(areaTo))
						.and(ProvisoCodeshareStgEntitySpecification.notEqualsProvisoCodeshareId(provisoCodeshareId))));
	}

	@Override
	public List<ProvisoCodeshareStgEntity> findByMainId(Optional<Integer> provisoMainId) {
		log.info("Cacheable Proviso Codeshare Entity's ID= {}", provisoMainId);
		return provisoCodeshareStgRepository
				.findAll(ProvisoCodeshareStgEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	public List<Integer> getListOfProvisoMainIdFromCodeshareStgDb() {

		return provisoCodeshareStgRepository.getListOfProvisoMainIdFromCodeshareStgDb();
	}

	@Override
	public void deleteProvisoCodehareByProvisoMainId(Integer provisoMainId) {
		provisoCodeshareStgRepository.deleteProvisoCodehareByProvisoMainId(provisoMainId);
	}

	@Override
	public void deleteProvisoCodehareByProvisoCodeshareId(Integer provisoCodeshareId) {
		provisoCodeshareStgRepository.deleteById(provisoCodeshareId);
	}

	@Override
	public Integer getMaxOfCodeshareRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {
		return provisoCodeshareStgRepository.getMaxOfCodeshareRecNumber(carrierNumCode, provisoSeqNumber);
	}
}
