package com.sgl.smartpra.global.master.app.configuration;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.master.model.SystemParameter;

@Configuration
@Component
public class FeignConfiguration {

	@FeignClient(value = "smartpra-master-app")
	public interface MasterFeignClient {

		@GetMapping("/listofvalues/{clientId}/{tableName}/{columeName}")
		public List<String> getListOfValues(@PathVariable(value = "clientId") String clientId,
				@PathVariable(value = "tableName") String tableName,
				@PathVariable(value = "columeName") String columeName);
		
		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(@PathVariable(value = "parameterName") String parameterName);

		@GetMapping("/test")
		public String test();

		@GetMapping("/airports/{airportCode}/validate")
		public boolean isValidAirportCodeOrCityCode(@PathVariable(value = "airportCode") String airportCode);

		@GetMapping("/carriers/carrierDesignatorCode/validate/{carrierDesignatorCode}")
		public boolean isValidCarrierDesignatorCode(
				@PathVariable("carrierDesignatorCode") String carrierDesignatorCode);
		
		@GetMapping("/billing-period/current-open")
		public OutwardBillingPeriods getCurrentOpenOutwardBillingPeriods();

	}

	@FeignClient(value = "smartpra-yqyr-global-app")
	public interface YQYRGlobalMasterFeignClient {

		@GetMapping("/fare-type-atpco/{atpcoFareType}")
		public boolean validateAtpcoFareType(@PathVariable(value = "atpcoFareType") String atpcoFareType);

		@GetMapping("/fare-type-paxType/{paxType}")
		public boolean validatePAXtype(@PathVariable(value = "paxType") String paxType);

	}
	

	@FeignClient(value = "smartpra-batch-global-app")
	public interface BatchGlobalMasterFeignClient {

		@PutMapping("/master-audit")
		public void updateMasterAudit(@RequestParam(value = "newObj") Object newObj,
				@RequestParam(value = "oldObj") Object oldObj, @RequestParam(value = "tableName") String tableName,
				@RequestParam(value = "serviceName") String serviceName);

	}

}