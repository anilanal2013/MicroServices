package com.sgl.smartpra.global.master.app.service;

import java.util.List;

import com.sgl.smartpra.global.master.model.FareTypeHierarchy;

public interface FareTypeHierarchyService {

	public FareTypeHierarchy createFareTypeHierarchy(FareTypeHierarchy fareTypeHierarchy);

	public FareTypeHierarchy updateFareTypeHierarchy(FareTypeHierarchy fareTypeHierarchy);
	
	public FareTypeHierarchy getFareTypeHierarchyByfareTypeHierarchyId(Integer fareTypeHierarchyId);
	
	public List<FareTypeHierarchy> getAllFareTypeHierarchy(String effectiveFromDate, String effectiveToDate, 
			Integer cabinLevel, Integer fareTypeLevel);

	public void deactivateFareTypeHierarchy(FareTypeHierarchy fareTypeHierarchy);

	public void activateFareTypeHierarchy(FareTypeHierarchy fareTypeHierarchy);

	public List<FareTypeHierarchy> getAllFareTypeHierarchyWithCabin( String effectiveDate,
			String cabin, Integer fareTypeLevel);

}
