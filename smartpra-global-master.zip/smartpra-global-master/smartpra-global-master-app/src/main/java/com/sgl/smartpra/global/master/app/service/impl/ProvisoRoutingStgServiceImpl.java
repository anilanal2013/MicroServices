package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.ProvisoMainStgDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoRoutingStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingStgEntity;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.ProvisoRoutingStgMapper;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CarrierService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.ProvisoMainStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoRoutingStgService;
import com.sgl.smartpra.global.master.app.service.StandardAreaSrevice;
import com.sgl.smartpra.global.master.app.service.UserAreaSrevice;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.Geo;
import com.sgl.smartpra.global.master.model.ProvisoRoutingStg;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoRoutingStgServiceImpl implements ProvisoRoutingStgService {
	
	public static final String OVERLAP_COMBINATION_EXIST = "Record already exist";
	private static final String AIRPORTCITY = "Only alphabets are allowed for Airport/City";
	private static final String PATTERN = "^[a-zA-Z]*$";
	private static final String AIRPORTCITYINVALID = "Invalid  Airport/City code : ";
	private static final String COUNTRYCODEALPHA = "Only alphabets are allowed for country code";
	private static final String COUNTRYCODEINVALID = "Invalid  country code : ";
	private static final String INVALIDSTDAREACODE = "Invalid  standard area code : ";
	private static final String GLOBAL = "global";
	private static final String FROMAREAINCLUDEMENDATORY = "Please provide AreaFromInclude";
	private static final String STATECODEALPHA = "Only alphabets are allowed for state code";
	private static final String INVALIDSTATECODE = "Invalid state code : ";
	private static final String MANDATORYGEOTYPEVALUE = "Please provide Geo Type Value";
	private static final String DOESNOTEXIST = " Does not exist";
	private static final String ISNOTACTIVE = " is not active";
	private static final String PROVISO_ROUTING_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN = "CarierNumCode of Proviso Routing should be similar to CarierNumCode of Proviso Main Corresponding to Proviso Main Id";
	private static final String ROUTING_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso Routing data not available for selected Proviso Main record";
	
	@Autowired
	private ProvisoRoutingStgDao provisoRoutingStgDao;
	
	@Autowired
	private ProvisoMainStgDao provisoMainStgDao;
	
	@Autowired
	private ProvisoRoutingStgMapper provisoRoutingStgMapper;
	@Autowired
	private MasterFeignClient masterFeignClient;
	List<String> typeValueList = new ArrayList<>();

	@Autowired
	private CarrierService carrierService;

	@Autowired
	private UserAreaSrevice userAreaSrevice;

	@Autowired
	private AirportService airportService;

	@Autowired
	private CountryService countryService;

	@Autowired
	StandardAreaSrevice standardAreaSrevice;

	@Autowired
	private ProvisoMainStgService provisoMainStgService;

	String clientId = null;
	public static final String PROVISOROUTING_LOV_TABLE_VALUE = LOVEnum.TABLENAME.getLOVEnum();
	public static final String AREACHECKTYPE_LOV_COLUMN_VALUE = LOVEnum.AREATYPE.getLOVEnum();
	public static final String AREAVIA_LOV_COLUMN_VALUE = LOVEnum.AREAVIA.getLOVEnum();
	
	Boolean getAreaFromFlag = false;
	Boolean getAreaToFlag = false;

	@Override
	@Transactional(rollbackOn = BusinessException.class)
	public ProvisoRoutingStg createProvisoRouting(ProvisoRoutingStg provisoRoutingStg) {
		
		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(OptionalUtil.getValue(provisoRoutingStg.getProvisoMainId()))
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(OptionalUtil.getValue(provisoRoutingStg.getProvisoMainId()))));
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}

		Integer routingRecNumber = provisoRoutingStgDao.getMaxOfProvisoRoutingRecNumber(
				provisoRoutingStg.getCarrierNumCode(), provisoRoutingStg.getProvisoSeqNumber(),
				provisoRoutingStg.getDetailRecNumber());
		routingRecNumber = (routingRecNumber == null) ? Integer.valueOf(1)
				: Integer.valueOf(routingRecNumber.intValue() + 1);
		provisoRoutingStg.setRoutingRecNumber(Optional.of(routingRecNumber));

		provisoRoutingStg.setCreatedDate(LocalDateTime.now());
		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		String areaFromInclude = null;
		String areaFromExclude = null;
		String areaToInclude = null;
		String areaToExclude = null;
		String areaViaInclude = null;
		String areaViaExclude = null;
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()))) {
			String[] fromAreaArray = validateArea(provisoRoutingStg.getAreaFrom(),
					provisoRoutingStg.getAreaFromInclude(), provisoRoutingStg.getAreaFromExclude(),
					provisoRoutingStg.getFromUserAreaName(), GLOBAL);
			areaFromInclude = fromAreaArray[0];
			areaFromExclude = fromAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo()))) {
			String[] toAreaArray = validateArea(provisoRoutingStg.getAreaTo(), provisoRoutingStg.getAreaToInclude(),
					provisoRoutingStg.getAreaToExclude(), provisoRoutingStg.getToUserAreaName(), GLOBAL);
			areaToInclude = toAreaArray[0];
			areaToExclude = toAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia()))) {
			String[] viaAreaArray = validateArea(provisoRoutingStg.getAreaVia(), provisoRoutingStg.getAreaViaInclude(),
					provisoRoutingStg.getAreaViaExclude(), provisoRoutingStg.getViaUserAreaName(), GLOBAL);
			areaViaInclude = viaAreaArray[0];
			areaViaExclude = viaAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		boolean fromAreaStandardAreaFlag = false;
		boolean toAreaStandardAreaFlag = false;
		boolean viaAreaStandardAreaFlag = false;
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom())))
			fromAreaStandardAreaFlag = OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo())))
			toAreaStandardAreaFlag = OptionalUtil.getValue(provisoRoutingStg.getAreaTo()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia())))
			viaAreaStandardAreaFlag = OptionalUtil.getValue(provisoRoutingStg.getAreaVia()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()))) {
			provisoRoutingStg.setAreaFrom(Optional.of(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom())));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo()))) {
			provisoRoutingStg.setAreaTo(Optional.of(OptionalUtil.getValue(provisoRoutingStg.getAreaTo())));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia()))) {
			provisoRoutingStg.setAreaVia(Optional.of(OptionalUtil.getValue(provisoRoutingStg.getAreaVia())));
		}
		validateBusinessConstraintsForCreate(provisoRoutingStg);
		ProvisoRoutingStg provisoRoutingStgRecord = provisoRoutingStgMapper
				.mapToModel(provisoRoutingStgDao.create(provisoRoutingStgMapper.mapToEntity(provisoRoutingStg)));
		Boolean updateFlag = false;
		String areaKey1 = "P";
		Carrier carrier = carrierService
				.findCarrierByCarrierCode(OptionalUtil.getValue(provisoRoutingStg.getCarrierNumCode()));
		String areaKey2 = OptionalUtil.getValue(carrier.getCarrierCode());
		String areaKey3 = provisoRoutingStgRecord.getProvisoRoutingId().toString();
		String areaKey4 = "GLB";
		Map<String, String> map = new HashMap<>();
		map.put("areaKey1", areaKey1);
		map.put("areaKey2", areaKey2);
		map.put("areaKey3", areaKey3);
		map.put("areaKey4", areaKey4);
		map.put("userFromAreaName", provisoRoutingStg.getFromUserAreaName());
		map.put("areaFromInclude", areaFromInclude);
		map.put("areaFromExclude", areaFromExclude);
		map.put("createdBy", OptionalUtil.getValue(provisoRoutingStg.getCreatedBy()));
		map.put("userFromArea", OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()).substring(1,
				OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()).length()));
		map.put("updateFlag", updateFlag.toString());

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom())) && fromAreaStandardAreaFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia())) && viaAreaStandardAreaFlag) {
			map.put("areaViaInclude", areaViaInclude);
			map.put("areaViaExclude", areaViaExclude);
			map.put("userViaAreaName", provisoRoutingStg.getViaUserAreaName());
			map.put("userViaArea", OptionalUtil.getValue(provisoRoutingStg.getAreaVia()).substring(1,
					OptionalUtil.getValue(provisoRoutingStg.getAreaVia()).length()));
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo())) && toAreaStandardAreaFlag) {
			map.put("areaToInclude", areaToInclude);
			map.put("areaToExclude", areaToExclude);
			map.put("userToAreaName", provisoRoutingStg.getToUserAreaName());
			map.put("userToArea", OptionalUtil.getValue(provisoRoutingStg.getAreaTo()).substring(1,
					OptionalUtil.getValue(provisoRoutingStg.getAreaTo()).length()));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo())) && toAreaStandardAreaFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		updateMainProvisoStatus(provisoMainStgEntity);
		return provisoRoutingStgRecord;
	}
	
	@Transactional(rollbackOn = BusinessException.class)
	private void updateMainProvisoStatus(ProvisoMainStgEntity provisoMainStgEntity) {
		provisoMainStgDao.updateProvisoMainStg(provisoMainStgEntity);		
	}

	private void validateBusinessConstraintsForCreate(ProvisoRoutingStg provisoRoutingStg) {
		validateOverlapForCreate(provisoRoutingStg);
		validateCheckAreaToForAreaCheckType(provisoRoutingStg);
		validateAreaVia(provisoRoutingStg);
		validateCarrierNumCodeByProvisoMainId(provisoRoutingStg);
	}

	private void validateCarrierNumCodeByProvisoMainId(ProvisoRoutingStg provisoRoutingStg) {

		String carrierNumCode = OptionalUtil.getValue((provisoMainStgService
				.getProvisoMainByprovisoMainId(OptionalUtil.getValue(provisoRoutingStg.getProvisoMainId())))
						.getCarrierNumCode());

		if (!(OptionalUtil.getValue(provisoRoutingStg.getCarrierNumCode()).equalsIgnoreCase(carrierNumCode))) {
			throw new BusinessException(PROVISO_ROUTING_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN);
		}

	}

	protected void validateAreaVia(ProvisoRoutingStg provisoRoutingStg) {
		if (OptionalUtil.isPresent(provisoRoutingStg.getAreaCheckType())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, PROVISOROUTING_LOV_TABLE_VALUE,
					AREAVIA_LOV_COLUMN_VALUE);
			if (!(listOfValues.contains(OptionalUtil.getValue(provisoRoutingStg.getAreaCheckType()))) 
					&& Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia()))) {
					throw new BusinessException("AreaVia should be Empty");
			}

		}

	}

	protected void validateCheckAreaToForAreaCheckType(ProvisoRoutingStg provisoRoutingStg) {
		if (OptionalUtil.isPresent(provisoRoutingStg.getAreaCheckType())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, PROVISOROUTING_LOV_TABLE_VALUE,
					AREACHECKTYPE_LOV_COLUMN_VALUE);

			if (!(listOfValues.contains(OptionalUtil.getValue(provisoRoutingStg.getAreaCheckType())))
					&& Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo()))) {
					throw new BusinessException("Area To should be Empty");
			}
			if (listOfValues.contains(OptionalUtil.getValue(provisoRoutingStg.getAreaCheckType()))
					&& Objects.isNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo()))
					&& !OptionalUtil.getValue(provisoRoutingStg.getAreaCheckType()).equalsIgnoreCase("W") &&
					!OptionalUtil.getValue(provisoRoutingStg.getAreaCheckType()).equalsIgnoreCase("O")) {
					throw new BusinessException("Area To should not be Empty");
			} 

			if (( OptionalUtil.getValue(provisoRoutingStg.getAreaCheckType()).equalsIgnoreCase("W") || 
					OptionalUtil.getValue(provisoRoutingStg.getAreaCheckType()).equalsIgnoreCase("O") )
					&& Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo()))){
				throw new BusinessException("Area To should be Empty");
			}
		}

	}

	private void validateOverlapForCreate(ProvisoRoutingStg provisoRoutingStg) {
		if (OptionalUtil.isPresent(provisoRoutingStg.getCarrierNumCode())
				&& OptionalUtil.isPresent(provisoRoutingStg.getProvisoSeqNumber())
				&& OptionalUtil.isPresent(provisoRoutingStg.getDetailRecNumber())
				&& OptionalUtil.isPresent(provisoRoutingStg.getRoutingRecNumber())) {
			if (provisoRoutingStgDao.getOverlapRecordCount(OptionalUtil.getValue(provisoRoutingStg.getCarrierNumCode()),
					OptionalUtil.getValue(provisoRoutingStg.getProvisoSeqNumber()),
					OptionalUtil.getValue(provisoRoutingStg.getDetailRecNumber()),
					OptionalUtil.getValue(provisoRoutingStg.getRoutingRecNumber())) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}

	}

	@Override
	public List<ProvisoRoutingStg> getProvisoRoutingByProvisoMainId(Optional<Integer> provisoMainId) {

		List<Integer> provisoMainIdFromDb = provisoRoutingStgDao.getListOfProvisoMainIdFromRoutingStgDb();
		if (!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))) {
			throw new BusinessException(ROUTING_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		return provisoRoutingStgMapper.mapToModel(provisoRoutingStgDao.findByMainId(provisoMainId));
	}

	@Override
	public ProvisoRoutingStg getProvisoRoutingByProvisoRoutingId(Integer provisoRoutingId) {

		return provisoRoutingStgMapper.mapToModel(provisoRoutingStgDao.findById(provisoRoutingId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoRoutingId))));
	}

	@Override
	public List<ProvisoRoutingStg> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber) {
		return provisoRoutingStgMapper
				.mapToModel(provisoRoutingStgDao.search(carrierNumCode, provisoSeqNumber, detailRecNumber));
	}

	@Override
	@Transactional(rollbackOn = BusinessException.class)
	public ProvisoRoutingStg updateProvisoRouting(Integer provisoRoutingId, ProvisoRoutingStg provisoRoutingStg) {
		
		ProvisoMainStgEntity provisoMainStgEntity = provisoMainStgDao.findById(OptionalUtil.getValue(provisoRoutingStg.getProvisoMainId()))
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(OptionalUtil.getValue(provisoRoutingStg.getProvisoMainId()))));
		if (Optional.of(provisoMainStgEntity.getProvisoStatus()).equals(Optional.of("R"))) {
			provisoMainStgEntity.setProvisoStatus("M");
		}

		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		String areaFromInclude = null;
		String areaFromExclude = null;
		String areaToInclude = null;
		String areaToExclude = null;
		String areaViaInclude = null;
		String areaViaExclude = null;
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()))) {
			String[] fromAreaArray = validateArea(provisoRoutingStg.getAreaFrom(),
					provisoRoutingStg.getAreaFromInclude(), provisoRoutingStg.getAreaFromExclude(),
					provisoRoutingStg.getFromUserAreaName(), GLOBAL);
			areaFromInclude = fromAreaArray[0];
			areaFromExclude = fromAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo()))) {
			String[] toAreaArray = validateArea(provisoRoutingStg.getAreaTo(), provisoRoutingStg.getAreaToInclude(),
					provisoRoutingStg.getAreaToExclude(), provisoRoutingStg.getToUserAreaName(), GLOBAL);
			areaToInclude = toAreaArray[0];
			areaToExclude = toAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia()))) {
			String[] viaAreaArray = validateArea(provisoRoutingStg.getAreaVia(), provisoRoutingStg.getAreaViaInclude(),
					provisoRoutingStg.getAreaViaExclude(), provisoRoutingStg.getViaUserAreaName(), GLOBAL);
			areaViaInclude = viaAreaArray[0];
			areaViaExclude = viaAreaArray[1];
			typeValueList = new ArrayList<>();
			typeValueList.clear();
		}

		boolean fromAreaStandardAreaFlag = false;
		boolean toAreaStandardAreaFlag = false;
		boolean viaAreaStandardAreaFlag = false;
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom())))
			fromAreaStandardAreaFlag = OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo())))
			toAreaStandardAreaFlag = OptionalUtil.getValue(provisoRoutingStg.getAreaTo()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia())))
			viaAreaStandardAreaFlag = OptionalUtil.getValue(provisoRoutingStg.getAreaVia()).startsWith("4");

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()))) {
			provisoRoutingStg.setAreaFrom(Optional.of(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom())));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo()))) {
			provisoRoutingStg.setAreaTo(Optional.of(OptionalUtil.getValue(provisoRoutingStg.getAreaTo())));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia()))) {
			provisoRoutingStg.setAreaVia(Optional.of(OptionalUtil.getValue(provisoRoutingStg.getAreaVia())));
		}

		log.info("{}", provisoRoutingStg);
		ProvisoRoutingStgEntity provisoRoutingStgEntity = provisoRoutingStgDao.findById(provisoRoutingId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoRoutingId)));
		validateBusinessConstraintsForUpdate(provisoRoutingStg, provisoRoutingStgEntity);
		provisoRoutingStg.setLastUpdatedDate(LocalDateTime.now());
		ProvisoRoutingStg provisoRoutingStgUpdatedRecord = provisoRoutingStgMapper.mapToModel(provisoRoutingStgDao
				.update(provisoRoutingStgMapper.mapToEntity(provisoRoutingStg, provisoRoutingStgEntity)));

		Boolean updateFlag = false;
		String areaKey1 = "P";
		Carrier carrier = carrierService
				.findCarrierByCarrierCode(OptionalUtil.getValue(provisoRoutingStg.getCarrierNumCode()));
		String areaKey2 = OptionalUtil.getValue(carrier.getCarrierCode());
		String areaKey3 = provisoRoutingStgUpdatedRecord.getProvisoRoutingId().toString();
		String areaKey4 = "GLB";
		Map<String, String> map = new HashMap<>();
		map.put("areaKey1", areaKey1);
		map.put("areaKey2", areaKey2);
		map.put("areaKey3", areaKey3);
		map.put("areaKey4", areaKey4);
		map.put("userFromAreaName", provisoRoutingStg.getFromUserAreaName());
		map.put("areaFromInclude", areaFromInclude);
		map.put("areaFromExclude", areaFromExclude);
		map.put("createdBy", provisoRoutingStgEntity.getCreatedBy());
		map.put("userFromArea", OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()).substring(1,
				OptionalUtil.getValue(provisoRoutingStg.getAreaFrom()).length()));
		map.put("updateFlag", updateFlag.toString());
		map.put("lastUpdatedBy", OptionalUtil.getValue(provisoRoutingStg.getLastUpdatedBy()));
		provisoRoutingStg.setLastUpdatedDate(LocalDateTime.now());
		map.put("lastUpdatedDate", provisoRoutingStg.getLastUpdatedDate().toString());

		userAreaSrevice.deleteUserArea(areaKey1, areaKey2, areaKey3);

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaFrom())) && fromAreaStandardAreaFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia())) && viaAreaStandardAreaFlag) {
			map.put("areaViaInclude", areaViaInclude);
			map.put("areaViaExclude", areaViaExclude);
			map.put("userViaAreaName", provisoRoutingStg.getViaUserAreaName());
			map.put("userViaArea", OptionalUtil.getValue(provisoRoutingStg.getAreaVia()).substring(1,
					OptionalUtil.getValue(provisoRoutingStg.getAreaVia()).length()));
		}

		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo())) && toAreaStandardAreaFlag) {
			map.put("areaToInclude", areaToInclude);
			map.put("areaToExclude", areaToExclude);
			map.put("userToAreaName", provisoRoutingStg.getToUserAreaName());
			map.put("userToArea", OptionalUtil.getValue(provisoRoutingStg.getAreaTo()).substring(1,
					OptionalUtil.getValue(provisoRoutingStg.getAreaTo()).length()));
		}
		if (Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaTo())) && toAreaStandardAreaFlag) {
			userAreaSrevice.clientSpecificUserAreaInsertOrUpdate(map);
		}
		updateMainProvisoStatus(provisoMainStgEntity);
		return provisoRoutingStgUpdatedRecord;
	}

	private void validateBusinessConstraintsForUpdate(ProvisoRoutingStg provisoRoutingStg,
			ProvisoRoutingStgEntity provisoRoutingStgEntity) {
		validateOverlapForUpdate(provisoRoutingStg, provisoRoutingStgEntity);
		validateCheckAreaToForAreaCheckType(provisoRoutingStg);
		validateAreaViaForUpdate(provisoRoutingStg);
		validateCarrierNumCodeByProvisoMainId(provisoRoutingStg);
	}

	protected void validateAreaViaForUpdate(ProvisoRoutingStg provisoRoutingStg) {
		if (OptionalUtil.isPresent(provisoRoutingStg.getAreaCheckType())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, PROVISOROUTING_LOV_TABLE_VALUE,
					AREAVIA_LOV_COLUMN_VALUE);

			if (!(listOfValues.contains(OptionalUtil.getValue(provisoRoutingStg.getAreaCheckType())))
					&& Objects.nonNull(OptionalUtil.getValue(provisoRoutingStg.getAreaVia()))) {
					throw new BusinessException("AreaVia should be Empty");
			}

		}

	}


	private void validateOverlapForUpdate(ProvisoRoutingStg provisoRoutingStg,
			ProvisoRoutingStgEntity provisoRoutingStgEntity) {
		String carrierNumCode = getCarrierNumCode(provisoRoutingStg, provisoRoutingStgEntity);
		Integer provisoSeqNumber = getProvisoSeqNumber(provisoRoutingStg, provisoRoutingStgEntity);
		Integer detailRecNumber = getDetailRecNumber(provisoRoutingStg, provisoRoutingStgEntity);
		Integer routingRecNumber = getRoutingRecNumber(provisoRoutingStg, provisoRoutingStgEntity);
		if (!carrierNumCode.equalsIgnoreCase(provisoRoutingStgEntity.getCarrierNumCode())
				|| !provisoSeqNumber.equals(provisoRoutingStgEntity.getProvisoSeqNumber())
				|| !detailRecNumber.equals(provisoRoutingStgEntity.getDetailRecNumber())
				|| !routingRecNumber.equals(provisoRoutingStgEntity.getRoutingRecNumber())) {
			if (provisoRoutingStgDao.getOverlapRecordCount(carrierNumCode, provisoSeqNumber, detailRecNumber,
					routingRecNumber, provisoRoutingStgEntity.getProvisoRoutingId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}

	}

	private String getCarrierNumCode(ProvisoRoutingStg provisoRoutingStg,
			ProvisoRoutingStgEntity provisoRoutingStgEntity) {
		return OptionalUtil.isPresent(provisoRoutingStg.getCarrierNumCode())
				? OptionalUtil.getValue(provisoRoutingStg.getCarrierNumCode())
				: provisoRoutingStgEntity.getCarrierNumCode();
	}

	private Integer getProvisoSeqNumber(ProvisoRoutingStg provisoRoutingStg,
			ProvisoRoutingStgEntity provisoRoutingStgEntity) {
		return OptionalUtil.isPresent(provisoRoutingStg.getProvisoSeqNumber())
				? OptionalUtil.getValue(provisoRoutingStg.getProvisoSeqNumber())
				: provisoRoutingStgEntity.getProvisoSeqNumber();
	}

	private Integer getDetailRecNumber(ProvisoRoutingStg provisoRoutingStg,
			ProvisoRoutingStgEntity provisoRoutingStgEntity) {
		return OptionalUtil.isPresent(provisoRoutingStg.getDetailRecNumber())
				? OptionalUtil.getValue(provisoRoutingStg.getDetailRecNumber())
				: provisoRoutingStgEntity.getDetailRecNumber();
	}

	private Integer getRoutingRecNumber(ProvisoRoutingStg provisoRoutingStg,
			ProvisoRoutingStgEntity provisoRoutingStgEntity) {
		return OptionalUtil.isPresent(provisoRoutingStg.getRoutingRecNumber())
				? OptionalUtil.getValue(provisoRoutingStg.getRoutingRecNumber())
				: provisoRoutingStgEntity.getRoutingRecNumber();
	}

	private StringBuilder userGeoList(List<Geo> l, StringBuilder geoString, boolean flag) {
		for (Geo geo : l) {

			if (geo.getGeoTypeId() == null)
				throw new BusinessException("GeoTypeId should be 1,2,3 or 5 ");
			if (geo.getGeoTypeId() == 1 || geo.getGeoTypeId() == 2 || geo.getGeoTypeId() == 3
					|| geo.getGeoTypeId() == 5) {

				if (geo.getGeoTypeId() == 1
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"GeoTypeValue should be maximum of 3 characters for  Airport/City Code");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					if (!airportService.isValidAirportCodeOrCityCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. Airport/City Code : "
								+ geo.getGeoTypeValue().toUpperCase() + "Does not exist or not active");
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 2
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 2) {
							typeValueList.clear();
							throw new BusinessException(
									"GeoTypeValue should be maximum of 2 characters for countryCode");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					try {
						countryService.getCountryByCountryCode(geo.getGeoTypeValue().toUpperCase());
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. Country Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					} catch (BusinessException se) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. Country Code :"
								+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 3
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {

					if (flag) {
						typeValueList.clear();
						throw new BusinessException("Geo Type Id 3 is not applicable for excludeGeoList");
					}
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 3) {
							typeValueList.clear();
							throw new BusinessException(
									"GeoTypeValue should be maximum of 3 characters for standardAreaCode");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					try {
						if (!standardAreaSrevice.isValidateStandardArea(geo.getGeoTypeValue().toUpperCase())) {
							typeValueList.clear();
							throw new BusinessException("Invalid Geo Type Value. standardArea Code :"
									+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
						}
					} catch (ResourceNotFoundException rnfe) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. standardArea Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST);
					} catch (BusinessException se) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. standardArea Code :"
								+ geo.getGeoTypeValue().toUpperCase() + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (geo.getGeoTypeId() == 5
						&& !typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					if (!geo.getGeoTypeValue().isEmpty()) {
						if (geo.getGeoTypeValue().length() > 4) {
							typeValueList.clear();
							throw new BusinessException("GeoTypeValue should be maximum of 4 characters for stateCode");
						}
					} else {
						typeValueList.clear();
						throw new BusinessException(MANDATORYGEOTYPEVALUE);
					}
					if (!airportService.isValidStateCode(geo.getGeoTypeValue().toUpperCase())) {
						typeValueList.clear();
						throw new BusinessException("Invalid Geo Type Value. State Code : "
								+ geo.getGeoTypeValue().toUpperCase() + DOESNOTEXIST + " or " + ISNOTACTIVE);
					}
					typeValueList.add(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase());
					geoString.append(geo.toString().toUpperCase());
					geoString.append(",");

				} else if (typeValueList.contains(geo.getGeoTypeId() + geo.getGeoTypeValue().toUpperCase())) {
					typeValueList.clear();
					throw new BusinessException("Duplicate Geotype Value: " + geo.getGeoTypeValue().toUpperCase());
				}

			} else {
				typeValueList.clear();
				throw new BusinessException(
						"Invalid Geo type id :" + geo.getGeoTypeId() + " Only 1,2,3,5 are the valid Geo type id ");
			}

		}
		if (geoString.length() > 1000) {
			typeValueList.clear();
			throw new BusinessException(
					"Area include list or Area exclude list length must be less than 1000 charecters");
		}
		if (geoString.length() != 0) {
			geoString.delete(geoString.length() - 1, geoString.length());
		}
		return geoString;

	}

	public String[] validateArea(Optional<String> geoArea, List<Geo> list, List<Geo> list2, String userAreaName,
			String area) {

		String[] array = new String[2];
		String areaInclude = "";
		String areaExclude = "";

		if (OptionalUtil.getValue(geoArea).startsWith("1") || OptionalUtil.getValue(geoArea).startsWith("2")
				|| OptionalUtil.getValue(geoArea).startsWith("3") || OptionalUtil.getValue(geoArea).startsWith("5")) {
			if (list != null || list2 != null || userAreaName != null) {
				throw new BusinessException("For " + OptionalUtil.getValue(geoArea)
						+ " IncludeArea, ExcludeArea and userAreaName not required for non User Defined Area");
			}
		}
		if (OptionalUtil.getValue(geoArea) != null) {
			if (OptionalUtil.getValue(geoArea).startsWith("1")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(AIRPORTCITY);
				} else {
					if (!airportService.isValidAirportCodeOrCityCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(AIRPORTCITYINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("2")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(COUNTRYCODEALPHA);
				} else {
					if (!countryService.isValidCountryCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(COUNTRYCODEINVALID
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("3")) {
				if (!standardAreaSrevice.getActiveStandardAreaByStandardAreaCode(
						OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
					throw new BusinessException(INVALIDSTDAREACODE
							+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("4") && area.equals(GLOBAL)) {
				boolean flag = false;
				List<Geo> geoFromAreaInclude = list;
				if (list != null && !list.isEmpty()) {

					if (userAreaName == null) {
						throw new BusinessException("Please provide User Area Name");
					}

					StringBuilder geoString = new StringBuilder();
					StringBuilder strareaIncludeList = userGeoList(geoFromAreaInclude, geoString, flag);
					areaInclude = strareaIncludeList.toString();
					if (list2 != null) {
						List<Geo> geoFromAreaExclude = list2;
						StringBuilder geoString1 = new StringBuilder();
						flag = true;
						StringBuilder strAreaExcludeList = userGeoList(geoFromAreaExclude, geoString1, flag);

						areaExclude = strAreaExcludeList.toString();
					}
					array[0] = areaInclude;
					array[1] = areaExclude;

				} else {
					throw new BusinessException(FROMAREAINCLUDEMENDATORY);
				}
			} else if (OptionalUtil.getValue(geoArea).startsWith("5")) {
				if (!Pattern.compile(PATTERN)
						.matcher(OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))
						.find()) {
					throw new BusinessException(STATECODEALPHA);
				} else {
					if (!airportService.isValidStateCode(
							OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()))) {
						throw new BusinessException(INVALIDSTATECODE
								+ OptionalUtil.getValue(geoArea).substring(1, OptionalUtil.getValue(geoArea).length()));
					}
				}
			}
		}
		return array;
	}

	@Override
	public void deleteProvisoRoutingByProvisoMainId(Integer provisoMainId) {
		List<ProvisoRoutingStgEntity> routineList = provisoRoutingStgDao.findByMainId(Optional.of(provisoMainId));
		
		getAreaFromFlag = false;
		getAreaToFlag = false;
		
		if (!routineList.isEmpty()) {
			routineList.stream().filter(Objects::nonNull).forEach(routine -> {
				if (Objects.nonNull(routine.getAreaFrom())) {
					getAreaFromFlag = routine.getAreaFrom().startsWith("4");
				}
				if (Objects.nonNull(routine.getAreaTo())) {
					getAreaToFlag = routine.getAreaTo().startsWith("4");
				}
				if (getAreaFromFlag || getAreaToFlag) {
					userAreaSrevice.deleteUserArea("P", routine.getCarrierNumCode(), routine.getProvisoRoutingId().toString());
				}
			});
			
		}
		provisoRoutingStgDao.deleteProvisoRoutingByProvisoMainId(provisoMainId);
	}

	@Override
	public void deleteProvisoRoutingByProvisoRoutingId(Integer provisoRoutingId) {
		ProvisoRoutingStgEntity routingEntity = provisoRoutingStgDao.findById(provisoRoutingId)
		.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoRoutingId)));
		
		getAreaFromFlag = false;
		getAreaToFlag = false;
		
		if (Objects.nonNull(routingEntity.getAreaFrom())) {
			getAreaFromFlag = routingEntity.getAreaFrom().startsWith("4");
		}
		if (Objects.nonNull(routingEntity.getAreaTo())) {
			getAreaToFlag = routingEntity.getAreaTo().startsWith("4");
		}	
			if (getAreaFromFlag || getAreaToFlag) {
				userAreaSrevice.deleteUserArea("P", routingEntity.getCarrierNumCode(), routingEntity.getProvisoRoutingId().toString());
			}
			provisoRoutingStgDao.deleteProvisoRoutingByProvisoRoutingId(provisoRoutingId);
		
	}
}
