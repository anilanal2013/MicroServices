package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.CountryEntity;

public interface CountryDao {

	public CountryEntity create(CountryEntity countryEntity);

	public CountryEntity update(CountryEntity countryEntity);

	public Optional<CountryEntity> findByCountryCode(String countryCode);

	public List<CountryEntity> getListOfCountries(Optional<String> countryCode, Optional<String> countryName);

	public List<CountryEntity> getListOfCountriesByIsActive(Optional<String> countryCode, Optional<String> countryName,
			Optional<Boolean> activate);

	public List<CountryEntity> findDistinctByCountryCodeIsNotNullAndIsActiveTrueOrderByCountryCode();

	public Long getCountryCode(String countryCode);

	public List<String> getCountryCodeList(List<String> countryCodeList);

	public long validateISOCountryCode(String isoCountryCode);

	public long validateISOCountryCodeForUpdate(String isoCountryCode, String countryCode);

	public long validateCountryNumber(Integer countryNumber);

	public long validateCountryNumberForUpdate(Integer countryNumber, String countryCode);

	public List<CountryEntity> findDistinctByCountryCodeIsNotNullAndActivateTrueOrderByCountryCode();

}
