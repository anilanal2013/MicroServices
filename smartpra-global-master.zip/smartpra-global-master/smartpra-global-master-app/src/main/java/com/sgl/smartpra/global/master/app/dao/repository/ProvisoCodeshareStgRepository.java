package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareStgEntity;

@Repository
public interface ProvisoCodeshareStgRepository
		extends JpaRepository<ProvisoCodeshareStgEntity, Integer>, JpaSpecificationExecutor<ProvisoCodeshareStgEntity> {
	@Query(value = "select pcs.provisoMainId from ProvisoCodeshareStgEntity pcs")
	List<Integer> getListOfProvisoMainIdFromCodeshareStgDb();

	@Transactional
	@Modifying
	@Query("delete from ProvisoCodeshareStgEntity pcse where pcse.provisoMainId= ?1")
	void deleteProvisoCodehareByProvisoMainId(Integer provisoMainId);

	@Query(value = "select max(pcs.codeshareRecNumber) from ProvisoCodeshareStgEntity pcs where pcs.carrierNumCode=?1 AND pcs.provisoSeqNumber=?2")
	Integer getMaxOfCodeshareRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);
}
