package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoDetailStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoDetailStgEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoDetailStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoDetailStgDaoImpl implements ProvisoDetailStgDao {

	@Autowired
	private ProvisoDetailStgRepository provisoDetailStgRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "provisoDetailStgModel", key = "#provisoDetailStgEntity.provisoDetailId") })
	public ProvisoDetailStgEntity create(ProvisoDetailStgEntity provisoDetailStgEntity) {
		return provisoDetailStgRepository.save(provisoDetailStgEntity);
	}

	@Override
	public List<ProvisoDetailStgEntity> findByMainId(Optional<Integer> provisoMainId) {

		return provisoDetailStgRepository.findAll(ProvisoDetailStgEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	@Cacheable(value = "provisoDetailStgModel", key = "#id")
	public Optional<ProvisoDetailStgEntity> findById(Integer id) {
		log.info("Cacheable Proviso Detail Entity's ID= {}", id);
		return provisoDetailStgRepository.findById(id);
	}

	@Override
	public List<ProvisoDetailStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {
		return provisoDetailStgRepository
				.findAll(ProvisoDetailStgEntitySpecification.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	@CachePut(value = "provisoDetailStgModel", key = "#provisoDetailStgEntity.provisoDetailId")
	@CacheEvict(value = "ProvisoDetailSearch", allEntries = true)
	public ProvisoDetailStgEntity update(ProvisoDetailStgEntity provisoDetailStgEntity) {
		return provisoDetailStgRepository.save(provisoDetailStgEntity);
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer detailRecNumber) {

		return provisoDetailStgRepository
				.count(Specification.where(ProvisoDetailStgEntitySpecification.equalsCarrierNumCode(carrierNumCode)
						.and(ProvisoDetailStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
						.and(ProvisoDetailStgEntitySpecification.equalsDetailRecNumber(detailRecNumber))));
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer detailRecNumber,
			Integer provisoDetailId) {

		return provisoDetailStgRepository
				.count(Specification.where(ProvisoDetailStgEntitySpecification.equalsCarrierNumCode(carrierNumCode)
						.and(ProvisoDetailStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
						.and(ProvisoDetailStgEntitySpecification.equalsDetailRecNumber(detailRecNumber))
						.and(ProvisoDetailStgEntitySpecification.notEqualsProvisoSectorId(provisoDetailId))));
	}

	@Override
	public List<ProvisoDetailStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> fbGroupCode) {

		return provisoDetailStgRepository
				.findAll(ProvisoDetailStgEntitySpecification.search(carrierNumCode, provisoSeqNumber, fbGroupCode));
	}

	@Override
	public List<Integer> getListOfProvisoMainIdFromDetailStgDb() {

		return provisoDetailStgRepository.getListOfProvisoMainIdFromDetailStgDb();
	}

	@Override
	public void deleteProvisoDetailByProvisoMainId(Integer provisoMainId) {
		provisoDetailStgRepository.deleteProvisoDetailByProvisoMainId(provisoMainId);
	}

	@Override
	public void deleteProvisoDetailByProvisoDetailId(Integer provisoDetailId) {
		provisoDetailStgRepository.deleteById(provisoDetailId);

	}
	
	@Override
	public Integer getMaxOfProvisoDetailRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {
		return provisoDetailStgRepository.getMaxOfProvisoDetailRecNumber(carrierNumCode,provisoSeqNumber);
	}
}
