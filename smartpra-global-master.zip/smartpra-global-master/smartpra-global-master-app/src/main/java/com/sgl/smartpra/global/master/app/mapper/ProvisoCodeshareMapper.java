package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareEntity;
import com.sgl.smartpra.global.master.model.ProvisoCodeshareModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoCodeshareMapper extends BaseMapper<ProvisoCodeshareModel, ProvisoCodeshareEntity> {
	ProvisoCodeshareEntity mapToEntity(ProvisoCodeshareModel provisoCodeshareModel,
			@MappingTarget ProvisoCodeshareEntity provisoCodeshareEntity);
	@Mapping(source = "provisoCodeshareId", target = "provisoCodeshareId", ignore = true)
	ProvisoCodeshareEntity mapToEntity(ProvisoCodeshareModel provisoCodeshareModel);
}
