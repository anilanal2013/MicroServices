package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.DictionaryDao;
import com.sgl.smartpra.global.master.app.dao.entity.spec.DictionaryEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.DictionaryRepository;
import com.sgl.smartpra.global.master.app.repository.entity.DictionaryEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DictionaryDaoImpl implements DictionaryDao {

	@Autowired
	DictionaryRepository dictionaryRepository;

	@Override
	@Cacheable(value = "dictionaryEntity", key="#id")
	public Optional<DictionaryEntity> findById(Integer dictionaryId) {
		log.info("Cacheable Dictionary Entity's ID= {}", dictionaryId);
		return dictionaryRepository.findById(dictionaryId);
	}

	@Override
	@Caching(evict= {@CacheEvict(value="dictionaryEntity",key = "#dictionaryEntity.dictionaryId")})
	public DictionaryEntity create(DictionaryEntity dictionaryEntity) {
		return dictionaryRepository.save(dictionaryEntity);
	}

	@Override
	@CachePut(value = "dictionaryEntity", key = "#dictionaryEntity.dictionaryId")
	public DictionaryEntity update(DictionaryEntity dictionaryEntity) {
		return dictionaryRepository.save(dictionaryEntity);
	}

	
	@Override
	@Caching(evict = { @CacheEvict(value = "dictionaryEntity", key = "#id") })
	public void deleteById(Integer id) {
		dictionaryRepository.deleteById(id);
		
	}

	@Override
	public List<DictionaryEntity> getAllDictionarys(Optional<String> elementName, Optional<String> dictionaryDefine) {
		return dictionaryRepository.findAll(DictionaryEntitySpecification.search(elementName,dictionaryDefine));
	}
	
	public DictionaryEntity getDictionaryByElementName(String elementName) {
		return null;
	}
}
