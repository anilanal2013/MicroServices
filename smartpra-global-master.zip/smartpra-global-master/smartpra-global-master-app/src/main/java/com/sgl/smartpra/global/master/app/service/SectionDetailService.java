package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.SectionDetail;

public interface SectionDetailService {

	SectionDetail findSectionDetailBySectionDetailId(Integer sectionMasterId, Integer sectionDetailId);

	List<SectionDetail> getAllSectionDetails(Integer sectionMasterId, Integer sectionDetailId,
			Optional<String> sectionElementName, Optional<Boolean> activate);
	
	SectionDetail createSectionDetail(Integer sectionMasterId, SectionDetail sectionDetail);

	List<SectionDetail> updateSectionDetail(List<SectionDetail> sectionDetails);

	public void deactivateSection(Integer sectionMasterId, Integer sectionDetailId, String lastUpdatedBy);

	public void activateSection(Integer sectionMasterId, Integer sectionDetailId, String lastUpdatedBy);

	public List<SectionDetail> getListOfSectionDetailsByChargeCode(String chargeCode, Optional<String> sectionElementName, Optional<Boolean> activate);
	
}
