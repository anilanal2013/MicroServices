package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ProvisoRoutingDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingEntity;
import com.sgl.smartpra.global.master.app.mapper.ProvisoRoutingCombinedMapper;
import com.sgl.smartpra.global.master.app.mapper.ProvisoRoutingMapper;
import com.sgl.smartpra.global.master.app.service.ProvisoRoutingService;
import com.sgl.smartpra.global.master.model.ProvisoRouting;
import com.sgl.smartpra.global.master.model.ProvisoRoutingStg;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoRoutingServiceImpl implements ProvisoRoutingService {
	@Autowired
	private ProvisoRoutingMapper provisoRoutingMapper;
	@Autowired
	ProvisoRoutingCombinedMapper provisoRoutingCombinedMapper;
	@Autowired
	private ProvisoRoutingDao provisoRoutingDao;

	private static final String ROUTING_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso Routing data not available for selected Proviso Main record";

	@Override
	public List<ProvisoRouting> getProvisoRoutingByProvisoMainId(Optional<Integer> provisoMainId) {
		List<Integer> provisoMainIdFromDb = provisoRoutingDao.getListOfProvisoMainIdFromRoutingDb();
		if (!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))) {
			throw new BusinessException(ROUTING_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		return provisoRoutingMapper.mapToModel(provisoRoutingDao.findByMainId(provisoMainId));
	}

	@Override
	public ProvisoRouting getProvisoRoutingByProvisoRoutingId(Integer provisoRoutingId) {

		return provisoRoutingMapper.mapToModel(provisoRoutingDao.findById(provisoRoutingId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoRoutingId))));
	}

	@Override
	public List<ProvisoRouting> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber) {

		return provisoRoutingMapper
				.mapToModel(provisoRoutingDao.search(carrierNumCode, provisoSeqNumber, detailRecNumber));
	}

	@Override
	public ProvisoRoutingStg saveProvisoRouting(ProvisoRoutingStg provisoRoutingStg) {
		provisoRoutingStg.setCreatedDate(LocalDateTime.now());
		return provisoRoutingCombinedMapper
				.mapToModel(provisoRoutingDao.create(provisoRoutingCombinedMapper.mapToEntity(provisoRoutingStg)));
	}
}
