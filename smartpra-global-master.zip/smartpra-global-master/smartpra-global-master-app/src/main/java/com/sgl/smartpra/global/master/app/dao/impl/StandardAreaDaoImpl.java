package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.StandardAreaDao;
import com.sgl.smartpra.global.master.app.dao.entity.spec.StandardAreaElementSpecification;
import com.sgl.smartpra.global.master.app.repository.StandardAreaRepository;
import com.sgl.smartpra.global.master.app.repository.entity.StandardAreaEntity;
import com.sgl.smartpra.global.master.model.Currency;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class StandardAreaDaoImpl extends CommonSearchDao<Currency> implements StandardAreaDao {

	@Autowired
	private StandardAreaRepository standardAreaRepository;

	@Override
	@Cacheable(value = "standardArea", key = "#standardAreaCode")
	public Optional<StandardAreaEntity> findById(String standardAreaCode) {
		return standardAreaRepository.findById(standardAreaCode);
	}

	@Override
	public List<StandardAreaEntity> search(Optional<String> standardAreaCode, Optional<String> standardAreaName,
			Boolean activate) {
		return standardAreaRepository
				.findAll(StandardAreaElementSpecification.search(standardAreaCode, standardAreaName, activate));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "standardArea", key = "#mapToEntity.standardAreaCode") })
	public StandardAreaEntity create(StandardAreaEntity mapToEntity) {
		return standardAreaRepository.save(mapToEntity);
	}

	@Override
	@CachePut(value = "standardArea", key = "#standardAreaEntity.standardAreaCode")
	public StandardAreaEntity update(StandardAreaEntity standardAreaEntity) {
		return standardAreaRepository.save(standardAreaEntity);
	}

	@Override
	public List<StandardAreaEntity> findByStandardAreaList(String cityCode, String stateCode, String countryCode) {
		return standardAreaRepository.findAll(Specification
				.where(StandardAreaElementSpecification.findByStandardAreaList(cityCode, stateCode, countryCode)
						.and(StandardAreaElementSpecification.isActive())));
	}

	@Override
	public long isValidateStandardArea(String standardAreaCode) {
		return standardAreaRepository.count(StandardAreaElementSpecification.equalStandardAreaCode(standardAreaCode)
				.and(StandardAreaElementSpecification.equalsActivate(true)));
	}
	
	@Override
	public List<StandardAreaEntity> findDistinctByStandardAreaCodeIsNotNullAndIsActiveTrueOrderByStandardAreaCode() {
		return standardAreaRepository.findDistinctByStandardAreaCodeIsNotNullAndActivateTrueOrderByStandardAreaCode();
	}
	
	@Override
	public StandardAreaEntity findByStandardAreaCodeAndActivate(String standardAreaCode) {
		return standardAreaRepository.findByStandardAreaCodeAndActivate(standardAreaCode, true);
	}

}
