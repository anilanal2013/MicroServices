package com.sgl.smartpra.global.master.app.dao.entity;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "mas_rate_agreement",schema = "SmartPRAMaster")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class RateAndAgreementEntity extends BaseEntity {

	
	private static final long serialVersionUID = 1L;
	
	
    @Id
    @Column(name = "rate_agreement_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer rateAgreementId;

    @Column(name = "supplier_type", nullable = false, length = 1)
    private String supplierType;

    @Column(name = "supplier_code", nullable = false, length = 3)
    private String supplierCode;

    @Column(name = "location_code", nullable = false, length = 3)
    private String locationCode;

    @Column(name = "charge_cat_code", nullable = false, length = 3)
    private String chargeCategory;

    @Column(name = "charge_code", nullable = false, length = 6)
    private String chargeCode;

    @Column(name = "rate_type", nullable = false, length = 1)
    private String rateType;

    @Column(name = "flight_type", nullable = false, length = 1)
    private String flightType;

    @Column(name = "schedule_or_charter", nullable = true, length = 1)
    private String scheduleOrCharter;

    @Column(name = "airport_code", nullable = false, length = 3)
    private String airport;

    @Column(name = "aircraft_type", nullable = true, length = 5)
    private String aircraftType;

    @Column(name = "engine_number", nullable = true, length = 50)
    private String engineNumber;

    @Column(name = "carrier_code", nullable = true, length = 3)
    private String carrier;

    @Column(name = "flight_no", nullable = true, length = 4)
    private String flightNo;

    @Column(name = "sector", nullable = true, length = 7)
    private String sector;

    @Column(name = "arrival_or_departure", nullable = true, length = 1)
    private String arrivalOrDeparture;

    @Column(name = "base_airport", nullable = true, length = 3)
    private String baseAirport;

    @Column(name = "effective_from_date", nullable = false)
    private LocalDate effectiveFromDate;

    @Column(name = "effective_to_date", nullable = false)
    private LocalDate effectiveToDate;

    @Column(name = "currency_code_local", nullable = false, length = 3)
    private String currencyCodeLocal;

    @Column(name = "currency_code_invoice", nullable = false, length = 3)
    private String currencyCodeInvoice;

    @Column(name = "exchange_rate", nullable = true)
    private BigDecimal exchangeRate;

    @Column(name = "quantity", nullable = false, precision = 10, scale = 2)
    private BigDecimal quantity;

    @Column(name = "unit_of_measurement", nullable = false, length = 3)
    private String unitOfMeasurement;

    @Column(name = "rates", nullable = false, length = 500)
    private String rates;

    @Column(name = "variance_percentage", nullable = true, precision = 5, scale = 2)
    private BigDecimal variancepercentage;

    @Column(name = "include_tax_indicator", nullable = true, length = 1)
    private String rateIncludeTaxIndicators;

    @Column(name = "date_time_validity", nullable = false, length = 1)
    private String dateAndTimeValidity;

    @Column(name = "applicable_airports", nullable = true, length = 1000)
    private String applicableAirports;

    @Column(name = "client_id", nullable = false, length = 2)
    private String clientId;

    @Column(name = "contract_reference" , nullable = true, length = 500)
    private String contractRef;

    @PrePersist
    public void prePersist() {
        setCreatedDate(LocalDateTime.now());
    }

    @PreUpdate
    public void preUpdate() {
        setLastUpdatedDate(LocalDateTime.now());
    }
}
