package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailStgEntity;

public class ProvisoDetailStgEntitySpecification {
	private ProvisoDetailStgEntitySpecification() {
	}

	public static Specification<ProvisoDetailStgEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber) {
		return (provisoDetailStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoDetailStgEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoDetailStgEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProvisoDetailStgEntity> findByMainId(Optional<Integer> provisoMainId) {
		return (provisoDetailStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoDetailStgEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProvisoDetailStgEntity> equalsCarrierNumCode(String carrierNumCode) {
		return (provisoDetailStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoDetailStgEntity.get("carrierNumCode"), carrierNumCode);
	}

	public static Specification<ProvisoDetailStgEntity> equalsProvisoSeqNumber(Integer provisoSeqNumber) {
		return (provisoDetailStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoDetailStgEntity.get("provisoSeqNumber"), provisoSeqNumber);
	}

	public static Specification<ProvisoDetailStgEntity> equalsDetailRecNumber(Integer detailRecNumber) {
		return (provisoDetailStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoDetailStgEntity.get("detailRecNumber"), detailRecNumber);
	}

	public static Specification<ProvisoDetailStgEntity> notEqualsProvisoSectorId(Integer provisoDetailId) {
		return (provisoSectorStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(provisoSectorStgEntity.get("provisoDetailId"), provisoDetailId);
	}

	public static Specification<ProvisoDetailStgEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<String> fbGroupCode) {
		return (provisoDetailStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoDetailStgEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoDetailStgEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			if (OptionalUtil.isPresent(fbGroupCode)) {
				predicates.add(criteriaBuilder.equal(provisoDetailStgEntity.get("fbGroupCode"),
						OptionalUtil.getValue(fbGroupCode)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
