package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.Fares;

public interface FaresService {
	
	public Fares createFares(Fares fares);

	public Fares updateFares(Fares fares);
	
	public Fares getFaresByFareId(Integer fareId);
	
	public List<Fares> findAll();

	public List<Fares> getFareBySearch(Optional<String> cxrCode, Optional<String> originCity, Optional<String> destinationCity,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate);

	public void deactivateFare(Fares fares);

	public void activateFare(Fares fares);

	public List<Fares> getFareForFareSelectionProcessing(Optional<String> cxrCode, Optional<String> originCity,
			Optional<String> destinationCity, Optional<String> effectiveDate);	 

}
