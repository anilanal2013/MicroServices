package com.sgl.smartpra.global.master.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.GeographyTypeEntity;

@Repository
public interface GeographyTypeRepository
		extends JpaRepository<GeographyTypeEntity, Integer>, JpaSpecificationExecutor<GeographyTypeEntity> {

}
