package com.sgl.smartpra.global.master.app.service.impl;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.AircraftTypeDao;
import com.sgl.smartpra.global.master.app.dao.entity.AircraftTypeEntity;
import com.sgl.smartpra.global.master.app.mapper.AircraftTypeMapper;
import com.sgl.smartpra.global.master.app.service.AircraftTypeService;
import com.sgl.smartpra.global.master.model.AircraftType;

@Service
@Transactional
public class AircraftTypeServiceImpl implements AircraftTypeService{

	@Autowired
	AircraftTypeMapper aircraftTypeMapper;
	
	@Autowired
	AircraftTypeDao aircraftTypeDao;
	
	@Override
	public AircraftType findAircraftTypeById(Optional<String> aircraftTypeCode) {
		AircraftTypeEntity entity = aircraftTypeDao.findOne(aircraftTypeCode)
				.orElseThrow(() -> new RecordNotFoundException(OptionalUtil.getValue(aircraftTypeCode)));
		
		return aircraftTypeMapper.mapToModel(entity);
	}

	@Override
	public List<AircraftType> findAircraftType() {
		return  aircraftTypeMapper.mapToModel(aircraftTypeDao.findAll());
	}
}
