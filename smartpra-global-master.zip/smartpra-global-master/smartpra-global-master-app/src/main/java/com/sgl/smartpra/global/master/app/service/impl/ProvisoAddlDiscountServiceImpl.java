package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ProvisoAddlDiscountDao;
import com.sgl.smartpra.global.master.app.mapper.ProvisoAdditionalDiscountMapper;
import com.sgl.smartpra.global.master.app.mapper.ProvisoAddlDiscountCombinedMapper;
import com.sgl.smartpra.global.master.app.service.ProvisoAddlDiscountService;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscount;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscountStg;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoAddlDiscountServiceImpl implements ProvisoAddlDiscountService {
	@Autowired
	private ProvisoAdditionalDiscountMapper provisoAdditionalDiscountMapper;
	@Autowired
	private ProvisoAddlDiscountCombinedMapper provisoAddlDiscountCombinedMapper;
	@Autowired
	private ProvisoAddlDiscountDao provisoAddlDiscountDao;

	private static final String ADDLDISCOUNT_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso Additional Discount data not available for selected Proviso Main record";

	@Override
	public List<ProvisoAdditionalDiscount> getProvisoAddlDiscountByProvisoMainId(Optional<Integer> provisoMainId) {
		List<Integer> provisoMainIdFromDb = provisoAddlDiscountDao.getListOfProvisoMainIdFromAddlDiscountDb();
		if (!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))) {
			throw new BusinessException(ADDLDISCOUNT_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		return provisoAdditionalDiscountMapper.mapToModel(provisoAddlDiscountDao.findByMainId(provisoMainId));
	}

	@Override
	public ProvisoAdditionalDiscount getProvisoAddlDiscountByProvisoAddlDiscountId(Integer provisoAddlDiscountId) {

		return provisoAdditionalDiscountMapper.mapToModel(provisoAddlDiscountDao.findById(provisoAddlDiscountId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoAddlDiscountId))));
	}

	@Override
	public List<ProvisoAdditionalDiscount> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> discountCode) {

		return provisoAdditionalDiscountMapper
				.mapToModel(provisoAddlDiscountDao.search(carrierNumCode, provisoSeqNumber, discountCode));
	}

	@Override
	public ProvisoAdditionalDiscountStg saveProvisoAddlDiscount(
			ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg) {
		provisoAdditionalDiscountStg.setCreatedDate(LocalDateTime.now());
		return provisoAddlDiscountCombinedMapper.mapToModel(provisoAddlDiscountDao
				.create(provisoAddlDiscountCombinedMapper.mapToEntity(provisoAdditionalDiscountStg)));

	}
}
