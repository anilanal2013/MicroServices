package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.AirportResponse;
import com.sgl.smartpra.global.master.model.CommonIdName;

@RestController
public class AirportController {

	@Autowired
	private AirportService airportService;

	@GetMapping("/airports")
    public List<Airport> getAllAirport(@RequestParam(name = "airportCode", required=false) Optional<String> airportCode,
    		@RequestParam(name = "airportName", required=false) Optional<String> airportName,
			@RequestParam(name = "cityCode", required=false) Optional<String> cityCode,
			@RequestParam(name = "cityName", required=false) Optional<String> cityName,
			@RequestParam(name = "countryCode", required=false) Optional<String> countryCode) {
		return airportService.getAllAirport(airportCode, airportName, cityCode, cityName,countryCode);
    }
	
	@GetMapping("/airportList")
    public AirportResponse getAllAirport(Pageable pageable, 
    		@RequestParam(name = "airportCode") @OptionalNotEmpty Optional<String> airportCode,
    		@RequestParam(name = "airportName") @OptionalNotEmpty Optional<String> airportName,
			@RequestParam(name = "cityCode") @OptionalNotEmpty Optional<String> cityCode,
			@RequestParam(name = "cityName") @OptionalNotEmpty Optional<String> cityName,
			@RequestParam(name = "countryCode") @OptionalNotEmpty Optional<String> countryCode,
			@RequestParam(name = "isActive", required=false) Boolean isActive,
			@RequestParam(value = "exceptionCall", required = false) Optional<String> exceptionCall) {
		Airport airport=new Airport();
		airport.setAirportCode(airportCode);
		airport.setAirportName(airportName);
		airport.setCityCode(cityCode);
		airport.setCityName(cityName);
		airport.setCountryCode(countryCode);
		airport.setIsActive(isActive);
		return airportService.findAll(airport, exceptionCall,pageable);
    }
	
	@GetMapping("/airports/{airportCode}")
	public Airport getAirportByAirportCode(@PathVariable(value = "airportCode") String airportCode) {
		return airportService.findAirportByAirportCode(airportCode);
	}

	@PostMapping("/airports")
	@ResponseStatus(value = HttpStatus.CREATED)
	public Airport createAirport(@Validated(Create.class) @RequestBody Airport airport) {
		return airportService.createAirport(airport);
	}

	@PutMapping("/airports/{airportCode}")
	@ResponseStatus(value = HttpStatus.OK)
	public Airport updateAirport(@PathVariable(value = "airportCode") String airportCode,
			@Validated(Update.class) @RequestBody Airport airport) {
		airport.setAirportCode(Optional.of(airportCode));
		return airportService.updateAirport(airport);
	}

	@PutMapping("/airports/{airportCode}/deactivate")
	public void deactivateAirport(@Valid @PathVariable(value = "airportCode") String airportCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		airportService.deactivateAirport(airportCode, lastUpdatedBy);

	}

	@PutMapping("/airports/{airportCode}/activate")
	public void activateAirport(@Valid @PathVariable(value = "airportCode") String airportCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		airportService.activateAirport(airportCode, lastUpdatedBy);

	}

	@GetMapping("/airports/{airportCode}/validate")
	public boolean isValidAirportCodeOrCityCode(@PathVariable(value = "airportCode") String airportCode) {
		return airportService.isValidAirportCodeOrCityCode(airportCode);
	}
	
	@GetMapping("/airports/{stateCode}/isValid")
	public boolean isValidStateCode(@PathVariable(value = "stateCode") String stateCode) {
		return airportService.isValidStateCode(stateCode);
	}
	
	@GetMapping("/airports/{cityCode}/isValidCityCode")
	public boolean isValidCityCode(@PathVariable(value = "cityCode") String cityCode) {
		return airportService.isValidCityCode(cityCode);
	}
	
	@GetMapping("/airports/{airportCode}/isValidAirportCode")
	public boolean isValidAirportCode(@PathVariable(value = "airportCode") String airportCode) {
		return airportService.isValidAirportCode(airportCode);
	}
	

	@GetMapping("/airports/{airportCode}/aiportCodes")
	public List<Airport> findCityByAirportCode(@PathVariable(value = "airportCode") String airportCode) {
		return airportService.findCityByAirportCode(airportCode);
	}
	
	@GetMapping("/airports/airport-list")
	public List<CommonIdName> getAirportList() {
		return airportService.getAirportList();
	}

	@GetMapping("/airports/city-list")
	public List<CommonIdName> getCityList() {
		return airportService.getCityList();
	}

	@GetMapping("/airports/state-list")
	public List<CommonIdName> getStateList() {
		return airportService.getStateList();
	}
	
	@GetMapping("/airports/{airportCode}/country")
	public String findCountryCodeByAirportCodeOrCityCode(@PathVariable(value = "airportCode") String airportCode) {
		return airportService.findCountryCodeByAirportCodeOrCityCode(airportCode);
	}
	
	@GetMapping("/airports/state-city-list")
    public List<Airport> getAirportByCityOrStateOrCountry(@RequestParam(name = "airportCode", required=false) Optional<String> airportCode,
    		@RequestParam(name = "stateCode", required=false) Optional<String> stateCode,
			@RequestParam(name = "cityCode", required=false) Optional<String> cityCode,
			@RequestParam(name = "countryCode", required=false) Optional<String> countryCode) {
		return airportService.getAirportByCityOrStateOrCountry(airportCode, stateCode, cityCode,countryCode);
    }
	
	@GetMapping("/airports/aiport-list")
	public String getTicketTravelDetail(
			@RequestParam(name = "airportCodes", required=true) List<String> airportCodes) {
		return airportService.getTicketTravelDetail(airportCodes);
	}
	
}
