package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.FareTypeHierarchyEntity;
import com.sgl.smartpra.global.master.model.FareTypeHierarchy;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, 
nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)

public interface FareTypeHierarchyMapper extends BaseMapper<FareTypeHierarchy, FareTypeHierarchyEntity>  {
	
	FareTypeHierarchyEntity mapToEntity(FareTypeHierarchy fareTypeHierarchy, @MappingTarget FareTypeHierarchyEntity fareTypeHierarchyEntity);

	@Mapping(source = "fareTypeHierarchyId", target = "fareTypeHierarchyId", ignore = true)
	FareTypeHierarchyEntity mapToEntity(FareTypeHierarchy fareTypeHierarchy);
	
}
