package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountStgEntity;
@Repository
public interface ProvisoAddlDiscountStgDao {
	ProvisoAdditionalDiscountStgEntity create(ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity);

	List<ProvisoAdditionalDiscountStgEntity> findByMainId(Optional<Integer> provisoMainId);

	Optional<ProvisoAdditionalDiscountStgEntity> findById(Integer id);

	public List<ProvisoAdditionalDiscountStgEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber);

	ProvisoAdditionalDiscountStgEntity update(ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity);

	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, String discountCode);

	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, String discountCode,
			Integer provisoAddlDiscountId);
	public List<Integer> getListOfProvisoMainIdFromAddlDiscountStgDb();

	void deleteProvisoAddlDiscountByProvisoMainId(Integer provisoMainId);

	void deleteProvisoAddlDiscountByProvisoAddlDiscountId(Integer provisoAddlDiscountId);
	
	public void deleteProvisoAddlDiscountStg(Integer provisoMainId,String carrierNumCode,Integer provisoSeqNumber);
	
}
