package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.FareTypeHierarchyEntity;;

public class FareTypeHeirarchyEntitySpecification {

	public FareTypeHeirarchyEntitySpecification() {

	}

	public static Specification<FareTypeHierarchyEntity> equalsCabin(String cabin) {
		return (fareTypeHeirarchyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareTypeHeirarchyEntity.get("cabin"), cabin);
	}

	public static Specification<FareTypeHierarchyEntity> equalsCabinLevel(Integer cabinLevel) {
		return (fareTypeHeirarchyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareTypeHeirarchyEntity.get("cabinLevel"), cabinLevel);
	}

	public static Specification<FareTypeHierarchyEntity> equalsFareTypeCode(String fareTypeCode) {
		return (fareTypeHeirarchyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareTypeHeirarchyEntity.get("fareTypeCode"), fareTypeCode);
	}

	public static Specification<FareTypeHierarchyEntity> notEqualsFareTypeHierarchyId(Integer fareTypeHierarchyId) {
		return (fareTypeHeirarchyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(fareTypeHeirarchyEntity.get("fareTypeHierarchyId"), fareTypeHierarchyId);
	}

	public static Specification<FareTypeHierarchyEntity> equalsFareTypeLevel(Integer fareTypeLevel) {
		return (fareTypeHeirarchyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareTypeHeirarchyEntity.get("fareTypeLevel"), fareTypeLevel);
	}

	public static Specification<FareTypeHierarchyEntity> equalsIsActive() {
		return (fareTypeHeirarchyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fareTypeHeirarchyEntity.get("activate"), true);
	}

	public static Specification<FareTypeHierarchyEntity> betweenEffectiveFromAndEffectiveToDate(
			LocalDate effectiveDate) {
		return (fareTypeHeirarchyEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), fareTypeHeirarchyEntity.get("effectiveFromDate"),
				fareTypeHeirarchyEntity.get("effectiveToDate"));
	}

	public static Specification<FareTypeHierarchyEntity> search(Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<Integer> cabinLevel, Optional<Integer> fareTypeLevel) {
		return (fareTypeHierarchyEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(cabinLevel)) {
				predicates.add(criteriaBuilder.equal(fareTypeHierarchyEntity.get("cabinLevel"),
						OptionalUtil.getValue(cabinLevel)));
			}
			if (OptionalUtil.isPresent(fareTypeLevel)) {
				predicates.add(criteriaBuilder.equal(fareTypeHierarchyEntity.get("fareTypeLevel"),
						OptionalUtil.getValue(fareTypeLevel)));
			}
			if (OptionalUtil.isPresent(effectiveFromDate)) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(fareTypeHierarchyEntity.get("effectiveFromDate"),
						OptionalUtil.getLocalDateValue(effectiveFromDate)));
			}
			if (OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(fareTypeHierarchyEntity.get("effectiveToDate"),
						OptionalUtil.getLocalDateValue(effectiveToDate)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<FareTypeHierarchyEntity> searchWithCabin(Optional<String> effectiveDate,
			Optional<String> cabin, Optional<Integer> fareTypeLevel) {
		return (fareTypeHierarchyEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(cabin)) {
				predicates
						.add(criteriaBuilder.equal(fareTypeHierarchyEntity.get("cabin"), OptionalUtil.getValue(cabin)));
			}
			if (OptionalUtil.isPresent(fareTypeLevel)) {
				predicates.add(criteriaBuilder.equal(fareTypeHierarchyEntity.get("fareTypeLevel"),
						OptionalUtil.getValue(fareTypeLevel)));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(fareTypeHierarchyEntity.get("effectiveFromDate"),
						OptionalUtil.getLocalDateValue(effectiveDate)));
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(fareTypeHierarchyEntity.get("effectiveToDate"),
						OptionalUtil.getLocalDateValue(effectiveDate)));
			}
			predicates.add(criteriaBuilder.equal(fareTypeHierarchyEntity.get("activate"), Boolean.TRUE));
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));

		};

	}

}
