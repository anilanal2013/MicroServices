package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.RejectionReasonCodeEntity;

public interface RejectionReasonCodeDao {


	public Optional<RejectionReasonCodeEntity> findById(String id);

	public RejectionReasonCodeEntity create(RejectionReasonCodeEntity rejectionReasonCodeEntity);

	public RejectionReasonCodeEntity update(RejectionReasonCodeEntity rejectionReasonCodeEntity);
	
	public List<RejectionReasonCodeEntity> update(List<RejectionReasonCodeEntity> rejectionReasonCodeEntity);
	
	public Optional<RejectionReasonCodeEntity> findOne(String id);

    List<RejectionReasonCodeEntity> findAll();
}
