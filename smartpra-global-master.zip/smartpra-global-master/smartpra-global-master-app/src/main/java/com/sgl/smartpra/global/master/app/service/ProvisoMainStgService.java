package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.ProvisoMainStgModel;

public interface ProvisoMainStgService {
	public ProvisoMainStgModel createProvisoMain(ProvisoMainStgModel provisoMainStgModel);

	public ProvisoMainStgModel updateProvisoMain(ProvisoMainStgModel provisoMainStgModel);

	public ProvisoMainStgModel moveProvisoMainToProd(Integer provisoMainId, ProvisoMainStgModel provisoMainStgModel);

	public void inActiveProvisoMain(ProvisoMainStgModel provisoMainStgModel);

	public List<ProvisoMainStgModel> search(Optional<String> carrierNumCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> provisoSection, Optional<String> provisoStatus);

	public ProvisoMainStgModel getProvisoMainByprovisoMainId(Integer provisoMainId);

	public void deleteProvisoMain(Integer provisoMainId);

	public List<CommonIdName> getDiscountList();
}
