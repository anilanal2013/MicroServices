package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.repository.entity.InvolIndicatorEntity;
import com.sgl.smartpra.global.master.model.InvolIndicator;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface InvolIndicatorMapper extends BaseMapper<InvolIndicator, InvolIndicatorEntity> {

	@Mapping(source = "involIndicatorId", target = "involIndicatorId", ignore = true)
	InvolIndicatorEntity mapToEntity(InvolIndicator involIndicator, @MappingTarget InvolIndicatorEntity involEntity);

	@Mapping(source = "involIndicatorId", target = "involIndicatorId", ignore = true)
	InvolIndicatorEntity mapToEntity(InvolIndicator involIndicator);
}
