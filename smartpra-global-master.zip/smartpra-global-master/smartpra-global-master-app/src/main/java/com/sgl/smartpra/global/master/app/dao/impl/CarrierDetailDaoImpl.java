package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.CarrierDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.CarrierDetailEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.CarrierDetailEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.CarrierDetailRepository;
import com.sgl.smartpra.global.master.model.Carrier;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CarrierDetailDaoImpl extends CommonSearchDao<Carrier> implements CarrierDetailDao {
	
	@Autowired
	private CarrierDetailRepository carrierDetailRepository;

	@Override
	@Cacheable(value = "carrierDetail", key = "#id")
	public Optional<CarrierDetailEntity> findById(Integer id) {
		log.info("Cacheable Carrier Entity's ID= {}", id);
		return carrierDetailRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "carrierDetail", key = "#carrierDetailEntity.carrierDetailId"),
			@CacheEvict(value = "carrierDetail", allEntries = true) })
	public CarrierDetailEntity create(CarrierDetailEntity carrierDetailEntity) {
		return carrierDetailRepository.save(carrierDetailEntity);
	}

	@Override
	@CachePut(value = "carrierDetail", key = "#carrierDetailEntity.carrierDetailId")
	@CacheEvict(value = "carrierDetail", allEntries = true)
	public CarrierDetailEntity update(CarrierDetailEntity carrierDetailEntity) {
		return carrierDetailRepository.save(carrierDetailEntity);
	}

	@Override
	public List<CarrierDetailEntity> findAll(Optional<String> carrierCode, Optional<String> effectiveDate) {
		return carrierDetailRepository.findAll(CarrierDetailEntitySpecification.search(carrierCode,effectiveDate));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "carrierDetail", key = "#carrierDetailEntity.carrierDetailId") })
	public void deleteById(Integer id) {
		carrierDetailRepository.deleteById(id);
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String carrierCode) {
		return carrierDetailRepository.count(Specification.where(CarrierDetailEntitySpecification.equalsCarrierCode(carrierCode))
				.and(CarrierDetailEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(CarrierDetailEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.or(CarrierDetailEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate))));
	}

	@Override
	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate,
			String carrierCode, Integer carrierDetailId) {
		return carrierDetailRepository.count(Specification.where(CarrierDetailEntitySpecification.equalsCarrierCode(carrierCode))
				.and(CarrierDetailEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
				.or(CarrierDetailEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))
				.or(CarrierDetailEntitySpecification.betweenEffectiveFrom(effectiveFromDate, effectiveToDate)))
				.and(CarrierDetailEntitySpecification.notEqualsCarrierDetailId(carrierDetailId)));
	}	
}
