package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.CountryDao;
import com.sgl.smartpra.global.master.app.dao.entity.CountryEntity;
import com.sgl.smartpra.global.master.app.mapper.CountryMapper;
import com.sgl.smartpra.global.master.app.service.CountryDetailService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.Country;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class CountryServiceImpl implements CountryService {

	private static final String COUNTRY = "country";
	private static final String COUNTRY_INACTIVE = "Country is inactive";
	private static final String INACTIVE_COUNTRY = "Given Country record is not active";
	private static final String ACTIVE_COUNTRY = "Given Country record is already active";
	private static final String COUNTRY_ALREADY_CREATED = "Record already exists";
	private static final String COUNTRY_CODE_UPDATE_VALIDATION = "Country code should not be changed";
	private static final String COUNTRY_CODE_MISMATCH = "Country Code in Json should be same as URL ";
	private static final String ISO_COUNTRY_CODE = "ISO Country Code should be unique";
	private static final String COUNTRY_NUMBER = "Country Number should be unique";

	@Autowired
	private CountryMapper countryMapper;

	@Autowired
	private CountryDao countryDao;

	@Autowired
	private CountryDetailService countryDetailService;

	public Country createCountry(Country country) {
		Country countryObj;
		Optional<CountryEntity> countryEntity = countryDao.findByCountryCode(country.getCountryCode());

		if (countryEntity.isPresent()
				&& (countryEntity.get().getCountryCode().equalsIgnoreCase(country.getCountryCode()))) {
			throw new BusinessException(COUNTRY_ALREADY_CREATED);
		}
		ValidateISOCountryCodeAndCountryNumber(country);

		country.setActivate(Boolean.TRUE);
		country.setCreatedDate(LocalDateTime.now());
		countryObj = countryMapper.mapToModel(countryDao.create(countryMapper.mapToEntity(country)));

//		if (country.getCopyFlag() != null && country.getCopyFlag()) {
//			countryDetailService.copyCountryDetailsRecordByCountryCode(country);
//		}
		return countryObj;
	}

	public Country getCountryByCountryCode(String countryCode) {

		return countryMapper.mapToModel(countryDao.findByCountryCode(countryCode)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(countryCode))));
	}

	public Country updateCountry(Country country, String countryCode) {
		log.info("{}", country);
		if (country.getCountryCode() != null) {
			if (!countryCode.equalsIgnoreCase(country.getCountryCode())) {
				throw new BusinessException(COUNTRY_CODE_MISMATCH);
			}
		} else {
			country.setCountryCode(countryCode);
		}
		CountryEntity countryEntity = countryDao.findByCountryCode(country.getCountryCode())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(country.getCountryCode())));

		if (!countryEntity.getActivate()) {
			throw new BusinessException(INACTIVE_COUNTRY);
		}

		if (!country.getCountryCode().equalsIgnoreCase(countryEntity.getCountryCode())) {
			throw new BusinessException(COUNTRY_CODE_UPDATE_VALIDATION);
		}
		ValidateISOCountryCodeAndCountryNumberForUpdate(country, countryEntity);
		country.setLastUpdatedDate(LocalDateTime.now());
		return countryMapper.mapToModel(countryDao.update(countryMapper.mapToEntity(country, countryEntity)));
	}

	public void deactivateCountry(Country country) {

		CountryEntity countryEntity = countryDao.findByCountryCode(country.getCountryCode())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(country.getCountryCode())));

		if (!countryEntity.getActivate()) {
			throw new BusinessException(INACTIVE_COUNTRY);
		}

		countryEntity.setActivate(Boolean.FALSE);

		countryDao.update(countryMapper.mapToEntity(country, countryEntity));

	}

	public void activateCountry(Country country) {

		CountryEntity countryEntity = countryDao.findByCountryCode(country.getCountryCode())
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(country.getCountryCode())));

		if (countryEntity.getActivate()) {
			throw new BusinessException(ACTIVE_COUNTRY);
		}

		countryEntity.setActivate(Boolean.TRUE);

		countryDao.update(countryMapper.mapToEntity(country, countryEntity));

	}

	public List<Country> getListOfCountries(String countryCode, String countryName) {
		return countryMapper.mapToModel(
				countryDao.getListOfCountries(Optional.ofNullable(countryCode), Optional.ofNullable(countryName)));
	}

	@Override
	public boolean isValidCountryCode(String countryCode) {
		if ((countryDao.getCountryCode(countryCode) > 0)) {
			return true;
		}
		return false;
	}

	@Override
	public List<String> getValidatedCountryCodeList(List<String> countryCodeList) {
		List<String> countryList = countryDao.getCountryCodeList(countryCodeList);
		ArrayList<String> validCountryCodeList = new ArrayList<>();
		countryList.forEach(country -> validCountryCodeList.add(country));
		return validCountryCodeList;
	}

	@Override
	public List<CommonIdName> getCountryList() {

		List<CommonIdName> countryList = new ArrayList<>();
		List<CountryEntity> listOfCurrencies = countryDao
				.findDistinctByCountryCodeIsNotNullAndActivateTrueOrderByCountryCode();
		for (CountryEntity objCountry : listOfCurrencies) {
			CommonIdName country = new CommonIdName();
			country.setId(objCountry.getCountryCode());
			country.setName(objCountry.getCountryCode() + " - " + objCountry.getCountryName());
			countryList.add(country);
		}
		return countryList;
	}

	@Override
	public List<Country> getListOfCountriesByIsActive(Optional<String> countryCode, Optional<String> countryName,
			Optional<Boolean> activate) {
		return countryMapper.mapToModel(countryDao.getListOfCountriesByIsActive(countryCode, countryName, activate));
	}

	public void ValidateISOCountryCodeAndCountryNumber(Country country) {
		if (countryDao.validateISOCountryCode(OptionalUtil.getValue(country.getIsoAlpha3CountryCode())) != 0) {
			throw new BusinessException(ISO_COUNTRY_CODE);

		}
		if (countryDao.validateCountryNumber(OptionalUtil.getValue(country.getCountryNumber())) != 0) {
			throw new BusinessException(COUNTRY_NUMBER);

		}
	}

	public void ValidateISOCountryCodeAndCountryNumberForUpdate(Country country, CountryEntity countryEntity) {
		if (countryDao.validateISOCountryCodeForUpdate(OptionalUtil.getValue(country.getIsoAlpha3CountryCode()),
				countryEntity.getCountryCode()) != 0) {
			throw new BusinessException(ISO_COUNTRY_CODE);

		}
		if (countryDao.validateCountryNumberForUpdate(OptionalUtil.getValue(country.getCountryNumber()),
				countryEntity.getCountryCode()) != 0) {
			throw new BusinessException(COUNTRY_NUMBER);

		}
	}
}