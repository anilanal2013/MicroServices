package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingStgEntity;
import com.sgl.smartpra.global.master.model.ProvisoRoutingStg;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoRoutingStgMapper extends BaseMapper<ProvisoRoutingStg, ProvisoRoutingStgEntity>{
	ProvisoRoutingStgEntity mapToEntity(ProvisoRoutingStg provisoRoutingStg,
			@MappingTarget ProvisoRoutingStgEntity provisoRoutingStgEntity);
	@Mapping(source = "provisoRoutingId", target = "provisoRoutingId", ignore = true)
	ProvisoRoutingStgEntity mapToEntity(ProvisoRoutingStg provisoRoutingStg);
}
