package com.sgl.smartpra.global.master.app.service.impl;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.RejectionReasonCodeDao;
import com.sgl.smartpra.global.master.app.dao.entity.RejectionReasonCodeEntity;
import com.sgl.smartpra.global.master.app.mapper.RejectionReasonCodeMapper;
import com.sgl.smartpra.global.master.app.service.RejectionReasonCodeService;
import com.sgl.smartpra.global.master.model.RejectionReasonCode;

import java.util.List;


@Service
@Transactional
public class RejectionReasonCodeServiceImpl implements RejectionReasonCodeService {

	@Autowired
	RejectionReasonCodeMapper rejectionReasonCodeMapper;
	
	@Autowired
	RejectionReasonCodeDao rejectionReasonCodeDao;
	
	@Override
	public RejectionReasonCode getRejectionReasonCode(@Valid String id) {
		RejectionReasonCodeEntity rejectionReasonCodeEntity = rejectionReasonCodeDao.findById(id).orElseThrow(() -> 
						new RecordNotFoundException(id));
			
				
		return rejectionReasonCodeMapper.mapToModel(rejectionReasonCodeEntity);
	}

	@Override
	public List<RejectionReasonCode> fetchAllRejectionCode() {
		return rejectionReasonCodeMapper.mapToModel(rejectionReasonCodeDao.findAll());
	}
}
