package com.sgl.smartpra.global.master.app.service.impl;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.RateAndAgreementDao;
import com.sgl.smartpra.global.master.app.dao.entity.RateAndAgreementEntity;
import com.sgl.smartpra.global.master.app.mapper.RateAndAgreementMapper;
import com.sgl.smartpra.global.master.app.service.RateAndAgreementService;
import com.sgl.smartpra.global.master.model.RateAndAgreementModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class RateAndAgreementServiceImpl implements RateAndAgreementService {

    @Autowired
    private RateAndAgreementDao rateAndAgreementDao;

    @Autowired
    private RateAndAgreementMapper rateAndAgreementMapper;

    @Override
    public RateAndAgreementModel create(RateAndAgreementModel rateAndAgreementModel) {
        rateAndAgreementModel.setCreatedDate(LocalDateTime.now());
        rateAndAgreementModel.setLastUpdatedDate(LocalDateTime.now());
        return rateAndAgreementMapper.mapToModel(rateAndAgreementDao.create(rateAndAgreementMapper.mapToEntity(rateAndAgreementModel)));
    }

    @Override
    public RateAndAgreementModel saveExist(RateAndAgreementModel rateAndAgreementModel) {
        RateAndAgreementEntity rateAndAgreementEntity = rateAndAgreementDao.findById(rateAndAgreementModel.getRateAgreementId())
                .orElseThrow(() -> new RecordNotFoundException("Rate and Agreement not found"));
        rateAndAgreementEntity = rateAndAgreementMapper.mapToEntity(rateAndAgreementModel,rateAndAgreementEntity);
        return rateAndAgreementMapper.mapToModel(rateAndAgreementDao.update(rateAndAgreementEntity));
    }

    @Override
    public List<RateAndAgreementModel> fetchAll(Optional<String> supplierCode, Optional<String> baseLocation, Optional<String> chargeCategory, Optional<String> chargeCode, Optional<String> effectivePeriodFrom, Optional<String> effectivePeriodTo, Optional<String> airport) {
        return rateAndAgreementMapper.mapToModel(rateAndAgreementDao.fetchAll(supplierCode,baseLocation,chargeCategory,chargeCode,effectivePeriodFrom,effectivePeriodTo,airport));
    }

    @Override
    public Boolean delete(Integer id) {
        return rateAndAgreementDao.delete(id);
    }
}
