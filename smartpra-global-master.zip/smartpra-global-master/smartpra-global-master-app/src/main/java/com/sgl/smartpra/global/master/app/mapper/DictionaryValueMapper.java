package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.repository.entity.DictionaryValueEntity;
import com.sgl.smartpra.global.master.model.DictionaryValue;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, 
nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface DictionaryValueMapper extends BaseMapper<DictionaryValue, DictionaryValueEntity> {

	DictionaryValueEntity mapToEntity(DictionaryValue dictionaryValue, @MappingTarget DictionaryValueEntity dictionaryValueEntity);

	@Mapping(source = "dictionaryValueId", target = "dictionaryValueId", ignore = true)
	DictionaryValueEntity mapToEntity(DictionaryValue dictionaryValueId);
}
