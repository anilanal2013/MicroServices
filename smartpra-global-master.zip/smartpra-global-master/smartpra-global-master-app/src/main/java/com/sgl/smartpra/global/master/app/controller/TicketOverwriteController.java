package com.sgl.smartpra.global.master.app.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.TicketOverwriteDetailService;
import com.sgl.smartpra.global.master.app.service.TicketOverwriteService;
import com.sgl.smartpra.global.master.model.TicketOverwrite;
import com.sgl.smartpra.global.master.model.TicketOverwriteDetail;

@RestController
public class TicketOverwriteController {
	
	@Autowired
	private TicketOverwriteService ticketOverwriteService;
	
	@Autowired
	private TicketOverwriteDetailService ticketOverwriteDetailService;
	
	@PostMapping("/saveTicketOverwrite")
	public TicketOverwrite saveTicketOverwrite(@Valid @RequestBody TicketOverwrite ticketOverwriteDao) {
		return ticketOverwriteService.saveTicketOverwrite(ticketOverwriteDao);
	}
	
	@GetMapping("/getTicketOverwrite/{id}")
	public TicketOverwrite getTicketOverwrite(@PathVariable Long id) {
		return ticketOverwriteService.getTicketOverwrite(id);
	}
	
    @GetMapping("/validateTicketOverwriteDetail")
    public List<TicketOverwriteDetail> validateTicketOverwriteDetail(@RequestParam(value = "source1", required = false) String source1,
                                                         @RequestParam(value = "source2", required = false) String source2,
                                                         @RequestParam(value = "processStatus", required = false) String processStatus,
                                                         @RequestParam(value = "transationCode", required = false) String transationCode,
                                                         @RequestParam(value = "tableName", required = false) String tableName) {
    	List<TicketOverwriteDetail> ticketOverwriteDetailList= new ArrayList<TicketOverwriteDetail>();
    	TicketOverwrite ticketOverwrite =ticketOverwriteService.validateTicketOverwriteDetail(source1, source2, processStatus, transationCode);
    	 if(ticketOverwrite!=null && ticketOverwrite.getScenarioNo()!=null)
    	 {
    		 ticketOverwriteDetailList=ticketOverwriteDetailService.getTicketOverwriteDetail(ticketOverwrite,tableName);
    	 }
       return ticketOverwriteDetailList;
    }
    @GetMapping("/validateTicketOverwrite")
    public boolean validateTicketOverwrite(@RequestParam(value = "source1", required = false) String source1,
                                                         @RequestParam(value = "source2", required = false) String source2,
                                                         @RequestParam(value = "processStatus", required = false) String processStatus,
                                                         @RequestParam(value = "transationCode", required = false) String transationCode) {
    	boolean validateTicketOverwrite=false;
    	TicketOverwrite ticketOverwrite =ticketOverwriteService.validateTicketOverwriteDetail(source1, source2, processStatus, transationCode);
    	
    	if(ticketOverwrite!=null)
    	{
    		validateTicketOverwrite=true;
    	}
       return validateTicketOverwrite;
    }
}
