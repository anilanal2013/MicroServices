package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.ChargeCodeEntity;

@Repository
public interface ChargeCodeDao {

	public List<ChargeCodeEntity> findAll(Optional<String> chargeCode, Optional<String> chargeCodeName,
			Optional<String> chargeCategoryCode);

	public Optional<ChargeCodeEntity> findOne(Optional<String> chargeCode);
	
	public ChargeCodeEntity create(ChargeCodeEntity chargeCodeEntity);

	public List<ChargeCodeEntity> update(List<ChargeCodeEntity> chargeCodeEntity);
	
	public List<String> getChargeCodeFromChargeCodeMaster();

}
