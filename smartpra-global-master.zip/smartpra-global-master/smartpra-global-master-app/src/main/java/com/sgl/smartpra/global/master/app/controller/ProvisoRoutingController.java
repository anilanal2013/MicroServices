package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.ProvisoRoutingService;
import com.sgl.smartpra.global.master.model.ProvisoRouting;

@RestController
@RequestMapping("/proviso/routing")
public class ProvisoRoutingController {
	@Autowired
	private ProvisoRoutingService provisoRoutingService;

	@GetMapping("provisoMain/{provisoMainId}")
	public List<ProvisoRouting> getProvisoRoutingByProvisoMainId(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId) {
		return provisoRoutingService.getProvisoRoutingByProvisoMainId(provisoMainId);
	}
	@GetMapping("/{provisoRoutingId}")
	public ProvisoRouting getProvisoRoutingByProvisoRoutingId(
			@PathVariable(value = "provisoRoutingId") Integer provisoRoutingId) {
		return provisoRoutingService.getProvisoRoutingByProvisoRoutingId(provisoRoutingId);
	}

	@GetMapping("/proviso-routing/{carrierNumCode}/{provisoSeqNumber}/{detailRecNumber}")
	public List<ProvisoRouting> searchByProvisoRouting(
			@PathVariable(value = "carrierNumCode") Optional<String> carrierNumCode,
			@PathVariable(value = "provisoSeqNumber") Optional<Integer> provisoSeqNumber,
	        @PathVariable(value = "detailRecNumber") Optional<Integer> detailRecNumber){
		return provisoRoutingService.search(carrierNumCode, provisoSeqNumber,detailRecNumber);
	}

}
