package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.OneCountry;

public interface OneCountryService {

	public OneCountry createOneCountry(OneCountry oneCountry);

	public List<OneCountry> getOneCountryByEffectiveDate(Optional<String> oneCountryCode,
			Optional<String> effectiveDate);

	public OneCountry getOneCountryByOneCountryId(Integer oneCountryId);
	
	public List<OneCountry> search(Optional<String> oneCountryCode, Optional<String> countryCodeList,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> isActive);

	public OneCountry getOneCountryByOneCountryCode(Optional<String> countryCodeList, Optional<String> effectiveDate);

	public OneCountry updateOneCountry(Integer oneCountryId, OneCountry oneCountry);

	public void deactivateOneCountry(OneCountry oneCountry);

	public void activateOneCountry(OneCountry oneCountry);

}
