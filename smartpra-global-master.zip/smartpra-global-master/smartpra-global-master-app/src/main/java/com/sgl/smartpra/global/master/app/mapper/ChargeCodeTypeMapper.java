package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ChargeCodeTypeEntity;
import com.sgl.smartpra.global.master.model.ChargeCodeType;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ChargeCodeTypeMapper extends BaseMapper<ChargeCodeType, ChargeCodeTypeEntity>{

	ChargeCodeTypeEntity mapToEntity(ChargeCodeType chargeCodeType, @MappingTarget ChargeCodeTypeEntity chargeCodeTypeEntity);

	@Mapping(source = "chargeCodeTypeId", target = "chargeCodeTypeId", ignore = true)
	ChargeCodeTypeEntity mapToEntity(ChargeCodeType chargeCodeType);
}
