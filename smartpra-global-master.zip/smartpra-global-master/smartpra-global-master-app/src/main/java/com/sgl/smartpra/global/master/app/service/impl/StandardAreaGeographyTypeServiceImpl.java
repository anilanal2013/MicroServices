package com.sgl.smartpra.global.master.app.service.impl;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.StandardAreaGeographyTypeMapper;
import com.sgl.smartpra.global.master.app.repository.GeographyTypeRepository;
import com.sgl.smartpra.global.master.app.repository.entity.GeographyTypeEntity;
import com.sgl.smartpra.global.master.app.service.StandardAreaGeographyTypeService;
import com.sgl.smartpra.global.master.model.GeographyType;

@Service
@Transactional
public class StandardAreaGeographyTypeServiceImpl implements StandardAreaGeographyTypeService {

	@Autowired
	StandardAreaGeographyTypeMapper standardAreaGeographyTypeMapper;

	@Autowired
	private GeographyTypeRepository geographyTypeRepository;

	private static final String STANDARDAREAGEOGRAPHYTYPE = "Geography Type ";

	@Override
	public GeographyType getStandardAreaGeographyTypeByStandardAreaGeographyTypeId(Integer geographicalTypeId) {

		Optional<GeographyTypeEntity> standardAreaGeographyTypeEntity = geographyTypeRepository
				.findById(geographicalTypeId);

		if (standardAreaGeographyTypeEntity.isPresent()) {

			// return only if the record is active
			if (standardAreaGeographyTypeEntity.get().getIsActive()) {
				return standardAreaGeographyTypeMapper
						.mapToStandardAreaGeographyTypeModel(standardAreaGeographyTypeEntity.get());
			}

			throw new ServiceException("Geography Type is not active");

		} else {
			throw new ResourceNotFoundException(STANDARDAREAGEOGRAPHYTYPE, "code", geographicalTypeId);
		}

	}

}
