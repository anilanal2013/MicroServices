package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.SectionService;
import com.sgl.smartpra.global.master.model.Section;
import com.sgl.smartpra.global.master.model.SectionDto;

@RestController
public class SectionController {

	@Autowired
	private SectionService sectionService;

	@GetMapping("/charge-codes/{chargeCode}/sections/{sectionMasterId}")
	public Section getSectionBySectionCode(@PathVariable(value = "chargeCode") Optional<String> chargeCode,
			@PathVariable(value = "sectionMasterId") Integer sectionMasterId) {
		return sectionService.findSectionBySectionMasterId(chargeCode, sectionMasterId);
	}

	@GetMapping("/charge-codes/{chargeCode}/sections")
	public List<Section> getAllSection(@PathVariable(value = "chargeCode") Optional<String> chargeCode,
			@RequestParam(value = "sectionCode", required = false) Optional<String> sectionCode,
			@RequestParam(value = "sectionName", required = false) Optional<String> sectionName,
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return sectionService.getAllSection(chargeCode, sectionCode, sectionName, activate);
	}

	@PostMapping("/charge-codes/{chargeCode}/sections")
	public Section createSection(@PathVariable(value = "chargeCode") Optional<String> chargeCode,
			@Validated(Create.class) @RequestBody Section section) {
		return sectionService.createSection(chargeCode, section);
	}

	@PutMapping("/update-sections")
	public List<Section> updateSection(@RequestBody List<Section> sections) {
		return sectionService.updateSection(sections);
	}

	@PutMapping("/charge-codes/{chargeCode}/sections/{sectionMasterId}/deactivate")
	public void deactivateSection(@Valid @PathVariable(value = "chargeCode") Optional<String> chargeCode,
			@Valid @PathVariable(value = "sectionMasterId") Integer sectionMasterId,
			@Validated(Update.class) @RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {

		sectionService.deactivateSection(chargeCode,sectionMasterId, lastUpdatedBy);
	}

	@PutMapping("/charge-codes/{chargeCode}/sections/{sectionMasterId}/activate")
	public void activateSection(@Valid @PathVariable(value = "chargeCode") Optional<String> chargeCode,
			@Valid @PathVariable(value = "sectionMasterId") Integer sectionMasterId,
			@Validated(Update.class) @RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {

		sectionService.activateSection(chargeCode,sectionMasterId, lastUpdatedBy);
	}

	@GetMapping("/charge-codes/sections")
	public List<Section> getSectionByChargeCode(@RequestParam(value = "chargeCode", required = true) String chargeCode) {
		return sectionService.getAllSection(Optional.of(chargeCode), null, null, null);
	}

	@GetMapping("/section/details")
	public List<SectionDto> fetchSectionByChargeCode(@RequestParam(value = "chargeCode", required = true) String chargeCode,
			@RequestParam(value = "currentBillingPeriod", required = true) String currentBillingPeriod) {
		return sectionService.fetchSectionByChargeCode(chargeCode, currentBillingPeriod);
	}
}
