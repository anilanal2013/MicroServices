package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_misc_section_detail")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class SectionDetailEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "misc_section_dtl_id", nullable = false)
	private Integer sectionDetailId;

	@Column(name = "section_mas_id", nullable = false)
	private Integer sectionMasterId;

	@Column(name = "section_element_name", nullable = false, length = 50)
	private String sectionElementName;

	@Column(name = "applicability", nullable = false, length = 2)
	private String applicability;

	@Column(name = "display_ord_num", nullable = false)
	private Double displayOrderNumber;

	@Column(name = "display_ind", nullable = false, length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean displayIndicator;

	@Column(name = "min_occurrence")
	private Integer minOccurrence;

	@Column(name = "max_occurrence")
	private Integer maxOccurrence;

	@Column(name = "element_type", nullable = false, length = 2)
	private String elementType;

	@Column(name = "element_size")
	private String elementSize;

	@Column(name = "order_number", nullable = false)
	private Double orderNumber;

	@Column(name = "validation_class")
	private String validationClass;
	
	@Column(name = "section_element_name_actual")
	private String sectionElementNameActual;

	@Column(name = "parent_section_element_name")
	private String parentSectionElementName;

	@Column(name = "allowed_occurrence")
	private Integer allowedOccurrence;

	@Column(name = "uom_type")
	private String uomType;

	@Column(name = "hint_value")
	private String hintValue;

	@Column(name = "mandatory_from_prd")
	private String mandatoryFromPeriod;

	@Column(name = "non_mandatory_from_prd")
	private String nonMandatoryFromPeriod;

	@Column(name = "tag_name")
	private String tagName;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
