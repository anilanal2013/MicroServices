
package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.CarrierDao;
import com.sgl.smartpra.global.master.app.dao.entity.CarrierEntity;
import com.sgl.smartpra.global.master.app.dao.repository.CarrierRepository;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.CarrierMapper;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CarrierService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.CommonIdName;

@Service
@Transactional
public class CarrierServiceImpl implements CarrierService {

	@Autowired
	private CountryService countryService;

	@Autowired
	private AirportService airportService;

	@Autowired
	private CarrierRepository carrierRepository;

	@Autowired
	private CarrierMapper carrierMapper;

	@Autowired
	private CarrierDao carrierDao;

	private static final String CARRIER = "carrier";

	private static final String COUNTRY = "country";

	public static final Pattern VALIDEMAILIDPATTERN = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
			Pattern.CASE_INSENSITIVE);

	private static final String LASTUPDATEDBYMSG = "LastUpdatedBy should be minimum of 1 and maximum of 15 characters";

	private static final String CARRIERINACTIVE = "Carrier is not active";

	private static final String LASTUPDATEDBYMENDATORYMSG = "Please provide lastupdatedby";

	private static final String CARRIERACTIVE = "Carrier is already in active state";

	private static final String CARRIERALREADYINACTIVE = "Carrier is already in deactivated state";

	private static final String COUNTRYCODEDEACTIVATE = "Country code is not active";

	private static final String CARRIERCODEALREADYEXISTING = "Record already exists";

	private Boolean operationCheck = false;

	public List<Carrier> getAllCarrier(Optional<String> carrierCode, Optional<String> carrierDesignatorCode,
			Optional<String> carrierName1, Optional<String> carrierName2, Optional<Boolean> isActive, Optional<String> exceptionCall) {
		return carrierMapper.mapToModel(
				carrierDao.findAll(carrierCode, carrierDesignatorCode, carrierName1, carrierName2, isActive,exceptionCall));
	}

	public Carrier findCarrierByCarrierCode(String carrierCode) {
		return carrierMapper.mapToModel(carrierDao.findById(carrierCode)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(carrierCode))));
	}

	public Carrier createCarrier(Carrier carrier) {
		Optional<CarrierEntity> carrierEntity = carrierDao.findById(OptionalUtil.getValue(carrier.getCarrierCode()));
		if (carrierEntity.isPresent()) {
			throw new BusinessException(CARRIERCODEALREADYEXISTING);
		}
		if (OptionalUtil.getValue(carrier.getCityCode()) != null)
			if (!airportService.isValidAirportCodeOrCityCode(OptionalUtil.getValue(carrier.getCityCode()))) {
				throw new BusinessException("Invalid City code " + OptionalUtil.getValue(carrier.getCityCode()));
			}
		try {
			countryService.getCountryByCountryCode(OptionalUtil.getValue(carrier.getCountryCode()));
		} catch (ResourceNotFoundException r) {
			throw new ResourceNotFoundException(COUNTRY, "code", OptionalUtil.getValue(carrier.getCountryCode()));
		} catch (BusinessException s) {
			throw new BusinessException(COUNTRYCODEDEACTIVATE);
		}
		validationForEmailId(carrier);
		validateWebsite(carrier);
		carrier.setCreatedDate(LocalDateTime.now());
		carrier.setIsActive(Boolean.TRUE);
		return carrierMapper.mapToModel(carrierDao.create(carrierMapper.mapToEntity(carrier)));
	}

	public Carrier updateCarrier(String carrierCode, Carrier carrier) {
		Optional<CarrierEntity> carrierEntity = carrierDao.findById(carrierCode);
		if (!carrierEntity.isPresent())
			throw new ResourceNotFoundException(CARRIER, "code", carrierCode);

		// update only if the record is active
		if (!carrierEntity.get().getIsActive()) {
			throw new BusinessException(CARRIERINACTIVE);
		}
		if (OptionalUtil.getValue(carrier.getCityCode()) != null)
			if (!airportService.isValidAirportCodeOrCityCode(OptionalUtil.getValue(carrier.getCityCode()))) {
				throw new BusinessException("Invalid City code " + OptionalUtil.getValue(carrier.getCityCode()));
			}

		try {
			countryService.getCountryByCountryCode(OptionalUtil.getValue(carrier.getCountryCode()));
		} catch (ResourceNotFoundException r) {
			throw new ResourceNotFoundException(COUNTRY, "code", OptionalUtil.getValue(carrier.getCountryCode()));
		} catch (BusinessException s) {
			throw new BusinessException(COUNTRYCODEDEACTIVATE);
		}

		validationForEmailId(carrier);
		validateWebsite(carrier);
		carrierEntity.get().setIsActive(true);
		carrierEntity.get().setLastUpdatedDate(LocalDateTime.now());

		return carrierMapper.mapToModel(carrierDao.update(carrierMapper.mapToEntity(carrier, carrierEntity.get())));
	}

	public void deactivateCarrier(String carrierCode, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		CarrierEntity carrierEntity = carrierDao.findById(carrierCode)
				.orElseThrow(() -> new RecordNotFoundException(carrierCode));

		if (!carrierEntity.getIsActive())
			throw new BusinessException(CARRIERALREADYINACTIVE);

		carrierEntity.setIsActive(Boolean.FALSE);
		carrierEntity.setLastUpdatedBy(lastUpdatedBy);
		carrierEntity.setLastUpdatedDate(LocalDateTime.now());
		carrierDao.update(carrierEntity);
	}

	public void activateCarrier(String carrierCode, String lastUpdatedBy) {
		lastUpdatedBy = lastUpdatedBy.trim();
		if (!lastUpdatedBy.isEmpty()) {
			if (lastUpdatedBy.length() > 15)
				throw new BusinessException(LASTUPDATEDBYMSG);
		} else {
			throw new BusinessException(LASTUPDATEDBYMENDATORYMSG);
		}
		CarrierEntity carrierEntity = carrierDao.findById(carrierCode)
				.orElseThrow(() -> new RecordNotFoundException(carrierCode));

		if (carrierEntity.getIsActive())
			throw new BusinessException(CARRIERACTIVE);

		carrierEntity.setIsActive(Boolean.TRUE);
		carrierEntity.setLastUpdatedBy(lastUpdatedBy);
		carrierEntity.setLastUpdatedDate(LocalDateTime.now());
		carrierDao.update(carrierEntity);
	}

    /*private void validationForEmailId(Carrier carrier) {
		if (OptionalUtil.isPresent(carrier.getEmail())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(carrier.getEmail()))
				&& OptionalUtil.getValue(carrier.getEmail()).contains(",")) {
			String[] emailList = OptionalUtil.getValue(carrier.getEmail()).split(",");
			for (int i = 0; i <= emailList.length - 1; i++) {
				if (Pattern.compile(VALIDEMAILIDPATTERN).matcher(emailList[i]).find()) {
				} else {
					throw new BusinessException("Invalid Email " + OptionalUtil.getValue(carrier.getEmail()));
				}
			}
		}
	}*/
	
	private void validationForEmailId(Carrier carrier) {
		if (OptionalUtil.isPresent(carrier.getEmail()) && StringUtils.isNotEmpty(OptionalUtil.getValue(carrier.getEmail()))) {
			String email = OptionalUtil.getValue(carrier.getEmail());
			if (OptionalUtil.getValue(carrier.getEmail()).trim().length() > 0) {
				if (!(VALIDEMAILIDPATTERN.matcher(email).find())) {
					throw new BusinessException("Invalid Email " + email);
				}
			}
		}
	}

	@Override
	public boolean isValidCarrierDesignatorCode(String carrierDesignatorCode) {
		boolean isValid = false;
		String carrierCodeDb = carrierRepository.getCarrierByCarrierDesignatorCode(carrierDesignatorCode);
		if (carrierCodeDb != null) {
			return true;
		}
		return isValid;
	}
	
	public boolean isValidcarrierDesignatorCodeList(String carrierDesignatorCode) {
		List<CarrierEntity> carrierEntity = carrierDao.isValidCarrierDesignatorCodeList(carrierDesignatorCode);
		return !carrierEntity.isEmpty();
	}

	@Override
	public boolean isValidCarrierCode(String carrierCode) {
		boolean isValid = false;
		List<String> carrierCodeDb = carrierRepository.validateCarrierCode(carrierCode);

		if (!carrierCodeDb.isEmpty()) {
			return true;
		}

		return isValid;
	}

	protected void validateWebsite(Carrier carrier) {
		if (OptionalUtil.isPresent(carrier.getWebsite())
				&& StringUtils.isNotEmpty(OptionalUtil.getValue(carrier.getWebsite()))) {
			String website = OptionalUtil.getValue(carrier.getWebsite());
			operationCheck = Pattern.compile("^((ftp|http|https):\\/\\/)?([a-zA-Z0-9]+(\\.[a-zA-Z0-9]+)+.*)$")
					.matcher(website).find();
			if (!operationCheck) {
				throw new BusinessException("Invalid website name"+ OptionalUtil.getValue(carrier.getWebsite()));
			}
		}
	}

	@Override
	public List<String> getValidCarrierCode(List<String> carrrierCodeList) {
		return carrierRepository.getCarrierCodeList(carrrierCodeList);
	}

	@Override
	public String getCarrrierCodeByCarrierDesignatorCode(String carrierDesignatorCode) {
		return carrierRepository.getCarrrierCodeByCarrierDesignatorCode(carrierDesignatorCode);
	}

	@Override
	public List<Carrier> getValidCarrierDetails(List<String> carrierCodeList) {
		return carrierMapper.mapToModel(carrierRepository.getCarrierDetails(carrierCodeList));

	}

	@Override
	public List<CommonIdName> getCarrierList() {
		
		List<CommonIdName> carrierList = new ArrayList<>();
		List<CarrierEntity> listOfCarriers = carrierDao
				.findDistinctByCarrierCodeIsNotNullAndIsActiveTrueOrderByCarrierCode();
		for (CarrierEntity objCarrier : listOfCarriers) {
			CommonIdName carrier = new CommonIdName();
			carrier.setId(objCarrier.getCarrierDesignatorCode());
			carrier.setName(objCarrier.getCarrierDesignatorCode()+" - "+objCarrier.getCarrierName1());
			carrierList.add(carrier);
		}

		return carrierList;
	}

	@Override
	public Carrier findCarrierByCarrierDesignatorCode(String carrierDesignatorCode) {
		return carrierMapper.mapToModel(carrierDao.getCarrierByCarrierDesignatorCode(carrierDesignatorCode)
				.orElseThrow(() -> new BusinessException("Record Not Found")));
	}

	@Override
	public Carrier getCarrierByCarrierCode(String carrierCode) {
		return carrierMapper.mapToModel(carrierDao.getCarrierByCarrierCode(carrierCode)
				.orElseThrow(() -> new BusinessException("Record Not Found")));
	}
	
	public boolean isValidCarrier(String carrierDesignatorCode,	String carrrierCode) {
		Optional<CarrierEntity> carrier = carrierRepository.findCarrier(carrierDesignatorCode,carrrierCode);
		if (carrier.isPresent()) {
			return true;
		}
		return false;
	}
}
