package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainStgEntity;
import com.sgl.smartpra.global.master.model.ProvisoMainStgModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoMainStgMapper extends BaseMapper<ProvisoMainStgModel, ProvisoMainStgEntity>{
	ProvisoMainStgEntity mapToEntity(ProvisoMainStgModel provisoMainStgModel, @MappingTarget ProvisoMainStgEntity provisoMainStgEntity);
	
	@Mapping(source = "provisoMainId", target = "provisoMainId", ignore = true)	 
	ProvisoMainStgEntity mapToEntity(ProvisoMainStgModel provisoMainStgModel);
}
