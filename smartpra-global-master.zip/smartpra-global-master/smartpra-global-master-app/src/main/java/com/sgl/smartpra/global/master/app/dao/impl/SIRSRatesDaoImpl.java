package com.sgl.smartpra.global.master.app.dao.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.SIRSRatesDao;
import com.sgl.smartpra.global.master.app.dao.entity.SIRSRatesEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.SIRSRatesEntitySpecification;
import com.sgl.smartpra.global.master.app.repository.SIRSRatesRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SIRSRatesDaoImpl implements SIRSRatesDao {

	@Autowired
	private SIRSRatesRepository sirsRatesRepository;

	@Override
	@Caching(evict = { @CacheEvict(value = "sirsRates", key = "#sirsRatesEntity.sirsRateId"),
			@CacheEvict(value = "sirsRatesSearch", allEntries = true) })
	public SIRSRatesEntity create(SIRSRatesEntity sirsRatesEntity) {
		return sirsRatesRepository.save(sirsRatesEntity);
	}

	@Override
	@Cacheable(value = "sirsRates", key = "#id")
	public Optional<SIRSRatesEntity> findById(Integer id) {

		return sirsRatesRepository.findById(id);
	}

	@Override
	@CachePut(value = "sirsRates", key = "#sirsRatesEntity.sirsRateId")
	@CacheEvict(value = "sirsRatesSearch", allEntries = true)
	public SIRSRatesEntity update(SIRSRatesEntity sirsRatesEntity) {
		return sirsRatesRepository.save(sirsRatesEntity);
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String globalRegion) {
		return sirsRatesRepository
				.count(Specification.where(SIRSRatesEntitySpecification.equalsGlobalRegion(globalRegion))
						.and(SIRSRatesEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate).or(
								SIRSRatesEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate))));
	}

	@Override
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String globalRegion,
			Integer sirsRateId) {
		return sirsRatesRepository.count(SIRSRatesEntitySpecification.equalsGlobalRegion(globalRegion)
				.and(SIRSRatesEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveFromDate)
						.or(SIRSRatesEntitySpecification.betweenEffectiveFromAndEffectiveToDate(effectiveToDate)))
				.and(SIRSRatesEntitySpecification.notEqualsSIRSRateId(sirsRateId)));
	}

	@Override
	public List<SIRSRatesEntity> search(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> globalRegion) {
		return sirsRatesRepository
				.findAll(SIRSRatesEntitySpecification.search(effectiveFromDate, effectiveToDate, globalRegion));
	}

	@Override
	public long getCount(SIRSRatesEntity mapToEntity) {
		return sirsRatesRepository.count(SIRSRatesEntitySpecification.search(mapToEntity));
	}

	@Override
	public Page<SIRSRatesEntity> getAllSIRSRates(SIRSRatesEntity mapToEntity, Pageable pageable) {
		return sirsRatesRepository.findAll(SIRSRatesEntitySpecification.search(mapToEntity), pageable);

	}

	@Override
	public List<SIRSRatesEntity> getAllSIRSRatesDates(LocalDate dateString) {
		return sirsRatesRepository.findAll(SIRSRatesEntitySpecification.search(dateString));
	}

}
