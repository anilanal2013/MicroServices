package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.SIRSRatesEntity;
import com.sgl.smartpra.global.master.model.SIRSRates;

@Repository
public interface SIRSRatesDao {

	public SIRSRatesEntity create(SIRSRatesEntity sirsRatesEntity);

	public Optional<SIRSRatesEntity> findById(Integer id);

	public SIRSRatesEntity update(SIRSRatesEntity mapToEntity);

	// -- This is for Create- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String globalRegion);

	// -- This is for Update- Overlap Count Validation
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String globalRegion,
			Integer sirsRateId);

	public List<SIRSRatesEntity> search(Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> globalRegion);

	public long getCount(SIRSRatesEntity mapToEntity);

	public Page<SIRSRatesEntity> getAllSIRSRates(SIRSRatesEntity mapToEntity, Pageable pageable);

	public List<SIRSRatesEntity> getAllSIRSRatesDates(LocalDate dateString);   

}
