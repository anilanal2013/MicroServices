package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.CurrencyDetailEntity;

public class CurrencyDetailEntitySpecification {
	
	private static final String EFFECTIVEFROMDATE = "effectiveFromDate";
	private static final String EFFECTIVETODATE = "effectiveToDate";
	private static final String CURRENCYCODE = "currencyCode";
	
	private CurrencyDetailEntitySpecification() {
	}

	public static Specification<CurrencyDetailEntity> equalsCurrencyCode(String currencyCode) {
		return (currencyDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(currencyDetailEntity.get(CURRENCYCODE), currencyCode);
	}

	public static Specification<CurrencyDetailEntity> notEqualsCurrencyDtlId(Integer currencyDetailId) {
		return (currencyDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(currencyDetailEntity.get("currencyDetailId"), currencyDetailId);
	}

	public static Specification<CurrencyDetailEntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (currencyDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), currencyDetailEntity.get(EFFECTIVEFROMDATE),
				currencyDetailEntity.get(EFFECTIVETODATE));
	}
	
	public static Specification<CurrencyDetailEntity> betweenEffectiveFrom(LocalDate effectiveFromDate,
			LocalDate effectiveToDate) {
		return (currencyDetailEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				currencyDetailEntity.get(EFFECTIVEFROMDATE), criteriaBuilder.literal(effectiveFromDate),
				criteriaBuilder.literal(effectiveToDate));

	}
	
	public static Specification<CurrencyDetailEntity> greaterThanOrEqualToEffectiveDate(Optional<String> effectiveDate) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.greaterThanOrEqualTo(
				oneCountryEntity.get(EFFECTIVEFROMDATE),
				criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)));
	}
	
	public static Specification<CurrencyDetailEntity> lessThanOrEqualToEffectiveDate(Optional<String> effectiveDate) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.lessThanOrEqualTo(
				oneCountryEntity.get(EFFECTIVETODATE),
				criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)));
	}
	
	public static void orderByAsc(Root<CurrencyDetailEntity> currencyDetailEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(currencyDetailEntity.get(orderByString)));
	}

	public static Specification<CurrencyDetailEntity> search(Optional<String> currencyCode,
			Optional<String> effectiveDate) {
		return (currencyDetailEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(currencyCode)) {
				predicates.add(criteriaBuilder.like(currencyDetailEntity.get(CURRENCYCODE),
						OptionalUtil.getValue(currencyCode) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(currencyDetailEntity.get(EFFECTIVETODATE),
						OptionalUtil.getLocalDateValue(effectiveDate)));
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(currencyDetailEntity.get(EFFECTIVEFROMDATE),
						OptionalUtil.getLocalDateValue(effectiveDate)));
			}
			orderByAsc(currencyDetailEntity, criteriaQuery, criteriaBuilder, EFFECTIVETODATE);
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		}; 
	}

}
