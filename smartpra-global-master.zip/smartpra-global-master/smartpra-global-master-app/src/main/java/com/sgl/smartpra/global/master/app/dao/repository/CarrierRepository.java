package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.CarrierEntity;


@Repository
public interface CarrierRepository extends JpaRepository<CarrierEntity, String>, JpaSpecificationExecutor<CarrierEntity> {

	@Query("select carrierCode from CarrierEntity a  where a.carrierCode = :carrierCode AND a.isActive=true")
	public String getCarrierByCarrierCode(@Param("carrierCode") String carrierCode);

	@Query("select carrierCode from CarrierEntity a  where a.carrierCode IN (:carrierCodeList) AND a.isActive=true")
	public List<String> getCarrierCodeList(@Param("carrierCodeList") List<String> carrierCodeList);
	
	@Query("select carrier from CarrierEntity carrier  where carrier.carrierCode IN (:carrierCodeList) AND carrier.isActive=true")
	public List<CarrierEntity> getCarrierDetails(@Param("carrierCodeList") List<String> carrierCodeList);

	@Query("select carrierDesignatorCode from CarrierEntity a  where a.carrierDesignatorCode = :carrierDesignatorCode AND a.isActive=true")
	public String getCarrierByCarrierDesignatorCode(@Param("carrierDesignatorCode") String carrierDesignatorCode);

	@Query("select carrierCode from CarrierEntity a  where a.carrierDesignatorCode = :carrierDesignatorCode AND a.isActive=true")
	public String getCarrrierCodeByCarrierDesignatorCode(@Param("carrierDesignatorCode") String carrierDesignatorCode);
	
	@Query("select carrierCode from CarrierEntity a  where a.carrierCode = :carrierCode AND a.isActive=true")
	public List<String> validateCarrierCode(@Param("carrierCode")String carrierCode);
	
	@Query("select carrierCode from CarrierEntity a  where a.carrierCode = :carrierCode AND a.isActive=true")
	public List<String> validateCarrierCod(@Param("carrierCode")String carrierCode);
	
	List<CarrierEntity> findDistinctByCarrierCodeIsNotNullAndIsActiveTrueOrderByCarrierCode();
	
	@Query("select carrier from CarrierEntity carrier  where carrier.carrierCode = :carrierCode AND carrier.carrierDesignatorCode = :carrierDesignatorCode AND carrier.isActive=true")
	public Optional<CarrierEntity> findCarrier(@Param("carrierDesignatorCode") String carrierDesignatorCode, @Param("carrierCode") String carrierCode);
	
}

