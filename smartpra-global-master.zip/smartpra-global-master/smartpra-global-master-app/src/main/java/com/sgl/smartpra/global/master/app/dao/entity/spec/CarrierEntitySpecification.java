package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.CarrierEntity;

public class CarrierEntitySpecification {

	private CarrierEntitySpecification() {
	}

	public static void orderByCountryCodeByAsc(Root<CarrierEntity> carrierEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(carrierEntity.get(orderByString)));
	}

	public static Specification<CarrierEntity> search(Optional<String> carrierCode,
			Optional<String> carrierDesignatorCode, Optional<String> carrierName1, Optional<String> carrierName2,
			Optional<Boolean> isActive,Optional<String> exceptionCall) {
		return (carrierEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierCode)) {
				predicates.add(criteriaBuilder.like(carrierEntity.get("carrierCode"),
						OptionalUtil.getValue(carrierCode) + "%"));
			}
			if (OptionalUtil.isPresent(carrierDesignatorCode)) {
				predicates.add(criteriaBuilder.like(carrierEntity.get("carrierDesignatorCode"),
						OptionalUtil.getValue(carrierDesignatorCode) + "%"));
			}
			if (OptionalUtil.isPresent(carrierName1)) {
				predicates.add(criteriaBuilder.like(carrierEntity.get("carrierName1"),
						OptionalUtil.getValue(carrierName1) + "%"));
			}
			if (OptionalUtil.isPresent(carrierName2)) {
				predicates.add(criteriaBuilder.like(carrierEntity.get("carrierName2"),
						OptionalUtil.getValue(carrierName2) + "%"));
			}
			if(!OptionalUtil.isPresent(exceptionCall) && StringUtils.isBlank(OptionalUtil.getValue(exceptionCall))) {
				if (OptionalUtil.getValue(isActive) == null || OptionalUtil.getValue(isActive)) {
					predicates.add(criteriaBuilder.isTrue(carrierEntity.get("isActive")));
				} else {
					predicates.add(criteriaBuilder.isFalse(carrierEntity.get("isActive")));
				}
			}
			orderByCountryCodeByAsc(carrierEntity, criteriaQuery, criteriaBuilder, "countryCode");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}
	
	public static Specification<CarrierEntity> equalCarrierDesignatorCode(String carrierDesignatorCode) {
		return (carrierEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierEntity.get("carrierDesignatorCode"), carrierDesignatorCode );
	}
	
	public static Specification<CarrierEntity> equalCarrierCode(String carrierCode) {
		return (carrierEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierEntity.get("carrierCode"), carrierCode );
	}
	
	public static Specification<CarrierEntity> isActive() {
		return (carrierEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(carrierEntity.get("isActive"), true );
	}

}
