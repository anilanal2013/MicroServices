package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.FBTDElementEntity;

@Repository
public interface FBTDElementDao {

	public Optional<FBTDElementEntity> getAllFBTDEntity(Optional<Integer> elementType, Optional<String> elementCode, Optional<String> effectiveDate);

	public  List<FBTDElementEntity> search(Optional<Integer> elementType, Optional<String> elementCode, 
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<Boolean> activate);

	public long checkOverlapExits(LocalDate effectiveFromDate, LocalDate effectiveToDate, Optional<Integer> elementType,
			Optional<String> elementCode);
	
	public long checkOverlapExitsForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, Optional<Integer> elementType,
			Optional<String> elementCode,Integer fbtdId);

	public FBTDElementEntity save(FBTDElementEntity fbtdElementEntity);

	public List<FBTDElementEntity> verifyIfSameRecordExits(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Integer> elementType, Optional<String> elementCode);

	public Optional<FBTDElementEntity> findById(Integer fbtdId);

	public List<FBTDElementEntity> findByElementCode(String elementCode, Integer elementType);

	public List<FBTDElementEntity> getFBTDElementByElementCodeBasedOnPrimeCode(String elementCode, Integer elementType);

	public List<FBTDElementEntity> validateCabin(String cabin, Integer elementType);

	public List<FBTDElementEntity> validateOtherInfo(String otherInfo, Integer elementType);

	public List<FBTDElementEntity> validateIATAFareType(String iataFareType, Integer elementType);

	public List<FBTDElementEntity> validateSeasonalCode(String seasonalCode, Integer elementType);

	public List<FBTDElementEntity> validateDayOfWeek(String dayOfWeek, Integer elementType);

	public List<FBTDElementEntity> validateDiscountCode(String discountCode, Integer elementType);

	public List<FBTDElementEntity> validateJourneyType(String journeyType, Integer elementType);

	public List<FBTDElementEntity> validateZedIdentifier(String zedIdentifier, Integer elementType);

	public List<FBTDElementEntity> getAllFBTDEntity1(Optional<String> date, Optional<Integer> elementType, Optional<String> elementCode);

	public List<FBTDElementEntity> verifyRecordExits(Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Integer fbtdId,
			Optional<Integer> elementType, Optional<String> elementCode);

	public FBTDElementEntity update(FBTDElementEntity fbtdElementEntity);

	public List<FBTDElementEntity> getCabilLevel(Integer elementType);

	public List<FBTDElementEntity> getDiscountCodeList();	

	public List<String> getElementCodeByElementTypeAndAdditionalInfo();

}
