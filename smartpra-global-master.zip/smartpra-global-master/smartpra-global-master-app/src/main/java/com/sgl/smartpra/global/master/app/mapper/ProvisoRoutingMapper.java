package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingEntity;
import com.sgl.smartpra.global.master.model.ProvisoRouting;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoRoutingMapper extends BaseMapper<ProvisoRouting, ProvisoRoutingEntity>{
	ProvisoRoutingEntity mapToEntity(ProvisoRouting provisoRouting,
			@MappingTarget ProvisoRoutingEntity provisoRoutingEntity);
	@Mapping(source = "provisoRoutingId", target = "provisoRoutingId", ignore = true)
	ProvisoRoutingEntity mapToEntity(ProvisoRouting provisoRouting);
}
