package com.sgl.smartpra.global.master.app.dao;

import com.sgl.smartpra.global.master.app.dao.entity.GlobalClientEntity;
import org.springframework.data.domain.Example;

import java.util.Optional;


public interface GlobalClientDao {

    public Optional<GlobalClientEntity> findAll(Example<GlobalClientEntity> globalClient);

}
