package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingStgEntity;

public class ProvisoRoutingStgEntitySpecification {
	ProvisoRoutingStgEntitySpecification(){
	}
	public static Specification<ProvisoRoutingStgEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<Integer> detailRecNumber) {
		return (provisoRoutingStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoRoutingStgEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoRoutingStgEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			if (OptionalUtil.isPresent(detailRecNumber)) {
				predicates.add(criteriaBuilder.equal(provisoRoutingStgEntity.get("detailRecNumber"),
						OptionalUtil.getValue(detailRecNumber)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProvisoRoutingStgEntity> findByMainId(Optional<Integer> provisoMainId) {
		return (provisoRoutingStgEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoRoutingStgEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
	
	public static Specification<ProvisoRoutingStgEntity> equalsCarrierNumCode(String carrierNumCode) {
		return (provisoRoutingStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoRoutingStgEntity.get("carrierNumCode"), carrierNumCode);
	}
    
	public static Specification<ProvisoRoutingStgEntity> equalsProvisoSeqNumber(Integer provisoSeqNumber) {
		return (provisoRoutingStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoRoutingStgEntity.get("provisoSeqNumber"), provisoSeqNumber);
	}

	public static Specification<ProvisoRoutingStgEntity> equalsDetailRecNumber(Integer detailRecNumber) {
		return (provisoRoutingStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoRoutingStgEntity.get("detailRecNumber"), detailRecNumber);
	}
	
	public static Specification<ProvisoRoutingStgEntity> equalsRoutingRecNumber(Integer routingRecNumber) {
		return (provisoRoutingStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(provisoRoutingStgEntity.get("routingRecNumber"), routingRecNumber);
	}
    
    
	public static Specification<ProvisoRoutingStgEntity> notEqualsProvisoRoutingId(Integer provisoRoutingId){
		return (provisoRoutingStgEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(provisoRoutingStgEntity.get("provisoRoutingId"), provisoRoutingId);
	}
}
