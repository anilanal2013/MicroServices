package com.sgl.smartpra.global.master.app.service;

import java.util.List;

import com.sgl.smartpra.global.master.model.StandardAreaDetail;

public interface StandardAreaDetailService {
	public List<StandardAreaDetail> getListOfStandardAreaDetails(String standardAreaCode);

	public StandardAreaDetail getStandardAreaDetailByStandardAreaDetailCode(String standardAreaCode,
			Integer standardAreaDetailId);

	public StandardAreaDetail createStandardAreaDetail(String standardAreaCode, StandardAreaDetail standardareaDetail);

	public StandardAreaDetail updateStandardAreaDetail(String standardAreaCode, Integer standardAreaDetailId,
			StandardAreaDetail standardAreaDetail);

	public void deleteStandardAreaDetail(String standardAreaCode, Integer standardAreaDetailId);

}
