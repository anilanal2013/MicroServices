package com.sgl.smartpra.global.master.app.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class CacheManage {
	
	@Autowired
	CacheManager cacheManager;
	
	@Value("${cache.timeToLive}")
	long cacheExpiryTime;
	
	public void evictAllCaches() {
		cacheManager.getCacheNames().stream()
	      .forEach(cacheName -> cacheManager.getCache(cacheName).clear());
	}
	
	@Scheduled(fixedDelayString = "${cache.timeToLive}" ,  initialDelay = 500)
	public CacheManager evictAllcachesAtIntervals() {
		evictAllCaches();
	return cacheManager;
	}

}
