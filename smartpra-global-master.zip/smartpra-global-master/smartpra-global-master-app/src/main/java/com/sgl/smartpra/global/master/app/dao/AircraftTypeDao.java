package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.AircraftTypeEntity;
import com.sgl.smartpra.global.master.model.AircraftType;


public interface AircraftTypeDao {

	public Optional<AircraftTypeEntity> findById(String id);

	public AircraftTypeEntity create(AircraftTypeEntity aircraftTypeEntity);

	public AircraftTypeEntity update(AircraftTypeEntity aircraftTypeEntity);
	
	public List<AircraftTypeEntity> update(List<AircraftTypeEntity> aircraftTypeEntity);
	
	public Optional<AircraftTypeEntity> findOne(Optional<String> id);

    List<AircraftTypeEntity> findAll();
}
