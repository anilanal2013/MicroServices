package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.repository.entity.ChargeCodeEntity;

public class ChargeCodeEntitySpec {
	public static Specification<ChargeCodeEntity> search(Optional<String> chargeCode, Optional<String> chargeCodeName,
			Optional<String> chargeCategoryCode) {
		return (chargeCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(chargeCode)) {
				predicates.add(criteriaBuilder.like(chargeCodeEntity.get("chargeCode"),
						OptionalUtil.getValue(chargeCode) + "%"));
			}
			if (OptionalUtil.isPresent(chargeCategoryCode)) {
				predicates.add(criteriaBuilder.like(chargeCodeEntity.get("chargeCategoryCode"),
						OptionalUtil.getValue(chargeCategoryCode) + "%"));
			}
			if (OptionalUtil.isPresent(chargeCodeName)) {
				predicates.add(criteriaBuilder.like(chargeCodeEntity.get("chargeCodeName"),
						OptionalUtil.getValue(chargeCodeName) + "%"));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ChargeCodeEntity> findOne(Optional<String> chargeCode) {
		return (chargeCodeEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(chargeCode)) {
				predicates.add(criteriaBuilder.like(chargeCodeEntity.get("chargeCode"),
						OptionalUtil.getValue(chargeCode) + "%"));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
