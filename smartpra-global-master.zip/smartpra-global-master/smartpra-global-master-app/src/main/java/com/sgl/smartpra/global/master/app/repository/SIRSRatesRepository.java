package com.sgl.smartpra.global.master.app.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sgl.smartpra.global.master.app.dao.entity.SIRSRatesEntity;

public interface SIRSRatesRepository
		extends JpaRepository<SIRSRatesEntity, Integer>, JpaSpecificationExecutor<SIRSRatesEntity> {

	@Query(value = "select a from SIRSRatesEntity a where (:effectiveDate between a.effectiveFromDate  AND a.effectiveToDate) AND a.activate = 'Y'")
	public List<SIRSRatesEntity> getAllSIRSRatesEntity(@Param("effectiveDate") LocalDate effectiveDate);

}
