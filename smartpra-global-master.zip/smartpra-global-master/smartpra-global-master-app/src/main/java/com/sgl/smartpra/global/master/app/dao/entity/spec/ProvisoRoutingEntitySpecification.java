package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingEntity;

public class ProvisoRoutingEntitySpecification {
	ProvisoRoutingEntitySpecification() {
	}

	public static Specification<ProvisoRoutingEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber, Optional<Integer> detailRecNumber) {
		return (provisoRoutingEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(carrierNumCode)) {
				predicates.add(criteriaBuilder.equal(provisoRoutingEntity.get("carrierNumCode"),
						OptionalUtil.getValue(carrierNumCode)));
			}
			if (OptionalUtil.isPresent(provisoSeqNumber)) {
				predicates.add(criteriaBuilder.equal(provisoRoutingEntity.get("provisoSeqNumber"),
						OptionalUtil.getValue(provisoSeqNumber)));
			}
			if (OptionalUtil.isPresent(detailRecNumber)) {
				predicates.add(criteriaBuilder.equal(provisoRoutingEntity.get("detailRecNumber"),
						OptionalUtil.getValue(detailRecNumber)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ProvisoRoutingEntity> findByMainId(Optional<Integer> provisoMainId) {
		return (provisoRoutingEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(provisoMainId)) {
				predicates.add(criteriaBuilder.equal(provisoRoutingEntity.get("provisoMainId"),
						OptionalUtil.getValue(provisoMainId)));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
