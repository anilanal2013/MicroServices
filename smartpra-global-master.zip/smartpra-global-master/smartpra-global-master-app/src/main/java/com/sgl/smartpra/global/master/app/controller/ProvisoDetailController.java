package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.global.master.app.service.ProvisoDetailService;
import com.sgl.smartpra.global.master.model.ProvisoDetailModel;

@RestController
@RequestMapping("/proviso/detail")
public class ProvisoDetailController {
	@Autowired
	private ProvisoDetailService provisoDetailService;

	@GetMapping("provisoMain/{provisoMainId}")
	public List<ProvisoDetailModel> getProvisoSectorByProvisoMainId(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId) {
		return provisoDetailService.getProvisoDetailByProvisoMainId(provisoMainId);
	}

	@GetMapping("/{provisoDetailId}")
	public ProvisoDetailModel getProvisoSectorByProvisioSectorId(
			@PathVariable(value = "provisoDetailId") Integer provisoDetailId) {
		return provisoDetailService.getProvisoDetailByProvisoDetailId(provisoDetailId);
	}

	@GetMapping("/proviso-deatail/{carrierNumCode}/{provisoSeqNumber}")
	public List<ProvisoDetailModel> searchByProvisoSector(
			@PathVariable(value = "carrierNumCode") Optional<String> carrierNumCode,
			@PathVariable(value = "provisoSeqNumber") Optional<Integer> provisoSeqNumber) {
		return provisoDetailService.search(carrierNumCode, provisoSeqNumber);
	}

	@GetMapping("/search")
	public List<ProvisoDetailModel> search(
			@RequestParam(name = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@RequestParam(name = "provisoSeqNumber", required = false) Optional<Integer> provisoSeqNumber,
			@RequestParam(name = "fbGroupCode", required = false) Optional<String> fbGroupCode) {
		return provisoDetailService.search(carrierNumCode, provisoSeqNumber, fbGroupCode);
	}
	
	@GetMapping("/exceptionlist")
	public List<ProvisoDetailModel>  getExceptionRecordFromProvisoDetail(@RequestParam(name = "provisoSeqNumber", required = false)Optional<Integer> provisoSeqNumber,
			@RequestParam(name = "detailRecNumber", required = false)Optional<Integer> detailRecNumber,
			@RequestParam(name = "carrierNumericCode", required = false)Optional<String> carrierNumCode){
		
		return provisoDetailService.getExceptionRecordFromProvisoDetail(provisoSeqNumber,detailRecNumber,carrierNumCode);
	}
}
