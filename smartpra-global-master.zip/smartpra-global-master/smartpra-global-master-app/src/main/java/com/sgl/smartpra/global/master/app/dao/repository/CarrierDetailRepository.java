package com.sgl.smartpra.global.master.app.dao.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sgl.smartpra.global.master.app.dao.entity.CarrierDetailEntity;


public interface CarrierDetailRepository extends JpaRepository<CarrierDetailEntity, Integer>, JpaSpecificationExecutor<CarrierDetailEntity> {
	
	@Query(value = "select a from CarrierDetailEntity a  where (:effectiveDate between a.effectiveFromDate  AND a.effectiveToDate) or a.carrierCode = :carrierCode ")
	public List<CarrierDetailEntity> getAllCarrierEntityByEffectiveDate(@Param("carrierCode") String carrierCode,@Param("effectiveDate") LocalDate effectiveDate);
	
	@Query(value = "select a from CarrierDetailEntity a  where (:effectiveDate between a.effectiveFromDate  AND a.effectiveToDate) and a.carrierCode = :carrierCode")
	public CarrierDetailEntity getCarrierTypeByCarrierCode(@Param("carrierCode") String carrierCode, @Param("effectiveDate") LocalDate effectiveDate);
	
}
