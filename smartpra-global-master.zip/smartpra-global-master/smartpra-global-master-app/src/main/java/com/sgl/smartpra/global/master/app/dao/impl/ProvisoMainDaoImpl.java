package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoMainDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoMainEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoMainRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoMainDaoImpl implements ProvisoMainDao {

	@Autowired
	private ProvisoMainRepository provisoMainRepository;

	@Override
	@Cacheable(value = "provisoMainModel", key = "#id")
	public Optional<ProvisoMainEntity> findById(Integer id) {
		
		log.info("Cacheable Proviso Main Entity's ID= {}", id);
		return provisoMainRepository.findById(id);
	}

	@Override
	public List<ProvisoMainEntity> searchProvisoMain(Optional<String> carrierNumCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> provisoSection,
			Optional<String> provisoStatus) {
		
		return provisoMainRepository.findAll(ProvisoMainEntitySpecification.search(carrierNumCode, effectiveFromDate,
				effectiveToDate, provisoSection,provisoStatus));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "provisoMainModel", key = "#provisoMainEntity.provisoMainId") })
	public ProvisoMainEntity create(ProvisoMainEntity provisoMainEntity) {
		return provisoMainRepository.save(provisoMainEntity);
	}
}
