package com.sgl.smartpra.global.master.app.mapper;


import org.mapstruct.*;

import com.sgl.smartpra.global.master.app.repository.entity.FrequencyType;
import com.sgl.smartpra.global.master.model.FrequencyTypeDTO;

/**
 * Mapper for the entity FrequencyType and its DTO FrequencyTypeDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface FrequencyTypeMapper extends EntityMapper<FrequencyTypeDTO, FrequencyType> {



    default FrequencyType fromId(Long id) {
        if (id == null) {
            return null;
        }
        FrequencyType frequencyType = new FrequencyType();
        frequencyType.getFrequencyTypeId();
        return frequencyType;
    }
}
