package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
@Table(name = "global_mas_carrier_detail")
public class CarrierDetailEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "carrier_dtl_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer carrierDetailId;

	@Column(name = "carrier_code", nullable = false,length=3)
	private String carrierCode;

	@Column(name = "effective_from_date", nullable = false)
	private LocalDate effectiveFromDate;

	@Column(name = "effective_to_date", nullable = false)
	private LocalDate effectiveToDate;
	
	@Column(name = "carrier_type", length = 4)
	private String carrierType;

	@Column(name = "base_country_code", nullable = false, length = 2)
	private String baseCountryCode;

	@Column(name = "base_city_code", nullable = false, length = 2)
	private String baseCityCode;

	@Column(name = "list_currency", nullable = false, length = 3)
	private String listCurrency;
	
	@Column(name = "country_code_icao", nullable = false, length = 2)
	private String countryCodeIcao;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
