package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.DictionaryValueDao;
import com.sgl.smartpra.global.master.app.dao.entity.spec.DictionaryValueEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.DictionaryValueRepository;
import com.sgl.smartpra.global.master.app.repository.entity.DictionaryValueEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DictionaryValueDaoImpl implements DictionaryValueDao {

	@Autowired
	DictionaryValueRepository dictionaryValueRepository;
	
	@Override
	@Cacheable(value = "dictionaryValueEntity", key="#id")
	public Optional<DictionaryValueEntity> findById(Integer id) {
		log.info("Cacheable Dictionary Value Entity's ID= {}", id);
		return dictionaryValueRepository.findById(id);
	}

	@Override
	@Caching(evict= {@CacheEvict(value="dictionaryValueEntity",key = "#dictionaryValueEntity.dictionaryValueId")})
	public DictionaryValueEntity create(DictionaryValueEntity dictionaryValueEntity) {
		return dictionaryValueRepository.save(dictionaryValueEntity);
	}

	@Override
	@Caching(evict= {@CacheEvict(value="dictionaryValueEntity",key = "#dictionaryValueEntity.dictionaryValueId")})
	public DictionaryValueEntity update(DictionaryValueEntity dictionaryValueEntity) {
		return dictionaryValueRepository.save(dictionaryValueEntity);
	}

	@Override
	public List<DictionaryValueEntity> getDictionaryValueByDictionaryId(Integer dictionaryValueId) {
		return dictionaryValueRepository.findAll(DictionaryValueEntitySpecification.search(dictionaryValueId));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "dictionaryValueEntity", key = "#id") })
	public void deleteById(Integer id) {
		dictionaryValueRepository.deleteById(id);

	}

}
