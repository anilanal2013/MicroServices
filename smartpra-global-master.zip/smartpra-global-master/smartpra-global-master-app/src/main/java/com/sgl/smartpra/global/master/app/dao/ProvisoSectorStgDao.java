package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorStgEntity;
@Repository
public interface ProvisoSectorStgDao {

	ProvisoSectorStgEntity create(ProvisoSectorStgEntity provisoSectorStgEntity);
	
	List<ProvisoSectorStgEntity> findByMainId(Optional<Integer> provisoMainId);
	
	Optional<ProvisoSectorStgEntity> findById(Integer provisoSectorId);

	List<ProvisoSectorStgEntity> searchByProvisoInMain(Optional<Integer> provisoMainId, Optional<String> areaFrom);

	List<ProvisoSectorStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);

	ProvisoSectorStgEntity update(ProvisoSectorStgEntity provisoSectorStgEntity);
	
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer sectionRecNumber);
	
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, Integer sectionRecNumber,Integer provisoSectorId);

	List<ProvisoSectorStgEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> sectionRecNumber);
	public List<Integer> getListOfProvisoMainIdFromSectorStgDb();

	void deleteProvisoSectorByProvisoMainId(Integer provisoMainId);

	void deleteProvisoSectorByProvisoSectorId(Integer provisoSectorId);
	
	public Integer getMaxOfProvisoSecRecNumber(Optional<String> carrierNumCode,Optional<Integer> provisoSeqNumber);
}
