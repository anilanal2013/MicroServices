package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.ProvisoCodeshareStgService;
import com.sgl.smartpra.global.master.model.ProvisoCodeshareStgModel;

@RestController
@RequestMapping("/proviso/codeshare/stg")
public class ProvisoCodeshareStgController {

	@Autowired
	ProvisoCodeshareStgService provisoCodeshareStgService;

	@PostMapping("/{provisoMainId}/proviso-codeshare")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoCodeshareStgModel createProvisoCodeshare(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@Validated(Create.class) @RequestBody ProvisoCodeshareStgModel provisoCodeshareStgModel) {
		provisoCodeshareStgModel.setProvisoMainId(provisoMainId);
		return provisoCodeshareStgService.createProvisoCodeshare(provisoCodeshareStgModel);
	}

	@GetMapping("/{provisoCodeshareId}")
	public ProvisoCodeshareStgModel getProvisoCodeshareByProvisoCodeshareId(
			@PathVariable(value = "provisoCodeshareId") Integer provisoCodeshareId) {
		return provisoCodeshareStgService.getProvisoCodeshareByProvisoCodeshareId(provisoCodeshareId);
	}

	@GetMapping("provisoMain/{provisoMainId}")
	public List<ProvisoCodeshareStgModel> getProvisoCodeshareByProvisoMainId(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId) {
		return provisoCodeshareStgService.getProvisoCodeshareByProvisoMainId(provisoMainId);
	}

	@GetMapping("/{provisoMainId}/{areaFrom}/{areaTo}")
	public List<ProvisoCodeshareStgModel> searchByProvisoMain(
			@PathVariable(value = "provisoMainId", required = false) Optional<Integer> provisoMainId,
			@PathVariable(value = "areaFrom", required = false) Optional<String> areaFrom,
			@PathVariable(value = "areaTo", required = false) Optional<String> areaTo) {
		return provisoCodeshareStgService.searchByProvisoMain(provisoMainId, areaFrom, areaTo);
	}

	@GetMapping("/search")
	public List<ProvisoCodeshareStgModel> search(
			@RequestParam(name = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@RequestParam(name = "provisoSeqNumber", required = false) Optional<Integer> provisoSeqNumber,
			@RequestParam(name = "provisoSection", required = false) Optional<String> provisoSection,
			@RequestParam(name = "areaFrom", required = false) Optional<String> areaFrom,
			@RequestParam(name = "areaTo", required = false) Optional<String> areaTo) {
		return provisoCodeshareStgService.search(carrierNumCode, provisoSeqNumber, provisoSection, areaFrom, areaTo);
	}

	@PutMapping("/{provisoMainId}/{provisoCodeshareId}")
	@ResponseStatus(value = HttpStatus.OK)
	public ProvisoCodeshareStgModel updateProvisoCodeshare(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@PathVariable(value = "provisoCodeshareId") Integer provisoCodeshareId,
			@Validated(Update.class) @RequestBody ProvisoCodeshareStgModel provisoCodeshareStgModel) {
		provisoCodeshareStgModel.setProvisoMainId(provisoMainId);
		return provisoCodeshareStgService.updateProvisoCodeshare(provisoCodeshareId, provisoCodeshareStgModel);
	}
	
	@DeleteMapping("/provisoCodeshareDeletedById/{provisoCodeshareId}")
	public void deleteProvisoCodeshareMasterStg(@PathVariable(value = "provisoCodeshareId") Integer provisoCodeshareId) {
		provisoCodeshareStgService.deleteProvisoCodehareByProvisoCodeshareId(provisoCodeshareId);
	}
}
