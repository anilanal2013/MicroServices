package com.sgl.smartpra.global.master.app.mapper;


import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.SectionDetailEntity;
import com.sgl.smartpra.global.master.model.SectionDetail;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SectionDetailMapper extends BaseMapper<SectionDetail, SectionDetailEntity>  {

	SectionDetailEntity mapToEntity(SectionDetail sectionDetail, @MappingTarget SectionDetailEntity sectionDetailEntity);

	@Mapping(source = "sectionDetailId", target = "sectionDetailId", ignore = true)
	SectionDetailEntity mapToEntity(SectionDetail sectionDetail);

}
