package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.FBTDElementDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoAddlDiscountStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountStgEntity;
import com.sgl.smartpra.global.master.app.mapper.ProvisoAdditionalDiscountStgMapper;
import com.sgl.smartpra.global.master.app.service.ProvisoAddlDiscountStgService;
import com.sgl.smartpra.global.master.app.service.ProvisoMainStgService;
import com.sgl.smartpra.global.master.model.ProvisoAdditionalDiscountStg;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoAddlDiscountStgServiceImpl implements ProvisoAddlDiscountStgService {
	public static final String OVERLAP_COMBINATION_EXIST = "Combination of CarrierNumCode,ProvisoSeqNumber and DiscountCode already exist";
	private static final String PROVISO_ADDLDISCOUNT_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN = "CarierNumCode of Proviso Additional Discount should be similar to CarierNumCode of Proviso Main Corresponding to Proviso Main Id";
	private static final String ADDLDISCOUNT_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso Additional Discount data not available for selected Proviso Main record";

	@Autowired
	private ProvisoAdditionalDiscountStgMapper provisoAdditionalDiscountStgMapper;
	@Autowired
	private ProvisoAddlDiscountStgDao provisoAddlDiscountStgDao;
	
	@Autowired
	private FBTDElementDao fbtdElementDao;

	@Autowired
	private ProvisoMainStgService provisoMainStgService;

	@Override
	public ProvisoAdditionalDiscountStg createProvisoAddlDiscount(
			ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg) {
		validateBusinessConstraintsForCreate(provisoAdditionalDiscountStg);
		provisoAdditionalDiscountStg.setCreatedDate(LocalDateTime.now());
		return provisoAdditionalDiscountStgMapper.mapToModel(provisoAddlDiscountStgDao
				.create(provisoAdditionalDiscountStgMapper.mapToEntity(provisoAdditionalDiscountStg)));
	}

	private void validateBusinessConstraintsForCreate(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg) {
		validateOverlapForCreate(provisoAdditionalDiscountStg);
		validateCarrierNumCodeByProvisoMainId(provisoAdditionalDiscountStg);
		validateDiscountCode(provisoAdditionalDiscountStg);
	}

	private void validateDiscountCode(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg) {
		List<String> elementCode = fbtdElementDao.getElementCodeByElementTypeAndAdditionalInfo();
		if (!(elementCode.contains(OptionalUtil.getValue(provisoAdditionalDiscountStg.getDiscountCode())))) {
			throw new BusinessException(
					"Invalid Discount Code:"  + OptionalUtil.getValue(provisoAdditionalDiscountStg.getDiscountCode()));
		}
	}

	private void validateCarrierNumCodeByProvisoMainId(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg) {

		String carrierNumCode = OptionalUtil.getValue((provisoMainStgService
				.getProvisoMainByprovisoMainId(OptionalUtil.getValue(provisoAdditionalDiscountStg.getProvisoMainId())))
						.getCarrierNumCode());

		if (!(OptionalUtil.getValue(provisoAdditionalDiscountStg.getCarrierNumCode())
				.equalsIgnoreCase(carrierNumCode))) {
			throw new BusinessException(PROVISO_ADDLDISCOUNT_CARRIERNUMCODE_SIMILARTY_WITH_PROVISO_MAIN);
		}

	}

	private void validateOverlapForCreate(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg) {
		if (OptionalUtil.isPresent(provisoAdditionalDiscountStg.getCarrierNumCode())
				&& OptionalUtil.isPresent(provisoAdditionalDiscountStg.getProvisoSeqNumber())
				&& OptionalUtil.isPresent(provisoAdditionalDiscountStg.getDiscountCode())) {
			if (provisoAddlDiscountStgDao.getOverlapRecordCount(
					OptionalUtil.getValue(provisoAdditionalDiscountStg.getCarrierNumCode()),
					OptionalUtil.getValue(provisoAdditionalDiscountStg.getProvisoSeqNumber()),
					OptionalUtil.getValue(provisoAdditionalDiscountStg.getDiscountCode())) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	@Override
	public List<ProvisoAdditionalDiscountStg> getProvisoAddlDiscountByProvisoMainId(Optional<Integer> provisoMainId) {

		List<Integer> provisoMainIdFromDb = provisoAddlDiscountStgDao.getListOfProvisoMainIdFromAddlDiscountStgDb();
		if (!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))) {
			throw new BusinessException(ADDLDISCOUNT_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		return provisoAdditionalDiscountStgMapper.mapToModel(provisoAddlDiscountStgDao.findByMainId(provisoMainId));

	}

	@Override
	public ProvisoAdditionalDiscountStg getProvisoAddlDiscountByProvisoAddlDiscountId(Integer provisoAddlDiscountId) {
		return provisoAdditionalDiscountStgMapper.mapToModel(provisoAddlDiscountStgDao.findById(provisoAddlDiscountId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoAddlDiscountId))));
	}

	@Override
	public List<ProvisoAdditionalDiscountStg> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber) {
		return provisoAdditionalDiscountStgMapper
				.mapToModel(provisoAddlDiscountStgDao.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	public ProvisoAdditionalDiscountStg updateProvisoAddlDiscount(Integer provisoAddlDiscountId,
			ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg) {
		log.info("{}", provisoAdditionalDiscountStg);
		ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity = provisoAddlDiscountStgDao
				.findById(provisoAddlDiscountId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoAddlDiscountId)));
		validateBusinessConstraintsForUpdate(provisoAdditionalDiscountStg, provisoAdditionalDiscountStgEntity);
		provisoAdditionalDiscountStg.setLastUpdatedDate(LocalDateTime.now());
		return provisoAdditionalDiscountStgMapper
				.mapToModel(provisoAddlDiscountStgDao.update(provisoAdditionalDiscountStgMapper
						.mapToEntity(provisoAdditionalDiscountStg, provisoAdditionalDiscountStgEntity)));

	}

	private void validateBusinessConstraintsForUpdate(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg,
			ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity) {
		validateOverlapForUpdate(provisoAdditionalDiscountStg, provisoAdditionalDiscountStgEntity);
		validateCarrierNumCodeByProvisoMainId(provisoAdditionalDiscountStg);
	}

	private void validateOverlapForUpdate(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg,
			ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity) {
		String carrierNumCode = getCarrierNumCode(provisoAdditionalDiscountStg, provisoAdditionalDiscountStgEntity);
		Integer provisoSeqNumber = getProvisoSeqNumber(provisoAdditionalDiscountStg,
				provisoAdditionalDiscountStgEntity);
		String discountCode = getDiscountCode(provisoAdditionalDiscountStg, provisoAdditionalDiscountStgEntity);

		if (!carrierNumCode.equalsIgnoreCase(provisoAdditionalDiscountStgEntity.getCarrierNumCode())
				|| !provisoSeqNumber.equals(provisoAdditionalDiscountStgEntity.getProvisoSeqNumber())
				|| !discountCode.equals(provisoAdditionalDiscountStgEntity.getDiscountCode())) {
			if (provisoAddlDiscountStgDao.getOverlapRecordCount(carrierNumCode, provisoSeqNumber, discountCode,
					provisoAdditionalDiscountStgEntity.getProvisoAddlDiscountId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
		}
	}

	private String getCarrierNumCode(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg,
			ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity) {
		return OptionalUtil.isPresent(provisoAdditionalDiscountStg.getCarrierNumCode())
				? OptionalUtil.getValue(provisoAdditionalDiscountStg.getCarrierNumCode())
				: provisoAdditionalDiscountStgEntity.getCarrierNumCode();
	}

	private Integer getProvisoSeqNumber(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg,
			ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity) {
		return OptionalUtil.isPresent(provisoAdditionalDiscountStg.getProvisoSeqNumber())
				? OptionalUtil.getValue(provisoAdditionalDiscountStg.getProvisoSeqNumber())
				: provisoAdditionalDiscountStgEntity.getProvisoSeqNumber();
	}

	private String getDiscountCode(ProvisoAdditionalDiscountStg provisoAdditionalDiscountStg,
			ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity) {
		return OptionalUtil.isPresent(provisoAdditionalDiscountStg.getDiscountCode())
				? OptionalUtil.getValue(provisoAdditionalDiscountStg.getDiscountCode())
				: provisoAdditionalDiscountStgEntity.getDiscountCode();
	}

	@Override
	public void deleteProvisoAddlDiscountByProvisoMainId(Integer provisoMainId) {
		provisoAddlDiscountStgDao.deleteProvisoAddlDiscountByProvisoMainId(provisoMainId);
	}

	@Override
	public void deleteProvisoAddlDiscountByProvisoAddlDiscountId(Integer provisoAddlDiscountId) {
		provisoAddlDiscountStgDao.deleteProvisoAddlDiscountByProvisoAddlDiscountId(provisoAddlDiscountId);

	}
}
