package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.CarrierDao;
import com.sgl.smartpra.global.master.app.dao.entity.CarrierEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.CarrierEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.CarrierRepository;
import com.sgl.smartpra.global.master.model.Carrier;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CarrierDaoImpl extends CommonSearchDao<Carrier> implements CarrierDao {

	@Autowired
	private CarrierRepository carrierRepository;
	
	@Override
	@Cacheable(value = "carrier", key = "#id")
	public Optional<CarrierEntity> findById(String id) {
		log.info("Cacheable Carrier Entity's ID= {}", id);
		return carrierRepository.findById(id);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "carrier", key = "#carrierEntity.carrierCode"),
			 @CacheEvict(value = "carrierCode", allEntries = true),@CacheEvict(value = "carrierDesignatorCode", allEntries = true) })
	public CarrierEntity create(CarrierEntity carrierEntity) {
		return carrierRepository.save(carrierEntity);
	}

	@Override
	@CachePut(value = "carrier", key = "#carrierEntity.carrierCode")
	@Caching(evict = { @CacheEvict(value = "carrierCode", allEntries = true),@CacheEvict(value = "carrierDesignatorCode", allEntries = true)})
	public CarrierEntity update(CarrierEntity carrierEntity) {
		return carrierRepository.save(carrierEntity);
	}

	@Override
	public List<CarrierEntity> findAll(Optional<String> carrierCode, Optional<String> carrierDesignatorCode,
			Optional<String> carrierName1, Optional<String> carrierName2, Optional<Boolean> isActive,Optional<String> exceptionCall) {
		return carrierRepository.findAll(CarrierEntitySpecification.search(carrierCode, carrierDesignatorCode,
				carrierName1, carrierName2, isActive,exceptionCall));
	}

	@Override
	public List<CarrierEntity> findDistinctByCarrierCodeIsNotNullAndIsActiveTrueOrderByCarrierCode() {
		
		return carrierRepository.findDistinctByCarrierCodeIsNotNullAndIsActiveTrueOrderByCarrierCode();
	}

	@Override
	@Cacheable({"carrierDesignatorCode"})
	public Optional<CarrierEntity> getCarrierByCarrierDesignatorCode(String carrierDesignatorCode) {
		log.info("Cacheable Carrier Entity carrierDesignatorCode= {}", carrierDesignatorCode);
		return carrierRepository.findOne(CarrierEntitySpecification.equalCarrierDesignatorCode(carrierDesignatorCode)
				.and(CarrierEntitySpecification.isActive()));
		
	}

	@Override
	@Cacheable(cacheNames={"carrierCode"})
	public Optional<CarrierEntity> getCarrierByCarrierCode(String carrierCode) {
		log.info("Cacheable Carrier Entity carrierCode= {}", carrierCode);
		return carrierRepository.findOne(CarrierEntitySpecification.equalCarrierCode(carrierCode)
				.and(CarrierEntitySpecification.isActive()));
	}
	
	@Override
	public List<CarrierEntity> isValidCarrierDesignatorCodeList(String carrierDesignatorCode) {
		return carrierRepository.findAll(Specification.where(CarrierEntitySpecification.equalCarrierDesignatorCode(carrierDesignatorCode)
				.and(CarrierEntitySpecification.isActive())));
	}
}
