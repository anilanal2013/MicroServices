package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorStgEntity;

@Repository
public interface ProvisoSectorStgRepository
		extends JpaRepository<ProvisoSectorStgEntity, Integer>, JpaSpecificationExecutor<ProvisoSectorStgEntity> {
	@Query(value = "select pss.provisoMainId from ProvisoSectorStgEntity pss")
	List<Integer> getListOfProvisoMainIdFromSectorStgDb();

	@Transactional
	@Modifying
	@Query("delete from ProvisoSectorStgEntity psse where psse.provisoMainId= ?1")
	void deleteProvisoSectorByProvisoMainId(Integer provisoMainId);

	@Query(value = "select max(pss.sectionRecNumber) from ProvisoSectorStgEntity pss where pss.carrierNumCode=?1 AND pss.provisoSeqNumber=?2")
	Integer getMaxOfProvisoSecRecNumber(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);
}
