package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainEntity;
import com.sgl.smartpra.global.master.model.ProvisoMainModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoMainMapper extends BaseMapper<ProvisoMainModel, ProvisoMainEntity>{
	ProvisoMainEntity mapToEntity(ProvisoMainModel provisoMainModel, @MappingTarget ProvisoMainEntity provisoMainEntity);
	
	@Mapping(source = "provisoMainId", target = "provisoMainId", ignore = true)	 
	ProvisoMainEntity mapToEntity(ProvisoMainModel provisoMainModel);
}
