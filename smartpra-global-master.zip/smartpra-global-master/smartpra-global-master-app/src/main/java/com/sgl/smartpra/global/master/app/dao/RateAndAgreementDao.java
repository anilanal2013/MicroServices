package com.sgl.smartpra.global.master.app.dao;

import com.sgl.smartpra.global.master.app.dao.entity.RateAndAgreementEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RateAndAgreementDao  {

    public RateAndAgreementEntity create(RateAndAgreementEntity rateAndAgreementEntity);

    RateAndAgreementEntity update(RateAndAgreementEntity mapToEntity);

    Optional<RateAndAgreementEntity> findById(Integer id);

    List<RateAndAgreementEntity> fetchAll(Optional<String> supplierCode, Optional<String> baseLocation, Optional<String> chargeCategory, Optional<String> chargeCode, Optional<String> effectivePeriodFrom, Optional<String> effectivePeriodTo, Optional<String> airport);

    Boolean delete(Integer id);
}
