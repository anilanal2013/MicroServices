package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.searchdao.CommonSearchDao;
import com.sgl.smartpra.global.master.app.dao.ChargeCategoryDao;
import com.sgl.smartpra.global.master.app.dao.entity.ChargeCategoryEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ChaCatEntitySpec;
import com.sgl.smartpra.global.master.app.dao.repository.ChargeCategoryRepository;

@Component
public class ChaCatDaoImpl<T> extends CommonSearchDao<T> implements ChargeCategoryDao {

	@Autowired
	private ChargeCategoryRepository chargeRepository;

	@Override
	public List<ChargeCategoryEntity> findAll(Optional<String> chargeCategoryCode, Optional<String> chargeCategoryName,
			Optional<Boolean> activate) {
		return chargeRepository.findAll(ChaCatEntitySpec.search(chargeCategoryCode, chargeCategoryName, activate));
	}

	@Override
	@Cacheable(value = "chargeCategory", key = "#id")
	public Optional<ChargeCategoryEntity> findOne(Optional<String> id) {
		return chargeRepository.findOne(ChaCatEntitySpec.findOne(id));
	}

	@Override
	public Optional<ChargeCategoryEntity> findByChargeCategoryName(Optional<String> name) {
		return chargeRepository.findOne(ChaCatEntitySpec.findByChargeCategoryName(name));
	}

	@Override
	@Cacheable(value = "chargeCategory", key = "#id")
	public Optional<ChargeCategoryEntity> findId(Optional<String> id) {
		return chargeRepository.findOne(ChaCatEntitySpec.findOne(id));
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "chargeCategory", key = "#mapToEntity.chargeCategoryCode") })
	public ChargeCategoryEntity create(ChargeCategoryEntity mapToEntity) {
		return chargeRepository.save(mapToEntity);
	}

	@Override
	// @CachePut(value = "chargeCategory", key = "#chargeEntity.chargeCategoryCode")
	public List<ChargeCategoryEntity> update(List<ChargeCategoryEntity> chargeEntity) {
		return chargeRepository.saveAll(chargeEntity);
	}

	@Override
	public ChargeCategoryEntity update(ChargeCategoryEntity chargeEntity) {
		return chargeRepository.save(chargeEntity);
	}

	@Override
	public List<String> getChargeCatCodeFromChargeCatMaster() {

		return chargeRepository.getChargeCatCodeFromChargeCatMaster();
	}

}