package com.sgl.smartpra.global.master.app.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.constant.LOVEnum;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.common.aspects.GlobalCommonUtils;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.CarrierDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.CarrierDetailEntity;
import com.sgl.smartpra.global.master.app.dao.repository.CarrierDetailRepository;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.mapper.CarrierDetailMapper;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CarrierDetailService;
import com.sgl.smartpra.global.master.app.service.CarrierService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.CurrencyService;
import com.sgl.smartpra.global.master.model.CarrierDetail;

@Service
@Transactional
public class CarrierDetailServiceImpl implements CarrierDetailService {

	@Autowired
	CarrierDetailRepository carrierDetailRepository;

	@Autowired
	private AirportService airportService;

	@Autowired
	CarrierDetailMapper carrierDetailMapper;

	@Autowired
	CarrierDetailDao carrierDetailDao;

	@Autowired
	CarrierService carrierService;

	@Autowired
	CountryService countryService;

	@Autowired
	CurrencyService currencyService;

	@Autowired
	private MasterFeignClient masterFeignClient;

	private static final String CARRIERDETAILID = "CarrierDetailId";
	private static final String CARRIERCODE = "CarrierCode";
	private String invalidCarrierCode = "Invalid Carrier code ";
	private String invalidCountryCode = "Invalid Country code ";
	private String invalidCurrencyCode = "Invalid Currency code ";
	private static final String OVERLAP_COMBINATION_EXIST = "Record already exists";
	private static final String CARRIER_CODE_MISMATCH = "Carrier Code in Json should be same as URL ";
	private static final String CARRIER_CODE_INACTIVE = "Carrier Code is not active";
	String clientId = null;
	public static final String TABLENAME = LOVEnum.TABLENAME.getLOVEnum();
	public static final String CARRIER_TYPE_LOV_COLUMN_VALUE = LOVEnum.CARRIER_TYPE.getLOVEnum();

	@Override
	public List<CarrierDetail> getListOfCarrierDetailsByEffectiveDate(Optional<String> carrierCode,
			Optional<String> effectiveDate) {
		return carrierDetailMapper.mapToModel(carrierDetailDao.findAll(carrierCode, effectiveDate));
	}

	@Override
	public CarrierDetail getCarrierDetailByCarrierDetailCode(String carrierCode, int carrierDetailId) {
		return carrierDetailMapper.mapToModel(carrierDetailDao.findById(carrierDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(carrierDetailId))));
	}

	@Override
	public CarrierDetail createCarrierDetail(String carrierCode, CarrierDetail carrierDetail) {

		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);

		if (OptionalUtil.isPresent(carrierDetail.getCarrierCode())) {
			if (!carrierCode.equalsIgnoreCase(OptionalUtil.getValue(carrierDetail.getCarrierCode()))) {
				throw new BusinessException(CARRIER_CODE_MISMATCH);
			}
		} else {
			carrierDetail.setCarrierCode(Optional.of(carrierCode));
		}

		if (OptionalUtil.isPresent(carrierDetail.getCarrierType())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, TABLENAME,
					CARRIER_TYPE_LOV_COLUMN_VALUE);

			if (!(listOfValues.contains(OptionalUtil.getValue(carrierDetail.getCarrierType())))) {
				throw new BusinessException(
						"Carrier Type[" + OptionalUtil.getValue(carrierDetail.getCarrierType()) + "] is Not Valid");
			}
		}

		validateEffectiveToDate(OptionalUtil.getLocalDateValue(carrierDetail.getEffectiveToDate()),
				OptionalUtil.getLocalDateValue(carrierDetail.getEffectiveFromDate()));

		carrierDetail.setCarrierCode(Optional.of(carrierCode));
		try {
			carrierService.findCarrierByCarrierCode(OptionalUtil.getValue(carrierDetail.getCarrierCode()));
		} catch (ResourceNotFoundException rnfe) {
			throw new BusinessException(invalidCarrierCode + OptionalUtil.getValue(carrierDetail.getCarrierCode()));

		}

		if (!airportService.isValidAirportCodeOrCityCode(OptionalUtil.getValue(carrierDetail.getBaseCityCode()))) {
			throw new BusinessException(
					"Invalid Base City Code " + OptionalUtil.getValue(carrierDetail.getBaseCityCode()));
		}

		validationForBaseCountryCodeAndCountryCodeIcao(carrierDetail);

		try {
			currencyService.findCurrencyByCurrencyCode(OptionalUtil.getValue(carrierDetail.getListCurrency()));
		} catch (ResourceNotFoundException rnfe) {
			throw new BusinessException(invalidCurrencyCode + OptionalUtil.getValue(carrierDetail.getListCurrency()));

		} catch (BusinessException se) {
			throw new BusinessException(invalidCurrencyCode + OptionalUtil.getValue(carrierDetail.getListCurrency()));
		}
		validateOverlap(carrierDetail);

		if (!carrierService.isValidCarrierCode(carrierCode)) {
			throw new BusinessException(CARRIER_CODE_INACTIVE);
		}

		carrierDetail.setCreatedDate(LocalDateTime.now());
		return carrierDetailMapper.mapToModel(carrierDetailDao.create(carrierDetailMapper.mapToEntity(carrierDetail)));
	}

	@Override
	public CarrierDetail updateCarrierDetail(String carrierCode, int carrierDetailId, CarrierDetail carrierDetail) {

		clientId = GlobalCommonUtils.getHostCarrierDesigCode(masterFeignClient);

		if (OptionalUtil.isPresent(carrierDetail.getCarrierCode())) {
			if (!carrierCode.equalsIgnoreCase(OptionalUtil.getValue(carrierDetail.getCarrierCode()))) {
				throw new BusinessException(CARRIER_CODE_MISMATCH);
			}
		} else {
			carrierDetail.setCarrierCode(Optional.of(carrierCode));
		}

		if (OptionalUtil.isPresent(carrierDetail.getCarrierType())) {
			List<String> listOfValues = masterFeignClient.getListOfValues(clientId, TABLENAME,
					CARRIER_TYPE_LOV_COLUMN_VALUE);

			if (!(listOfValues.contains(OptionalUtil.getValue(carrierDetail.getCarrierType())))) {
				throw new BusinessException(
						"Carrier Type[" + OptionalUtil.getValue(carrierDetail.getCarrierType()) + "] is Not Valid");
			}
		}

		validateEffectiveToDate(OptionalUtil.getLocalDateValue(carrierDetail.getEffectiveToDate()),
				OptionalUtil.getLocalDateValue(carrierDetail.getEffectiveFromDate()));

		Optional<CarrierDetailEntity> carrierDetailEntity = carrierDetailRepository.findById(carrierDetailId);

		if (!carrierDetailEntity.isPresent()) {
			throw new ResourceNotFoundException(CARRIERDETAILID, "code", carrierDetailId);
		}

		if (carrierDetailEntity.get().getCarrierCode().equals(carrierCode)) {
			try {
				carrierService.findCarrierByCarrierCode(carrierCode);
			} catch (ResourceNotFoundException rnfe) {
				throw new BusinessException(invalidCarrierCode + carrierCode);

			} catch (BusinessException se) {
				throw new BusinessException(invalidCarrierCode + carrierCode);
			}

			if (!airportService.isValidAirportCodeOrCityCode(OptionalUtil.getValue(carrierDetail.getBaseCityCode()))) {
				throw new BusinessException(
						"Invalid Base City Code " + OptionalUtil.getValue(carrierDetail.getBaseCityCode()));
			}

			validationForBaseCountryCodeAndCountryCodeIcao(carrierDetail);

			try {
				currencyService.findCurrencyByCurrencyCode(OptionalUtil.getValue(carrierDetail.getListCurrency()));
			} catch (ResourceNotFoundException rnfe) {
				throw new BusinessException(
						invalidCurrencyCode + OptionalUtil.getValue(carrierDetail.getListCurrency()));

			} catch (BusinessException se) {
				throw new BusinessException(
						invalidCurrencyCode + OptionalUtil.getValue(carrierDetail.getListCurrency()));
			}
		} else {
			throw new BusinessException(
					"Carrier code " + carrierCode + "  and Carrier code in Carrier Details Master " + carrierDetailId);
		}
		carrierDetail.setCarrierCode(Optional.of(carrierCode));
		carrierDetail.setCarrierDetailId(carrierDetailId);
		carrierDetailEntity.get().setLastUpdatedDate(LocalDateTime.now());
		validateOverlapForUpdate(carrierDetail, carrierDetailEntity.get());
		return carrierDetailMapper.mapToModel(
				carrierDetailDao.update(carrierDetailMapper.mapToEntity(carrierDetail, carrierDetailEntity.get())));
	}

	@Override
	public void deleteCarrierDetail(String carrierCode, int carrierDetailId) {
		Optional<CarrierDetailEntity> carrierDetailEntity = carrierDetailRepository.findById(carrierDetailId);

		if (carrierDetailEntity.isPresent()) {
			if (carrierDetailEntity.get().getCarrierCode().equals(carrierCode)) {
				carrierDetailDao.deleteById(carrierDetailId);
			} else {
				throw new ResourceNotFoundException(CARRIERCODE, "code", carrierCode);
			}

		} else {
			throw new ResourceNotFoundException(CARRIERDETAILID, "code", carrierDetailId);
		}
	}

	private void validationForBaseCountryCodeAndCountryCodeIcao(CarrierDetail carrierDetail) {

		String[] array = { OptionalUtil.getValue(carrierDetail.getBaseCountryCode()),
				OptionalUtil.getValue(carrierDetail.getCountryCodeIcao()) };
		for (int i = 0; i <= array.length - 1; i++) {
			try {
				countryService.getCountryByCountryCode(array[i]);
			} catch (ResourceNotFoundException rnfe) {
				throw new BusinessException(invalidCountryCode + array[i]);

			} catch (BusinessException se) {
				throw new BusinessException(invalidCountryCode + array[i]);
			}
		}
	}

	@Override
	public CarrierDetail getCarrierType(String carrierDesignatorCode, String effectiveDate) {
		String carrierCode = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date effectiveDateParse = null;
		try {
			effectiveDateParse = sdf.parse(effectiveDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		carrierCode = carrierService.getCarrrierCodeByCarrierDesignatorCode(carrierDesignatorCode);
		CarrierDetailEntity carrierDetailEntity = carrierDetailRepository.getCarrierTypeByCarrierCode(carrierCode,
				convertLocalDate(effectiveDateParse));
		if (carrierDetailEntity != null) {
			return carrierDetailMapper.mapToModel(carrierDetailEntity);
		} else {
			return carrierDetailMapper.mapToModel(new CarrierDetailEntity());

		}
	}

	@Override
	public CarrierDetail getCarrierTypeByCarrierCode(String carrierCode, String effectiveDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date effectiveDateParse = null;
		try {
			effectiveDateParse = sdf.parse(effectiveDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		CarrierDetailEntity carrierDetailEntity = carrierDetailRepository.getCarrierTypeByCarrierCode(carrierCode,
				convertLocalDate(effectiveDateParse));
		if (carrierDetailEntity != null) {
			return carrierDetailMapper.mapToModel(carrierDetailEntity);
		} else {
			return carrierDetailMapper.mapToModel(new CarrierDetailEntity());

		}
	}

	private void validateOverlap(CarrierDetail carrierDetail) {
		if (carrierDetailDao.getOverLapRecordCount(OptionalUtil.getLocalDateValue(carrierDetail.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(carrierDetail.getEffectiveToDate()),
				OptionalUtil.getValue(carrierDetail.getCarrierCode())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

	private void validateOverlapForUpdate(CarrierDetail carrierDetail, CarrierDetailEntity carrierDetailEntity) {
		if (carrierDetailDao.getOverLapRecordCountForUpdate(
				OptionalUtil.getLocalDateValue(carrierDetail.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(carrierDetail.getEffectiveToDate()),
				OptionalUtil.getValue(carrierDetail.getCarrierCode()), carrierDetailEntity.getCarrierDetailId()) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

	public LocalDate convertLocalDate(Date date) {
		if (date != null) {
			return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		} else {
			return null;
		}
	}

	private void validateEffectiveToDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("Effective To date[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("Effective To Date[" + effectiveToDate
					+ "] should be greater than Effective From Date[" + effectiveFromDate + "]");
		}
	}
}
