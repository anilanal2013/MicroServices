package com.sgl.smartpra.global.master.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.StandardAreaDetailService;
import com.sgl.smartpra.global.master.model.StandardAreaDetail;

@RestController
public class StandardAreaDetailController {

	@Autowired
	private StandardAreaDetailService standardAreaDetailService;

	@GetMapping("standardareas/{standardAreaCode}/details")
	public List<StandardAreaDetail> getListOfStandardAreaDeatails(
			@PathVariable(value = "standardAreaCode") String standardAreaCode) {
		return standardAreaDetailService.getListOfStandardAreaDetails(standardAreaCode);
	}

	@GetMapping("/standardareas/{standardAreaCode}/details/{standardAreaDetailId}")
	public StandardAreaDetail getStandardAreaDetailByStandardAreaDetailCode(
			@PathVariable(value = "standardAreaCode") String standardAreaCode,
			@PathVariable(value = "standardAreaDetailId") Integer standardAreaDetailId) {
		return standardAreaDetailService.getStandardAreaDetailByStandardAreaDetailCode(standardAreaCode,
				standardAreaDetailId);
	}

	@PostMapping("/standardareas/{standardAreaCode}/details")
	public StandardAreaDetail createStandardAreaDetail(
			@PathVariable(value = "standardAreaCode") String standardAreaCode,
			@Validated(Create.class) @RequestBody StandardAreaDetail standardareaDetail) {
		return standardAreaDetailService.createStandardAreaDetail(standardAreaCode, standardareaDetail);
	}

	@PutMapping("/standardareas/{standardAreaCode}/details/{standardAreaDetailId}")
	public StandardAreaDetail updateStandardAreaDetail(
			@PathVariable(value = "standardAreaDetailId") Integer standardAreaDetailId,
			@PathVariable(value = "standardAreaCode") String standardAreaCode,
			@Validated(Update.class) @RequestBody StandardAreaDetail standardAreaDetail) {
		return standardAreaDetailService.updateStandardAreaDetail(standardAreaCode, standardAreaDetailId,
				standardAreaDetail);
	}

	@DeleteMapping("/standardareas/{standardAreaCode}/details/{standardAreaDetailId}")
	public void deleteStandardAreaDetail(@PathVariable(value = "standardAreaCode") String standardAreaCode,
			@PathVariable(value = "standardAreaDetailId") Integer standardAreaDetailId) {
		standardAreaDetailService.deleteStandardAreaDetail(standardAreaCode, standardAreaDetailId);

	}

}
