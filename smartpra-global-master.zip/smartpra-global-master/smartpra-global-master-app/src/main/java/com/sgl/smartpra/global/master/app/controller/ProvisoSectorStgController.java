package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.ProvisoSectorStgService;
import com.sgl.smartpra.global.master.model.ProvisoSectorStgModel;

@RestController
@RequestMapping("/proviso/sector/stg")
public class ProvisoSectorStgController {

	@Autowired
	private ProvisoSectorStgService provisoSectorStgService;

	@PostMapping("/{provisoMainId}/proviso-sector")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoSectorStgModel createProvisoSector(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@Validated(Create.class) @RequestBody ProvisoSectorStgModel provisoSectorStgModel) {
		provisoSectorStgModel.setProvisoMainId(provisoMainId);
		return provisoSectorStgService.createProvisoSector(provisoSectorStgModel);
	}

	@GetMapping("provisoMain/{provisoMainId}")
	public List<ProvisoSectorStgModel> getProvisoSectorByProvisoMainId(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId) {
		return provisoSectorStgService.getProvisoSectorByProvisoMainId(provisoMainId);
	}

	@GetMapping("/{provisoSectorId}")
	public ProvisoSectorStgModel getProvisoSectorByProvisoSectorId(
			@PathVariable(value = "provisoSectorId") Integer provisoSectorId) {
		return provisoSectorStgService.getProvisoSectorByProvisoSectorId(provisoSectorId);
	}

	@GetMapping("/{provisoMainId}/{areaFrom}")
	public List<ProvisoSectorStgModel> searchByProvisoInMain(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@PathVariable(value = "areaFrom") Optional<String> areaFrom) {
		return provisoSectorStgService.searchByProvisoInMain(provisoMainId, areaFrom);
	}

	@GetMapping("/proviso-sector/{carrierNumCode}/{provisoSeqNumber}")
	public List<ProvisoSectorStgModel> searchByProvisoSector(
			@PathVariable(value = "carrierNumCode") Optional<String> carrierNumCode,
			@PathVariable(value = "provisoSeqNumber") Optional<Integer> provisoSeqNumber) {
		return provisoSectorStgService.search(carrierNumCode, provisoSeqNumber);
	}

	@GetMapping("/search")
	public List<ProvisoSectorStgModel> search(
			@RequestParam(name = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@RequestParam(name = "provisoSeqNumber", required = false) Optional<Integer> provisoSeqNumber,
			@RequestParam(name = "sectionRecNumber", required = false) Optional<Integer> sectionRecNumber) {
		return provisoSectorStgService.search(carrierNumCode, provisoSeqNumber, sectionRecNumber);
	}

	@PutMapping("/{provisoMainId}/{provisoSectorId}")
	@ResponseStatus(value = HttpStatus.OK)
	public ProvisoSectorStgModel updateProvisoSector(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@PathVariable(value = "provisoSectorId") Integer provisoSectorId,
			@Validated(Update.class) @RequestBody ProvisoSectorStgModel provisoSectorStgModel) {
		provisoSectorStgModel.setProvisoMainId(provisoMainId);
		return provisoSectorStgService.updateProvisoSector(provisoSectorId, provisoSectorStgModel);
	}
	
	@DeleteMapping("/provisoSectorDeletedById/{provisoSectorId}")
	public void deleteProvisoSectorMasterStg(@PathVariable(value = "provisoSectorId") Integer provisoSectorId) {
		provisoSectorStgService.deleteProvisoSectorByProvisoSectorId(provisoSectorId);
	}	
}
