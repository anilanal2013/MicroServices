package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.global.master.app.dao.ProvisoAddlDiscountStgDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountStgEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.ProvisoAddlDiscountStgEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoAddlDiscountStgRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProvisoAddlDiscountStgDaoImpl implements ProvisoAddlDiscountStgDao {

	@Autowired
	private ProvisoAddlDiscountStgRepository provisoAddlDiscountStgRepository;

	@Override
	@Caching(evict = {
			@CacheEvict(value = "provisoAdditionalDiscountStg", key = "#provisoAdditionalDiscountStgEntity.provisoAddlDiscountId") })
	public ProvisoAdditionalDiscountStgEntity create(
			ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity) {
		return provisoAddlDiscountStgRepository.save(provisoAdditionalDiscountStgEntity);
	}

	@Override
	public List<ProvisoAdditionalDiscountStgEntity> findByMainId(Optional<Integer> provisoMainId) {
		return provisoAddlDiscountStgRepository
				.findAll(ProvisoAddlDiscountStgEntitySpecification.findByMainId(provisoMainId));
	}

	@Override
	@Cacheable(value = "provisoAdditionalDiscountStg", key = "#id")
	public Optional<ProvisoAdditionalDiscountStgEntity> findById(Integer id) {

		log.info("Cacheable Proviso Additional Discount Entity's ID= {}", id);
		return provisoAddlDiscountStgRepository.findById(id);
	}

	@Override
	public List<ProvisoAdditionalDiscountStgEntity> search(Optional<String> carrierNumCode,
			Optional<Integer> provisoSeqNumber) {

		return provisoAddlDiscountStgRepository
				.findAll(ProvisoAddlDiscountStgEntitySpecification.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	@CachePut(value = "provisoAdditionalDiscountStg", key = "#provisoAdditionalDiscountStgEntity.provisoAddlDiscountId")
	@CacheEvict(value = "ProvisoAdditionalDiscountSearch", allEntries = true)
	public ProvisoAdditionalDiscountStgEntity update(
			ProvisoAdditionalDiscountStgEntity provisoAdditionalDiscountStgEntity) {
		return provisoAddlDiscountStgRepository.save(provisoAdditionalDiscountStgEntity);
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, String discountCode) {

		return provisoAddlDiscountStgRepository.count(
				Specification.where(ProvisoAddlDiscountStgEntitySpecification.equalsCarrierNumCode(carrierNumCode)
						.and(ProvisoAddlDiscountStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
						.and(ProvisoAddlDiscountStgEntitySpecification.equalsDiscountCode(discountCode))));
	}

	@Override
	public long getOverlapRecordCount(String carrierNumCode, Integer provisoSeqNumber, String discountCode,
			Integer provisoAddlDiscountId) {

		return provisoAddlDiscountStgRepository.count(Specification.where(ProvisoAddlDiscountStgEntitySpecification
				.equalsCarrierNumCode(carrierNumCode)
				.and(ProvisoAddlDiscountStgEntitySpecification.equalsProvisoSeqNumber(provisoSeqNumber))
				.and(ProvisoAddlDiscountStgEntitySpecification.equalsDiscountCode(discountCode))
				.and(ProvisoAddlDiscountStgEntitySpecification.notEqualsProvisoAddlDiscountId(provisoAddlDiscountId))));
	}

	@Override
	public List<Integer> getListOfProvisoMainIdFromAddlDiscountStgDb() {
		return provisoAddlDiscountStgRepository.getListOfProvisoMainIdFromAddlDistcountStgDb();
	}

	@Override
	public void deleteProvisoAddlDiscountByProvisoMainId(Integer provisoMainId) {
		provisoAddlDiscountStgRepository.deleteProvisoAddlDiscountByProvisoMainId(provisoMainId);
	}

	@Override
	public void deleteProvisoAddlDiscountByProvisoAddlDiscountId(Integer provisoAddlDiscountId) {
		provisoAddlDiscountStgRepository.deleteById(provisoAddlDiscountId);

	}
	
	@Override
	public void deleteProvisoAddlDiscountStg(Integer provisoMainId, String carrierNumCode, Integer provisoSeqNumber) {
		provisoAddlDiscountStgRepository.deleteProvisoAddlDiscountStgFromDb(provisoMainId,carrierNumCode,provisoSeqNumber);
	}
	
}
