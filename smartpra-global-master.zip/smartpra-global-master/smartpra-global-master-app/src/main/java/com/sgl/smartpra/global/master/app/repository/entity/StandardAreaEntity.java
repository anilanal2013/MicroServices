package com.sgl.smartpra.global.master.app.repository.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;
import com.sgl.smartpra.global.master.app.dao.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_std_area")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
public class StandardAreaEntity extends BaseEntity {

	@Id
	@Column(name = "std_area_code", nullable = false, length = 3)
	private String standardAreaCode;

	@Column(name = "std_area_name", nullable = false, length = 30)
	private String standardAreaName;

	@Column(name = "std_area_list", nullable = false, length = 1000)
	private String standardAreaList;
	
	@Column(name = "area_type", nullable = false, length = 1)
	private String areaType;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	@NotNull
	private Boolean activate;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}