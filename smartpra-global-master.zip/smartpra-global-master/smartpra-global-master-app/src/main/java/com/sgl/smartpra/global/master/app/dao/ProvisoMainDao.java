package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoMainEntity;
@Repository
public interface ProvisoMainDao {
	public Optional<ProvisoMainEntity> findById(Integer id);
	
	public List<ProvisoMainEntity> searchProvisoMain(Optional<String> carrierNumCode,
			Optional<String> effectiveFromDate, Optional<String> effectiveToDate, Optional<String> provisoSection,
			Optional<String> provisoStatus);
	public ProvisoMainEntity create(ProvisoMainEntity mapToEntity);

}
