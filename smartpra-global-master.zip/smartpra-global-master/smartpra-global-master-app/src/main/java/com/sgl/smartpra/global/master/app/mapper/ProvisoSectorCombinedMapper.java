package com.sgl.smartpra.global.master.app.mapper;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoSectorEntity;
import com.sgl.smartpra.global.master.model.ProvisoSectorStgModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoSectorCombinedMapper extends BaseMapper<ProvisoSectorStgModel, ProvisoSectorEntity> {
	ProvisoSectorEntity mapToEntity(ProvisoSectorStgModel provisoSectorStgModel,
			@MappingTarget ProvisoSectorEntity provisoSectorEntity);
	ProvisoSectorEntity mapToEntity(ProvisoSectorStgModel provisoSectorStgModel);
}
