package com.sgl.smartpra.global.master.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.FBTDElementEntity;

@Repository
public interface FBTDElementRepository
		extends JpaRepository<FBTDElementEntity, Integer>, JpaSpecificationExecutor<FBTDElementEntity> {

	@Query(value = "select fbtde.elementCode from FBTDElementEntity fbtde where fbtde.elementType=5 AND fbtde.additionalInfo='D'")
	 List<String> getElementCodeByElementTypeAndAdditionalInfo();
}
