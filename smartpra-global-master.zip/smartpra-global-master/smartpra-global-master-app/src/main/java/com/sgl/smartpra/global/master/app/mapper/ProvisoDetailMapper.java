package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoDetailEntity;
import com.sgl.smartpra.global.master.model.ProvisoDetailModel;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ProvisoDetailMapper extends BaseMapper<ProvisoDetailModel, ProvisoDetailEntity> {
	ProvisoDetailEntity mapToEntity(ProvisoDetailModel provisoDetailStgModel,
			@MappingTarget ProvisoDetailEntity provisoDetailStgEntity);

	@Mapping(source = "provisoDetailId", target = "provisoDetailId", ignore = true)
	ProvisoDetailEntity mapToEntity(ProvisoDetailModel provisoDetailStgModel);
}
