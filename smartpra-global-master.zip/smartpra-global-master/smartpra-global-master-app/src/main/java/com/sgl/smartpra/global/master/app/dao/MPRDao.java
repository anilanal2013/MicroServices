package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.repository.entity.MPREntity;

@Repository
public interface MPRDao {

	public Optional<MPREntity> findById(Integer minimumProrateRuleId);

	public MPREntity create(MPREntity mprEntity);

	public MPREntity update(MPREntity mapToEntity);

	List<MPREntity> verifyIfOverlapForUtilDateExists(LocalDate effectiveFromDate, LocalDate effectiveToDate);

	//public List<MPREntity> getMprDetails(Optional<String> effectiveDate);
	public Optional<MPREntity> getMprDetails(Optional<String> effectiveDate);

	public List<MPREntity> getMPR(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate);

}
