package com.sgl.smartpra.global.master.app.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.SectionDetailDao;
import com.sgl.smartpra.global.master.app.dao.entity.SectionDetailEntity;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.SectionDetailMapper;
import com.sgl.smartpra.global.master.app.service.SectionDetailService;
import com.sgl.smartpra.global.master.app.service.SectionService;
import com.sgl.smartpra.global.master.app.service.UOMService;
import com.sgl.smartpra.global.master.model.Section;
import com.sgl.smartpra.global.master.model.SectionDetail;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;

@Service
@Transactional
public class SectionDetailServiceImpl implements SectionDetailService {

	enum MONTH {
		JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC;
	}

	@Autowired
	SectionDetailMapper sectionDetailMapper;

	@Autowired
	SectionDetailDao sectionDetailDao;

	@Autowired
	SectionService sectionService;

	@Autowired
	UOMService uomService;

	@Autowired
	MasterFeignClient masterFeignClient;

	private String doesNotExist = " does not exist";
	private String isNotActive = " is not active";
	private static final String INVALIDSECTIONMASTERID = "Invalid Section Master Id in path variable. Section Master Id : ";
	private static final String BILLINGMONTHFORMAT = "billingMonth Format should be MMM-yy format";
	private static final String BILLINGMONTH = "MMM-yy";

	@Override
	public SectionDetail findSectionDetailBySectionDetailId(Integer sectionMasterId, Integer sectionDetailId) {

		validateSectionMasterId(sectionMasterId);

		SectionDetailEntity sectionDetailEntity = sectionDetailDao.findById(sectionDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sectionDetailId)));

		if (sectionDetailEntity.getSectionMasterId().equals(sectionMasterId)) {
			return sectionDetailMapper.mapToModel(sectionDetailEntity);
		} else {
			throw new ServiceException("Given Section Master Id: " + sectionMasterId
					+ "in path variable missmatch with sectionDetailId Record : " + sectionDetailId);
		}
	}

	@Override
	public List<SectionDetail> getAllSectionDetails(Integer sectionMasterId, Integer sectionDetailId,
			Optional<String> sectionElementName, Optional<Boolean> activate) {

		validateSectionMasterId(sectionMasterId);

		return sectionDetailMapper
				.mapToModel(sectionDetailDao.findAll(sectionMasterId, sectionDetailId, sectionElementName, activate));
	}

	@Override
	public SectionDetail createSectionDetail(Integer sectionMasterId, SectionDetail sectionDetail) {

		validateSectionMasterId(sectionMasterId);

		if (OptionalUtil.isPresent(sectionDetail.getOrderNumber())) {
			validateOrderNumber(sectionDetail);
		}

		/*
		 * if (!uomService.isValidUomType(String.valueOf(sectionDetail.getUomType()))) {
		 * throw new ServiceException("UomType is not active"); }
		 */

		sectionDetail.setActivate(Boolean.TRUE);
		sectionDetail.setSectionMasterId(sectionMasterId);
		sectionDetail.setCreatedDate(LocalDateTime.now());

		return sectionDetailMapper.mapToModel(sectionDetailDao.create(sectionDetailMapper.mapToEntity(sectionDetail)));
	}

	@Override
	public List<SectionDetail> updateSectionDetail(List<SectionDetail> sectionDetails) {
		List<SectionDetailEntity> sectionDetailEntityList = new ArrayList<>();
		for (SectionDetail sectionDetail : sectionDetails) {
			SectionDetailEntity sectionDetailEntity = sectionDetailDao.findById(sectionDetail.getSectionDetailId())
					.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sectionDetail.getSectionDetailId())));

			if (OptionalUtil.isPresent(sectionDetail.getApplicability())) {
				validateDisplayIndicator(sectionDetail);
			}

			if (OptionalUtil.isPresent(sectionDetail.getDisplayOrderNumber())) {
				validateDispalyOrderNumber(sectionDetail);
			}
			if (OptionalUtil.isPresent(sectionDetail.getMandatoryFromPeriod())) {
				validateMandatoryFromPeriod(sectionDetail);
			}
			if (OptionalUtil.isPresent(sectionDetail.getMandatoryFromPeriod())) {
				validateNonMandatoryfromPeriod(sectionDetail);
			}
			sectionDetailEntityList.add(sectionDetailMapper.mapToEntity(sectionDetail, sectionDetailEntity));
		}
		return sectionDetailMapper.mapToModel(sectionDetailDao.update(sectionDetailEntityList));
	}

	@Override
	public void deactivateSection(Integer sectionMasterId, Integer sectionDetailId, String lastUpdatedBy) {

		validateSectionMasterId(sectionMasterId);

		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		SectionDetailEntity sectionDetailEntity = sectionDetailDao.findById(sectionDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sectionDetailId)));

		if (!sectionDetailEntity.getActivate()) {
			throw new ServiceException("SectionDetail is already in deactivate state");
		}

		sectionDetailEntity.setLastUpdatedBy(lastUpdatedBy);
		sectionDetailEntity.setLastUpdatedDate(LocalDateTime.now());
		sectionDetailEntity.setActivate(Boolean.FALSE);

		sectionDetailDao.update(sectionDetailEntity);
	}

	@Override
	public void activateSection(Integer sectionMasterId, Integer sectionDetailId, String lastUpdatedBy) {

		validateSectionMasterId(sectionMasterId);

		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		SectionDetailEntity sectionDetailEntity = sectionDetailDao.findById(sectionDetailId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sectionDetailId)));

		if (sectionDetailEntity.getActivate()) {
			throw new BusinessException("SectionDetail is already activate state");
		}

		sectionDetailEntity.setLastUpdatedBy(lastUpdatedBy);
		sectionDetailEntity.setLastUpdatedDate(LocalDateTime.now());
		sectionDetailEntity.setActivate(Boolean.TRUE);

		sectionDetailDao.update(sectionDetailEntity);
	}

	private void validateOrderNumber(SectionDetail sectionDetail) {

		List<SectionDetailEntity> sectionDetailEntity = sectionDetailDao
				.getByOrderNumber(sectionDetail.getOrderNumber());

		if (!sectionDetailEntity.isEmpty()) {
			throw new BusinessException("For the given Section OrderNumber: " + sectionDetail.getOrderNumber()
					+ " can not give duplicate: " + sectionDetail.getOrderNumber());
		}
	}

	private void validateSectionMasterId(Integer sectionMasterId) {
		try {
			sectionService.findSectionBySectionMasterId(sectionMasterId);
		} catch (ResourceNotFoundException rnfe) {
			throw new BusinessException(INVALIDSECTIONMASTERID + sectionMasterId + doesNotExist);
		} catch (ServiceException se) {
			throw new BusinessException(INVALIDSECTIONMASTERID + sectionMasterId + isNotActive);
		}

	}

	private void validateDisplayIndicator(SectionDetail sectionDetail) {

		if (OptionalUtil.getValue(sectionDetail.getApplicability()).equals("M")) {
			sectionDetail.setDisplayIndicator(Boolean.TRUE);
		}
	}

	private void validateDispalyOrderNumber(SectionDetail sectionDetail) {

		List<SectionDetailEntity> sectionDetailEntity = sectionDetailDao
				.getByDisplayOrderNumber(sectionDetail.getSectionMasterId(), sectionDetail.getSectionDetailId(), sectionDetail.getDisplayOrderNumber());
		if (!sectionDetailEntity.isEmpty()) {
			throw new BusinessException(
					"For the given Section DisplayorderNumber: " + sectionDetail.getDisplayOrderNumber()
							+ " can not give duplicate: " + sectionDetail.getDisplayOrderNumber());
		}

		if (sectionDetail.getDisplayIndicator().equals(Boolean.TRUE)) {
			sectionDetail.setDisplayOrderNumber(sectionDetail.getDisplayOrderNumber());
		} else if (sectionDetail.getDisplayIndicator().equals(Boolean.FALSE) && Double.parseDouble(OptionalUtil.getValue(sectionDetail.getDisplayOrderNumber())) > 0.0) {
			throw new BusinessException("for given displayOrderNumber, displayIndicator is always set to true");
		}

	}

	private void validateMandatoryFromPeriod(SectionDetail sectionDetail) {

		String mandatoryField = null;
		Integer billingPeriod = null;
		String[] billingMonthPeriod = null;
		Date outwardBillingMonth = null;
		Date currentBillingMonth = null;

		if (!OptionalUtil.getValue(sectionDetail.getMandatoryFromPeriod()).isEmpty()) {
			validateBillingMonthAndBillingPeriod(OptionalUtil.getValue(sectionDetail.getMandatoryFromPeriod()));

			mandatoryField = OptionalUtil.getValue(sectionDetail.getMandatoryFromPeriod());
			billingMonthPeriod = mandatoryField.split("/");
			billingPeriod = Integer.valueOf(String.valueOf(billingMonthPeriod[1]));
	
			OutwardBillingPeriods outwardBillingPeriods = masterFeignClient.getCurrentOpenOutwardBillingPeriods();
	
			if ((billingPeriod < outwardBillingPeriods.getBillingPeriod()))
				throw new BusinessException(
						"Entered mandatoryBillingPeriod should not be lesser than outwardBillingPeriod");
	
			if (billingPeriod >= outwardBillingPeriods.getBillingPeriod()) {
				sectionDetail.setMandatoryFromPeriod(sectionDetail.getMandatoryFromPeriod());
			}
			if (OptionalUtil.getValue(sectionDetail.getApplicability()).equals("R")
					|| OptionalUtil.getValue(sectionDetail.getApplicability()).equals("RA")) {
				sectionDetail.setMandatoryFromPeriod(sectionDetail.getMandatoryFromPeriod());
			}
	
			try {
				outwardBillingMonth = new SimpleDateFormat(BILLINGMONTH).parse(outwardBillingPeriods.getBillingMonth());
			} catch (ParseException e1) {
				throw new BusinessException(BILLINGMONTHFORMAT);
			}
	
			try {
				currentBillingMonth = new SimpleDateFormat(BILLINGMONTH).parse(billingMonthPeriod[0]);
			} catch (ParseException e) {
				throw new BusinessException(BILLINGMONTHFORMAT);
			}
			if (currentBillingMonth.before(outwardBillingMonth)) {
				if (currentBillingMonth.equals(outwardBillingMonth)) {
					sectionDetail.setMandatoryFromPeriod(sectionDetail.getMandatoryFromPeriod());
	
				}
			}
	
			else if (outwardBillingMonth.after(currentBillingMonth)) {
				throw new BusinessException("Entered currentBillingMonth should not be greater than outwardBillingMonth");
			}
		}
	}

	private void validateNonMandatoryfromPeriod(SectionDetail sectionDetail) {

		String nonMandatoryField = null;
		Integer billingPeriod = null;
		String[] billingMonthPeriod = null;
		Date outwardBillingMonth = null;
		Date currentBillingMonth = null;

		if (!OptionalUtil.getValue(sectionDetail.getNonMandatoryFromPeriod()).isEmpty()) {
			validateBillingMonthAndBillingPeriod(OptionalUtil.getValue(sectionDetail.getNonMandatoryFromPeriod()));

			nonMandatoryField = OptionalUtil.getValue(sectionDetail.getNonMandatoryFromPeriod());
			billingMonthPeriod = nonMandatoryField.split("/");
			billingPeriod = Integer.parseInt(billingMonthPeriod[1]);
	
			OutwardBillingPeriods outwardBillingPeriods = masterFeignClient.getCurrentOpenOutwardBillingPeriods();
	
			if ((billingPeriod < outwardBillingPeriods.getBillingPeriod()))
				throw new BusinessException(
						"Entered nonMandatoryBillingPeriod should not be lesser than outwardBillingPeriod");
	
			if (billingPeriod >= outwardBillingPeriods.getBillingPeriod()) {
				sectionDetail.setNonMandatoryFromPeriod(sectionDetail.getNonMandatoryFromPeriod());
			}
			if (OptionalUtil.getValue(sectionDetail.getApplicability()).equals("M")) {
				sectionDetail.setNonMandatoryFromPeriod(sectionDetail.getNonMandatoryFromPeriod());
			}
	
			try {
				outwardBillingMonth = new SimpleDateFormat(BILLINGMONTH).parse(outwardBillingPeriods.getBillingMonth());
			} catch (ParseException e) {
				throw new BusinessException(BILLINGMONTHFORMAT);
			}
	
			try {
				currentBillingMonth = new SimpleDateFormat(BILLINGMONTH).parse(billingMonthPeriod[0]);
			} catch (ParseException e) {
				throw new BusinessException(BILLINGMONTHFORMAT);
			}
	
			if (currentBillingMonth.before(outwardBillingMonth)) {
				if (currentBillingMonth.equals(outwardBillingMonth)) {
					sectionDetail.setNonMandatoryFromPeriod(sectionDetail.getNonMandatoryFromPeriod());
				}
			} else if (currentBillingMonth.after(outwardBillingMonth)) {
				throw new BusinessException("Entered currentBillingMonth should not be greater than outwardBillingMonth");
			}
		}
	}

	private void validateBillingMonthAndBillingPeriod(String mandatoryField) {
		if (Stream.of(MONTH.values()).map(MONTH::name).collect(Collectors.toList())
				.contains(mandatoryField.substring(0, 3).toUpperCase())) {
			if (!Pattern.compile("[A-Z]{3}-[0-9]{2}/[0][1-4]$").matcher(mandatoryField).find()) {
				throw new BusinessException("Please enter valid billing period:" + mandatoryField);
			}
		} else {
			throw new BusinessException("Please enter a valid month : [" + mandatoryField.substring(0, 3) + "]");
		}

	}
	
	@Override
	public List<SectionDetail> getListOfSectionDetailsByChargeCode(String chargeCode, Optional<String> sectionElementName, Optional<Boolean> activate) {
		List<SectionDetail> secDtlList = new ArrayList<>();
		List<Section> sectionList = sectionService.getAllSection(Optional.of(chargeCode) , null , null , Optional.of(true));
		if(CollectionUtils.isEmpty(sectionList)) {
			return secDtlList;
		} else {
			List<Integer> sections = sectionList.stream().map(section ->{
				if(chargeCode.equalsIgnoreCase(section.getChargeCode().get())) {
					return section.getSectionMasterId();
				}
				return null;
			}).collect(Collectors.toList());
			return sectionDetailMapper
				.mapToModel(sectionDetailDao.getListOfSectionDetailsByChargeCode(sections, sectionElementName, activate));
		}
	}
	
}