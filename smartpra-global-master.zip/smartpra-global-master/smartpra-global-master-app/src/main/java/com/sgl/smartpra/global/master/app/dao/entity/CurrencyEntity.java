package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicUpdate
@DynamicInsert
@Table(name = "global_mas_currency")
public class CurrencyEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "currency_code", unique = true, nullable = false, length = 3)
	private String currencyCode;

	@Column(name = "currency_name", nullable = false, length = 50)
	private String currencyName;

	@Column(name = "currency_numeric_code", nullable = false, length = 3)
	private int currencyNumericCode;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean isActive;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
