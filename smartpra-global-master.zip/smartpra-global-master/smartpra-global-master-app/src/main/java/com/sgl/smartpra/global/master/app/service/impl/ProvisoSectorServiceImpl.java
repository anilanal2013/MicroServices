package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ProvisoSectorDao;
import com.sgl.smartpra.global.master.app.mapper.ProvisoSectorCombinedMapper;
import com.sgl.smartpra.global.master.app.mapper.ProvisoSectorMapper;
import com.sgl.smartpra.global.master.app.service.ProvisoSectorService;
import com.sgl.smartpra.global.master.model.ProvisoSectorModel;
import com.sgl.smartpra.global.master.model.ProvisoSectorStgModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoSectorServiceImpl implements ProvisoSectorService {
	@Autowired
	private ProvisoSectorDao provisoSectorDao;
	@Autowired
	private ProvisoSectorMapper provisoSectorMapper;
	@Autowired
	private ProvisoSectorCombinedMapper provisoSectorCombinedMapper;
	private static final String SECTOR_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso Sector data not available for selected Proviso Main record";

	@Override
	public List<ProvisoSectorModel> getProvisoSectorByProvisoMainId(Optional<Integer> provisoMainId) {

		List<Integer> provisoMainIdFromDb = provisoSectorDao.getListOfProvisoMainIdFromSectorDb();
		if (!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))) {
			throw new BusinessException(SECTOR_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		return provisoSectorMapper.mapToModel(provisoSectorDao.findByMainId(provisoMainId));
	}

	@Override
	public ProvisoSectorModel getProvisoSectorByProvisioSectorId(Integer provisoSectorId) {

		return provisoSectorMapper.mapToModel(provisoSectorDao.findById(provisoSectorId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoSectorId))));
	}

	@Override
	public List<ProvisoSectorModel> searchByProvisoInMain(Optional<Integer> provisoMainId, Optional<String> areaFrom) {

		return provisoSectorMapper.mapToModel(provisoSectorDao.searchByProvisoInMain(provisoMainId, areaFrom));
	}

	@Override
	public List<ProvisoSectorModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber) {

		return provisoSectorMapper.mapToModel(provisoSectorDao.search(carrierNumCode, provisoSeqNumber));
	}

	@Override
	public List<ProvisoSectorModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> sectionRecNumber) {
		return provisoSectorMapper
				.mapToModel(provisoSectorDao.search(carrierNumCode, provisoSeqNumber, sectionRecNumber));
	}

	@Override
	public ProvisoSectorStgModel saveProvisoSector(ProvisoSectorStgModel provisoSectorStgModel) {
		provisoSectorStgModel.setCreatedDate(LocalDateTime.now());
		return provisoSectorCombinedMapper
				.mapToModel(provisoSectorDao.create(provisoSectorCombinedMapper.mapToEntity(provisoSectorStgModel)));

	}
}
