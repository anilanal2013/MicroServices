package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.ProvisoRoutingStgService;
import com.sgl.smartpra.global.master.model.ProvisoRoutingStg;

@RestController
@RequestMapping("/proviso/routing/stg")
public class ProvisoRoutingStgController {

	@Autowired
	private ProvisoRoutingStgService provisoRoutingStgService;

	@PostMapping("/{provisoMainId}/proviso-routing")
	@ResponseStatus(value = HttpStatus.CREATED)
	public ProvisoRoutingStg createProvisoRouting(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@Validated(Create.class) @RequestBody ProvisoRoutingStg provisoRoutingStg) {
		provisoRoutingStg.setProvisoMainId(provisoMainId);
		return provisoRoutingStgService.createProvisoRouting(provisoRoutingStg);
	}

	@GetMapping("provisoMain/{provisoMainId}")
	public List<ProvisoRoutingStg> getProvisoRoutingByProvisoMainId(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId) {
		return provisoRoutingStgService.getProvisoRoutingByProvisoMainId(provisoMainId);
	}

	@GetMapping("/{provisoRoutingId}")
	public ProvisoRoutingStg getProvisoRoutingByProvisoRoutingId(
			@PathVariable(value = "provisoRoutingId") Integer provisoRoutingId) {
		return provisoRoutingStgService.getProvisoRoutingByProvisoRoutingId(provisoRoutingId);
	}

	@GetMapping("/proviso-routing/{carrierNumCode}/{provisoSeqNumber}/{detailRecNumber}")
	public List<ProvisoRoutingStg> searchByProvisoRouting(
			@PathVariable(value = "carrierNumCode", required = false) Optional<String> carrierNumCode,
			@PathVariable(value = "provisoSeqNumber", required = false) Optional<Integer> provisoSeqNumber,
			@PathVariable(value = "detailRecNumber", required = false) Optional<Integer> detailRecNumber) {
		return provisoRoutingStgService.search(carrierNumCode, provisoSeqNumber, detailRecNumber);
	}

	@PutMapping("/{provisoMainId}/{provisoRoutingId}")
	@ResponseStatus(value = HttpStatus.OK)
	public ProvisoRoutingStg updateProvisoRouting(
			@PathVariable(value = "provisoMainId") Optional<Integer> provisoMainId,
			@PathVariable(value = "provisoRoutingId") Integer provisoRoutingId,
			@Validated(Update.class) @RequestBody ProvisoRoutingStg provisoRoutingStg) {
		provisoRoutingStg.setProvisoMainId(provisoMainId);
		return provisoRoutingStgService.updateProvisoRouting(provisoRoutingId, provisoRoutingStg);
	}
	
	@DeleteMapping("/provisoRoutingDeletedById/{provisoRoutingId}")
	public void deleteProvisoRoutingMasterStg(@PathVariable(value = "provisoRoutingId") Integer provisoRoutingId) {
		provisoRoutingStgService.deleteProvisoRoutingByProvisoRoutingId(provisoRoutingId);
	}	
}
