package com.sgl.smartpra.global.master.app.dao.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "global_mas_misc_chrge_category")
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
@Data
public class ChargeCategoryEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "charge_cat_code", nullable = false, length = 3)
	private String chargeCategoryCode;

	@Column(name = "charge_cat_name", nullable = false, length = 30)
	private String chargeCategoryName;

	@Column(name = "financial_trn_type", nullable = false, length = 3)
	private String financialTransactionType = "INV";

	@Column(name = "location_req_ind", nullable = false)
	private Boolean locationRequiredIndicator = Boolean.FALSE;

	@Column(name = "po_req_ind", length = 1)
	private Boolean poNumberRequiredIndicator = Boolean.TRUE;

	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "attribute_1")
	private String attribute1;

	@Column(name = "attribute_2")
	private String attribute2;

	@Column(name = "profit_centre")
	private String profitCentre;

	@Column(name = "cost_center_code")
	private String costCenterCode;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
		setCreatedDate(LocalDateTime.now());
		setActivate(Boolean.TRUE);
	}
}