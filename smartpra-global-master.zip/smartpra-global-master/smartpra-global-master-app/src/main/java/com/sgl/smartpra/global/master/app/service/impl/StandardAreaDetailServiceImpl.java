package com.sgl.smartpra.global.master.app.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.SearchCriteria;
import com.sgl.smartpra.global.master.app.dao.StandardAreaDetailDao;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.StandardAreaDetailMapper;
import com.sgl.smartpra.global.master.app.repository.StandardAreaDetailRepository;
import com.sgl.smartpra.global.master.app.repository.entity.StandardAreaDetailEntity;
import com.sgl.smartpra.global.master.app.service.AirportService;
import com.sgl.smartpra.global.master.app.service.CountryService;
import com.sgl.smartpra.global.master.app.service.StandardAreaDetailService;
import com.sgl.smartpra.global.master.app.service.StandardAreaGeographyTypeService;
import com.sgl.smartpra.global.master.app.service.StandardAreaSrevice;
import com.sgl.smartpra.global.master.model.GeographyType;
import com.sgl.smartpra.global.master.model.StandardAreaDetail;

@Service
@Transactional
public class StandardAreaDetailServiceImpl implements StandardAreaDetailService {
	@Autowired
	StandardAreaDetailMapper standardAreaDetailmapper;

	@Autowired
	private StandardAreaDetailRepository standardAreaDetailRepository;

	@Autowired
	private StandardAreaGeographyTypeService standardAreaGeographyTypeService;

	@Autowired
	private StandardAreaSrevice standardAreaSrevice;

	@Autowired
	private AirportService airportService;

	@Autowired
	private CountryService countryService;

	@Autowired
	private StandardAreaDetailDao standardAreaDetailDao;

	private String doesNotExist = " does not exist";
	private String isNotActive = " is not active";

	@Override
	public List<StandardAreaDetail> getListOfStandardAreaDetails(String standardAreaCode) {
		List<SearchCriteria> params = new ArrayList<>();

		// fetch only active records

		if (standardAreaCode != null && standardAreaCode.length() > 0) {
			params.add(new SearchCriteria("standardAreaCode", "=", standardAreaCode));
		}
		return standardAreaDetailmapper
				.mapToStandardAreaDetailModelList(standardAreaDetailDao.search(params, new StandardAreaDetailEntity()));
	}

	@Override
	public StandardAreaDetail getStandardAreaDetailByStandardAreaDetailCode(String standardAreaCode,
			Integer standardAreaDetailId) {

		Optional<StandardAreaDetailEntity> standardAreaDetailEntity = standardAreaDetailRepository
				.findById(standardAreaDetailId);

		if (!standardAreaDetailEntity.isPresent())
			throw new ResourceNotFoundException("standardAreaDetail", "Id", standardAreaDetailId);

		if (!standardAreaDetailEntity.get().getStandardAreaCode().equals(standardAreaCode)) {
			throw new ServiceException("Standard Area Code:" + standardAreaCode
					+ " missmatch with given standardAreaDetailId  " + standardAreaDetailId);
		}

		return standardAreaDetailmapper.mapToStandardAreaDetailModel(standardAreaDetailEntity.get());

	}

	@Override
	public StandardAreaDetail createStandardAreaDetail(String standardAreaCode, StandardAreaDetail standardAreaDetail) {
		GeographyType geographyType = null;
		try {
			if(!standardAreaSrevice.getActiveStandardAreaByStandardAreaCode(standardAreaCode)) {
				throw new ServiceException("Invalid Standard Area Code : "
						+ standardAreaDetail.getStandardAreaCode());
			}
		} catch (ResourceNotFoundException rnfe) {
			throw new ServiceException("Invalid Standard Area Code. Standard Area Code : "
					+ standardAreaDetail.getStandardAreaCode() + doesNotExist);
		} catch (ServiceException se) {
			throw new ServiceException("Invalid Standard Area Code. Standard Area Code :"
					+ standardAreaDetail.getStandardAreaCode() + isNotActive);
		}

		try {
			geographyType = standardAreaGeographyTypeService.getStandardAreaGeographyTypeByStandardAreaGeographyTypeId(
					standardAreaDetail.getGeographicalTypeId());
		} catch (ResourceNotFoundException rnfe) {
			throw new ServiceException("Invalid Standard Area Geography ID. Standard Area Geography ID : "
					+ standardAreaDetail.getGeographicalTypeId() + doesNotExist);
		} catch (ServiceException se) {
			throw new ServiceException("Invalid Standard Area Geography ID. Standard Area Geography ID"
					+ standardAreaDetail.getGeographicalTypeId() + isNotActive);
		}

		if (geographyType.getGeoType().equals("City")) {
			if (!airportService.isValidAirportCodeOrCityCode(standardAreaDetail.getStandardAreaValue())) {
				throw new ServiceException("Invalid Standard Area Value. Airport/City Code : "
						+ standardAreaDetail.getStandardAreaValue() + "Does not exist or not active");
			}

		} else if (geographyType.getGeoType().equals("Country")) {
			try {
				if (!airportService.isValidStateCode(standardAreaDetail.getStandardAreaValue()))
					countryService.getCountryByCountryCode(standardAreaDetail.getStandardAreaValue());
			} catch (ResourceNotFoundException rnfe) {
				throw new ServiceException("Invalid Standard Area Geography ID. Country / State Code : "
						+ standardAreaDetail.getStandardAreaValue() + doesNotExist);
			} catch (ServiceException se) {
				throw new ServiceException("Invalid Standard Area Geography ID. Country / State Code :"
						+ standardAreaDetail.getStandardAreaValue() + isNotActive);
			}

		}

		standardAreaDetail.setStandardAreaCode(standardAreaCode);
		standardAreaDetail.setCreatedDate(new Timestamp(new Date().getTime()));

		return standardAreaDetailmapper.mapToStandardAreaDetailModel(standardAreaDetailRepository
				.save(standardAreaDetailmapper.mapToStandardAreaDetailEntity(standardAreaDetail)));
	}

	@Override
	public StandardAreaDetail updateStandardAreaDetail(String standardAreaCode, Integer standardAreaDetailId,
			StandardAreaDetail standardAreaDetail) {

		GeographyType geographyType = null;

		Optional<StandardAreaDetailEntity> standardAreaDetailEntity = standardAreaDetailRepository
				.findById(standardAreaDetailId);

		if (!standardAreaDetailEntity.isPresent()) {
			throw new ResourceNotFoundException("standardAreadetail", "detail", standardAreaDetailId);
		}

		if (standardAreaDetailEntity.get().getStandardAreaCode().equals(standardAreaCode)) {

			try {
				if(!standardAreaSrevice.getActiveStandardAreaByStandardAreaCode(standardAreaCode)) {
					throw new ServiceException("Invalid Standard Area Code : "
							+ standardAreaDetail.getStandardAreaCode());
				}
			} catch (ResourceNotFoundException rnfe) {
				throw new ServiceException("Invalid Standard Area Code. Standard Area Code : "
						+ standardAreaDetail.getStandardAreaCode() + doesNotExist);
			} catch (ServiceException se) {
				throw new ServiceException("Invalid Standard Area Code. Standard Area Code :"
						+ standardAreaDetail.getStandardAreaCode() + isNotActive);
			}

			try {
				geographyType = standardAreaGeographyTypeService
						.getStandardAreaGeographyTypeByStandardAreaGeographyTypeId(
								standardAreaDetail.getGeographicalTypeId());
			} catch (ResourceNotFoundException rnfe) {
				throw new ServiceException("Invalid Standard Area Geography ID. Standard Area Geography ID : "
						+ standardAreaDetail.getGeographicalTypeId() + doesNotExist);
			} catch (ServiceException se) {
				throw new ServiceException("Invalid Standard Area Geography ID. Standard Area Geography ID "
						+ standardAreaDetail.getGeographicalTypeId() + isNotActive);
			}

			if (geographyType.getGeoType().equals("City")) {
				if (!airportService.isValidAirportCodeOrCityCode(standardAreaDetail.getStandardAreaValue())) {
					throw new ServiceException("Invalid Standard Area Value. Airport/City Code : "
							+ standardAreaDetail.getStandardAreaValue() + "Does not exist or not active");
				}

			} else if (geographyType.getGeoType().equals("Country")) {
				try {
					if (!airportService.isValidStateCode(standardAreaDetail.getStandardAreaValue()))
						countryService.getCountryByCountryCode(standardAreaDetail.getStandardAreaValue());
				} catch (ResourceNotFoundException rnfe) {
					throw new ServiceException("Invalid Standard Area Geography ID. Country / State Code : "
							+ standardAreaDetail.getStandardAreaValue() + doesNotExist);
				} catch (ServiceException se) {
					throw new ServiceException("Invalid Standard Area Geography ID. Country / State Code :"
							+ standardAreaDetail.getStandardAreaValue() + isNotActive);
				}

			}

			standardAreaDetail.setStandardAreaCode(standardAreaCode);
			standardAreaDetail.setStandardAreaDetailId(standardAreaDetailId);
			standardAreaDetailEntity.get().setStandardAreaCode(standardAreaDetail.getStandardAreaCode());
			standardAreaDetailEntity.get().setStandardAreaDetailId(standardAreaDetail.getStandardAreaDetailId());
			standardAreaDetailEntity.get().setStandardAreaValue(standardAreaDetail.getStandardAreaValue());
			standardAreaDetailEntity.get().setGeographicalTypeId(standardAreaDetail.getGeographicalTypeId());
			standardAreaDetailEntity.get().setLastUpdatedBy(standardAreaDetail.getLastUpdatedBy());
			standardAreaDetailEntity.get().setLastUpdatedDate(new Timestamp(new Date().getTime()));

		} else {
			throw new ServiceException("Standard Area Code: " + standardAreaCode
					+ " is missmatch to the given standardAreaDetailId :" + standardAreaDetailId);
		}

		return standardAreaDetailmapper
				.mapToStandardAreaDetailModel(standardAreaDetailRepository.save(standardAreaDetailEntity.get()));
	}

	@Override
	public void deleteStandardAreaDetail(String standardAreaCode, Integer standardAreaDetailId) {

		Optional<StandardAreaDetailEntity> standardAreaDetailEntity = standardAreaDetailRepository
				.findById(standardAreaDetailId);

		if (!standardAreaDetailEntity.isPresent()) {
			throw new ResourceNotFoundException("standardAreaDetail", "detail", standardAreaDetailId);
		}

		if (!standardAreaDetailEntity.get().getStandardAreaCode().equals(standardAreaCode)) {
			throw new ServiceException("Standard Area Code:" + standardAreaCode
					+ " missmatch with given standardAreaDetailId  " + standardAreaDetailId + "record");
		}

		standardAreaDetailRepository.delete(standardAreaDetailEntity.get());
	}

}
