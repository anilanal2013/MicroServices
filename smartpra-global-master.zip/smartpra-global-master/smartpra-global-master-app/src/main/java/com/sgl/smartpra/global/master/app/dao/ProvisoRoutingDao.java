package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoRoutingEntity;
@Repository
public interface ProvisoRoutingDao {

	List<ProvisoRoutingEntity> findByMainId(Optional<Integer> provisoMainId);

	Optional<ProvisoRoutingEntity> findById(Integer id);

	public List<ProvisoRoutingEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> detailRecNumber);

	ProvisoRoutingEntity create(ProvisoRoutingEntity provisoRoutingEntity);

	public List<Integer> getListOfProvisoMainIdFromRoutingDb();
}
