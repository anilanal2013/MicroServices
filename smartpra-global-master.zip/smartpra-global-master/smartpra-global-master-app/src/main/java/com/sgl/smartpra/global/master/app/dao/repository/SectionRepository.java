package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.SectionEntity;
import com.sgl.smartpra.global.master.model.SectionDto;

@Repository
public interface SectionRepository
		extends JpaRepository<SectionEntity, Integer>, JpaSpecificationExecutor<SectionEntity> {

	@Query(" SELECT new com.sgl.smartpra.global.master.model.SectionDto(s.sectionMasterId, s.sectionNameActual, s.chargeCode, d.sectionElementNameActual, d.displayIndicator, d.applicability, d.mandatoryFromPeriod, d.nonMandatoryFromPeriod) "
			+ " FROM SectionEntity s, SectionDetailEntity d where s.chargeCode = :chargeCode "
			+ " AND d.displayIndicator = 'Y' and d.applicability = 'M' " 
			+ " AND ( "
			+ "	   (d.applicability = 'M') and (d.nonMandatoryFromPeriod is null or d.nonMandatoryFromPeriod = '')"
			+ "	OR (d.applicability <> 'M' and d.mandatoryFromPeriod <= :currentBillingPeriod))"
			+ " AND s.sectionMasterId = d.sectionMasterId ")
	List<SectionDto> fetchSectionByChargeCode(@Param("chargeCode") String chargeCode, @Param("currentBillingPeriod") String currentBillingPeriod);
}
