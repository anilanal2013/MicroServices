package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.global.master.model.InvolIndicator;
import com.sgl.smartpra.global.master.model.InvolIndicatorResponse;

public interface InvolIndicatorService {

	List<InvolIndicator> getListOfAllInvol(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<String> indicatorType, Optional<String> ticketField, Optional<Boolean> activate);

	List<InvolIndicator> getListOfInvolIndicator(Optional<String> effectiveDate, Optional<String> indicatorType);

	InvolIndicator getInvolIndicatorByInvolIndicatorId(int involIndicatorId);

	InvolIndicator createInvolIndicator(InvolIndicator involIndicator);

	InvolIndicator updateInvolIndicator(int involIndicatorId, InvolIndicator involIndicator);

	void deactivateInvolIndicator(@Valid int involIndicatorId, String lastUpdatedBy);

	void activateInvolIndicator(@Valid int involIndicatorId, String lastUpdatedBy);

	List<InvolIndicator> validateDate(Optional<String> effectiveDate);

	InvolIndicatorResponse getListOfAllInvol(Pageable pageable, InvolIndicator involIndicator);
}
