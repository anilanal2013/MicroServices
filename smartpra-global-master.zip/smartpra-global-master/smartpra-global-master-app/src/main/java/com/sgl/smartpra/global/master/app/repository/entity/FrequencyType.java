package com.sgl.smartpra.global.master.app.repository.entity;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "global_mas_frequency_type")
public class FrequencyType extends AbstractAuditingEntity implements Serializable  {

    private static final long serialVersionUID = 1L;
    
	@Id
	@Column(name = "frequency_type_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long frequencyTypeId;

    @NotNull
    @Column(name = "frequency_type_name", nullable = false)
    private String frequencyTypeName;

    @NotNull
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;
   


    public Long getFrequencyTypeId() {
		return frequencyTypeId;
	}

	public void setFrequencyTypeId(Long frequencyTypeId) {
		this.frequencyTypeId = frequencyTypeId;
	}

	public String getFrequencyTypeName() {
		return frequencyTypeName;
	}

	public void setFrequencyTypeName(String frequencyTypeName) {
		this.frequencyTypeName = frequencyTypeName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        FrequencyType frequencyType = (FrequencyType) o;
        if (frequencyType.getFrequencyTypeId() == null || getFrequencyTypeId() == null) {
            return false;
        }
        return Objects.equals(getFrequencyTypeId(), frequencyType.getFrequencyTypeId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getFrequencyTypeId());
    }

    @Override
    public String toString() {
        return "FrequencyType{" +
            "id=" + getFrequencyTypeId() +
            ", frequecncyTypeName='" + getFrequencyTypeName() + "'" +
            ", isActive='" + getIsActive() + "'" +
            "}";
    }
}
