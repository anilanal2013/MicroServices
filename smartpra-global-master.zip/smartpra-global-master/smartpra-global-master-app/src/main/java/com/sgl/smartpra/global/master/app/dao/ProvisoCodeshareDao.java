package com.sgl.smartpra.global.master.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareEntity;
@Repository
public interface ProvisoCodeshareDao {
	
	List<ProvisoCodeshareEntity> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> provisoSection, Optional<String> areaFrom, Optional<String> areaTo);

	List<ProvisoCodeshareEntity> searchByProvisoMain(Optional<Integer> provisoMainId, Optional<String> areaFrom,
			Optional<String> areaTo);

	Optional<ProvisoCodeshareEntity> findById(Integer provisioCodeshareId);
	
	public ProvisoCodeshareEntity create(ProvisoCodeshareEntity provisoCodeshareEntity);

	List<ProvisoCodeshareEntity> findByMainId(Optional<Integer> provisoMainId);
	
	public List<Integer> getListOfProvisoMainIdFromRoutingDb();
}
