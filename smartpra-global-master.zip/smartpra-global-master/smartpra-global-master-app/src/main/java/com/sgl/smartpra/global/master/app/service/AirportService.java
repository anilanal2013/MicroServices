package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;

import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.AirportResponse;
import com.sgl.smartpra.global.master.model.CommonIdName;

public interface AirportService {

	public List<Airport> getAllAirport(Optional<String> airportCode, Optional<String> airportName, Optional<String> cityCode, Optional<String> cityName,
			Optional<String> countryCode);

	public Airport findAirportByAirportCode(String airportCode);

	public Airport createAirport(Airport airport);

	public Airport updateAirport(Airport airport);

	public void deactivateAirport(String airportCode, String lastUpdatedBy);

	public void activateAirport(String airportCode, String lastUpdatedBy);

	public boolean isValidAirportCodeOrCityCode(String standardAreaValue);

	public boolean isValidStateCode(String stateCode);
	
	public boolean isValidCityCode(String stateCode);
	
	public boolean isValidAirportCode(String airportCode);

	public List<Airport> findCityByAirportCode(String airportCode);
	
	public List<CommonIdName> getAirportList();
	
	public List<CommonIdName> getCityList();
	
	public List<CommonIdName> getStateList();
	
	public AirportResponse findAll(Airport airport,Optional<String> exceptionCall,Pageable pageable);
	
	public String findCountryCodeByAirportCodeOrCityCode(String airportCode);
	
	public List<Airport> getAirportByCityOrStateOrCountry(Optional<String> airportCode, Optional<String> stateCode, Optional<String> cityCode,
			Optional<String> countryCode);

	public String getTicketTravelDetail(List<String> airportCodes);

}
