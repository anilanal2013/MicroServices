package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.CurrencyService;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.global.master.model.Currency;

@RestController

public class CurrencyController {

	@Autowired
	CurrencyService currencyService;

	@GetMapping("/currencies")
	public List<Currency> getAllcurrencies(@RequestParam(value = "currencyCode", required = false) String currencyCode,
			@RequestParam(value = "currencyName", required = false) String currencyName,
			@RequestParam(value = "isActive", required = false) Boolean isActive) {
		return currencyService.getAllCurrency(currencyCode, currencyName, isActive);
	}

	@GetMapping("/currencies/{currencyCode}")
	public Currency getCurrencyByCurrencyCode(@PathVariable(value = "currencyCode") String currencyCode) {
		return currencyService.findCurrencyByCurrencyCode(currencyCode);
	}
	
	@GetMapping("/currencies/active-currencyNumericCode")
	public Currency getActiveCurrencyByCurrencyNumericCode(
			@RequestParam(value = "currencyNumericCode", required = true) Integer currencyNumericCode) {
		return currencyService.getCurrencyByCurrencyNumericCode(currencyNumericCode);
	}

	@PostMapping("/currencies")
	@ResponseStatus(value = HttpStatus.CREATED)
	public Currency createCurrency(@Validated(Create.class) @RequestBody Currency currency) {
		return currencyService.createCurrency(currency);
	}

	@PutMapping("/currencies/{currencyCode}")
	@ResponseStatus(value = HttpStatus.CREATED)
	public Currency updateCurrency(@PathVariable(value = "currencyCode") String currencyCode,
			@Validated(Update.class) @RequestBody Currency currency) {
		currency.setCurrencyCode(Optional.of(currencyCode));
		return currencyService.updateCurrency(currencyCode, currency);
	}

	@PutMapping("/currencies/{currencyCode}/deactivate")
	public void deactivateCurrency(@Valid @PathVariable(value = "currencyCode") String currencyCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		currencyService.deactivateCurrency(currencyCode, lastUpdatedBy);

	}

	@PutMapping("/currencies/{currencyCode}/activate")
	public void activateCurrency(@Valid @PathVariable(value = "currencyCode") String currencyCode,
			@RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {
		currencyService.activateCurrency(currencyCode, lastUpdatedBy);

	}

	@GetMapping("/currencies/{currencyCode}/validate")
	public boolean validateCurrencyCode(@PathVariable(value = "currencyCode") String currencyCode) {
		return currencyService.isValidCurrencyCode(currencyCode);
	}
	
	@PostMapping("/currencies/validate")
	public List<String> validateCurrencyCodeList(@RequestBody List<String> currencyCodeList){
		return currencyService.getValidCurrencyCode(currencyCodeList);
	}
	
	@GetMapping("/currencies/currency-list")
	public List<CommonIdName> getCurrencyList() {
		return currencyService.getCurrencyList();
	}
 }
