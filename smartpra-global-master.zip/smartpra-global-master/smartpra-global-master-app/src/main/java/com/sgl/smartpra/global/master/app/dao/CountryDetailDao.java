package com.sgl.smartpra.global.master.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.app.dao.entity.CountryDetailEntity;

public interface CountryDetailDao {

	CountryDetailEntity create(CountryDetailEntity countryDetailEntity);

	CountryDetailEntity update(CountryDetailEntity countryDetailEntity);

	List<CountryDetailEntity> findAll();

	List<CountryDetailEntity> getAllCountryEntityByEffectiveDate(Optional<String> countryCode,
			Optional<String> effectiveDate);
	
	List<CountryDetailEntity> findByCountryCode(Optional<String> countryCode);

	Optional<CountryDetailEntity> findById(Integer currencyDetailId);

	void delete(Integer id);
	
	public long getOverLapRecordCount(LocalDate effectiveFromDate, LocalDate effectiveToDate, String countryCode);
	
	public long getOverLapRecordCountForUpdate(LocalDate effectiveFromDate, LocalDate effectiveToDate, String countryCode, Integer countryDtlId);

	List<CountryDetailEntity> findByCountryCode(String countryCode);

	List<CountryDetailEntity> createAll(List<CountryDetailEntity> countryDetailEntity);

	CountryDetailEntity getCountryDetailsByEffectiveDate(String countryCode, Optional<String> issueDate);

}
