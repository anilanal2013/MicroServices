package com.sgl.smartpra.global.master.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.SectionDetailService;
import com.sgl.smartpra.global.master.model.SectionDetail;

@RestController
public class SectionDetailController {

	@Autowired
	SectionDetailService sectionDetailService;

	@GetMapping("/sections/{sectionMasterId}/details/{sectionDetailId}")
	public SectionDetail getSectionDetailBySectionDetailId(
			@PathVariable(value = "sectionMasterId") Integer sectionMasterId,
			@PathVariable(value = "sectionDetailId") Integer sectionDetailId) {
		return sectionDetailService.findSectionDetailBySectionDetailId(sectionMasterId, sectionDetailId);
	}

	@GetMapping("/sections/{sectionMasterId}/details")
	public List<SectionDetail> getListOfSectionDetails(@PathVariable(value = "sectionMasterId") Integer sectionMasterId,
			@RequestParam(value = "sectionDetailId", required = false) Integer sectionDetailId,
			@RequestParam(value = "sectionElementName", required = false) Optional<String> sectionElementName, 
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return sectionDetailService.getAllSectionDetails(sectionMasterId,sectionDetailId,sectionElementName,activate);
	}

	@PostMapping("/sections/{sectionMasterId}/details")
	public SectionDetail createSectionDetail(@PathVariable(value = "sectionMasterId") Integer sectionMasterId,
			@Validated(Create.class) @RequestBody SectionDetail sectionDetail) {
		return sectionDetailService.createSectionDetail(sectionMasterId, sectionDetail);
	}

	@PutMapping("/update-sections-details")
	public List<SectionDetail> updateSectionDetail(@Validated(Update.class) @RequestBody List<SectionDetail> sectionDetails) {
		return sectionDetailService.updateSectionDetail(sectionDetails);
	}

	@PutMapping("/sections/{sectionMasterId}/details/{sectionDetailId}/deactivate")
	public void deactivateSection(@Valid @PathVariable(value = "sectionMasterId") Integer secionMasterId,
			@Valid @PathVariable(value = "sectionDetailId") Integer sectionDetailId,
			@Validated(Update.class) @RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {

		sectionDetailService.deactivateSection(secionMasterId, sectionDetailId, lastUpdatedBy);
	}

	@PutMapping("/sections/{sectionMasterId}/details/{sectionDetailId}/activate")
	public void activateSection(@Valid @PathVariable(value = "sectionMasterId") Integer secionMasterId,
			@Valid @PathVariable(value = "sectionDetailId") Integer sectionDetailId,
			@Validated(Update.class) @RequestParam(value = "lastUpdatedBy", required = true) String lastUpdatedBy) {

		sectionDetailService.activateSection(secionMasterId, sectionDetailId, lastUpdatedBy);
	}
	
	@GetMapping("/sections/details/{chargeCode}")
	public List<SectionDetail> getListOfSectionDetailsByChargeCode(@PathVariable(value = "chargeCode") String chargeCode,
			@RequestParam(value = "sectionElementName", required = false) Optional<String> sectionElementName, 
			@RequestParam(value = "activate", required = false) Optional<Boolean> activate) {
		return sectionDetailService.getListOfSectionDetailsByChargeCode(chargeCode, sectionElementName, activate);
	}
}