package com.sgl.smartpra.global.master.app.service.impl;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ChargeCodeTypeDao;
import com.sgl.smartpra.global.master.app.dao.entity.ChargeCodeTypeEntity;
import com.sgl.smartpra.global.master.app.mapper.ChargeCodeTypeMapper;
import com.sgl.smartpra.global.master.app.service.ChargeCodeTypeService;
import com.sgl.smartpra.global.master.model.ChargeCodeType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Transactional
public class ChargeCodeTypeServiceImpl implements ChargeCodeTypeService{

	@Autowired
	ChargeCodeTypeMapper chargeCodeTypemapper;
	
	@Autowired
	ChargeCodeTypeDao chargeCodeTypeDao;
	
	
	
	@Override
	public List<ChargeCodeType> getAllChargeCodeTypeByCodeandCat(Optional<String> chargeCode,
			Optional<String> chargeCatCode) {
		return chargeCodeTypemapper.mapToModel(chargeCodeTypeDao.findAll(chargeCatCode, chargeCode));
	}
	
	@Override
	public ChargeCodeType getChargeCodeById(Integer id) {
		ChargeCodeTypeEntity entity =chargeCodeTypeDao.findById(id).orElseThrow(() -> new RecordNotFoundException(String.valueOf(id)));
		return chargeCodeTypemapper.mapToModel(entity);
	}

	@Override
	public ChargeCodeType getChargeCodeTypeByChargeCatAndChargeCodeAndChargeCodeType(
			Optional<String> chargeCodeCategory,Optional<String> chargeCode, Optional<String> chargeType) {
		List<ChargeCodeTypeEntity> al = chargeCodeTypeDao.findAll(chargeCodeCategory,chargeCode);
		ChargeCodeTypeEntity chargeCodeTypeEntity = al.stream().filter(Objects::nonNull).filter(w ->
				StringUtils.equalsIgnoreCase(w.getChargeCodeType(), StringUtils.trim(OptionalUtil.getValue(chargeType))))
				.findFirst().orElseThrow(() -> new RecordNotFoundException(String.valueOf(OptionalUtil.getValue(chargeType))));
		return chargeCodeTypemapper.mapToModel(chargeCodeTypeEntity);
	}
}
