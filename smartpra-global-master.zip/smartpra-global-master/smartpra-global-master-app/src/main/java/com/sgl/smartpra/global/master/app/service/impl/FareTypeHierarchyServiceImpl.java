package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.configuration.FeignConfiguration.YQYRGlobalMasterFeignClient;
import com.sgl.smartpra.global.master.app.dao.FareTypeHierarchyDao;
import com.sgl.smartpra.global.master.app.dao.entity.FareTypeHierarchyEntity;
import com.sgl.smartpra.global.master.app.mapper.FareTypeHierarchyMapper;
import com.sgl.smartpra.global.master.app.service.FBTDElementService;
import com.sgl.smartpra.global.master.app.service.FareTypeHierarchyService;
import com.sgl.smartpra.global.master.model.FareTypeHierarchy;

import lombok.extern.slf4j.Slf4j;

@Service(value = "FareTypeHierarchyService")
@Transactional
@Slf4j
public class FareTypeHierarchyServiceImpl implements FareTypeHierarchyService {

	@Autowired
	protected FareTypeHierarchyMapper fareTypeHierarchyMapper;

	@Autowired
	protected FareTypeHierarchyDao fareTypeHierarchyDao;

	@Autowired
	private YQYRGlobalMasterFeignClient yqyrGlobalMasterFeignClient;

	@Autowired
	private FBTDElementService fbtdElementService;

	protected static final String OVERLAP_COMBINATION_EXIST = "Record already exist";
	private static final String INACTIVE_FARE_TYPE_HIERARCHY = "Given Fare Type Hierarchy record is not active";
	private static final String ACTIVE_FARE_TYPE_HIERARCHY = "Given Fare Type Hierarchy record is already active";

	Boolean operationCheck = false;

	@Override
	public FareTypeHierarchy createFareTypeHierarchy(FareTypeHierarchy fareTypeHierarchy) {
		log.info("{}", fareTypeHierarchy);
		fareTypeHierarchy.setActivate(Boolean.TRUE);
		validateBusinessConstraints(fareTypeHierarchy);
		return fareTypeHierarchyMapper
				.mapToModel(fareTypeHierarchyDao.create(fareTypeHierarchyMapper.mapToEntity(fareTypeHierarchy)));
	}

	@Override
	public FareTypeHierarchy updateFareTypeHierarchy(FareTypeHierarchy fareTypeHierarchy) {
		log.info("{}", fareTypeHierarchy);
		FareTypeHierarchyEntity fareTypeHierarchyEntity = fareTypeHierarchyDao
				.findById(fareTypeHierarchy.getFareTypeHierarchyId()).orElseThrow(
						() -> new RecordNotFoundException(String.valueOf(fareTypeHierarchy.getFareTypeHierarchyId())));

		validateBusinessConstraints(fareTypeHierarchy, fareTypeHierarchyEntity);
		return fareTypeHierarchyMapper.mapToModel(fareTypeHierarchyDao
				.update(fareTypeHierarchyMapper.mapToEntity(fareTypeHierarchy, fareTypeHierarchyEntity)));
	}

	@Override
	public FareTypeHierarchy getFareTypeHierarchyByfareTypeHierarchyId(Integer fareTypeHierarchyId) {
		return fareTypeHierarchyMapper.mapToModel(fareTypeHierarchyDao.findById(fareTypeHierarchyId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(fareTypeHierarchyId))));
	}

	@Override
	public List<FareTypeHierarchy> getAllFareTypeHierarchy(String effectiveFromDate, String effectiveToDate,
			Integer cabinLevel, Integer fareTypeLevel) {
		return fareTypeHierarchyMapper.mapToModel(fareTypeHierarchyDao.getAllFareTypeHierarchy(
				Optional.ofNullable(effectiveFromDate), Optional.ofNullable(effectiveToDate),
				Optional.ofNullable(cabinLevel), Optional.ofNullable(fareTypeLevel)));
	}

	protected void validateEffectiveToDate(LocalDate effectiveToDate, LocalDate effectiveFromDate) {
		LocalDate currentDate = LocalDate.now();
		if (!effectiveToDate.isAfter(currentDate) && !effectiveToDate.isEqual(currentDate)) {
			throw new BusinessException("EffectiveToDate[" + effectiveToDate
					+ "]  should be greater than or equal to the current date[" + currentDate + "]");
		}
		if (!effectiveToDate.isAfter(effectiveFromDate)) {
			throw new BusinessException("EffectiveToDate[" + effectiveToDate
					+ "] should be greater than EffectiveFromDate[" + effectiveFromDate + "]");
		}
	}

	protected void validateAtpcoFareType(FareTypeHierarchy fareTypeHierarchy) {
		if (OptionalUtil.isPresent(fareTypeHierarchy.getFareTypeCode())) {
			String fareTypeCode = OptionalUtil.getValue(fareTypeHierarchy.getFareTypeCode());
			if (!yqyrGlobalMasterFeignClient.validateAtpcoFareType(fareTypeCode)) {
				throw new BusinessException("Fare Type[" + fareTypeCode + "] is not a valid ATPCO PAX-FareType");
			}
		}
	}

	protected void validateCabin(FareTypeHierarchy fareTypeHierarchy) {
		if (OptionalUtil.isPresent(fareTypeHierarchy.getCabin())) {
			String cabin = OptionalUtil.getValue(fareTypeHierarchy.getCabin());
			if (!fbtdElementService.validateCabin(cabin)) {
				throw new BusinessException("Fare Type[" + cabin + "] is not a valid cabin");
			}
		}
	}

	protected void validateCabinLevel(FareTypeHierarchy fareTypeHierarchy) {
		if (OptionalUtil.isPresent(fareTypeHierarchy.getCabinLevel())) {
			Integer cabinLevel = OptionalUtil.getValue(fareTypeHierarchy.getCabinLevel());
			if (!fbtdElementService.validateOtherInfo(cabinLevel.toString())) {
				throw new BusinessException("Cabin level[" + cabinLevel + "] is not a valid cabin level");
			}
		}
	}

	protected void validateFareTypeLevel(FareTypeHierarchy fareTypeHierarchy) {
		if (OptionalUtil.isPresent(fareTypeHierarchy.getFareTypeLevel())) {
			String fareTypeLevel = OptionalUtil.getValue(fareTypeHierarchy.getFareTypeLevel()).toString();
			operationCheck = Pattern.compile("^([1-9])$").matcher(fareTypeLevel).find();
			if (!operationCheck) {
				throw new BusinessException(
						"Fare type level[" + fareTypeLevel + "] is not valid, valid  values are 1-9");
			}
		}
	}

	@Override
	public void deactivateFareTypeHierarchy(FareTypeHierarchy fareTypeHierarchy) {
		FareTypeHierarchyEntity fareTypeHierarchyEntity = fareTypeHierarchyDao
				.findById(fareTypeHierarchy.getFareTypeHierarchyId()).orElseThrow(
						() -> new RecordNotFoundException(String.valueOf(fareTypeHierarchy.getFareTypeHierarchyId())));
		if (!fareTypeHierarchyEntity.getActivate()) {
			throw new BusinessException(INACTIVE_FARE_TYPE_HIERARCHY);
		}
		fareTypeHierarchyEntity.setActivate(Boolean.FALSE);
		fareTypeHierarchyDao.update(fareTypeHierarchyMapper.mapToEntity(fareTypeHierarchy, fareTypeHierarchyEntity));
	}

	@Override
	public void activateFareTypeHierarchy(FareTypeHierarchy fareTypeHierarchy) {
		FareTypeHierarchyEntity fareTypeHierarchyEntity = fareTypeHierarchyDao
				.findById(fareTypeHierarchy.getFareTypeHierarchyId()).orElseThrow(
						() -> new RecordNotFoundException(String.valueOf(fareTypeHierarchy.getFareTypeHierarchyId())));
		if (fareTypeHierarchyEntity.getActivate()) {
			throw new BusinessException(ACTIVE_FARE_TYPE_HIERARCHY);
		}
		fareTypeHierarchyEntity.setActivate(Boolean.TRUE);
		fareTypeHierarchyDao.update(fareTypeHierarchyMapper.mapToEntity(fareTypeHierarchy, fareTypeHierarchyEntity));

	}

	@Override
	public List<FareTypeHierarchy> getAllFareTypeHierarchyWithCabin(String effectiveDate, String cabin,
			Integer fareTypeLevel) {
		return fareTypeHierarchyMapper.mapToModel(fareTypeHierarchyDao.getAllFareTypeHierarchyCabin(
				Optional.ofNullable(effectiveDate), Optional.ofNullable(cabin), Optional.ofNullable(fareTypeLevel)));
	}

	private void validateBusinessConstraints(FareTypeHierarchy fareTypeHierarchy) {
		validateEffectiveToDate(fareTypeHierarchy);
		validateOverlap(fareTypeHierarchy);
		validateAtpcoFareType(fareTypeHierarchy);
		validateCabin(fareTypeHierarchy);
		validateCabinLevel(fareTypeHierarchy);
		validateFareTypeLevel(fareTypeHierarchy);
	}

	private void validateEffectiveToDate(FareTypeHierarchy fareTypeHierarchy,
			FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		validateEffectiveToDate(getEffectiveToDate(fareTypeHierarchy, fareTypeHierarchyEntity),
				getEffectiveFromDate(fareTypeHierarchy, fareTypeHierarchyEntity));
	}

	private void validateOverlap(FareTypeHierarchy fareTypeHierarchy) {
		if (fareTypeHierarchyDao.getOverLapRecordCount(
				OptionalUtil.getLocalDateValue(fareTypeHierarchy.getEffectiveFromDate()),
				OptionalUtil.getLocalDateValue(fareTypeHierarchy.getEffectiveToDate()),
				OptionalUtil.getValue(fareTypeHierarchy.getFareTypeCode()),
				OptionalUtil.getValue(fareTypeHierarchy.getCabin()),
				OptionalUtil.getValue(fareTypeHierarchy.getCabinLevel()),
				OptionalUtil.getValue(fareTypeHierarchy.getFareTypeLevel())) != 0) {
			throw new BusinessException(OVERLAP_COMBINATION_EXIST);

		}
	}

	private void validateBusinessConstraints(FareTypeHierarchy fareTypeHierarchy,
			FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		validateAtpcoFareType(fareTypeHierarchy);
		validateCabin(fareTypeHierarchy);
		validateCabinLevel(fareTypeHierarchy);
		validateEffectiveToDate(fareTypeHierarchy, fareTypeHierarchyEntity);
		overLapForUpdate(fareTypeHierarchy, fareTypeHierarchyEntity);
	}

	private void validateEffectiveToDate(FareTypeHierarchy fareTypeHierarchy) {
		validateEffectiveToDate(OptionalUtil.getLocalDateValue(fareTypeHierarchy.getEffectiveToDate()),
				OptionalUtil.getLocalDateValue(fareTypeHierarchy.getEffectiveFromDate()));
	}

	private void overLapForUpdate(FareTypeHierarchy fareTypeHierarchy,
			FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		LocalDate effectiveFromDate = getEffectiveFromDate(fareTypeHierarchy, fareTypeHierarchyEntity);
		LocalDate effectiveToDate = getEffectiveToDate(fareTypeHierarchy, fareTypeHierarchyEntity);
		String cabin = getCabin(fareTypeHierarchy, fareTypeHierarchyEntity);
		Integer cabinLevel = getCabinLevel(fareTypeHierarchy, fareTypeHierarchyEntity);
		String fareTypeCode = getFareTypeCode(fareTypeHierarchy, fareTypeHierarchyEntity);
		Integer fareTypeLevel = getFareTypeLevel(fareTypeHierarchy, fareTypeHierarchyEntity);
			if (fareTypeHierarchyDao.getOverLapRecordCountForUpdate(effectiveFromDate, effectiveToDate, fareTypeCode,
					cabin, cabinLevel, fareTypeLevel, fareTypeHierarchyEntity.getFareTypeHierarchyId()) != 0) {
				throw new BusinessException(OVERLAP_COMBINATION_EXIST);
			}
	}

	private Integer getFareTypeLevel(FareTypeHierarchy fareTypeHierarchy,
			FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		return OptionalUtil.isPresent(fareTypeHierarchy.getFareTypeLevel())
				? OptionalUtil.getValue(fareTypeHierarchy.getFareTypeLevel())
				: fareTypeHierarchyEntity.getFareTypeLevel();
	}

	private String getFareTypeCode(FareTypeHierarchy fareTypeHierarchy,
			FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		return OptionalUtil.isPresent(fareTypeHierarchy.getFareTypeCode())
				? OptionalUtil.getValue(fareTypeHierarchy.getFareTypeCode())
				: fareTypeHierarchyEntity.getFareTypeCode();
	}

	private Integer getCabinLevel(FareTypeHierarchy fareTypeHierarchy,
			FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		return OptionalUtil.isPresent(fareTypeHierarchy.getCabinLevel())
				? OptionalUtil.getValue(fareTypeHierarchy.getCabinLevel())
				: fareTypeHierarchyEntity.getCabinLevel();
	}
   
	private String getCabin(FareTypeHierarchy fareTypeHierarchy, FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		return OptionalUtil.isPresent(fareTypeHierarchy.getCabin())
				? OptionalUtil.getValue(fareTypeHierarchy.getCabin())
				: fareTypeHierarchyEntity.getCabin();
	}

	private LocalDate getEffectiveFromDate(FareTypeHierarchy fareTypeHierarchy,
			FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		return OptionalUtil.isPresent(fareTypeHierarchy.getEffectiveFromDate())
				? OptionalUtil.getLocalDateValue(fareTypeHierarchy.getEffectiveFromDate())
				: fareTypeHierarchyEntity.getEffectiveFromDate();
	}

	private LocalDate getEffectiveToDate(FareTypeHierarchy fareTypeHierarchy,
			FareTypeHierarchyEntity fareTypeHierarchyEntity) {
		return OptionalUtil.isPresent(fareTypeHierarchy.getEffectiveToDate())
				? OptionalUtil.getLocalDateValue(fareTypeHierarchy.getEffectiveToDate())
				: fareTypeHierarchyEntity.getEffectiveToDate();
	}
}
