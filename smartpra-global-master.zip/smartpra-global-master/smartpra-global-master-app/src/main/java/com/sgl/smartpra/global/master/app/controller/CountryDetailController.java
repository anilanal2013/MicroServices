
package com.sgl.smartpra.global.master.app.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;
import com.sgl.smartpra.global.master.app.service.CountryDetailService;
import com.sgl.smartpra.global.master.model.CountryDetail;

@RestController
public class CountryDetailController {

	@Autowired
	private CountryDetailService countryDtlService;

	@PostMapping("/countries/{countryCode}/details")
	public CountryDetail createCountryDetail(@PathVariable(value = "countryCode") String countryCode,
			@Validated(Create.class) @RequestBody CountryDetail countryDetail) {
		return countryDtlService.createCountryDetail(countryDetail,countryCode);
	}

	@GetMapping("/countries/{countryCode}/details/{countryDtlId}")
	public CountryDetail getCountryDetailByCounryDetailCode(@PathVariable(value = "countryCode") String countryCode,
			@PathVariable(value = "countryDtlId") Integer countryDtlId) {
		return countryDtlService.getCountryDetailByCounryDetailCode(countryCode, countryDtlId);
	}

	@GetMapping("/countries/{countryCode}/details")
	public List<CountryDetail> getListOfCountryDetails(@PathVariable(value = "countryCode") String countryCode,
			@RequestParam(value = "effectiveDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveDate) {
		return countryDtlService.getListOfCountryDetails(countryCode, effectiveDate);
	}

	@PutMapping("/countries/{countryCode}/details/{countryDtlId}")
	public CountryDetail updateCountryDetail(@PathVariable(value = "countryDtlId") Integer countryDtlId,
			@Validated(Update.class) @RequestBody CountryDetail countryDetail) {
		return countryDtlService.updateCountryDetail(countryDtlId, countryDetail);
	}

	@DeleteMapping("/countries/{countryCode}/details/{countryDtlId}")
	public void deleteCountryDetail(@PathVariable(value = "countryCode") String countryCode,
			@PathVariable(value = "countryDtlId") Integer countryDtlId) {
		countryDtlService.deleteCountryDetail(countryCode, countryDtlId);
	}
	
	@GetMapping("/countries/{countryCode}/cabinclass")
	public List<CountryDetail> findCountryCodeByCountryCodeAndCabinClass(@PathVariable(value = "countryCode") String countryCode) {
		return countryDtlService.findCountryCodeByCountryCodeAndCabinClass(countryCode);
	}
	
	@GetMapping("/countries/{countryCode}/details/issuedate")
	public CountryDetail getCountryDetailsByEffectiveDate(@PathVariable(value = "countryCode") String countryCode,
			@RequestParam(value = "effectiveDate", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") String effectiveDate) {
		return countryDtlService.getCountryDetailsByEffectiveDate(countryCode, effectiveDate);
	}

}
