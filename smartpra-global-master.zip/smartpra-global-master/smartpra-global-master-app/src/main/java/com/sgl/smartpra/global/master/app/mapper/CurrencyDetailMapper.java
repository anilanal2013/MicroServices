package com.sgl.smartpra.global.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.global.master.app.dao.entity.CurrencyDetailEntity;
import com.sgl.smartpra.global.master.model.CurrencyDetail;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, 
nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CurrencyDetailMapper extends BaseMapper<CurrencyDetail, CurrencyDetailEntity> {

	CurrencyDetailEntity mapToEntity(CurrencyDetail currencyDetail, @MappingTarget CurrencyDetailEntity currencyDetailEntity);

	CurrencyDetailEntity mapToEntity(CurrencyDetail currencyDetail);

	/*
	 * CurrencyDetail mapToCurrencyDetailModel(CurrencyDetailEntity
	 * currencyDetailEntity);
	 * 
	 * List<CurrencyDetail> mapToCurrencyDetailModelList(List<CurrencyDetailEntity>
	 * currencyDetailEntityList);
	 * 
	 * CurrencyDetailEntity mapToCurrencyDetailEntity(CurrencyDetail
	 * currencyDetail);
	 * 
	 * List<CurrencyDetailEntity> mapToCurrencyDetailEntityList(List<CurrencyDetail>
	 * currencyDetailList);
	 */

}
