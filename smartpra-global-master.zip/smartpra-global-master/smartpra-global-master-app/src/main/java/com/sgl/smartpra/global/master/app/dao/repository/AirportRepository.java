package com.sgl.smartpra.global.master.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.global.master.app.dao.entity.AirportEntity;

@Repository
public interface AirportRepository
		extends JpaRepository<AirportEntity, String>, JpaSpecificationExecutor<AirportEntity> {

	List<AirportEntity> findByCityCode(String cityCode);
		
	List<AirportEntity> findDistinctByAirportCodeIsNotNullAndIsActiveTrueOrderByAirportCode();
	
	List<AirportEntity> findDistinctByCityCodeIsNotNullAndIsActiveTrueOrderByCityCode();

	List<AirportEntity> findDistinctByStateCodeIsNotNullAndIsActiveTrueOrderByStateCode();

}
