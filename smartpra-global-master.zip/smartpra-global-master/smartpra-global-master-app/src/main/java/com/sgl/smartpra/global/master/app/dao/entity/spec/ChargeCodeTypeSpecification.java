package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.ChargeCodeTypeEntity;

public class ChargeCodeTypeSpecification {

	public static Specification<ChargeCodeTypeEntity> search(Optional<String> chargeCatCode, Optional<String> chargeCode){
		return (chargeCodeType, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (OptionalUtil.isPresent(chargeCatCode)) {
				predicates.add(criteriaBuilder.like(chargeCodeType.get("chargeCatCode"),
						OptionalUtil.getValue(chargeCatCode) + "%"));
			}
			if (OptionalUtil.isPresent(chargeCode)) {
				predicates.add(criteriaBuilder.like(chargeCodeType.get("chargeCode"),
						OptionalUtil.getValue(chargeCode) + "%"));
			}

			
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}
}
