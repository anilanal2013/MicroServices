package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ChargeCodeDao;
import com.sgl.smartpra.global.master.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.ChargeCodeMapper;
import com.sgl.smartpra.global.master.app.repository.entity.ChargeCodeEntity;
import com.sgl.smartpra.global.master.app.service.ChargeCategoryService;
import com.sgl.smartpra.global.master.app.service.ChargeCodeService;
import com.sgl.smartpra.global.master.model.ChargeCategory;
import com.sgl.smartpra.global.master.model.ChargeCode;

@Service
@Transactional
public class ChargeCodeServiceImpl implements ChargeCodeService {

	@Autowired
	private ChargeCodeMapper chargeCodeMapper;

	@Autowired
	private ChargeCodeDao chargeCodeDao;

	@Autowired
	private ChargeCategoryService chargeCategoryService;

	private static final String CHARGECATEGORYCODE = "Given Charge Category Code: ";
	private static final String CHARGECODE = "chargeCode";
	private static final String CHARGECODERECORDMISMATCH = " in path variable mismatch with Charge Code Record ";
	private static final String INVALIDCHARGECATEGORY = "Invalid Charge category in path variable. Charge Category code : ";
	private String doesNotExist = " does not exist";
	private String isNotActive = " is not active";

	@Override
	public ChargeCode createChargeCode(Optional<String> chargeCategoryCode, ChargeCode chargeCodeModel) {

		try {
			chargeCategoryService.getChargeCategoryByChargeCategoryCode(chargeCategoryCode);
		} catch (ResourceNotFoundException rnfe) {
			throw new ServiceException(INVALIDCHARGECATEGORY + chargeCategoryCode + doesNotExist);
		} catch (ServiceException se) {
			throw new ServiceException(INVALIDCHARGECATEGORY + chargeCategoryCode + isNotActive);
		}

		Optional<ChargeCodeEntity> chargeCodeEntity = chargeCodeDao.findOne(chargeCodeModel.getChargeCode());
		if (chargeCodeEntity.isPresent()) {
			throw new ServiceException("Charge code has been already created");
		}
		ChargeCategory chargeCategory = chargeCategoryService.getChargeCategoryByChargeCategoryCode(chargeCategoryCode);

		if (chargeCategory == null) {
			throw new ServiceException("Charge Category Code is not matching");
		}
		chargeCodeTypeRequiredIndicator(chargeCodeModel);
		locationCodeRequiredIndicator(chargeCodeModel);
		poLineItemRequiredIndicator(chargeCodeModel);
		productIdRequiredIndicator(chargeCodeModel);
		chargeCodeModel.setActivate(Boolean.TRUE);
		chargeCodeModel.setCreatedDate(LocalDateTime.now());
		return chargeCodeMapper.mapToModel(chargeCodeDao.create(chargeCodeMapper.mapToEntity(chargeCodeModel)));

	}

	@Override
	public ChargeCode getChargeCodeByChargeCode(Optional<String> chargeCategoryCode, Optional<String> chargeCode) {

		Optional<ChargeCodeEntity> chargeCodeEntity = chargeCodeDao.findOne(chargeCode);
		if (!chargeCodeEntity.isPresent()) {
			throw new ServiceException("Charge Category code has been already created");
		}

		ChargeCategory chargeCategory = chargeCategoryService.getChargeCategoryByChargeCategoryCode(chargeCategoryCode);

		if (chargeCategory.getActivate()) {
			if (chargeCategory.getChargeCategoryCode().equals(chargeCategoryCode))
				return chargeCodeMapper.mapToModel(chargeCodeEntity.orElseThrow(() -> new ServiceException(
						CHARGECATEGORYCODE + chargeCategoryCode + CHARGECODERECORDMISMATCH + chargeCode)));

			throw new ServiceException("Charge Code is not active");
		} else {
			throw new ResourceNotFoundException(CHARGECODE, "code", chargeCode);
		}
	}

	@Override
	public List<ChargeCode> getAllChargeCode(Optional<String> chargeCategoryCode, Optional<String> chargeCode,
			Optional<String> chargeCodeName) {

		try {
			chargeCategoryService.getChargeCategoryByChargeCategoryCode(chargeCategoryCode);
		} catch (ResourceNotFoundException rnfe) {
			throw new ServiceException(INVALIDCHARGECATEGORY + chargeCategoryCode + doesNotExist);
		} catch (ServiceException se) {
			throw new ServiceException(INVALIDCHARGECATEGORY + chargeCategoryCode + isNotActive);
		}

		return chargeCodeMapper.mapToModel(chargeCodeDao.findAll(chargeCode, chargeCodeName, chargeCategoryCode));
	}

	@Override
	public List<ChargeCodeEntity> updateChargeCode(List<ChargeCode> chargeCodeModel) {

		List<ChargeCodeEntity> entityList = new ArrayList<ChargeCodeEntity>();
		for (ChargeCode chargeCod : chargeCodeModel) {
			ChargeCodeEntity chargeCodeEntity = chargeCodeDao.findOne(chargeCod.getChargeCode())
					.orElseThrow(() -> new RecordNotFoundException(OptionalUtil.getValue(chargeCod.getChargeCode())));
			ChargeCodeEntity mapToEntity = chargeCodeMapper.mapToEntity(chargeCod, chargeCodeEntity);
			entityList.add(mapToEntity);

			chargeCodeModel.stream().forEach(charge -> chargeCategoryService
					.getChargeCategoryByChargeCatCode(charge.getChargeCategoryCode().orElseThrow(
							() -> new RecordNotFoundException(String.valueOf(charge.getChargeCategoryCode())))));
		}
		return chargeCodeDao.update(entityList);

	}

	@Override
	public void deactivateChargeCode(Optional<String> chargeCategoryCode, Optional<String> chargeCode,
			Optional<String> lastUpdatedBy) {

		try {
			chargeCategoryService.getChargeCategoryByChargeCategoryCode(chargeCategoryCode);
		} catch (ResourceNotFoundException rnfe) {
			throw new ServiceException(INVALIDCHARGECATEGORY + chargeCategoryCode + doesNotExist);
		} catch (ServiceException se) {
			throw new ServiceException(INVALIDCHARGECATEGORY + chargeCategoryCode + isNotActive);
		}

		ChargeCodeEntity chargeCodeEntity = chargeCodeDao.findOne(chargeCode)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(chargeCode)));

		if (!chargeCodeEntity.getActivate())
			throw new ServiceException("Charge Code is already in deactive state");

		if (!chargeCodeEntity.getChargeCategoryCode().equals(chargeCategoryCode))
			throw new ServiceException(CHARGECATEGORYCODE + chargeCategoryCode + CHARGECODERECORDMISMATCH + chargeCode);

		chargeCodeEntity.setActivate(Boolean.FALSE);
		chargeCodeEntity.setLastUpdatedBy(OptionalUtil.getValue(lastUpdatedBy));
		chargeCodeEntity.setLastUpdatedDate(LocalDateTime.now());

		chargeCodeDao.create(chargeCodeEntity);
	}

	@Override
	public void activateChargeCode(Optional<String> chargeCategoryCode, Optional<String> chargeCode,
			Optional<String> lastUpdatedBy) {

		try {
			chargeCategoryService.getChargeCategoryByChargeCategoryCode(chargeCategoryCode);
		} catch (ResourceNotFoundException rnfe) {
			throw new ServiceException(INVALIDCHARGECATEGORY + chargeCategoryCode + doesNotExist);
		} catch (ServiceException se) {
			throw new ServiceException(INVALIDCHARGECATEGORY + chargeCategoryCode + isNotActive);
		}

		Optional<ChargeCodeEntity> chargeCodeEntity = chargeCodeDao.findOne(chargeCode);

		if (chargeCodeEntity.get().getActivate())
			throw new ServiceException("Charge Code is already in active state");

		if (chargeCodeEntity.get().getChargeCategoryCode() == OptionalUtil.getValue(chargeCategoryCode)) {
			throw new ServiceException("In valid charge category code");
		}

	}

	private void productIdRequiredIndicator(ChargeCode chargeCodeModel) {
		if (!OptionalUtil.isPresent(chargeCodeModel.getProductIdRequiredIndicator())) {
			chargeCodeModel.setProductIdRequiredIndicator(Optional.ofNullable(Boolean.FALSE));
		}
	}

	private void poLineItemRequiredIndicator(ChargeCode chargeCodeModel) {
		if (!OptionalUtil.isPresent(chargeCodeModel.getPoLineItemRequiredIndicator())) {
			chargeCodeModel.setPoLineItemRequiredIndicator(Optional.ofNullable(Boolean.FALSE));
		}
	}

	private void locationCodeRequiredIndicator(ChargeCode chargeCodeModel) {
		if (!OptionalUtil.isPresent(chargeCodeModel.getLocationCodeRequiredIndicator())) {
			chargeCodeModel.setLocationCodeRequiredIndicator(Optional.ofNullable(Boolean.FALSE));
		}

	}

	private void chargeCodeTypeRequiredIndicator(ChargeCode chargeCodeModel) {
		if (!OptionalUtil.isPresent(chargeCodeModel.getChargeCodeTypeRequiredIndicator())) {
			chargeCodeModel.setChargeCodeTypeRequiredIndicator(Optional.ofNullable(Boolean.FALSE));
		}

	}

	public ChargeCode getChargeCodeByChargeCode(Optional<String> chargeCode) {

		ChargeCodeEntity chargeCodeEntity = chargeCodeDao.findOne(chargeCode)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(chargeCode)));
		return chargeCodeMapper.mapToModel(chargeCodeEntity);

	}

	@Override
	public List<String> getChargeCodeFromChargeCodeMaster() {
		// TODO Auto-generated method stub
		return chargeCodeDao.getChargeCodeFromChargeCodeMaster();
	}
}
