package com.sgl.smartpra.global.master.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.sgl.smartpra.global.master.app.dao.entity.TicketOverwiteDetailEntity;
import com.sgl.smartpra.global.master.app.repository.entity.StandardAreaDetailEntity;
import com.sgl.smartpra.global.master.model.StandardAreaDetail;
import com.sgl.smartpra.global.master.model.TicketOverwriteDetail;

@Mapper(componentModel="Spring")
public interface TicketOverwriteDetailMapper extends BaseMapper<TicketOverwriteDetail, TicketOverwiteDetailEntity> {
	
	TicketOverwiteDetailEntity mapToEntity(TicketOverwriteDetail ticketOverwiteDetailDao);

	TicketOverwriteDetail mapToModel(TicketOverwiteDetailEntity ticketOverwiteDetailEntity);
	
	List<TicketOverwriteDetail> mapToTicketOverwriteDetailModelList(List<TicketOverwiteDetailEntity> ticketOverwriteDetail);

	default TicketOverwiteDetailEntity fromId(Long id){
		if(id == null){
			return null;
		}
		TicketOverwiteDetailEntity ticketOverwiteDetailEntity = new TicketOverwiteDetailEntity();
		ticketOverwiteDetailEntity.setScenrioDtlId(id);
		return ticketOverwiteDetailEntity;
	}
	
}
