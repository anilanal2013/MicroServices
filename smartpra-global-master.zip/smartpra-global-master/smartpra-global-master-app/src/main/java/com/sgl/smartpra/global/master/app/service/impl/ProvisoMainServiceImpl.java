package com.sgl.smartpra.global.master.app.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ProvisoAddlDiscountDao;
import com.sgl.smartpra.global.master.app.dao.ProvisoMainDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoAdditionalDiscountEntity;
import com.sgl.smartpra.global.master.app.dao.repository.ProvisoMainRepository;
import com.sgl.smartpra.global.master.app.mapper.ProvisoMainCombinedMapper;
import com.sgl.smartpra.global.master.app.mapper.ProvisoMainMapper;
import com.sgl.smartpra.global.master.app.service.ProvisoMainService;
import com.sgl.smartpra.global.master.model.ProvisoMainModel;
import com.sgl.smartpra.global.master.model.ProvisoMainStgModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoMainServiceImpl implements ProvisoMainService {
	public static final String PROVISO_MAIN_ALREADY_INACTIVE = "proviso main is already in deactive state";
	@Autowired
	private ProvisoMainMapper provisoMainMapper;
	@Autowired
	private ProvisoMainCombinedMapper provisoMainCombinedMapper;
	@Autowired
	private ProvisoMainDao provisoMainDao;

	@Autowired
	private ProvisoMainRepository provisoMainRepository;
	
	@Autowired
	private ProvisoAddlDiscountDao provisoAddlDiscountDao;

	@Override
	public List<ProvisoMainModel> search(Optional<String> carrierNumCode, Optional<String> effectiveFromDate,
			Optional<String> effectiveToDate, Optional<String> provisoSection, Optional<String> provisoStatus) {
		List<ProvisoMainModel> provisoMainModelList = provisoMainMapper.mapToModel(provisoMainDao
				.searchProvisoMain(carrierNumCode, effectiveFromDate, effectiveToDate, provisoSection, provisoStatus));
		for (ProvisoMainModel provisoMainModel : provisoMainModelList) {
			List<ProvisoAdditionalDiscountEntity> provisoAdditionalDiscountEntityList=provisoAddlDiscountDao.findByMainId(Optional.of(provisoMainModel.getProvisoMainId()));
			for(ProvisoAdditionalDiscountEntity provisoAdditionalDiscountEntity:provisoAdditionalDiscountEntityList) {
			provisoMainModel.setDiscountCode(Optional.of(provisoAdditionalDiscountEntity.getDiscountCode()));
			}
		}
		return provisoMainModelList;
	}

	@Override
	public ProvisoMainModel getProvisoMainByprovisoMainId(Integer provisoMainId) {

		return provisoMainMapper.mapToModel(provisoMainDao.findById(provisoMainId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoMainId))));
	}

	@Override
	public ProvisoMainStgModel saveProvisoMain(ProvisoMainStgModel provisoMainStgModel) {
		provisoMainStgModel.setCreatedDate(LocalDateTime.now());
		return provisoMainCombinedMapper
				.mapToModel(provisoMainDao.create(provisoMainCombinedMapper.mapToEntity(provisoMainStgModel)));
	}

	@Override
	public List<ProvisoMainModel> getProvisoMainList(String carrierNumCode, String effectiveDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date effectiveDateParse = null;
		try {
			effectiveDateParse = sdf.parse(effectiveDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return provisoMainMapper.mapToModel(
				provisoMainRepository.getProvisoMainList(carrierNumCode, convertLocalDate(effectiveDateParse)));
	}

	public LocalDate convertLocalDate(Date date) {
		if (date != null) {
			return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		} else {
			return null;
		}
	}
}
