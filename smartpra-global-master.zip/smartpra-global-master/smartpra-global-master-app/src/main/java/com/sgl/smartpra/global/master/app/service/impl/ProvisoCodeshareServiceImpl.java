package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.ProvisoCodeshareDao;
import com.sgl.smartpra.global.master.app.dao.entity.ProvisoCodeshareEntity;
import com.sgl.smartpra.global.master.app.mapper.ProvisoCodeshareCombinedMapper;
import com.sgl.smartpra.global.master.app.mapper.ProvisoCodeshareMapper;
import com.sgl.smartpra.global.master.app.service.ProvisoCodeshareService;
import com.sgl.smartpra.global.master.model.ProvisoCodeshareModel;
import com.sgl.smartpra.global.master.model.ProvisoCodeshareStgModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class ProvisoCodeshareServiceImpl implements ProvisoCodeshareService {
	@Autowired
	private ProvisoCodeshareDao provisoCodeshareDao;
	@Autowired
	private ProvisoCodeshareMapper provisoCodeshareMapper;

	@Autowired
	private ProvisoCodeshareCombinedMapper provisoCodeshareCombinedMapper;

	private static final String CODESHARE_RECORD_CORRESPONDANCE_TO_MAIN = "Proviso CodeShare data not available for selected Proviso Main record";

	@Override
	public List<ProvisoCodeshareModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<String> provisoSection, Optional<String> areaFrom, Optional<String> areaTo) {

		return provisoCodeshareMapper.mapToModel(
				provisoCodeshareDao.search(carrierNumCode, provisoSeqNumber, provisoSection, areaFrom, areaTo));

	}

	@Override
	public List<ProvisoCodeshareModel> searchByProvisoMain(Optional<Integer> provisoMainId, Optional<String> areaFrom,
			Optional<String> areaTo) {

		return provisoCodeshareMapper
				.mapToModel(provisoCodeshareDao.searchByProvisoMain(provisoMainId, areaFrom, areaTo));

	}

	@Override
	public ProvisoCodeshareModel getProvisoCodeshareByProvisoCodeshareId(Integer provisoCodeshareId) {

		return provisoCodeshareMapper.mapToModel(provisoCodeshareDao.findById(provisoCodeshareId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(provisoCodeshareId))));
	}

	@Override
	public ProvisoCodeshareStgModel saveProvisoCodeshare(ProvisoCodeshareStgModel provisoCodeshareStgModel) {
		provisoCodeshareStgModel.setCreatedDate(LocalDateTime.now());
		return provisoCodeshareCombinedMapper.mapToModel(
				provisoCodeshareDao.create(provisoCodeshareCombinedMapper.mapToEntity(provisoCodeshareStgModel)));

	}

	@Override
	public List<ProvisoCodeshareModel> getProvisoCodeshareByProvisoMainId(Optional<Integer> provisoMainId) {
		
		List<Integer> provisoMainIdFromDb=provisoCodeshareDao.getListOfProvisoMainIdFromRoutingDb();
		if(!(provisoMainIdFromDb.contains(OptionalUtil.getValue(provisoMainId)))){
			throw new BusinessException(CODESHARE_RECORD_CORRESPONDANCE_TO_MAIN);
		}
		
		return provisoCodeshareMapper.mapToModel(provisoCodeshareDao.findByMainId(provisoMainId));
	}
}
