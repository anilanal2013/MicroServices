package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.dao.entity.OneCountryEntity;

public class OneCountryEntitySpecification {

	private OneCountryEntitySpecification() {
	}

	private static final String ONECOUNTRYCODE = "oneCountryCode";
	private static final String EFFECTIVEFROMDATE = "effectiveFromDate";
	private static final String EFFECTIVETODATE = "effectiveToDate";
	private static final String ISACTIVE = "isActive";
	private static final String COUNTRYCODELIST = "countryCodeList";

	public static Specification<OneCountryEntity> equalCountryCode(Optional<String> oneCountryCode) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(oneCountryEntity.get(ONECOUNTRYCODE), OptionalUtil.getValue(oneCountryCode));
	}

	public static Specification<OneCountryEntity> betweenEffectiveAndFromDate(Optional<String> effectiveFromDate) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
				oneCountryEntity.get(EFFECTIVEFROMDATE), oneCountryEntity.get(EFFECTIVETODATE));
	}

	public static Specification<OneCountryEntity> betweenEffectiveDateAndToDate(Optional<String> effectiveToDate) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
				oneCountryEntity.get(EFFECTIVEFROMDATE), oneCountryEntity.get(EFFECTIVETODATE));
	}

	public static Specification<OneCountryEntity> notEqualOneCountryId(Integer oneCountryId) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.notEqual(oneCountryEntity.get("oneCountryId"), oneCountryId);
	}

	public static Specification<OneCountryEntity> equalEffectiveFromDate(Optional<String> effectiveFromDate) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(oneCountryEntity.get(EFFECTIVEFROMDATE), OptionalUtil.getLocalDateValue(effectiveFromDate));
	}

	public static Specification<OneCountryEntity> equalEffectiveToDate(Optional<String> effectiveToDate) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(oneCountryEntity.get(EFFECTIVETODATE), OptionalUtil.getLocalDateValue(effectiveToDate));
	}

	public static Specification<OneCountryEntity> greaterThanOrEqualToEffectiveDate(Optional<String> effectiveDate) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.greaterThanOrEqualTo(
				criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
				oneCountryEntity.get(EFFECTIVEFROMDATE));
	}

	public static Specification<OneCountryEntity> lessThanOrEqualToEffectiveDate(Optional<String> effectiveDate) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.lessThanOrEqualTo(
				criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
				oneCountryEntity.get(EFFECTIVETODATE));
	}

	public static Specification<OneCountryEntity> likeCountryCodeList(Optional<String> countryCodeList) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.like(oneCountryEntity.get(COUNTRYCODELIST), "%" + OptionalUtil.getValue(countryCodeList) + "%");
	}

	public static Specification<OneCountryEntity> isActive() {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(oneCountryEntity.get(ISACTIVE), true);
	}

	public static Specification<OneCountryEntity> isNotActive() {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(oneCountryEntity.get(ISACTIVE), false);
	}

	public static Specification<OneCountryEntity> getAllOneCountryUpdated(Optional<String> countryCodeList,
			Integer oneCountryId) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(countryCodeList)) {
				predicates.add(criteriaBuilder.like(oneCountryEntity.get(COUNTRYCODELIST),
						OptionalUtil.getValue(countryCodeList) + "%"));
			}
			if (oneCountryId != null) {
				predicates.add(criteriaBuilder.notEqual(oneCountryEntity.get("oneCountryId"), oneCountryId));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static void orderByAsc(Root<OneCountryEntity> oneCountryEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.asc(oneCountryEntity.get(orderByString)));
	}

	public static Specification<OneCountryEntity> search(Optional<String> oneCountryCode,
			Optional<String> countryCodeList, Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> isActive) {
		return (oneCountryEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(oneCountryCode)) {
				predicates.add(criteriaBuilder.like(oneCountryEntity.get(ONECOUNTRYCODE),
						OptionalUtil.getValue(oneCountryCode) + "%"));
			}
			if (OptionalUtil.isPresent(countryCodeList)) {
				predicates.add(criteriaBuilder.like(oneCountryEntity.get(COUNTRYCODELIST),
						OptionalUtil.getValue(countryCodeList) + "%"));
			}
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								oneCountryEntity.get(EFFECTIVEFROMDATE), oneCountryEntity.get(EFFECTIVETODATE)),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								oneCountryEntity.get(EFFECTIVEFROMDATE), oneCountryEntity.get(EFFECTIVETODATE))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							oneCountryEntity.get(EFFECTIVEFROMDATE), oneCountryEntity.get(EFFECTIVETODATE)));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							oneCountryEntity.get(EFFECTIVEFROMDATE), oneCountryEntity.get(EFFECTIVETODATE)));
				}
			}

			if (OptionalUtil.getValue(isActive) == null || OptionalUtil.getValue(isActive)) {
				predicates.add(criteriaBuilder.isTrue(oneCountryEntity.get(ISACTIVE)));
			} else {
				predicates.add(criteriaBuilder.isFalse(oneCountryEntity.get(ISACTIVE)));
			}
			orderByAsc(oneCountryEntity, criteriaQuery, criteriaBuilder, "oneCountryCode");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
