package com.sgl.smartpra.global.master.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.common.model.ValidationMessage;
import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.app.dao.SectionDao;
import com.sgl.smartpra.global.master.app.dao.entity.SectionEntity;
import com.sgl.smartpra.global.master.app.exception.ServiceException;
import com.sgl.smartpra.global.master.app.mapper.SectionMapper;
import com.sgl.smartpra.global.master.app.service.ChargeCodeService;
import com.sgl.smartpra.global.master.app.service.SectionService;
import com.sgl.smartpra.global.master.model.ChargeCode;
import com.sgl.smartpra.global.master.model.Section;
import com.sgl.smartpra.global.master.model.SectionDto;

@Service
@Transactional
public class SectionServiceImpl implements SectionService {

	@Autowired
	SectionMapper sectionMapper;

	@Autowired
	SectionDao sectionDao;

	@Autowired
	private ChargeCodeService chargeCodeService;

	public static final String SECTION_NOT_ACTIVE = "Section is not active";

	public static final Optional<String> CHARGECATEGORYCODE = null;

	public static final String INVALID_INPUT_MAXOCCURENCE = "Invalid input for maxOccurrence, value must be between 1 to 999 or -1 only";

	public static final String CHARGECODE_NOT_ACTIVE = "ChargeCode is not active";

	public static final String SECTION_ALREADY_ACTIVE = "section is already in active state";

	@Override
	public List<Section> getAllSection(Optional<String> chargeCode, Optional<String> sectionCode,
			Optional<String> sectionName, Optional<Boolean> activate) {

		return sectionMapper.mapToModel(sectionDao.findAll(chargeCode, sectionCode, sectionName, activate));
	}

	@Override
	public Section findSectionBySectionMasterId(Optional<String> chargeCode, Integer sectionMasterId) {

		ChargeCode chaCode = chargeCodeService.getChargeCodeByChargeCode(chargeCode);
		if (!chaCode.getActivate()) {
			throw new BusinessException(CHARGECODE_NOT_ACTIVE);
		}

		SectionEntity sectionEntity = sectionDao.findById(sectionMasterId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sectionMasterId)));

		// return only if the record is active
		if (sectionEntity.getActivate()) {
			return sectionMapper.mapToModel(sectionEntity);
		} else {
			throw new BusinessException(SECTION_NOT_ACTIVE);
		}
	}

	@Override
	public Section createSection(Optional<String> chargeCode, Section section) {

		ChargeCode chaCode = chargeCodeService.getChargeCodeByChargeCode(chargeCode);

		if (!chaCode.getActivate()) {
			throw new BusinessException(CHARGECODE_NOT_ACTIVE);
		}

		section.setActivate(Boolean.TRUE);
		section.setCreatedDate(LocalDateTime.now());
		return sectionMapper.mapToModel(sectionDao.create(sectionMapper.mapToEntity(section)));

	}

	@Override
	public List<Section> updateSection(List<Section> sections) {

		List<SectionEntity> sectionEntitys = new ArrayList<>();
		for (Section section : sections) {
			SectionEntity sectionEntity = sectionDao.findById(section.getSectionMasterId())
					.orElseThrow(() -> new RecordNotFoundException(String.valueOf(section.getSectionMasterId())));
			sectionEntitys.add(sectionMapper.mapToEntity(section, sectionEntity));
		}

		return sectionMapper.mapToModel(sectionDao.update(sectionEntitys));

	}

	@Override
	public void deactivateSection(Optional<String> chargeCode, Integer sectionMasterId, String lastUpdatedBy) {

		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		ChargeCode chaCode = chargeCodeService.getChargeCodeByChargeCode(chargeCode);

		if (!chaCode.getActivate()) {
			throw new BusinessException(CHARGECODE_NOT_ACTIVE);
		}

		SectionEntity sectionEntity = sectionDao.findById(sectionMasterId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sectionMasterId)));

		if (!sectionEntity.getActivate())
			throw new ServiceException(SECTION_NOT_ACTIVE);

		sectionEntity.setLastUpdatedBy(lastUpdatedBy);
		sectionEntity.setLastUpdatedDate(LocalDateTime.now());
		sectionEntity.setActivate(Boolean.FALSE);
		sectionDao.update(sectionEntity);
	}

	@Override
	public void activateSection(Optional<String> chargeCode, Integer sectionMasterId, String lastUpdatedBy) {

		if (lastUpdatedBy.isEmpty()) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_REQUIRED);
		} else if (lastUpdatedBy.length() > 15) {
			throw new BusinessException(ValidationMessage.LAST_UPDATED_BY_LENGTH);
		}

		ChargeCode chaCode = chargeCodeService.getChargeCodeByChargeCode(chargeCode);

		if (!chaCode.getActivate()) {
			throw new BusinessException(CHARGECODE_NOT_ACTIVE);
		}

		SectionEntity sectionEntity = sectionDao.findById(sectionMasterId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sectionMasterId)));

		if (sectionEntity.getActivate())
			throw new BusinessException(SECTION_ALREADY_ACTIVE);

		sectionEntity.setLastUpdatedBy(lastUpdatedBy);
		sectionEntity.setLastUpdatedDate(LocalDateTime.now());
		sectionEntity.setActivate(Boolean.TRUE);
		sectionDao.update(sectionEntity);
	}
	
	@Override
	public Section findSectionBySectionMasterId(Integer sectionMasterId) {

		SectionEntity sectionEntity = sectionDao.findById(sectionMasterId)
				.orElseThrow(() -> new RecordNotFoundException(String.valueOf(sectionMasterId)));
		return sectionMapper.mapToModel(sectionEntity);
	}
	
	@Override
	public List<SectionDto> fetchSectionByChargeCode(String chargeCode, String currentBillingPeriod){
		return sectionDao.fetchSectionByChargeCode(chargeCode, currentBillingPeriod);
	}
}
