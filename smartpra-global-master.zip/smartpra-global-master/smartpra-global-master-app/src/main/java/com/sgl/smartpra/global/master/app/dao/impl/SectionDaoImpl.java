package com.sgl.smartpra.global.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Component;

//import com.sgl.smartpra.exceptions.exception.BusinessException;
import com.sgl.smartpra.global.master.app.dao.SectionDao;
import com.sgl.smartpra.global.master.app.dao.entity.SectionEntity;
import com.sgl.smartpra.global.master.app.dao.entity.spec.SectionEntitySpecification;
import com.sgl.smartpra.global.master.app.dao.repository.SectionRepository;
import com.sgl.smartpra.global.master.model.SectionDto;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SectionDaoImpl implements SectionDao {

	@Autowired
	private SectionRepository sectionRepository;

	@Override
	@Cacheable(value = "sectionEntity", key = "#sectionMasterId")
	public Optional<SectionEntity> findById(Integer sectionMasterId) {
		log.info("Cacheable SectionEntity's ID= {}", sectionMasterId);
		return sectionRepository.findById(sectionMasterId);
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "sectionEntity", key = "#sectionEntity.sectionMasterId") })
	public SectionEntity create(SectionEntity sectionEntity) {
		return sectionRepository.save(sectionEntity);
	}

	@Override
	public List<SectionEntity> update(List<SectionEntity> sectionEntity) {
		return sectionRepository.saveAll(sectionEntity);
	}

	@Override
	public SectionEntity update(SectionEntity sectionEntity) {
		return sectionRepository.save(sectionEntity);
	}

	@Override
	public List<SectionEntity> findAll(Optional<String> chargeCode, Optional<String> sectionCode,
			Optional<String> sectionName, Optional<Boolean> activate) {
		return sectionRepository
				.findAll(SectionEntitySpecification.search(chargeCode, sectionCode, sectionName, activate));
	}

	@Override
	public Optional<SectionEntity> findOne(Integer id) {
		Optional<SectionEntity> entity = sectionRepository.findById(id);
		if (!entity.get().getActivate()) {
			//throw new BusinessException("record not Active " + id);
		}
		return entity;
	}

	@Override
	public List<SectionDto> fetchSectionByChargeCode(String chargeCode, String currentBillingPeriod) {
		return sectionRepository.fetchSectionByChargeCode(chargeCode, currentBillingPeriod);
	}

}
