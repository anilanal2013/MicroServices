package com.sgl.smartpra.global.master.app.service;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.global.master.model.ProvisoSectorModel;
import com.sgl.smartpra.global.master.model.ProvisoSectorStgModel;

public interface ProvisoSectorService {
	

	public List<ProvisoSectorModel> getProvisoSectorByProvisoMainId(Optional<Integer> provisoMainId);

	public ProvisoSectorModel getProvisoSectorByProvisioSectorId(Integer provisoSectorId);

	public List<ProvisoSectorModel> searchByProvisoInMain(Optional<Integer> provisoMainId, Optional<String> areaFrom);

	public List<ProvisoSectorModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber);

	public List<ProvisoSectorModel> search(Optional<String> carrierNumCode, Optional<Integer> provisoSeqNumber,
			Optional<Integer> sectionRecNumber);

	public ProvisoSectorStgModel saveProvisoSector(ProvisoSectorStgModel provisoSectorStgModel);
}
