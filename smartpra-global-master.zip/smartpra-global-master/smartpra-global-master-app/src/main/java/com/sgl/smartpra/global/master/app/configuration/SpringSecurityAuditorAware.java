package com.sgl.smartpra.global.master.app.configuration;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;


@Component
public class SpringSecurityAuditorAware implements AuditorAware<String> {

	 @Override
	    public Optional<String> getCurrentAuditor() {
		 //TODO : we need to uncomment the below line for having actual login user detail.
	       // return Optional.of(SecurityUtils.getCurrentUserLogin().orElse(Constants.SYSTEM_ACCOUNT));
		 return Optional.of("Admin");
	    }
}
