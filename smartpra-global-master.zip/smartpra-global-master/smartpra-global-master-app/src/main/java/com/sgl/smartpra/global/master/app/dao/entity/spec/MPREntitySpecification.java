package com.sgl.smartpra.global.master.app.dao.entity.spec;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.app.repository.entity.MPREntity;

public class MPREntitySpecification {

	/*
	 * public static Specification<MPREntity> getMprDetails(Optional<String>
	 * effectiveDate) { return (mprEntity, criteriaQuery, criteriaBuilder) -> {
	 * List<Predicate> predicates = new ArrayList<>(); if
	 * (OptionalUtil.isPresent(effectiveDate)) { predicates.add(
	 * criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.
	 * getLocalDateValue(effectiveDate)), mprEntity.get("effectiveFromDate"),
	 * mprEntity.get("effectiveToDate"))); } return
	 * criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()])); };
	 * 
	 * }
	 */
	
	
	public static Specification<MPREntity> getMprDetails(Optional<String> effectiveDate) {
		return (mprEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(effectiveDate)) {
				predicates.add(
						criteriaBuilder.between(criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveDate)),
								mprEntity.get("effectiveFromDate"), mprEntity.get("effectiveToDate")));
			}
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	public static Specification<MPREntity> betweenEffectiveFromAndEffectiveToDate(LocalDate effectiveDate) {
		return (mprEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.between(
				criteriaBuilder.literal(effectiveDate), mprEntity.get("effectiveFromDate"),
				mprEntity.get("effectiveToDate"));
	}

	public static Specification<MPREntity> isActive() {
		return (mprEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(mprEntity.get("activate"), true);
	}
	
	public static void orderByDesc(Root<MPREntity>mprEntity,CriteriaQuery<?> criteriaQuery,CriteriaBuilder criteriaBuilder, String orderByString) {
		criteriaQuery.orderBy(criteriaBuilder.desc(mprEntity.get(orderByString)));
	}

	public static Specification<MPREntity> getMPR(Optional<String> effectiveFromDate, Optional<String> effectiveToDate,
			Optional<Boolean> activate) {
		return (mprEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (OptionalUtil.isPresent(effectiveFromDate) && OptionalUtil.isPresent(effectiveToDate)) {
				predicates.add(criteriaBuilder.or(
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
								mprEntity.get("effectiveFromDate"), mprEntity.get("effectiveToDate")),
						criteriaBuilder.between(
								criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
								mprEntity.get("effectiveFromDate"), mprEntity.get("effectiveToDate"))));
			} else {
				if (OptionalUtil.isPresent(effectiveFromDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveFromDate)),
							mprEntity.get("effectiveFromDate"), mprEntity.get("effectiveToDate")));
				}
				if (OptionalUtil.isPresent(effectiveToDate)) {
					predicates.add(criteriaBuilder.between(
							criteriaBuilder.literal(OptionalUtil.getLocalDateValue(effectiveToDate)),
							mprEntity.get("effectiveFromDate"), mprEntity.get("effectiveToDate")));
				}
			}
			if (OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(mprEntity.get("activate"), OptionalUtil.getValue(activate)));
			}
			if (!OptionalUtil.isPresent(activate)) {
				predicates.add(criteriaBuilder.equal(mprEntity.get("activate"), true));
			}
			orderByDesc(mprEntity, criteriaQuery, criteriaBuilder,"effectiveToDate");
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
