package com.sgl.smartpra.batch.mib.app.dao.entitySpec;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;
import com.sgl.smartpra.mib.entity.MiscBillingInvSupportingDocEntity;


public class InvoiceSupportingDocEntitySpec {
	
	private static final String DISPLAYORDER = "attachmentSeq";
	
	private InvoiceSupportingDocEntitySpec() {}
	

	public static Specification<MiscBillingInvSupportingDocEntity> getAttachmentList(String clientId, 
			String invoice_urn) {
		return (miscBillingInvSupportingDocEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
		
				predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("clientId"), clientId));
			
				predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("documentUniqueNo"), invoice_urn));
				
				orderByAsc(miscBillingInvSupportingDocEntity, criteriaQuery, criteriaBuilder, DISPLAYORDER);
				
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}


	public static Specification<MiscBillingInvSupportingDocEntity> search(String clientId, 
			Optional<String> billingMonth,Optional<Integer> billingPeriod,Optional<String> billingCarrier,
			Optional<String> billingType,Optional<String> billedCarrier,Optional<String> transactionType,
			Optional<String> carrierCode,Optional<String> documentNo,Optional<Integer> couponNo,
			Optional<String> memoNo, Optional<String> fimNo) {
		return (miscBillingInvSupportingDocEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
		
				predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("clientId"), clientId));
			
				if(billingMonth.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("billingMonth"), billingMonth.get()));
				}
				if(billingPeriod.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("billingPeriod"), billingPeriod.get()));
				}
				if(billingCarrier.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("billingCarrier"), billingCarrier.get()));
				}
				if(billingType.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("billingType"), billingType.get()));
				}
				if(billedCarrier.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("billedCarrier"), billedCarrier.get()));
				}
				if(transactionType.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("transactionType"), transactionType.get()));
				}
				if(carrierCode.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("carrierCode"), carrierCode.get()));
				}
				if(documentNo.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("documentNo"), documentNo.get()));
				}
				if(couponNo.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("couponNo"), couponNo.get()));
				}
				if(memoNo.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("memoNo"), memoNo.get()));
				}
				if(fimNo.isPresent()) {
					predicates.add(criteriaBuilder.equal(miscBillingInvSupportingDocEntity.get("fimNo"), fimNo.get()));
				}
				orderByAsc(miscBillingInvSupportingDocEntity, criteriaQuery, criteriaBuilder, DISPLAYORDER);
				
			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static void orderByAsc(Root<MiscBillingInvSupportingDocEntity> miscBillingInvSupportingDocEntity, CriteriaQuery<?> criteriaQuery,
			CriteriaBuilder criteriaBuilder, String displayOrder) {
		criteriaQuery.orderBy(criteriaBuilder.asc(miscBillingInvSupportingDocEntity.get(displayOrder)));
	}
}
