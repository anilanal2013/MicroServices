/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ListToBigDecimal;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ObjectToString;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;
import com.sgl.smartpra.mib.jaxb.standard.Tax;

/**
 * @author kanprasa
 *
 */
@Mapper(uses = QualifiedByUtil.class, componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface TaxDetailsMapper {
	
	@Mapping(source = "taxType", target = "taxType", qualifiedBy=ObjectToString.class)
	@Mapping(source = "taxCategory", target = "taxCategory", qualifiedBy=ObjectToString.class)
	@Mapping(source = "taxAmount", target = "taxAmount", qualifiedBy=ListToBigDecimal.class)
	@Mapping(source = "taxPercent", target = "taxPercentage")
	public MiscBillingTaxDetailsEntity mapToEntity(Tax tax);

	@Mapping(source = "taxType", target = "taxType", ignore=true)
	@Mapping(source = "taxCategory", target = "taxCategory", ignore=true)
	@Mapping(source = "taxAmount", target = "taxAmount", ignore=true)
	@Mapping(source = "taxLevel", target = "taxLevel", ignore=true)
	@Mapping(source = "taxPercentage", target = "taxPercent")
	public void mapEntityToTaxDetail(MiscBillingTaxDetailsEntity taxEntity, @MappingTarget Tax tax);

}