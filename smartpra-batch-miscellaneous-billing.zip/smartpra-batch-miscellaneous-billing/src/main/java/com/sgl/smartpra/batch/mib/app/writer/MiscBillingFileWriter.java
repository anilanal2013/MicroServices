package com.sgl.smartpra.batch.mib.app.writer;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.mib.app.processor.MiscBillingValidatorProcessor;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceTransmissionModel;
import com.sgl.smartpra.mib.repository.MiscBillingInvTransHeaderDataRepository;


/**
 * @author kanprasa
 *
 */
@Component
public class MiscBillingFileWriter implements ItemWriter<InvoiceTransmissionModel> {

	private static final Logger log = LoggerFactory.getLogger(MiscBillingFileWriter.class);

	@Autowired
	private MiscBillingInvTransHeaderDataRepository transmissionHeaderRepository;

	@Autowired
	private MiscBillingValidatorProcessor miscBillingValidatorProcessor;

	@Override
	public void write(List<? extends InvoiceTransmissionModel> invoiceTransmissionList) throws Exception {
		log.info("Entering TransmissionHeaderWriter");
		invoiceTransmissionList.forEach( invoiceTransmission -> {
			MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity = invoiceTransmission.getMiscBillingInvTransHeaderEntity();
			List<MiscBillingTrnInvoiceEntity> invoiceEntityList = invoiceTransmission.getMiscBillingTrnInvoiceEntityListList();
			miscBillingInvTransHeaderEntity.setMiscBillingTrnInvoices(invoiceEntityList);
			miscBillingValidatorProcessor.validate(miscBillingInvTransHeaderEntity);
			transmissionHeaderRepository.save(miscBillingInvTransHeaderEntity);
		});
	}
}
