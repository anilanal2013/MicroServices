package com.sgl.smartpra.batch.mib.app.controller;


import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sgl.smartpra.batch.mib.app.service.InvoiceSupportingDocumentService;
import com.sgl.smartpra.mib.domain.MiscBillingInvSupportingDoc;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class InvoiceSupportingDocumentViewController {

	@Autowired
	private InvoiceSupportingDocumentService invoiceSupportingDocumentService;

	@GetMapping("/suppdocview")
	public void viewSupportingDocument(HttpServletRequest request, 
            HttpServletResponse response, 
            @RequestBody MiscBillingInvSupportingDoc miscBillingInvSupportingDoc
            ) throws IOException{
	
	invoiceSupportingDocumentService.viewSupportingDocument(request, response, miscBillingInvSupportingDoc);
      
	}
	
}
