package com.sgl.smartpra.batch.mib.app.validator;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.ChargeCategory;
import com.sgl.smartpra.master.model.CurrencyToleranceDetails;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class InvoiceValidator {

    @SuppressWarnings("rawtypes")
	private final Predicate<List> isNotEmptyList = (w) -> w != null && !w.isEmpty();

    @Autowired
    private CommonValidator commonValidator;
    
    @Autowired
    private LineItemValidator lineItemValidator;
    
    @Autowired
    private TaxDetailsValidator taxDetailValidator;
    
    @Autowired
    private AddOnChargeDetailsValidator addOnChargeDetailsValidator;
    
    @Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
    
    public Multimap<String,ExceptionTransactionModel> validateInvoiceTxn(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity,
            Multimap<String,ExceptionTransactionModel> mErrorCode){
    	String invoiceNo = miscBillingTrnInvoiceEntity.getInvoiceNumber();
    	String invoiceDt = MiscBillingUtil.dateToString(miscBillingTrnInvoiceEntity.getInvoiceDate());
    	LocalDate invoiceDate = MiscBillingUtil.stringToLocalDate(invoiceDt);
    	String currency = miscBillingTrnInvoiceEntity.getCurrencyCode();
    	String chargeCategory = miscBillingTrnInvoiceEntity.getChargeCategoryCode();
    	log.debug("validateInvoiceTxn(): invoiceNo: " + invoiceNo + ", chargeCategory: " + chargeCategory);
    	log.debug("validateInvoiceTxn(): currency: " + currency + ", invoiceDate: " + invoiceDate);
    	List<CurrencyToleranceDetails> currTolList = null;
    	
    	if(commonValidator.getTolDtlMap() == null) {
    		commonValidator.setTolDtlMap(new HashMap<>());
    	}
   		if(commonValidator.getTolDtlMap().get(currency) == null) {
   			currTolList = smartpraMasterAppClient.getListOfCurrencyTolerance(currency, miscBillingTrnInvoiceEntity.getClientId(), null, null);
   			commonValidator.getTolDtlMap().put(currency, currTolList);
    	} else {
    		currTolList = commonValidator.getTolDtlMap().get(currency);
    	}
   		
   		CurrencyToleranceDetails currTolerance  = this.getCurrToleranceDtl(invoiceDate, currTolList);
   		commonValidator.setCurrTolerance(currTolerance);
   		
		String carrierCode = miscBillingTrnInvoiceEntity.getSellerOrganizationId();
		Map<String, String> map;
		this.mandataryValidation(miscBillingTrnInvoiceEntity, mErrorCode);
		
		boolean isCarrierPresent = true;
		if (!validateSellerOrganizationOrganizationID(carrierCode)) {
			map = new HashedMap<>();
			map.put(MiscBillingConstants.BILLING_CARRIER_CODE, carrierCode);
			map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1006);
			isCarrierPresent = false;
		}
		
		if (!validateSettlementIndicatorPaymentTermsSettlementMethod(miscBillingTrnInvoiceEntity.getSettlementMethod(), isCarrierPresent)) {
			commonValidator.setErrorCode(mErrorCode, ErrorCode.MISC1007, MiscBillingConstants.BILLING_CARRIER_CODE, carrierCode);
		}
		
		if (!validateChargeCategory(commonValidator.getChargeCategoryObj())) {
			map = new HashedMap<>();
			map.put(MiscBillingConstants.CHARGE_CATEGORY_CODE, miscBillingTrnInvoiceEntity.getChargeCategoryCode());
			map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1008);
		}
		if (isCorrespondenceDetailsEmpty(miscBillingTrnInvoiceEntity)) {
			commonValidator.setErrorCode(mErrorCode, ErrorCode.MISC1117, MiscBillingConstants.INVOICE_NO, invoiceNo);
		}
		if (isRejectedInvoiceDetailsEmpty(miscBillingTrnInvoiceEntity)) {
			commonValidator.setErrorCode(mErrorCode, ErrorCode.MISC1009, MiscBillingConstants.INVOICE_NO, invoiceNo);
		}
		if (!validateTotalAmount(miscBillingTrnInvoiceEntity)) {
			map = new HashedMap<>();
			map.put("Total Amount", String.valueOf(miscBillingTrnInvoiceEntity.getTotalAmount()));
			map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1010);
		}
		if (!validateLineItemCount(miscBillingTrnInvoiceEntity)) {
			map = new HashedMap<>();
			map.put("Line Item Count", String.valueOf(miscBillingTrnInvoiceEntity.getLineItemCount()));
			map.put("No. of Line item", String.valueOf(miscBillingTrnInvoiceEntity.getMiscBillingInvLineitem().size()));
			map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1011);
		}
		
		List<MiscBillingInvLineitemEntity> lineItemList = miscBillingTrnInvoiceEntity.getMiscBillingInvLineitem();
		boolean isLocDiff = this.isLocationDiffForEachLineItem(lineItemList);
		if(isLocDiff) {
			if(StringUtils.isNotBlank(miscBillingTrnInvoiceEntity.getLocationCode())) {
				map = new HashedMap<>();
				commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1134);
			}
		} else { 
			if(commonValidator.isRequired(commonValidator.getChargeCategoryObj(), MiscBillingPredicates.isLocationCodeRequired())) {
				if(commonValidator.isValueEmpty(miscBillingTrnInvoiceEntity.getLocationCode(), MiscBillingPredicates.isEmptyObject())) {
					map = new HashedMap<>();
					map.put("Charge Code",commonValidator.getChargeCategory());
					map.put("Invoice No.",commonValidator.getInvoiceNo());
					commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC2014);
				}
			}
		}
		
		if (commonValidator.isRequired(commonValidator.getChargeCategoryObj(), MiscBillingPredicates.isPoNumberRequired())) {
			if(commonValidator.isValueEmpty(miscBillingTrnInvoiceEntity.getPoNumber(), MiscBillingPredicates.isEmptyObject())) {
				map = new HashedMap<>();
				map.put("Charge Code",commonValidator.getChargeCategory());
				map.put("Invoice No.",commonValidator.getInvoiceNo());
				commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC2015);
			}
		}
		
		List<MiscBillingInvLineitemEntity> lineItemEntityList = miscBillingTrnInvoiceEntity.getMiscBillingInvLineitem();
		for (MiscBillingInvLineitemEntity lineitemEntity : lineItemEntityList) {
			commonValidator.populateChargeCodeObj(chargeCategory, lineitemEntity.getChargeCode());
			lineItemValidator.validateLineItems(lineitemEntity, mErrorCode);
			commonValidator.setChargeCodeObj(null);
		}
		
		taxDetailValidator.validateTaxDetails(miscBillingTrnInvoiceEntity.getMiscBillingTaxDetails(), mErrorCode, MiscBillingConstants.INVOICE);
		addOnChargeDetailsValidator.validateAddOnDetails(miscBillingTrnInvoiceEntity.getMiscBillingAddOnChargeDtl(), mErrorCode);
		return mErrorCode;
	}

    public Boolean validateSettlementIndicatorPaymentTermsSettlementMethod(String settlementInd, boolean isCarrierPresent){
        if("I".equalsIgnoreCase(settlementInd) || "A".equalsIgnoreCase(settlementInd)) { 
        	if(isCarrierPresent) {
        		return Boolean.TRUE;
        	} else {
        		return Boolean.FALSE;
        	}
        }	
		return Boolean.TRUE;
    }
    
    public Boolean validateSellerOrganizationOrganizationID(String sellerOrganizationId){
    	return (commonValidator.getCarrier() != null 
    			&& sellerOrganizationId.equalsIgnoreCase(commonValidator.getCarrier().getCarrierCode().get())) 
    			? Boolean.TRUE : Boolean.FALSE;
    }

    public Boolean validateChargeCategory(ChargeCategory chargeCategoryObj) {
        return chargeCategoryObj != null ? Boolean.TRUE : Boolean.FALSE;
    }
 
    public Boolean validateTotalAmount(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity) {
        BigDecimal totalAmount = miscBillingTrnInvoiceEntity.getTotalAmount().setScale(2,RoundingMode.HALF_UP);
        BigDecimal total = miscBillingTrnInvoiceEntity.getTotalTaxAmount()
        					.add(miscBillingTrnInvoiceEntity.getTotalVatAmount())
        					.add(miscBillingTrnInvoiceEntity.getTotalAddonChargeAmount())
        					.add(miscBillingTrnInvoiceEntity.getTotalLineItemAmount())
        					.setScale(2, RoundingMode.HALF_UP);
        
        if(commonValidator.getCurrTolerance() != null) {
	        BigDecimal limit = new BigDecimal(commonValidator.getCurrTolerance().getGrossAcceptableVarianceAmt().get());
	        BigDecimal diff = totalAmount.subtract(total);
	        if(Math.abs(diff.doubleValue()) <= limit.doubleValue()) {
	           return Boolean.TRUE;
	        }
        } else {
        	if(totalAmount.compareTo(total) == 0){
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    public Boolean validateRejectionInvoice(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity){
        if (StringUtils.equalsIgnoreCase(miscBillingTrnInvoiceEntity.getRejectionFlag(),"Y") &&
            StringUtils.isBlank(miscBillingTrnInvoiceEntity.getOriginalInvoiceNumber())){
                return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public Boolean isRejectedInvoiceDetailsEmpty(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity){
        if (StringUtils.equalsIgnoreCase(miscBillingTrnInvoiceEntity.getRejectionFlag(),"Y")){
        	if(StringUtils.isEmpty(miscBillingTrnInvoiceEntity.getOriginalInvoiceNumber()) 
            		|| StringUtils.isEmpty(miscBillingTrnInvoiceEntity.getSettlementMonthPeriod())
            		|| miscBillingTrnInvoiceEntity.getRejectionStage() == null 
            		|| miscBillingTrnInvoiceEntity.getRejectionStage() == 0) {
                return Boolean.TRUE;
            }
        } 
        return Boolean.FALSE;
    }

    public Boolean isCorrespondenceDetailsEmpty(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity){
        if (StringUtils.equalsIgnoreCase(miscBillingTrnInvoiceEntity.getCorrespondanceFlag(),"Y")){
            if(StringUtils.isEmpty(miscBillingTrnInvoiceEntity.getOriginalInvoiceNumber()) 
            		|| StringUtils.isEmpty(miscBillingTrnInvoiceEntity.getAuthorityToBillFlag())
            		|| miscBillingTrnInvoiceEntity.getCorrespondanceRefNo() == null 
            		|| miscBillingTrnInvoiceEntity.getCorrespondanceRefNo() == 0) {
                return Boolean.TRUE;
            }
        } 
        return Boolean.FALSE;
    }
    
    public Boolean validateLineItemCount(MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity){
        if(isNotEmptyList.test(miscBillingTrnInvoiceEntity.getMiscBillingInvLineitem())) {
            int count = miscBillingTrnInvoiceEntity.getLineItemCount() == null ? 0 : miscBillingTrnInvoiceEntity.getLineItemCount();
            if (miscBillingTrnInvoiceEntity.getMiscBillingInvLineitem().size() == count) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }
    
    public boolean isLocationDiffForEachLineItem(List<MiscBillingInvLineitemEntity> lineItems) {
    	return lineItems.stream().map(x -> x.getLocationCode()).distinct().count() > 1;
    }
    
    public void mandataryValidation(MiscBillingTrnInvoiceEntity invoiceEntity,
            Multimap<String,ExceptionTransactionModel> mErrorCode){
            	
		commonValidator.requiredValidation(MiscBillingConstants.INVOICE_NO,
				invoiceEntity.getInvoiceNumber(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		
		commonValidator.requiredValidation(MiscBillingConstants.INVOICE_DATE,
				invoiceEntity.getInvoiceDate(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		
		commonValidator.requiredValidation(MiscBillingConstants.INVOICE_TYPE,
				invoiceEntity.getInvoiceType(), mErrorCode, MiscBillingPredicates.isEmptyObject());

		commonValidator.requiredValidation(MiscBillingConstants.CHARGE_CATEGORY_CODE,
				invoiceEntity.getChargeCategoryCode(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		
		commonValidator.requiredValidation(MiscBillingConstants.SELLER_ORG_ID,
				invoiceEntity.getSellerOrganizationId(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		
		commonValidator.requiredValidation(MiscBillingConstants.CURRENCY_CODE,
				invoiceEntity.getCurrencyCode(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		
		commonValidator.requiredValidation(MiscBillingConstants.SETTLEMENT_METHOD,
				invoiceEntity.getSettlementMethod(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		
    }
    
    public CurrencyToleranceDetails getCurrToleranceDtl(LocalDate invoiceDate, List<CurrencyToleranceDetails> currTolList) {
		CurrencyToleranceDetails ctd = null;
		LocalDate effectiveFrom = null;
		LocalDate effectiveTo = null;
		if(currTolList != null && currTolList.size() > 1) {
			for (CurrencyToleranceDetails currencyDtls : currTolList) {
				if(currencyDtls.getEffectiveFromDate().isPresent()) {
					effectiveFrom = MiscBillingUtil.stringToLocalDate(currencyDtls.getEffectiveFromDate().get());
				}
				if(currencyDtls.getEffectiveToDate().isPresent()) {
					effectiveTo = MiscBillingUtil.stringToLocalDate(currencyDtls.getEffectiveToDate().get());
				}
				if(invoiceDate.isAfter(effectiveFrom) && invoiceDate.isBefore(effectiveTo)) {
					ctd = currencyDtls;
				}
			}
		} else if(currTolList != null && currTolList.size() == 1) {
			if(currTolList.get(0).getEffectiveFromDate().isPresent()) {
				effectiveFrom = MiscBillingUtil.stringToLocalDate(currTolList.get(0).getEffectiveFromDate().get());
			}
			if(currTolList.get(0).getEffectiveToDate().isPresent()) {
				effectiveTo = MiscBillingUtil.stringToLocalDate(currTolList.get(0).getEffectiveToDate().get());
			}
			if(invoiceDate.isAfter(effectiveFrom) && invoiceDate.isBefore(effectiveTo)) {
				ctd = currTolList.get(0);
			}
		}
		return ctd;
	}
}
