package com.sgl.smartpra.batch.mib.app.validator;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;

@Component
public class LineItemDetailValidator {

	@Autowired
	private CommonValidator commonValidator;
	
	@Autowired
    private LineItemValidator lineItemValidator;
	
    @Autowired
    private TaxDetailsValidator taxDetailValidator;
    
    @Autowired
    private AddOnChargeDetailsValidator addOnChargeDetailsValidator;
	
	@Autowired
	private SupportingDetailValidator supportingDetailValidator;
	   
	public void validateLineItemsDetails(MiscBillingInvLineitemDtlEntity lineitemDtlEntity, Multimap<String, ExceptionTransactionModel> mErrorCode) {

		MiscBillingInvLineitemEntity lineItemEntity = lineitemDtlEntity.getMiscBillingInvLineitem();
		String invoiceNo = commonValidator.getInvoiceNo();
		Integer lineItemNumber = lineItemEntity.getLineItemNumber();
		Integer lineItemDtlNumber = lineitemDtlEntity.getLineItemDetailNumber();
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.DESCRIPTION,
						lineitemDtlEntity.getDescription(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.END_DATE,
						lineitemDtlEntity.getEndDate(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.QUANTITY,
						lineitemDtlEntity.getQuantity(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.UNIT_PRICE,
						lineitemDtlEntity.getUnitPrice(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		

		if (commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isProductIdRequired())) {
			if(commonValidator.isValueEmpty(lineitemDtlEntity.getProductId(), MiscBillingPredicates.isEmptyObject())) {
				commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.PRODUCT_ID,
							lineitemDtlEntity.getProductId(), mErrorCode, lineItemNumber, 
							lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
			}
		}
		
		Map<String, String> map;
		if (lineitemDtlEntity.getStartDate() != null && !lineItemValidator.validateStartDate(lineitemDtlEntity.getStartDate(), lineitemDtlEntity.getEndDate())) {
			map = new HashedMap<>();
			map.put("Start Date", String.valueOf(lineitemDtlEntity.getStartDate()));
			map.put("End Date", String.valueOf(lineitemDtlEntity.getEndDate()));
			map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1105);
		}
		
		if (lineitemDtlEntity.getEndDate() != null && !lineItemValidator.validateEndDate(lineitemDtlEntity.getStartDate(), lineitemDtlEntity.getEndDate())) {
			map = new HashedMap<>();
			String startDate = lineitemDtlEntity.getStartDate() != null ? String.valueOf(lineitemDtlEntity.getStartDate()) : MiscBillingConstants.EMPTY_STRING;
			map.put("Start Date", startDate);
	    	map.put("End Date", String.valueOf(lineitemDtlEntity.getEndDate()));
	        map.put("Billing Period End date", commonValidator.getBillingPeriodEndDate());
			map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1106);
		}

		if(lineitemDtlEntity.getChargeAmt() == null) {
			commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.CHARGE_AMOUNT,
					lineitemDtlEntity.getChargeAmt(), mErrorCode, lineItemNumber, 
					lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		} else if (!MiscBillingConstants.YES.equalsIgnoreCase(lineitemDtlEntity.getMinQtyFlag()) 
				&& !lineItemValidator.validateChargeAmount(lineitemDtlEntity.getQuantity(),
						lineitemDtlEntity.getUnitPrice(), lineitemDtlEntity.getChargeAmt())) {
			map = new HashedMap<>();
			map.put("Charge Amount", String.valueOf(lineitemDtlEntity.getChargeAmt()));
			map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
			map.put("Quantity", String.valueOf(lineitemDtlEntity.getQuantity()));
			map.put("Unit Price", String.valueOf(lineitemDtlEntity.getUnitPrice()));
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1108);
		}
		
		if(lineitemDtlEntity.getTotalNetAmt() == null) {
			commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.TOTAL_NET_AMOUNT,
				lineitemDtlEntity.getTotalNetAmt(), mErrorCode, lineItemNumber, 
				lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		} else if (!lineItemValidator.validateTotalNetAmount(lineitemDtlEntity.getChargeAmt(),
				lineitemDtlEntity.getTaxAmt(), lineitemDtlEntity.getVatAmt(),
			lineitemDtlEntity.getAddOnChargeAmt(), lineitemDtlEntity.getTotalNetAmt())) {
			map = new HashedMap<>();
			map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
			map.put("Line item No.", String.valueOf(lineitemDtlEntity.getLineItemNumber()));
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1109);
		}

		if (commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isProductIdRequired())) {
			if(commonValidator.isValueEmpty(lineItemEntity.getProductId(), MiscBillingPredicates.isEmptyObject())) {
				map = new HashedMap<>();
				map.put("Charge Code", commonValidator.getChargeCode());
				map.put(MiscBillingConstants.INVOICE_NO, commonValidator.getInvoiceNo());
				commonValidator.setErrorCode(mErrorCode,map, ErrorCode.MISC2016);
			}
		}

		taxDetailValidator.validateTaxDetails(lineitemDtlEntity.getMiscBillingTaxDetails(), mErrorCode, MiscBillingConstants.LINE_ITEM_DETAIL);
		addOnChargeDetailsValidator.validateAddOnDetails(lineitemDtlEntity.getMiscBillingAddOnChargeDtl(), mErrorCode);
		supportingDetailValidator.validateSupportingDetails(mErrorCode, lineItemNumber,
				lineitemDtlEntity.getLineItemDetailNumber(), lineitemDtlEntity.getMiscBillingSupportingDetail());
				
	}
}
