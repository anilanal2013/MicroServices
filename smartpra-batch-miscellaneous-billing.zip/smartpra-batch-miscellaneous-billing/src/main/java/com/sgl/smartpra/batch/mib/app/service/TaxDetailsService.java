/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.mib.app.mapper.TaxDetailsMapper;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;
import com.sgl.smartpra.mib.jaxb.dictionary.TaxCategory;
import com.sgl.smartpra.mib.jaxb.dictionary.TaxLevel;
import com.sgl.smartpra.mib.jaxb.dictionary.TaxType;
import com.sgl.smartpra.mib.jaxb.standard.Tax;
import com.sgl.smartpra.mib.jaxb.standard.TaxAmount;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class TaxDetailsService {
	
	@Autowired
	private TaxDetailsMapper taxDetailsMapper;
	
	public List<Tax> getTaxDetails(List<MiscBillingTaxDetailsEntity> taxEntityList) {
		List<Tax> taxList = new ArrayList<>();
		for (MiscBillingTaxDetailsEntity taxEntity : taxEntityList) {
			Tax tax = new Tax();
			taxDetailsMapper.mapEntityToTaxDetail(taxEntity, tax);
			tax.setTaxType(TaxType.fromValue(taxEntity.getTaxType()));
			tax.setTaxCategory(TaxCategory.fromValue(taxEntity.getTaxCategory()));
			tax.setTaxLevel(TaxLevel.fromValue(taxEntity.getTaxLevel()));
			TaxAmount taxAmount = new TaxAmount();
			taxAmount.setValue(taxEntity.getTaxAmount());
			tax.getTaxAmount().add(taxAmount);
			taxList.add(tax);
		}
		return taxList;
	}
}
