package com.sgl.smartpra.batch.mib.app.config.batch;

import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLStreamException;

import org.springframework.batch.item.xml.StaxEventItemWriter;

public class NoRootStaxEventItemWriter<T> extends StaxEventItemWriter<T> {

    /*
     * Methods
     */
    @Override
    protected void startDocument(XMLEventWriter writer) throws XMLStreamException {
        XMLEventFactory factory = createXmlEventFactory();

        // write start document
        writer.add(factory.createStartDocument(getEncoding(), getVersion()));
    }

    @Override
    protected void endDocument(XMLEventWriter writer) { 
    	/* We need to skip the endDocument hence this method is empty. */
    }

}