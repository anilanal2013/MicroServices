package com.sgl.smartpra.batch.mib.app.service;

import java.util.HashMap;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.batch.mib.app.validator.InvoiceValidator;
import com.sgl.smartpra.excep.resolution.model.ExceptionValidationModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.repository.MiscBillingTrnInvoiceDataRepository;
import com.sgl.smartpra.mib.utils.MiscBillingCommonUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class InwardInvoiceService {
	
	@Autowired
	private MiscBillingTrnInvoiceDataRepository invoiceRepository;
	
	@Autowired
	private InvoiceValidator invoiceValidator;
	
    @Autowired
    private CommonValidator commonValidator;
    
    @Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	public MiscBillingTrnInvoiceEntity getInvoice(String invoiceUrn) {
		Optional<MiscBillingTrnInvoiceEntity> invoiceEntity = invoiceRepository.findById(invoiceUrn);
		if(invoiceEntity.isPresent()) {
			return invoiceEntity.get();
		}
		return null;
	}
	
	public ExceptionValidationModel getReValidationResults(ExceptionValidationModel exceptionValidationModel) {
		
		HashMap<String, String> errors = new HashMap<>();
		MiscBillingTrnInvoiceEntity invoiceEntity = null;
		String invoiceUrn = exceptionValidationModel.getInvoiceUrn();
		if(StringUtils.isBlank(invoiceUrn)) {
			errors.put(MiscBillingConstants.INVOICE_URN, MiscBillingConstants.MANDATORY_INVOICE_URN);
		} else {
			invoiceEntity = this.getInvoice(invoiceUrn);
			if(invoiceEntity == null) {
				errors.put(invoiceUrn, MiscBillingConstants.INVALID_INVOICE_URN);
			}
		}
		
		if(!errors.isEmpty()) {
			exceptionValidationModel.setValidationStatus(false);
			exceptionValidationModel.setErrors(errors);
			return exceptionValidationModel;
		}
		
		OutwardBillingPeriods outwardBillingPeriods = null;
		try {
			if(invoiceEntity != null) {
				outwardBillingPeriods = smartpraMasterAppClient.getCurrentOpenOutwardBillingPeriods(invoiceEntity.getClientId());
				commonValidator.setBillingPeriodEndDate(MiscBillingCommonUtil.convertLocalDateToString("yyyy-MM-dd", outwardBillingPeriods.getEndDate()));
			}
		} catch (Exception e) {
			log.error("Exception thrown while calling getCurrentOpenOutwardBillingPeriods(clientId): " + e.getMessage());
			e.printStackTrace();
		}
		
		commonValidator.populateCommonFields(MiscBillingConstants.INWARD, invoiceEntity);
		Multimap<String,ExceptionTransactionModel> mErr = ArrayListMultimap.create();
		invoiceValidator.validateInvoiceTxn(invoiceEntity, mErr);
		commonValidator.reset();
		
		if(mErr != null && !mErr.isEmpty()) {
			mErr.asMap().forEach((k,v) -> v.forEach(w -> {
				try {
					log.debug("key: " + k + ", value: " + w.getExceptionCode() + ", invoiceNo: " + w.getBatchKey4());
					errors.put(w.getExceptionCode(), "Y");
				} catch (Exception e) {
					log.error(e.getMessage());
				}
			}));
		}
		
		if(errors.isEmpty()) {
			exceptionValidationModel.setValidationStatus(true);
		} else {
			exceptionValidationModel.setValidationStatus(false);
			exceptionValidationModel.setErrors(errors);
		}
		
		return exceptionValidationModel;
	}
}
