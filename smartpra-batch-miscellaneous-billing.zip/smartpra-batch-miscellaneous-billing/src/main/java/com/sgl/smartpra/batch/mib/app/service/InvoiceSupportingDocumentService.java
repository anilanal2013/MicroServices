package com.sgl.smartpra.batch.mib.app.service;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.sgl.smartpra.batch.mib.app.dao.InvoiceSupportingDocumentDao;
import com.sgl.smartpra.batch.mib.app.mapper.MiscBillingInvSupportingDocMapper;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.exceptions.exception.RecordAlreadyExistsException;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.mib.domain.MiscBillingInvSupportingDoc;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class InvoiceSupportingDocumentService {
	
	@Value("${batch.directory.supporting-doc.temp}")
	private String suppDocBatchTempDir;

	@Autowired
	private InvoiceSupportingDocumentDao invoiceSupportingDocumentDao;
	
	@Autowired
	private MiscBillingInvSupportingDocMapper miscBillingInvSupportingDocMapper;
	
	@Autowired
	private SupportingDocService supportingDocService;
	
	public List<MiscBillingInvSupportingDoc> search( String clientId, Optional<String> billingMonth,Optional<Integer> billingPeriod,Optional<String> billingCarrier,Optional<String> billingType,Optional<String> billedCarrier,Optional<String> transactionType,Optional<String> carrierCode,Optional<String> documentNo,Optional<Integer> couponNo,Optional<String> memoNo, Optional<String> fimNo)  {
		
		return miscBillingInvSupportingDocMapper.mapToModel(invoiceSupportingDocumentDao.search(clientId, billingMonth, billingPeriod, billingCarrier, billingType, billedCarrier, transactionType, carrierCode, documentNo, couponNo, memoNo, fimNo));
		
	}
	
	public List<MiscBillingInvSupportingDoc> getAttachmentList( String clientId, String invoice_urn){
		
		return miscBillingInvSupportingDocMapper.mapToModel(invoiceSupportingDocumentDao.getAttachmentList(clientId, invoice_urn));
	}
	
	private MiscBillingInvSupportingDoc createRecord(String clientId, String billingMonth,Integer billingPeriod,
			String buyerId,String sellerId,String inwardOutwardFlag,String batchNo, Optional<String> createdBy,String fileName) {
		
		MiscBillingInvSupportingDoc miscBillingInvSupportingDoc = new MiscBillingInvSupportingDoc();
		
		miscBillingInvSupportingDoc.setClientId(clientId);
		miscBillingInvSupportingDoc.setDocumentUniqueNo(batchNo);
		miscBillingInvSupportingDoc.setBillingType(inwardOutwardFlag);
		miscBillingInvSupportingDoc.setBillingMonth(billingMonth);
		miscBillingInvSupportingDoc.setBillingPeriod(billingPeriod);
		/*Buyer Organization id & Seller Organization ID  are there.
		in case of Inward invoices  Buyer is Host carrier (Billed) and Seller is other carriers (Billing)*/
		miscBillingInvSupportingDoc.setBilledCarrier((inwardOutwardFlag.equalsIgnoreCase
				(MiscBillingConstants.INWARD)?buyerId:sellerId));
		miscBillingInvSupportingDoc.setBillingCarrier((inwardOutwardFlag.equalsIgnoreCase
				(MiscBillingConstants.INWARD)?sellerId:buyerId));
		miscBillingInvSupportingDoc.setTransactionType(MiscBillingConstants.SUPP_DOC_TRANSACTION_TYPE);
		miscBillingInvSupportingDoc.setBatchKey(batchNo);
		miscBillingInvSupportingDoc.setTransactionRefNo(batchNo);
		miscBillingInvSupportingDoc.setCreatedBy(createdBy); //since to save
		miscBillingInvSupportingDoc.setCreatedDate(LocalDateTime.now());
		 miscBillingInvSupportingDoc.setFileName(fileName);
    	 miscBillingInvSupportingDoc.setAttachmentType(getFileExtension(fileName).get());
    	 miscBillingInvSupportingDoc.setFilePath(suppDocBatchTempDir);
    	 miscBillingInvSupportingDoc.setAttachmentSeq(getAttachmentList(clientId,batchNo).size() + 1);
    	 
		return miscBillingInvSupportingDoc;
	}
	
	public MiscBillingInvSupportingDoc saveSupportingDocument(String clientId, String billingMonth,Integer billingPeriod,
			String buyerId,String sellerId,String inwardOutwardFlag,String batchNo, Optional<String> createdBy,
			List<MultipartFile> supportingDocuments) throws Exception {
				
		MiscBillingInvSupportingDoc miscBillingInvSupportingDoc = null;
		
		String directoryPath = getDirectorypath(suppDocBatchTempDir,clientId, billingMonth, billingPeriod.toString(), 
				(inwardOutwardFlag.equalsIgnoreCase(MiscBillingConstants.INWARD)?buyerId:sellerId), inwardOutwardFlag, 
				(inwardOutwardFlag.equalsIgnoreCase(MiscBillingConstants.INWARD)?sellerId:buyerId),batchNo);
			
				
		//create the directory if not exists
		if(!Files.exists(Paths.get(directoryPath))) {
		
			Files.createDirectories(Paths.get(directoryPath));
		}
		
		//save the file in directory structure
		if(supportingDocuments.size()==0) {
			return null;
		}
		
		for(MultipartFile document:supportingDocuments) {
			
			Map<String,String> sysParamMap = supportingDocService.populateSystemParameters(clientId);
			
			int fileNameLength = Integer.parseInt(sysParamMap.get("SIS_ATTACHMENT_FILE_LENGTH"));
			String fileType = sysParamMap.get("SIS_ATTACHMENT_FILETYPE");
			
			if(!(document.getOriginalFilename().length() <= fileNameLength)) {
				throw new Exception("File Name cannot be more than 65 characters");
			}
			
			if(!(fileType.contains(getFileExtension(document.getOriginalFilename()).get().toUpperCase()))) {
				throw new Exception("Please choose any one of the File types -" + fileType);
			}
			
			byte[] bytes;
			bytes = document.getBytes();
			
	         Path path = Paths.get(directoryPath +  document.getOriginalFilename());
	         if(Files.exists(path)) {
	        	throw new RecordAlreadyExistsException(document.getOriginalFilename());
	         }
	         else {
	        	  miscBillingInvSupportingDoc = save(createRecord( clientId,  billingMonth, billingPeriod,
	        			 buyerId, sellerId, inwardOutwardFlag, batchNo, createdBy,document.getOriginalFilename() ));    
	        	 
	        	Files.write(path, bytes);
	        	 
	         }
	         
		}
		return miscBillingInvSupportingDoc;
	}
	
	public MiscBillingInvSupportingDoc save(MiscBillingInvSupportingDoc miscBillingInvSupportingDoc) {
		return miscBillingInvSupportingDocMapper.mapToModel(invoiceSupportingDocumentDao.save(miscBillingInvSupportingDocMapper.mapToEntity(miscBillingInvSupportingDoc)));
	}
	
		
	public String deleteSupportingDocument(List<MiscBillingInvSupportingDoc> miscBillingInvSupportingDocList) throws IOException {

		for(MiscBillingInvSupportingDoc miscBillingInvSupportingDoc :miscBillingInvSupportingDocList) {
			String directoryPath = getDirectorypath(miscBillingInvSupportingDoc.getFilePath(),miscBillingInvSupportingDoc.getClientId(), miscBillingInvSupportingDoc.getBillingMonth(), 
					miscBillingInvSupportingDoc.getBillingPeriod().toString(), miscBillingInvSupportingDoc.getBillingCarrier(), miscBillingInvSupportingDoc.getBillingType(),
					miscBillingInvSupportingDoc.getBilledCarrier(), miscBillingInvSupportingDoc.getDocumentUniqueNo());
		
			 Path path = Paths.get( directoryPath +  miscBillingInvSupportingDoc.getFileName());
			 if(Files.deleteIfExists(path)) {				
				 invoiceSupportingDocumentDao.delete(miscBillingInvSupportingDocMapper.mapToEntity(miscBillingInvSupportingDoc));
	         }
	         else {
	        	 throw new RecordNotFoundException(miscBillingInvSupportingDoc.getFileName());
	         }
		}

		return "Files has been deleted successfully";
	}
	
	public void viewSupportingDocument(HttpServletRequest request, HttpServletResponse response, MiscBillingInvSupportingDoc miscBillingInvSupportingDoc) throws IOException {
				
		String directoryPath = getDirectorypath(miscBillingInvSupportingDoc.getFilePath(),miscBillingInvSupportingDoc.getClientId(), miscBillingInvSupportingDoc.getBillingMonth(), 
				miscBillingInvSupportingDoc.getBillingPeriod().toString(), miscBillingInvSupportingDoc.getBillingCarrier(), miscBillingInvSupportingDoc.getBillingType(),
				miscBillingInvSupportingDoc.getBilledCarrier(), miscBillingInvSupportingDoc.getDocumentUniqueNo());
	
		//String fileName = fileList.get(Integer.parseInt(index));
		
		Path file = Paths.get(directoryPath, miscBillingInvSupportingDoc.getFileName() );
			
	        if (Files.exists(file)) 
	        {
	        	Optional<String> fileExtension = getFileExtension(miscBillingInvSupportingDoc.getFileName());
	            response.setContentType(getContentType(fileExtension.isPresent()?fileExtension.get().toLowerCase():"text/html"));
	            response.addHeader("Content-Disposition", "inline; filename="+miscBillingInvSupportingDoc.getFileName());
	            
	             Files.copy(file, response.getOutputStream());
	             response.getOutputStream().flush();

	        }
	}
	
	private String getContentType(String extension) {
		
		switch(extension) {
		case "pdf":
			return "application/pdf";
		case "xls":
			return "application/vnd.ms-excel";
		case "xlsx":
			return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		case "xml":	
			return "application/xml";
		case "jpeg":
		case "jpg":
			return "image/jpeg";   
		case "png":
			return "image/png";  
		case "tiff":
			return "image/tiff"; 
		case "doc":
			return "application/msword";
		case "docx":
			return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
		case "txt":
			return "text/plain";
		case "csv":
			return "text/csv";
		default:
			return "text/html";
		
		}
	}
	
	private Optional<String> getFileExtension(String filename) {
		
		return Optional.ofNullable(filename)
			      .filter(f -> f.contains("."))
			      .map(f -> f.substring(filename.lastIndexOf(".") + 1));
	}

	private String getDirectorypath(String rootDir,String clientId, String billingMonth,String billingPeriod,String billingCarrier,String billingType,String billedCarrier,String batchNo) {
		StringBuilder directoryPath = new StringBuilder();
		directoryPath.append(rootDir + File.separator);
		directoryPath.append(billingCarrier + File.separator);
		directoryPath.append(billingMonth + File.separator);
		directoryPath.append(billingPeriod + File.separator);
		directoryPath.append(billedCarrier + File.separator);
		directoryPath.append(billingType + File.separator);
		directoryPath.append(batchNo + File.separator);
		
		return directoryPath.toString();
	}

}
