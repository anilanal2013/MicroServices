package com.sgl.smartpra.batch.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.mib.domain.MiscBillingInvSupportingDoc;
import com.sgl.smartpra.mib.entity.MiscBillingInvSupportingDocEntity;

@Mapper(componentModel = "Spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface MiscBillingInvSupportingDocMapper extends BaseMapper<MiscBillingInvSupportingDoc,MiscBillingInvSupportingDocEntity>{

	
}
