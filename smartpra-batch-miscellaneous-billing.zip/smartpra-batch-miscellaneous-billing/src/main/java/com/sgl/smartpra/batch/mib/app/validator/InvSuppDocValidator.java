/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.validator;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraExceptionTransIntgAppClient;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.batch.mib.app.service.SupportingDocService;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.CarrierInterlineDetailsModel;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.repository.MiscBillingTrnInvoiceDataRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class InvSuppDocValidator {
	
	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	private MiscBillingTrnInvoiceDataRepository invoiceRepository;
	
	@Autowired
	private SmartpraExceptionTransIntgAppClient smartpraExceptionTransIntgAppClient;
	
	@Autowired
	private SupportingDocService supportingDocService;

	public boolean isValidFileFormat(String filename) {
		// OAR-MISC-P-157-20181001.ZIP
		boolean result = false;
		if(StringUtils.isNoneBlank(filename)) {
			List<String> list =  Arrays.asList(filename.split("-"));
			if(CollectionUtils.isEmpty(list) || list.size() != 5) {
				log.debug("Invalid fileFormat of file: " + filename + ", Correct format: OAR-XXXX-A-BBB-CCCCCCCC.ZIP ");
			} else {
				if("OAR".equalsIgnoreCase(list.get(0)) && "MISC".equalsIgnoreCase(list.get(1)) 
				  && "P".equalsIgnoreCase(list.get(2)) && Pattern.matches("[0-9]{3}", list.get(3))
				  && Pattern.matches("[0-9]{8}.zip", list.get(4))){
					result = true;
					log.debug("FileFormat of file: " + filename + " is valid. ");
				}
			}
		} else {
			log.debug("Filename given is blank.");
		}
		return result;
	}
	
	public boolean validateCarrierCodeInFilename(String filename, String hostNumericCode) {
		// OAR-MISC-P-157-20181001.ZIP
		boolean result = false;
		if(StringUtils.isNoneBlank(filename)) {
			List<String> list =  Arrays.asList(filename.split("-"));
			if(CollectionUtils.isEmpty(list) || list.size() != 5) {
				log.debug("Invalid fileFormat of file: " + filename + ", Correct format: OAR-XXXX-A-BBB-CCCCCCCC.ZIP ");
			} else {
				if(StringUtils.equals(list.get(3), hostNumericCode)){
					result = true;
					log.debug("Host numeric code in file is valid: " + list.get(3));
				}
			}
		} else {
			log.debug("Filename given is blank.");
		}
		return result;
	}
	
	public boolean validateMainFolderDetailsWithBillingPeriod(String filename) {
		// OAR-MISC-P-157-20181001.ZIP
		boolean result = false;
		if(StringUtils.isNoneBlank(filename)) {
			List<String> list =  Arrays.asList(filename.split("-"));
			if(CollectionUtils.isEmpty(list) || list.size() != 5) {
				log.debug("Invalid fileFormat of file: " + filename + ", Correct format: OAR-XXXX-A-BBB-CCCCCCCC.ZIP ");
			} else {
				String yyyymmdd = list.get(4).substring(0, 8);
				log.debug("Billing period: " + yyyymmdd);
				if(Pattern.matches("[0-9]{8}", yyyymmdd)){
					result = true;
					log.debug("Billing period is valid: " + yyyymmdd);
				}
			}
		} else {
			log.debug("Filename given is blank.");
		}
		return result;
		
	}
	
	public MiscBillingTrnInvoiceEntity getInvoiceEntity(String clientId, String invoiceNo) {
		Optional<MiscBillingTrnInvoiceEntity> invoiceEntity = Optional.empty();
		String invoiceUrn = invoiceRepository.getInvoiceUrn(clientId, invoiceNo);
		if(StringUtils.isNotBlank(invoiceUrn)) {
			log.debug("Valid = " + invoiceNo + " = " + invoiceUrn);
			invoiceEntity = invoiceRepository.findById(invoiceUrn);
		} else {
			log.debug("InValid = " + invoiceNo + " = " + " Not found");
		}
		return invoiceEntity.isPresent() ? invoiceEntity.get() : null;
	}
	
	// OAR-MISC-P-157-20181001.ZIP
	public Multimap<String,ExceptionTransactionModel> validateMainFolder(String zipFilename, String clientId, String hostNumericCode, Integer fileId) {
		
		Multimap<String, ExceptionTransactionModel> errorMap = ArrayListMultimap.create();
		Map<String, String> map = new HashedMap<>();
		if(!isValidFileFormat(zipFilename)) {
     		map.put(MiscBillingConstants.OAR_FILE_FORMAT, zipFilename); 
     		errorMap.put(ErrorCode.INWD1049.toString(), this.prepareExceptionTransactionModel(ErrorCode.INWD1049.toString(), clientId, null, 
     				hostNumericCode, fileId, null, null, null, null, map));
		}
		if(!validateCarrierCodeInFilename(zipFilename, hostNumericCode)) {	
			map = new HashedMap<>();
     		map.put(MiscBillingConstants.BILLED_CARIER, hostNumericCode); 
     		errorMap.put(ErrorCode.INWD1050.toString(), this.prepareExceptionTransactionModel(ErrorCode.INWD1050.toString(), clientId, null, 
     				hostNumericCode, fileId, null, null, null, null, map));
		}
		if(!validateMainFolderDetailsWithBillingPeriod(zipFilename)) {	
			map = new HashedMap<>();
     		map.put(MiscBillingConstants.MAIN_FOLDER, zipFilename); 
     		errorMap.put(ErrorCode.INWD1052.toString(), this.prepareExceptionTransactionModel(ErrorCode.INWD1052.toString(), clientId, null, 
     				hostNumericCode, fileId, null, null, null, null, map));
		}
		return errorMap;
	}
	
	public String validateBillingCarrierWithInterlineDetails(String hostNumericCode, Integer fileId, 
			String clientId, List<String> list, Optional<String> date, Multimap<String, ExceptionTransactionModel> errorMap) {
		
		log.debug("In validateBillingCarrierWithInterlineDetails(): ");
		String billingNumerCarrierCode = MiscBillingConstants.EMPTY_STRING;
		// 9W-589
		Optional<String> billingCarrier = list.stream().filter(x -> Pattern.matches("[a-zA-Z0-9]{1}[a-zA-Z0-9]{1}-[0-9]{3}", x)).findFirst();
				
		if (billingCarrier.isPresent()) {
			billingNumerCarrierCode = billingCarrier.get().substring(3);
			List<CarrierInterlineDetailsModel> carrierList = smartpraMasterAppClient
					.getListOfCarrierInterlineDetailsByEffectiveDate(billingNumerCarrierCode, clientId, null);
			if (CollectionUtils.isNotEmpty(carrierList)) {
				Optional<CarrierInterlineDetailsModel> carrier = carrierList.stream()
						.filter(x -> x.getMiscSis().isPresent() ? x.getMiscSis().get() : Boolean.FALSE).findAny();
				if (carrier.isPresent()) {
					LocalDate fromDate = MiscBillingUtil.stringToLocalDate(carrier.get().getEffectiveFromDate().get());
					LocalDate toDate = MiscBillingUtil.stringToLocalDate(carrier.get().getEffectiveToDate().get());
					LocalDate billingPeriodDate = MiscBillingUtil.stringToLocalDate(date.get(), "yyyyMMdd");
					if (billingPeriodDate.isBefore(fromDate) || billingPeriodDate.isAfter(toDate)) {
						Map<String, String> map = new HashedMap<>();
			     		map.put(MiscBillingConstants.CARRIER_CODE, billingNumerCarrierCode); 
			     		errorMap.put(MiscBillingConstants.EMPTY_STRING, this.prepareExceptionTransactionModel(ErrorCode.INWD1053.toString(), clientId, billingNumerCarrierCode, 
			     				hostNumericCode, fileId, MiscBillingConstants.EMPTY_STRING, MiscBillingConstants.EMPTY_STRING, 
			     				null, null, map));
					}
				}
			}
		}
		return billingNumerCarrierCode;
	}
	
	public ExceptionTransactionModel prepareExceptionTransactionModel(String exceptionCode, String clientId, String billingCarrierNumCode, 
			String hostNumericCode, Integer fileId, String invoiceNo, String batchNo, String invDate, String billingPeriodEndDate, 
			Map<String,String> paremNameValueMap) {
		
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setExceptionCode(exceptionCode);
		exceptionTransactionModel.setCreatedBy(MiscBillingConstants.CREATEDBY);
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setClientId(clientId);
		exceptionTransactionModel.setEnvironment("P"); //production data.
		if(fileId != null) {
			exceptionTransactionModel.setFileId(Long.valueOf(fileId));
		}
		exceptionTransactionModel.setBatchKey1(billingCarrierNumCode);
		exceptionTransactionModel.setBatchKey2(hostNumericCode);
		exceptionTransactionModel.setBatchKey3(null);
		exceptionTransactionModel.setBatchKey4(invoiceNo);
		exceptionTransactionModel.setInvoiceUrn(batchNo);
		
		try {
			LocalDate invoiceDate = MiscBillingUtil.stringToLocalDate(invDate);
			LocalDate bped = MiscBillingUtil.stringToLocalDate(billingPeriodEndDate);
			
			LocalDateTime invoiceDateLT = (invoiceDate != null) ? invoiceDate.atTime(LocalTime.now()) : null;
			LocalDateTime bpedLT = (bped != null) ? bped.atTime(LocalTime.now()) : null;
			
			exceptionTransactionModel.setBatchKey5(invoiceDateLT);
			exceptionTransactionModel.setBatchKey6(bpedLT);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
		if (paremNameValueMap != null) {
			paremNameValueMap.forEach((key, value) -> {
				final ExceptionParametersValueModel parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName(key);
				parametersValueModel.setParameterValue(value);
				parametersValueModelList.add(parametersValueModel);
			});
		}

		exceptionTransactionModel.setParametersValueList(parametersValueModelList);

		return exceptionTransactionModel;
	}
	
	public void saveSuppDocError(Multimap<String, ExceptionTransactionModel> mErr) {
		log.debug("In saveSuppDocError(): ");
		if(mErr != null && !mErr.isEmpty()) {
			log.debug("saveSuppDocError() - count: " + mErr.size());
			mErr.asMap().forEach((k,v) -> v.forEach(w -> {
				try {
					log.debug("key: " + k + ", value: " + w.getExceptionCode() + ", invoiceNo: " + w.getBatchKey4());
					smartpraExceptionTransIntgAppClient.initExceptionTrasaction(w);
				} catch (Exception e) {
					log.error(e.getMessage());
				}
			}));
		}
	}

}
