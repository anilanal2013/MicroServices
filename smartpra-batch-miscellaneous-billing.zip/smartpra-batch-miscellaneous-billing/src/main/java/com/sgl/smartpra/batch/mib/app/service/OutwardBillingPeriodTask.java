/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.mib.utils.MiscBillingCommonUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Scope(value = "step")
@Service
@Slf4j
public class OutwardBillingPeriodTask implements Tasklet{

	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
    private CommonValidator commonValidator;
	
	@Autowired
	private FileLoggingService fileLoggingService;

	public OutwardBillingPeriodTask(SmartpraMasterAppClient smartpraMasterAppClient, 
			CommonValidator commonValidator, FileLoggingService fileLoggingService) {
    	this.smartpraMasterAppClient = smartpraMasterAppClient;
    	this.commonValidator = commonValidator;
    	this.fileLoggingService = fileLoggingService;
    }
	
	@Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
    	log.debug("#################### Entering OutwardBillingService Tasklet ####################");
    	StepExecution stepExecution = chunkContext.getStepContext().getStepExecution();
    	JobParameters jobParameters = stepExecution.getJobParameters();
		String clientId = jobParameters.getString("clientId");
		OutwardBillingPeriods outwardBillingPeriods = null;
		String carrierDesignatorCode = MiscBillingUtil.getHostCarrierDesigCode(smartpraMasterAppClient);
		String hostCarrierCode = MiscBillingUtil.getHostCarrierCode(smartpraMasterAppClient, carrierDesignatorCode);

		FileLogging fileLogging = null;
		try {
			fileLogging = fileLoggingService.createFileLogging(clientId, 
					carrierDesignatorCode, hostCarrierCode, "outwardXmlJob", 
					MiscBillingConstants.EMPTY_STRING, "Manual");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if(fileLogging != null) {
			commonValidator.setFileId(fileLogging.getFileId().intValue());
		}
		try {
			outwardBillingPeriods = smartpraMasterAppClient.getCurrentOpenOutwardBillingPeriods(clientId);
		} catch (Exception e) {
			log.error("Exception thrown while calling getCurrentOpenOutwardBillingPeriods(clientId): " + e.getMessage());
			e.printStackTrace();
		}
		if(outwardBillingPeriods != null) {
			log.debug("BillingMonth: " + outwardBillingPeriods.getBillingMonth() + ", BillingPeriod: " + outwardBillingPeriods.getBillingPeriod());
			commonValidator.setBillingMonth(outwardBillingPeriods.getBillingMonth());
			commonValidator.setBillingPeriod(outwardBillingPeriods.getBillingPeriod());
			commonValidator.setClientId(outwardBillingPeriods.getClientId());
    		commonValidator.setBillingPeriodEndDate(MiscBillingCommonUtil.convertLocalDateToString("yyyy-MM-dd", outwardBillingPeriods.getEndDate()));
		}
        log.debug("#################### Exiting OutwardBillingService Tasklet ####################");
        return RepeatStatus.FINISHED;
    }
}