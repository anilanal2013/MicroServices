package com.sgl.smartpra.batch.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.BillingMonth;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.BillingPeriod;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ObjectToString;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.StringToDate;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceHeader;

@Mapper(uses = QualifiedByUtil.class, componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface InvoiceHeaderMapper {
	
	@Mapping(source = "invoiceDate", target = "invoiceDate", qualifiedBy=StringToDate.class)
	@Mapping(source = "taxPointDate", target = "taxPointDate", qualifiedBy=StringToDate.class)
	@Mapping(source = "invoiceType", target = "invoiceType", qualifiedBy=ObjectToString.class)
	@Mapping(source = "chargeCategory", target = "chargeCategoryCode")	
	@Mapping(source = "sellerOrganization.organizationID", target = "sellerOrganizationId")
	@Mapping(source = "sellerOrganization.locationID", target = "sellerLocationId")
	@Mapping(source = "paymentTerms.currencyCode", target = "currencyCode")
	@Mapping(source = "paymentTerms.clearanceCurrencyCode", target = "clearanceCurrencyCode")
	@Mapping(source = "paymentTerms.exchangeRate", target = "exchangeRate")
	@Mapping(source = "paymentTerms.settlementMonthPeriod", target = "settlementMonthPeriod")
	@Mapping(target = "settlementMethod", source="paymentTerms.settlementMethod", qualifiedBy = ObjectToString.class)
	@Mapping(target = "digitalSignatureFlag", source="ISDetails.digitalSignatureFlag", qualifiedBy = ObjectToString.class)
	@Mapping(target = "suspendedFlag", source="ISDetails.suspendedFlag", qualifiedBy = ObjectToString.class)
	@Mapping(source = "ISDetails.ISValidationFlag", target = "isValidationFlag")
	@Mapping(target = "rejectionFlag", source="ISDetails.rejectionFlag", qualifiedBy = ObjectToString.class)
	@Mapping(source = "ISDetails.rejectedInvoiceDetails.rejectionStage", target = "rejectionStage")	
	@Mapping(source = "paymentTerms.settlementMonthPeriod", target = "billingMonth", qualifiedBy = BillingMonth.class) 
	@Mapping(source = "paymentTerms.settlementMonthPeriod", target = "billingPeriod", qualifiedBy = BillingPeriod.class)
	@Mapping(source = "ISDetails.rejectedInvoiceDetails.settlementMonthPeriod", target = "orginalBillingMonth", qualifiedBy = BillingMonth.class) 
	@Mapping(source = "ISDetails.rejectedInvoiceDetails.settlementMonthPeriod", target = "originalBillingPeriod", qualifiedBy = BillingPeriod.class)
	@Mapping(target = "correspondanceFlag", source="ISDetails.correspondenceFlag", qualifiedBy = ObjectToString.class)
	@Mapping(target = "authorityToBillFlag", source="ISDetails.correspondenceDetails.authorityToBillFlag", qualifiedBy = ObjectToString.class)												 
	@Mapping(source = "layout.description", target = "description")
	@Mapping(target = "invoiceStatus", constant="OP")
	@Mapping(target = "inwardOutwardFlag", constant="I")
	public void mapInvoiceHeaderToEntity(InvoiceHeader invoiceHeader, @MappingTarget MiscBillingTrnInvoiceEntity invoiceEntity);

	@Mapping(source = "invoiceType", target = "invoiceType", ignore=true)
	@Mapping(source = "invoiceDate", target = "invoiceDate", qualifiedBy=ObjectToString.class)
	@Mapping(source = "taxPointDate", target = "taxPointDate", qualifiedBy=ObjectToString.class)
	@Mapping(source = "currencyCode", target = "paymentTerms.currencyCode")
	@Mapping(source = "clearanceCurrencyCode", target = "paymentTerms.clearanceCurrencyCode")
	@Mapping(source = "exchangeRate", target = "paymentTerms.exchangeRate")
	@Mapping(source = "description", target = "layout.description")
	public void mapEntityToInvoiceHeader(MiscBillingTrnInvoiceEntity invoiceEntity, @MappingTarget InvoiceHeader invoiceHeader);

}