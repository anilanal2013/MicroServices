package com.sgl.smartpra.batch.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.jaxb.standard.TransmissionSummary;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface TransmissionSummaryMapper {

	@Mapping(source = "invoiceCount", target = "invoiceCount", defaultValue="0")
	@Mapping(source = "attachmentCount", target = "attachmentCount", defaultValue="0")
	public void mapTransmissionSummaryToEntity(TransmissionSummary transmissionSummary, @MappingTarget MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity);

}
