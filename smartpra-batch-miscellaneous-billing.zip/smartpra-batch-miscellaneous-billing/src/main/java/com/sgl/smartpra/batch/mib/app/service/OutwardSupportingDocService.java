/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.batch.mib.app.utils.ZipUtil;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.mib.repository.MiscBillingTrnInvoiceDataRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Slf4j
@Service
public class OutwardSupportingDocService {

	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	private MiscBillingTrnInvoiceDataRepository invoiceRepository;
	
	@Autowired
	private ZipUtil zipUtil;
	
	@Autowired
	private SupportingDocService supportingDocService;
	
	@Value("${batch.directory.supporting-doc.temp}")
	private String suppDocBatchTempDir;
	
	@Value("${batch.directory.supporting-doc.final}")
	private String suppDocBatchFinalDir;
	
	@Value("${batch.directory.supporting-doc.output}")
	private String suppDocBatchOutputDir;
	
	private String hostAlphaCode;
	private String hostNumericCode;
	
	public String outwardSuppDoc(String clientId, String billingMonth, String billingPeriod) {
		// validate input
		boolean inValidInput = this.validateOutwardSuppDocInput(clientId, billingMonth, billingPeriod);
		if(inValidInput) {
			return "Input entered is invalid. ClientId: " + clientId + ", billingMonth: " + billingMonth + ", billingPeriod: " + billingPeriod;
		}
		
		// Get all files from temp folder in list
		List<String> sourceList = this.getAllSuppDocFiles(billingMonth, billingPeriod);
		if(CollectionUtils.isEmpty(sourceList)) {
			return "No Outward Supporting doc files found to process...";
		}
		
		// Get zip file name- MSDF-15720190219000001.ZIP
		String zipFileName = this.getOutwardSuppDocZipFile();
		
		String msg = supportingDocService.checkIfFileAlreadyRun(zipFileName);
		if(StringUtils.isNotBlank(msg)) return msg;
		
		FileLogging fileLogging = supportingDocService.createFileLogging("outwardAttachment", zipFileName, "manual", sourceList.size(), clientId, suppDocBatchOutputDir);
		// getSuppDocFinalList after replacing batchNo with InvoiceNo
		List<String> targetList = this.getSuppDocFinalList(sourceList);

		// Create final folder
		this.createFinalFolder(targetList);
		
		// Copy files from temp to final folder
		this.copyFilesToFinalFolder(sourceList, targetList);

		// Create zip file
		String source = suppDocBatchFinalDir.substring(0, suppDocBatchFinalDir.length()-1);
		zipUtil.generateFileList(new File(source), source);
		zipUtil.zipIt(suppDocBatchFinalDir + zipFileName, source);
		SmartpraFileUtility.moveFile(suppDocBatchFinalDir + zipFileName, suppDocBatchOutputDir + zipFileName);
		supportingDocService.updateFileLogging(true, targetList.size(), fileLogging);
		return "Zip file created at location: " + suppDocBatchOutputDir + zipFileName;
	}
	
	public boolean validateOutwardSuppDocInput(String clientId, String billingMonth, String billingPeriod) {
		boolean invalidInput = false;
		String hostCarrier = this.getHostCarrier(clientId);
		if(!StringUtils.equals(clientId, hostCarrier)) {
			invalidInput = true; 
		}
		// 201902
		if(!Pattern.matches("[2]{1}[0]{1}[1/2]{1}[0-9]{3}", billingMonth)) {
			invalidInput = true;
		}
		if(!Pattern.matches("[0/1]{1}[0-9]{1}", billingPeriod)) {
			invalidInput = true;
		}
		return invalidInput;
	}
	
	// temp\157\201902\02
	public List<String> getAllSuppDocFiles(String billingMonth, String billingPeriod) {
		log.debug("Walking through zip file at location: " + suppDocBatchTempDir);
		List<String> result = null;
		StringBuilder pattern = new StringBuilder(MiscBillingConstants.TEMP_FOLDER);
		pattern.append(hostNumericCode).append(File.separator).append(billingMonth).append(File.separator).append(billingPeriod);
		try (Stream<Path> walk = Files.walk(Paths.get(suppDocBatchTempDir))) {
			result = walk.filter(Files::isRegularFile).map(x -> x.toString())
					.filter(x -> x.contains(pattern.toString()))
					.collect(Collectors.toList());

			if (CollectionUtils.isEmpty(result)) {
				log.debug("No files to process. Hence exiting the process...");
			} else {
				result.forEach(x -> log.debug(x));
			}
		} catch (IOException e) {
			e.printStackTrace();
			log.debug("Exception thrown while processing file from temp folder. Hence exiting the process...");
		}
		return result;
	}
	
    public List<String> getSuppDocFinalList(List<String> result) {
		List<String> suppDocFinalList = new ArrayList<>();
		for (String filePath : result) {
			log.debug("Processing file: " + filePath);
			List<String> list = Arrays.asList(filePath.split(Pattern.quote(File.separator)));
			Optional<String> batchNo = list.stream().filter(x -> x.startsWith(MiscBillingConstants.MO))
													  .findFirst();
			if(batchNo.isPresent()) {
				log.debug("validFile: " + batchNo.get());
				String invoiceNo = invoiceRepository.getInvoiceNo(batchNo.get(), hostAlphaCode);
				log.debug("invoiceNo: " + invoiceNo);
				if(invoiceNo == null) {
					log.debug("InvoiceNo is null for InvoiceUrn: " + batchNo + ". Hence stopping the process...");
					System.exit(1);
				} else {
					String finalPath = filePath.replaceFirst(MiscBillingConstants.TEMP, MiscBillingConstants.FINAL);
					finalPath = finalPath.replaceFirst(batchNo.get(), invoiceNo);
					log.debug("finalPath: " + finalPath);
					suppDocFinalList.add(finalPath);
				}
			}
		}
		return suppDocFinalList;
    }
    
    public void createFinalFolder(List<String> finalList) {
    	log.debug("Creating Final Folder...");
		for (String filePath : finalList) {
			log.debug("Processing file: " + filePath);
			List<String> list = Arrays.asList(filePath.split(Pattern.quote(File.separator)));
			
			boolean proceed = false;
			for (int i=0; i < list.size() - 1; i++) {
				if(StringUtils.equals(MiscBillingConstants.FINAL, list.get(i))) {
					proceed = true; continue;
				}
				if(proceed) {
					String folderName = String.join(File.separator, list.subList(0, i+1));
					log.debug("Creating folder: " + folderName);
					File dir = new File(folderName);
					try {
						if(!dir.isDirectory()) {
							dir.mkdir();
						}
					} catch (Exception ex) {
						log.debug("Error occured while creating directory for folderName: " + folderName);
					}
				}
			}
		}
    }
    
    public void copyFilesToFinalFolder(List<String> sourceList, List<String> destList) {
		
    	log.debug("Copying source files to final folder...");
    	if(CollectionUtils.isNotEmpty(sourceList) && CollectionUtils.isNotEmpty(destList)) {
	    	for(int i=0; i < sourceList.size(); i++) {
		    	File source = new File(sourceList.get(i));
		    	File dest = new File(destList.get(i));
				try {
					if(!dest.exists()) {
						Path target = Files.copy(source.toPath(), dest.toPath());
						if(target != null) log.debug(target.toString());
					}
				} catch (IOException e) {
					e.printStackTrace();
					log.debug("Error thrown while copying source to target...");
				}
	    	}
    	} else {
    		log.debug("Not copying source files to final folder since size of destList is 0. ");
    	}
    }
    
	// MSDF-157 2019 02 19 000001 .ZIP
	public String getOutwardSuppDocZipFile(){
		StringBuilder sb = new StringBuilder(MiscBillingConstants.MSDF);
		sb.append(hostNumericCode);
		LocalDate currentDate = LocalDate.now(); // 2016-06-17
		log.debug("Current Date = " + currentDate);
		
		String day = currentDate.getDayOfMonth() + MiscBillingConstants.EMPTY_STRING; // 17
		String month = currentDate.getMonth().getValue()  + MiscBillingConstants.EMPTY_STRING; // JUNE
		String year = currentDate.getYear() + MiscBillingConstants.EMPTY_STRING; // 2016
		log.debug("year = " + year + ", month = " + month + ", date = " + day);
		
		if(day.length() == 1) day = MiscBillingConstants.ZERO + day;
		if(month.length() == 1) month = MiscBillingConstants.ZERO + month;
		sb.append(year).append(month).append(day).append("000001").append(MiscBillingConstants.DOT_ZIP);
		log.debug("ZipFileName  = " + sb.toString());
		return sb.toString();
	}
	
    public String getHostCarrier(String clientId) {
		hostAlphaCode = MiscBillingUtil.getHostCarrierDesigCode(smartpraMasterAppClient, clientId);
		if(StringUtils.isBlank(hostAlphaCode)) {
			return "Invalid clientId: " + clientId; 
		}
		hostNumericCode = MiscBillingUtil.getHostCarrierCode(smartpraMasterAppClient, hostAlphaCode);
		log.debug("hostAlphaCode: " + hostAlphaCode + ", hostNumericCode: " + hostNumericCode);
		return hostAlphaCode;
	}
}
