/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;
import com.sgl.smartpra.mib.jaxb.standard.AddOnCharges;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceSummary;

/**
 * @author kanprasa
 *
 */
@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AddOnChargeDtlMapper {

	@Mapping(source = "addOnChargePercentage", target = "addOnChargePercentage", ignore=true)
	public MiscBillingAddOnChargeDtlEntity mapForInvSummaryToEntity(InvoiceSummary.AddOnCharges addOnCharge);

	@Mapping(source = "addOnChargePercentage", target = "addOnChargePercentage", ignore=true)
	public MiscBillingAddOnChargeDtlEntity mapToEntity(AddOnCharges addOnCharge);
	
	@Mapping(source = "addOnChargePercentage", target = "addOnChargePercentage", ignore=true)
	public void mapEntityToAddOnChargeDtlForInvSummary(MiscBillingAddOnChargeDtlEntity addOnChargedTlEntity, @MappingTarget InvoiceSummary.AddOnCharges addOnCharge);

	@Mapping(source = "addOnChargePercentage", target = "addOnChargePercentage", ignore=true)
	public void mapEntityToAddOnChargeDtl(MiscBillingAddOnChargeDtlEntity addOnChargedTlEntity, @MappingTarget AddOnCharges addOnCharge);
}