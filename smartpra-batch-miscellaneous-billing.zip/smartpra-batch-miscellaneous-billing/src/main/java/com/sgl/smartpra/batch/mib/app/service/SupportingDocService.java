package com.sgl.smartpra.batch.mib.app.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.batch.mib.app.validator.InvSuppDocValidator;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.mib.entity.MiscBillingInvSupportingDocEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.repository.MiscBillingInvSupportingDocRepository;
import com.sgl.smartpra.mib.repository.MiscBillingTrnInvoiceDataRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Slf4j
@Service
public class SupportingDocService {

	private Map<String, String> sysParamMap = new HashMap<>();

	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	private MiscBillingTrnInvoiceDataRepository invoiceRepository;
	
	@Autowired
	private MiscBillingInvSupportingDocRepository suppDocRepository;
	
	@Autowired
	private BatchGlobalFeignClient batchGlobalFeignClient;
	
	@Autowired
	private InvSuppDocValidator invSuppDocValidator;
	
	@Value("${batch.directory.supporting-doc.input}")
	private String suppDocBatchInputDir;
	
	@Value("${batch.directory.supporting-doc.duplicate}")
	private String suppDocBatchDuplicateDir;
	
	@Value("${batch.directory.supporting-doc.failed}")
	private String suppDocBatchFailedDir;
	
	@Value("${batch.directory.supporting-doc.processed}")
	private String suppDocBatchProcessedDir;
	
	@Value("${env-prod}")
	private String move;
	
	private Map<String, Integer> invoiceMap = new HashMap<>();
	
	private String hostAlphaCode;
	private String hostNumericCode;
	
	public String getHostCarrier(String clientId) {
		hostAlphaCode = MiscBillingUtil.getHostCarrierDesigCode(smartpraMasterAppClient, clientId);
		if(StringUtils.isBlank(hostAlphaCode)) {
			return "Invalid clientId: " + clientId; 
		}
		hostNumericCode = MiscBillingUtil.getHostCarrierCode(smartpraMasterAppClient, hostAlphaCode);
		log.debug("hostAlphaCode: " + hostAlphaCode + ", hostNumericCode: " + hostNumericCode);
		return hostAlphaCode;
	}
	
	public Map<String, String> populateSystemParameters(String clientId) {
		List<String> params = Arrays.asList("SIS_ATTACHMENT_FILE_LENGTH", "SIS_ATTACHMENT_FILETYPE");
		try {
			List<SystemParameter> systemParameterList = smartpraMasterAppClient.getSystemParameterByparameterNameAndClientId(clientId, params);
			sysParamMap = systemParameterList.stream().collect(Collectors.toMap(s -> s.getParameterName().get().trim(), s -> s.getParameterRangeFrom().get()));
			printSystemParameters();
		} catch (Exception e) {
			log.error("SystemParameterController throws exception while retriving data from master.");
			e.printStackTrace();
		}
		
		return sysParamMap;
	}
	
	public String processFiles() {
		String zipFileName = this.processZipFile();
		String msg = this.checkIfFileAlreadyRun(zipFileName);
		if(StringUtils.isNotBlank(msg)) {
			return msg;
		} else {
			List<String> fileList = this.getAllSuppDocFiles(zipFileName);
			if(CollectionUtils.isEmpty(fileList)) {
				return "No files to process. Hence exiting the process...";
			}
			FileLogging fileLogging = this.createFileLogging("suppDocJob", zipFileName, "Manual", fileList.size(), hostAlphaCode, suppDocBatchInputDir);
			if(fileLogging == null) {
				return "Error thrown while creating fileLogging. Hence exiting the process...";
			}
			Integer fileId = fileLogging.getFileId().intValue();
			Multimap<String, ExceptionTransactionModel> errorMap = invSuppDocValidator.validateMainFolder(zipFileName, hostAlphaCode, hostNumericCode, fileId);
			List<MiscBillingInvSupportingDocEntity> suppDocList = this.loopThroughFiles(fileId, fileList, errorMap);
			boolean success = this.saveSuppDocList(suppDocList);
			invSuppDocValidator.saveSuppDocError(errorMap);
			this.updateFileLogging(success, suppDocList.size(), fileLogging);
			invoiceMap.clear();
			msg = "Miscellaneous Billing Supporting doc attachment zip file (" + suppDocBatchInputDir + zipFileName + ") is successfully loaded in database.";
		}
		return msg;
	}
	
	public String processZipFile() {
		log.debug("Unzipping Zip File at location: " + suppDocBatchInputDir);
		try {
			this.unzipFile();
		} catch (IOException e) {
			log.debug("Error thrown while unzipping file at location: " + suppDocBatchInputDir);
		}
		String zipFileName = MiscBillingConstants.EMPTY_STRING;
		File dir = new File(suppDocBatchInputDir);
		List<File> listOfFiles = Arrays.asList(dir.listFiles());
		Optional<File> file = listOfFiles.stream().filter(x -> x.isFile() && x.getName().endsWith(".zip")).findFirst();
		if(file.isPresent()) {
			zipFileName = file.get().getName();
		}
		return zipFileName;
	}
	public String checkIfFileAlreadyRun(String fileName) {
		String str = MiscBillingConstants.EMPTY_STRING;
		String date = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		List<FileLogging> fileLogList = batchGlobalFeignClient.getFileLogByFileName(fileName);
		if(MiscBillingConstants.YES.equals(move) && CollectionUtils.isNotEmpty(fileLogList)) {
			log.info("Miscellaneous Billing Supporting doc attachment zip file (" + suppDocBatchInputDir + fileName + ") is already loaded in database. Hence stopping the batch process.");
			SmartpraFileUtility.moveFile(suppDocBatchInputDir + fileName, suppDocBatchDuplicateDir + fileName + date);
			str = "Miscellaneous Billing Supporting doc attachment zip file (" + suppDocBatchInputDir + fileName + ") is already loaded in database. Hence stopping the batch process.";
		}
		return str;
	}
	
    public void unzipFile() throws IOException {

        if (!Paths.get(suppDocBatchInputDir).toFile().exists()) {	
            Files.createDirectories(Paths.get(suppDocBatchInputDir));
        }
        File dir = new File(suppDocBatchInputDir);
		File[] listOfFiles = dir.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
	        try (ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(new File(suppDocBatchInputDir + File.separator + listOfFiles[i].getName())))) {
	            ZipEntry entry = zipInputStream.getNextEntry();
	            while (entry != null) {
	                Path filePath = Paths.get(suppDocBatchInputDir, entry.getName());
	                if (!entry.isDirectory()) {
	                    unzipFiles(zipInputStream, filePath);
	                } else {
	                    Files.createDirectories(filePath);
	                }
	
	                zipInputStream.closeEntry();
	                entry = zipInputStream.getNextEntry();
	            }
	        }
		}
    }

    public void unzipFiles(final ZipInputStream zipInputStream, final Path unzipFilePath) throws IOException {

        try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(unzipFilePath.toAbsolutePath().toString()))) {
            byte[] bytesIn = new byte[1024];
            int read = 0;
            while ((read = zipInputStream.read(bytesIn)) != -1) {
                bos.write(bytesIn, 0, read);
            }
        }
    }
    
    public List<String> getAllSuppDocFiles(String zipFileName) {
		log.debug("Walking through zip file at location: " + suppDocBatchInputDir + zipFileName);
		List<String> result = null;
		try (Stream<Path> walk = Files.walk(Paths.get(suppDocBatchInputDir))) {
			result = walk.filter(Files::isRegularFile)
					.map(x -> x.toString())
					.filter(x -> x.contains(MiscBillingConstants.SUPP_DOC))
					.collect(Collectors.toList());
			log.debug("result: " + result);
			if(CollectionUtils.isEmpty(result)) {
				log.debug("No files to process. Hence exiting the process...");
			} else {
				result.forEach(x -> log.debug(x));
			}
		} catch (IOException e) {
			e.printStackTrace();
			log.debug("Exception thrown while processing file. Hence exiting the process...");
		}
		return result;
    }
    
    public List<MiscBillingInvSupportingDocEntity> loopThroughFiles(Integer fileId, List<String> result, Multimap<String, ExceptionTransactionModel> errorMap) {
		List<MiscBillingInvSupportingDocEntity> suppDocList = new ArrayList<>();
		invoiceMap.clear();
		for (String filePath : result) {
			log.debug("Processing file: " + filePath);
			String invoiceNo;
			List<String> list = Arrays.asList(filePath.split(Pattern.quote(File.separator)));
			Optional<String> miscFolder = list.stream().filter(x -> x.startsWith("MISC")).findFirst();
			Optional<String> invoiceFolder  = list.stream().filter(x -> x.startsWith("INV-")).findFirst();
			if(miscFolder.isPresent()) log.debug("miscFolder: " + miscFolder.get());
			if(invoiceFolder.isPresent()) {
				log.debug("invoiceFolder: " + invoiceFolder.get());
				invoiceNo = invoiceFolder.get().substring(4);
				log.debug("invoiceNo: " + invoiceNo);
				if(invoiceMap.get(invoiceNo) == null) {
					invoiceMap.put(invoiceNo, 1);
				} else {
					invoiceMap.put(invoiceNo, invoiceMap.get(invoiceNo) + 1);
				}
				suppDocList.add(this.createSupportingDoc(filePath, BigInteger.valueOf(fileId), errorMap));
			}
		}
		return suppDocList;
    }
    
    public boolean saveSuppDocList(List<MiscBillingInvSupportingDocEntity> suppDocList) {
    	boolean success = false;
		if(CollectionUtils.isNotEmpty(suppDocList)) {
			log.debug("Saving supporting doc entities - count: " + suppDocList.size());
			try {
				suppDocRepository.saveAll(suppDocList);
				success = true;
			} catch (Exception e) {
				log.debug("SuppDoc: Error thrown while saving supporting doc in DB. " + e.getMessage());
			}
		} else {
			log.debug("Supporting Doc list is empty. No files to process.");
		}
		return success;
    }
 
	public FileLogging createFileLogging(String jobName, String fileName, String processedBy, 
			Integer totalCounts, String clientId, String filePath) {
		log.debug("Creating filelog..");
		FileLogging fileLogging = null;
		try {
			fileLogging = MiscBillingUtil.initFileLogging();
			fileLogging.setClientId(clientId);
			fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_INPUT);
			fileLogging.setFileCategory(FileLoggingConstants.FILELOGGING_FILECATEGORY_ZIP);
			fileLogging.setFileName(fileName);
			fileLogging.setProcessedBy(processedBy);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_CREATED);
			fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
			fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
			fileLogging.setTotalCounts(totalCounts);
			fileLogging.setHeaderCounts(0);
			fileLogging.setDetailCounts(0);
			fileLogging.setErrorCounts(0);
			fileLogging.setTransferredCounts(0);
			fileLogging.setFileSize(SmartpraFileUtility.getFileSize(filePath + fileName));
			fileLogging.setModuleName(MiscBillingConstants.FILELOGGING_MODULE);
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_MISC_BILLING_SUP);
			fileLogging.setSource(MiscBillingConstants.FILELOGGING_SOURCE);
			fileLogging.setIsEncryptedPostSuccess(MiscBillingConstants.NO);
			fileLogging.setIsEncryptedPriorLoading(MiscBillingConstants.NO);
			fileLogging.setIsMovedToRelevantFolder(MiscBillingConstants.NO);
			fileLogging.setIsNotificationSent(MiscBillingConstants.NO);
			fileLogging.setIsRenamedPostSuccess(MiscBillingConstants.NO);
			fileLogging.setJobName(jobName);
			fileLogging.setCreatedBy(MiscBillingConstants.CREATEDBY);
			fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));
			fileLogging.setModuleId(MiscBillingConstants.MODULE_ID);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			log.debug("Filelog created with fileId: " + fileLogging.getFileId());
		} catch (Exception e1) {
			e1.printStackTrace();
			log.debug("Error thrown while creating fileLogging. Hence exiting the process...");
		}
		return fileLogging;
	}
	
	public void updateFileLogging(boolean success, int count, FileLogging fileLogging) {
		String date = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		if(success) {
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
			fileLogging.setTransferredCounts(count);
			fileLogging.setErrorCounts(0);
			fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
			if(MiscBillingConstants.YES.equals(move)) {
				boolean flag = SmartpraFileUtility.moveFile(suppDocBatchInputDir + fileLogging.getFileName(), 
						suppDocBatchProcessedDir + fileLogging.getFileName() + date);
				fileLogging.setIsMovedToRelevantFolder(flag ? "Y" : "N");
			}
			log.info("!!! JOB FINISHED! Time to verify the results");
		} else {
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
			fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK);
			fileLogging.setTransferredCounts(0);
			fileLogging.setErrorCounts(count);
			if(MiscBillingConstants.YES.equals(move)) {
				boolean flag = SmartpraFileUtility.moveFile(suppDocBatchInputDir + fileLogging.getFileName(), 
						suppDocBatchFailedDir + fileLogging.getFileName() + date);
				fileLogging.setIsMovedToRelevantFolder(flag ? "Y" : "N");
			}
			log.info("!!! JOB FINISHED -FAILED ! Time to verify the results");
		}
		fileLogging.setTotalCounts(count);
		fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
		log.debug("Updating file log with fileId: " + fileLogging.getFileId());
		batchGlobalFeignClient.updateFileLog(fileLogging.getFileId(), fileLogging);
	}
	
	public MiscBillingInvSupportingDocEntity createSupportingDoc(String filePath, BigInteger fileId, Multimap<String, ExceptionTransactionModel> errorMap) {
		log.debug("Creating supporting doc entity for file: " + filePath);
		Optional<String> clientId; 
		Optional<String> billingMonth = Optional.empty();
		Optional<String> billedCarrier;
		Optional<String> date;
		String year = MiscBillingConstants.EMPTY_STRING;
		String billingNumerCarrierCode;
		Integer billingPeriod = 0;
		List<String> list = Arrays.asList(filePath.split(Pattern.quote(File.separator)));
		// MISC-P-QR-157-20181001
		Optional<String> miscFolder = list.stream().filter(x -> x.startsWith("MISC")).findFirst();
		if(miscFolder.isPresent()) {
			log.debug("miscFolder: " + miscFolder.get());
			List<String> params = Arrays.asList(miscFolder.get().split(Pattern.quote("-")));
			clientId = params.stream().filter(x -> x.length() == 2).findFirst();
			billedCarrier = params.stream().filter(x -> x.length() == 3).findFirst();
			date = params.stream().filter(x -> x.length() == 8).findFirst();
			if(date.isPresent()) { // 20181001
				year = date.get().substring(2, 4);
				billingMonth = Optional.ofNullable(date.get().substring(4, 6));
				billingPeriod = Integer.parseInt(date.get().substring(6));
				log.debug("year = " + year + ", billingMonth = " + billingMonth.get() + ", billingPeriod = " + billingPeriod);
			}
		} else {
			log.debug("ERR: miscFolder variable not defined. Hence aborting the process.");
			return null;
		}
		
		billingNumerCarrierCode = invSuppDocValidator.validateBillingCarrierWithInterlineDetails(hostNumericCode, 
				fileId.intValue(), clientId.get(), list, date, errorMap);

		MiscBillingInvSupportingDocEntity suppDocEntity = new MiscBillingInvSupportingDocEntity();
		suppDocEntity.setClientId(clientId.get());
		suppDocEntity.setBillingType(MiscBillingConstants.I);
		suppDocEntity.setBillingPeriod(billingPeriod);
		
		if(billingMonth.isPresent()) suppDocEntity.setBillingMonth(MiscBillingUtil.getMonth(billingMonth.get()) + "-" + year);
		suppDocEntity.setBillingCarrier(billingNumerCarrierCode);
		
		if(billedCarrier.isPresent()) suppDocEntity.setBilledCarrier(billedCarrier.get());
		suppDocEntity.setTransactionType(MiscBillingConstants.SUPP_DOC_TRANSACTION_TYPE);
		Optional<String> invoiceStr = list.stream().filter(x -> x.startsWith("INV-")).findFirst();
		
		String invoiceNo = MiscBillingConstants.EMPTY_STRING;
		String invoiceUrn = MiscBillingConstants.EMPTY_STRING;
		if(invoiceStr.isPresent()) {
			invoiceNo = invoiceStr.get().substring(4);
			invoiceUrn = invoiceRepository.getInvoiceUrn(clientId.get(), invoiceNo);
			suppDocEntity.setInvoiceNo(invoiceNo);
			suppDocEntity.setBatchKey(invoiceUrn);
			log.debug("invoiceNo = " + invoiceNo + ", invoiceUrn = " + invoiceUrn);
		}
		if(StringUtils.isBlank(invoiceUrn)) {
			suppDocEntity.setTransactionRefNo(invoiceNo);
			suppDocEntity.setDocumentUniqueNo(invoiceNo);
		} else {
			suppDocEntity.setTransactionRefNo(invoiceUrn);
			suppDocEntity.setDocumentUniqueNo(invoiceUrn);
		}
		
		MiscBillingTrnInvoiceEntity invoiceEntity = invSuppDocValidator.getInvoiceEntity(hostAlphaCode, invoiceNo);
		if(invoiceEntity == null) {
			log.debug("InvoiceEntity for invoice: " + invoiceNo + " is null.");
			Map<String, String> map = new HashedMap<>();
     		map.put("Invoice Number", invoiceNo); 
     		map.put("Billing type", MiscBillingConstants.I);
     		map.put("Billing Carrier", billingNumerCarrierCode);
     		map.put("Billing Month", billingMonth.get());
     		map.put("Billing Period", billingPeriod.toString());
     		//errorMap.put(MiscBillingConstants.EMPTY_STRING, invSuppDocValidator.prepareExceptionTransactionModel(ErrorCode.INWD3057.toString(), clientId.get(), billingNumerCarrierCode, 
     		//		hostNumericCode, fileId.intValue(), MiscBillingConstants.EMPTY_STRING, MiscBillingConstants.EMPTY_STRING, 
     		//		null, null, map));
		}
		
		suppDocEntity.setCarrierCode(null);
		suppDocEntity.setAttachmentSeq(invoiceMap.get(invoiceNo));
		suppDocEntity.setAttachmentType(filePath.substring(filePath.lastIndexOf(".")));
		suppDocEntity.setFileName(list.get(list.size() - 1));
		suppDocEntity.setFilePath(String.join(File.separator, list.subList(0, list.size() - 1)));
		suppDocEntity.setFileId(fileId.toString());
		suppDocEntity.setRecordSeq(null);
		return suppDocEntity;
	}
	
	public void printSystemParameters() {
		if(sysParamMap != null && !sysParamMap.isEmpty()) {
			log.debug("SIS_ATTACHMENT_FILE_LENGTH: " + sysParamMap.get("SIS_ATTACHMENT_FILE_LENGTH"));
			log.debug("SIS_ATTACHMENT_FILETYPE: " + sysParamMap.get("SIS_ATTACHMENT_FILETYPE"));
		}
	}
	
    @Transactional(propagation = Propagation.REQUIRED)
	public String invokejobSuppDoc(String clientId) {
		this.getHostCarrier(clientId);
		this.populateSystemParameters(clientId);
		return this.processFiles();
	}

}
