/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.processor;

import java.math.BigInteger;
import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.mib.app.service.LineItemDetailService;
import com.sgl.smartpra.batch.mib.app.service.LineItemService;
import com.sgl.smartpra.batch.mib.app.service.OutwardInvoiceService;
import com.sgl.smartpra.batch.mib.app.service.TransmissionService;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.mib.entity.MiscBillInvTransTotalAmtEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.jaxb.standard.Invoice;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceHeader;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceTransmission;
import com.sgl.smartpra.mib.jaxb.standard.LineItem;
import com.sgl.smartpra.mib.jaxb.standard.LineItemDetail;
import com.sgl.smartpra.mib.jaxb.standard.TransmissionHeader;
import com.sgl.smartpra.mib.jaxb.standard.TransmissionSummary;
import com.sgl.smartpra.mib.repository.MiscBillingInvTransHeaderDataRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Component
@Scope(value = "step")
@Slf4j
public class OutwardBillingProcessor implements ItemProcessor<List<MiscBillingTrnInvoiceEntity>, InvoiceTransmission> {	
	
	@Value("#{stepExecution}")
	private StepExecution stepExecution;
	
	@Autowired
	private OutwardInvoiceService outwardInvoiceService;
	
	@Autowired
	private LineItemService lineItemService;
	
	@Autowired
	private LineItemDetailService lineItemDetailService;

	@Autowired
	private CommonValidator commonValidator; 
	
	@Autowired
	private TransmissionService transmissionService;
	
	@Autowired
	private MiscBillingInvTransHeaderDataRepository transmissionHeaderRepository;
	
	@Override
	public InvoiceTransmission process(List<MiscBillingTrnInvoiceEntity> invoiceEntityList) throws Exception {
		log.debug("#################### Entering OutwardBillingProcessor ####################");
		InvoiceTransmission invoiceTransmission = new InvoiceTransmission();
		String fy = outwardInvoiceService.getCurrentFy(commonValidator.getClientId());
		int attachmentCount = 0;
		for (MiscBillingTrnInvoiceEntity invoiceEntity : invoiceEntityList) {
			Invoice invoice = new Invoice();
			commonValidator.populateCommonFields(MiscBillingConstants.OUTWARD, invoiceEntity);
			String invoiceNo = outwardInvoiceService.generateInvoiceNo(commonValidator.getClientId(), fy, commonValidator.getCarrier().getCarrierDesignatorCode().get());
			invoiceEntity.setInvoiceNumber(invoiceNo);
			InvoiceHeader invoiceHeader = outwardInvoiceService.getInvoiceHeader(invoiceEntity);
			boolean isInvoiceRejected = false; 
			if(MiscBillingConstants.YES.equalsIgnoreCase(invoiceEntity.getRejectionFlag())){
				isInvoiceRejected = true;
			}
			List<LineItem> lineItemList = lineItemService.getLineItems(invoiceEntity.getMiscBillingInvLineitem(), isInvoiceRejected);
			for (MiscBillingInvLineitemEntity lineItemEntity : invoiceEntity.getMiscBillingInvLineitem()) {
				BigInteger lineItemNo = lineItemEntity.getLineItemNumber() != null ? BigInteger.valueOf(lineItemEntity.getLineItemNumber()) : null; 
				List<LineItemDetail> lineItemDtlList = lineItemDetailService.getLineItemDetails(lineItemNo, lineItemEntity.getMiscBillingLineitemDetails());
				invoice.getLineItemDetail().addAll(lineItemDtlList);
			}
			invoice.setInvoiceHeader(invoiceHeader);
			invoice.getLineItem().addAll(lineItemList);
			invoice.setInvoiceSummary(outwardInvoiceService.getInvoiceSummary(invoiceEntity));
			invoiceTransmission.getInvoice().add(invoice);
			if(invoiceEntity.getMiscBillingInvAttachment() != null && invoiceEntity.getMiscBillingInvAttachment().size() > 0) {
				attachmentCount += invoiceEntity.getMiscBillingInvAttachment().size();
			}
			commonValidator.reset();
		}
		TransmissionHeader transmissionHeader; 
		int invoiceCount = invoiceEntityList.size();
		if(invoiceCount == 1) {
			transmissionHeader = transmissionService.getTransmissionHeader(invoiceCount, invoiceEntityList.get(0).getInvoiceNumber());
		} else {
			transmissionHeader = transmissionService.getTransmissionHeader(invoiceCount, invoiceEntityList.get(0).getInvoiceNumber());
		}
		commonValidator.setOutwardInvoiceCount(invoiceCount);
		Long chargeCodeCount = invoiceEntityList.stream()
											   .map(invoice -> invoice.getMiscBillingInvLineitem().size())
											   .count();
		if(chargeCodeCount != null) {
			commonValidator.setOutwardChargeCodeCount(Math.toIntExact(chargeCodeCount));
		}
											   
		invoiceTransmission.setTransmissionHeader(transmissionHeader);
		TransmissionSummary transmissionSummary = transmissionService.getTransmissionSummary(invoiceEntityList);
		invoiceTransmission.setTransmissionSummary(transmissionSummary);
		MiscBillingInvTransHeaderEntity invTransHeader = transmissionService.getTransmissionHeaderEntity(transmissionHeader, invoiceCount, attachmentCount);
		List<MiscBillInvTransTotalAmtEntity> transSummaryList = transmissionService.processTransmissionSummary(transmissionSummary, invTransHeader);
		invTransHeader.setMiscBillInvTransTotalAmt(transSummaryList);
		MiscBillingInvTransHeaderEntity transHeaderEntity  = transmissionHeaderRepository.save(invTransHeader);
		outwardInvoiceService.populateInvoicesInHeader(transHeaderEntity, invoiceEntityList);
		transHeaderEntity.setFileId(commonValidator.getFileId());
		transmissionHeaderRepository.save(transHeaderEntity);
		commonValidator.setTransHeaderId(transHeaderEntity.getTransHdrId());
		log.debug("#################### Exiting OutwardBillingProcessor ####################");
		return invoiceTransmission;
	}
}	