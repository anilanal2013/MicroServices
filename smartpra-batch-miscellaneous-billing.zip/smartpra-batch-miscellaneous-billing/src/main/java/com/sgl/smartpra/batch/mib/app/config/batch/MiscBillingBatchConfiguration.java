package com.sgl.smartpra.batch.mib.app.config.batch;

import java.io.File;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.mib.app.listener.JobCompletionNotificationListener;
import com.sgl.smartpra.batch.mib.app.processor.MiscBillingFileProcessor;
import com.sgl.smartpra.batch.mib.app.processor.MiscBillingSchemaValidation;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.validator.SchemaValidator;
import com.sgl.smartpra.batch.mib.app.writer.MiscBillingFileWriter;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceTransmission;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceTransmissionModel;

@Configuration
@EnableBatchProcessing
public class MiscBillingBatchConfiguration {

	@Autowired
	private JobBuilderFactory jobs;
	 
    @Autowired
    private StepBuilderFactory steps;
    
	@Value("${max-threads}")
	private int maxThreads;
	
	@Value("${batch.directory.misc-billing.input}")
	private String batchInputDir;
	
	@Autowired
	private SchemaValidator schemaValidator;
	
	@Autowired
	private PlatformTransactionManager transactionManager;

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setConcurrencyLimit(maxThreads);
		return taskExecutor;
	}

	@Bean
	public Job iataXmlJob(JobCompletionNotificationListener listener, Step extractFileDataToStaging) {
	  	return jobs.get("iataXmlJob")
	  			.incrementer(new RunIdIncrementer())
	  			.listener(listener)
	  			.start(extractFileDataToStaging)
	    		.build();
	}
	
    @Bean
    public Step schemaValidation() {
           return steps.get("schemaValidation")
                       .tasklet(new MiscBillingSchemaValidation(schemaValidator))
                       .build();
    }
	
    @Bean 
    public Step extractFileDataToStaging() {
    	return steps.get("extractFileDataToStaging")
    			.<InvoiceTransmission,InvoiceTransmissionModel>chunk(100)
    			.reader(invoiceItemReader(null))
    			.processor(inwardProcessor())
                .writer(jpaItemWriter())
                .transactionManager(transactionManager)
				.taskExecutor(taskExecutor())
				.throttleLimit(maxThreads)
				.allowStartIfComplete(true)
                .build();
    }
      
    @Bean
    @StepScope
    public StaxEventItemReader<InvoiceTransmission> invoiceItemReader(@Value("#{jobParameters[fileName]}") String fileName){
    		    	    	
    	StaxEventItemReader<InvoiceTransmission> staxEventItemReader = new StaxEventItemReader<>();
    	staxEventItemReader.setResource(new FileSystemResource(batchInputDir +File.separator+ fileName));
    	staxEventItemReader.setFragmentRootElementName(MiscBillingConstants.INVOICE_TRANSMISSION);
    	
    	Jaxb2Marshaller unMarshaller = new Jaxb2Marshaller();
    	unMarshaller.setClassesToBeBound(InvoiceTransmission.class);
    	staxEventItemReader.setUnmarshaller(unMarshaller);
    	return staxEventItemReader;
    }
    
    @Bean
    @StepScope
    public ItemProcessor<InvoiceTransmission, InvoiceTransmissionModel> inwardProcessor() {
        return new MiscBillingFileProcessor();
    }
    
    @Bean
    @StepScope
	public ItemWriter<InvoiceTransmissionModel> jpaItemWriter() {
        return new MiscBillingFileWriter();
    }
	    
}
