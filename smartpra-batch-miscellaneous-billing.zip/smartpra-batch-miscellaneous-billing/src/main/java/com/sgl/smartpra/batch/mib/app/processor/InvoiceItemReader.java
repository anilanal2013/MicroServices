/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.processor;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.repository.MiscBillingTrnInvoiceDataRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Component
@Scope(value = "step")
@Slf4j
public class InvoiceItemReader implements ItemReader<List<MiscBillingTrnInvoiceEntity>>{

	@Autowired
	private MiscBillingTrnInvoiceDataRepository invoiceRepository;
	
	@Autowired
	private CommonValidator commonValidator; 
	
	@Override
	public List<MiscBillingTrnInvoiceEntity> read() throws Exception{
		 List<MiscBillingTrnInvoiceEntity> invoiceEntityList = invoiceRepository.findAllByBillingMonthAndPeriodAndStatus(commonValidator.getBillingMonth().toString(), 
				commonValidator.getBillingPeriod(), commonValidator.getClientId());
		if(invoiceEntityList != null && invoiceEntityList.isEmpty()) invoiceEntityList = null;
		return invoiceEntityList;
	}
}
