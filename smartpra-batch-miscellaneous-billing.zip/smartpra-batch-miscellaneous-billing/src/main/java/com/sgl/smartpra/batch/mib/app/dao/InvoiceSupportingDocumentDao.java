package com.sgl.smartpra.batch.mib.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.mib.app.dao.entitySpec.InvoiceSupportingDocEntitySpec;
import com.sgl.smartpra.mib.domain.MiscBillingInvSupportingDoc;
import com.sgl.smartpra.mib.entity.MiscBillingInvSupportingDocEntity;
import com.sgl.smartpra.mib.repository.MiscBillingInvSupportingDocRepository;

@Component
public class InvoiceSupportingDocumentDao {

	@Autowired
	private MiscBillingInvSupportingDocRepository miscBillingInvSupportingDocRepository;
	

	public List<MiscBillingInvSupportingDocEntity> search( String clientId, Optional<String> billingMonth,Optional<Integer> billingPeriod,Optional<String> billingCarrier,Optional<String> billingType,Optional<String> billedCarrier,Optional<String> transactionType,Optional<String> carrierCode,Optional<String> documentNo,Optional<Integer> couponNo,Optional<String> memoNo, Optional<String> fimNo)  {
		
		return miscBillingInvSupportingDocRepository.findAll(InvoiceSupportingDocEntitySpec.search(clientId, billingMonth, billingPeriod, billingCarrier, billingType, billedCarrier, transactionType, carrierCode, documentNo, couponNo, memoNo, fimNo));
		
	}
	
	public List<MiscBillingInvSupportingDocEntity> getAttachmentList( String clientId, String invoice_urn){
		
		return miscBillingInvSupportingDocRepository.findAll(InvoiceSupportingDocEntitySpec.getAttachmentList(clientId, invoice_urn));
	}
	
	public MiscBillingInvSupportingDocEntity save(MiscBillingInvSupportingDocEntity miscBillingInvSupportingDocEntity) {
		
		return miscBillingInvSupportingDocRepository.save(miscBillingInvSupportingDocEntity);
	}
	
	public void delete(MiscBillingInvSupportingDocEntity miscBillingInvSupportingDocEntity) {
		
		miscBillingInvSupportingDocRepository.delete(miscBillingInvSupportingDocEntity);
	}
}
