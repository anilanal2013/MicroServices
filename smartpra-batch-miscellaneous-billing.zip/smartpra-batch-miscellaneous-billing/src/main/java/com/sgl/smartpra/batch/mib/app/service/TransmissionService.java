/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.mib.entity.MiscBillInvTransTotalAmtEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.jaxb.standard.TransmissionHeader;
import com.sgl.smartpra.mib.jaxb.standard.TransmissionSummary;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class TransmissionService {

	@Autowired
	private CommonValidator commonValidator; 
	
	public TransmissionHeader getTransmissionHeader(int invoiceCount, String invoiceNo) {
		TransmissionHeader transmissionHeader = new TransmissionHeader();
		transmissionHeader.setVersion(MiscBillingConstants.IATA_VERSION);
		transmissionHeader.setIssuingOrganizationID(getIssuingOrgId());
		transmissionHeader.setBillingCategory(MiscBillingConstants.BILLING_CATEGORY);
        //YYYY-MM-DDTHH:MI:SS
        String formatDateTime = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME).substring(0,19);
        transmissionHeader.setTransmissionDateTime(formatDateTime);
        
        if(invoiceCount == 1) {
        	transmissionHeader.setTransmissionID(new StringBuffer(invoiceNo)
        			.append(commonValidator.getBillingPeriodEndDate()).toString());
        } else {
        	transmissionHeader.setTransmissionID(new StringBuffer(transmissionHeader.getIssuingOrganizationID())
        			.append(invoiceNo).append(commonValidator.getBillingPeriodEndDate()).toString());
        }
		return transmissionHeader;
	}
	
	public String getIssuingOrgId() {
		return commonValidator.getSysParamMap().get(MiscBillingConstants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE);
	}
	
	public TransmissionSummary getTransmissionSummary(MiscBillingInvTransHeaderEntity transHeaderEntity) {
		TransmissionSummary transmissionSummary = new TransmissionSummary();
		if(transHeaderEntity.getAttachmentCount() != null) {
			transmissionSummary.setAttachmentCount(BigInteger.valueOf(transHeaderEntity.getAttachmentCount()));
		}
		transmissionSummary.setInvoiceCount(transHeaderEntity.getInvoiceCount());
		for (MiscBillInvTransTotalAmtEntity summaryEntity : transHeaderEntity.getMiscBillInvTransTotalAmt()) {
			if(MiscBillingConstants.TOTAL_AMOUNT.equalsIgnoreCase(summaryEntity.getAmountType())){
				TransmissionSummary.TotalAmount totalAmt = new TransmissionSummary.TotalAmount();
				totalAmt.setCurrencyCode(summaryEntity.getCurrencyCode());
				totalAmt.setValue(summaryEntity.getTotalAmount());
				transmissionSummary.getTotalAmount().add(totalAmt);
			} else if(MiscBillingConstants.ADD_ON_CHARGE.equalsIgnoreCase(summaryEntity.getAmountType())){	
				TransmissionSummary.TotalAddOnChargeAmount addOnChargeAmt = new TransmissionSummary.TotalAddOnChargeAmount();
				addOnChargeAmt.setCurrencyCode(summaryEntity.getCurrencyCode());
				addOnChargeAmt.setValue(summaryEntity.getTotalAmount());
				transmissionSummary.getTotalAddOnChargeAmount().add(addOnChargeAmt);
			} else if(MiscBillingConstants.TAX.equalsIgnoreCase(summaryEntity.getAmountType())){
				TransmissionSummary.TotalTaxAmount taxAmt = new TransmissionSummary.TotalTaxAmount();
				taxAmt.setCurrencyCode(summaryEntity.getCurrencyCode());
				taxAmt.setValue(summaryEntity.getTotalAmount());
				transmissionSummary.getTotalTaxAmount().add(taxAmt);
			} else if(MiscBillingConstants.VAT.equalsIgnoreCase(summaryEntity.getAmountType())){
				TransmissionSummary.TotalVATAmount vatAmt = new TransmissionSummary.TotalVATAmount();
				vatAmt.setCurrencyCode(summaryEntity.getCurrencyCode());
				vatAmt.setValue(summaryEntity.getTotalAmount());
				transmissionSummary.getTotalVATAmount().add(vatAmt);
			}
		}
		return transmissionSummary;
	}
	
	public TransmissionSummary getTransmissionSummary(List<MiscBillingTrnInvoiceEntity> invoiceEntityList) {
		TransmissionSummary transmissionSummary = new TransmissionSummary();
		if(invoiceEntityList != null && invoiceEntityList.size() > 0) {
			transmissionSummary.setInvoiceCount(invoiceEntityList.size());
			Map<String, BigDecimal> amtMap = getTotalAmount(invoiceEntityList);
			Map<String, BigDecimal> taxMap = getTotalTaxAmount(invoiceEntityList);
			Map<String, BigDecimal> vatMap = getTotalVatAmount(invoiceEntityList);
			Map<String, BigDecimal> aocMap = getTotalAocAmount(invoiceEntityList);
			this.populateSummary(MiscBillingConstants.TOTAL_AMOUNT, amtMap, transmissionSummary);
			this.populateSummary(MiscBillingConstants.TAX, taxMap, transmissionSummary);
			this.populateSummary(MiscBillingConstants.VAT, vatMap, transmissionSummary);
			this.populateSummary(MiscBillingConstants.ADD_ON_CHARGE, aocMap, transmissionSummary);
		}
		return transmissionSummary;
	}
	
	public void populateSummary(String type, Map<String, BigDecimal> amtMap, TransmissionSummary transmissionSummary) {
		
		if(amtMap != null && amtMap.size() > 0) {
			log.debug(amtMap.toString());
			amtMap.forEach((key,value)-> {
				if(MiscBillingConstants.TOTAL_AMOUNT.equalsIgnoreCase(type)) {
					TransmissionSummary.TotalAmount totalAmount = new TransmissionSummary.TotalAmount();
					totalAmount.setCurrencyCode(key);
					totalAmount.setValue(value);
					transmissionSummary.getTotalAmount().add(totalAmount);
				} else if(MiscBillingConstants.TAX.equalsIgnoreCase(type)) {
					TransmissionSummary.TotalTaxAmount totalTaxAmount = new TransmissionSummary.TotalTaxAmount();
					totalTaxAmount.setCurrencyCode(key);
					totalTaxAmount.setValue(value);
					transmissionSummary.getTotalTaxAmount().add(totalTaxAmount);
				} else if(MiscBillingConstants.VAT.equalsIgnoreCase(type)) {	
					TransmissionSummary.TotalVATAmount totalVatAmount = new TransmissionSummary.TotalVATAmount();
					totalVatAmount.setCurrencyCode(key);
					totalVatAmount.setValue(value);
					transmissionSummary.getTotalVATAmount().add(totalVatAmount);
				} else if(MiscBillingConstants.ADD_ON_CHARGE.equalsIgnoreCase(type)) {	
					TransmissionSummary.TotalAddOnChargeAmount totalAocAmount = new TransmissionSummary.TotalAddOnChargeAmount();
					totalAocAmount.setCurrencyCode(key);
					totalAocAmount.setValue(value);
					transmissionSummary.getTotalAddOnChargeAmount().add(totalAocAmount);
				}
			});
		}
	}
	
	public Map<String, BigDecimal> getTotalAmount(List<MiscBillingTrnInvoiceEntity> invoiceEntityList) {

		Map<String,BigDecimal> totalAmountMap = invoiceEntityList.stream()
                    .filter(Objects::nonNull)
                    .filter(w -> StringUtils.isNoneBlank(w.getCurrencyCode()))
                    .map(w -> {
                        if (w.getTotalAmount() == null) {
                            w.setTotalAmount(BigDecimal.ZERO);
                        }
                        return w;
                    })
                   .collect(Collectors.groupingBy(MiscBillingTrnInvoiceEntity::getCurrencyCode,
                           Collectors.reducing(BigDecimal.ZERO, MiscBillingTrnInvoiceEntity::getTotalAmount,
                                   BigDecimal::add)));

		return totalAmountMap;
	}
	
	public Map<String, BigDecimal> getTotalTaxAmount(List<MiscBillingTrnInvoiceEntity> invoiceEntityList) {

		Map<String,BigDecimal> totalTaxAmtMap = invoiceEntityList.stream()
                    .filter(Objects::nonNull)
                    .filter(w -> StringUtils.isNoneBlank(w.getCurrencyCode()))
                    .map(w -> {
                    	if (w.getTotalTaxAmount() == null) {
                            w.setTotalTaxAmount(BigDecimal.ZERO);
                        }
                        return w;
                    })
                   .collect(Collectors.groupingBy(MiscBillingTrnInvoiceEntity::getCurrencyCode,
                           Collectors.reducing(BigDecimal.ZERO, MiscBillingTrnInvoiceEntity::getTotalTaxAmount, BigDecimal::add)));

		return totalTaxAmtMap;
	}
	
	public Map<String, BigDecimal> getTotalVatAmount(List<MiscBillingTrnInvoiceEntity> invoiceEntityList) {

		Map<String,BigDecimal> totalVatAmtMap = invoiceEntityList.stream()
                    .filter(Objects::nonNull)
                    .filter(w -> StringUtils.isNoneBlank(w.getCurrencyCode()))
                    .map(w -> {
                    	if (w.getTotalVatAmount() == null) {
                        	w.setTotalVatAmount(BigDecimal.ZERO);
                        }
                        return w;
                    })
                   .collect(Collectors.groupingBy(MiscBillingTrnInvoiceEntity::getCurrencyCode,
                           Collectors.reducing(BigDecimal.ZERO, MiscBillingTrnInvoiceEntity::getTotalVatAmount, BigDecimal::add)));

		return totalVatAmtMap;
	}
	
	public Map<String, BigDecimal> getTotalAocAmount(List<MiscBillingTrnInvoiceEntity> invoiceEntityList) {

		Map<String,BigDecimal> totalAocMap = invoiceEntityList.stream()
                    .filter(Objects::nonNull)
                    .filter(w -> StringUtils.isNoneBlank(w.getCurrencyCode()))
                    .map(w -> {
                    	if (w.getTotalAddonChargeAmount() == null) {
                        	w.setTotalAddonChargeAmount(BigDecimal.ZERO);
                        }
                        return w;
                    })
                   .collect(Collectors.groupingBy(MiscBillingTrnInvoiceEntity::getCurrencyCode,
                           Collectors.reducing(BigDecimal.ZERO, MiscBillingTrnInvoiceEntity::getTotalAddonChargeAmount, BigDecimal::add)));

		return totalAocMap;
	}
	
	public MiscBillingInvTransHeaderEntity getTransmissionHeaderEntity(TransmissionHeader transmissionHeader, int invoiceCount
			, int attachmentCount) {
		MiscBillingInvTransHeaderEntity invTransHeader = new MiscBillingInvTransHeaderEntity();
		invTransHeader.setClientId(commonValidator.getClientId());
		invTransHeader.setBillingMonth(commonValidator.getBillingMonth().toUpperCase());
		invTransHeader.setBillingPeriod(commonValidator.getBillingPeriod());
		invTransHeader.setTransmissionDateTime(transmissionHeader.getTransmissionDateTime());
		invTransHeader.setTransVersion(transmissionHeader.getVersion());
		invTransHeader.setTransmissionId(transmissionHeader.getTransmissionID());
		invTransHeader.setIssuingOrganizationId(transmissionHeader.getIssuingOrganizationID());
		invTransHeader.setInvoiceCount(invoiceCount);
		invTransHeader.setAttachmentCount(attachmentCount);
		invTransHeader.setBillingCategory(MiscBillingConstants.BILLING_CATEGORY);
		invTransHeader.setInwardOutwardFlag(MiscBillingConstants.OUTWARD);
		return invTransHeader;
	}

	public List<MiscBillInvTransTotalAmtEntity> processTransmissionSummary(TransmissionSummary  transmissionSummary,
			MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity) throws Exception {
		log.debug("Entering processSummary()");
		
		List<MiscBillInvTransTotalAmtEntity> transSummaryList = new ArrayList<MiscBillInvTransTotalAmtEntity>();
		List<TransmissionSummary.TotalAmount> totalAmountList = transmissionSummary.getTotalAmount();
		totalAmountList.forEach(amount -> {
			MiscBillInvTransTotalAmtEntity transSummaryEntity = new MiscBillInvTransTotalAmtEntity();
			transSummaryEntity.setAmountType(MiscBillingConstants.TOTAL_AMOUNT);
			transSummaryEntity.setCurrencyCode(amount.getCurrencyCode());
			transSummaryEntity.setTotalAmount(amount.getValue());
			transSummaryEntity.setMiscBillingInvTransHeader(miscBillingInvTransHeaderEntity);
			transSummaryList.add(transSummaryEntity);
		});
		
		List<TransmissionSummary.TotalAddOnChargeAmount> addOnChargeAmountList = transmissionSummary.getTotalAddOnChargeAmount();
		addOnChargeAmountList.forEach(addOnCharge -> {
			MiscBillInvTransTotalAmtEntity transSummaryEntity = new MiscBillInvTransTotalAmtEntity();
			transSummaryEntity.setAmountType(MiscBillingConstants.ADD_ON_CHARGE);
			transSummaryEntity.setCurrencyCode(addOnCharge.getCurrencyCode());
			transSummaryEntity.setTotalAmount(addOnCharge.getValue());
			transSummaryEntity.setMiscBillingInvTransHeader(miscBillingInvTransHeaderEntity);
			transSummaryList.add(transSummaryEntity);
		});
		
		List<TransmissionSummary.TotalTaxAmount> taxAmountList = transmissionSummary.getTotalTaxAmount();
		taxAmountList.forEach(taxAmount -> {
			MiscBillInvTransTotalAmtEntity transSummaryEntity = new MiscBillInvTransTotalAmtEntity();
			transSummaryEntity.setAmountType(MiscBillingConstants.TAX);
			transSummaryEntity.setCurrencyCode(taxAmount.getCurrencyCode());
			transSummaryEntity.setTotalAmount(taxAmount.getValue());
			transSummaryEntity.setMiscBillingInvTransHeader(miscBillingInvTransHeaderEntity);
			transSummaryList.add(transSummaryEntity);
		});
		
		List<TransmissionSummary.TotalVATAmount> vatAmountList = transmissionSummary.getTotalVATAmount();
		vatAmountList.forEach(vatAmount -> {
			MiscBillInvTransTotalAmtEntity transSummaryEntity = new MiscBillInvTransTotalAmtEntity();
			transSummaryEntity.setAmountType(MiscBillingConstants.VAT);
			transSummaryEntity.setCurrencyCode(vatAmount.getCurrencyCode());
			transSummaryEntity.setTotalAmount(vatAmount.getValue());
			transSummaryEntity.setMiscBillingInvTransHeader(miscBillingInvTransHeaderEntity);
			transSummaryList.add(transSummaryEntity);
		});
		
		miscBillingInvTransHeaderEntity.setMiscBillInvTransTotalAmt(transSummaryList);

		log.debug("Exiting processSummary(): " );
		return transSummaryList;
	}
}
