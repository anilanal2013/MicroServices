package com.sgl.smartpra.batch.mib.app.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.microsoft.sqlserver.jdbc.StringUtils;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraExceptionTransIntgAppClient;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MiscBillingService {

	@Value("${batch.directory.misc-billing.input}")
	private String miscBillingBatchInputDir;

	@Value("${batch.directory.misc-billing.duplicate}")
	private String miscBillingBatchDuplicateDir;

	@Value("${batch.directory.misc-billing.failed}")
	private String miscBillingBatchFailedDir;

	@Value("${batch.directory.misc-billing.processed}")
	private String miscBillingBatchProcessedDir;
	
	@Value("${env-prod}")
	private String envprod;

	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	@Qualifier(value = "iataXmlJob")
	private Job iataXmlJob;
	
	@Autowired
	@Qualifier(value = "outwardXmlJob")
	private Job outwardXmlJob;

	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	private BatchGlobalFeignClient batchGlobalFeignClient;
	
	@Autowired
	private MiscBillingUtil miscBillingUtil;
	
	@Autowired
	private CommonValidator commonValidator;
	
	@Autowired
	private SmartpraExceptionTransIntgAppClient exceptionTransIntgAppClient;
	 
	public String executeInboundJob(String fileName, String processedBy, String clientId) throws Exception {

		String hostCarrDesigCode = MiscBillingUtil.getHostCarrierDesigCode(smartpraMasterAppClient, clientId);
		if(StringUtils.isEmpty(hostCarrDesigCode)) {
			return "ClientId entered is invalid: " + clientId;
		}
		String defaultCarrierNumericCode = MiscBillingUtil.getHostCarrierCode(smartpraMasterAppClient, hostCarrDesigCode);
		commonValidator.setHostCarrierCode(hostCarrDesigCode);
		String dtStr = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());

		if (!SmartpraFileUtility.fileExists(miscBillingBatchInputDir + fileName)) {
			log.info("Miscellaneous Billing Batch input file not found (" + miscBillingBatchInputDir + fileName + ")");
			return "Batch input file not found (" + miscBillingBatchInputDir + fileName + ")";
		}

		List<FileLogging> fileLogList = batchGlobalFeignClient.getFileLogByFileName(fileName);
		if(MiscBillingConstants.YES.equals(envprod) && CollectionUtils.isNotEmpty(fileLogList)) {
			log.info("Miscellaneous Billing Batch input file (" + miscBillingBatchInputDir + fileName + ") is already loaded in database. Hence stopping the batch process.");
			SmartpraFileUtility.moveFile(miscBillingBatchInputDir + fileName, miscBillingBatchDuplicateDir + fileName + dtStr);
			return "Miscellaneous Billing Batch input file (" + miscBillingBatchInputDir + fileName + ") is already loaded in database. Hence stopping the batch process.";
		}
		
		FileLogging fileLogging = MiscBillingUtil.initFileLogging();
		fileLogging.setClientId(hostCarrDesigCode);
		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_INPUT);
		fileLogging.setFileName(fileName);
		fileLogging.setProcessedBy(processedBy);
		fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_MISC_BILLING_IN);
		fileLogging.setJobName(iataXmlJob.getName());
		fileLogging.setFileSize(SmartpraFileUtility.getFileSize(miscBillingBatchInputDir + fileName));

		FileErrorLog fileErrorLog;
		List<FileErrorLog> fileErrorLogList;

		// If file is empty
		if (SmartpraFileUtility.isEmptyFile(miscBillingBatchInputDir + fileName)) {
			String errorMsg = "Input file " + miscBillingBatchInputDir + fileName + " is empty.";
			if(MiscBillingConstants.YES.equals(envprod)) {
				SmartpraFileUtility.moveFile(miscBillingBatchInputDir + fileName, miscBillingBatchFailedDir + fileName + dtStr);
			}
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setRemarks(errorMsg);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("File is empty");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<FileErrorLog>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_MISC_BILLING_IN);
			batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}
		//is valid file
		Map<String, String> statusMap = MiscBillingUtil.isValidFile(defaultCarrierNumericCode, fileName);
		if (!statusMap.isEmpty() && statusMap.get(MiscBillingConstants.STATUS).equals(Boolean.FALSE.toString())) {
			String errorMsg = "Input file " + fileName + " invalid (file name pattern should be MXMLT-BBBCCCCCCCC.XML )";
			if(MiscBillingConstants.YES.equals(envprod)) {
				SmartpraFileUtility.moveFile(miscBillingBatchInputDir + fileName, miscBillingBatchFailedDir + fileName + dtStr);
			}
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setRemarks(errorMsg);
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Invalid File Input");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			// Call to exception framework-
			statusMap.remove(MiscBillingConstants.STATUS);
			ExceptionTransactionModel exceptionTxnModel = miscBillingUtil.prepareExceptionTransactionModel(
					MiscBillingConstants.MISC1001, statusMap, hostCarrDesigCode, fileLogging.getFileId().intValue());
				exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTxnModel);
			return errorMsg;
		}
		
		fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);

		// @formatter:off
		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addString("fileName", fileLogging.getFileName()).addString("clientId", hostCarrDesigCode)
				.addLong("fileId", fileLogging.getFileId().longValue()).toJobParameters();
		jobLauncher.run(iataXmlJob, jobParameters);
		// @formatter:on
		return "Job executed";

	}
	
	public String executeOutBoundJob() throws Exception {
		String hostCarrDesigCode = MiscBillingUtil.getHostCarrierDesigCode(smartpraMasterAppClient);
		if(!StringUtils.isEmpty(hostCarrDesigCode)) {
			JobParameters jobParameters = new JobParametersBuilder()
				.addLong("time", System.currentTimeMillis())
				.addString("clientId", hostCarrDesigCode)
				.toJobParameters();
		
			jobLauncher.run(outwardXmlJob, jobParameters);
			return "Job executed";
		}
		return "Job Failed!!";
	}
}
