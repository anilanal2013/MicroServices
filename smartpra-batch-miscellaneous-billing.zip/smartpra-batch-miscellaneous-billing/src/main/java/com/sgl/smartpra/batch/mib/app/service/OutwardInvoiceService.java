/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.mapper.InvoiceHeaderMapper;
import com.sgl.smartpra.batch.mib.app.mapper.InvoiceSummaryMapper;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.jaxb.dictionary.BooleanFlag;
import com.sgl.smartpra.mib.jaxb.dictionary.CorrespondenceFlag;
import com.sgl.smartpra.mib.jaxb.dictionary.DigitalSignatureFlag;
import com.sgl.smartpra.mib.jaxb.dictionary.InvoiceType;
import com.sgl.smartpra.mib.jaxb.dictionary.RejectionFlag;
import com.sgl.smartpra.mib.jaxb.dictionary.SettlementMethod;
import com.sgl.smartpra.mib.jaxb.dictionary.SuspendedFlag;
import com.sgl.smartpra.mib.jaxb.standard.Address;
import com.sgl.smartpra.mib.jaxb.standard.BuyerOrganization;
import com.sgl.smartpra.mib.jaxb.standard.CorrespondenceDetails;
import com.sgl.smartpra.mib.jaxb.standard.ISDetails;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceHeader;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceSummary;
import com.sgl.smartpra.mib.jaxb.standard.RejectedInvoiceDetails;
import com.sgl.smartpra.mib.jaxb.standard.SellerOrganization;
import com.sgl.smartpra.mib.repository.MiscBillingTrnInvoiceDataRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class OutwardInvoiceService {

	@Autowired
	private MiscBillingTrnInvoiceDataRepository invoiceRepository;
	
	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	private InvoiceHeaderMapper invoiceHeaderMapper;
	
	@Autowired
	private InvoiceSummaryMapper invoiceSummaryMapper;
	
	@Autowired
	private TaxDetailsService taxDetailsService;
	
	@Autowired
	private AddOnChargeDtlService addOnChargeDtlService;

	@Autowired
	private CommonValidator commonValidator; 
	
	@Autowired
	private SupportingDetailService suppDtlService;
	
	public String generateInvoiceNo(String clientId, String fy, String carrierCode) {
		log.debug("Start of generateInvoiceNo() " + carrierCode);
		String invoiceNo;
		String maxInvoiceNo = invoiceRepository.getMaxInvoiceNo(clientId, new StringBuffer("M").append(carrierCode).append(fy).toString());

		if(StringUtils.isBlank(maxInvoiceNo)) {
			invoiceNo = new StringBuffer("M").append(carrierCode).append(fy).append("00001").toString();
		} else {
			Integer subInv = Integer.parseInt(maxInvoiceNo.substring(5));
			subInv++;
			String invoiceSeq = getInvoiceSeq(subInv);
			invoiceNo = new StringBuffer("M").append(carrierCode).append(fy).append(invoiceSeq).toString();
		}
		log.debug("End of generateInvoiceNo() " + invoiceNo);
		return invoiceNo;
	}
	
	public String generateBatchNo(String inwardOutwardFlag, String clientId, String maxBatchNo, String fy) {
		log.debug("Start of generateBatchNo() " + clientId);
		String batchNo;

		if(StringUtils.isBlank(maxBatchNo)) {
			batchNo = "M" + inwardOutwardFlag + fy + "000001";
		} else {
			// MI19000001 => 000001
			Integer subInv = Integer.parseInt(maxBatchNo.substring(4));
			subInv++;
			batchNo = "M" + inwardOutwardFlag + fy + getBatchSeq(subInv);
		}
		log.debug("End of generateInvoiceNo() " + batchNo);
		return batchNo;
	}
	
	public String getMaxBatchNo(String inwardOutwardFlag, String clientId, String fy) {
		log.debug("getMaxBatchNo():- clientId: " + clientId + ", fy = " + fy);
		return invoiceRepository.getMaxBatchNo(clientId, new StringBuffer("M").append(inwardOutwardFlag).append(fy).toString());
	}
	
	public String getCurrentFy(String clientId) {
		FinancialMonthModel financialMonthModel = null;
		String fy = MiscBillingConstants.EMPTY_STRING;
		try {
			financialMonthModel = smartpraMasterAppClient.getCurrentOpenFinancialMonthForFinancialCalendar(clientId);
		} catch (Exception e) {
			log.error("Error thrown while calling method getCurrentOpenFinancialMonthForFinancialCalendar() " + e.getMessage());
			e.printStackTrace();
		}
		if(financialMonthModel != null) {
			fy = financialMonthModel.getFinancialYear().substring(0,2).toUpperCase();
		}
		return fy;
	}
	
	public void populateBatchNoInInvoices(String clientId, String inwardOutwardFlag, List<MiscBillingTrnInvoiceEntity> invoiceEntityList){
		String fy = getCurrentFy(clientId);
		String maxBatchNo = getMaxBatchNo(inwardOutwardFlag, clientId, fy);
		log.debug("maxBatchNo: " + maxBatchNo + ", fy = " + fy);
		for (MiscBillingTrnInvoiceEntity invoiceEntity : invoiceEntityList) {
			String invoiceUrn = generateBatchNo(inwardOutwardFlag, clientId, maxBatchNo, fy);
		   	invoiceEntity.setInvoiceUrn(invoiceUrn);
		   	maxBatchNo = invoiceUrn;
		}  
	}

	public String getInvoiceSeq(Integer subInv) {
		String invoiceSeq;
		String subStr = subInv.toString();
		// 00001, 00011, 00111, 01111, 11111
		if(subStr.length() == 1) {
			invoiceSeq = "0000" + subStr; 
		} else if(subStr.length() == 2) {
			invoiceSeq = "000" + subStr;
		} else if(subStr.length() == 3) {
			invoiceSeq = "00" + subStr;
		} else if(subStr.length() == 4) {
			invoiceSeq = "0" + subStr;
		} else {
			invoiceSeq = subStr;
		}
		return invoiceSeq;
	}
	
	public String getBatchSeq(Integer subInv) {
		String batchSeq;
		String subStr = subInv.toString();
		// 000001, 000011, 000111, 001111, 011111, 111111
		if(subStr.length() == 1) {
			batchSeq = "00000" + subStr; 
		} else if(subStr.length() == 2) {
			batchSeq = "0000" + subStr;
		} else if(subStr.length() == 3) {
			batchSeq = "000" + subStr;
		} else if(subStr.length() == 4) {
			batchSeq = "00" + subStr;
		} else if(subStr.length() == 5) {
			batchSeq = "0" + subStr;
		} else {
			batchSeq = subStr;
		}
		return batchSeq;
	}
	public InvoiceHeader getInvoiceHeader(MiscBillingTrnInvoiceEntity invoiceEntity) {
		
		InvoiceHeader invoiceHeader = new InvoiceHeader();
		invoiceHeaderMapper.mapEntityToInvoiceHeader(invoiceEntity, invoiceHeader);
		ISDetails isDetails = new ISDetails();
		if(MiscBillingConstants.I.equals(invoiceEntity.getInvoiceType())) {
			invoiceHeader.setInvoiceType(InvoiceType.fromValue(MiscBillingConstants.INVOICE));
		} else if(MiscBillingConstants.C.equals(invoiceEntity.getInvoiceType())) {
			invoiceHeader.setInvoiceType(InvoiceType.fromValue(MiscBillingConstants.CREDIT_NOTE));
		}
		invoiceHeader.setPONumber(invoiceEntity.getPoNumber());
		if(StringUtils.isNotBlank(invoiceEntity.getDigitalSignatureFlag())){
			isDetails.setDigitalSignatureFlag(DigitalSignatureFlag.fromValue(invoiceEntity.getDigitalSignatureFlag()));
		}
		if(StringUtils.isNotBlank(invoiceEntity.getSuspendedFlag())){
			isDetails.setSuspendedFlag(SuspendedFlag.fromValue(invoiceEntity.getSuspendedFlag()));
		}
		if(StringUtils.isNotBlank(invoiceEntity.getCorrespondanceFlag()) && MiscBillingConstants.YES.equalsIgnoreCase(invoiceEntity.getCorrespondanceFlag())){
			isDetails.setCorrespondenceFlag(CorrespondenceFlag.fromValue(invoiceEntity.getCorrespondanceFlag()));
			CorrespondenceDetails correspondenceDetails = new CorrespondenceDetails();
			correspondenceDetails.setInvoiceNumber(invoiceEntity.getOriginalInvoiceNumber());
			correspondenceDetails.setCorrespondenceRefNumber(BigInteger.valueOf(invoiceEntity.getCorrespondanceRefNo()));
			correspondenceDetails.setAuthorityToBillFlag(BooleanFlag.fromValue(invoiceEntity.getAuthorityToBillFlag()));
			isDetails.setCorrespondenceDetails(correspondenceDetails);
		}
		if(StringUtils.isNotBlank(invoiceEntity.getRejectionFlag()) && MiscBillingConstants.YES.equalsIgnoreCase(invoiceEntity.getRejectionFlag())){
			isDetails.setRejectionFlag(RejectionFlag.fromValue(invoiceEntity.getRejectionFlag()));
			RejectedInvoiceDetails rejectedInvoiceDetails = new RejectedInvoiceDetails();
			rejectedInvoiceDetails.setRejectionStage(BigInteger.valueOf(invoiceEntity.getRejectionStage()));
			rejectedInvoiceDetails.setInvoiceNumber(invoiceEntity.getOriginalInvoiceNumber());
			if(StringUtils.isNotBlank(invoiceEntity.getOrginalBillingMonth())){
				String month = MiscBillingUtil.getMonthInDigit(invoiceEntity.getOrginalBillingMonth().substring(0, 3));
				String yr = invoiceEntity.getOrginalBillingMonth().substring(4);
				rejectedInvoiceDetails.setSettlementMonthPeriod(new StringBuffer(yr).append(month)
						.append("0").append(invoiceEntity.getOriginalBillingPeriod()).toString());
			}
			isDetails.setRejectedInvoiceDetails(rejectedInvoiceDetails);
		}
		if(StringUtils.isNotBlank(invoiceEntity.getSettlementMethod())){
			invoiceHeader.getPaymentTerms().setSettlementMethod(SettlementMethod.fromValue(invoiceEntity.getSettlementMethod()));
		}
		if(StringUtils.isNotBlank(invoiceEntity.getSettlementMonthPeriod())){
			invoiceHeader.getPaymentTerms().setSettlementMonthPeriod(invoiceEntity.getSettlementMonthPeriod());
		}
		Map<String, String> chargeCategoryMap = commonValidator.getChargeCategoryMap();
		invoiceHeader.setChargeCategory(chargeCategoryMap.get(invoiceEntity.getChargeCategoryCode()));
		invoiceHeader.setISDetails(isDetails);
		invoiceHeader.setSellerOrganization(getSellerOrganization(invoiceEntity));
		invoiceHeader.setBuyerOrganization(getBuyerOrganization(invoiceEntity));
		return invoiceHeader;
	}
	
	public BuyerOrganization getBuyerOrganization(MiscBillingTrnInvoiceEntity invoiceEntity) {
		BuyerOrganization buyerOrganization = new BuyerOrganization();
		String carrierNumericCode = invoiceEntity.getBuyerOrganizationId(); 
		buyerOrganization.setOrganizationID(carrierNumericCode); 
		buyerOrganization.setLocationID(invoiceEntity.getBuyerLocationId());
		Carrier carrier = null;
		if(StringUtils.isNotBlank(carrierNumericCode)) {
			carrier = commonValidator.getCarrier();
			if(carrier != null) {
				if(carrier.getCarrierName1().isPresent()) buyerOrganization.setOrganizationName1(carrier.getCarrierName1().get());
				if(carrier.getTaxRegistrationId().isPresent()) buyerOrganization.setTaxRegistrationID(carrier.getTaxRegistrationId().get());
				if(carrier.getCompanyRegistrationId().isPresent()) buyerOrganization.setCompanyRegistrationID(carrier.getCompanyRegistrationId().get());
				BuyerOrganization.Address address = new BuyerOrganization.Address();
				if(carrier.getCarrierAddress1().isPresent()) address.setAddressLine1(carrier.getCarrierAddress1().get());
				if(carrier.getCarrierAddress2().isPresent()) address.setAddressLine2(carrier.getCarrierAddress2().get());
				if(carrier.getCarrierAddress3().isPresent()) address.setAddressLine3(carrier.getCarrierAddress3().get());
				if(carrier.getCityCode().isPresent()) address.setCityName(carrier.getCityCode().get());
				if(carrier.getSubDivisionCode().isPresent()) address.setSubdivisionCode(carrier.getSubDivisionCode().get());
				if(carrier.getSubDivisionName().isPresent()) address.setSubdivisionName(carrier.getSubDivisionName().get());
				if(carrier.getCountryCode().isPresent()) {
					address.setCountryCode(carrier.getCountryCode().get());
					address.setCountryName(commonValidator.getCountryMap().get(carrier.getCountryCode().get()));
				}
				buyerOrganization.setContactName(commonValidator.getSysParamMap().get(MiscBillingConstants.PARAM_DEFAULT_PROCESSING_MANAGER));
				if(carrier.getPostalCode().isPresent()) address.setPostalCode(carrier.getPostalCode().get());
				buyerOrganization.setAddress(address);
				buyerOrganization.getContactDetails().addAll(suppDtlService.getContactDetails(carrier));
			}
	   	}
		return buyerOrganization;
	}
	
	// Outward: Seller -> host
	public SellerOrganization getSellerOrganization(MiscBillingTrnInvoiceEntity invoiceEntity) {
		SellerOrganization sellerOrganization = new SellerOrganization();
		String hostCarrierCode = commonValidator.getSysParamMap().get(MiscBillingConstants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE);
		if(StringUtils.isNotBlank(hostCarrierCode)) {
			commonValidator.populateHostCarrier(hostCarrierCode);
		}
		sellerOrganization.setOrganizationID(hostCarrierCode);
		sellerOrganization.setLocationID(invoiceEntity.getSellerLocationId());
		Carrier carrier = null;
		if(StringUtils.isNotBlank(hostCarrierCode)) {
			carrier = commonValidator.getHostCarrier();
			if(carrier != null) {
				if(carrier.getCarrierName1().isPresent()) sellerOrganization.setOrganizationName1(carrier.getCarrierName1().get());
				if(carrier.getTaxRegistrationId().isPresent()) sellerOrganization.setTaxRegistrationID(carrier.getTaxRegistrationId().get());
				if(carrier.getCompanyRegistrationId().isPresent()) sellerOrganization.setCompanyRegistrationID(carrier.getCompanyRegistrationId().get());
				Address address = new Address();
				if(carrier.getCarrierAddress1().isPresent()) address.setAddressLine1(carrier.getCarrierAddress1().get());
				if(carrier.getCarrierAddress2().isPresent()) address.setAddressLine2(carrier.getCarrierAddress2().get());
				if(carrier.getCarrierAddress3().isPresent()) address.setAddressLine3(carrier.getCarrierAddress3().get());
				if(carrier.getCityCode().isPresent()) address.setCityName(carrier.getCityCode().get());
				if(carrier.getSubDivisionCode().isPresent()) address.setSubdivisionCode(carrier.getSubDivisionCode().get());
				if(carrier.getSubDivisionName().isPresent()) address.setSubdivisionName(carrier.getSubDivisionName().get());
				if(carrier.getCountryCode().isPresent()) {
					address.setCountryCode(carrier.getCountryCode().get());
					address.setCountryName(commonValidator.getCountryMap().get(carrier.getCountryCode().get()));
				}
				sellerOrganization.setContactName(commonValidator.getSysParamMap().get(MiscBillingConstants.PARAM_DEFAULT_PROCESSING_MANAGER));
				if(carrier.getPostalCode().isPresent()) address.setPostalCode(carrier.getPostalCode().get());
				sellerOrganization.setAddress(address);
				sellerOrganization.getContactDetails().addAll(suppDtlService.getContactDetails(carrier));
			}
	   	}
		return sellerOrganization;
	}
	
	public InvoiceSummary getInvoiceSummary(MiscBillingTrnInvoiceEntity invoiceEntity) {
		InvoiceSummary invoiceSummary = new InvoiceSummary();
		invoiceSummaryMapper.mapEntityToInvoiceSummary(invoiceEntity, invoiceSummary);
		if(invoiceEntity.getMiscBillingTaxDetails() != null && invoiceEntity.getMiscBillingTaxDetails().size() > 0) {
			List<MiscBillingTaxDetailsEntity> taxEntityList = invoiceEntity.getMiscBillingTaxDetails().stream()
					.filter(x -> MiscBillingConstants.INVOICE.equalsIgnoreCase(x.getTaxLevel())).collect(Collectors.toList());
			invoiceSummary.getTax().addAll(taxDetailsService.getTaxDetails(taxEntityList));
		}
		if(invoiceEntity.getMiscBillingAddOnChargeDtl() != null && invoiceEntity.getMiscBillingAddOnChargeDtl().size() > 0) {
			List<MiscBillingAddOnChargeDtlEntity> aocEntityList = invoiceEntity.getMiscBillingAddOnChargeDtl().stream()
					.filter(x -> MiscBillingConstants.INVOICE.equalsIgnoreCase(x.getAddOnLevel())).collect(Collectors.toList());
			invoiceSummary.getAddOnCharges().addAll(addOnChargeDtlService.getAddOnChargeDetailsForInvSummary(aocEntityList));
		}
		return invoiceSummary;
	}
	
	// 157, 20110603, 20190429193028.xml
	public String generateOutwardBillingFileName(String carrierCode, String YYYYMMPP) {
		StringBuilder fileName = new StringBuilder(MiscBillingConstants.FILE_NAME_PREFIX);
		LocalDateTime dateTime = LocalDateTime.now();
		String date = dateTime.format(DateTimeFormatter.BASIC_ISO_DATE);
		String timestamp = dateTime.getHour() + "" + dateTime.getMinute() + "" + dateTime.getSecond();
		fileName.append(carrierCode).append(YYYYMMPP).append(date).append(timestamp).append(MiscBillingConstants.XML);
		log.debug("generateOutwardBillingFileName() " + fileName.toString());
		return fileName.toString();
	}
	
	public String generateBillingMonthAndPeriodInYYYYMMPPFormat() {
		String YYYYMMPP = MiscBillingConstants.EMPTY_STRING;
		String billingMonth = commonValidator.getBillingMonth(); 
		if(StringUtils.isNotBlank(billingMonth)) {
			String month = MiscBillingUtil.getMonthInDigit(billingMonth.toUpperCase().substring(0, 3));
			String yr = billingMonth.substring(4);
			if(StringUtils.isNotBlank(yr) && yr.length() == 2) {
				yr = MiscBillingConstants.TWENTY + yr;
			}
			YYYYMMPP = new StringBuffer(yr).append(month).append(MiscBillingConstants.ZERO)
										   .append(commonValidator.getBillingPeriod()).toString();
		}
		return YYYYMMPP;
	}
	
	public void populateInvoicesInHeader(MiscBillingInvTransHeaderEntity transHeaderEntity, List<MiscBillingTrnInvoiceEntity> invoiceEntityList){
		
		for (MiscBillingTrnInvoiceEntity invoiceEntity : invoiceEntityList) {
			invoiceEntity.setMiscBillingInvTransHeader(transHeaderEntity);
		}
		transHeaderEntity.setMiscBillingTrnInvoices(invoiceEntityList);
	}
}
