package com.sgl.smartpra.batch.mib.app.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ZipUtil {
    private List<String> fileList;
	
    ZipUtil(){
    	fileList = new ArrayList<String>();
    }

    /**
     * Zip it
     * @param zipFile output ZIP file location
     */
    public void zipIt(String zipFile, String source){

	     byte[] buffer = new byte[1024];
	     try{
	    	FileOutputStream fos = new FileOutputStream(zipFile);
	    	ZipOutputStream zos = new ZipOutputStream(fos);
	    	log.debug("Output to Zip : " + zipFile);
	    		
	    	for(String file : this.fileList){
	    		log.debug("File Added : " + file);
	    		ZipEntry ze= new ZipEntry(file);
	        	zos.putNextEntry(ze);
	               
	        	FileInputStream in = new FileInputStream(source + File.separator + file);
	        	int len;
	        	while ((len = in.read(buffer)) > 0) {
	        		zos.write(buffer, 0, len);
	        	}
	        	in.close();
	    	}
	    		
	    	zos.closeEntry();
	    	zos.close();
	    	log.debug("Done..");
	    }catch(IOException ex){
	       ex.printStackTrace();   
	    }
   }
    
    /**
     * Traverse a directory and get all files,
     * and add the file into fileList  
     * @param node file or directory
     */
    public void generateFileList(File node, String source){
	    //add file only
		if(node.isFile()){
			fileList.add(generateZipEntry(node.getAbsoluteFile().toString(), source));
		}
			
		if(node.isDirectory()){
			String[] subNote = node.list();
			for(String filename : subNote){
				generateFileList(new File(node, filename), source);
			}
		}
    }

    /**
     * Format the file path for zip
     * @param file file path
     * @return Formatted file path
     */
    private String generateZipEntry(String file, String source){
    	return file.substring(source.length()+1, file.length());
    }
}