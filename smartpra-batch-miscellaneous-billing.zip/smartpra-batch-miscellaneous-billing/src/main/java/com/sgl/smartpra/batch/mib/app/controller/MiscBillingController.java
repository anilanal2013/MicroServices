package com.sgl.smartpra.batch.mib.app.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.mib.app.service.InwardInvoiceService;
import com.sgl.smartpra.batch.mib.app.service.MiscBillingService;
import com.sgl.smartpra.batch.mib.app.service.OutwardSupportingDocService;
import com.sgl.smartpra.batch.mib.app.service.SupportingDocService;
import com.sgl.smartpra.excep.resolution.model.ExceptionValidationModel;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class MiscBillingController {
	
	@Autowired
	private MiscBillingService miscBillingService;
	
	@Autowired
	private SupportingDocService supportingDocService;
	
	@Autowired
	private OutwardSupportingDocService outwardSuppDocService;
	
	@Autowired
	private InwardInvoiceService inwardInvoiceService;
	
	@RequestMapping("/miscellaneous-billing/invokejob")
	public String invokeInboundJob(@RequestParam("fileName") String fileName, @RequestParam("clientId") String clientId) throws Exception {
		log.debug("In invokeInboundJob()");
		return miscBillingService.executeInboundJob(fileName, "Manual", clientId);
	}
	
	@RequestMapping("/miscellaneous-billing/invokeoutwardjob")
	public String invokeGenerateOutwardXml() throws Exception {
		log.debug("In invokeGenerateOutwardXml()");
		return miscBillingService.executeOutBoundJob();
	}
	
	@PostMapping("/miscellaneous-billing/re-validate")
	public ExceptionValidationModel reValidation(@RequestBody ExceptionValidationModel exceptionValidationModel) throws Exception {
		log.debug("In reValidation()");
		return inwardInvoiceService.getReValidationResults(exceptionValidationModel);
	}
	
	@GetMapping("/miscellaneous-billing/invokejob/suppdoc")
	public String invokejobSuppDoc(@RequestParam(value="clientId", required=true) String clientId){
		log.debug("In invokejobSuppDoc()");
		return supportingDocService.invokejobSuppDoc(clientId);
	}
	
	@GetMapping("/miscellaneous-billing/outward/suppdoc")
	public String outwardSuppDoc(@RequestParam(value="clientId", required=true) String clientId, 
			@RequestParam(value="billingMonth", required=true) String billingMonth,
			@RequestParam(value="billingPeriod", required=true) String billingPeriod){
		log.debug("In invokejobSuppDoc()");
		return outwardSuppDocService.outwardSuppDoc(clientId, billingMonth, billingPeriod);
	}	
}

