package com.sgl.smartpra.batch.mib.app.processor;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.batch.mib.app.validator.InvoiceValidator;
import com.sgl.smartpra.batch.mib.app.validator.TransmissionHeaderValidator;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.utils.MiscBillingCommonUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MiscBillingValidatorProcessor {

	@Autowired
    private TransmissionHeaderValidator transmissionHeaderValidator;

    @Autowired
    private InvoiceValidator invoiceValidator;

    @Autowired
    private CommonValidator commonValidator;
    
    @Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
    
    @Autowired
	private FeignConfiguration.SmartpraExceptionTransIntgAppClient smartpraExceptionTransIntgAppClient;
    
	public void validate(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity) {
		OutwardBillingPeriods outwardBillingPeriods = null;
		try {
			outwardBillingPeriods = smartpraMasterAppClient.getCurrentOpenOutwardBillingPeriods(miscBillingInvTransHeaderEntity.getClientId());
			commonValidator.setBillingPeriodEndDate(MiscBillingCommonUtil.convertLocalDateToString("yyyy-MM-dd", outwardBillingPeriods.getEndDate()));
		} catch (Exception e) {
			log.error("Exception thrown while calling getCurrentOpenOutwardBillingPeriods(clientId): " + e.getMessage());
			e.printStackTrace();
		}
		List<ExceptionTransactionModel> alExceptionTransactionModels = transmissionHeaderValidator.validate(miscBillingInvTransHeaderEntity);
		Multimap<String,ExceptionTransactionModel> mErr = ArrayListMultimap.create();
		
		List<MiscBillingTrnInvoiceEntity> invoiceEntityList = miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices();
		for (MiscBillingTrnInvoiceEntity invoiceEntity : invoiceEntityList) {
			commonValidator.populateCommonFields(MiscBillingConstants.INWARD, invoiceEntity);
			invoiceValidator.validateInvoiceTxn(invoiceEntity, mErr);
			commonValidator.reset();
		}
		
		long open = miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices().stream().filter(x -> x.getInvoiceStatus().equals("OP")).count();
		long error = miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices().stream().filter(x -> x.getInvoiceStatus().equals("ER")).count();
		log.debug("Step:1 : Open: " + open + ", error: " + error);

		if (CollectionUtils.isNotEmpty(alExceptionTransactionModels)) {
			log.debug("alExceptionTransactionModels count: " + alExceptionTransactionModels.size());
			try {
				for (ExceptionTransactionModel e : alExceptionTransactionModels) {
					log.debug("ExceptionCode: " + e.getExceptionCode() + ", invoiceUrn: " + e.getInvoiceUrn() + ", invoiceNo: " + e.getBatchKey4());
					smartpraExceptionTransIntgAppClient.initExceptionTrasaction(e);
				}	
			} catch (Exception e) {
				log.error(e.getMessage());
				e.printStackTrace();
			}
		}
		open = miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices().stream().filter(x -> x.getInvoiceStatus().equals("OP")).count();
		error = miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices().stream().filter(x -> x.getInvoiceStatus().equals("ER")).count();
		log.debug("Step:2 : Open: " + open + ", error: " + error);

		if(mErr != null && !mErr.isEmpty()) {
			mErr.asMap().forEach((k,v) -> v.forEach(w -> {
				try {
					log.debug("key: " + k + ", value: " + w.getExceptionCode() + ", invoiceNo: " + w.getBatchKey4());
					smartpraExceptionTransIntgAppClient.initExceptionTrasaction(w);
				} catch (Exception e) {
					log.error(e.getMessage());
				}
			}));

			for (MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity: miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices()) {
				boolean excepType = false;
				if (mErr.containsKey(miscBillingTrnInvoiceEntity.getInvoiceUrn())){
					log.debug("InvoiceUrn: " + miscBillingTrnInvoiceEntity.getInvoiceUrn());
					List<ExceptionTransactionModel> exList = (List<ExceptionTransactionModel>) mErr.get(miscBillingTrnInvoiceEntity.getInvoiceUrn());
					List<String> exCode = exList.stream().map(x -> x.getExceptionCode()).distinct().collect(Collectors.toList());
					if(CollectionUtils.isNotEmpty(exList)) {
						excepType = exList.stream().filter(x -> !("MISC1106".equalsIgnoreCase(x.getExceptionCode()) || "MISC1135".equalsIgnoreCase(x.getExceptionCode())))
								.filter(Objects::nonNull).count() > 0;
					}
					log.debug("excepType: " + excepType + ", exceptionCodes: " + exCode.toString());
					if(excepType) {
						miscBillingTrnInvoiceEntity.setInvoiceStatus("ER");
						miscBillingTrnInvoiceEntity.getMiscBillingInvLineitem().forEach(x -> x.setProcessStatus("ER"));
					}
				}
			}
			open = miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices().stream().filter(x -> x.getInvoiceStatus().equals("OP")).count();
			error = miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices().stream().filter(x -> x.getInvoiceStatus().equals("ER")).count();
			log.debug("Step:3 : Open: " + open + ", error: " + error);
		}
	}
}
