package com.sgl.smartpra.batch.mib.app.controller;


import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.sgl.smartpra.batch.mib.app.service.InvoiceSupportingDocumentService;
import com.sgl.smartpra.mib.domain.MiscBillingInvSupportingDoc;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("suppdoc")
public class InvoiceSupportingDocumentController {

	@Autowired
	private InvoiceSupportingDocumentService invoiceSupportingDocumentService;
	
	@GetMapping("/search")
	public List<MiscBillingInvSupportingDoc> search(@RequestParam(value="clientId", required=true) String clientId, 
			@RequestParam(value="billingMonth", required=false) Optional<String> billingMonth,
			@RequestParam(value="billingPeriod", required=false) Optional<Integer> billingPeriod,
			@RequestParam(value="billingCarrier", required=false) Optional<String> billingCarrier,
			@RequestParam(value="billingType", required=false) Optional<String> billingType,
			@RequestParam(value="billedCarrier", required=false) Optional<String> billedCarrier,
			@RequestParam(value="transactionType", required= false) Optional<String> transactionType,
			@RequestParam(value="carrierCode", required= false) Optional<String> carrierCode,
			@RequestParam(value="documentNo", required=false) Optional<String> documentNo,
			@RequestParam(value="couponNo", required=false) Optional<Integer> couponNo,
			@RequestParam(value="memoNo", required= false) Optional<String> memoNo,
			@RequestParam(value="fimNo", required= false) Optional<String> fimNo)  {
		
		return invoiceSupportingDocumentService.search(clientId, billingMonth, billingPeriod, billingCarrier, billingType, billedCarrier, transactionType, carrierCode, documentNo, couponNo, memoNo, fimNo);
		
	}
	
	@GetMapping("/attachment-list")
	public List<MiscBillingInvSupportingDoc> getAttachmentList(@RequestParam(value="clientId", required=true) String clientId
			,@RequestParam(value="invoice_urn", required=true) String invoice_urn){
		return invoiceSupportingDocumentService.getAttachmentList(clientId, invoice_urn);
		
	}
	
	@PostMapping("/save")
	public MiscBillingInvSupportingDoc saveSupportingDocument(@RequestParam(value="clientId", required=true) String clientId, 
			@RequestParam(value="billingMonth", required=true) String billingMonth,
			@RequestParam(value="billingPeriod", required=true) Integer billingPeriod,
			@RequestParam(value="buyerId", required=true) String buyerId,
			@RequestParam(value="sellerId", required=true) String sellerId,
			@RequestParam(value="inwardOutwardFlag", required= true) String inwardOutwardFlag,
			@RequestParam(value="batchNo", required=true) String batchNo,
			@RequestParam(value="createdBy", required=true) Optional<String> createdBy,
			@RequestParam(value="file", required=false) List<MultipartFile> supportingDocuments) throws Exception {
				
		return invoiceSupportingDocumentService.saveSupportingDocument(clientId, billingMonth, billingPeriod, buyerId, sellerId, inwardOutwardFlag, batchNo, createdBy, supportingDocuments);
		
	}
	
	@PostMapping("/delete")
	public String deleteSupportingDocument(@RequestBody List<MiscBillingInvSupportingDoc> miscBillingInvSupportingDocList) throws IOException {
				
		return invoiceSupportingDocumentService.deleteSupportingDocument(miscBillingInvSupportingDocList);
		 
		
	}
	

	
}
