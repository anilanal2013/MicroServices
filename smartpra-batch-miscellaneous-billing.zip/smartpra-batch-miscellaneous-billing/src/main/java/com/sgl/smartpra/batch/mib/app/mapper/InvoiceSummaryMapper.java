package com.sgl.smartpra.batch.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.IntegerToBigInteger;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ReturnSumFromList;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceSummary;

/**
 * @author kanprasa
 *
 */
@Mapper(uses = QualifiedByUtil.class, componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface InvoiceSummaryMapper {

	@Mapping(source = "totalAmountInClearanceCurrency", target = "totalClearanceCurrencyAmt")
	@Mapping(source = "totalAmount.value", target = "totalAmount")
	@Mapping(source = "totalVATAmount", target = "totalVatAmount")
	@Mapping(source = "totalAddOnChargeAmount.value", target = "totalAddonChargeAmount")
	@Mapping(target = "addonChargeAmount", source="addOnCharges", qualifiedBy = ReturnSumFromList.class)
	public void mapInvoiceSummaryToEntity(InvoiceSummary invoiceSummary, @MappingTarget MiscBillingTrnInvoiceEntity invoiceEntity);

	@Mapping(source = "totalAddonChargeAmount", target = "totalAddOnChargeAmount.value")
	@Mapping(source = "totalVatAmount", target = "totalVATAmount")
	@Mapping(source = "totalAmount", target = "totalAmount.value")
	@Mapping(source = "totalClearanceCurrencyAmt", target = "totalAmountInClearanceCurrency")
	@Mapping(source = "noOfAttachments", target="attachmentCount")	
	public void mapEntityToInvoiceSummary(MiscBillingTrnInvoiceEntity invoiceEntity, @MappingTarget InvoiceSummary invoiceSummary);

}
