/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.validator;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Multimap;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.SectionDto;
import com.sgl.smartpra.mib.entity.MiscBillingSupportingDetailEntity;
import com.sgl.smartpra.mib.jaxb.standard.AccommodationDetails;
import com.sgl.smartpra.mib.jaxb.standard.AircraftDetails;
import com.sgl.smartpra.mib.jaxb.standard.AreaDetails;
import com.sgl.smartpra.mib.jaxb.standard.CarDetails;
import com.sgl.smartpra.mib.jaxb.standard.CateringDetails;
import com.sgl.smartpra.mib.jaxb.standard.ConsumptionDetails;
import com.sgl.smartpra.mib.jaxb.standard.Density;
import com.sgl.smartpra.mib.jaxb.standard.EmployeeDetails;
import com.sgl.smartpra.mib.jaxb.standard.FlightDetails;
import com.sgl.smartpra.mib.jaxb.standard.MailDetails;
import com.sgl.smartpra.mib.jaxb.standard.MaxTakeOffWeight;
import com.sgl.smartpra.mib.jaxb.standard.MealType;
import com.sgl.smartpra.mib.jaxb.standard.MiscData;
import com.sgl.smartpra.mib.jaxb.standard.MiscDetails;
import com.sgl.smartpra.mib.jaxb.standard.ParkingDetails;
import com.sgl.smartpra.mib.jaxb.standard.PassengerDetails;
import com.sgl.smartpra.mib.jaxb.standard.RouteDateTime;
import com.sgl.smartpra.mib.jaxb.standard.RouteDetails;
import com.sgl.smartpra.mib.jaxb.standard.SettlementDetails;
import com.sgl.smartpra.mib.jaxb.standard.Temperature;
import com.sgl.smartpra.mib.jaxb.standard.UATPDetails;
import com.sgl.smartpra.mib.jaxb.standard.WaypointCode;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Component
@Slf4j
public class SupportingDetailValidator { 
	
	@Autowired
    private FeignConfiguration.SmartpraGlobalMasterAppClient smartpraGlobalMasterAppClient;
	
	@Autowired
    private CommonValidator commonValidator;
	
	//@HystrixCommand(fallbackMethod = "validateSupportingDetailsFallBack")
	public void validateSupportingDetails(Multimap<String,ExceptionTransactionModel> mErrorCode, 
			Integer lineItemNumber, Integer lineItemDetailNumber, List<MiscBillingSupportingDetailEntity> supportingDtlList) {

		List<SectionDto> sectionDtoList = smartpraGlobalMasterAppClient.fetchSectionByChargeCode(commonValidator.getChargeCode(), commonValidator.getBillingPeriodEndDate());
		for (MiscBillingSupportingDetailEntity supDtl : supportingDtlList) {
			String sectionName = supDtl.getSectionName(); // FlightDetails
			// {"flightNo":"419","flightDateTime":"2013-04-02"}
			String jsonValue = supDtl.getJsonValue();
			try {
				// FlightDetails - {"flightNo":"AB323","flightDateTime":"2018-07-29T04:11:18","flightZone":"Domestic","passengerCount":[{"value":100,"type":"Domestic"}]}
				// RouteDetails -  [{"locationCode":{"value":"YUL","type":"Origin"},"routeDateTime":{"value":"2018-07-29T08:38:00","type":"Entry"}}]
				// AircraftDetails-{"aircraftRegistrationNo":"CFAAA","maxTakeOffWeight":{"value":69,"uomCode":"TNE"},"aircraftTypeCodeICAO":"A319"}
				List<SectionDto> secList = sectionDtoList.stream()
						.filter(fd -> sectionName.equalsIgnoreCase(fd.getSectionNameActual()))
						.collect(Collectors.toList());
				if(MiscBillingConstants.FLIGHT_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateFlightDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode); 
				} else if(MiscBillingConstants.AIRCRAFT_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateAircraftDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);	
				} else if(MiscBillingConstants.ROUTE_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateRouteDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if(MiscBillingConstants.SETTLEMENT_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateSettlementDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if(MiscBillingConstants.PASSENGER_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validatePassengerDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if(MiscBillingConstants.CATERING_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateCateringDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if(MiscBillingConstants.EMPLOYEE_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateEmployeeDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if(MiscBillingConstants.MISC_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateMiscDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if (MiscBillingConstants.MAIL_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateMailDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if (MiscBillingConstants.PARKING_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateParkingDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if (MiscBillingConstants.AREA_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateAreaDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if (MiscBillingConstants.CONSUMPTION_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateConsumptionDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if (MiscBillingConstants.ACCOMODATION_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateAccommodationDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if (MiscBillingConstants.CAR_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateCarDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				} else if (MiscBillingConstants.UATP_DETAILS.equalsIgnoreCase(sectionName)) {
					this.validateUATPDetails(sectionName, jsonValue, lineItemNumber, lineItemDetailNumber, secList, mErrorCode);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void validateSupportingDetailsFallBack(Multimap<String,ExceptionTransactionModel> mErrorCode, 
			Integer lineItemNumber, Integer lineItemDetailNumber, List<MiscBillingSupportingDetailEntity> supportingDtlList) {
		log.debug("CIRCUIT BREAKER ENABLED!!! No response from smartpraGlobalMasterAppClient.fetchSectionByChargeCode(chargeCode, currentBillingPeriod) service at this moment. " +
                " Service will be back shortly - " + new Date());
	}
	
	// {"flightNo":"AB323","flightDateTime":"2018-07-29T04:11:18","flightZone":"Domestic","passengerCount":[{"value":100,"type":"Domestic"}]}
	public void validateFlightDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			FlightDetails fd = mapper.readValue(jsonValue, FlightDetails.class);
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				boolean isEmpty = false;
				if(fd == null) { 
					isEmpty = true;
				} else if("FlightNo".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(fd.getFlightNo())) isEmpty = true;
				} else if("FlightDateTime".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(fd.getFlightDateTime())) isEmpty = true;
				} else if("FlightDirection".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(fd.getFlightDirection())) isEmpty = true;
				} else if("PassengerCount".equalsIgnoreCase(sectionElementNameActual)) {
					isEmpty = fd.getPassengerCount().stream()
											  .anyMatch(x -> StringUtils.isBlank(x.getType()) || x.getValue() == null);
				}
				if(isEmpty) {
					commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating FlightDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
	
	public void validateMailDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			MailDetails md = mapper.readValue(jsonValue, MailDetails.class);
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				boolean isEmpty = false;
				if(md == null) { 
					isEmpty = true;
				} else if("BagNo".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(md.getBagNo())) isEmpty = true;
				} else if("MailCategory".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(md.getMailCategory())) isEmpty = true;
				} else if("MailClass".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(md.getMailClass())) isEmpty = true;
				} else if("MailNo".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(md.getMailNo())) isEmpty = true;
				}
				if(isEmpty) {
					commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating MailDetails: " + jsonValue);
			log.error(e.getMessage());
		}
	}
	
	public void validateParkingDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			ParkingDetails pd = mapper.readValue(jsonValue, ParkingDetails.class);
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				boolean isEmpty = false;
				if(pd == null || ("OffStandDateTime".equalsIgnoreCase(sectionElementNameActual) && StringUtils.isBlank(pd.getOffStandDateTime())) 
						|| ("OnStandDateTime".equalsIgnoreCase(sectionElementNameActual) && StringUtils.isBlank(pd.getOnStandDateTime()))) { 
					isEmpty = true;
				}
				
				if(isEmpty) {
					commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating ParkingDetails: " + jsonValue);
			log.error(e.getMessage());
		}
	}
	
	public void validateAreaDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		AreaDetails.Address address = null;
		try {
			AreaDetails ad = mapper.readValue(jsonValue, AreaDetails.class);
			address = ad != null ? ad.getAddress() : null;
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				boolean isEmpty = false;
				if(ad == null || address == null) { 
					isEmpty = true;
				} else if("CityName".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(address.getCityName())) isEmpty = true;
				} else if("CountryCode".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(address.getCountryCode())) isEmpty = true;
				} else if("CountryCode_ICAO".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(address.getCountryCodeICAO())) isEmpty = true;
				} else if("PostalCode".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(address.getPostalCode())) isEmpty = true;
				} else if("SubdivisionCode".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(address.getSubdivisionCode())) isEmpty = true;
				} else if("SubdivisionName".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(address.getSubdivisionName())) isEmpty = true;	
				} else if("AddressLine1".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(address.getAddressLine1())) isEmpty = true;
				} else if("AddressLine2".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(address.getAddressLine2())) isEmpty = true;
				} else if("AddressLine3".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(address.getAddressLine3())) isEmpty = true;
				}
				if(isEmpty) {
					commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating AreaDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
	
	public void validateConsumptionDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			ConsumptionDetails cd = mapper.readValue(jsonValue, ConsumptionDetails.class);
			Temperature temperature = cd != null ? cd.getTemperature() : null;
		    Density density = cd != null ? cd.getDensity() : null;
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				boolean isEmpty = false;
				if(cd == null) { 
					isEmpty = true;
				} else if("Density".equalsIgnoreCase(sectionElementNameActual)) {
					if(density == null || StringUtils.isBlank(density.getType()) || density.getValue() == null 
							|| density.getUOM() == null ) {
						isEmpty = true;
					}
				} else if("EndDateTime".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(cd.getEndDateTime())) isEmpty = true;
				} else if("StartDateTime".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(cd.getStartDateTime())) isEmpty = true;
				} else if("Temperature".equalsIgnoreCase(sectionElementNameActual)) {
					if(temperature == null || StringUtils.isBlank(temperature.getType()) || temperature.getValue() == null 
						|| temperature.getUOM() == null) {
						isEmpty = true;
					}
				}
				if(isEmpty) {
					commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating ConsumptionDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
	
	public void validateAccommodationDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			AccommodationDetails ad = mapper.readValue(jsonValue, AccommodationDetails.class);
			AccommodationDetails.RoomCategory roomCategory = ad != null ? ad.getRoomCategory() : null;
			AccommodationDetails.RoomType roomType = ad != null ? ad.getRoomType() : null;
			AccommodationDetails.BedType bedType = ad != null ? ad.getBedType() : null;
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				boolean isEmpty = false;
				if(ad == null) { 
					isEmpty = true;
				} else if("BedType".equalsIgnoreCase(sectionElementNameActual)) {
					if(bedType == null || StringUtils.isBlank(bedType.getName()) || StringUtils.isBlank(bedType.getValue())) {
						isEmpty = true;
					}
				} else if("EmployeeType".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getEmployeeType())) isEmpty = true;
				} else if("GuestNo".equalsIgnoreCase(sectionElementNameActual)) {
					if(ad.getGuestNo() == null) isEmpty = true;
				} else if("RoomCategory".equalsIgnoreCase(sectionElementNameActual)) {
					if(roomCategory == null || StringUtils.isBlank(roomCategory.getName()) || StringUtils.isBlank(roomCategory.getValue())) {
						isEmpty = true;
					}
				} else if("NumberOfBed".equalsIgnoreCase(sectionElementNameActual)) {
					if(ad.getNumberOfBed() == null) isEmpty = true;
				} else if("RoomType".equalsIgnoreCase(sectionElementNameActual)) {
					if(roomType == null || StringUtils.isBlank(roomType.getName()) || StringUtils.isBlank(roomType.getValue())) {
						isEmpty = true;
					}
				} else if("TypeOfStay".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getTypeOfStay())) isEmpty = true;
				} else if("VoucherCode".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getVoucherCode())) isEmpty = true;	
				}
				if(isEmpty) {
					commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating AccommodationDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
	
	public void validateCarDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			CarDetails cd = mapper.readValue(jsonValue, CarDetails.class);
			CarDetails.CarCategory carCategory = cd != null ? cd.getCarCategory() : null;
			CarDetails.CarTransmission carT = cd != null ? cd.getCarTransmission() : null;
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				boolean isEmpty = false;
				if("CarCategory".equalsIgnoreCase(sectionElementNameActual)) {
					if(carCategory == null || StringUtils.isBlank(carCategory.getName()) || StringUtils.isBlank(carCategory.getValue())) {
						isEmpty = true;
					}
				} else if("CarTransmission".equalsIgnoreCase(sectionElementNameActual)) {
					if(carT == null || StringUtils.isBlank(carT.getName()) || StringUtils.isBlank(carT.getValue())) {
						isEmpty = true;
					}
				}
				if(isEmpty) {
					commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating AccommodationDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
	
	public void validateUATPDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			UATPDetails ud = mapper.readValue(jsonValue, UATPDetails.class);
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				boolean isEmpty = false;
				if(ud == null) { 
					isEmpty = true;
				} else if("DailyExchangeRate".equalsIgnoreCase(sectionElementNameActual)) {
					if(ud.getDailyExchangeRate() == null) isEmpty = true;
				} else if("OriginalInvoiceDate".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ud.getOriginalInvoiceDate())) isEmpty = true;
				} else if("OriginalInvoiceNumber".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ud.getOriginalInvoiceNumber())) isEmpty = true;
				} else if("RejectedCommissions".equalsIgnoreCase(sectionElementNameActual)) {
					if(ud.getRejectedCommissions() == null) isEmpty = true;
				} else if("RejectedInvoiceDate".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ud.getRejectedInvoiceDate())) isEmpty = true;
				} else if("RejectedInvoiceNo".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ud.getRejectedInvoiceNo())) isEmpty = true;
				} else if("RejectionReasonCode".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ud.getRejectionReasonCode())) isEmpty = true;
				} else if("SignedForAmount".equalsIgnoreCase(sectionElementNameActual)) {
					if(ud.getSignedForAmount() == null) isEmpty = true;
				} else if("SignedForCurrencyCode".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ud.getSignedForCurrencyCode())) isEmpty = true;
				}
				if(isEmpty) {
					commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating validateUATPDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
	
	// {"aircraftRegistrationNo":"CFAAA","maxTakeOffWeight":{"value":69,"uomCode":"TNE"},"aircraftTypeCodeICAO":"A319"}
	public void validateAircraftDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			AircraftDetails ad = mapper.readValue(jsonValue, AircraftDetails.class);
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				boolean isEmpty = false;
				if(ad == null) { 
					isEmpty = true;
				} else if("AircraftRegistrationNo".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getAircraftRegistrationNo())) isEmpty = true;
				} else if("AircraftTypeCode".equalsIgnoreCase(sectionElementNameActual) || "AircraftTypeCode_ICAO".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getAircraftTypeCode()) && StringUtils.isBlank(ad.getAircraftTypeCodeICAO())) isEmpty = true;
				} else if("CabinClass".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getCabinClass())) isEmpty = true;
				} else if("EngineNo".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getEngineNo())) isEmpty = true;
				} else if("EngineType".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getEngineType())) isEmpty = true;
				} else if("MaxTakeOffWeight".equalsIgnoreCase(sectionElementNameActual)) {
					MaxTakeOffWeight mtw = ad.getMaxTakeOffWeight(); 
					if(mtw == null || StringUtils.isBlank(mtw.getUOMCode()) || mtw.getValue() == null) isEmpty = true;
				} else if("NoiseClass".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getNoiseClass())) isEmpty = true;
				} else if("PartNo".equalsIgnoreCase(sectionElementNameActual)) {
					if(StringUtils.isBlank(ad.getPartNo())) isEmpty = true;
				}
				if(isEmpty) {
					commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
						mErrorCode, lineItemNumber, lineItemDetailNumber);
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating AircraftDetails: " + jsonValue);
		}
	}
	
	// [{"locationCode":{"value":"YUL","type":"Origin"},"routeDateTime":{"value":"2018-07-29T08:38:00","type":"Entry"}}]
	public void validateRouteDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			List<RouteDetails> rdtlList = Arrays.asList(mapper.readValue(jsonValue, RouteDetails[].class));
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				for (RouteDetails routeDetails : rdtlList) {
					boolean isEmpty = false;
					if("CountryCode".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(routeDetails.getCountryCode())) isEmpty = true;
					} else if("LocationCode".equalsIgnoreCase(sectionElementNameActual) || "LocationCode_ICAO".equalsIgnoreCase(sectionElementNameActual)) {
						RouteDetails.LocationCode lc = routeDetails.getLocationCode(); 
						RouteDetails.LocationCodeICAO lcIcao = routeDetails.getLocationCodeICAO();
						if((lc == null || StringUtils.isBlank(lc.getValue())) && 
								(lcIcao == null || StringUtils.isBlank(lcIcao.getValue()))) 
							isEmpty = true;
					} else if("RouteDateTime".equalsIgnoreCase(sectionElementNameActual)) {
						RouteDateTime rdt = routeDetails.getRouteDateTime(); 
						if(rdt == null || StringUtils.isBlank(rdt.getType()) || StringUtils.isBlank(rdt.getValue())) isEmpty = true;
					} else if("WaypointCode".equalsIgnoreCase(sectionElementNameActual)) {
						WaypointCode wpc = routeDetails.getWaypointCode(); 
						if(wpc == null || StringUtils.isBlank(wpc.getType()) || StringUtils.isBlank(wpc.getValue())) isEmpty = true;
					}
					if(isEmpty) {
						commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating RouteDetails: " + jsonValue);
		}
	}	
	
	public void validateSettlementDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			List<SettlementDetails> settleList = Arrays.asList(mapper.readValue(jsonValue, SettlementDetails[].class));
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				for (SettlementDetails sdtl : settleList) {
					boolean isEmpty = false;
					if("Amount".equalsIgnoreCase(sectionElementNameActual)) {
						SettlementDetails.Amount sa= sdtl.getAmount();
						if(sa == null || StringUtils.isBlank(sa.getName()) || sa.getValue() == null) isEmpty = true;
					} else if("DailyRate".equalsIgnoreCase(sectionElementNameActual)) {
						if(sdtl.getDailyRate() == null) isEmpty = true;
					} else if("ExchangeRate".equalsIgnoreCase(sectionElementNameActual)) {
						if(sdtl.getExchangeRate() == null) isEmpty = true;
					} else if("InvoiceRefNumber".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(sdtl.getInvoiceRefNumber())) isEmpty = true;
					}
					if(isEmpty) {
						commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating SettlementDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
	
	public void validatePassengerDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			List<PassengerDetails> psgList = Arrays.asList(mapper.readValue(jsonValue, PassengerDetails[].class));
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				for (PassengerDetails psg : psgList) {
					boolean isEmpty = false;
					if("PassengerName".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(psg.getPassengerName())) isEmpty = true;
					} else if("TicketNo".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(psg.getTicketNo())) isEmpty = true;
					}
					if(isEmpty) {
						commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating PassengerDetails: " + jsonValue);
			e.printStackTrace();
		}
	}	

	public void validateCateringDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			List<CateringDetails> catList = Arrays.asList(mapper.readValue(jsonValue, CateringDetails[].class));
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				for (CateringDetails cat : catList) {
					boolean isEmpty = false;
					if("BoardFlightDate".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(cat.getBoardFlightDate())) isEmpty = true;
					} else if("BoardFlightNbr".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(cat.getBoardFlightNbr())) isEmpty = true;
					} else if("Facility".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(cat.getFacility())) isEmpty = true;
					} else if("InvoiceDbsDate".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(cat.getInvoiceDbsDate())) isEmpty = true;
					} else if("InvoiceOpCode".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(cat.getInvoiceOpCode())) isEmpty = true;
					} else if("MealCode".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(cat.getMealCode())) isEmpty = true;
					} else if("MealType".equalsIgnoreCase(sectionElementNameActual)) {
						MealType mealType = cat.getMealType();
						if(mealType == null || StringUtils.isBlank(mealType.getName()) || StringUtils.isBlank(mealType.getValue())) isEmpty = true;
					} else if("ServiceFlightDate".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(cat.getServiceFlightDate())) isEmpty = true;
					} else if("ServiceFlightNbr".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(cat.getServiceFlightNbr())) isEmpty = true;
					}
					if(isEmpty) {
						commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating CateringDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
		
	public void validateEmployeeDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
				List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			List<EmployeeDetails> edList = Arrays.asList(mapper.readValue(jsonValue, EmployeeDetails[].class));
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				for (EmployeeDetails ed : edList) {
					boolean isEmpty = false;
					if("IssueDescription".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(ed.getIssueDescription())) isEmpty = true;
					} else if("PassExpiryDate".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(ed.getPassExpiryDate())) isEmpty = true;
					} else if("PassIssueDate".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(ed.getPassIssueDate())) isEmpty = true;
					} else if("PassNo".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(ed.getPassNo())) isEmpty = true;
					} else if("StaffID".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(ed.getStaffID())) isEmpty = true;
					} else if("StaffName".equalsIgnoreCase(sectionElementNameActual)) {
						if(StringUtils.isBlank(ed.getStaffName())) isEmpty = true;
					}
					if(isEmpty) {
						commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating EmployeeDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
	
	public void validateMiscDetails(String sectionName, String jsonValue, Integer lineItemNumber, Integer lineItemDetailNumber, 
			List<SectionDto> sectionDtoList, Multimap<String,ExceptionTransactionModel> mErrorCode) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			MiscDetails miscDetails = mapper.readValue(jsonValue, MiscDetails.class);
			List<MiscData> miscDataList = miscDetails.getMiscData();
			for (SectionDto fdtl : sectionDtoList) {
				String sectionElementNameActual = fdtl.getSectionElementNameActual();
				for (MiscData misc : miscDataList) {
					boolean isEmpty = false;
					if(StringUtils.isBlank(misc.getName()) || StringUtils.isBlank(misc.getValue()) || StringUtils.isBlank(misc.getUOMCode())) isEmpty = true;
					if(isEmpty) {
						commonValidator.requiredValidationForSupportingDetail(String.join(":", sectionName, sectionElementNameActual), 
							mErrorCode, lineItemNumber, lineItemDetailNumber);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception thrown while validating MiscDetails: " + jsonValue);
			e.printStackTrace();
		}
	}
}
