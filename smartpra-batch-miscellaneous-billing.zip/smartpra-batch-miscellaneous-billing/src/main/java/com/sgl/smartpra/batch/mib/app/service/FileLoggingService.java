/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class FileLoggingService {

	@Value("${batch.directory.misc-billing.output}")
	private String miscBillingBatchOutputDir;

	@Autowired
	private BatchGlobalFeignClient batchGlobalFeignClient;
	
	@HystrixCommand(fallbackMethod = "createFileLoggingFallBack")
	public FileLogging createFileLogging(String clientId, String hostCarrDesigCode, String carrierNumericCode, String jobName, 
			String fileName, String processedBy) {
		FileLogging fileLogging = MiscBillingUtil.initFileLogging();
		fileLogging.setClientId(hostCarrDesigCode);
		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_OUTPUT);
		fileLogging.setFileName(fileName);
		fileLogging.setProcessedBy(processedBy);
		fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_MISC_BILLING_OUT);
		fileLogging.setJobName(jobName);
		fileLogging.setFileSize(SmartpraFileUtility.getFileSize(miscBillingBatchOutputDir + fileName));
		fileLogging.setModuleId(MiscBillingConstants.MODULE_ID);
		return batchGlobalFeignClient.createFileLog(fileLogging);
	}
	
	public FileLogging createFileLoggingFallBack(String clientId, String hostCarrDesigCode, String carrierNumericCode, String jobName, 
			String fileName, String processedBy) {
		log.debug("CIRCUIT BREAKER ENABLED!!! No response from batchGlobalFeignClient.createFileLog(fileLogging) service at this moment. " +
                " Service will be back shortly - clientId: " + clientId + ", fileName: " + fileName);
		return null;
	}
}
