package com.sgl.smartpra.batch.mib.app.config.sftp;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.file.filters.AcceptOnceFileListFilter;
import org.springframework.integration.file.remote.session.CachingSessionFactory;
import org.springframework.integration.file.remote.session.SessionFactory;
import org.springframework.integration.sftp.filters.SftpSimplePatternFileListFilter;
import org.springframework.integration.sftp.inbound.SftpInboundFileSynchronizer;
import org.springframework.integration.sftp.inbound.SftpInboundFileSynchronizingMessageSource;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.MessagingException;

import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.sgl.smartpra.batch.mib.app.service.MiscBillingService;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class MiscBillingSftpConfig {

	@Value("${sftp.host}")
	private String sftpHost;

	@Value("${sftp.port}")
	private int sftpPort;

	@Value("${sftp.user}")
	private String sftpUser;

	@Value("${sftp.privateKey:#{null}}")
	private Resource sftpPrivateKey;

	@Value("${sftp.privateKeyPassphrase:}")
	private String sftpPrivateKeyPassphrase;

	@Value("${sftp.password}")
	private String sftpPassword;

	@Value("${sftp.remote.directory.download.misc-billing-in}")
	private String sftpRemoteDirectoryDownload;

	@Value("${batch.directory.misc-billing.input}")
	private String sftpLocalDirectoryDownload;

	@Value("${sftp.remote.directory.download.filter:*.*}")
	private String sftpRemoteDirectoryDownloadFilter;
	
	@Autowired
	private MiscBillingService miscBillingService;
	
	@Bean
	public SessionFactory<LsEntry> sftppSessionFactory() {
		DefaultSftpSessionFactory factory = new DefaultSftpSessionFactory(false);
		factory.setHost(sftpHost);
		factory.setPort(sftpPort);
		factory.setUser(sftpUser);
		Properties properties = new Properties();
		properties.put("PreferredAuthentications", "password");
		properties.put("StrictHostKeyChecking", "no");
		factory.setSessionConfig(properties);
		if (sftpPrivateKey != null) {
			factory.setPrivateKey(sftpPrivateKey);
			factory.setPrivateKeyPassphrase(sftpPrivateKeyPassphrase);
		} else {
			factory.setPassword(sftpPassword);
		}
		factory.setAllowUnknownKeys(true);
		return new CachingSessionFactory<LsEntry>(factory);
	}

	@Bean
	public SftpInboundFileSynchronizer miscBillingSftpInboundFileSynchronizer() {
		SftpInboundFileSynchronizer fileSynchronizer = new SftpInboundFileSynchronizer(sftppSessionFactory());
		fileSynchronizer.setRemoteDirectory(sftpRemoteDirectoryDownload);
		fileSynchronizer.setFilter(new SftpSimplePatternFileListFilter(sftpRemoteDirectoryDownloadFilter));
		return fileSynchronizer;
	}

	@Bean
	public MessageChannel miscBillingInSftpChannel() {
		return new DirectChannel();
	}

	@Bean
	//@InboundChannelAdapter(channel = "miscBillingInSftpChannel",  poller = @Poller(cron = "0/5 * * * * *")) //0/5 * * * * * autoStartup = "false",
	@InboundChannelAdapter(channel = "miscBillingInSftpChannel",  autoStartup = "false" , poller = @Poller(fixedDelay="1000000000000")) //0/5 * * * * * autoStartup = "false",
	public MessageSource<File> sftpMessageSourceMiscBillingIn() {
		SftpInboundFileSynchronizingMessageSource source = new SftpInboundFileSynchronizingMessageSource(
				miscBillingSftpInboundFileSynchronizer());
		source.setLocalDirectory(new File(sftpLocalDirectoryDownload));

		source.setAutoCreateLocalDirectory(true);
		source.setLocalFilter(new AcceptOnceFileListFilter<File>());
		return source;
	}

	@Bean
	@ServiceActivator(inputChannel = "miscBillingInSftpChannel")
	public MessageHandler miscBillingInFileHandler() {
		return new MessageHandler() {
			@Override
			public void handleMessage(Message<?> message) throws MessagingException {
				List<String> allFiles = allFilesToProcess(sftpLocalDirectoryDownload, sftpLocalDirectoryDownload);
				
				for (String file : allFiles) {
					try {
						miscBillingService.executeInboundJob(file, FileLoggingConstants.FILELOGGING_PROCESSEDBY_SCHEDULER, "6E");
					} catch (Exception exc) {
						log.error(exc.getMessage());
					}
				}
				
	
				MessageHeaders messageHeaders = message.getHeaders();
				String filename = (String) messageHeaders.get("file_name");
				log.info("filename : " + filename);
			}
		};
	}

	public List<String> allFilesToProcess(String sourceDir, String destinationDir) {
		List<String> unzipedFiles = SmartpraFileUtility.unzipFiles(sourceDir, destinationDir);
		File dir = new File(sourceDir);
		String[] listOfFiles = dir.list(new FilenameFilter() {
			@Override
			public boolean accept(File sourceDir, String name) {
				return name.toLowerCase().endsWith(".xml");
			}
		});
		List<String> allFiles = Arrays.asList(listOfFiles);
		allFiles.addAll(unzipedFiles);
		log.info(" allFiles " + allFiles);
		return allFiles;
	}


	
}
