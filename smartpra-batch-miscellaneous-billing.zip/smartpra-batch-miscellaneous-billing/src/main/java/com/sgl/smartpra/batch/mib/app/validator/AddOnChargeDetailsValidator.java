package com.sgl.smartpra.batch.mib.app.validator;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;

@Component
public class AddOnChargeDetailsValidator {
    
	@Autowired
    private CommonValidator commonValidator;
	
	public void validateAddOnDetails(List<MiscBillingAddOnChargeDtlEntity> addOnChargeList,
					Multimap<String,ExceptionTransactionModel> mErrorCode) {

		for (MiscBillingAddOnChargeDtlEntity addOnChargeEntity : addOnChargeList) {
            if(!commonValidator.validateTaxAmount(addOnChargeEntity.getAddOnChargeAmount(),
            		addOnChargeEntity.getAddOnChargePercentage(), addOnChargeEntity.getAddOnChargeableAmount())){
            	Map<String,String> map = new HashedMap<>();
            	map.put("Tax / VAT/ Addon Charge", String.valueOf(addOnChargeEntity.getAddOnChargeName()));
                map.put("Invoice No.", commonValidator.getInvoiceNo());
                map.put("Amount", String.valueOf(addOnChargeEntity.getAddOnChargeAmount()));
                map.put("Percentage", String.valueOf(addOnChargeEntity.getAddOnChargePercentage()));
                map.put("Applicable Amount", String.valueOf(addOnChargeEntity.getAddOnChargeableAmount()));
                commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1115);
            }
        }
    }
}
