package com.sgl.smartpra.batch.mib.app.validator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;

@Component
public class TaxDetailsValidator {

	@Autowired
    private CommonValidator commonValidator;
	
	public void validateTaxDetails(List<MiscBillingTaxDetailsEntity> taxList,
			Multimap<String, ExceptionTransactionModel> mErrorCode, String level) {

		MiscBillingInvLineitemEntity lineItemEntity = null;
		MiscBillingInvLineitemDtlEntity lineItemDtlEntity = null;
		
		for (MiscBillingTaxDetailsEntity taxDetailsEntity : taxList) {
			if(MiscBillingConstants.LINE_ITEM.equals(level)) {
				lineItemEntity = taxDetailsEntity.getMiscBillingInvLineitem();
			} 
			if(MiscBillingConstants.LINE_ITEM_DETAIL.equals(level)) {
				lineItemDtlEntity = taxDetailsEntity.getMiscBillingInvLineitemDtl();
			}
			Map<String, String> map;
			if (!validateTaxType(taxDetailsEntity.getTaxType())) {
				map = new HashedMap<>();
				map.put("Invoice No.", commonValidator.getInvoiceNo());
				if(lineItemEntity != null) 	  map.put("Line item No.", String.valueOf(lineItemEntity.getLineItemNumber()));
				if(lineItemDtlEntity != null) map.put("Line item Details No.", String.valueOf(lineItemDtlEntity.getLineItemDetailNumber()));
				commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1114);
			}
			if (!commonValidator.validateTaxAmount(taxDetailsEntity.getTaxAmount(),taxDetailsEntity.getTaxPercentage(), 
					taxDetailsEntity.getTaxableAmount())) {
				map = new HashedMap<>();
				map.put("Tax / VAT/ Addon Charge", String.valueOf(taxDetailsEntity.getTaxType()));
				map.put("Invoice No.", commonValidator.getInvoiceNo());
				map.put("Amount", String.valueOf(taxDetailsEntity.getTaxAmount()));
				map.put("Percentage", String.valueOf(taxDetailsEntity.getTaxPercentage()));
				map.put("Applicable Amount", String.valueOf(taxDetailsEntity.getTaxableAmount()));
				commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1115);
			}
		};
	}
	
    public Boolean validateTaxType(String taxType){
    	Boolean isValid = Boolean.FALSE;
    	Map<String, List<String>> dictionaryMap = commonValidator.getDictionaryMap();
    	if(StringUtils.isNotBlank(taxType)) {
        	isValid =  dictionaryMap.get(MiscBillingConstants.TAX_TYPE)
        						.stream()
        						.anyMatch(x -> (StringUtils.equalsIgnoreCase(x , "TAX") || StringUtils.equalsIgnoreCase(x, "VAT")));
        }
		return isValid;
    }
}
