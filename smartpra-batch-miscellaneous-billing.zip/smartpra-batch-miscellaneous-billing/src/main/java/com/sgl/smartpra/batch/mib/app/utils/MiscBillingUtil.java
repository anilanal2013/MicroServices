package com.sgl.smartpra.batch.mib.app.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.SystemParameter;

@Component
public class MiscBillingUtil {

	@Autowired
	private CommonValidator commonValidator;
	
	private MiscBillingUtil() {}
	private static List<String> months = Arrays.asList("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12");
	private static List<String> billingPeriods = Arrays.asList("00", "01", "02", "03", "04");

	/**
	 * This method will get the host carrier designator code.
	 * 
	 * @param smartpraMasterAppClient SmartPraMasterAppClient
	 * @return
	 */
	public static String getHostCarrierDesigCode(SmartpraMasterAppClient smartpraMasterAppClient) {
		String hostCarrierDesigCode = null;
		List<SystemParameter> systemParameterList =  smartpraMasterAppClient
				.getSystemParameterByparameterName(MiscBillingConstants.PARAM_DEFAULT_CARRIER_ALPHA_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierDesigCode = OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());
		}
		return hostCarrierDesigCode;
	}
	
	public static String getHostCarrierDesigCode(SmartpraMasterAppClient smartpraMasterAppClient, String clientId) {
		String hostCarrierDesigCode = null;
		SystemParameter systemParameter =  smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(MiscBillingConstants.PARAM_DEFAULT_CARRIER_ALPHA_CODE, clientId);
		if (systemParameter != null) {
			hostCarrierDesigCode = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
		}
		return hostCarrierDesigCode;
	}

	public static String getHostCarrierCode(SmartpraMasterAppClient smartpraMasterAppClient, String clientId) {
		String hostCarrierCode = null;
		SystemParameter systemParameter =  smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(MiscBillingConstants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE, clientId);
		if (systemParameter != null) {
			hostCarrierCode = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
		}

		return hostCarrierCode;
	}
	
	public static String getBaseCurrency(SmartpraMasterAppClient smartpraMasterAppClient, String clientId) {
		String baseCurrency = null;
		SystemParameter systemParameter =  smartpraMasterAppClient
				.getSystemParameterByparameterNameAndClientId(MiscBillingConstants.PARAM_DEFAULT_CURRENCY_CODE, clientId);
		if (systemParameter != null) {
			baseCurrency = OptionalUtil.getValue(systemParameter.getParameterRangeFrom());
		}

		return baseCurrency;
	}
	
	/**
	 * This method will initialize the filelogging object with basic data.
	 * 
	 * @return
	 */
	public static FileLogging initFileLogging() {
		FileLogging fileLogging = new FileLogging();
		fileLogging.setFileCategory(FileLoggingConstants.FILELOGGING_FILECATEGORY_XML);
		fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setModuleName(MiscBillingConstants.FILELOGGING_MODULE);
		fileLogging.setSource(MiscBillingConstants.FILELOGGING_SOURCE);
		fileLogging.setCreatedBy(MiscBillingConstants.CREATEDBY);
		fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));

		// may not be mandatory
		fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_STARTED);
		fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setTotalCounts(0);
		fileLogging.setTransferredCounts(0);
		fileLogging.setIsEncryptedPostSuccess("N");
		fileLogging.setIsEncryptedPriorLoading("N");
		fileLogging.setIsRenamedPostSuccess("N");
		fileLogging.setIsMovedToRelevantFolder("N");
		fileLogging.setIsNotificationSent("N");
		fileLogging.setModuleId(MiscBillingConstants.MODULE_ID);
		return fileLogging;
	}

	public static String getMonth(String month) {

		String result;
		switch (month) {
	        case "01":
	        	result = "JAN"; 
	            break;
	        case "02":
	        	result = "FEB";
	            break;
	        case "03":
	        	result = "MAR";
	            break;
	        case "04":
	            result = "APR";
	            break;
	        case "05":
	            result = "MAY";
	            break;    
	        case "06":
	            result = "JUN";
	            break;
	        case "07":
	            result = "JUL";
	            break;    
	        case "08":
	            result = "AUG";
	            break;
	        case "09":
	            result = "SEP";
	            break;
	        case "10":
	            result = "OCT";
	            break;
	        case "11":
	            result = "NOV";
	            break;
	        case "12":
	            result = "DEC";
	            break;
	        default:
	            result = "";
	            break;    
		}
		return result;
	}
	
	public static String getMonthInDigit(String month) {

		String result;
		switch (month) {
	        case "JAN":
	        	result = "01"; 
	            break;
	        case "FEB":
	        	result = "02";
	            break;
	        case "MAR":
	        	result = "03";
	            break;
	        case "APR":
	            result = "04";
	            break;
	        case "MAY":
	            result = "05";
	            break;    
	        case "JUN":
	            result = "06";
	            break;
	        case "JUL":
	            result = "07";
	            break;    
	        case "AUG":
	            result = "08";
	            break;
	        case "SEP":
	            result = "09";
	            break;
	        case "OCT":
	            result = "10";
	            break;
	        case "NOV":
	            result = "11";
	            break;
	        case "DEC":
	            result = "12";
	            break;
	        default:
	            result = "";
	            break;    
		}
		return result;
	}

	/**
	 * This method will verify the "host designator code" and file type
	 *
	 * @param fileName
	 * @return
	 */
	public static Map<String, String> isValidFile(String hostCarrNumericCode, String fileName) {

		Map<String, String> fileStatus = new HashMap<>();

		if (StringUtils.isNotEmpty(fileName) && fileName.length() == 21) {
			String year = fileName.substring(9, 13);
			String month = fileName.substring(13, 15);
			String billingPeriod = fileName.substring(15, 17);

			if (fileName.startsWith(MiscBillingConstants.MISC_BILLING_FILENAME_CONSTANT)) {
				fileStatus.put(MiscBillingConstants.STATUS, Boolean.TRUE.toString());
			} else {
				String elementVal = "File Constant : " + fileName.substring(0, 6);
				return updateStatusMap(fileStatus, elementVal, "1", "6");
			}
			if (StringUtils.isNotEmpty(hostCarrNumericCode) && hostCarrNumericCode.equals(fileName.substring(6, 9))) {
				fileStatus.put(MiscBillingConstants.STATUS, Boolean.TRUE.toString());
			} else {
				String elementVal = "CarrierCode : " + fileName.substring(6, 9);
				return updateStatusMap(fileStatus, elementVal, "7", "9");
			}

			if (Integer.valueOf(year) <= Calendar.getInstance().get(Calendar.YEAR) && months.contains(month)) {
				fileStatus.put(MiscBillingConstants.STATUS, Boolean.TRUE.toString());
			} else {
				String elementVal = "Billing Month : " + year + month;
				return updateStatusMap(fileStatus, elementVal, "10", "15");

			}

			if (billingPeriods.contains(billingPeriod)) {
				fileStatus.put(MiscBillingConstants.STATUS, Boolean.TRUE.toString());
			} else {
				String elementVal = "Billing period : " + billingPeriod;
				return updateStatusMap(fileStatus, elementVal, "16", "17");
			}
			if (fileName.toUpperCase().endsWith(FileLoggingConstants.FILELOGGING_FILECATEGORY_XML)) {
				fileStatus.put(MiscBillingConstants.STATUS, Boolean.TRUE.toString());
			} else {
				return updateStatusMap(fileStatus, "File Extension", "18", "21");
			}
		} else {
			String elementVal = "File length : " + (StringUtils.isNotEmpty(fileName) ? fileName.length() : 0);
			return updateStatusMap(fileStatus, elementVal, "1", "21");
		}
		return fileStatus;
	}

	private static Map<String, String> updateStatusMap(Map<String, String> fileStatus, String elementVal,
			String startPos, String endPos) {
		
		fileStatus.put(MiscBillingConstants.ELEMENT_NAME, elementVal);
		fileStatus.put(MiscBillingConstants.START_POSITION, startPos);
		fileStatus.put(MiscBillingConstants.END_POSITION, endPos);
		fileStatus.put(MiscBillingConstants.STATUS, Boolean.FALSE.toString());
		return fileStatus;
	}

	public ExceptionTransactionModel prepareExceptionTransactionModel(String exceptionCode, Map<String,String> paremNameValueMap, String clientId, Integer fileId) {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setExceptionCode(exceptionCode);
		exceptionTransactionModel.setCreatedBy(MiscBillingConstants.CREATEDBY);
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setClientId(clientId);
		exceptionTransactionModel.setEnvironment("P"); //production data.
		if(fileId != null) {
			exceptionTransactionModel.setFileId(Long.valueOf(fileId));
		}
		if(commonValidator.getCarrier() != null) {
			Optional<String> carrierNumCode = commonValidator.getCarrier().getCarrierCode();
			if(carrierNumCode.isPresent()) {
				exceptionTransactionModel.setBatchKey1(carrierNumCode.get());
			}	
		}
		if(commonValidator.getHostCarrier() != null) {
			Optional<String> hostCarrierNumCode = commonValidator.getHostCarrier().getCarrierCode();
			if(hostCarrierNumCode.isPresent()) {
				exceptionTransactionModel.setBatchKey2(hostCarrierNumCode.get());
			}
		}
		exceptionTransactionModel.setBatchKey3(commonValidator.getChargeCategory());
		exceptionTransactionModel.setBatchKey4(commonValidator.getInvoiceNo());
		exceptionTransactionModel.setInvoiceUrn(commonValidator.getBatchNo());
		
		try {
			LocalDate invoiceDate = stringToLocalDate(commonValidator.getInvoiceDate());
			LocalDate bped = stringToLocalDate(commonValidator.getBillingPeriodEndDate());
			
			LocalDateTime invoiceDateLT = (invoiceDate != null) ? invoiceDate.atTime(LocalTime.now()) : null;
			LocalDateTime bpedLT = (bped != null) ? bped.atTime(LocalTime.now()) : null;
			
			exceptionTransactionModel.setBatchKey5(invoiceDateLT);
			exceptionTransactionModel.setBatchKey6(bpedLT);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
		if (paremNameValueMap != null) {
			paremNameValueMap.forEach((key, value) -> {
				final ExceptionParametersValueModel parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName(key);
				parametersValueModel.setParameterValue(value);
				parametersValueModelList.add(parametersValueModel);
			});
		}

		exceptionTransactionModel.setParametersValueList(parametersValueModelList);

		return exceptionTransactionModel;
	}
	
	public static Boolean isElementEmpty(String element){
        Boolean isEmpty = Boolean.FALSE;
        if(StringUtils.isEmpty(element)) {
        	isEmpty = Boolean.TRUE;
        } 
        return isEmpty;
    }	
	
	public static String dateToString(Date date) {
		String str = MiscBillingConstants.EMPTY_STRING;
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  
			str = dateFormat.format(date);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return str;
	}
	
	public static LocalDate stringToLocalDate(String str) {
		LocalDate localDate = null;
		if(StringUtils.isBlank(str)) return null;
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			localDate = LocalDate.parse(str, formatter);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return localDate;
	}
	
	public static LocalDate stringToLocalDate(String str, String format) {
		LocalDate localDate = null;
		if(StringUtils.isBlank(str)) return null;
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
			localDate = LocalDate.parse(str, formatter);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return localDate;
	}
}
