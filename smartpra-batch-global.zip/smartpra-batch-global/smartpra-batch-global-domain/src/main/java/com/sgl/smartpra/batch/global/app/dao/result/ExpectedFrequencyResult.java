package com.sgl.smartpra.batch.global.app.dao.result;

import java.io.Serializable;

import lombok.Data;

@Data
public class ExpectedFrequencyResult implements Serializable{

	private static final long serialVersionUID = 1L;

	private String expectedFrequency;

	private String moduleName;

	public ExpectedFrequencyResult(String expectedFrequency, String moduleName) {
		super();
		this.expectedFrequency = expectedFrequency;
		this.moduleName = moduleName;
	}
}
