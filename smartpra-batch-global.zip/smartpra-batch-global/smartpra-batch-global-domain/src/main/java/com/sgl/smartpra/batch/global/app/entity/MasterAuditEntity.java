package com.sgl.smartpra.batch.global.app.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "master_audit")
public class MasterAuditEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "master_audit_id")
	private long masterAuditId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "event_type")
	private String eventType;

	@Column(name = "network_login")
	private String networkLogin;

	@Column(name = "new_value")
	private String newValue;

	@Column(name = "old_value")
	private String oldValue;

	@Column(name = "order_id")
	private String orderId;

	@Column(name = "resource_name")
	private String resourceName;

	@Column(name = "schema_name")
	private String schemaName;

	@Column(name = "table_name")
	private String tableName;

	@Column(name = "update_date")
	private LocalDateTime updateDate;

	@Column(name = "user_ip")
	private String userIp;

	@Column(name = "user_machine_name")
	private String userMachineName;

	@Column(name = "user_name")
	private String userName;

}
