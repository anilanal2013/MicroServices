package com.sgl.smartpra.batch.global.app.dao.spec;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.batch.global.app.entity.TicketAuditEntity;

public class TicketAuditEntitySpecification {

	public static Specification<TicketAuditEntity> search(String documentNumber, String documentUniqueId,
			String issuingAirline) {
		return (ticketAuditEntity, criteriaQuery, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (documentNumber != null) {
				predicates.add(criteriaBuilder.like(ticketAuditEntity.get("documentNumber"), documentNumber + "%"));
			}
			if (documentUniqueId != null) {
				predicates.add(criteriaBuilder.like(ticketAuditEntity.get("documentUniqueId"), documentUniqueId + "%"));
			}
			if (issuingAirline != null) {
				predicates.add(criteriaBuilder.like(ticketAuditEntity.get("issuingAirline"), issuingAirline + "%"));
			}

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

}
