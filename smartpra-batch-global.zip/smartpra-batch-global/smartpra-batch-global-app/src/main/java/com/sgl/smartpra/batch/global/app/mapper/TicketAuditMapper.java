package com.sgl.smartpra.batch.global.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.sgl.smartpra.batch.global.app.entity.TicketAuditEntity;
import com.sgl.smartpra.batch.global.model.TicketAudit;

@Mapper(componentModel = "Spring")
public interface TicketAuditMapper extends BaseMapper<TicketAudit, TicketAuditEntity> {

	TicketAuditEntity mapToEntity(TicketAudit ticketAudit, @MappingTarget TicketAuditEntity ticketAuditEntity);

	@Mapping(source = "ticketAuditId", target = "ticketAuditId", ignore = true)
	TicketAuditEntity mapToEntity(TicketAudit ticketAudit);

}
