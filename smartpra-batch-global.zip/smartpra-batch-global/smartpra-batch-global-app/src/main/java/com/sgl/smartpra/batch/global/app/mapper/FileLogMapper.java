package com.sgl.smartpra.batch.global.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.batch.global.app.entity.FileLoggingEntity;
import com.sgl.smartpra.batch.global.model.FileLogging;

@Mapper
public interface FileLogMapper {
	
	FileLogging mapToFileLogModel(FileLoggingEntity fileLoggingEntity);

	List<FileLogging> mapToFileLogModelList(List<FileLoggingEntity> fileLoggingEntityList);

	FileLoggingEntity mapToFileLoggingEntity(FileLogging fileLogging);

	List<FileLoggingEntity> mapToFileLoggingEntityList(List<FileLogging> fileLoggingList);
}
