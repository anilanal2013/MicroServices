package com.sgl.smartpra.batch.global.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.global.app.dao.TicketAuditDao;
import com.sgl.smartpra.batch.global.app.dao.spec.TicketAuditEntitySpecification;
import com.sgl.smartpra.batch.global.app.entity.TicketAuditEntity;
import com.sgl.smartpra.batch.global.app.repository.TicketAuditRepository;

@Component
public class TicketAuditDaoImpl implements TicketAuditDao {

	@Autowired
	private TicketAuditRepository ticketAuditRepository;

	public List<TicketAuditEntity> getAllTicketAudit(String documentNumber, String documentUniqueId,
			String issuingAirline) {
		return ticketAuditRepository
				.findAll(TicketAuditEntitySpecification.search(documentNumber, documentUniqueId, issuingAirline));
	}

	public TicketAuditEntity updateTicketAudit(TicketAuditEntity ticketAuditEntity) {
		return ticketAuditRepository.save(ticketAuditEntity);
	}

}
