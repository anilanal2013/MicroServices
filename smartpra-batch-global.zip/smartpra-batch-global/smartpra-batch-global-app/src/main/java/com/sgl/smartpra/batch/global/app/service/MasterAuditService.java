package com.sgl.smartpra.batch.global.app.service;

import java.util.List;

import com.sgl.smartpra.batch.global.model.MasterAudit;

public interface MasterAuditService {

	List<MasterAudit> getMasterAuditByResourceName(String resourceName);

	MasterAudit updateMasterAudit(Object newObj, Object oldObj, String tableName, String serviceName);

}
