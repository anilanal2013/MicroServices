package com.sgl.smartpra.batch.global.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.global.app.service.TicketAuditService;
import com.sgl.smartpra.batch.global.model.TicketAudit;
import com.sgl.smartpra.common.validator.group.Create;

@RestController
public class TicketAuditController {

	@Autowired
	private TicketAuditService ticketAuditService;

	@GetMapping("/ticket-audit")
	public List<TicketAudit> getAllTicketAudit(
			@RequestParam(value = "documentNumber", required = false) String documentNumber,
			@RequestParam(value = "documentUniqueId", required = false) String documentUniqueId,
			@RequestParam(value = "issuingAirline", required = false) String issuingAirline) {

		return ticketAuditService.getAllTicketAudit(documentNumber, documentUniqueId, issuingAirline);

	}

	@PostMapping("/ticket-audit")
	public TicketAudit updateTicketAudit(@Validated(Create.class) @RequestBody TicketAudit ticketAudit) {

		return ticketAuditService.updateTicketAudit(ticketAudit);

	}
}
