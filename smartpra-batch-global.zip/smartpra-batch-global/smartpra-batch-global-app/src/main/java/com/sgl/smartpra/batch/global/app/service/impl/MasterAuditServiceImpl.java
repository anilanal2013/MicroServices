package com.sgl.smartpra.batch.global.app.service.impl;

import java.net.InetAddress;
import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.global.app.dao.MasterAuditDao;
import com.sgl.smartpra.batch.global.app.mapper.MasterAuditMapper;
import com.sgl.smartpra.batch.global.app.service.MasterAuditService;
import com.sgl.smartpra.batch.global.model.MasterAudit;

@Service
@Transactional
public class MasterAuditServiceImpl implements MasterAuditService {

	@Autowired
	private MasterAuditDao masterAuditDao;

	@Autowired
	private MasterAuditMapper masterAuditMapper;

	InetAddress ip = null;

	@Override
	public List<MasterAudit> getMasterAuditByResourceName(String resourceName) {

		return masterAuditMapper.mapToModel(masterAuditDao.getMasterAuditByResourceName(resourceName));
	}

	@Override
	public MasterAudit updateMasterAudit(Object newObj, Object oldObj, String tableName, String serviceName) {

		MasterAudit masterAudit = new MasterAudit();

		try {
			ip = InetAddress.getLocalHost();
		} catch (Exception e) {
			//log.error("Conext: " + e.getMessage());
		}

		masterAudit.setOldValue(oldObj.toString());
		masterAudit.setNewValue(newObj.toString());
		masterAudit.setUserName("SmartPraAdmin");
		masterAudit.setTableName(tableName);
		masterAudit.setSchemaName(tableName);
		masterAudit.setResourceName(tableName);
		masterAudit.setClientId("QR");
		masterAudit.setUserIp(ip.getHostAddress());
		masterAudit.setUserMachineName(ip.getHostName());
		masterAudit.setUpdateDate(LocalDateTime.now());
		masterAudit.setEventType(serviceName);
		masterAudit.setNetworkLogin(ip.getHostAddress());

		return masterAuditMapper
				.mapToModel(masterAuditDao.updateMasterAudit(masterAuditMapper.mapToEntity(masterAudit)));
	}

}
