package com.sgl.smartpra.batch.global.app.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.global.app.entity.MasterAuditEntity;

@Repository
public interface MasterAuditDao {

	public List<MasterAuditEntity> getMasterAuditByResourceName(String resourceName);

	public MasterAuditEntity updateMasterAudit(MasterAuditEntity masterAuditEntity);

}
