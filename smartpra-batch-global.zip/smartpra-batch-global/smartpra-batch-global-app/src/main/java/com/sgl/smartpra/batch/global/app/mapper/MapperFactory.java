package com.sgl.smartpra.batch.global.app.mapper;

import org.mapstruct.factory.Mappers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperFactory {

	@Bean
	public InboundFileLogMapper getInboundFileLogMapper() {
		return Mappers.getMapper(InboundFileLogMapper.class);
	}

	@Bean
	public FileLogMapper getFileLogMapper() {
		return Mappers.getMapper(FileLogMapper.class);
	}

}