package com.sgl.smartpra.batch.global.model;

import java.time.LocalDateTime;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sgl.smartpra.common.validator.group.Create;

import lombok.Data;

@Data
public class TicketAudit {

	private long ticketAuditId;

	@Size(min = 2, max = 2, message = "Invalid Client Id Size", groups = Create.class)
	private String clientId;

	private int couponNo;

	@Size(min = 1, max = 20, message = "Invalid Document Number Size", groups = Create.class)
	private String documentNumber;

	@Size(min = 1, max = 33, message = "Invalid Document UniqueId Size", groups = Create.class)
	private String documentUniqueId;

	@Size(min = 1, max = 33, message = "Invalid Event Type Size", groups = Create.class)
	private String eventType;

	@Size(min = 1, max = 3, message = "Invalid Issuing Airline Size", groups = Create.class)
	private String issuingAirline;

	@Size(min = 1, max = 10000000, message = "Invalid New Value Size", groups = Create.class)
	private String newValue;

	@Size(min = 1, max = 10000000, message = "Invalid Old Value Size", groups = Create.class)
	private String oldValue;

	@Size(min = 0, max = 20, message = "Invalid OrderId Size", groups = Create.class)
	private String orderId;

	@Size(min = 1, max = 100, message = "Invalid Resource Name Size", groups = Create.class)
	private String resourceName;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime updateDate;

	private String userIp;

	private String userMachineName;

	private String userName;

	private String networkLogin;

}
