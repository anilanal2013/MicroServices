package com.sgl.smartpra.batch.global.model;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class MasterAudit {

	private long masterAuditId;

	private String clientId;

	private String eventType;

	private String networkLogin;

	private String newValue;

	private String oldValue;

	private String orderId;

	private String resourceName;

	private String schemaName;

	private String tableName;

	private LocalDateTime updateDate;

	private String userIp;

	private String userMachineName;

	private String userName;

}
