package com.sgl.smartpra.batch.global.model;

import java.util.List;

import org.springframework.batch.item.file.transform.Range;

public interface FixedLengthLayoutInterface {

	public default Range[] getColumns(List<FixedLengthFieldLayout> fixedLengthFieldLayoutList) {

		Range[] rangeArray = new Range[fixedLengthFieldLayoutList.size()];
		int index = 0;
		for (FixedLengthFieldLayout fixedLengthFieldLayout : fixedLengthFieldLayoutList)
			if (fixedLengthFieldLayout.getEndPosition() == null) {
				rangeArray[index] = new Range(fixedLengthFieldLayout.getStartPosition());
			} else {
				rangeArray[index] = new Range(fixedLengthFieldLayout.getStartPosition(),
						fixedLengthFieldLayout.getEndPosition());
				index++;
			}
		return rangeArray;
	}

	public default String[] getNames(List<FixedLengthFieldLayout> fixedLengthFieldLayoutList) {

		String[] columNameArray = new String[fixedLengthFieldLayoutList.size()];
		int index = 0;
		for (FixedLengthFieldLayout fixedLengthFieldNameLayout : fixedLengthFieldLayoutList) {
			columNameArray[index] = fixedLengthFieldNameLayout.getFieldname();
			index++;
		}

		return columNameArray;

	}

	public static List<FixedLengthFieldLayout> getFixedLengthFieldLayoutList(List<FixedLengthFieldLayout> fixedLengthFieldLayoutList) {
		return fixedLengthFieldLayoutList;
	}

}
