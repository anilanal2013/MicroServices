package com.sgl.smartpra.batch.global;

public enum SalesFileHeader {
	
	TTH("ARC", "ARC", "CNJ"), BFH("BSP", "BSP", "CJN"), ARC("TTH", "ARC", "CJN"), BSP("BFH", "ARC", "CJN"),
	AMADEUS_HOT("BFH", "AMADEUS_HOT", "CJN") ;
	
	private String value;
	
	private String fileType;
	
	private String conjunctionIndicator;

	private SalesFileHeader(String value , String fileType , String conjunctionIndicator) {
		this.value = value;
		this.fileType = fileType;
		this.conjunctionIndicator = conjunctionIndicator;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getConjunctionIndicator() {
		return conjunctionIndicator;
	}

	public void setConjunctionIndicator(String conjunctionIndicator) {
		this.conjunctionIndicator = conjunctionIndicator;
	}
}
