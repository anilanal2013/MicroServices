package com.sgl.smartpra.batch.global.model;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.sgl.smartpra.common.model.BaseMaster;

@JsonInclude(Include.NON_NULL)
public class FileErrorLog extends BaseMaster implements Serializable {

	private static final long serialVersionUID = -7003206084583012536L;

	private BigInteger fileErrorId;
	
	private BigInteger fileId;

	private String errorDetail;
	
	private String errorDescription;

	public BigInteger getFileErrorId() {
		return fileErrorId;
	}

	public void setFileErrorId(BigInteger fileErrorId) {
		this.fileErrorId = fileErrorId;
	}

	public BigInteger getFileId() {
		return fileId;
	}

	public void setFileId(BigInteger fileId) {
		this.fileId = fileId;
	}

	public String getErrorDetail() {
		return errorDetail;
	}

	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	

}
