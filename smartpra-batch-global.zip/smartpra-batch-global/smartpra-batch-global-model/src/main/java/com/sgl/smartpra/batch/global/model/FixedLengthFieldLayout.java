package com.sgl.smartpra.batch.global.model;

public class FixedLengthFieldLayout {

    private String fieldName;
    private Integer startPosition;
    private Integer endPosition;
    
    public FixedLengthFieldLayout(String fieldname, Integer startPosition, Integer endPosition){
    	this.fieldName = fieldname;
    	this.startPosition = startPosition;
    	this.endPosition = endPosition;
    }
  

	public String getFieldname() {
		return fieldName;
	}

	public void setFieldname(String fieldname) {
		this.fieldName = fieldname;
	}

	public Integer getStartPosition() {
		return startPosition;
	}

	public void setStartPosition(Integer startPosition) {
		this.startPosition = startPosition;
	}

	public Integer getEndPosition() {
		return endPosition;
	}

	public void setEndPosition(Integer endPosition) {
		this.endPosition = endPosition;
	}
}
