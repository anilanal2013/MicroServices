package com.sgl.smartpra.common.validator;

public class ValidatorConstants {

	public static final String REGEX_DDMMYY = "((0[1-9]|[12][0-9]|3[01])(0[1-9]|1[0-2])([0-9][0-9]))*";
	
	public static final String REGEX_NUMBER = "[+-]?[0-9]+(\\.[0-9]+)?([Ee][+-]?[0-9]+)?";
}
