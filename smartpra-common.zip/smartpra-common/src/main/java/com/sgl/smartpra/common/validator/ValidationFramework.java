package com.sgl.smartpra.common.validator;

import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.validation.BindException;

import com.sgl.smartpra.common.model.ValidatorResponse;

@ComponentScan
public interface ValidationFramework {
	
	public List<ValidatorResponse> validateEntity(Object obj) throws BindException;

}
