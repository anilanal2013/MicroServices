package com.sgl.smartpra.common.validator.impl;

import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.OptionalFieldSize;

/**
 * This class is used to validate the given optional object's field size
 *
 */
public class OptionalFieldSizeValidator implements ConstraintValidator<OptionalFieldSize, Optional<String>> {

	private int min;

	private int max;

	@Override
	public void initialize(OptionalFieldSize constraintAnnotation) {
		this.min = constraintAnnotation.min();
		this.max = constraintAnnotation.max();

	}

	@Override
	public boolean isValid(Optional<String> value, ConstraintValidatorContext context) {
		if (!OptionalUtil.isNotNull(value)) {
			return true;
		} else if (OptionalUtil.isEmpty(value)) {
			return true;
		} else {
			return value.get().length() >= min && value.get().length() <= max;
		}
	}

}
