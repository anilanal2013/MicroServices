package com.sgl.smartpra.common.constant;

public enum Month {
    JAN {
        @Override
        public int getMonthValue() {
            return 1;
        }
    },
    FEB {
        @Override
        public int getMonthValue() {
            return 2;
        }
    },
    MAR {
        @Override
        public int getMonthValue() {
            return 3;
        }
    },
    APR {
        @Override
        public int getMonthValue() {
            return 4;
        }
    },
    MAY {
        @Override
        public int getMonthValue() {
            return 5;
        }
    },
    JUN {
        @Override
        public int getMonthValue() {
            return 6;
        }
    },
    JUL {
        @Override
        public int getMonthValue() {
            return 7;
        }
    },
    AUG {
        @Override
        public int getMonthValue() {
            return 8;
        }
    },
    SEP {
        @Override
        public int getMonthValue() {
            return 9;
        }
    },
    OCT {
        @Override
        public int getMonthValue() {
            return 10;
        }
    },
    NOV {
        @Override
        public int getMonthValue() {
            return 11;
        }
    },
    DEC {
        @Override
        public int getMonthValue() {
            return 12;
        }
    };
    public abstract int getMonthValue();
}
