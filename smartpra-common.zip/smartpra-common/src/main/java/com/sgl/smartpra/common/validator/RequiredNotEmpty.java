package com.sgl.smartpra.common.validator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.sgl.smartpra.common.validator.impl.RequiredNotEmptyValidator;

/**
 * This Annotation interface is used to validate mandatory elements. Provided
 * element cannot be null or empty
 * 
 * @author rajanand1
 *
 */
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = RequiredNotEmptyValidator.class)
@Documented
public @interface RequiredNotEmpty {

	String message() default "Cannot be Null or Empty";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};
	
	

}
