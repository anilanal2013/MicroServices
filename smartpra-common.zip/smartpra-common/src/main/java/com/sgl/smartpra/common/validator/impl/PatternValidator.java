/**
 * 
 */
package com.sgl.smartpra.common.validator.impl;

import java.util.Optional;
import java.util.regex.Matcher;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.OptionalPattern;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * This class is used to validate the given RegEx with the provided pattern
 * 
 * @author patblaxm
 *
 */
@Slf4j
public class PatternValidator implements ConstraintValidator<OptionalPattern, Optional<String>> {
	private String regexp;

	@Override
	public void initialize(OptionalPattern constraintAnnotation) {
		this.regexp = constraintAnnotation.regexp();

	}

	@Override
	public boolean isValid(Optional<String> value, ConstraintValidatorContext context) {
		log.info("value {}", value);
		if (!OptionalUtil.isNotNull(value)) {
			return true;
		} else if (OptionalUtil.isEmpty(value)) {
			return false;
		} else {
			try {
				return java.util.regex.Pattern.compile(this.regexp).matcher(value.get()).find();
			} catch (Throwable e) {
				log.error("Given RegEx {}", value.get() + " is not a valid pattern {}", regexp);
				return false;
			}
		}
	}

}
