package com.sgl.smartpra.common.validator.impl;

import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.NotApplicable;

import lombok.extern.slf4j.Slf4j;

/**
 * This Annotation interface is used to restrict the fields usage.
 * 
 * @author rajanand1
 *
 */
@Slf4j
public class NotApplicableValidator implements ConstraintValidator<NotApplicable, Optional<?>> {

	@Override
	public boolean isValid(Optional<?> value, ConstraintValidatorContext context) {
		log.info("{}", value);
		if (!OptionalUtil.isNotNull(value)) {
			return true;
		} else {
			return false;
		}
	}

}
