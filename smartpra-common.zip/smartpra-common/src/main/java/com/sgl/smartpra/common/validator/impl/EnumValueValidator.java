package com.sgl.smartpra.common.validator.impl;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.util.StringUtils;

import com.sgl.smartpra.common.util.OptionalUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EnumValueValidator implements ConstraintValidator<com.sgl.smartpra.common.validator.Enum, Object> {

	private Set<String> enumValuesSet;

	@Override
	public void initialize(com.sgl.smartpra.common.validator.Enum constraintAnnotation) {
		this.enumValuesSet = new HashSet<>();
		for (java.lang.Enum<?> enumValues : constraintAnnotation.enumClass().getEnumConstants()) {
			this.enumValuesSet.add(enumValues.toString());
		}
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		log.info("value{}", value);
		if (value instanceof String) {
			return isValid((String) value);
		} else if (value instanceof Optional) {
			return isValid((Optional<?>) value);
		}
		return false;
	}

	private boolean isValid(String value) {
		if (StringUtils.hasText(value) && this.enumValuesSet.contains(value)) {
			return true;
		}
		return false;
	}

	private boolean isValid(Optional<?> value) {
		if (!OptionalUtil.isNotNull(value)) {
			return true;
		} else if (OptionalUtil.isEmpty(value)) {
			return false;
		} else {
			if (this.enumValuesSet.contains((String) value.get())) {
				return true;
			} else {
				return false;
			}
		}
	}
}