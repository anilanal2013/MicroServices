package com.sgl.smartpra.common.validator.group;

public interface Update {

}
