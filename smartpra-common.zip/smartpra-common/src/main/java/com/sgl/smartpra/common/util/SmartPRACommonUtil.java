package com.sgl.smartpra.common.util;

import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;


public class SmartPRACommonUtil {

	public static String padString(String str, String pad, final Integer maxLen) {
		int length = str.length();
		StringBuilder stringBuilder = new StringBuilder();
		while(length < maxLen) {
			stringBuilder.append(pad.trim());
			++length;
		}
		return stringBuilder.toString()+str;
	}

	public static String postPadString(String str, String pad, final Integer maxLen) {
		int length = str.length();
		StringBuilder stringBuilder = new StringBuilder();
		while(length < maxLen) {
			stringBuilder.append(pad.trim());
			++length;
		}
		return str+stringBuilder.toString();
	}

	public static String postNoTrimPadString(String str, String pad, final Integer maxLen) {
		int length = str.length();
		StringBuilder stringBuilder = new StringBuilder();
		while(length < maxLen) {
			stringBuilder.append(pad);
			++length;
		}
		return str+stringBuilder.toString();
	} 

	public static String getCurrentDate(String dateFormat) {
		return new SimpleDateFormat(dateFormat).format(new Date());
	}

	public static String deriveFlightNo(String actualFlightNo, String sysParamFlightLen) {
		String derFlightNo="";
		if(actualFlightNo != null  &&!actualFlightNo.isEmpty() ) { 
			if(sysParamFlightLen == null || sysParamFlightLen.equals("0")) {
				if(actualFlightNo.length() > 4) {
					derFlightNo = actualFlightNo.substring(actualFlightNo.length()-4);
				} else {
					derFlightNo = actualFlightNo;
				}
			} else if(sysParamFlightLen.equals("3")) {
				if(actualFlightNo.length() > 3) {
					derFlightNo = actualFlightNo.substring(actualFlightNo.length()-3);
				} else {
					//derFlightNo = String.format("%03d", Integer.parseInt(actualFlightNo));
					derFlightNo = StringUtils.leftPad(actualFlightNo, 3, "0");
				}
			} else if(sysParamFlightLen.equals("4")) {
				if(actualFlightNo.length() > 4) {
					derFlightNo = actualFlightNo.substring(actualFlightNo.length()-4);
				} else {
					//derFlightNo = String.format("%04d", Integer.parseInt(actualFlightNo));
					derFlightNo = StringUtils.leftPad(actualFlightNo, 4, "0");
				}
			} 
		} else {
			return actualFlightNo;
		}
		return derFlightNo;
	}
	public static Boolean isNullOrTrimEmpty(String str) {
		return (str == null || str.trim().length() == 0)?true:false;
	}
	public static Boolean isNullOrZeroBigDecimal(BigDecimal bigDecimal) {
		return (bigDecimal == null || bigDecimal.compareTo(BigDecimal.ZERO) == 0)?true:false;
	}
	public static Boolean strNullCompare(String soruce, String target) {
		return (soruce != null && soruce.equalsIgnoreCase(target))?true:false;
	}

	
	public static LocalDate convertToLocalDate(Date date) {
		if(date != null) {
			return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		}else {
			return null;	
		}
	}
	
	public static LocalDateTime convertToLocalDateTimeToDate(Date date) {
        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

	public static LocalDate convertStrToLocalDate(String strDate, String currStrFormat) {
		DateTimeFormatter formatter = null;
		LocalDate localDate = null;
		if(!isNullOrTrimEmpty(strDate) && !isNullOrTrimEmpty(currStrFormat)) {
			formatter = DateTimeFormatter.ofPattern(currStrFormat);
			localDate = LocalDate.parse(strDate, formatter);
		}
		return localDate;
	}
	public static String deriveCodeShareRBD(String ticketedRBD, String codeShareMarketedRBDList, String codeShareOperatedRBDList) {
		String codeShareRBD = null;
		if(ticketedRBD != null && codeShareMarketedRBDList != null && codeShareOperatedRBDList != null ) {
			String[] marketedRBDs = codeShareMarketedRBDList.split("/");
			String[] operatedRBDs = codeShareOperatedRBDList.split("/");
			int index = Arrays.asList(marketedRBDs).indexOf(ticketedRBD);
			if(index >= 0 && index < operatedRBDs.length) {
				codeShareRBD = operatedRBDs[index];
			}
		}
		return codeShareRBD;
	}	

}