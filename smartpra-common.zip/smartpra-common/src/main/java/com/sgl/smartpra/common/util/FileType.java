package com.sgl.smartpra.common.util;

public enum FileType {
	TXT, PDF, DOC, DOCX, XML;

	public static boolean contains(String ext) {

		for (FileType type : FileType.values()) {
			if (type.name().equalsIgnoreCase(ext)) {
				return true;
			}
		}

		return false;
	}
}
