package com.sgl.smartpra.common.validator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.sgl.smartpra.common.validator.impl.DateFormatValidator;

/**
 * This Annotation interface is used to validate the given date with the
 * provided dateformat. This annotation is used on the fields.
 * 
 * @author rajanand1
 *
 */
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = DateFormatValidator.class)
@Documented
public @interface DateFormat {

	String message() default "Invalid DateTime Format";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

	String pattern();

}
