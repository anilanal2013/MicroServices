package com.sgl.smartpra.common.validator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.sgl.smartpra.common.validator.impl.FieldSizeValidator;

/**
 * This Annotation interface is used to validate the field's size with the
 * provided min, max values. This annotation is used on the fields.
 * 
 * @author rajanand1
 *
 */
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = FieldSizeValidator.class)
@Documented
public @interface FieldSize {

	String message() default "Incorrect Field Length";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

	int min() default 0;

	int max() default Integer.MAX_VALUE;;

}
