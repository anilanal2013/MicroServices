package com.sgl.smartpra.common.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sgl.smartpra.common.validator.FieldSize;
import com.sgl.smartpra.common.validator.NotApplicable;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;

@Data
public class BaseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@RequiredNotEmpty(groups = Create.class)
	@FieldSize(min = 1, max = 15, groups = Create.class)
	@NotApplicable(groups=Update.class)
	private Optional<String> createdBy;

	@RequiredNotEmpty(groups = Update.class)
	@FieldSize(min = 1, max = 15, groups = Update.class)
	@NotApplicable(groups=Create.class)
	private Optional<String> lastUpdatedBy;

	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime createdDate;

	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime lastUpdatedDate;

}
