package com.sgl.smartpra.common.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * This Util provides methods to convert the given Optional<String> element into
 * corresponding Object
 * 
 * @author rajanand1
 *
 */

public final class OptionalUtil {

	private OptionalUtil() {
	}

	private static final String DATE_PATTERN = "yyyy-MM-dd";

	public static boolean isEmpty(Optional<?> t) {
		return isNotNull(t) && Optional.empty().equals(t);
	}

	public static boolean isPresent(Optional<?> t) {
		return isNotNull(t) && !isEmpty(t);
	}

	public static boolean isNotNull(Optional<?> t) {
		return t != null;
	}

	public static <T> T getValue(Optional<T> t) {
		return t.orElse(null);
	}

	public static LocalDate getLocalDateValue(Optional<String> dateString) {
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_PATTERN);
		return LocalDate.parse(dateString.get(), dateTimeFormatter);
	}
}
