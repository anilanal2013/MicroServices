package com.sgl.smartpra.common.validator.impl;

import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.util.StringUtils;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.ValidValues;

import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to validate input string matches with given values
 * 
 * @author rajanand1
 *
 */
@Slf4j
public class ValidValuesValidator implements ConstraintValidator<ValidValues, Optional<String>> {

	private Set<String> validValuesSet;

	@Override
	public void initialize(ValidValues constraintAnnotation) {
		this.validValuesSet = (StringUtils.commaDelimitedListToSet(constraintAnnotation.values()));
	}

	@Override
	public boolean isValid(Optional<String> value, ConstraintValidatorContext context) {
		if (!OptionalUtil.isNotNull(value)) {
			return true;
		} else if (OptionalUtil.isEmpty(value)) {
			return false;
		} else {
			return validValuesSet.contains(OptionalUtil.getValue(value).trim());
		}

	}

}
