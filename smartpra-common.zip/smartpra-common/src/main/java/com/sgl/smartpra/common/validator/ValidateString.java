package com.sgl.smartpra.common.validator;

import javax.validation.Payload;

public @interface ValidateString {

    String[] acceptedValues();

    String message() default "Invalid value. This is not permitted.";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { }; 
}