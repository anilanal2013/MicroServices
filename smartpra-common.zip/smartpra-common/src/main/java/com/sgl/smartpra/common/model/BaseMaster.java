package com.sgl.smartpra.common.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Size;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

/**
 * Base class for all master model
 *
 */
public class BaseMaster implements Serializable{

	@NotNull(message = ValidationMessage.CREATED_BY_REQUIRED, groups = Create.class)
	@Size(min = 1, max = 15, message = ValidationMessage.CREATED_BY_LENGTH, groups = Create.class)
	@Null(message = ValidationMessage.CREATED_BY_INVALID, groups = Update.class)
	protected String createdBy;

	//@Null(message = ValidationMessage.CREATED_DATE_INVALID, groups = { Create.class, Update.class })
	protected Timestamp createdDate;

	@NotNull(message = ValidationMessage.LAST_UPDATED_BY_REQUIRED, groups = Update.class)
	@Size(min = 1, max = 15, message = ValidationMessage.LAST_UPDATED_BY_LENGTH, groups = Update.class)
	@Null(message = ValidationMessage.LAST_UPDATED_BY_INVALID, groups = Create.class)
	protected String lastUpdatedBy;

	@Null(message = ValidationMessage.LAST_UPDATED_DATE_INVALID, groups = { Create.class, Update.class })
	protected Timestamp lastUpdatedDate;

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		if (createdBy != null) {
			this.createdBy = createdBy.trim();
		}
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		if (lastUpdatedBy != null) {
			this.lastUpdatedBy = lastUpdatedBy.trim();
		}
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
