package com.sgl.smartpra.common.validator.impl;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.DateFormat;

import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to validate the given date with the provided dateformat
 * 
 * @author rajanand1
 *
 */
@Slf4j
public class DateFormatValidator implements ConstraintValidator<DateFormat, Optional<String>> {

	private String pattern;

	@Override
	public void initialize(DateFormat constraintAnnotation) {
		this.pattern = constraintAnnotation.pattern();

	}

	@Override
	public boolean isValid(Optional<String> value, ConstraintValidatorContext context) {
		log.info("value {}", value);
		if (!OptionalUtil.isNotNull(value)) {
			return true;
		} else if (OptionalUtil.isEmpty(value)) {
			return false;
		} else {
			try {
				DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
				dateTimeFormatter.parse(value.get());
				return true;
			} catch (Exception e) {
				log.error("Given Date {}", value.get() + " is not of pattern {}", pattern);
				return false;
			}
		}
	}

}
