package com.sgl.smartpra.common.validator.impl;

import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.util.StringUtils;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;

public class OptionalNotEmptyValidator implements ConstraintValidator<OptionalNotEmpty, Optional<?>> {

	@Override
	public boolean isValid(Optional<?> value, ConstraintValidatorContext context) {
		if (!OptionalUtil.isNotNull(value)) {
			return true;
		} else if (OptionalUtil.isEmpty(value)) {
			return false;
		} else {
			if (OptionalUtil.getValue(value) instanceof String) {
				return StringUtils.hasText((String) OptionalUtil.getValue(value));
			} else {
				return true;
			}
		}
	}
}
