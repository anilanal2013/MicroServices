package com.sgl.smartpra.common.validator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.sgl.smartpra.common.validator.impl.PatternValidator;

/**
 * 
 * This Annotation interface is used to check the given RegEx. This annotation is used on the fields.
 * 
 * @author patblaxm
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Constraint(validatedBy = PatternValidator.class)
@Documented
public @interface OptionalPattern {
	String message() default "Invalid value";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

	String regexp();
}
