package com.sgl.smartpra.common.validator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
 
import javax.validation.Constraint;
import javax.validation.Payload;

import com.sgl.smartpra.common.validator.impl.RangeValidator;
 
@Documented
@Constraint(validatedBy = {RangeValidator.class})
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface Range
{
    public abstract String message() default "Invalid value. Not within Provided Range";
     
    public abstract Class<?>[] groups() default {};
  
    public abstract Class<? extends Payload>[] payload() default {};
     
    public int max();
    
    public int min();
     
}