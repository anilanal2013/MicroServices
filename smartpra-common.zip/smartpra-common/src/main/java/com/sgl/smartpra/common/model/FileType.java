package com.sgl.smartpra.common.model;

public enum FileType {
	TXT, PDF, DOC, DOCX;

	public static boolean contains(String ext) {

		for (FileType type : FileType.values()) {
			if (type.name().equalsIgnoreCase(ext)) {
				return true;
			}
		}

		return false;
	}
}
