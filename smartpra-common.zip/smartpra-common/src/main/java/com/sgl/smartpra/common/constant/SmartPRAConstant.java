package com.sgl.smartpra.common.constant;

public class SmartPRAConstant {
    public static final String CLIENT_ID = "QR";
    
    public static final String VALIDATION_MODULE_FLOWN = "FLOWN";
    public static final String VALIDATION_MODULE_SALES = "SALES";
    public static final String VALIDATION_SOURCE_UI = "UI";
    public static final String VALIDATION_MODULE_NONUI = "SERVICE";
}
