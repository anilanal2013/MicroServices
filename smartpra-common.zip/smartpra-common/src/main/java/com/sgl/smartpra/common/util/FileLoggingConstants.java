package com.sgl.smartpra.common.util;

public class FileLoggingConstants {

	public static final String FILELOGGING_FILETYPE_REQUEST_IN="ONEWORLD-REQUEST-IN";
	public static final String FILELOGGING_FILETYPE_REQUEST_OUT="ONEWORLD-REQUEST-OUT";
	public static final String FILELOGGING_FILETYPE_RESPONSE_IN="ONEWORLD-RESPONSE-IN";
	public static final String FILELOGGING_FILETYPE_RESPONSE_OUT="ONEWORLD-RESPONSE-OUT";
	public static final String FILELOGGING_FILETYPE_CODESHARE_IN="ONEWORLD-CODESHARE-IN";
	public static final String FILELOGGING_FILETYPE_CODESHARE_OUT="ONEWORLD-CODESHARE-OUT";
	public static final String FILELOGGING_FILETYPE_ESAL_IN="ONEWORLD-ESAL-IN";
	public static final String FILELOGGING_FILETYPE_ESAL_OUT="ONEWORLD-ESAL-OUT";
	

	public static final String FILELOGGING_INTERFACE_INPUT="I";
	public static final String FILELOGGING_INTERFACE_OUTPUT="O";

	public static final String FILELOGGING_FILECATEGORY_TEXT="Text";

	public static final String FILELOGGING_PROCESSEDBY_MANUAL="Manual";
	public static final String FILELOGGING_PROCESSEDBY_SCHEDULER="Scheduler";

	public static final String FILELOGGING_FILESTATUS_CREATED="CR";
	public static final String FILELOGGING_FILESTATUS_STARTED="ST";
	public static final String FILELOGGING_FILESTATUS_TRANSFERRED="TR";
	public static final String FILELOGGING_FILESTATUS_ERRONEOUS="ER";
	public static final String FILELOGGING_FILESTATUS_TECHFAILED="TF";
	public static final String FILELOGGING_FILESTATUS_PARTTRANSFERRED="PT";
	public static final String FILELOGGING_LOADSTATUS__STAGING_SUCCESS="SC";
	public static final String FILELOGGING_LOADSTATUS_STAGING_FAILED = "SF";
	public static final String FILELOGGING_LOADSTATUS__PROCESSING_SUCCESS="PS";
	public static final String FILELOGGING_LOADSTATUS_PROCESSING_FAILED = "PF";

	public static final String FILELOGGING_FIELDERROR_STATUS="Errored";

	public static final String FILELOGGING_FAILED_REMARK="Batch execution failed.";
	
	public static final String MODULE_TABLE_NAME="General";
	public static final String MODULE_COLUMN_NAME="Module";
	
	//BSP and 20.3
	public static final String FILELOGGING_FILETYPE_BSP_IN="BSP-IN";
	public static final String FILELOGGING_SOURCE_BSP = "BSP";
	public static final String MODULE_SALES="Sales";
	public static final String FILELOGGING_MODULEID_BSP = "SA";
	
	public static final String FILELOGGING_FILETYPE_SALES_AMADEUS_IN="AMADEUS-HOT-IN";
	public static final String FILELOGGING_SOURCE_SALES_AMADEUS = "AMADEUS-HOT";
	public static final String FILELOGGING_MODULEID_SALES_AMADEUS  = "SA";
	
	public static final String STAGING_ENVIRONMENT = "S";
	public static final String PRODUCTION_ENVIRONMENT	= "P";

	//Amadeus
	public static final String FILELOGGING_FILETYPE_AMADEUS_ETL_IN="AMADEUS-ETL-IN";
	public static final String FILELOGGING_FILETYPE_AMADEUS_EMD_IN="AMADEUS-EMD-IN";
	
	public static final String FILELOGGING_FILETYPE_SABER_IN="SABER_IN";
	public static final String FILELOGGING_FILETYPE_SABER_EMD__IN="SABER_EMD_IN";
	public static final String FILE_LOGGING_FILE_TYPE_SABER_XL_IN="SABER_XL_IN";
	public static final String FILELOGGING_SOURCE_AMADEUS="AMADEUS";
	public static final String FILELOGGING_CREATEDBY_AMADEUS = "AMADEUS_BATCH";
	public static final String FILELOGGING_UPDATEDBY_AMADEUS = "AMADEUS_BATCH";
	public static final String FILELOGGING_MODULEID_AMADEUS = "FL";
	
	//Miscellaneous Billing
	public static final String FILELOGGING_FILETYPE_MISC_BILLING_IN="MISC-BILLING-IN";
	public static final String FILELOGGING_FILETYPE_MISC_BILLING_OUT="MISC-BILLING-OUT";
	public static final String FILELOGGING_FILETYPE_MISC_BILLING_SUP="MISC-BILLING-SUP";
	public static final String FILELOGGING_FILECATEGORY_XML="XML";
	public static final String FILELOGGING_SOURCE_ARC = "ARC";
	public static final String FILELOGGING_FILECATEGORY_ZIP="ZIP";
}
