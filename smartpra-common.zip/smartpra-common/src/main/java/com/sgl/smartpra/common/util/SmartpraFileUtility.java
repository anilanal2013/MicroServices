package com.sgl.smartpra.common.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FileUtils;
import org.hibernate.service.spi.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SmartpraFileUtility {
	private static final Logger LOGGER = LoggerFactory.getLogger(SmartpraFileUtility.class);

	public static List<String> extractFiles(String sourceDir, String destinationDir, String extension) {
		byte[] buffer = new byte[1024];
		List<String> unzipedFiles = new ArrayList<>();
		try {
			File dir = new File(sourceDir);
			File[] listOfFiles = dir.listFiles();

			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(extension)) {
					ZipInputStream zis = new ZipInputStream(
							new FileInputStream(new File(sourceDir + File.separator + listOfFiles[i].getName())));
					ZipEntry ze = zis.getNextEntry();
					while (ze != null) {
						String fileName = ze.getName();
						File outPut = new File(destinationDir + File.separator + fileName);
						FileOutputStream fos = new FileOutputStream(outPut);
						int len;
						while ((len = zis.read(buffer)) > 0) {
							fos.write(buffer, 0, len);
						}
						unzipedFiles.add(fileName);
						fos.close();
						ze = zis.getNextEntry();
					}
					zis.closeEntry();
					zis.close();
				} else if (listOfFiles[i].isDirectory()) {

				}
			}
		} catch (Exception e) {

			throw new ServiceException(e.getMessage());

		}

		return unzipedFiles;
	}

	public static String getFileSize(String fileName) {
		File fileObj = new File(fileName);
		return FileUtils.byteCountToDisplaySize(fileObj.length());
	}

	/**
	 * This method is used to move a file from one folder to another folder.
	 * 
	 * @param source
	 * @param target
	 * @return
	 */
	public static boolean moveFile(String source, String target) {
		Path moveResp = null;
		try {
			moveResp = Files.move(Paths.get(source), Paths.get(target));
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return moveResp != null ? true : false;
	}

	/**
	 * This method is used to check the file exists.
	 * 
	 * @param fileName
	 * @return
	 */
	public static boolean fileExists(String fileName) {
		if (fileName == null)
			return false;
		File file = new File(fileName);
		return file != null && file.exists() && file.isFile();
	}

	public static boolean isEmptyFile(String fileName) {
		File file = new File(fileName);
		return file.length() == 0;
	}

	public static List<String> unzipFiles(String sourceDir, String destinationDir) {
		byte[] buffer = new byte[1024];
		List<String> unzipedFiles = new ArrayList<>();
		try {
			File dir = new File(sourceDir);
			File[] listOfFiles = dir.listFiles();

			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(".zip")) {
					ZipInputStream zis = new ZipInputStream(
							new FileInputStream(new File(sourceDir + File.separator + listOfFiles[i].getName())));
					ZipEntry ze = zis.getNextEntry();
					while (ze != null) {
						String fileName = ze.getName();
						File outPut = new File(destinationDir + File.separator + fileName);
						FileOutputStream fos = new FileOutputStream(outPut);
						int len;
						while ((len = zis.read(buffer)) > 0) {
							fos.write(buffer, 0, len);
						}
						unzipedFiles.add(fileName);
						fos.close();
						ze = zis.getNextEntry();
					}
					zis.closeEntry();
					zis.close();
				} else if (listOfFiles[i].isDirectory()) {
					LOGGER.info(" Directory " + listOfFiles[i].getName());
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new ServiceException(e.getMessage());

		}

		return unzipedFiles;
	}

	/**
	 * Read the text file and fetch the first line to identify the file type or
	 * sequence no.
	 * 
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public String readFirstLine(String fileName) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
		String firstLine = bufferedReader.readLine();
		bufferedReader.close();
		return firstLine;
	}

	public String readLineForSaber(String fileName) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
		String detailRecord = bufferedReader.readLine();
		Integer length = 0;
		while ((detailRecord = bufferedReader.readLine()) != null) {
			if (detailRecord.startsWith("C")) {
				length = detailRecord.length();
				LOGGER.info("Length of Sabre VCR Detail Record has##############" + length);
				break;
			}
		}

		bufferedReader.close();
		return Integer.toString(length);
	}

}
