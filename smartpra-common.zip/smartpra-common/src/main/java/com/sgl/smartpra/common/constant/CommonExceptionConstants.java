package com.sgl.smartpra.common.constant;

public class CommonExceptionConstants {

	public static final String EXCEPTION_TYPE_NOERROR = "V";
	public static final String EXCEPTION_TYPE_ERROR = "E";
	public static final String EXCEPTION_TYPE_WARNING = "W";

	public static final String EXCEPTION_MODULE_GENERAL = "GEN";
	public static final String EXCEPTION_FORCE_CLOSE_GENERAL = "GENERAL";

	public static final String EXCEPCODE_GEN2000 = "GEN2000";
	public static final String EXCEPCODE_GEN2000_PARAM_1 = "Carrier code";
	public static final String EXCEPCODE_GEN2000_PARAM_2 = "Document Number";
	public static final String EXCEPCODE_GEN2000_PARAM_3 = "Coupon Number";

	public static final String EXCEPCODE_GEN1102 = "GEN1102";
	public static final String EXCEPCODE_GEN1102_PARAM_1 = "Carrier Numeric Code";
	public static final String EXCEPCODE_GEN1102_PARAM_2 = "Document Number";

	public static final String EXCEPCODE_GEN1103 = "GEN1103";
	public static final String EXCEPCODE_GEN1103_PARAM_1 = "City Code";
	public static final String EXCEPCODE_GEN1103_PARAM_2 = "Carrier Numeric Code";
	public static final String EXCEPCODE_GEN1103_PARAM_3 = "Document Number";
	public static final String UIFIELD_GEN1103_POI_ERROR = "placeOfIssue";
	public static final String UIMSG_GEN1103_POI_ERROR = "Invalid Place Of Issue Error";
	public static final String UIFIELD_GEN1103_POI_WARN = "placeOfIssue";
	public static final String UIMSG_GEN1103_POI_WARN = "Invalid Place Of Issue Warning";
	public static final String UIFIELD_GEN1103_POS_ERROR = "placeOfSale";
	public static final String UIMSG_GEN1103_POS_ERROR = "Invalid Place Of Sale Error";
	public static final String UIFIELD_GEN1103_POS_WARN = "placeOfSale";
	public static final String UIMSG_GEN1103_POS_WARN = "Invalid Place Of Sale Warning";

	
	public static final String EXCEPCODE_GEN1104 = "GEN1104";
	public static final String EXCEPCODE_GEN1104_PARAM_1 = "Carrier Numeric Code";
	public static final String EXCEPCODE_GEN1104_PARAM_2 = "Document Number";
	public static final String EXCEPCODE_GEN1104_PARAM_3 = "Agency Code";
	public static final String UIFIELD_GEN1104_AGENT_ERROR = "agentCode";
	public static final String UIMSG_GEN1104_AGENT_ERROR = "Invalid Agent Code Error";
	public static final String UIFIELD_GEN1104_AGENT_WARN = "agentCode";
	public static final String UIMSG_GEN1104_AGENT_WARN = "Invalid Agent Code Warning";
	public static final String UIFIELD_GEN1104_ORIGAGENT_ERROR = "originalAgentCode";
	public static final String UIMSG_GEN1104_ORIGAGENT_ERROR = "Invalid Original Agent Code Error";
	public static final String UIFIELD_GEN1104_ORIGAGENT_WARN = "originalAgentCode";
	public static final String UIMSG_GEN1104_ORIGAGENT_WARN = "Invalid Original Agent Code Warning";

	
	public static final String EXCEPCODE_GEN1106 = "GEN1106";
	public static final String EXCEPCODE_GEN1106_PARAM_1 = "Carrier Numeric Code";
	public static final String EXCEPCODE_GEN1106_PARAM_2 = "Document Number";
	public static final String EXCEPCODE_GEN1106_PARAM_3 = "Carrier Code";

	public static final String EXCEPCODE_GEN1108 = "GEN1108";
	public static final String EXCEPCODE_GEN1108_PARAM_1 = "Carrier Numeric Code";
	public static final String EXCEPCODE_GEN1108_PARAM_2 = "Document Number";

	public static final String EXCEPCODE_GEN1118 = "GEN1118";
	public static final String EXCEPCODE_GEN1118_PARAM_1 = "Coupon Number";
	public static final String EXCEPCODE_GEN1118_PARAM_2 = "Issue Airline";
	public static final String EXCEPCODE_GEN1118_PARAM_3 = "Document Number";
	public static final String EXCEPCODE_GEN1118_PARAM_4 = "Utilization Type";
	public static final String EXCEPCODE_GEN1118_PARAM_5 = "Document Type";

	public static final String EXCEPCODE_GEN1101 = "GEN1101";
	public static final String EXCEPCODE_GEN1101_PARAM_1 = "File name";

	public static final String EXCEPCODE_GEN1115 = "GEN1115";
	public static final String EXCEPCODE_GEN1115_PARAM_1 = "Agency code";
	
	public static final String EXCEPCODE_GEN2004 = "GEN2004";
	public static final String EXCEPCODE_GEN2004_PARAM_1 = "Agency code";
	public static final String EXCEPCODE_GEN2004_PARAM_2 = "Currency code";
	public static final String EXCEPCODE_GEN2004_PARAM_3 = "Eff From Date";
	public static final String EXCEPCODE_GEN2004_PARAM_4 = "Eff to Date";
	public static final String UIFIELD_GEN2004_AGENT_ERROR = "agentCode";
	public static final String UIMSG_GEN2004_AGENT_ERROR = "Unable to create an agent Error";
	public static final String UIFIELD_GEN2004_AGENT_WARN = "agentCode";
	public static final String UIMSG_GEN2004_AGENT_WARN = "Unable to create an agent Warning";
	public static final String UIFIELD_GEN2004_ORIGAGENT_ERROR = "originalAgentCode";
	public static final String UIMSG_GEN2004_ORIGAGENT_ERROR = "Unable to create an original agent Error";
	public static final String UIFIELD_GEN2004_ORIGAGENT_WARN = "originalAgentCode";
	public static final String UIMSG_GEN2004_ORIGAGENT_WARN = "Unable to create an original agent Warning";

	public static final String EXCEPCODE_LIFT1006 = "LIFT1006";
	public static final String EXCEPCODE_LIFT1006_PARAM_1 = "Airport Code";
	public static final String EXCEPCODE_LIFT1006_PARAM_2 = "File Name";
	public static final String UIFIELD_LIFT1006_FRMAIRPORT_ERROR = "fromAirport";
	public static final String UIMSG_LIFT1006_FRMAIRPORT_ERROR = "Invalid From Airport Error";
	public static final String UIFIELD_LIFT1006_FRMAIRPORT_WARN = "fromAirport";
	public static final String UIMSG_LIFT1006_FRMAIRPORT_WARN = "Invalid From Airport Warning";
	public static final String UIFIELD_LIFT1006_TOAIRPORT_ERROR = "toAirport";
	public static final String UIMSG_LIFT1006_TOAIRPORT_ERROR = "Invalid To Airport Error";
	public static final String UIFIELD_LIFT1006_TOAIRPORT_WARN = "toAirport";
	public static final String UIMSG_LIFT1006_TOAIRPORT_WARN = "Invalid To Airport Warning";

}
