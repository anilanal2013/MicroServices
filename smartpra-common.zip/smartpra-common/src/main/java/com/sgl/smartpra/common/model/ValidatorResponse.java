package com.sgl.smartpra.common.model;

import java.io.Serializable;

public class ValidatorResponse implements Serializable{

	protected String fieldName;
	protected String fieldValue;
	protected String fieldErrorMessage;
	
	
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	public String getFieldErrorMessage() {
		return fieldErrorMessage;
	}
	public void setFieldErrorMessage(String fieldErrorMessage) {
		this.fieldErrorMessage = fieldErrorMessage;
	}
	
	
	
	
}
