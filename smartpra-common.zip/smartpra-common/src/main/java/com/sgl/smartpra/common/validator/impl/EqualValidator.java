package com.sgl.smartpra.common.validator.impl;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.logging.log4j.util.Strings;

import com.sgl.smartpra.common.validator.Equal;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class EqualValidator implements ConstraintValidator<Equal, Object> {

	private static final String DIFF = "DIFF";
	private static final String SUM = "SUM";
	private String baseField;
	private String[] subfields;
	private String subfieldsOperation;

	@Override
	public void initialize(Equal constraint) {
		baseField = constraint.baseField();
		subfields = constraint.subfields();
		subfieldsOperation = constraint.subfieldsOperation();
	}

	@Override
	public boolean isValid(Object object, ConstraintValidatorContext context) {
		boolean valid = false;
		try {

			if (subfieldsOperation.isEmpty()) {
				valid = checkStringsEqual(object);
			} else {
				valid = checkNumbersEqual(object);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return valid;
	}

	private boolean checkNumbersEqual(Object object) throws Exception {
		boolean valid;
		Double baseFieldValue = convertToDouble(
				getFieldValue(object, baseField));
		Double value = 0.0;
		if (subfieldsOperation.equals(SUM)) {
			value = sum(object);
		} else if (subfieldsOperation.equals(DIFF)) {
			value = difference(object);
		}
		valid = baseFieldValue != null && baseFieldValue.equals(value);
		return valid;
	}

	private boolean checkStringsEqual(Object object) throws Exception {
		boolean valid;
		String baseFieldValue = String
				.valueOf(getFieldValue(object, baseField));
		String subFieldValue = Arrays.asList(subfields).stream().map(st -> {
			String matchFieldValue = Strings.EMPTY;
			try {
				matchFieldValue = String.valueOf(getFieldValue(object, st));
			} catch (Exception e) {
				log.error(e.getMessage());
				return Strings.EMPTY;
			}
			return matchFieldValue;
		}).collect(Collectors.joining());
		valid = Objects.nonNull(baseFieldValue)
				&& baseFieldValue.equals(subFieldValue);
		return valid;
	}

	private Double sum(Object object) {
		Double value = Arrays.asList(subfields).stream().map(st -> {
			Double matchFieldValue = 0d;
			try {
				matchFieldValue = convertToDouble(getFieldValue(object, st));
			} catch (Exception e) {
				log.error(e.getMessage());
				return 0.0;
			}
			return matchFieldValue;
		}).reduce(0d, (subtotal, element) -> subtotal
				+ (element.isNaN() ? 0d : element));
		return value;
	}

	private Double difference(Object object) {
		Double value = Arrays.asList(subfields).stream().map(st -> {
			Double matchFieldValue = 0d;
			try {
				matchFieldValue = convertToDouble(getFieldValue(object, st));
			} catch (Exception e) {
				log.error(e.getMessage());
				return 0.0;
			}
			return matchFieldValue;
		}).reduce(0d, (subtotal, element) -> Math.abs(subtotal)
				- (element.isNaN() ? 0d : element));
		return value;
	}

	private Double convertToDouble(Object object) {
		Double value = 0d;
		if (object != null) {
			value = Double.valueOf(String.valueOf(object).replace(",", ""));
		}
		return value;
	}
	private Object getFieldValue(Object object, String fieldName)
			throws Exception {
		Class<?> clazz = null;
		Method method = null;
		String[] fieldNames = fieldName.split("\\.");
		for(String fn : fieldNames) {
			clazz = object.getClass();
			if(clazz.getName().equals("java.util.Optional")){
				method = clazz.getDeclaredMethod("get");
				method.setAccessible(true);
				object = method.invoke(object);
				clazz = object.getClass();
			}
			fn=fn.substring(0, 1).toUpperCase()+fn.substring(1);
			method = clazz.getDeclaredMethod("get"+fn);
			method.setAccessible(true);
			object = method.invoke(object);
			if(Objects.isNull(object)) {
				break;
			}
		}
		if(Objects.nonNull(object)) {
			clazz = object.getClass();
			if(clazz.getName().equals("java.util.Optional")){
				method = clazz.getDeclaredMethod("get");
				method.setAccessible(true);
				object = method.invoke(object);
				clazz = object.getClass();
			}
		}
		return object;
	}

}