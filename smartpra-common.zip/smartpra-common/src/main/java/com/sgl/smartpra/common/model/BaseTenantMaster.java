package com.sgl.smartpra.common.model;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

/*
 * Base class for all client (tenant) specific master
 */
public class BaseTenantMaster extends BaseMaster {

	@Null(message = "clientId is not a valid input", groups = { Create.class, Update.class })
	protected String clientId;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

}
