package com.sgl.smartpra.common.validator;

import java.util.regex.Pattern;

public class StringValidatorUtils {

	private static final String VALIDEMAILIDPATTERN = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

	private static final String VALIDEMAILIDMSG = "Please provide valid email ID ";

	public static boolean  validateEmailId(String email) {
		boolean isValid = false;
		if (email != null) {
			if (Pattern.compile(VALIDEMAILIDPATTERN).matcher(email).find()) {
				return true;
			} else {
				return false;
			}

		}
		return isValid;
	}

}
