package com.sgl.smartpra.common.validator.impl;

import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.util.StringUtils;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;

import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to validate Mandatory Element's not empty
 * 
 * @author rajanand1
 *
 */
@Slf4j
public class RequiredNotEmptyValidator implements ConstraintValidator<RequiredNotEmpty, Optional<?>> {

	@Override
	public boolean isValid(Optional<?> value, ConstraintValidatorContext context) {
		if (OptionalUtil.isPresent(value)) {
			log.info("{}", value);
			if (OptionalUtil.getValue(value) instanceof String) {
				return StringUtils.hasText((String) OptionalUtil.getValue(value));
			} else {
				return true;
			}
		}
		return false;
	}

}
