package com.sgl.smartpra.common.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.common.model.ValidatorResponse;
import com.sgl.smartpra.common.validator.group.BatchValidate;


@Component
public class EntityValidator implements ValidationFramework  {
	
	private static Logger log = LoggerFactory.getLogger(EntityValidator.class);
	
	@Override
	public List<ValidatorResponse> validateEntity(Object obj) {
		return validateConstraints(obj);
		
	}
	
	public List<ValidatorResponse> validateConstraints(Object obj) {
		
		
		List<ValidatorResponse> validatorResponseList=new ArrayList<>();
		
		List<String> listString = new ArrayList<>();
		
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		
		Set<ConstraintViolation<Object>> constraintViolations = validator
				.validate(obj, BatchValidate.class);
		
		if (!constraintViolations.isEmpty()) {
			for (ConstraintViolation<Object> cv : constraintViolations) {
				log.info(String.format("Error here! property: [%s], value: [%s], message: [%s]",
						cv.getPropertyPath(), cv.getInvalidValue(), cv.getMessage()));
				ValidatorResponse validatorResponse=new ValidatorResponse();
				validatorResponse.setFieldName(cv.getPropertyPath().toString());
				if(cv.getInvalidValue() == null)
					validatorResponse.setFieldValue("null");
				else
					validatorResponse.setFieldValue(cv.getInvalidValue().toString());
				validatorResponse.setFieldErrorMessage(cv.getMessage());
				listString.add(cv.getPropertyPath()+","+ cv.getInvalidValue()+","+ cv.getMessage());
				validatorResponseList.add(validatorResponse);
			}
		}
		
		return validatorResponseList;
	}

}
