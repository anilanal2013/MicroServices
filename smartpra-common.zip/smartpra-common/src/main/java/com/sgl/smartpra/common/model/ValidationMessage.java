package com.sgl.smartpra.common.model;

public class ValidationMessage {

	// hide public constructor
	private ValidationMessage() {
		super();
	}

	public static final String CREATED_BY_REQUIRED = "Please provide created by";
	public static final String CREATED_BY_LENGTH = "Created By should be minimum of 1 and maximum of 15 characters";
	public static final String CREATED_BY_INVALID = "Created By is not a valid input";
	public static final String CREATED_DATE_INVALID = "CreatedDate is not a valid input";

	public static final String LAST_UPDATED_BY_REQUIRED = "Please provide last updated by";
	public static final String LAST_UPDATED_BY_LENGTH = "Last Updated By should be minimum of 1 and maximum of 15 characters";
	public static final String LAST_UPDATED_BY_INVALID = "Last updated by is not a valid input";
	public static final String LAST_UPDATED_DATE_INVALID = "Last UpdatedDate is not a valid input";

	public static final String IS_ACTIVE_INVALID = "isActive is not a valid input";
	public static final String CLIENT_ID_INVALID = "clientId is not a valid input";

}
