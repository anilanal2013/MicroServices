package com.sgl.smartpra.common.validator.impl;

import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.validator.Range;

/**
 * This class is used to validate range for the provided element
 * 
 * @author rajanand1
 *
 */
public class RangeValidator implements ConstraintValidator<Range, Optional<Integer>> {

	private int min;

	private int max;

	@Override
	public void initialize(Range constraintAnnotation) {
		this.min = constraintAnnotation.min();
		this.max = constraintAnnotation.max();
	}

	@Override
	public boolean isValid(Optional<Integer> value, ConstraintValidatorContext context) {
		if (!OptionalUtil.isNotNull(value)) {
			return true;
		} else if (OptionalUtil.isEmpty(value)) {
			return false;
		} else {
			return OptionalUtil.getValue(value) >= min && OptionalUtil.getValue(value) <= max;
		}

	}

}
