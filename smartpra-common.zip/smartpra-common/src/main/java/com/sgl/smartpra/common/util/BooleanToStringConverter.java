package com.sgl.smartpra.common.util;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.springframework.util.StringUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to convert the provided Boolean object value to
 * corresponding String (Single Character) value. True equals "Y" and false
 * equals "N".
 * 
 * @author rajanand1
 *
 */
@Converter
@Slf4j
public class BooleanToStringConverter implements AttributeConverter<Boolean, String> {

	private static final String YES = "Y";

	private static final String NO = "N";

	@Override
	public String convertToDatabaseColumn(Boolean value) {
		return (value != null && value) ? YES : NO;
	}

	@Override
	public Boolean convertToEntityAttribute(String value) {
		if (StringUtils.hasText(value)) {
			return YES.equals(value);
		} else {
			return null;
		}

	}
}