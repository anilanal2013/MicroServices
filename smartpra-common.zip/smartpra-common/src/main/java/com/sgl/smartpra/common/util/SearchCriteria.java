package com.sgl.smartpra.common.util;

import java.util.List;
import java.util.Map;

import com.sgl.smartpra.common.model.KeyValue;

public class SearchCriteria {

	private String key;
	private String operation;
	private Object value;
	private List<KeyValue> extraValues; 
	
	public SearchCriteria() {
		super();
	}

	public SearchCriteria(String key, String operation, Object value) {
		super();
		this.key = key;
		this.operation = operation;
		this.value = value;
	}
	
	public SearchCriteria(String key, String operation, Object value, List<KeyValue> extraValues) {
		super();
		this.key = key;
		this.operation = operation;
		this.value = value;
		this.extraValues = extraValues;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public List<KeyValue> getExtraValues() {
		return extraValues;
	}

	public void setExtraValues(List<KeyValue> extraValues) {
		this.extraValues = extraValues;
	}

}
