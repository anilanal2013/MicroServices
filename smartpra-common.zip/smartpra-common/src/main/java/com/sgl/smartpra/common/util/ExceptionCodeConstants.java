package com.sgl.smartpra.common.util;

public class ExceptionCodeConstants {

	public static final String ERRORCODE_DOCTYPE="GEN1102";

	public static final String ERRORCODE_DOCCLASS="SALE1003";
	
	
	public static final String ERRORCODE_AGENCYMASTER="LIFT4002";
	
	public static final String ERRORCODE_INCORRECTDATA="LIFT1003";

	public static final String ERRORCODE_FLIGHTKEYNOTFOUND="LIFT1010";
	
	public static final String ERRORCODE_FLIGHTNOTFOUND="LIFT1008";
	
	public static final String ERRORCODE_INVALIDCARRIERCODE="GEN1106";
	
	public static final String GENERAL_EXCEPTION="LIFT3006";
	
	public static final String ERRORCODE_REQUEST_DATA_PRESENT="LIFT3001";
	
	public static final String ERRORCODE_DATA_NOT_POPULATED="LIFT3003";
	
	public static final String ERRORCODE_WRONG_FILE="LIFT1021";
	
	public static final String EXCEPTION_TYPE_ERROR="E";

}
