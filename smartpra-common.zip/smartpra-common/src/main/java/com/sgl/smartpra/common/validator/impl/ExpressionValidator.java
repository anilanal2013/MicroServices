package com.sgl.smartpra.common.validator.impl;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.expression.EvaluationContext;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import com.sgl.smartpra.common.validator.Expression;

public class ExpressionValidator implements ConstraintValidator<Expression, Object> {

	private String exp;

	ExpressionParser parser = new SpelExpressionParser();

	@Override
	public void initialize(Expression expression) {
		exp = expression.exp();
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		EvaluationContext evaluationContext = new StandardEvaluationContext(value);
		return (boolean) parser.parseExpression(exp).getValue(evaluationContext);
		// return MVEL.evalToBoolean(mvelExp, value);
	}

}
