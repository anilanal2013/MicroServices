package com.sgl.smartpra.common.validator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.sgl.smartpra.common.validator.impl.OptionalNotEmptyValidator;

/**
 * This Annotation interface is used to validate optional elements. If the
 * element is provided in the json, then cannot be null or empty
 * 
 * @author rajanand1
 *
 */
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = OptionalNotEmptyValidator.class)
@Documented
public @interface OptionalNotEmpty {

	String message() default "Cannot be Null or Empty when provided";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

}
