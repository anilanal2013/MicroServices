package com.sgl.smartpra.common.model;

import javax.validation.constraints.Null;

import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

/*
 * Base class for all client (tenant) specific master parent
 * this will have additionally isActive
 */
public class BaseTenantMasterParent extends BaseTenantMaster {

	@Null(message = "isActive is not a valid input", groups = { Create.class, Update.class })
	protected Boolean isActive;

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

}
