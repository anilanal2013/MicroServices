package com.sgl.smartpra.common.searchdao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.sgl.smartpra.common.util.SearchCriteria;

public abstract class CommonSearchDao<T> {

	@PersistenceContext
	private EntityManager entityManager;

	public List<? extends Object> search(final List<SearchCriteria> params, Object entity) {
		final CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		final CriteriaQuery<? extends Object> query = builder.createQuery(entity.getClass());
		final Root<? extends Object> root = query.from(entity.getClass());

		Predicate predicate = builder.conjunction();

		for (final SearchCriteria param : params) {
			if (param.getOperation().equalsIgnoreCase(">")) {
				predicate = builder.and(predicate,
						builder.greaterThan(root.get(param.getKey()), param.getValue().toString()));
			} else if (param.getOperation().equalsIgnoreCase("<")) {
				predicate = builder.and(predicate,
						builder.lessThan(root.get(param.getKey()), param.getValue().toString()));
			} else if (param.getOperation().equalsIgnoreCase(">=")) {
				if (root.get(param.getKey()).getJavaType() == Date.class)
					predicate = builder.and(predicate, builder.greaterThanOrEqualTo(root.get(param.getKey()),
							"convert(datetime," + param.getValue().toString() + ")"));
				else
					predicate = builder.and(predicate,
							builder.greaterThanOrEqualTo(root.get(param.getKey()), param.getValue().toString()));
			} else if (param.getOperation().equalsIgnoreCase("<=")) {
				if (root.get(param.getKey()).getJavaType() == Date.class)
					predicate = builder.and(predicate, builder.lessThanOrEqualTo(root.get(param.getKey()),
							"convert(datetime," + param.getValue().toString() + ")"));
				else
					predicate = builder.and(predicate,
							builder.lessThanOrEqualTo(root.get(param.getKey()), param.getValue().toString()));
			} else if (param.getOperation().equalsIgnoreCase("=")) {
				if (root.get(param.getKey()).getJavaType() == Boolean.class)
					predicate = builder.and(predicate, builder.equal(root.get(param.getKey()), param.getValue()));
				else
					predicate = builder.and(predicate,
							builder.equal(root.get(param.getKey()), param.getValue().toString()));
			} else if (param.getOperation().equalsIgnoreCase(":")) {
				if (root.get(param.getKey()).getJavaType() == String.class) {
					predicate = builder.and(predicate,
							builder.like(root.get(param.getKey()), param.getValue() + "%"));
				} else {
					predicate = builder.and(predicate, builder.equal(root.get(param.getKey()), param.getValue()));
				}
			}
			else if (param.getOperation().equalsIgnoreCase("||:")) {
				if (root.get(param.getKey()).getJavaType() == String.class) {
					predicate = builder.or(predicate,
							builder.like(root.get(param.getKey()), param.getValue() + "%"));
				} else {
					predicate = builder.and(predicate, builder.equal(root.get(param.getKey()), param.getValue()));
				}
			}
			
			
		}
		query.where(predicate);

		return entityManager.createQuery(query).getResultList();

	}
	
	
	
	public Object searchObject(final List<SearchCriteria> params, Object entity) {
		final CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		final CriteriaQuery<? extends Object> query = builder.createQuery(entity.getClass());
		final Root<? extends Object> root = query.from(entity.getClass());

		Predicate predicate = builder.conjunction();

		for (final SearchCriteria param : params) {
			if (param.getOperation().equalsIgnoreCase(">")) {
				predicate = builder.and(predicate,
						builder.greaterThan(root.get(param.getKey()), param.getValue().toString()));
				
			} else if (param.getOperation().equalsIgnoreCase("<")) {
				predicate = builder.and(predicate,
						builder.lessThan(root.get(param.getKey()), param.getValue().toString()));
			} else if (param.getOperation().equalsIgnoreCase(">=")) {
				if (root.get(param.getKey()).getJavaType() == Date.class)
					predicate = builder.and(predicate, builder.greaterThanOrEqualTo(root.get(param.getKey()),
							"convert(datetime," + param.getValue().toString() + ")"));
				else
					predicate = builder.and(predicate,
							builder.greaterThanOrEqualTo(root.get(param.getKey()), param.getValue().toString()));
			} else if (param.getOperation().equalsIgnoreCase("<=")) {
				if (root.get(param.getKey()).getJavaType() == Date.class)
					predicate = builder.and(predicate, builder.lessThanOrEqualTo(root.get(param.getKey()),
							"convert(datetime," + param.getValue().toString() + ")"));
				else
					predicate = builder.and(predicate,
							builder.lessThanOrEqualTo(root.get(param.getKey()), param.getValue().toString()));
			} else if (param.getOperation().equalsIgnoreCase("=")) {
				if (root.get(param.getKey()).getJavaType() == Boolean.class)
					predicate = builder.and(predicate, builder.equal(root.get(param.getKey()), param.getValue()));
				else
					predicate = builder.and(predicate,
							builder.equal(root.get(param.getKey()), param.getValue().toString()));
			} else if (param.getOperation().equalsIgnoreCase(":")) {
				if (root.get(param.getKey()).getJavaType() == String.class) {
					predicate = builder.and(predicate,
							builder.like(root.get(param.getKey()), "%" + param.getValue() + "%"));
				} else {
					predicate = builder.and(predicate, builder.equal(root.get(param.getKey()), param.getValue()));
				}
			}
			else if (param.getOperation().equalsIgnoreCase("||:")) {
				if (root.get(param.getKey()).getJavaType() == String.class) {
					predicate = builder.or(predicate,
							builder.like(root.get(param.getKey()), "%" + param.getValue() + "%"));
				} else {
					predicate = builder.and(predicate, builder.equal(root.get(param.getKey()), param.getValue()));
				}
			}
			
		}
		query.where(predicate);
		return entityManager.createQuery(query).getResultList()
				.stream().findFirst();

	}
}
