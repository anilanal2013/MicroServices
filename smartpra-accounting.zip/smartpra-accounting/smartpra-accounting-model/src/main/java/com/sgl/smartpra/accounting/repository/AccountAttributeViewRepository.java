package com.sgl.smartpra.accounting.repository;

import com.sgl.smartpra.accounting.entity.AccountAttributeViewEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountAttributeViewRepository extends JpaRepository<AccountAttributeViewEntity,Long> {

    List<AccountAttributeViewEntity> findByScenarioNumber(Integer scenarioNumber);

	List<AccountAttributeViewEntity> findByScenarioNumberAndClientId(Integer scenarioNumber, String clientId);
}
