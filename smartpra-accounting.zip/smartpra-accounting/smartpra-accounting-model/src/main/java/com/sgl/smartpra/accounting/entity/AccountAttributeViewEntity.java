package com.sgl.smartpra.accounting.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Data
@Table(name = "account_attribute_view", schema = "dbo")
public class AccountAttributeViewEntity {

    public AccountAttributeViewEntity() {

    }

    @Id
    private Long id;
    
    @Column(name="scenario_number")
    private Integer scenarioNumber;

    @Column(name="account_alpha_code")
    private String accountAlphaCode;

    @Column(name="account_alpha_code_id")
    private Integer accountAlphaCodeId;

    @Column(name="account_definition_identifier")
    private Integer accountDefinitionIdentifier;

    @Column(name="account_description")
    private String accountDescription;

    @Column(name="account_num_code")
    private String accountNumCode;

    @Column(name="account_type")
    private String accountType;

    @Column(name="accounting_attributes_1")
    private String accountingAttributes1;

    @Column(name="accounting_attributes_10")
    private String accountingAttributes10;

    @Column(name="accounting_attributes_11")
    private String accountingAttributes11;

    @Column(name="accounting_attributes_12")
    private String accountingAttributes12;

    @Column(name="accounting_attributes_13")
    private String accountingAttributes13;

    @Column(name="accounting_attributes_14")
    private String accountingAttributes14;

    @Column(name="accounting_attributes_15")
    private String accountingAttributes15;

    @Column(name="accounting_attributes_16")
    private String accountingAttributes16;

    @Column(name="accounting_attributes_17")
    private String accountingAttributes17;

    @Column(name="accounting_attributes_18")
    private String accountingAttributes18;

    @Column(name="accounting_attributes_19")
    private String accountingAttributes19;

    @Column(name="accounting_attributes_2")
    private String accountingAttributes2;

    @Column(name="accounting_attributes_20")
    private String accountingAttributes20;

    @Column(name="accounting_attributes_3")
    private String accountingAttributes3;

    @Column(name="accounting_attributes_4")
    private String accountingAttributes4;

    @Column(name="accounting_attributes_5")
    private String accountingAttributes5;

    @Column(name="accounting_attributes_6")
    private String accountingAttributes6;

    @Column(name="accounting_attributes_7")
    private String accountingAttributes7;

    @Column(name="accounting_attributes_8")
    private String accountingAttributes8;

    @Column(name="accounting_attributes_9")
    private String accountingAttributes9;

    @Column(name="accounting_attributes_master_1")
    private String accountingAttributesMaster1;

    @Column(name="accounting_attributes_master_10")
    private String accountingAttributesMaster10;

    @Column(name="accounting_attributes_master_11")
    private String accountingAttributesMaster11;

    @Column(name="accounting_attributes_master_12")
    private String accountingAttributesMaster12;

    @Column(name="accounting_attributes_master_13")
    private String accountingAttributesMaster13;

    @Column(name="accounting_attributes_master_14")
    private String accountingAttributesMaster14;

    @Column(name="accounting_attributes_master_15")
    private String accountingAttributesMaster15;

    @Column(name="accounting_attributes_master_16")
    private String accountingAttributesMaster16;

    @Column(name="accounting_attributes_master_17")
    private String accountingAttributesMaster17;

    @Column(name="accounting_attributes_master_18")
    private String accountingAttributesMaster18;

    @Column(name="accounting_attributes_master_19")
    private String accountingAttributesMaster19;

    @Column(name="accounting_attributes_master_2")
    private String accountingAttributesMaster2;

    @Column(name="accounting_attributes_master_20")
    private String accountingAttributesMaster20;

    @Column(name="accounting_attributes_master_3")
    private String accountingAttributesMaster3;

    @Column(name="accounting_attributes_master_4")
    private String accountingAttributesMaster4;

    @Column(name="accounting_attributes_master_5")
    private String accountingAttributesMaster5;

    @Column(name="accounting_attributes_master_6")
    private String accountingAttributesMaster6;

    @Column(name="accounting_attributes_master_7")
    private String accountingAttributesMaster7;

    @Column(name="accounting_attributes_master_8")
    private String accountingAttributesMaster8;

    @Column(name="accounting_attributes_master_9")
    private String accountingAttributesMaster9;

    @Column(name="accounting_transaction_id")
    private Integer accountingTransactionId;

    @Column(name="ancillary_service")
    private String ancillaryService;

    @Column(name="attribute_1")
    private String attribute1;

    @Column(name="attribute_10")
    private String attribute10;

    @Column(name="attribute_11")
    private String attribute11;

    @Column(name="attribute_12")
    private String attribute12;

    @Column(name="attribute_13")
    private String attribute13;

    @Column(name="attribute_14")
    private String attribute14;

    @Column(name="attribute_15")
    private String attribute15;

    @Column(name="attribute_16")
    private String attribute16;

    @Column(name="attribute_17")
    private String attribute17;

    @Column(name="attribute_18")
    private String attribute18;

    @Column(name="attribute_19")
    private String attribute19;

    @Column(name="attribute_2")
    private String attribute2;

    @Column(name="attribute_20")
    private String attribute20;

    @Column(name="attribute_3")
    private String attribute3;

    @Column(name="attribute_4")
    private String attribute4;

    @Column(name="attribute_5")
    private String attribute5;

    @Column(name="attribute_6")
    private String attribute6;

    @Column(name="attribute_7")
    private String attribute7;

    @Column(name="attribute_8")
    private String attribute8;

    @Column(name="attribute_9")
    private String attribute9;

    @Column(name="attribute_validation_indicator_1")
    private String attributeValidationIndicator1;

    @Column(name="attribute_validation_indicator_10")
    private String attributeValidationIndicator10;

    @Column(name="attribute_validation_indicator_11")
    private String attributeValidationIndicator11;

    @Column(name="attribute_validation_indicator_12")
    private String attributeValidationIndicator12;

    @Column(name="attribute_validation_indicator_13")
    private String attributeValidationIndicator13;

    @Column(name="attribute_validation_indicator_14")
    private String attributeValidationIndicator14;

    @Column(name="attribute_validation_indicator_15")
    private String attributeValidationIndicator15;

    @Column(name="attribute_validation_indicator_16")
    private String attributeValidationIndicator16;

    @Column(name="attribute_validation_indicator_17")
    private String attributeValidationIndicator17;

    @Column(name="attribute_validation_indicator_18")
    private String attributeValidationIndicator18;

    @Column(name="attribute_validation_indicator_19")
    private String attributeValidationIndicator19;

    @Column(name="attribute_validation_indicator_2")
    private String attributeValidationIndicator2;

    @Column(name="attribute_validation_indicator_20")
    private String attributeValidationIndicator20;

    @Column(name="attribute_validation_indicator_3")
    private String attributeValidationIndicator3;

    @Column(name="attribute_validation_indicator_4")
    private String attributeValidationIndicator4;

    @Column(name="attribute_validation_indicator_5")
    private String attributeValidationIndicator5;

    @Column(name="attribute_validation_indicator_6")
    private String attributeValidationIndicator6;

    @Column(name="attribute_validation_indicator_7")
    private String attributeValidationIndicator7;

    @Column(name="attribute_validation_indicator_8")
    private String attributeValidationIndicator8;

    @Column(name="attribute_validation_indicator_9")
    private String attributeValidationIndicator9;

    @Column(name="balance_flag")
    private String balanceFlag;

    @Column(name="bsp_agent_flag")
    private String bspAgentFlag;

    @Column(name="charge_cat_code")
    private String chargeCatCode;

    @Column(name="charge_code")
    private String chargeCode;

    @Column(name="client_id")
    private String clientId;

    @Column(name="component_identifier")
    private String componentIdentifier;

    @Column(name="conversion_date_use")
    private String conversionDateUse;

    @Column(name="debit_credit_indicator")
    private String debitCreditIndicator;

    @Column(name="delivering_carrier_indicator")
    private String deliveringCarrierIndicator;

    @Column(name="doc_type")
    private String docType;

    @Column(name="effective_from_date")
    private Date effectiveFromDate;

    @Column(name="effective_to_date")
    private Date effectiveToDate;

    @Column(name="fop_type")
    private String fopType;

    @Column(name="invoice_type")
    private String invoiceType;

    @Column(name="is_active")
    private String isActive;

    @Column(name="misc_document_issued_for")
    private String miscDocumentIssuedFor;

    @Column(name="misc_document_util_type")
    private String miscDocumentUtilType;

    @Column(name="module")
    private String module;

    @Column(name="pre_implementation_indicator")
    private String preImplementationIndicator;

    @Column(name="prime_reissue_indicator")
    private String primeReissueIndicator;

    @Column(name="provisional_account_code")
    private String provisionalAccountCode;

    @Column(name="receiving_carrier_indicator")
    private String receivingCarrierIndicator;

    @Column(name="rejection_memo_type")
    private String rejectionMemoType;

    @Column(name="sales_exist_indicator")
    private String salesExistIndicator;

    @Column(name="self_oal_indicator")
    private String selfOalIndicator;

    @Column(name="source_code")
    private Integer sourceCode;

    @Column(name="transaction_serial_no")
    private Integer transactionSerialNo;

    @Column(name="transaction_type")
    private String transactionType;
}
