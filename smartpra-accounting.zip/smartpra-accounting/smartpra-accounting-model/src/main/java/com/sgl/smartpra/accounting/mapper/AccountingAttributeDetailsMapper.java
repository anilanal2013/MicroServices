package com.sgl.smartpra.accounting.mapper;

import com.sgl.smartpra.accounting.entity.AccountingAttributeDetailsEntity;
import com.sgl.smartpra.accounting.model.AccountingAttributeDetails;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AccountingAttributeDetailsMapper extends BaseMapper<AccountingAttributeDetails, AccountingAttributeDetailsEntity> {

}
