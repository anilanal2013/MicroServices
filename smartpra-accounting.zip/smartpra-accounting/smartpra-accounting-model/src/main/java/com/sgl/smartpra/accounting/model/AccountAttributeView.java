package com.sgl.smartpra.accounting.model;

import lombok.Data;

import java.util.Date;




@Data
public class AccountAttributeView  {

    public AccountAttributeView(){

    }

    private Integer scenarioNumber;

    private String accountAlphaCode;

    private Integer accountAlphaCodeId;

    private Integer accountDefinitionIdentifier;

    private String accountDescription;

    private String accountNumCode;

    private String accountType;

    private String accountingAttributes1;

    private String accountingAttributes10;

    private String accountingAttributes11;

    private String accountingAttributes12;

    private String accountingAttributes13;

    private String accountingAttributes14;

    private String accountingAttributes15;

    private String accountingAttributes16;

    private String accountingAttributes17;

    private String accountingAttributes18;

    private String accountingAttributes19;

    private String accountingAttributes2;

    private String accountingAttributes20;

    private String accountingAttributes3;

    private String accountingAttributes4;

    private String accountingAttributes5;

    private String accountingAttributes6;

    private String accountingAttributes7;

    private String accountingAttributes8;

    private String accountingAttributes9;

    private String accountingAttributesMaster1;

    private String accountingAttributesMaster10;

    private String accountingAttributesMaster11;

    private String accountingAttributesMaster12;

    private String accountingAttributesMaster13;

    private String accountingAttributesMaster14;

    private String accountingAttributesMaster15;

    private String accountingAttributesMaster16;

    private String accountingAttributesMaster17;

    private String accountingAttributesMaster18;

    private String accountingAttributesMaster19;

    private String accountingAttributesMaster2;

    private String accountingAttributesMaster20;

    private String accountingAttributesMaster3;

    private String accountingAttributesMaster4;

    private String accountingAttributesMaster5;

    private String accountingAttributesMaster6;

    private String accountingAttributesMaster7;

    private String accountingAttributesMaster8;

    private String accountingAttributesMaster9;

    private Integer accountingTransactionId;

    private String ancillaryService;

    private String attribute1;

    private String attribute10;

    private String attribute11;

    private String attribute12;

    private String attribute13;

    private String attribute14;

    private String attribute15;

    private String attribute16;

    private String attribute17;

    private String attribute18;

    private String attribute19;

    private String attribute2;

    private String attribute20;

    private String attribute3;

    private String attribute4;

    private String attribute5;

    private String attribute6;

    private String attribute7;

    private String attribute8;

    private String attribute9;

    private String attributeValidationIndicator1;

    private String attributeValidationIndicator10;

    private String attributeValidationIndicator11;

    private String attributeValidationIndicator12;

    private String attributeValidationIndicator13;

    private String attributeValidationIndicator14;

    private String attributeValidationIndicator15;

    private String attributeValidationIndicator16;

    private String attributeValidationIndicator17;

    private String attributeValidationIndicator18;

    private String attributeValidationIndicator19;

    private String attributeValidationIndicator2;

    private String attributeValidationIndicator20;

    private String attributeValidationIndicator3;

    private String attributeValidationIndicator4;

    private String attributeValidationIndicator5;

    private String attributeValidationIndicator6;

    private String attributeValidationIndicator7;

    private String attributeValidationIndicator8;

    private String attributeValidationIndicator9;

    private String balanceFlag;

    private String bspAgentFlag;

    private String chargeCatCode;

    private String chargeCode;

    private String clientId;

    private String componentIdentifier;

    private String conversionDateUse;

    private String debitCreditIndicator;

    private String deliveringCarrierIndicator;

    private String docType;

    private Date effectiveFromDate;

    private Date effectiveToDate;

    private String fopType;

    private String invoiceType;

    private String isActive;

    private String miscDocumentIssuedFor;

    private String miscDocumentUtilType;

    private String module;

    private String preImplementationIndicator;

    private String primeReissueIndicator;

    private String provisionalAccountCode;

    private String receivingCarrierIndicator;

    private String rejectionMemoType;

    private String salesExistIndicator;

    private String selfOalIndicator;

    private Integer sourceCode;

    private Integer transactionSerialNo;

    private String transactionType;
}
