package com.sgl.smartpra.accounting.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * 
 * @author lsivak1
 *
 */
@Entity
@Table(name = "accounting_transaction",schema = "SmartPRAAccounting")
@DynamicInsert
@DynamicUpdate
@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingTransactionEntity  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "accounting_txn_id")
	private Integer accountingTxnId;

	@Column(name = "client_id", length = 2)
	private String  clientId; 

	@Column(name = "module" )
	private String  module;
	
	@Column(name = "transaction_type", length = 5)
	private String  transactionType; 
	
	@Column(name = "request")
	private String  request;
	
	@Column(name = "dateofissue")
	private LocalDate dateOfIssue;
	
	@Column(name = "transissairline")
	private String  transIssAirline;
	
	@Column(name = "invoice_no")
	private String  invoiceNo;
	
	@Column(name = "status", length = 20)
	private String  status; 
	
	@Column(name = "status_desc", length = 50)
	private String  statusDesc;

	@Column(name = "created_by", nullable = false)
	@Length(min = 1, max = 15)
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "last_updated_by")
	@Length(min = 1, max = 15)
	private String lastUpdatedBy;

	@Column(name = "last_update_date")
	private LocalDateTime lastUpdatedDate;
	@Column(name = "scenario_number")
	private Integer scenarioNumber; 
	@Transient
	private Map<String, Object>batchKeyMap;
	@Transient
	private String invoiceLevel;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
