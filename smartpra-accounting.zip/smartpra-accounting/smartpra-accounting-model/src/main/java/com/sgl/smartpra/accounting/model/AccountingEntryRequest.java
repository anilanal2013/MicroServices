package com.sgl.smartpra.accounting.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingEntryRequest {

    List<AccountAttributeView> accountAttributeView;
    AccountingTransaction accountingTransaction;
}
