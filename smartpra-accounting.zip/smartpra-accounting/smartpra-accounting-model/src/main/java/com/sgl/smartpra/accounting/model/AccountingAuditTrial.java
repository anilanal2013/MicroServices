package com.sgl.smartpra.accounting.model;

import com.sgl.smartpra.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingAuditTrial extends BaseModel {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer accountingAuditTrialId;

    private String clienId;

    private String summarisationId;

    private String module;

    private String jvNumber;

    private String finYear;

    private String transIssAirline;

    private String transDocNumber;

    private String mainIssAirline;

    private String mainDocNumber;

    private String refIssuingCarrier;

    private String refDocumentNumber;

    private Integer couponNumber;

    private String documentUniqueId;

    private String orderId;

    private String pnr;

    private String docType;

    private LocalDate dateOfIssue;

    private String accountAlphaCode;

    private String accountDesciption;

    private String accountNumCode;

    private String transactionCurrency;

    private BigDecimal drAmtInTransactionCurrency;

    private BigDecimal crAmtInTransactionCurrency;

    private String baseCurrency;

    private BigDecimal debitAmountInBaseCurrency;

    private BigDecimal creditAmountInBaseCurrency;

    private String reportingCurrency;

    private BigDecimal drAmtInReportingCurrency;

    private BigDecimal crAmtInReportingCurrency;

    private BigDecimal conversionRate;

    private LocalDate conversionDate;

    private BigDecimal convRateReportingCurrency;

    private LocalDate convDateReportingCurrency;

    private LocalDate accountingDate;

    private String batchKey1;

    private String batchKey2;

    private String batchKey3;

    private String batchKey4;

    private LocalDate batchKey5;

    private LocalDate batchKey6;

    private String narration;

    private String accountingAttribute1;

    private String accountingAttribute2;

    private String accountingAttribute3;

    private String accountingAttribute4;

    private String accountingAttribute5;

    private String accountingAttribute6;

    private String accountingAttribute7;

    private String accountingAttribute8;

    private String accountingAttribute9;

    private String accountingAttribute10;

    private String accountingAttribute11;

    private String accountingAttribute12;

    private String accountingAttribute13;

    private String accountingAttribute14;

    private String accountingAttribute15;

    private String accountingAttribute16;

    private String accountingAttribute17;

    private String accountingAttribute18;

    private String accountingAttribute19;

    private String accountingAttribute20;

    private String memoNo;

    private Integer scenarioNumber;

    private Integer accountDefinitionIdentifier;

    private String reversalIndicator;

    private LocalDate monthClosedDate;

    private String erpResponseNumber;

    private String accountType;
}
