package com.sgl.smartpra.accounting.model;
import java.util.Optional;
import com.sgl.smartpra.common.model.BaseModel;
import com.sgl.smartpra.common.validator.OptionalFieldSize;
import com.sgl.smartpra.common.validator.OptionalNotEmpty;
import com.sgl.smartpra.common.validator.RequiredNotEmpty;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingTransactionModel extends BaseModel {
	private static final long serialVersionUID = 1L;

	private Integer accountingTransactionId;

	@RequiredNotEmpty(message = "Please provide Client Id", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@OptionalFieldSize(min = 1, max = 2, message = "Client Id should be minimum of 1 and maximum of 2 characters", groups = {
			Create.class, Update.class })
	private Optional<String> clientId;

	private Optional<Integer> scenarioNumber;

	@RequiredNotEmpty(message = "Please provide Transaction Serial No", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Integer> transactionSerialNo;

	private Optional<Integer> accountDefinitionIdentifier;

	@RequiredNotEmpty(message = "Please provide Account Alpha Code", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	@OptionalFieldSize(min = 1, max = 3, message = "Account Alpha Code should be minimum of 1 and maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> accountAlphaCode;

	@OptionalFieldSize(max = 3, message = "Provisional Account Code should be  maximum of 3 characters", groups = {
			Create.class, Update.class })
	private Optional<String> provisionalAccountCode;

	@OptionalFieldSize(max = 2, message = "Provisional Account Code should be  maximum of 2 characters", groups = {
			Create.class, Update.class })
	private Optional<String> debitCreditIndicator;

	@OptionalFieldSize(max = 1, message = "Balance Flag should be  maximum of 1 characters", groups = { Create.class,
			Update.class })
	private Optional<String> balanceFlag;

	@RequiredNotEmpty(message = "Please provide IsActive", groups = Create.class)
	@OptionalNotEmpty(groups = Update.class)
	private Optional<Boolean> isActive;
}
