
package com.sgl.smartpra.accounting.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.accounting.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author Siva Kumar
 *
 */
@DynamicInsert
@DynamicUpdate
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name="accounting_mapping", schema = "SmartPRAAccounting")
public class AccountingExtractMappingEntity extends BaseEntity {

	private static final long serialVersionUID = 3934210959390555186L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="acccounting_mapping_id")
	private Integer acccountingMappingId;

	@Column(name="client_id")
	private String clientId;

	@Column(name="module_id")
	private String moduleId;

	@Column(name="sequence_number")
	private int sequencenumber;

	@Column(name="key_val")
	private String keyval;

	@Column(name="value")
	private String value;

	@Column(name="data_type")
	private String datatype;

	@Column(name="format")
	private String format;

	@Column(name="from_datatype")
	private String fromdatatype;

	@Column(name="from_format")
	private String fromformat;

	@Column(name="default_value")
	private String defaultvalue;

	@Column(name="length")
	private int length;

	@Column(name="validation")
	private String validation;

	@Column(name="account_type")
	private String accounttype;

	@Column(name="is_active")
	private String isactive;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
