package com.sgl.smartpra.accounting.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Optional;

/**
 * 
 * @author lsivak1
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingMasterDetails {
	
	private Integer id;
	
	private Optional<String> accountMaster;
	
	private Optional<String> accountAttribute;
	
	private Optional<String> accountConstraintAttribute;
	
	private Optional<String> operator;
	
	private Integer sequence;
	
	private AccountingMasterMappingDetails mappingDetails;
	
	private Optional<String> isActive;

}
