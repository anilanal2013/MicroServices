package com.sgl.smartpra.accounting.mapper;

import com.sgl.smartpra.accounting.entity.AccountAttributeViewEntity;
import com.sgl.smartpra.accounting.model.AccountAttributeView;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AccountAttributeViewMapper extends BaseMapper<AccountAttributeView, AccountAttributeViewEntity> {

}
