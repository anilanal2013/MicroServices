package com.sgl.smartpra.accounting.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 
 * @author lsivak1
 *
 */

@Entity
@Table(name = "accounting_master_mapping_details",schema = "SmartPRAAccounting")
@DynamicInsert
@DynamicUpdate
@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingMasterMappingDetailsEntity extends BaseEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "account_master_mapping_master", length = 50)
	private String accountMasterMappingMaster;
	
	@Column(name = "account_master_mapping_attribute ", length = 50)
	private String accountMasterMappingAttribute;
	
	@Column(name = "account_master_mapping_condition ", length = 100)
	private String accountMasterMappingCondition;
	
	@Column(name = "is_active ", length = 1)
	private String isActive;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
