package com.sgl.smartpra.accounting.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountingMappingConfModel implements Serializable {

	private static final long serialVersionUID = 3934210959390555186L;
	
	private Integer acccountingMappingId;

	private String clientId;

	private String moduleId;

	private int sequencenumber;

	private String keyval;

	private String value;

	private String datatype;

	private String format;

	private String fromdatatype;

	private String fromformat;

	private String defaultvalue;

	private int length;

	private String validation;

	private String accounttype;

	private String isactive;

}
