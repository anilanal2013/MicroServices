package com.sgl.smartpra.accounting.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Optional;

/**
 * 
 * @author lsivak1
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingMasterMappingDetails {
	
	private Integer id;
	
	private Optional<String> accountMasterMappingMaster;
	
	private Optional<String> accountMasterMappingAttribute;
	
	private Optional<String> accountMasterMappingCondition;
	
	private Optional<String> isActive;

}
