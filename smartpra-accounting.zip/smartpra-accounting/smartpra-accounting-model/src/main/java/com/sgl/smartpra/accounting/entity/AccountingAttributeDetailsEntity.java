package com.sgl.smartpra.accounting.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 
 * @author lsivak1
 *
 */

@Entity
@Table(name = "accounting_attribute_details", schema = "SmartPRAAccounting")
@DynamicInsert
@DynamicUpdate
@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingAttributeDetailsEntity extends BaseEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "client_id", length = 3)
	private String clientId;

	@Column(name = "account_code_alpha", length = 2)
	private String accountCodeAlpha;

	@Column(name = "account_num_code", length = 50)
	private String accountNumCode;

	@Column(name = "account_description", length = 100)
	private String accountDescription;

	@Column(name = "component_identifier", length = 50)
	private String componentIdentifier;

	@Column(name = "scenario_number")
	private Integer scenarioNumber;

	@Column(name = "debit_credit_indicator", length = 2)
	private String debitCreditIndicator;

	@Column(name = "account_number", length = 100)
	private String accountNumber;

	@Column(name = "conversion_date_use", length = 100)
	private String conversionDateUse;

	@Column(name = "accounting_attributes_value_1", length = 50)
	private String accountingAttributesValue1;

	@Column(name = "accounting_attributes_value_2", length = 50)
	private String accountingAttributesValue2;

	@Column(name = "accounting_attributes_value_3", length = 50)
	private String accountingAttributesValue3;

	@Column(name = "accounting_attributes_value_4", length = 50)
	private String accountingAttributesValue4;

	@Column(name = "accounting_attributes_value_5", length = 50)
	private String accountingAttributesValue5;

	@Column(name = "accounting_attributes_value_6", length = 50)
	private String accountingAttributesValue6;

	@Column(name = "accounting_attributes_value_7", length = 50)
	private String accountingAttributesValue7;

	@Column(name = "accounting_attributes_value_8", length = 50)
	private String accountingAttributesValue8;

	@Column(name = "accounting_attributes_value_9", length = 50)
	private String accountingAttributesValue9;

	@Column(name = "accounting_attributes_value_10", length = 50)
	private String accountingAttributesValue10;

	@Column(name = "accounting_attributes_value_11", length = 50)
	private String accountingAttributesValue11;

	@Column(name = "accounting_attributes_value_12", length = 50)
	private String accountingAttributesValue12;

	@Column(name = "accounting_attributes_value_13", length = 50)
	private String accountingAttributesValue13;

	@Column(name = "accounting_attributes_value_14", length = 50)
	private String accountingAttributesValue14;

	@Column(name = "accounting_attributes_value_15", length = 50)
	private String accountingAttributesValue15;

	@Column(name = "accounting_attributes_value_16", length = 50)
	private String accountingAttributesValue16;

	@Column(name = "accounting_attributes_value_17", length = 50)
	private String accountingAttributesValue17;

	@Column(name = "accounting_attributes_value_18", length = 50)
	private String accountingAttributesValue18;

	@Column(name = "accounting_attributes_value_19", length = 50)
	private String accountingAttributesValue19;

	@Column(name = "accounting_attributes_value_20", length = 50)
	private String accountingAttributesValue20;

	@Column(name = "is_active ", length = 1)
	private String isActive;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
