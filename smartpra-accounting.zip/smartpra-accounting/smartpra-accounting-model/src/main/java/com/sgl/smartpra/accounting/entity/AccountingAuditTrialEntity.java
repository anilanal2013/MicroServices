package com.sgl.smartpra.accounting.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "accounting_audit_trail")
@Data
@EqualsAndHashCode(callSuper = false)
@DynamicInsert
@DynamicUpdate
public class AccountingAuditTrialEntity extends BaseEntity {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name = "accounting_audit_trail_id", nullable = false)
private Integer accountingAuditTrialId;

@Column(name = "client_id", nullable = false)
private String clienId;

@Column(name = "summarisation_id" , nullable = false)
private String summarisationId;
@Column(name = "module", nullable = false)
private String module;
@Column(name = "jv_number", nullable = false)
private String jvNumber;
@Column(name = "fin_year" , nullable = false)
private String finYear;
@Column(name = "trans_iss_airline" , nullable = true)
private String transIssAirline;
@Column(name = "trans_doc_number", nullable = true)
private String transDocNumber;
@Column(name = "main_iss_airline" , nullable = true)
private String mainIssAirline;
@Column(name = "main_doc_number" , nullable = true)
private String mainDocNumber;
@Column(name = "ref_issuing_carrier" , nullable = true)
private String refIssuingCarrier;
@Column(name = "ref_document_number" , nullable = true)
private String refDocumentNumber;
@Column(name = "coupon_number" , nullable = true)
private Integer couponNumber;
@Column(name = "document_unique_id" , nullable = true)
private String documentUniqueId;
@Column(name = "order_id" , nullable = true)
private String orderId;
@Column(name = "pnr" , nullable = true)
private String pnr;
@Column(name = "doc_type", nullable = true)
private String docType;
@Column(name = "date_of_issue" , nullable = true)
private LocalDate dateOfIssue;
@Column(name = "account_alpha_code" , nullable = false)
private String accountAlphaCode;
@Column(name = "account_description" , nullable = false)
private String accountDesciption;
@Column(name = "account_num_code" , nullable = false)
private String accountNumCode;
@Column(name = "transaction_currency" , nullable = false)
private String transactionCurrency;
@Column(name = "dr_amt_in_transaction_currency", nullable = false)
private BigDecimal drAmtInTransactionCurrency = BigDecimal.ZERO;
@Column(name = "cr_amt_in_transaction_currency", nullable = false)
private BigDecimal crAmtInTransactionCurrency = BigDecimal.ZERO;;
@Column(name = "base_currency" , nullable = false)
private String baseCurrency;
@Column(name = "debit_amount_in_base_currency", nullable = false)
private BigDecimal debitAmountInBaseCurrency = BigDecimal.ZERO;;
@Column(name = "credit_amount_in_base_currency" , nullable = false)
private BigDecimal creditAmountInBaseCurrency = BigDecimal.ZERO;;
@Column(name = "reporting_currency" , nullable = false)
private String reportingCurrency;
@Column(name = "dr_amt_in_reporting_currency", nullable = false)
private BigDecimal drAmtInReportingCurrency = BigDecimal.ZERO;;
@Column(name = "cr_amt_in_reporting_currency", nullable = false)
private BigDecimal crAmtInReportingCurrency = BigDecimal.ZERO;;
@Column(name = "conversion_rate" , nullable = false)
private BigDecimal conversionRate = BigDecimal.ONE;
@Column(name = "conversion_date" , nullable = false)
private LocalDate conversionDate;
@Column(name = "conv_rate_reporting_currency" , nullable = false)
private BigDecimal convRateReportingCurrency = BigDecimal.ONE;
@Column(name = "conv_date_reporting_currency" , nullable = false)
private LocalDate convDateReportingCurrency;
@Column(name = "accounting_date" , nullable = true)
private LocalDate accountingDate;
@Column(name = "batch_key1" , nullable = false)
private String batchKey1;
@Column(name = "batch_key2" , nullable = false)
private String batchKey2;
@Column(name = "batch_key3" , nullable = false)
private String batchKey3;
@Column(name = "batch_key4" , nullable = false)
private String batchKey4;
@Column(name = "batch_key5", nullable = false)
private LocalDate batchKey5;
@Column(name = "batch_key6" , nullable = false)
private LocalDate batchKey6;
@Column(name = "narration" , nullable = true)
private String narration;
@Column(name = "accounting_attribute_1" , nullable = true)
private String accountingAttribute1;
@Column(name = "accounting_attribute_2" , nullable = true)
private String accountingAttribute2;
@Column(name = "accounting_attribute_3" , nullable = true)
private String accountingAttribute3;
@Column(name = "accounting_attribute_4" , nullable = true)
private String accountingAttribute4;
@Column(name = "accounting_attribute_5" , nullable = true)
private String accountingAttribute5;
@Column(name = "accounting_attribute_6" , nullable = true)
private String accountingAttribute6;
@Column(name = "accounting_attribute_7" , nullable = true)
private String accountingAttribute7;
@Column(name = "accounting_attribute_8" , nullable = true)
private String accountingAttribute8;
@Column(name = "accounting_attribute_9" , nullable = true)
private String accountingAttribute9;
@Column(name = "accounting_attribute_10" , nullable = true)
private String accountingAttribute10;
@Column(name = "accounting_attribute_11" , nullable = true)
private String accountingAttribute11;
@Column(name = "accounting_attribute_12" , nullable = true)
private String accountingAttribute12;
@Column(name = "accounting_attribute_13" , nullable = true)
private String accountingAttribute13;
@Column(name = "accounting_attribute_14" , nullable = true)
private String accountingAttribute14;
@Column(name = "accounting_attribute_15" , nullable = true)
private String accountingAttribute15;
@Column(name = "accounting_attribute_16" , nullable = true)
private String accountingAttribute16;
@Column(name = "accounting_attribute_17" , nullable = true)
private String accountingAttribute17;
@Column(name = "accounting_attribute_18" , nullable = true)
private String accountingAttribute18;
@Column(name = "accounting_attribute_19" , nullable = true)
private String accountingAttribute19;
@Column(name = "accounting_attribute_20" , nullable = true)
private String accountingAttribute20;
@Column(name = "memo_no" , nullable = true)
private String memoNo;
@Column(name = "scenario_number" , nullable = true)
private Integer scenarioNumber;
@Column(name = "account_definition_identifier" , nullable = true)
private Integer accountDefinitionIdentifier;
@Column(name = "reversal_indicator", nullable = false)
private String reversalIndicator;
@Column(name = "month_closed_date" , nullable = false)
private LocalDate monthClosedDate;
@Column(name = "erp_response_number" , nullable = true)
private String erpResponseNumber;
@Column(name = "account_type" , nullable = true)
private String accountType;

    @PrePersist
    public void prePersist() {
        setCreatedDate(LocalDateTime.now());
    }

    @PreUpdate
    public void preUpdate() {
        setLastUpdatedDate(LocalDateTime.now());
    }
}
