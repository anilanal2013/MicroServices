package com.sgl.smartpra.accounting.mapper;

import com.sgl.smartpra.accounting.entity.AccountingTransactionEntity;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AccountingTransactionMapper extends BaseMapper<AccountingTransaction, AccountingTransactionEntity> {
	
}
