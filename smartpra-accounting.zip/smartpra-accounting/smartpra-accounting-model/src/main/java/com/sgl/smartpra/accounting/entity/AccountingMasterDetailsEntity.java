package com.sgl.smartpra.accounting.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 
 * @author lsivak1
 *
 */

@Entity
@Table(name = "accounting_master_details",schema = "SmartPRAAccounting")
@DynamicInsert
@DynamicUpdate
@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingMasterDetailsEntity extends BaseEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "account_master", length = 50)
	private String accountMaster;
	
	@Column(name = "account_attribute", length = 50)
	private String accountAttribute;
	
	@Column(name = "account_constraint_attribute", length = 50)
	private String accountConstraintAttribute;
	
	@Column(name = "operator", length = 5)
	private String operator;
	
	@Column(name = "sequence")
	private Integer sequence;
	
	@ManyToOne(fetch = FetchType.LAZY ,  cascade = CascadeType.ALL)
	@JoinColumn(name = "id", nullable = false, insertable = false, updatable = false)
	@NotNull
	private AccountingMasterMappingDetailsEntity mappingDetails;
	
	@Column(name = "is_active ", length = 1)
	private String isActive;
	
	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
