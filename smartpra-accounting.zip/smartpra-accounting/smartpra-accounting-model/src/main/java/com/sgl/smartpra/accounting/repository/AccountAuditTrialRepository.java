package com.sgl.smartpra.accounting.repository;

import com.sgl.smartpra.accounting.entity.AccountingAuditTrialEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountAuditTrialRepository extends JpaRepository<AccountingAuditTrialEntity, Integer> {
}
