package com.sgl.smartpra.accounting.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ErrorInfo {

    private String errorCode;

    private String errorMessage;


}
