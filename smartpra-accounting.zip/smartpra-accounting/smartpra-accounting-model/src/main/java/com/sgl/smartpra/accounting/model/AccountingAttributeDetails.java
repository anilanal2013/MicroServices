package com.sgl.smartpra.accounting.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Optional;

/**
 * 
 * @author lsivak1
 *
 */

@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingAttributeDetails {

	private Integer id;

	private Optional<String> clientId;

	private Optional<String> accountCodeAlpha;

	private Optional<String> accountNumCode;

	private Optional<String> accountDescription;

	private Optional<String> componentIdentifier;

	private Integer scenarioNumber;

	private Optional<String> debitCreditIndicator;

	private Optional<String> accountNumber;

	private Optional<String> conversionDateUse;

	private Optional<String> accountingAttributesValue1;

	private Optional<String> accountingAttributesValue2;

	private Optional<String> accountingAttributesValue3;

	private Optional<String> accountingAttributesValue4;

	private Optional<String> accountingAttributesValue5;

	private Optional<String> accountingAttributesValue6;

	private Optional<String> accountingAttributesValue7;

	private Optional<String> accountingAttributesValue8;

	private Optional<String> accountingAttributesValue9;

	private Optional<String> accountingAttributesValue10;

	private Optional<String> accountingAttributesValue11;

	private Optional<String> accountingAttributesValue12;

	private Optional<String> accountingAttributesValue13;

	private Optional<String> accountingAttributesValue14;

	private Optional<String> accountingAttributesValue15;

	private Optional<String> accountingAttributesValue16;

	private Optional<String> accountingAttributesValue17;

	private Optional<String> accountingAttributesValue18;

	private Optional<String> accountingAttributesValue19;

	private Optional<String> accountingAttributesValue20;

	private Optional<String> isActive;

}
