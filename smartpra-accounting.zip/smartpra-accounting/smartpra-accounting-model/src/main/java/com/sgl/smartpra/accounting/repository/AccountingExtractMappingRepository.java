package com.sgl.smartpra.accounting.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.accounting.entity.AccountingExtractMappingEntity;

/**
 * 
 * @author Siva Kumar
 *
 */

@Repository
public interface AccountingExtractMappingRepository extends JpaRepository<AccountingExtractMappingEntity, Integer> {

	List<AccountingExtractMappingEntity> findByClientIdAndModuleIdAndAccounttypeOrderBySequencenumberAsc(String clientId, String moduleId,
			String accounttype);
	List<AccountingExtractMappingEntity> findByClientIdAndModuleIdAndAccounttype(String clientId, String Module,
			String exceptionCode);
}
