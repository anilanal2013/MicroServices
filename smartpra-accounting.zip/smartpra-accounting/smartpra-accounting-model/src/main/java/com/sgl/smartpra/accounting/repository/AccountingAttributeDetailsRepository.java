package com.sgl.smartpra.accounting.repository;

import com.sgl.smartpra.accounting.entity.AccountingAttributeDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;


@Repository
public interface AccountingAttributeDetailsRepository extends JpaRepository<AccountingAttributeDetailsEntity, Integer>,
		JpaSpecificationExecutor<AccountingAttributeDetailsEntity> {

}
