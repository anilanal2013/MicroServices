package com.sgl.smartpra.accounting.model;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

import com.sgl.smartpra.common.model.BaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author lsivak1
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class AccountingTransaction extends BaseModel {

	private Integer accountingTxnId;

	private Optional<String> clientId;

	private String module;

	private Optional<String> transactionType;

	private Optional<String> request;

	private LocalDate dateOfIssue;

	private Optional<String> transIssAirline;

	private Optional<String> invoiceNo;

	private Optional<String> status;

	private Optional<String> statusDesc;

	private String invoiceLevel;
	
	private Integer scenarioNumber; 
	
	private Map<String, Object>batchKeyMap;

}
