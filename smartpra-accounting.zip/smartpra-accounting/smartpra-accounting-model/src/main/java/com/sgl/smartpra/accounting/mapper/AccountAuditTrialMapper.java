package com.sgl.smartpra.accounting.mapper;

import com.sgl.smartpra.accounting.entity.AccountingAuditTrialEntity;
import com.sgl.smartpra.accounting.model.AccountingAuditTrial;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AccountAuditTrialMapper extends  BaseMapper<AccountingAuditTrial, AccountingAuditTrialEntity> {
}
