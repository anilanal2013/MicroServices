package com.sgl.smartpra.accounting.model;

import java.time.LocalDate;

import lombok.Data;

/**
 * 
 * @author Siva Kumar
 *
 */
@Data
public class AccountSummarizationModel {
	
	private int accountingSummarizationId;
	
	private String moduleId;

	private String clientId;
	
	private String summarisationID;
	
	private String glInterfaceID;
	
	private String documentType;
	
	private String dateOfIssue;
	
	private String accountAlphaCode;
	
	private String accountNumcode;
	
	private String transactionCurrency;
	
	private String debitAmountInTransactionCurrency;
	
	private String creditAmountInTransactionCurrency;
	
	private String baseCurrency;
	
	private String debitAmountInBaseCurrency;
	
	private String creditAmountInBaseCurrency;
	
	private String conversionRate;
	
	private String reportingCurrency;
	
	private String debitAmountInReportingCurrency;
	
	private String creditAmountInReportingCurrency;
	
	private String conversionRateReportingCurrency;
	
	private String batchKey1;
	
	private String batchKey2;
	
	private String batchKey3;
	
	private String batchKey4;
	
	private String batchKey5;
	
	private LocalDate batchKey6;
	
	private String narration;
	
	private String invoiceDueDate;
	
	private String valueDate;
	
	private String accountingAttribute1;
	
	private String accountingAttribute2;
	
	private String accountingAttribute3;
	
	private String accountingAttribute4;
	
	private String accountingAttribute5;
	
	private String accountingAttribute6;
	
	private String accountingAttribute7;
	
	private String accountingAttribute8;
	
	private String accountingAttribute9;
	
	private String accountingAttribute10;
	
	private String accountingAttribute11;
	
	private String accountingAttribute12;
	
	private String accountingAttribute13;
	
	private String accountingAttribute14;
	
	private String accountingAttribute15;
	
	private String accountingAttribute16;
	
	private String accountingAttribute17;
	
	private String accountingAttribute18;
	
	private String accountingAttribute19;
	
	private String accountingAttribute20;
	
	private String lastUserId;
	
	private String lastUpdateDate;
	
	private LocalDate monthClosedDate;
	
	private String erpResponseNumber;

}
