package com.sgl.smartpra.accounting.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)

public class AccountResponse {

    private String jvReferenceNum;

    private String txn;

    private String status;

    private String errorCode;

    private String errorMessage;
   
}
