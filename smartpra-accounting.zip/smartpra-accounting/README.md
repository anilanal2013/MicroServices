# SmartPRA Accounting

SmartPra Accounting is a java library for dealing with accounting.

## Installation

Use the maven [maven](https://maven.apache.org/download.cgi) to install maven.

```bash
mvn clean install
```

## Clone

```bash
git clone http://wusazedev12:7990/scm/smartpra/smartpra-accounting.git
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)