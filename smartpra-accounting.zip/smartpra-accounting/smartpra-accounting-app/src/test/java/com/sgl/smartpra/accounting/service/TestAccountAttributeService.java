package com.sgl.smartpra.accounting.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.sgl.smartpra.accounting.app.configuration.ConfigForExceptionCodes;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.MasterFeignClient;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.RuleEngineFeignClient;
import com.sgl.smartpra.accounting.app.exceptions.FiegnClientException;
import com.sgl.smartpra.accounting.app.service.AccountingService;
import com.sgl.smartpra.accounting.entity.AccountingTransactionEntity;
import com.sgl.smartpra.accounting.mapper.AccountAttributeViewMapper;
import com.sgl.smartpra.accounting.mapper.AccountAuditTrialMapper;
import com.sgl.smartpra.accounting.mapper.AccountingTransactionMapper;
import com.sgl.smartpra.accounting.model.AccountAttributeView;
import com.sgl.smartpra.accounting.model.AccountResponse;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.model.AccountingTransactionModel;
import com.sgl.smartpra.accounting.repository.AccountAuditTrialRepository;
import com.sgl.smartpra.accounting.repository.AccountingTransactionRepository;
import com.sgl.smartpra.master.model.AccountDefIdentifierResponse;
import com.sgl.smartpra.master.model.AccountDefIdentifierWrapper;
import com.sgl.smartpra.master.model.AccountModel;
import com.sgl.smartpra.master.model.MasScenarioModel;


@RunWith(SpringRunner.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
@TestPropertySource(properties={"retry.maxAttempts=3","retry.delay=5000"})
public class TestAccountAttributeService {

	
	@Autowired
	private AccountingService accountingService;
	@Autowired
	MasterFeignClient masterFeignClient;
	
	@Autowired
	RuleEngineFeignClient ruleEngineFeignClient;
	
	@Autowired
	 ConfigForExceptionCodes masterExceptionCodes;
	
	@Autowired
	AccountAuditTrialRepository accountAuditTrialRepository;

	@Autowired
	AccountAttributeViewMapper accountAttributeViewMapper;

	@Autowired
	AccountAuditTrialMapper accountAuditTrialMapper;
	@Autowired
	AccountingTransactionMapper accountingTransactionMapper;
	@Autowired
	AccountingTransactionRepository accountingTransactionRepository;
	@Autowired
	FeignClientConfiguration.TransactionExceptionFeignClient transactionExceptionFeignClient;
	
	   @TestConfiguration
	   @EnableRetry
	   
	    static class conf {
			
	        @Bean
	        public AccountingService accountingService() {
	            return new AccountingService();
	        }
	       @Bean
	        public MasterFeignClient masterFeignClient() {
	            return Mockito.mock(MasterFeignClient.class);
	        }

	        @Bean
	        public RuleEngineFeignClient ruleEngineFeignClient() {
	            return Mockito.mock(RuleEngineFeignClient.class);
	        }
	        
	        @Bean
	        public ConfigForExceptionCodes masterExceptionCodes() {
	            return new ConfigForExceptionCodes();
	        }
	        @Bean
	        public AccountAuditTrialRepository accountAuditTrialRepository() {
	            return Mockito.mock(AccountAuditTrialRepository.class);
	        }
	        @Bean
	        public AccountAttributeViewMapper accountAttributeViewMapper() {
	            return Mockito.mock(AccountAttributeViewMapper.class);
	        }
	        @Bean
	        public AccountAuditTrialMapper accountAuditTrialMapper() {
	            return Mockito.mock(AccountAuditTrialMapper.class);
	        }
	        @Bean
	        public AccountingTransactionMapper accountingTransactionMapper() {
	            return Mockito.mock(AccountingTransactionMapper.class);
	        }
	        @Bean
	        public AccountingTransactionRepository accountingTransactionRepository() {
	            return Mockito.mock(AccountingTransactionRepository.class);
	        }
	        @Bean
	        public FeignClientConfiguration.TransactionExceptionFeignClient transactionExceptionFeignClient() {
	            return Mockito.mock(FeignClientConfiguration.TransactionExceptionFeignClient.class);
	        }
	
	   }
	

	   @Test
	public void testValidateMastersForEmptyAccountingTransactionMaster() throws  FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(getMasScenarioModel().getScenarioNumber())).thenReturn(new ArrayList<AccountingTransactionModel>());
		AccountResponse ar=accountingService.validateMasters(getNewAccountingTransaction(), getMasScenarioModel(), new ArrayList<AccountAttributeView>() ,null);
		Assert.assertNotNull(ar);
		assertEquals(ar.getJvReferenceNum(),null);
		assertEquals(ar.getStatus(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
		assertEquals(ar.getErrorMessage(), "Transaction Account Master Not Found for Scenario Number "+getMasScenarioModel().getScenarioNumber());
		assertEquals(ar.getTxn(),getNewAccountingTransaction().getInvoiceNo().get());
	}
	   @Test
	public void testValidateMastersForEmptyAccountDefinitionMaster() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(getMasScenarioModel().getScenarioNumber())).thenReturn(getAccountingTransactionModels());
		AccountingTransactionEntity accountingTransactionEntity=new AccountingTransactionEntity();
		when(masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(Mockito.any())).thenReturn(getAccountDefIdentifierResponse());
		//Mockito.doNothing(transactionExceptionFeignClient.initExceptionTrasaction(exceptionTransactionModel))
		AccountResponse ar=accountingService.validateMasters(getNewAccountingTransaction(), getMasScenarioModel(), new ArrayList<AccountAttributeView>() ,null);
		assertEquals(ar.getErrorCode(), "MISC1126");
		assertEquals(ar.getStatus(),  HttpStatus.INTERNAL_SERVER_ERROR.toString());
		assertEquals(ar.getJvReferenceNum(),null);
		assertEquals(ar.getErrorMessage(),"Account Definition Master Not Found for Account Definition Identifiers 108-107 and  Account Alpha Code SSA-SSC");
		
		
	}
	   @Test
	public void testValidateMasterForEmptyAccountCodeMaster() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(getMasScenarioModel().getScenarioNumber())).thenReturn(getAccountingTransactionModels());//for Transaction Account Master
		AccountingTransactionEntity accountingTransactionEntity=new AccountingTransactionEntity();
		when(masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(Mockito.any())).thenReturn(null);// negative scenario of Account Definition Master
		when(masterFeignClient.getAccountModelsByAlphaCodes(Mockito.any())).thenReturn(new ArrayList<AccountModel>());//stubbing for accode code master
		AccountResponse ar=accountingService.validateMasters(getNewAccountingTransaction(), getMasScenarioModel(), new ArrayList<AccountAttributeView>() ,null);
		assertEquals(ar.getErrorCode(), "MISC1126");
		assertEquals(ar.getStatus(),  HttpStatus.INTERNAL_SERVER_ERROR.toString());
		assertEquals(ar.getJvReferenceNum(),null);
		assertEquals(ar.getErrorMessage(),"Account Master Not Found for alpha codes SSA");

	}
	   @Test
	public void testValidateMastersForAccountingTransactionMasterTimeOutException() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(Mockito.any())).thenThrow(HystrixRuntimeException.class);
		AccountResponse ar=accountingService.validateMasters(getNewAccountingTransaction(), getMasScenarioModel(), new ArrayList<AccountAttributeView>() ,null);
		assertEquals(ar.getErrorCode(), "need to be change ");
		assertEquals(ar.getStatus(),  String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()));
		assertEquals(ar.getJvReferenceNum(),null);
		assertEquals(ar.getErrorMessage(),"Service Unavailable");

	}
	   @Test
	public void testValidateMastersForAccountDefinitionMasterTimeOutException() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(getMasScenarioModel().getScenarioNumber())).thenReturn(getAccountingTransactionModels());
		AccountingTransactionEntity accountingTransactionEntity=new AccountingTransactionEntity();
		when(masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(Mockito.any())).thenThrow(HystrixRuntimeException.class);
		AccountResponse ar=accountingService.validateMasters(getNewAccountingTransaction(), getMasScenarioModel(), new ArrayList<AccountAttributeView>() ,null);
		assertEquals(ar.getErrorCode(), "need to be change ");
		assertEquals(ar.getStatus(),  String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()));
		assertEquals(ar.getJvReferenceNum(),null);
		assertEquals(ar.getErrorMessage(),"Service Unavailable");		
	}
	   @Test
	public void testValidateMasterForAccountCodeMasterTimeOutException() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(getMasScenarioModel().getScenarioNumber())).thenReturn(getAccountingTransactionModels());//for Transaction Account Master
		AccountingTransactionEntity accountingTransactionEntity=new AccountingTransactionEntity();
		when(masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(Mockito.any())).thenReturn(null);// negative scenario of Account Definition Master
		when(masterFeignClient.getAccountModelsByAlphaCodes(Mockito.any())).thenThrow(HystrixRuntimeException.class);//stubbing for accode code master
		AccountResponse ar=accountingService.validateMasters(getNewAccountingTransaction(), getMasScenarioModel(), new ArrayList<AccountAttributeView>() ,null);
		assertEquals(ar.getErrorCode(), "need to be change ");
		assertEquals(ar.getStatus(),  String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()));
		assertEquals(ar.getJvReferenceNum(),null);
		assertEquals(ar.getErrorMessage(),"Service Unavailable");		
	}
	
	private List<AccountingTransactionModel> getAccountingTransactionModels(){
	List<AccountingTransactionModel>accTracModelList=new ArrayList<AccountingTransactionModel>();
	AccountingTransactionModel accountingTransactionModel=new AccountingTransactionModel();
	accountingTransactionModel.setAccountAlphaCode(Optional.of("SSA"));
	accountingTransactionModel.setAccountDefinitionIdentifier(Optional.of(108));
	accTracModelList.add(accountingTransactionModel);
	return accTracModelList;
	}
		private AccountDefIdentifierResponse getAccountDefIdentifierResponse() {
			AccountDefIdentifierResponse accountDefIdentifierResponse=new AccountDefIdentifierResponse();
		List<AccountDefIdentifierWrapper>accountDefIdentifierWrappers=new ArrayList<>();
		
		AccountDefIdentifierWrapper wrapper1=new AccountDefIdentifierWrapper();
		wrapper1.setAccountCodeAlpha("SSA");
		wrapper1.setAccountDefinitionIdentifier(108);
		AccountDefIdentifierWrapper wrapper2=new AccountDefIdentifierWrapper();
		wrapper2.setAccountCodeAlpha("SSC");
		wrapper2.setAccountDefinitionIdentifier(107);
		accountDefIdentifierWrappers.add(wrapper1);
		accountDefIdentifierWrappers.add(wrapper2);
		accountDefIdentifierResponse.setErrorData(accountDefIdentifierWrappers);
		
		return accountDefIdentifierResponse;
	}
	private AccountResponse getAccountResponse(){
		AccountResponse response=new AccountResponse();
		response.setErrorCode("MISC1126");
		response.setJvReferenceNum(null);
		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		response.setTxn("12345");
		response.setErrorMessage("Account Definition Master Not Found for Account Definition Identifiers 108 107 and Account Alpha Code SSA SSC");
		return response;
		
	}	
		private AccountingTransaction getNewAccountingTransaction(){
		AccountingTransaction accTransaction=new AccountingTransaction();
		accTransaction.setInvoiceNo(Optional.of("123454"));
		accTransaction.setAccountingTxnId(423);
		accTransaction.setClientId(Optional.of("QR"));
		accTransaction.setTransIssAirline(Optional.of("741"));
		accTransaction.setInvoiceNo(Optional.of("741"));
		return accTransaction;
	}
	private MasScenarioModel getMasScenarioModel(){
		MasScenarioModel masScenarioModel=new MasScenarioModel();
		masScenarioModel.setScenarioNumber(2);
		return masScenarioModel;
	}

	
}
