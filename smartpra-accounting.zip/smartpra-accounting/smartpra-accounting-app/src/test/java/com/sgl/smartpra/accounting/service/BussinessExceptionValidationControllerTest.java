package com.sgl.smartpra.accounting.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.accounting.app.controller.BussinessExceptionValidationController;
import com.sgl.smartpra.accounting.app.service.BussinessExceptionValidationService;
import com.sgl.smartpra.excep.resolution.model.ExceptionValidationModel;

@RunWith(MockitoJUnitRunner.class)
@WebMvcTest(BussinessExceptionValidationController.class)
public class BussinessExceptionValidationControllerTest {
	
    private MockMvc mockMvc;
	
	@InjectMocks
	BussinessExceptionValidationController controller;
	@Mock
	private BussinessExceptionValidationService exceptionValidationService; 
	 @Before
	    public void setUp() throws Exception {
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	    }
	
	 @Test
	 public void testValidateBussinessExceptions() throws Exception{
		 ExceptionValidationModel validationModel=new ExceptionValidationModel();
		 validationModel.setTaskId(123);
		 ObjectMapper obj = new ObjectMapper();
		 when(exceptionValidationService.validateExceptions(Mockito.any())).thenReturn(getResultExceptionValidationModel());
		 MvcResult result = this.mockMvc.perform(post("/validateExceptions").content(obj.writeValueAsString(validationModel)).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
		 ExceptionValidationModel rs=obj.readValue(result.getResponse().getContentAsString(), ExceptionValidationModel.class)	;
		assertEquals(rs.getValidationStatus(),true);;
	 }

	public  ExceptionValidationModel getResultExceptionValidationModel(){
		 ExceptionValidationModel validationModel=new ExceptionValidationModel();
		 validationModel.setValidationStatus(true);
		return validationModel;
	 }
	 
}
