package com.sgl.smartpra.accounting.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.sgl.smartpra.accounting.app.configuration.ConfigForExceptionCodes;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.MasterFeignClient;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.RuleEngineFeignClient;
import com.sgl.smartpra.accounting.app.exceptions.FiegnClientException;
import com.sgl.smartpra.accounting.app.service.AccountingService;
import com.sgl.smartpra.accounting.app.service.ExceptionLoggingService;
import com.sgl.smartpra.accounting.entity.AccountingAuditTrialEntity;
import com.sgl.smartpra.accounting.entity.AccountingTransactionEntity;
import com.sgl.smartpra.accounting.mapper.AccountAttributeViewMapper;
import com.sgl.smartpra.accounting.mapper.AccountAuditTrialMapper;
import com.sgl.smartpra.accounting.mapper.AccountingTransactionMapper;
import com.sgl.smartpra.accounting.model.AccountAttributeView;
import com.sgl.smartpra.accounting.model.AccountingAuditTrial;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.model.AccountingTransactionModel;
import com.sgl.smartpra.accounting.repository.AccountAuditTrialRepository;
import com.sgl.smartpra.accounting.repository.AccountingTransactionRepository;
import com.sgl.smartpra.excep.resolution.model.ExceptionValidationModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.AccountDefIdentifierResponse;
import com.sgl.smartpra.master.model.AccountDefIdentifierWrapper;
import com.sgl.smartpra.master.model.AccountModel;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.MasScenarioModel;

@RunWith(SpringRunner.class)
public class AccountServiceTest {

	@InjectMocks
	private AccountingService accountingService;
	
	@Mock
	MasterFeignClient masterFeignClient;
	
	@Mock
	RuleEngineFeignClient ruleEngineFeignClient;
	@Mock
	private ConfigForExceptionCodes masterExceptionCodes;
	
	@Mock
	AccountAuditTrialRepository accountAuditTrialRepository;

	@Mock
	AccountAttributeViewMapper accountAttributeViewMapper;

	@Mock
	AccountAuditTrialMapper accountAuditTrialMapper;
	@Mock
	AccountingTransactionMapper accountingTransactionMapper;
	@Mock
	AccountingTransactionRepository accountingTransactionRepository;
	@Mock
	FeignClientConfiguration.TransactionExceptionFeignClient transactionExceptionFeignClient;
	@Mock 
	ExceptionLoggingService exceptionLoggingService;
	@Test
	public void testValidateMastersTransactionAccountMasterNotFoundValidationFalse() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(Mockito.any())).thenReturn(new ArrayList<AccountingTransactionModel>());
		when(masterExceptionCodes.getTransactionAccountMasterNotFound()).thenReturn("GEN6007");
		ExceptionValidationModel response=accountingService.validateMasters(getValidationModel(),getAccountingTransactionEntity(),"GEN6007",getAccountingAttributeViewList(),getAccountingTransaction(),getMasScenarioModel());
		assertEquals(response.getValidationStatus(), false);
		
	}
	@Test
	public void testValidateMastersTransactionAccountMasterNotFoundForDifferentError() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(Mockito.any())).thenReturn(new ArrayList<AccountingTransactionModel>());
		when(masterExceptionCodes.getTransactionAccountMasterNotFound()).thenReturn("GEN6001");
		Mockito.doNothing().when(transactionExceptionFeignClient).initExceptionTrasaction(Mockito.any());
		when(exceptionLoggingService.getModuleBasedExceptionCode(Mockito.anyString(), Mockito.anyString())).thenReturn("GEN6013");
		when(exceptionLoggingService.getExceptionTransactionModel(Mockito.any(), Mockito.anyString(), Mockito.any())).thenReturn(getExceptionTransactionModel());
		ExceptionValidationModel response=accountingService.validateMasters(getValidationModel(),getAccountingTransactionEntity(),"GEN6007",getAccountingAttributeViewList(),getAccountingTransaction(),getMasScenarioModel());
		assertEquals(response.getValidationStatus(), false);
		
	}
	@Test
	public void testValidateMastersTransactionAccountMasterNotFoundValidationStatusTrue() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(Mockito.any())).thenReturn(getAccountingTransactionModels());
		when(masterExceptionCodes.getTransactionAccountMasterNotFound()).thenReturn("GEN6007");
		when(masterExceptionCodes.getAccountDefinitionMasterMotFound()).thenReturn("GEN6013");
		when(exceptionLoggingService.getExceptionTransactionModel(Mockito.any(), Mockito.anyString(), Mockito.any())).thenReturn(getExceptionTransactionModel());
		Mockito.doNothing().when(transactionExceptionFeignClient).initExceptionTrasaction(Mockito.any());
		when(masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(Mockito.any())).thenReturn(getAccountDefIdentifierResponse());
		when(exceptionLoggingService.getModuleBasedExceptionCode(Mockito.anyString(), Mockito.anyString())).thenReturn("GEN6013");
		ExceptionValidationModel response=accountingService.validateMasters( getValidationModel(),getAccountingTransactionEntity(),"GEN6007",getAccountingAttributeViewList(),getAccountingTransaction(),getMasScenarioModel());
		assertEquals(response.getValidationStatus(), true);
		
	}
	@Test
	public void testValidateMastersAccounDefinitiontMasterNotFoundValidationStatusTrue() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(Mockito.any())).thenReturn(getAccountingTransactionModels());
		when(masterExceptionCodes.getTransactionAccountMasterNotFound()).thenReturn("GEN6007");
		when(masterExceptionCodes.getAccountDefinitionMasterMotFound()).thenReturn("GEN6013");
		AccountDefIdentifierResponse accountDefIdentifierResponse=getAccountDefIdentifierResponse();
		accountDefIdentifierResponse.setErrorData(new ArrayList<>());
		when(masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(Mockito.any())).thenReturn(accountDefIdentifierResponse);
		when(masterExceptionCodes.getAccountMasterNotFound()).thenReturn("GEN6011");
		Mockito.doNothing().when(transactionExceptionFeignClient).initExceptionTrasaction(Mockito.any());
		when(exceptionLoggingService.getModuleBasedExceptionCode(Mockito.anyString(), Mockito.anyString())).thenReturn("GEN6013");
		when(exceptionLoggingService.getExceptionTransactionModel(Mockito.any(), Mockito.anyString(), Mockito.any())).thenReturn(getExceptionTransactionModel());
		ExceptionValidationModel response=accountingService.validateMasters(getValidationModel(),getAccountingTransactionEntity(),"GEN6013",getAccountingAttributeViewList(),getAccountingTransaction(),getMasScenarioModel());
		assertEquals(response.getValidationStatus(), true);
		
	}
	private ExceptionTransactionModel getExceptionTransactionModel() {
		
		return new ExceptionTransactionModel();
	}
	@Test
	public void testValidateMastersAccounDefinitiontMasterNotFoundValidationStatusFalse() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(Mockito.any())).thenReturn(getAccountingTransactionModels());
		when(masterExceptionCodes.getTransactionAccountMasterNotFound()).thenReturn("GEN6007");
		when(masterExceptionCodes.getAccountDefinitionMasterMotFound()).thenReturn("GEN6013");
		when(masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(Mockito.any())).thenReturn(getAccountDefIdentifierResponse());
		when(masterExceptionCodes.getAccountMasterNotFound()).thenReturn("GEN6011");
		ExceptionValidationModel response=accountingService.validateMasters( getValidationModel(),getAccountingTransactionEntity(),"GEN6013",getAccountingAttributeViewList(),getAccountingTransaction(),getMasScenarioModel());
		assertEquals(response.getValidationStatus(), false);
		
	}
	
	@Test
	public void testValidateAccountMasterNotFoundValidationStatusTrue() throws FiegnClientException{
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(Mockito.any())).thenReturn(getAccountingTransactionModels());
		when(masterExceptionCodes.getTransactionAccountMasterNotFound()).thenReturn("GEN6007");
		when(masterExceptionCodes.getAccountDefinitionMasterMotFound()).thenReturn("GEN6013");
		AccountDefIdentifierResponse accountDefIdentifierResponse=getAccountDefIdentifierResponse();
		accountDefIdentifierResponse.setErrorData(new ArrayList<>());
		when(masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(Mockito.any())).thenReturn(accountDefIdentifierResponse);
		when(masterExceptionCodes.getAccountMasterNotFound()).thenReturn("GEN6011");
		when(masterFeignClient.getAccountModelsByAlphaCodes(Mockito.any())).thenReturn(getAccountModels());
		when(ruleEngineFeignClient.calculateAccounts(Mockito.any())).thenReturn(getAccountingAuditTrials());
		when(masterFeignClient.getCurrentOpenFinancialMonthForFinancialCalendar(Mockito.any())).thenReturn(getFinancialMonthModel());
		when(masterFeignClient.getLatestClosedFinancialMonthForFinancialCalendar()).thenReturn(new FinancialMonthModel());
		when(accountAuditTrialMapper.mapToEntity(Mockito.anyListOf(AccountingAuditTrial.class))).thenReturn(new ArrayList<AccountingAuditTrialEntity>());
		when(accountAuditTrialRepository.saveAll(Mockito.any())).thenReturn(new ArrayList<AccountingAuditTrialEntity>());
		when(accountAuditTrialMapper.mapToModel(Mockito.anyListOf(AccountingAuditTrialEntity.class))).thenReturn(new ArrayList<AccountingAuditTrial>());
		when(accountingTransactionMapper.mapToEntity(Mockito.any(AccountingTransaction.class))).thenReturn(new AccountingTransactionEntity());
		when(accountingTransactionRepository.save(Mockito.any())).thenReturn(new AccountingTransactionEntity());
		ExceptionValidationModel response=accountingService.validateMasters(getValidationModel(),getAccountingTransactionEntity(),"GEN6011",getAccountingAttributeViewList(),getAccountingTransaction(),getMasScenarioModel());
		assertEquals(response.getValidationStatus(), true);
		
	}
	
	public FinancialMonthModel getFinancialMonthModel(){
		FinancialMonthModel financialMonthModel=new FinancialMonthModel();
		financialMonthModel.setFinancialMonth("Mar");
		return financialMonthModel;
	}

	private List<AccountingAuditTrial> getAccountingAuditTrials() {
		List<AccountingAuditTrial> auditTrials = new ArrayList<>();
		AccountingAuditTrial accountingAuditTrial = new AccountingAuditTrial();
		auditTrials.add(accountingAuditTrial);
		return auditTrials;
	}
	private List<AccountModel> getAccountModels() {
		List<AccountModel> accountModels=new ArrayList<>();
		AccountModel accountModel=new AccountModel();
		accountModels.add(accountModel);
		return accountModels;
	}
	public AccountDefIdentifierResponse getAccountDefIdentifierResponse(){
		AccountDefIdentifierResponse accountDefIdentifierResponse =new AccountDefIdentifierResponse();
		List<AccountDefIdentifierWrapper> errorData=new ArrayList<>();
		AccountDefIdentifierWrapper wrapper=new AccountDefIdentifierWrapper();
		wrapper.setAccountCodeAlpha("ASA");
		wrapper.setAccountDefinitionIdentifier(123);
		errorData.add(wrapper);
		accountDefIdentifierResponse.setErrorData(errorData);
		return accountDefIdentifierResponse;
	}
	public List<AccountingTransactionModel> getAccountingTransactionModels(){
		List<AccountingTransactionModel> aTxnModels=new ArrayList<AccountingTransactionModel>();
		AccountingTransactionModel aTxn=new AccountingTransactionModel();
		aTxn.setAccountAlphaCode(Optional.of("SSA"));
		aTxn.setAccountDefinitionIdentifier(Optional.of(108));
		aTxnModels.add(aTxn);
		return aTxnModels;
		
	}
	private ExceptionValidationModel getValidationModel(){
		ExceptionValidationModel validationModelReponse=new ExceptionValidationModel();
		validationModelReponse.setAccountingTransactionId(Long.valueOf(423));
		validationModelReponse.setValidationStatus(false);
		return validationModelReponse;
	}
	private AccountingTransactionEntity getAccountingTransactionEntity(){
		AccountingTransactionEntity accountingTransactionEntity=new AccountingTransactionEntity();
		accountingTransactionEntity.setScenarioNumber(423);
		
		return accountingTransactionEntity;
	}
	private List<AccountAttributeView> getAccountingAttributeViewList(){
		List<AccountAttributeView> accountingAttributeViewList=new ArrayList<>();
		AccountAttributeView accountAttributeView=new AccountAttributeView();
		accountingAttributeViewList.add(accountAttributeView);
		return accountingAttributeViewList;
	}
	private  AccountingTransaction getAccountingTransaction(){
		 AccountingTransaction accountingTransaction=new  AccountingTransaction();
		 accountingTransaction.setClientId(Optional.of("QR"));
		 accountingTransaction.setModule("M");
		 accountingTransaction.setAccountingTxnId(423);
		 accountingTransaction.setTransIssAirline(Optional.of("741"));
		 accountingTransaction.setInvoiceNo(Optional.of("741"));
		 return accountingTransaction;
	}
	public MasScenarioModel getMasScenarioModel(){
		MasScenarioModel masScenarioModel=new MasScenarioModel();
		masScenarioModel.setScenarioNumber(423);
		masScenarioModel.setModule(Optional.of("M"));
		return masScenarioModel;
	}
}
