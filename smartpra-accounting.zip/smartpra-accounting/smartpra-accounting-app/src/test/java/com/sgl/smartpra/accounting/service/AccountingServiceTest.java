package com.sgl.smartpra.accounting.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.MasterFeignClient;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.RuleEngineFeignClient;
import com.sgl.smartpra.accounting.model.AccountingTransactionModel;

@RunWith(MockitoJUnitRunner.class)
public class AccountingServiceTest {

	@Mock
	MasterFeignClient masterFeignClient;
	
	@Mock
	RuleEngineFeignClient ruleEngineFeignClient;
	
	@Test
	public void testTransactionAccountMasterForNonMappedScenarioNo(){
		when(masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(Mockito.any())).thenReturn(new ArrayList<AccountingTransactionModel>());
		
	
	}
}
