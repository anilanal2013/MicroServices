package com.sgl.smartpra.accounting.service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.sgl.smartpra.accounting.app.utils.JVnGL;
import com.sgl.smartpra.accounting.model.AccountingTransaction;

@RunWith(SpringRunner.class)
public class JVnGLTest {
	@Test
    public void testCalculateJVNotNull(){
	JVnGL jVnGL=new JVnGL();
	AccountingTransaction accountingTransaction=getAccountingTransaction();
	String jvNumber =  ReflectionTestUtils.invokeMethod(jVnGL,"calculateJV", new Object[]{accountingTransaction});
	Assert.assertNotNull(jvNumber);
	}
			private AccountingTransaction getAccountingTransaction() {
			AccountingTransaction accountingTransaction=new AccountingTransaction();
			accountingTransaction.setAccountingTxnId(5202);
			accountingTransaction.setClientId(Optional.of("QR"));
			accountingTransaction.setModule("M");
			accountingTransaction.setTransactionType(Optional.of("BSP"));
			accountingTransaction.setDateOfIssue(LocalDate.now());
			accountingTransaction.setTransIssAirline(Optional.of("741"));
			accountingTransaction.setInvoiceNo(Optional.of("12345"));
			accountingTransaction.setStatus(Optional.of("ERROR"));
			accountingTransaction.setStatusDesc(Optional.of("error"));
			accountingTransaction.setInvoiceLevel("I");
			accountingTransaction.setScenarioNumber(423);
			Map<String, Object>batchKey=new HashMap<>();
			batchKey.put("batchKey1", "batchKey1");
			batchKey.put("batchKey2", "batchKey2");
			batchKey.put("batchKey3", "batchKey3");
			batchKey.put("batchKey4", "batchKey4");
			batchKey.put("batchKey5", "batchKey5");
			batchKey.put("batchKey6", "batchKey6");
			accountingTransaction.setBatchKeyMap(batchKey);
			return accountingTransaction;
	}
		
	}


