package com.sgl.smartpra.accounting.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.sgl.smartpra.accounting.app.configuration.ConfigForExceptionCodes;
import com.sgl.smartpra.accounting.app.dao.AccountAttributeDao;
import com.sgl.smartpra.accounting.app.exceptions.FiegnClientException;
import com.sgl.smartpra.accounting.app.service.AccountingService;
import com.sgl.smartpra.accounting.app.service.impl.BussinessExceptionValidationServiceImpl;
import com.sgl.smartpra.accounting.entity.AccountAttributeViewEntity;
import com.sgl.smartpra.accounting.entity.AccountingTransactionEntity;
import com.sgl.smartpra.accounting.mapper.AccountAttributeViewMapper;
import com.sgl.smartpra.accounting.mapper.AccountAuditTrialMapper;
import com.sgl.smartpra.accounting.mapper.AccountingTransactionMapper;
import com.sgl.smartpra.accounting.model.AccountAttributeView;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.repository.AccountAuditTrialRepository;
import com.sgl.smartpra.accounting.repository.AccountingTransactionRepository;
import com.sgl.smartpra.excep.resolution.model.ExceptionValidationModel;
import com.sgl.smartpra.exception.txn.enums.EnvironmentEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionTransactionEnum;
import com.sgl.smartpra.master.model.MasScenarioModel;

@RunWith(SpringRunner.class)
public class BussinessExceptionValidationServiceImplTest {
	@Mock
	private AccountingService accountingService;
		@Mock
	AccountAttributeViewMapper accountAttributeViewMapper;
		@Mock
	AccountAttributeDao accountAttributeDao;
		@Mock
	private AccountingTransactionRepository accountingTransactionRepository;
		@Mock
	AccountingTransactionMapper accountingTransactionMapper;
		@Mock
	AccountAuditTrialRepository accountAuditTrialRepository;
	
		@Mock
	AccountAuditTrialMapper accountAuditTrialMapper;
		@Mock
	private ConfigForExceptionCodes masterExceptionCodes;
	
	@InjectMocks
	private BussinessExceptionValidationServiceImpl bussinessExceptionValidationServiceImpl;
	/*@@Mock
	MasterFeignClient masterFeignClient;*/

	/*  @TestConfiguration
	static class conf{
		@Bean
		public BussinessExceptionValidationServiceImpl bussinessExceptionValidationServiceImpl(){
			return new BussinessExceptionValidationServiceImpl();
		}
		@Bean
		public AccountingService accountingService(){
			return new AccountingService();
		}
			@Bean
		public AccountAttributeViewMapper accountAttributeViewMapper(){
			return Mockito.mock(AccountAttributeViewMapper.class);
		}
		@Bean
		public AccountAttributeDao accountAttributeDao(){
			return Mockito.mock(AccountAttributeDao.class);
		}
		@Bean
		public AccountingTransactionRepository accountingTransactionRepository(){
			return Mockito.mock(AccountingTransactionRepository.class);
		}
		@Bean
		public AccountingTransactionMapper accountingTransactionMapper(){
			return Mockito.mock(AccountingTransactionMapper.class);
		}
		@Bean
		public AccountAuditTrialRepository accountAuditTrialRepository(){
			return Mockito.mock(AccountAuditTrialRepository.class);
		}
		@Bean
		public AccountAuditTrialMapper accountAuditTrialMapper(){
			return Mockito.mock(AccountAuditTrialMapper.class);
		}
		@Bean
		public ConfigForExceptionCodes masterExceptionCodes(){
			return new ConfigForExceptionCodes();
		}
		@Bean
		public MasterFeignClient masterFeignClient(){
			return Mockito.mock(MasterFeignClient.class);
		}

	}*/
	@Test
	public void testValidateExceptionsForScenarioNotFound() throws FiegnClientException{
		
		when(masterExceptionCodes.getMastersExceptionCodes()).thenReturn(getMasterExceptionCodes());
		when(accountingTransactionRepository.findById(Mockito.any())).thenReturn(getAccountingTransactionEntity());
		Optional<AccountingTransactionEntity> existAccTxn = null;
		AccountingTransaction aTxn=	getAccountingTransaction();
		aTxn.setScenarioNumber(null);
		when(accountingTransactionMapper.mapToModel(getAccountingTransactionEntity().get())).thenReturn(aTxn);
		when(accountingService.fetchScenarioMasterByRules(Mockito.any())).thenReturn(getMasScenarioModel());
		when(accountingService.getScenarioMasters(Mockito.any())).thenReturn(getLisOfScenarioModel());
		when(masterExceptionCodes.getScenarioMasterNotFoundErrorCodes()).thenReturn(getScenarioMasterNotFoundErrorCodes());
		when(accountAttributeDao.fetchAccountAttributeViewByScenarioNumberAndClientId(Mockito.any(),Mockito.any())).thenReturn(getAccountAttributeViewEntityList());
		when(accountAttributeViewMapper.mapToModel(Mockito.anyListOf(AccountAttributeViewEntity.class))).thenReturn(getAccountAttributeViewList());
		when(masterExceptionCodes.getRuleEngineNotFound()).thenReturn("RENF");
		when(accountingService.validateMasters(Mockito.any(),Mockito.any(),Mockito.anyString(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(getExceptionValidationModel());
		Mockito.doNothing().when(accountingService).completeTransaction(Mockito.any(), Mockito.any());
		ExceptionValidationModel response=bussinessExceptionValidationServiceImpl.validateExceptions(getValidationModelrequest());
		assertEquals(response.getValidationStatus(),true);
		
			
		
	}
	private ExceptionValidationModel getExceptionValidationModel() {
		return new ExceptionValidationModel();
	}
	public List<AccountAttributeViewEntity>getAccountAttributeViewEntityList(){
	return new ArrayList<AccountAttributeViewEntity>();
	}
	public List<AccountAttributeView>getAccountAttributeViewList(){
		List<AccountAttributeView>aaVs =new ArrayList<AccountAttributeView>();
		AccountAttributeView attributeView=new AccountAttributeView();
		aaVs.add(attributeView);
		return aaVs;
	}
	private List<String> getScenarioMasterNotFoundErrorCodes() {
		List<String>exCodes=new ArrayList<>();
		exCodes.add("GEN6001");
		exCodes.add("GEN6002");
		exCodes.add("GEN6003");
		exCodes.add("GEN6004");
		exCodes.add("GEN6005");
		return exCodes;
		
	}
	private List<MasScenarioModel> getLisOfScenarioModel() {
		List<MasScenarioModel> sm=new ArrayList<MasScenarioModel>();
		MasScenarioModel model=new MasScenarioModel();
		sm.add(model);
		return sm;
	}
	private ExceptionValidationModel getValidationModelrequest() {
		ExceptionValidationModel exceptionValidationModel=new ExceptionValidationModel();
		exceptionValidationModel.setTaskId(1234);
		exceptionValidationModel.setExceptionCodes(Stream.of("GEN6001")
                .collect(Collectors.toCollection(HashSet::new)));
		exceptionValidationModel.setExceptionTransactionIds(new HashSet<>());
		exceptionValidationModel.setStagingReferenceId(new HashSet<>());
		exceptionValidationModel.setEnvironment(EnvironmentEnum.PRODUCTION);
		exceptionValidationModel.setInvoiceUrn("");
		exceptionValidationModel.setDocumentUniqueId("");
		exceptionValidationModel.setCouponNumber(12345);
		exceptionValidationModel.setAccountingTransactionId(Long.valueOf(12345));
		exceptionValidationModel.setTransactionType(ExceptionTransactionEnum.BSP);
		exceptionValidationModel.setValidationStatus(false);
		return exceptionValidationModel;
		
	}
	public List<String> getMasterExceptionCodes(){
		List<String>exCodes=new ArrayList<>();
		exCodes.add("GEN6001");
		exCodes.add("GEN6002");
		exCodes.add("GEN6003");
		exCodes.add("GEN6004");
		exCodes.add("GEN6005");
		exCodes.add("GEN6006");
		exCodes.add("GEN6007");
		exCodes.add("GEN6013");
		exCodes.add("GEN6011");
		return exCodes;
		
	}
	String request="{\"createdBy\":null,\"createdDate\":null,\"lastUpdatedBy\":null,\"lastUpdatedDate\":null,\"invoiceUrn\":\"MI19000175\",\"clientId\":\"QR\",\"invoiceNumber\":\"\",\"jvReferenceNumber\":\"\",\"invoiceDate\":1551916800000,\"invoiceType\":\"I\",\"taxInvoiceNumber\":null,\"taxPointDate\":null,\"locationCode\":\"\",\"chargeCategoryCode\":\"GHD\",\"sellerOrganizationId\":\"741\",\"sellerLocationId\":null,\"buyerOrganizationId\":null,\"buyerLocationId\":null,\"currencyCode\":\"AED\",\"clearanceCurrencyCode\":null,\"exchangeRate\":1.00000000,\"bkrExchangeRate\":null,\"accountingMonth\":null,\"accountingDate\":null,\"settlementMonthPeriod\":\"010301\",\"settlementMethod\":\"D\",\"digitalSignatureFlag\":null,\"suspendedFlag\":null,\"isValidationFlag\":null,\"rejectionFlag\":null,\"rejectionStage\":null,\"originalInvoiceNumber\":\"\",\"originalBillingPeriod\":null,\"orginalBillingMonth\":\"\",\"correspondanceFlag\":\" \",\"authorityToBillFlag\":\" \",\"correspondanceRefNo\":null,\"disputeRefNumber\":null,\"poNumber\":\"\",\"invoiceTemplateLanguage\":null,\"description\":\"\",\"noOfAttachments\":null,\"lineItemCount\":null,\"totalLineItemAmount\":5387.290,\"taxAmount\":0.000,\"vatAmount\":0.000,\"addonChargeAmount\":0.000,\"totalAddonChargeAmount\":0.000,\"totalTaxAmount\":0.000,\"totalVatAmount\":0.000,\"totalAmount\":5387.290,\"totalClearanceCurrencyAmt\":null,\"baseCurrency\":null,\"amountBaseCurrency\":null,\"inwardOutwardFlag\":\"O\",\"invoiceStatus\":\"SA\",\"rejInvoiceNo\":\"\",\"billingMonth\":\"MAR-01\",\"billingPeriod\":1,\"supplierType\":\"C\",\"chargeAmountAccepted\":null,\"totalTaxAmountAccepted\":null,\"totalVatAmountAccepted\":null,\"totalAddonChargeAmountAccepted\":null,\"netAmountAccepted\":null,\"chargeAmountRejected\":null,\"totalTaxAmountRejected\":null,\"totalVatAmountRejected\":null,\"totalAddonChargeAmountRejected\":null,\"netAmountRejected\":null,\"supplierName\":\"SAFI AIRWAYS LTD.\",\"miscBillingInvLineitem\":null,\"miscBillingTaxDetails\":null,\"miscBillingAddOnChargeDtl\":null,\"miscBillingInvAttachment\":null}";

	public Optional<AccountingTransactionEntity> getAccountingTransactionEntity(){
		AccountingTransactionEntity transactionEntity=new AccountingTransactionEntity();
		Optional<AccountingTransactionEntity> transactionEntityOptional=Optional.of(transactionEntity);
		transactionEntity.setAccountingTxnId(5202);
		transactionEntity.setClientId("QR");
		transactionEntity.setModule("M");
		transactionEntity.setTransactionType("BSP");
		transactionEntity.setRequest(request);
		transactionEntity.setDateOfIssue(LocalDate.now());
		transactionEntity.setTransIssAirline("741");
		transactionEntity.setInvoiceNo("123245");
		transactionEntity.setStatus("ERROR");
		transactionEntity.setStatusDesc("error");
		transactionEntity.setCreatedBy("Junit");
		transactionEntity.setCreatedDate(LocalDateTime.now());
		transactionEntity.setLastUpdatedBy("junit");
		transactionEntity.setLastUpdatedDate(LocalDateTime.now());
		transactionEntity.setScenarioNumber(423);
		transactionEntity.setInvoiceLevel("I");
		
		return transactionEntityOptional;
	}
	
	public AccountingTransaction getAccountingTransaction(){
		AccountingTransaction accountingTransaction=new AccountingTransaction();
		accountingTransaction.setAccountingTxnId(5202);
		accountingTransaction.setClientId(Optional.of("QR"));
		accountingTransaction.setModule("M");
		accountingTransaction.setTransactionType(Optional.of("BSP"));
		accountingTransaction.setRequest(Optional.of(request));
		accountingTransaction.setDateOfIssue(LocalDate.now());
		accountingTransaction.setTransIssAirline(Optional.of("741"));
		accountingTransaction.setInvoiceNo(Optional.of("12345"));
		accountingTransaction.setStatus(Optional.of("ERROR"));
		accountingTransaction.setStatusDesc(Optional.of("error"));
		accountingTransaction.setInvoiceLevel("I");
		accountingTransaction.setScenarioNumber(423);
		return accountingTransaction;
	}
	
	public MasScenarioModel getMasScenarioModel(){
		MasScenarioModel masScenarioModel=new MasScenarioModel();
		masScenarioModel.setScenarioNumber(423);
		masScenarioModel.setModule(Optional.of("M"));
		return masScenarioModel;
	}
}
