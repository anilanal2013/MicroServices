package com.sgl.smartpra.accounting.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;

import com.sgl.smartpra.accounting.app.service.impl.ExceptionLoggingImpl;
import com.sgl.smartpra.accounting.entity.AccountingExtractMappingEntity;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.repository.AccountingExtractMappingRepository;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

@RunWith(SpringRunner.class)
public class ExceptionLoggingImplTest {
	@InjectMocks
	private ExceptionLoggingImpl exceptionLoggingImpl; 
	@Mock
	private AccountingExtractMappingRepository accountingExtractMappingRepository;
	@Mock
	private Environment environment;
		
	@Test
	public void testGetExceptionTransactionModel(){
		when(accountingExtractMappingRepository.findByClientIdAndModuleIdAndAccounttype(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(getAccountingExtractMappingEntity());
		when(environment.getProperty(Mockito.anyString())).thenReturn("GEN6014");
		ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingImpl.getExceptionTransactionModel(getAccountingTransaction(), "scenarioNotFound", getParmMap());
		assertEquals(exceptionTransactionModel.getParametersValueList(),getParametersValueList());
	}

	private List<ExceptionParametersValueModel> getParametersValueList() {
		 List<ExceptionParametersValueModel> parametersValueList=new ArrayList<>();
		 ExceptionParametersValueModel valueModel=new ExceptionParametersValueModel();
		 valueModel.setParameterName("accountAlphaCode");
		 valueModel.setParameterValue("accountAlphaCode");
		 parametersValueList.add(valueModel);
		return parametersValueList;
	}

	private Map<String, Object> getParmMap() {
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("accountAlphaCode", "accountAlphaCode");
		return map;
	}
	
	public AccountingTransaction getAccountingTransaction(){
		AccountingTransaction accountingTransaction=new AccountingTransaction();
		accountingTransaction.setAccountingTxnId(5202);
		accountingTransaction.setClientId(Optional.of("QR"));
		accountingTransaction.setModule("M");
		accountingTransaction.setTransactionType(Optional.of("BSP"));
		accountingTransaction.setDateOfIssue(LocalDate.now());
		accountingTransaction.setTransIssAirline(Optional.of("741"));
		accountingTransaction.setInvoiceNo(Optional.of("12345"));
		accountingTransaction.setStatus(Optional.of("ERROR"));
		accountingTransaction.setStatusDesc(Optional.of("error"));
		accountingTransaction.setInvoiceLevel("I");
		accountingTransaction.setScenarioNumber(423);
		return accountingTransaction;
	}

	private List<AccountingExtractMappingEntity> getAccountingExtractMappingEntity() {
	List<AccountingExtractMappingEntity>accList=new ArrayList<>();
	AccountingExtractMappingEntity accountingExtractMappingEntity=new AccountingExtractMappingEntity();
	accountingExtractMappingEntity.setKeyval("accountAlphaCode");
	accountingExtractMappingEntity.setValue("accountAlphaCode");
	accountingExtractMappingEntity.setDefaultvalue("alphacode");
	accList.add(accountingExtractMappingEntity);
		return accList;
	}
}
