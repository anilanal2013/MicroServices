package com.sgl.smartpra.accounting.service;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.sgl.smartpra.accounting.app.utils.JVnGL;
import com.sgl.smartpra.accounting.model.AccountingTransaction;

public class AccountingAttributeServiceTest {

    @Test
    public void testCalculateJV(){
   //     AccountAttributeService accountAttributeService = new AccountAttributeService();
    	JVnGL jVnGL=new JVnGL();
        AccountingTransaction accountingTransaction = new AccountingTransaction();
        accountingTransaction.setModule("M");
        accountingTransaction.setAccountingTxnId(1);
       String s =  ReflectionTestUtils.invokeMethod(jVnGL,"calculateJV", new Object[]{"M", 1});
        Assert.assertThat(s, CoreMatchers.containsString("M"));
        Assert.assertEquals("M000000001",s);
    }


}
