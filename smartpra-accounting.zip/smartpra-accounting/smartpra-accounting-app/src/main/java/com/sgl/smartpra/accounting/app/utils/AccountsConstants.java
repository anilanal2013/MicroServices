package com.sgl.smartpra.accounting.app.utils;

public class AccountsConstants {

    public static final String MISC_1126 = "MISC1126";
    public static final String MISC_1125 = "MISC1125";
	public static final String MISC_9002 = "MISC9002";
	
	public static final String MODULE_ID = "AC";

	public static final String FILECATEGORY_CSV = "CSV";
	
	public static final String PROCESSED_BY_MANUAL = "Manual";
	
	public static final String CREATED_BY_ACCOUNTING = "ACCOUNTING";
	
	public static final String FILETYPE_GL = "GL";
	
	public static final String N = "N";
}
