package com.sgl.smartpra.accounting.app.configuration;

import org.springframework.stereotype.Component;

import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.MasterFeignClient;

import feign.hystrix.FallbackFactory;
@Component
public class MasterFallBackFactory implements FallbackFactory<MasterFeignClient> {

	@Override
	public MasterFeignClient create(Throwable cause) {
			return new FeignClientExceptionServiceImpl(cause);
	}

}
