package com.sgl.smartpra.accounting.app.exceptions;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author nacsanth
 *
 */
@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class ConfigurationSetUpNotFoundException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private String jvReferenceNum;
    private String httpStatus;  
    private String error;
    private String errorMess;
    private String invoiceNo;

}
