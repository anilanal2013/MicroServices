package com.sgl.smartpra.accounting.app.utils;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.sgl.smartpra.accounting.model.AccountingTransaction;

public class JVnGL {
	
	public static String calculateJV(String module, Integer accountTxn){
		return StringUtils.join(module,StringUtils.leftPad(String.valueOf(accountTxn),9,"0"));
	}
	public static String fetchGLSummarizationNo(String module, String closedDate, Integer accountTxn){
		return StringUtils.join(module,closedDate,accountTxn);

	}
	public static String calculateJV(AccountingTransaction accountingTransaction) {
		if(accountingTransaction!=null){
		String keys=accountingTransaction.getBatchKeyMap()!=null?accountingTransaction.getBatchKeyMap().entrySet().stream().filter(Objects::nonNull).map(x->String.valueOf(x.getValue())).collect(Collectors.joining()):"";
		String dateTime=LocalDateTime.now().toString();
		return	 StringUtils.join(accountingTransaction.getModule(),accountingTransaction.getTransIssAirline().orElse(""),accountingTransaction.getInvoiceNo().orElse(""),accountingTransaction.getDateOfIssue()!=null?accountingTransaction.getDateOfIssue().toString():"",
				 keys!=null?keys:"",dateTime);
		}
		return null;
		 
	}
}
