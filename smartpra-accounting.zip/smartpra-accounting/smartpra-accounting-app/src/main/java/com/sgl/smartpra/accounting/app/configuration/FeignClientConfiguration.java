package com.sgl.smartpra.accounting.app.configuration;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.accounting.model.AccountingAuditTrial;
import com.sgl.smartpra.accounting.model.AccountingEntryRequest;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.model.AccountingTransactionModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.AccountDefIdentifierResponse;
import com.sgl.smartpra.master.model.AccountModel;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.MasScenarioModel;

@Configuration
public class FeignClientConfiguration {

	@FeignClient(value = "smartpra-master-app", fallbackFactory = MasterFallBackFactory.class/*configuration=FeignErrorDecoder.class*/)
	public interface MasterFeignClient {

		@PostMapping("/fetch_scenario-master")
		public List<MasScenarioModel> fetchScenarioMaster(@RequestBody MasScenarioModel scenarioMaster);

		@GetMapping("/financial-month/current-open")
		public FinancialMonthModel getCurrentOpenFinancialMonthForFinancialCalendar(
				@RequestParam(value = "clientId", required = false) String clientId);

		@GetMapping("/financial-month/latest-closed")
		public FinancialMonthModel getLatestClosedFinancialMonthForFinancialCalendar();
		
		@GetMapping("/accounting-transaction/{scenarioNumber}")
		public List<AccountingTransactionModel> getMasTransactionAccountsModelsByScenaroNo(@PathVariable("scenarioNumber") Integer scenarioNumber );
		
		@GetMapping("/account/account-alpha-codes")
		public List<AccountModel> getAccountModelsByAlphaCodes(@RequestParam("accountAlphaCode") List<String> accountAlphaCode);
		
		@PostMapping("/account-definition/account-alpha-code/account-def-identifier")
		public AccountDefIdentifierResponse getMasAccountDefModelsByAccDefIdAndAccAlphaCode(@RequestBody AccountDefIdentifierResponse accountDefIdentifierRequest);


	}
	
	@FeignClient(value = "smartpra-rule-engine")
	public interface RuleEngineFeignClient {
		
		@PostMapping("/fetchScenario")
	    public MasScenarioModel fetchScenarioMaster(
	                                              @RequestBody AccountingTransaction accountingTransaction);

		@PostMapping("/calculateAccounts")
	    public List<AccountingAuditTrial> calculateAccounts(@RequestBody AccountingEntryRequest accountingEntryRequest);

	}
	@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface TransactionExceptionFeignClient {

		@GetMapping("/api/init-exceptionmessage")
		public void initExceptionTrasaction(@RequestBody ExceptionTransactionModel exceptionTransactionModel);
	}
}
