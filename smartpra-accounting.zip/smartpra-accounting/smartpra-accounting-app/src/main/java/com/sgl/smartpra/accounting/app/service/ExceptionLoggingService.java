package com.sgl.smartpra.accounting.app.service;

import java.util.Map;

import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

public interface ExceptionLoggingService {

	void logException(ExceptionTransactionModel exceptionTransactionModel);

	ExceptionTransactionModel getExceptionTransactionModel(AccountingTransaction accountingTransaction, String string, Map<String, Object> scenarioMasterMap);

	String getModuleBasedExceptionCode(String tranAccNotFound, String module);

}
