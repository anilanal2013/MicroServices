package com.sgl.smartpra.accounting.app.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.accounting.app.configuration.ConfigForExceptionCodes;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration;
import com.sgl.smartpra.accounting.app.dao.AccountAttributeDao;
import com.sgl.smartpra.accounting.app.exceptions.FiegnClientException;
import com.sgl.smartpra.accounting.app.service.AccountingService;
import com.sgl.smartpra.accounting.app.service.BussinessExceptionValidationService;
import com.sgl.smartpra.accounting.app.service.ExceptionLoggingService;
import com.sgl.smartpra.accounting.app.utils.CollectionUtlis;
import com.sgl.smartpra.accounting.app.utils.TxnExceptionUtil;
import com.sgl.smartpra.accounting.entity.AccountingTransactionEntity;
import com.sgl.smartpra.accounting.mapper.AccountAttributeViewMapper;
import com.sgl.smartpra.accounting.mapper.AccountAuditTrialMapper;
import com.sgl.smartpra.accounting.mapper.AccountingTransactionMapper;
import com.sgl.smartpra.accounting.model.AccountAttributeView;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.repository.AccountAuditTrialRepository;
import com.sgl.smartpra.accounting.repository.AccountingExtractMappingRepository;
import com.sgl.smartpra.accounting.repository.AccountingTransactionRepository;
import com.sgl.smartpra.excep.resolution.model.ExceptionValidationModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.MasScenarioModel;

import lombok.extern.slf4j.Slf4j;

/**
 * @author nacsanth
 *
 */
@Service
@Slf4j
public class BussinessExceptionValidationServiceImpl implements BussinessExceptionValidationService{

	@Autowired
	private AccountingService accountingService;
	@Autowired
	AccountAttributeViewMapper accountAttributeViewMapper;
	@Autowired
	AccountAttributeDao accountAttributeDao;
	@Autowired
	private AccountingTransactionRepository accountingTransactionRepository;
	@Autowired
	AccountingTransactionMapper accountingTransactionMapper;
	@Autowired
	AccountAuditTrialRepository accountAuditTrialRepository;
	
	@Autowired
	AccountAuditTrialMapper accountAuditTrialMapper;
	@Autowired
	private ConfigForExceptionCodes masterExceptionCodes;
	@Autowired
	FeignClientConfiguration.TransactionExceptionFeignClient transactionExceptionFeignClient;
	@Autowired
	private AccountingExtractMappingRepository accountingExtractMappingRepository;
	@Autowired
	private ExceptionLoggingService exceptionLoggingService;
	@Autowired
	private Environment environment;
	public static final String SCENARIO_NOT_FOUND ="scenarioNotFound";
	public static final String DEFAULT_MODULE="MA";
	@Override
	public ExceptionValidationModel validateExceptions(ExceptionValidationModel exceptionValidationModel) throws FiegnClientException {
		exceptionValidationModel.setValidationStatus(false);
		log.info("Validating exception codes are{} ",exceptionValidationModel.getExceptionCodes());
		for(String errorCode:exceptionValidationModel.getExceptionCodes()){
			if(masterExceptionCodes.getMastersExceptionCodes().contains(errorCode)){
				if(exceptionValidationModel.getAccountingTransactionId()!=null){
				Optional<AccountingTransactionEntity> existAccTxn=accountingTransactionRepository.findById(exceptionValidationModel.getAccountingTransactionId().intValue());
				if(existAccTxn.isPresent()){
					AccountingTransaction accountingTransaction = accountingTransactionMapper.mapToModel(existAccTxn.get());
					accountingTransaction.setInvoiceLevel("I");
					MasScenarioModel scenarioMaster = null;
					//if(accountingTransaction.getScenarioNumber()==null){
					 scenarioMaster = accountingService.fetchScenarioMasterByRules(accountingTransaction);
					List<MasScenarioModel> scenarioMasters = new ArrayList<>();
					if(StringUtils.isNotBlank(scenarioMaster.getModule().orElse(""))){
						scenarioMasters = accountingService.getScenarioMasters(scenarioMaster);
					}else{
						return ruleEngineValidation(exceptionValidationModel, errorCode, accountingTransaction);
					}
						if(CollectionUtlis.isEmpty(scenarioMasters)){
							return scenarioMasterValidation(exceptionValidationModel, errorCode, accountingTransaction,scenarioMaster);
						}else if(scenarioMasters.size()==1){
							scenarioMaster=scenarioMasters.get(0);
							String scenarioMastrNotFoundExceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(SCENARIO_NOT_FOUND,accountingTransaction.getModule());
							if(scenarioMastrNotFoundExceptionCode.equalsIgnoreCase(errorCode)){
								exceptionValidationModel.setValidationStatus(true);
							}
							}else{
								return exceptionValidationModel;
							}
					//}

					List<AccountAttributeView> accountingAttributeViewList = accountAttributeViewMapper
							.mapToModel(accountAttributeDao.fetchAccountAttributeViewByScenarioNumberAndClientId(scenarioMaster!=null?scenarioMaster.getScenarioNumber():null,accountingTransaction.getClientId().orElse(""))); 
					if(CollectionUtlis.isEmpty(accountingAttributeViewList)){
						existAccTxn.get().setScenarioNumber(scenarioMaster!=null?scenarioMaster.getScenarioNumber():null);
						log.info("Master Validation - Account Attriubute view is empty for Scenario Number {}", existAccTxn.get().getScenarioNumber());
						return accountingService.validateMasters(exceptionValidationModel, existAccTxn.get(),errorCode,accountingAttributeViewList,accountingTransaction,scenarioMaster);
					}else{
						exceptionValidationModel.setValidationStatus(true);
						accountingService.completeTransaction(accountingAttributeViewList, accountingTransaction);
					}
				  }
				}else{
					log.error("accounting txn id is not present for errorCode {}",errorCode);
					}
			}
		}
		return exceptionValidationModel;
		
	}


	/**
	 * this method validates scenario master
	 * @param exceptionValidationModel
	 * @param errorCode
	 * @param accountingTransaction
	 * @param scenarioMaster 
	 * @return ExceptionValidationModel
	 */
	public ExceptionValidationModel scenarioMasterValidation(ExceptionValidationModel exceptionValidationModel,
			String errorCode, AccountingTransaction accountingTransaction, MasScenarioModel scenarioMaster) {
		ObjectMapper obj=new ObjectMapper();
		String scenarioMastrNotFoundExceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(SCENARIO_NOT_FOUND,accountingTransaction.getModule());
		if(scenarioMastrNotFoundExceptionCode.equalsIgnoreCase(errorCode)){
			return exceptionValidationModel;
		}else{
			Map<String,Object>scenarioMasterExceptionMap=obj.convertValue(scenarioMaster, Map.class);
			ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,SCENARIO_NOT_FOUND,scenarioMasterExceptionMap);
			exceptionLoggingService.logException(exceptionTransactionModel);
			HashMap<String,String>newExceptions=new HashMap<>();
			String exceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(SCENARIO_NOT_FOUND,accountingTransaction.getModule());
			newExceptions.put(exceptionCode,SCENARIO_NOT_FOUND);
			exceptionValidationModel.setErrors(newExceptions);
			return exceptionValidationModel;
		}
	}


	/**
	 * this method will validate the rule engine
	 * @param exceptionValidationModel
	 * @param errorCode
	 * @param accountingTransaction
	 * @return ExceptionValidationModel
	 */
	public ExceptionValidationModel ruleEngineValidation(ExceptionValidationModel exceptionValidationModel,
			String errorCode, AccountingTransaction accountingTransaction) {
		String ruleEngineNotFoundException=exceptionLoggingService.getModuleBasedExceptionCode("ruleEngineNotFound","");
		if(errorCode.equalsIgnoreCase(ruleEngineNotFoundException)){
			return exceptionValidationModel;
		}else{
			ExceptionTransactionModel exceptionTransactionModel=TxnExceptionUtil.prepareExceptionTransactionModelForMisc(accountingTransaction,"Rule Engine is down",null);
			transactionExceptionFeignClient.initExceptionTrasaction(exceptionTransactionModel);
			HashMap<String,String>newExceptions=new HashMap<>();
			newExceptions.put("RuleEngineNotFound", "RuleEngineNotFound");
			exceptionValidationModel.setErrors(newExceptions);
			return exceptionValidationModel;
		}
	}

	
	public void prepareValidationObject(ExceptionValidationModel validationModelReponse,ExceptionValidationModel validationModelRequest){
		validationModelReponse.setValidationStatus(false);
		validationModelReponse.setExceptionCodes(validationModelRequest.getExceptionCodes());
		validationModelReponse.setAccountingTransactionId(validationModelRequest.getAccountingTransactionId().longValue());

	}
	@Transactional
	public AccountingTransaction saveAccountingTransaction(AccountingTransaction accountingTransaction, Optional<String> status){
		accountingTransaction.setStatus(status);
		accountingTransaction.setLastUpdatedDate(LocalDateTime.now());
		AccountingTransactionEntity accountingTransactionEntity = accountingTransactionMapper.mapToEntity(accountingTransaction);
		accountingTransactionEntity = accountingTransactionRepository.save(accountingTransactionEntity);
		accountingTransaction.setAccountingTxnId(accountingTransactionEntity.getAccountingTxnId());
		accountingTransaction.setCreatedDate(accountingTransactionEntity.getCreatedDate());
		return accountingTransaction;
	}
}
