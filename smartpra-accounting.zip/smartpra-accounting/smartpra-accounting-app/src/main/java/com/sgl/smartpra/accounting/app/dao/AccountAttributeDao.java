package com.sgl.smartpra.accounting.app.dao;

import com.sgl.smartpra.accounting.entity.AccountAttributeViewEntity;

import java.util.List;

public interface AccountAttributeDao {
	
	public List<AccountAttributeViewEntity> fetchAccountAttributeView(Integer scenarionumber) ;

	public List<AccountAttributeViewEntity> fetchAccountAttributeViewByScenarioNumberAndClientId(Integer scenarioNumber,
			String orElse);

}
