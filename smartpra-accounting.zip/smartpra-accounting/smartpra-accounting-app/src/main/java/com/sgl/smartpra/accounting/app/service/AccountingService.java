package com.sgl.smartpra.accounting.app.service;
import static com.sgl.smartpra.accounting.app.utils.AccountsConstants.MISC_1126;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.sgl.smartpra.accounting.app.configuration.ConfigForExceptionCodes;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.MasterFeignClient;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.RuleEngineFeignClient;
import com.sgl.smartpra.accounting.app.exceptions.FiegnClientException;
import com.sgl.smartpra.accounting.app.utils.CollectionUtlis;
import com.sgl.smartpra.accounting.app.utils.JVnGL;
import com.sgl.smartpra.accounting.app.utils.TxnExceptionUtil;
import com.sgl.smartpra.accounting.entity.AccountingAuditTrialEntity;
import com.sgl.smartpra.accounting.entity.AccountingTransactionEntity;
import com.sgl.smartpra.accounting.mapper.AccountAttributeViewMapper;
import com.sgl.smartpra.accounting.mapper.AccountAuditTrialMapper;
import com.sgl.smartpra.accounting.mapper.AccountingTransactionMapper;
import com.sgl.smartpra.accounting.model.AccountAttributeView;
import com.sgl.smartpra.accounting.model.AccountResponse;
import com.sgl.smartpra.accounting.model.AccountingAuditTrial;
import com.sgl.smartpra.accounting.model.AccountingEntryRequest;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.model.AccountingTransactionModel;
import com.sgl.smartpra.accounting.repository.AccountAuditTrialRepository;
import com.sgl.smartpra.accounting.repository.AccountingTransactionRepository;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.excep.resolution.model.ExceptionValidationModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.AccountAlphaCode;
import com.sgl.smartpra.master.model.AccountDefIdentifierResponse;
import com.sgl.smartpra.master.model.AccountDefIdentifierWrapper;
import com.sgl.smartpra.master.model.AccountModel;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.MasScenarioModel;

import lombok.extern.slf4j.Slf4j;

@Service(value = "accountingService")
@Slf4j
public class AccountingService {

	@Autowired
	MasterFeignClient masterFeignClient;
	
	@Autowired
	RuleEngineFeignClient ruleEngineFeignClient;
	@Autowired
	private ConfigForExceptionCodes masterExceptionCodes;
	
	@Autowired
	AccountAuditTrialRepository accountAuditTrialRepository;

	@Autowired
	AccountAttributeViewMapper accountAttributeViewMapper;

	@Autowired
	AccountAuditTrialMapper accountAuditTrialMapper;
	@Autowired
	AccountingTransactionMapper accountingTransactionMapper;
	@Autowired
	AccountingTransactionRepository accountingTransactionRepository;
	private static final String COMPLETE = "COMPLETE";
	@Autowired
	FeignClientConfiguration.TransactionExceptionFeignClient transactionExceptionFeignClient;
	@Autowired
	private ExceptionLoggingService exceptionLoggingService;
	
	public static final String SCENARIO_NOT_FOUND ="scenarioNotFound";
	public static final String TRAN_ACC_NOT_FOUND ="transactionAccountMasterNotFound";
	public static final String ACC_DEF_NOT_FOUND ="accountDefinitionMasterNotFound";
	public static final String ACC_NOT_FOUND="accountMasterNotFound";
	public static final String DEFAULT_MODULE="MA";
	
	public List<MasScenarioModel> getScenarioMasters(MasScenarioModel scenarioMaster) {
		log.info("Enter in the getScenarioMasters");
			return masterFeignClient.fetchScenarioMaster( scenarioMaster);
	}
	
	public MasScenarioModel fetchScenarioMasterByRules (AccountingTransaction accountingTransaction) {
		log.info("Enter in the fetchScenarioMaster");
		return ruleEngineFeignClient.fetchScenarioMaster(accountingTransaction);
	}
	
	public List<AccountingAuditTrial> getAccountingTrail(AccountingEntryRequest accountingEntryRequest) {
		log.info("Enter in the getAccountingTrail");
		return ruleEngineFeignClient.calculateAccounts(accountingEntryRequest);
	}

	public FinancialMonthModel fetchCurrentOpenFinancialMonth(String clientId) {
		log.info("Enter in the fetchCurrentOpenFinancialMonth");
		return masterFeignClient.getCurrentOpenFinancialMonthForFinancialCalendar(clientId);
	}

	public FinancialMonthModel getLatestClosedFinancialMonthForFinancialCalendar(){
		log.info("Enter in the getLatestClosedFinancialMonthForFinancialCalendar");
		return masterFeignClient.getLatestClosedFinancialMonthForFinancialCalendar();
	}
	
	/** this method validate Masters based on
	 * @param accountingTransaction
	 * @param scenarioMaster
	 * @param accountingAttributeViewList
	 * @param accountResponse
	 * @returns - AccountResponse
	 * @throws FiegnClientException
	 */
	@Retryable(value = {FiegnClientException.class},maxAttemptsExpression = "#{${retry.maxAttempts}}",backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	public AccountResponse validateMasters(AccountingTransaction accountingTransaction, MasScenarioModel scenarioMaster,
				List<AccountAttributeView> accountingAttributeViewList, AccountResponse accountResponse) throws  FiegnClientException  {
					ObjectMapper objectMapper=new ObjectMapper();
					
		try{
					List<AccountingTransactionModel> masTransactionAccountsModelList =masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(scenarioMaster.getScenarioNumber());
					if (CollectionUtlis.isEmpty(masTransactionAccountsModelList)) {
						Map<String,Object>txnAccMap=scenarioMaster!=null?objectMapper.convertValue(scenarioMaster, Map.class):null;
						accountResponse = transactionAccoundMasterValidation(accountingTransaction, scenarioMaster,txnAccMap);
					} else {
							List<String> alphaCodes=new ArrayList<>();
							AccountDefIdentifierResponse accountDefIdentifierRequest=new AccountDefIdentifierResponse();
							List<AccountDefIdentifierWrapper>accountDefIdentifierWrappers=new ArrayList<>();
							alphaCodes = getAlphaCodes(masTransactionAccountsModelList, accountDefIdentifierWrappers);
							accountDefIdentifierRequest.setErrorData(accountDefIdentifierWrappers);
							AccountDefIdentifierResponse accountDefIdentifierResponse = masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(accountDefIdentifierRequest);
							if (accountDefIdentifierResponse != null && !CollectionUtlis.isEmpty(accountDefIdentifierResponse.getErrorData())) {
								accountResponse = accoundDefintionMasterValidation(accountingTransaction,
										accountDefIdentifierResponse);
							} else {
								accountResponse = accoundCodeMasterValidation(accountingTransaction, accountResponse,
										alphaCodes);
								}
						}
					return accountResponse;
		}catch(HystrixRuntimeException e){
			log.info("HystrixRuntimeException occured", e);
			throw new FiegnClientException(HttpStatus.SERVICE_UNAVAILABLE.value(),HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase(),accountingTransaction.getInvoiceNo().orElse(""));//configuration

		}
		
	}

	/** this method validates Transaction Account Master
	 * @param accountingTransaction
	 * @param scenarioMaster
	 * @param txnAccMap
	 * @returns -AccountResponse
	 */
	public AccountResponse transactionAccoundMasterValidation(AccountingTransaction accountingTransaction,MasScenarioModel scenarioMaster, Map<String, Object> txnAccMap) {
		AccountResponse accountResponse;
		log.info("Transaction Account Master Not Found for Scenario number{}",scenarioMaster.getScenarioNumber());
		 accountResponse= setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(),"MISC1126",
				"Transaction Account Master Not Found for Scenario Number "+scenarioMaster.getScenarioNumber().toString(),accountingTransaction.getInvoiceNo().orElse(""));
		 ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,TRAN_ACC_NOT_FOUND,txnAccMap);
		 exceptionLoggingService.logException(exceptionTransactionModel);
		return accountResponse;
	}

	/** this method validate Account Definition Master
	 * @param accountingTransaction
	 * @param accountDefIdentifierResponse
	 * @return AccountResponse
	 */
	public AccountResponse accoundDefintionMasterValidation(AccountingTransaction accountingTransaction,AccountDefIdentifierResponse accountDefIdentifierResponse) {
		AccountResponse accountResponse;
		String adi=accountDefIdentifierResponse.getErrorData().stream().filter(acc->acc.getAccountDefinitionIdentifier()!=null).
				map(acc->String.valueOf(acc.getAccountDefinitionIdentifier())).collect(Collectors.joining("-"));
		String alphaCode=accountDefIdentifierResponse.getErrorData().stream().map(acc->acc.getAccountCodeAlpha()).collect(Collectors.joining("-"));
		String exceptionCode="Account Definition Master Not Found for Account Definition Identifiers "+adi+" and  Account Alpha Code "+alphaCode;
		log.info(exceptionCode);
		Map<String,Object>accDefMasterExceptionMap=new HashMap<>();
		accDefMasterExceptionMap.put("accountCodeAlpha",alphaCode);
		ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,ACC_DEF_NOT_FOUND,accDefMasterExceptionMap);
		exceptionLoggingService.logException(exceptionTransactionModel);
		accountResponse= setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(), "MISC1126", exceptionCode,OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
		return accountResponse;
	}

	/** this method validate accound code master
	 * @param accountingTransaction
	 * @param accountResponse
	 * @param alphaCodes
	 * @returns -AccountResponse
	 */
	public AccountResponse accoundCodeMasterValidation(AccountingTransaction accountingTransaction,AccountResponse accountResponse, List<String> alphaCodes) {
		AccountAlphaCode accountAlphaCode = new AccountAlphaCode();
		accountAlphaCode.setAccountAlphaCode(alphaCodes);
		List<AccountModel> accountModelList = masterFeignClient.getAccountModelsByAlphaCodes(alphaCodes);
				if (CollectionUtlis.isEmpty(accountModelList)) {
					String alphaCode=alphaCodes.stream().collect(Collectors.joining("-"));
					String exceptionCodes="Account Master Not Found for alpha codes "+alphaCodes;
					log.info(exceptionCodes);
					Map<String,Object>accMasterExceptionMap=new HashMap<>();
					accMasterExceptionMap.put("accountCodeAlpha",alphaCode);
					ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,ACC_NOT_FOUND,accMasterExceptionMap);
					exceptionLoggingService.logException(exceptionTransactionModel);
					accountResponse= setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(),"MISC1126",exceptionCodes,OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
					}
		return accountResponse;
	}

	 @Recover
	 public AccountResponse setAccountResponseForMasterValidations(FiegnClientException e){
		 log.info("Maximum retry attempt is over and recovery is done for validate Master for invoiceNo{}",e.getErrorMessage(),e.getRequestParm());
		 return setAccountResponse(null, String.valueOf(e.getErrorCode()),"need to be change ",e.getErrorMessage(),e.getRequestParm());//Need to be updated as per updated Exception Code and Parameters
			
		
	 }
	 private AccountResponse setAccountResponse(String jvReferenceNum, String httpStatus, String error, String errorMess,String invoiceNo) {
			AccountResponse accountResponse = new AccountResponse();
			accountResponse.setJvReferenceNum(jvReferenceNum);
			accountResponse.setStatus(httpStatus);
			accountResponse.setErrorCode(error);
			accountResponse.setErrorMessage(errorMess);
			accountResponse.setTxn(invoiceNo);
			return accountResponse;
		}
		/**
		 * @param clientId
		 * @return
		 * @throws FinancialMonthModelException
		 * @throws FiegnClientException 
		 */
		@Retryable(value = {FiegnClientException.class},maxAttemptsExpression = "#{${retry.maxAttempts}}",backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
		public FinancialMonthModel fetchCurrentOpenFinancialMonth(Optional<String> clientId) throws  FiegnClientException  {
			FinancialMonthModel financialMonthModel =fetchCurrentOpenFinancialMonth(OptionalUtil.getValue(clientId));
			if(financialMonthModel==null){
				log.info("Server down/connection time out , retrying is in process");
				throw new FiegnClientException(HttpStatus.SERVICE_UNAVAILABLE.value(),HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase(),clientId.isPresent()?clientId.get():"");//configuration
			}
			return  financialMonthModel;
		}
		/**
		 * @return
		 * @throws FinancialMonthModelException
		 * @throws FiegnClientException 
		 */
		@Retryable(value = {FiegnClientException.class},maxAttemptsExpression = "#{${retry.maxAttempts}}",backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
		public FinancialMonthModel findLatestClosedFinancialMonthForFinancialCalendar() throws FiegnClientException {
			FinancialMonthModel financialMonthModel = getLatestClosedFinancialMonthForFinancialCalendar();
			if(financialMonthModel==null){
				log.info("Server down/connection time out , retrying is in process");
				throw new FiegnClientException(HttpStatus.SERVICE_UNAVAILABLE.value(),HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase(),"");//configuration
			}

			return  financialMonthModel;
		}
		/**
		 * @param exception
		 * @return
		 */
		@Recover
		public FinancialMonthModel retryForFinancialMonthModelException(FiegnClientException exception){
			log.info("Maximum retry attempt is over and recovery is done for FinancialMonthModel");
			return null;
			
		}

		
		/**
		 * this method validates the Transaction Account Master based on the input fields
		 * @param exceptionValidationModel
		 * @param accountingTransactionEntity
		 * @param errorCode
		 * @param accountingAttributeViewList
		 * @param accountingTransaction
		 * @return - ExceptionValidationModel
		 * @throws FiegnClientException
		 */
		public ExceptionValidationModel validateMasters(ExceptionValidationModel exceptionValidationModel, AccountingTransactionEntity accountingTransactionEntity,String errorCode, List<AccountAttributeView> accountingAttributeViewList, AccountingTransaction accountingTransaction,MasScenarioModel scenarioMaster) throws FiegnClientException {
			List<AccountingTransactionModel> masTransactionAccountsModelList =masterFeignClient.getMasTransactionAccountsModelsByScenaroNo(accountingTransactionEntity.getScenarioNumber());
			String txnAccMasterNotFoundExceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(TRAN_ACC_NOT_FOUND,accountingTransaction.getModule());
			if (CollectionUtlis.isEmpty(masTransactionAccountsModelList) && errorCode.equalsIgnoreCase(txnAccMasterNotFoundExceptionCode)) {
					log.info("Master Validation - Transaction Account Master Not Found for Scenario number{}",accountingTransactionEntity.getScenarioNumber());
					exceptionValidationModel.setValidationStatus(false);
					return exceptionValidationModel;
				}else if(CollectionUtlis.isEmpty(masTransactionAccountsModelList) && !errorCode.equalsIgnoreCase(txnAccMasterNotFoundExceptionCode)){
					return logTxnAccMaster(exceptionValidationModel,accountingTransaction,scenarioMaster);
				}else if(!CollectionUtlis.isEmpty(masTransactionAccountsModelList)){
					return validateAccMaster(exceptionValidationModel, errorCode, accountingAttributeViewList,accountingTransaction, masTransactionAccountsModelList);
			
		}
			return exceptionValidationModel;
		}

		/**
		 * This method validates Structure definition  and Account Definition Master
		 * @param exceptionValidationModel
		 * @param errorCode
		 * @param accountingAttributeViewList
		 * @param accountingTransaction
		 * @param masTransactionAccountsModelList
		 * @return ExceptionValidationModel
		 * @throws FiegnClientException
		 */
		public ExceptionValidationModel validateAccMaster(ExceptionValidationModel exceptionValidationModel,String errorCode, List<AccountAttributeView> accountingAttributeViewList,
				AccountingTransaction accountingTransaction,
				List<AccountingTransactionModel> masTransactionAccountsModelList) throws FiegnClientException {
			String txnAccMasterNotFoundExceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(TRAN_ACC_NOT_FOUND,accountingTransaction.getModule());
			if(errorCode.equalsIgnoreCase(txnAccMasterNotFoundExceptionCode)){
				exceptionValidationModel.setValidationStatus(true);
			}
			List<String> alphaCodes=new ArrayList<>();
			AccountDefIdentifierResponse accountDefIdentifierRequest=new AccountDefIdentifierResponse();
			List<AccountDefIdentifierWrapper>accountDefIdentifierWrappers=new ArrayList<>();
			alphaCodes = getAlphaCodes(masTransactionAccountsModelList, accountDefIdentifierWrappers);
			accountDefIdentifierRequest.setErrorData(accountDefIdentifierWrappers);
			AccountDefIdentifierResponse accountDefIdentifierResponse = masterFeignClient.getMasAccountDefModelsByAccDefIdAndAccAlphaCode(accountDefIdentifierRequest);
			if (accountDefIdentifierResponse != null && !CollectionUtlis.isEmpty(accountDefIdentifierResponse.getErrorData())) {
				String adi=accountDefIdentifierResponse.getErrorData().stream().filter(acc->acc.getAccountDefinitionIdentifier()!=null).map(acc->String.valueOf(acc.getAccountDefinitionIdentifier())).collect(Collectors.joining("-"));
				String alphaCode=accountDefIdentifierResponse.getErrorData().stream().map(acc->acc.getAccountCodeAlpha()).collect(Collectors.joining("-"));
				String exceptionCode="Account Definition Master Not Found for Account Definition Identifiers "+adi+" and  Account Alpha Code "+alphaCode;
				log.info(exceptionCode);
				String accDefinitionMasterNotFoundExceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(ACC_DEF_NOT_FOUND,accountingTransaction.getModule());

					if(errorCode.equalsIgnoreCase(accDefinitionMasterNotFoundExceptionCode)){
						exceptionValidationModel.setValidationStatus(false);
					return exceptionValidationModel;
				}else if(!errorCode.equalsIgnoreCase(accDefinitionMasterNotFoundExceptionCode)){
					return logAccountDefinitionMasterNotFoundException(exceptionValidationModel, accountingTransaction,
							adi, alphaCode, exceptionCode);
				}
			}
			else {
				String accDefinitionMasterNotFoundExceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(ACC_DEF_NOT_FOUND,accountingTransaction.getModule());
				if(errorCode.equalsIgnoreCase(accDefinitionMasterNotFoundExceptionCode)){
					exceptionValidationModel.setValidationStatus(true);
				}
				AccountAlphaCode accountAlphaCode = new AccountAlphaCode();
				accountAlphaCode.setAccountAlphaCode(alphaCodes);
				List<AccountModel> accountModelList = masterFeignClient.getAccountModelsByAlphaCodes(alphaCodes);
						if (CollectionUtlis.isEmpty(accountModelList)) {
							String accountMasterNotFoundExceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(ACC_NOT_FOUND,accountingTransaction.getModule());
							if(errorCode.equalsIgnoreCase(accountMasterNotFoundExceptionCode)){
								exceptionValidationModel.setValidationStatus(false);
								return exceptionValidationModel;
							}else if(!errorCode.equalsIgnoreCase(accountMasterNotFoundExceptionCode)){
								logAccountMasterNotFoundException(exceptionValidationModel, accountingTransaction,
										alphaCodes);
							}
					}else if(!CollectionUtlis.isEmpty(accountModelList)){
						exceptionValidationModel.setValidationStatus(true);
						completeTransaction(accountingAttributeViewList, accountingTransaction);
					}
						
				}

			return exceptionValidationModel;
		}

		/** this method logs the account master exception
		 * @param exceptionValidationModel
		 * @param accountingTransaction
		 * @param alphaCodes
		 */
		public void logAccountMasterNotFoundException(ExceptionValidationModel exceptionValidationModel,
				AccountingTransaction accountingTransaction, List<String> alphaCodes) {
			//call exception logging micro service
			String alphaCodeException=alphaCodes.stream().collect(Collectors.joining("-"));
			String exceptionCodes="Account Master Not Found for alpha codes "+alphaCodeException;
			log.error(exceptionCodes);
			Map<String,Object>accMasterNotFound=new HashMap<>();
			accMasterNotFound.put("accountCodeAlpha", alphaCodeException);
			ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,ACC_NOT_FOUND,accMasterNotFound);			
			exceptionLoggingService.logException(exceptionTransactionModel);
			exceptionValidationModel.setValidationStatus(true);
		}

		/** this method logs the account Definition master exception
		 * @param exceptionValidationModel
		 * @param accountingTransaction
		 * @param adi
		 * @param alphaCode
		 * @param exceptionCode
		 * @return
		 */
		public ExceptionValidationModel logAccountDefinitionMasterNotFoundException(ExceptionValidationModel exceptionValidationModel, AccountingTransaction accountingTransaction,	String adi, String alphaCode, String exception) {
			Map<String,Object>accDefMasterException=new HashMap<>();
			log.error(exception);
			accDefMasterException.put("accountCodeAlpha", alphaCode);
			//call exception logging micro service
			ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,ACC_DEF_NOT_FOUND,accDefMasterException);			
			exceptionLoggingService.logException(exceptionTransactionModel);
							
			String exceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(ACC_DEF_NOT_FOUND,accountingTransaction.getModule());
			HashMap<String,String>newExceptions=new HashMap<>();
			newExceptions.put(exceptionCode, TRAN_ACC_NOT_FOUND);
			exceptionValidationModel.setErrors(newExceptions);
			return exceptionValidationModel;
		}

		/** this method gives List of AlphaCodes
		 * @param masTransactionAccountsModelList
		 * @param accountDefIdentifierWrappers
		 * @return List of String
		 */
		public List<String> getAlphaCodes(List<AccountingTransactionModel> masTransactionAccountsModelList,
				List<AccountDefIdentifierWrapper> accountDefIdentifierWrappers) {
			List<String> alphaCodes;
			alphaCodes = masTransactionAccountsModelList.parallelStream().filter( (tam -> tam!=null && tam.getAccountDefinitionIdentifier()!=null && tam.getAccountDefinitionIdentifier().isPresent()&& tam.getAccountAlphaCode()!=null && tam.getAccountAlphaCode().isPresent())).map(tam -> {
					AccountDefIdentifierWrapper accDefWarpper = new AccountDefIdentifierWrapper();
					accDefWarpper.setAccountCodeAlpha(tam.getAccountAlphaCode().get());
					accDefWarpper.setAccountDefinitionIdentifier(tam.getAccountDefinitionIdentifier().get());
					accountDefIdentifierWrappers.add(accDefWarpper);
				return tam;
			}).map(tam -> {
				return tam.getAccountAlphaCode().get();
			}).collect(Collectors.toList());
			return alphaCodes;
		}

		/**
		 * @param exceptionValidationModel- this method logs  Transaction Account Master
		 * @param accountingTransaction
		 * @param scenarioMaster 
		 * @return-ExceptionValidationModel
		 */
		@SuppressWarnings("unchecked")
		public ExceptionValidationModel logTxnAccMaster(ExceptionValidationModel exceptionValidationModel, AccountingTransaction accountingTransaction, MasScenarioModel scenarioMaster) {
			//call exception logging micro service
			ObjectMapper obj=new ObjectMapper();
			Map<String,Object>scenarioMasterMap=scenarioMaster!=null?obj.convertValue(scenarioMaster, Map.class):null;
			ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,TRAN_ACC_NOT_FOUND,scenarioMasterMap);
			exceptionLoggingService.logException(exceptionTransactionModel);
			String exceptionCode=exceptionLoggingService.getModuleBasedExceptionCode(TRAN_ACC_NOT_FOUND,accountingTransaction.getModule());
			HashMap<String,String>newExceptions=new HashMap<>();
			newExceptions.put(exceptionCode, TRAN_ACC_NOT_FOUND);
			exceptionValidationModel.setErrors(newExceptions);
			return exceptionValidationModel;
		}

		/**
		 * @param accountingAttributeViewList
		 * @param accountingTransaction
		 * @throws FiegnClientException
		 */
		public void completeTransaction(List<AccountAttributeView> accountingAttributeViewList,
				AccountingTransaction accountingTransaction) throws FiegnClientException {
			List<AccountingAuditTrial> accountingAuditTrial = null;
			AccountingEntryRequest accountingEntryRequest = new AccountingEntryRequest();
			accountingEntryRequest.setAccountAttributeView(accountingAttributeViewList);
			accountingEntryRequest.setAccountingTransaction(accountingTransaction);
			try {
			accountingAuditTrial = getAccountingTrail(accountingEntryRequest);
			} catch(Exception e){
			log.error("Exception while fetching from getAccountingTrail(accountingEntryRequest){}",accountingEntryRequest);
			}
			if (accountingAuditTrial == null || accountingAuditTrial.isEmpty()){
				//call log exception microservice
				String errorCode="Accounting AuditTrial is null for "+OptionalUtil.getValue(accountingTransaction.getInvoiceNo());
				ExceptionTransactionModel exceptionTransactionModel=TxnExceptionUtil.prepareExceptionTransactionModelForMisc(accountingTransaction,errorCode,null);
				exceptionLoggingService.logException(exceptionTransactionModel);
			}
			FinancialMonthModel financialMonthModel =fetchCurrentOpenFinancialMonth(accountingTransaction.getClientId());//
			if (financialMonthModel == null){
				//call log exception microservice
				String errorCode="Current Open Financial Month is null for "+accountingTransaction.getClientId();
				ExceptionTransactionModel exceptionTransactionModel=TxnExceptionUtil.prepareExceptionTransactionModelForMisc(accountingTransaction,errorCode,null);
				exceptionLoggingService.logException(exceptionTransactionModel);
			}
			FinancialMonthModel financialMonthModelClose =findLatestClosedFinancialMonthForFinancialCalendar();
			if (financialMonthModelClose == null){
				//call log exception microservice
				String errorCode="Current Close Financial Month is null for "+OptionalUtil.getValue(accountingTransaction.getInvoiceNo());
				ExceptionTransactionModel exceptionTransactionModel=TxnExceptionUtil.prepareExceptionTransactionModelForMisc(accountingTransaction,errorCode,null);
				exceptionLoggingService.logException(exceptionTransactionModel);
			}
			final String module  = accountingTransaction.getModule();
			final Integer accountTxn = accountingTransaction.getAccountingTxnId();
			final String stjvNumb = JVnGL.calculateJV(module, accountTxn);
			final String invoiceLevel = accountingTransaction.getInvoiceLevel();
			AtomicInteger count = new AtomicInteger();
			accountingAuditTrial.stream().filter(Objects::nonNull).forEachOrdered(account -> {
				count.getAndIncrement();
				account.setJvNumber(stjvNumb);
				account.setSummarisationId(JVnGL.fetchGLSummarizationNo(module,financialMonthModelClose.getFinancialMonth(), count.get()));
				account.setFinYear(financialMonthModel.getFinancialYear());
				account.setAccountingAttribute20(invoiceLevel);
				account.setMonthClosedDate(LocalDate.now());
				account.setCreatedBy(Optional.of("System"));
			});

			accountingAuditTrial = saveAccountAuditTrial(accountingAuditTrial);
			updateAccountingTransaction(accountingTransaction,Optional.of(COMPLETE));
		}
		
		private List<AccountingAuditTrial> saveAccountAuditTrial(List<AccountingAuditTrial> accountingAuditTrial) {
			List<AccountingAuditTrialEntity> accountingAuditTrialEntityList = accountAuditTrialMapper.mapToEntity(accountingAuditTrial);
			return accountAuditTrialMapper.mapToModel( accountAuditTrialRepository.saveAll(accountingAuditTrialEntityList));
		}
		public AccountingTransaction updateAccountingTransaction(AccountingTransaction accountingTransaction, Optional<String> status){
			accountingTransaction.setStatus(status);
			accountingTransaction.setLastUpdatedDate(LocalDateTime.now());
			AccountingTransactionEntity accountingTransactionEntity = accountingTransactionMapper.mapToEntity(accountingTransaction);
			accountingTransactionEntity = accountingTransactionRepository.save(accountingTransactionEntity);
		
			accountingTransaction.setAccountingTxnId(accountingTransactionEntity.getAccountingTxnId());
			accountingTransaction.setCreatedDate(accountingTransactionEntity.getCreatedDate());
			return accountingTransaction;
		}
	public ExceptionValidationModel prepareValidationObject(ExceptionValidationModel validationModelReponse,
				ExceptionValidationModel validationModelRequest) {
			validationModelRequest.setValidationStatus(false);
			return validationModelRequest;
		}

	
}
