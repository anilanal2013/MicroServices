package com.sgl.smartpra.accounting.app.service;

import static com.sgl.smartpra.accounting.app.utils.AccountsConstants.MISC_1125;
import static com.sgl.smartpra.accounting.app.utils.AccountsConstants.MISC_1126;
import static com.sgl.smartpra.accounting.app.utils.AccountsConstants.MISC_9002;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration;
import com.sgl.smartpra.accounting.app.dao.AccountAttributeDao;
import com.sgl.smartpra.accounting.app.exceptions.FiegnClientException;
import com.sgl.smartpra.accounting.app.utils.JVnGL;
import com.sgl.smartpra.accounting.app.utils.TxnExceptionUtil;
import com.sgl.smartpra.accounting.entity.AccountingAuditTrialEntity;
import com.sgl.smartpra.accounting.entity.AccountingTransactionEntity;
import com.sgl.smartpra.accounting.mapper.AccountAttributeViewMapper;
import com.sgl.smartpra.accounting.mapper.AccountAuditTrialMapper;
import com.sgl.smartpra.accounting.mapper.AccountingAttributeDetailsMapper;
import com.sgl.smartpra.accounting.mapper.AccountingTransactionMapper;
import com.sgl.smartpra.accounting.model.AccountAttributeView;
import com.sgl.smartpra.accounting.model.AccountResponse;
import com.sgl.smartpra.accounting.model.AccountingAuditTrial;
import com.sgl.smartpra.accounting.model.AccountingEntryRequest;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.repository.AccountAuditTrialRepository;
import com.sgl.smartpra.accounting.repository.AccountingAttributeDetailsRepository;
import com.sgl.smartpra.accounting.repository.AccountingTransactionRepository;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.MasScenarioModel;

import lombok.extern.slf4j.Slf4j;

@Service(value = "accountAttributeService")
@Slf4j
public class AccountAttributeService {

	static final  DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("uuMMdd");
	static final  DateTimeFormatter DATE_TIME_FORMATTER_T = DateTimeFormatter.ofPattern("uuMMddHHmmss");
	private static final String INIT = "INIT";
	private static final String COMPLETE = "COMPLETE";
	private static final String ERROR = "ERROR";


	@Autowired
	AccountingTransactionRepository accountingTransactionRepository;

	@Autowired
	AccountingService accountingService;

	@Autowired
	AccountingAttributeDetailsRepository accountingAttributeDetailsRepository;

	@Autowired
	AccountingAttributeDetailsMapper accountingAttributeDetailsMapper;

	@Autowired
	AccountingTransactionMapper accountingTransactionMapper;

	@Autowired
	AccountAttributeDao accountAttributeDao;

	@Autowired
	AccountAuditTrialRepository accountAuditTrialRepository;

	@Autowired
	AccountAttributeViewMapper accountAttributeViewMapper;

	@Autowired
	AccountAuditTrialMapper accountAuditTrialMapper;
	@Autowired
	FeignClientConfiguration.TransactionExceptionFeignClient transactionExceptionFeignClient;
	@Autowired
	private ExceptionLoggingService exceptionLoggingService;
	public static final String SCENARIO_NOT_FOUND ="scenarioNotFound";
	
	@SuppressWarnings("unchecked")
	public AccountResponse fetchAccountingAuditTrial(AccountingTransaction accountingTransaction) throws FiegnClientException  {
		log.info("Entering in fetchAccountAttributeDetails method");
		accountingTransaction = saveAccountingTransaction(accountingTransaction, Optional.of(INIT));
		List<AccountingAuditTrial> accountingAuditTrial = null;
		AccountResponse accountResponse = null;
		ObjectMapper objectMapper=new ObjectMapper();
		MasScenarioModel scenarioMaster = accountingService.fetchScenarioMasterByRules(accountingTransaction);
			log.info("s - "+scenarioMaster);
			List<MasScenarioModel> scenarioMasters = new ArrayList<>();
			if(scenarioMaster!=null&&StringUtils.isNotBlank(scenarioMaster.getModule().orElse(""))){
				scenarioMasters = accountingService.getScenarioMasters(scenarioMaster);
				}else {
				saveAccountingTransaction(accountingTransaction,Optional.of(ERROR));
				accountResponse = setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(), MISC_1126,"Scenario not Found for "+scenarioMaster,OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
				Map<String,Object>scenarioMasterMap=objectMapper.convertValue(scenarioMaster, Map.class);
				ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,SCENARIO_NOT_FOUND,scenarioMasterMap);
				exceptionLoggingService.logException(exceptionTransactionModel);
				return accountResponse;
			} 
		log.info("s - "+scenarioMaster);
			if (scenarioMasters != null && !scenarioMasters.isEmpty()) {
				if (scenarioMasters.size() == 1) {
					scenarioMaster = scenarioMasters.get(0);
				} else {
					Map<String,Object>scenarioMasterMap=objectMapper.convertValue(scenarioMaster, Map.class);
					saveAccountingTransaction(accountingTransaction,Optional.of(ERROR));
					accountResponse = setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(), MISC_1126,"Found mulipleScenarion for "+scenarioMaster,OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
					ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,SCENARIO_NOT_FOUND,scenarioMasterMap);
					exceptionLoggingService.logException(exceptionTransactionModel);
					return accountResponse;
				}
			} else {
				saveAccountingTransaction(accountingTransaction,Optional.of(ERROR));
				Map<String,Object>scenarioMasterMap=objectMapper.convertValue(scenarioMaster, Map.class);
				ExceptionTransactionModel exceptionTransactionModel=exceptionLoggingService.getExceptionTransactionModel(accountingTransaction,SCENARIO_NOT_FOUND,scenarioMasterMap);
					exceptionLoggingService.logException(exceptionTransactionModel);
				accountResponse = setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(), MISC_1126,"Scenario not Found for "+scenarioMaster,OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
				return accountResponse;
			}
			List<AccountAttributeView> accountingAttributeViewList = accountAttributeViewMapper
					.mapToModel(accountAttributeDao.fetchAccountAttributeView(scenarioMaster.getScenarioNumber()));
		if (accountingAttributeViewList == null || accountingAttributeViewList.isEmpty()) {
			accountResponse = setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(), "MISC1126",
					"Account is null ", OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
			saveAccountingTransaction(accountingTransaction, Optional.of(ERROR));
			accountResponse = accountingService.validateMasters(accountingTransaction, scenarioMaster, accountingAttributeViewList,
					accountResponse);
			if (accountResponse != null) {
				return accountResponse;
			}
		}
		
			AccountingEntryRequest accountingEntryRequest = new AccountingEntryRequest();
			accountingEntryRequest.setAccountAttributeView(accountingAttributeViewList);
			accountingEntryRequest.setAccountingTransaction(accountingTransaction);
			try {
			accountingAuditTrial = accountingService.getAccountingTrail(accountingEntryRequest);
			} catch(Exception e){
				accountResponse = setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(), MISC_9002,e.getMessage(),OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
				return accountResponse;
			}
			if (accountingAuditTrial == null || accountingAuditTrial.isEmpty()){
				accountResponse = setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(), MISC_1126,"Accounting AuditTrial is null ",OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
				String errorCode="Accounting AuditTrial is null for "+OptionalUtil.getValue(accountingTransaction.getInvoiceNo());
				ExceptionTransactionModel exceptionTransactionModel=TxnExceptionUtil.prepareExceptionTransactionModelForMisc(accountingTransaction,errorCode,null);
				exceptionLoggingService.logException(exceptionTransactionModel);
				return accountResponse;
			
			}
			FinancialMonthModel financialMonthModel = accountingService.fetchCurrentOpenFinancialMonth(accountingTransaction.getClientId());//
			if (financialMonthModel == null){
				accountResponse = setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(), MISC_1125,"Current Open Financial Month is null",OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
				String errorCode="Current Open Financial Month is null for "+accountingTransaction.getClientId();
				ExceptionTransactionModel exceptionTransactionModel=TxnExceptionUtil.prepareExceptionTransactionModelForMisc(accountingTransaction,errorCode,null);
				exceptionLoggingService.logException(exceptionTransactionModel);
				return accountResponse;
			}
			FinancialMonthModel financialMonthModelClose =accountingService.findLatestClosedFinancialMonthForFinancialCalendar();
			if (financialMonthModelClose == null){
				accountResponse = setAccountResponse(null, HttpStatus.INTERNAL_SERVER_ERROR.toString(), MISC_1125,"Current Close Financial Month is null",OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
				String errorCode="Current Close Financial Month is null for "+OptionalUtil.getValue(accountingTransaction.getInvoiceNo());
				ExceptionTransactionModel exceptionTransactionModel=TxnExceptionUtil.prepareExceptionTransactionModelForMisc(accountingTransaction,errorCode,null);
				exceptionLoggingService.logException(exceptionTransactionModel);
				return accountResponse;
			}
			final String module  = accountingTransaction.getModule();
			final Integer accountTxn = accountingTransaction.getAccountingTxnId();
			final String stjvNumb = JVnGL.calculateJV(module, accountTxn);
			//final String stjvNumb=JVnGL.calculateJV(accountingTransaction);
			final String invoiceLevel = accountingTransaction.getInvoiceLevel();
			AtomicInteger count = new AtomicInteger();
			accountingAuditTrial.stream().filter(Objects::nonNull).forEachOrdered(account -> {
				count.getAndIncrement();
				account.setJvNumber(stjvNumb);
				account.setSummarisationId(JVnGL.fetchGLSummarizationNo(module,financialMonthModelClose.getFinancialMonth(), count.get()));
				account.setFinYear(financialMonthModel.getFinancialYear());
				account.setAccountingAttribute20(invoiceLevel);
				account.setMonthClosedDate(LocalDate.now());
				account.setCreatedBy(Optional.of("System"));
			});

			accountingAuditTrial = saveAccountAuditTrial(accountingAuditTrial);
			saveAccountingTransaction(accountingTransaction,Optional.of(COMPLETE));
			accountResponse = setAccountResponse(stjvNumb, HttpStatus.OK.toString(),null,null,OptionalUtil.getValue(accountingTransaction.getInvoiceNo()));
			return accountResponse;

	}

	

	private AccountResponse setAccountResponse(String jvReferenceNum, String httpStatus, String error, String errorMess,String invoiceNo) {
		AccountResponse accountResponse = new AccountResponse();
		accountResponse.setJvReferenceNum(jvReferenceNum);
		accountResponse.setStatus(httpStatus);
		accountResponse.setErrorCode(error);
		accountResponse.setErrorMessage(errorMess);
		accountResponse.setTxn(invoiceNo);
		return accountResponse;
	}

	private List<AccountingAuditTrial> saveAccountAuditTrial(List<AccountingAuditTrial> accountingAuditTrial) {
		List<AccountingAuditTrialEntity> accountingAuditTrialEntityList = accountAuditTrialMapper.mapToEntity(accountingAuditTrial);
		return accountAuditTrialMapper.mapToModel( accountAuditTrialRepository.saveAll(accountingAuditTrialEntityList));
	}
	
	

	
	public AccountingTransaction saveAccountingTransaction(AccountingTransaction accountingTransaction, Optional<String> status){
		accountingTransaction.setStatus(status);
		accountingTransaction.setLastUpdatedDate(LocalDateTime.now());
		AccountingTransactionEntity accountingTransactionEntity = accountingTransactionMapper.mapToEntity(accountingTransaction);
		accountingTransactionEntity = accountingTransactionRepository.save(accountingTransactionEntity);
		accountingTransaction.setAccountingTxnId(accountingTransactionEntity.getAccountingTxnId());
		accountingTransaction.setCreatedDate(accountingTransactionEntity.getCreatedDate());
		return accountingTransaction;
	}



	
	
}
