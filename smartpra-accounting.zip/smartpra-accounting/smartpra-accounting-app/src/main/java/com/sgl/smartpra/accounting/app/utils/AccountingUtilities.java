package com.sgl.smartpra.accounting.app.utils;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.accounting.model.AccountingMappingConfModel;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AccountingUtilities {

	public List<Map<String, Object>> fetchAccountsBasedOnSummarizationAndMappingConf(
			List<Map<String, Object>> summarizationList, List<AccountingMappingConfModel> accountingMappingConfList) {
		log.info("Inside AccountingUtilities class, fetchAccountsBasedOnSummarizationAndMappingConf method");
		try {
			return summarizationList.stream().filter(Objects::nonNull).map(summarizarionObjectIntoMap -> {
				Map<String, Object> finalOutputAccountingMapConfMap = new HashMap<>();
				accountingMappingConfList.stream().filter(Objects::nonNull).forEach(accountingMappingConf -> {
					mapData(finalOutputAccountingMapConfMap, summarizarionObjectIntoMap, accountingMappingConf);
				});
				return finalOutputAccountingMapConfMap;
			}).collect(Collectors.toList());
		} catch (Exception e) {
			log.error(
					"Exception Inside AccountingUtilities class, fetchAccountsBasedOnSummarizationAndMappingConf method");
			return Collections.emptyList();
		}
	}

	private void mapData(Map<String, Object> finalOutputAccountingMapConfMap,
			Map<String, Object> summarizarionObjectIntoMap, AccountingMappingConfModel accountingMappingConf) {
		log.info("Inside AccountingUtilities class, mapData method");
		String dataType = StringUtils.lowerCase(accountingMappingConf.getDatatype());
		if (StringUtils.equalsIgnoreCase(dataType, "construct")) {
			String mTableValue = accountingMappingConf.getValue();
			StringBuilder generatedDynamicValue = getDynamicValueFormation(summarizarionObjectIntoMap, mTableValue);
			finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), generatedDynamicValue);
		} else {
			finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), summarizarionObjectIntoMap
					.getOrDefault(accountingMappingConf.getValue(), StringUtils.isNotEmpty(accountingMappingConf.getDefaultvalue()) ? accountingMappingConf.getDefaultvalue() : "null"));
		}
		if (StringUtils.equalsIgnoreCase(dataType, "localdate")) {
			String date = (String) summarizarionObjectIntoMap.get(accountingMappingConf.getValue());
			String outputInString = null;
			if (StringUtils.isNotBlank(date)) {
				SimpleDateFormat inputFormat = new SimpleDateFormat(accountingMappingConf.getFormat());
				SimpleDateFormat outputFormat = new SimpleDateFormat(accountingMappingConf.getFromformat());
				try {
					Date dateCal = inputFormat.parse(date);
					outputInString = outputFormat.format(dateCal);
				} catch (Exception e) {
					log.error("Exception occurs in date Format " + e.getMessage());
				}
			}
			finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), outputInString);
		} else if (StringUtils.equalsIgnoreCase(StringUtils.lowerCase(accountingMappingConf.getFromdatatype()),
				"localdate")) {
			String st = null;
			try {
				DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(accountingMappingConf.getFormat());
				st = ((LocalDate) summarizarionObjectIntoMap.get(accountingMappingConf.getValue()))
						.format(dateTimeFormatter);
			} catch (Exception e) {
				log.error("Exception occurs in date Format " + e.getMessage());
			}
			finalOutputAccountingMapConfMap.put(accountingMappingConf.getKeyval(), st);
		}

	}

	public StringBuilder getDynamicValueFormation(Map<String, Object> summarizarionObjectIntoMap,
			String columnValueToChange) {
		StringBuilder dynamicValueFormat = null;
		if (columnValueToChange != null) {
			String[] strarr = columnValueToChange.split(",", 0);
			 dynamicValueFormat = new StringBuilder();
			for (String str : strarr) {
				if (str.startsWith("batch") || str.startsWith("accountingAttribute")) {
					dynamicValueFormat.append(summarizarionObjectIntoMap.get(str));
					if (!str.equals("/")) {
						dynamicValueFormat.append(" ");
					}
				} else {
					if (str.equals("/")) {
						StringBuilder temp = new StringBuilder(dynamicValueFormat.toString().trim());
						dynamicValueFormat = temp.append(str);
					} else {
						dynamicValueFormat.append(str);
					}
					if (!str.equals("/")) {
						dynamicValueFormat.append(" ");
					}
				}
			}
		} 
		return dynamicValueFormat;
	}
	
	public static FileLogging initFileLoggingGL(int totalCounts, int transferredCounts, String fileType,String fileFormat) {
		FileLogging fileLogging = new FileLogging();
		fileLogging.setFileCategory(fileFormat);
		fileLogging.setFileType(fileType);
		fileLogging.setProcessedBy(AccountsConstants.PROCESSED_BY_MANUAL);
		fileLogging.setSource(AccountsConstants.CREATED_BY_ACCOUNTING);
		fileLogging.setCreatedBy(AccountsConstants.CREATED_BY_ACCOUNTING);
		fileLogging.setModuleName(AccountsConstants.CREATED_BY_ACCOUNTING);
		fileLogging.setModuleId(AccountsConstants.MODULE_ID);
		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_OUTPUT);
		fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
		fileLogging.setIsEncryptedPostSuccess(AccountsConstants.N);
		fileLogging.setIsEncryptedPriorLoading(AccountsConstants.N);
		fileLogging.setIsRenamedPostSuccess(AccountsConstants.N);
		fileLogging.setIsMovedToRelevantFolder(AccountsConstants.N);
		fileLogging.setIsNotificationSent(AccountsConstants.N);
		fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));
		fileLogging.setHeaderCounts(1);
		fileLogging.setTotalCounts(totalCounts);
		fileLogging.setDetailCounts(0);
		fileLogging.setTransferredCounts(transferredCounts);
		fileLogging.setErrorCounts(0);
		return fileLogging;
	}
}
