package com.sgl.smartpra.accounting.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.accounting.app.exceptions.FiegnClientException;
import com.sgl.smartpra.accounting.app.service.BussinessExceptionValidationService;
import com.sgl.smartpra.excep.resolution.model.ExceptionValidationModel;

/**
 * @author nacsanth
 *
 */
@RestController
public class BussinessExceptionValidationController {
	@Autowired
	private BussinessExceptionValidationService exceptionValidationService; 

	
	/**
	 * @param validationModel - this ExceptionValidationModel object will be validated as per the error code it contains 
	 * @return  -it will return ExceptionValidationModel with true status if validated successfully else false
	 * @throws FiegnClientException
	 */
	@PostMapping("/validateExceptions")
	public ExceptionValidationModel  validateBussinessExceptions(@RequestBody ExceptionValidationModel validationModel) throws FiegnClientException{
		return exceptionValidationService.validateExceptions(validationModel);
	}
}
