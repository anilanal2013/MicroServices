package com.sgl.smartpra.accounting.app.service;

import com.sgl.smartpra.accounting.app.exceptions.FiegnClientException;
import com.sgl.smartpra.excep.resolution.model.ExceptionValidationModel;

/**
 * @author nacsanth
 *
 */
public interface BussinessExceptionValidationService {

	ExceptionValidationModel validateExceptions(ExceptionValidationModel validationModel) throws FiegnClientException;
	
}
