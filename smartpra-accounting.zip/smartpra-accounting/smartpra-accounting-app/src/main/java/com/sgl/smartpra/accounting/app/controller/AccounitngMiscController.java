package com.sgl.smartpra.accounting.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.accounting.app.exceptions.FiegnClientException;
import com.sgl.smartpra.accounting.app.service.AccountAttributeService;
import com.sgl.smartpra.accounting.model.AccountResponse;
import com.sgl.smartpra.accounting.model.AccountingTransaction;

@RestController
@RequestMapping("/accounting-misc")
public class AccounitngMiscController {

	@Autowired
	AccountAttributeService accountAttributeService;
	


	@PostMapping("/accounting-details")
	public AccountResponse getAttributeDetails(
			@RequestBody AccountingTransaction accountingTransaction) throws  FiegnClientException {
		return accountAttributeService.fetchAccountingAuditTrial(accountingTransaction);
	}
}
