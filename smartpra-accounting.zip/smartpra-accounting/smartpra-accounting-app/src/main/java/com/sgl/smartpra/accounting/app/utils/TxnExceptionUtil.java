package com.sgl.smartpra.accounting.app.utils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

import lombok.experimental.UtilityClass;
/**
 * @author nacsanth
 * this class gives the methods to form ExceptionTransactionModel 
 */

@UtilityClass
public class TxnExceptionUtil {
	public static final String ACCOUNTING_SYSTEM="ACCOUNTING_SYSTEM";

	public static ExceptionTransactionModel prepareExceptionTransactionModelForMisc(AccountingTransaction accountingTransaction, String exceptionCode, Map<String, Object> parmValues){
		ExceptionTransactionModel exceptionTransactionModel= new ExceptionTransactionModel();
		exceptionTransactionModel.setEnvironment("P");
		exceptionTransactionModel.setExceptionCode(exceptionCode);
		exceptionTransactionModel.setClientId(accountingTransaction.getClientId().orElse(""));
		exceptionTransactionModel.setIssuedCarrier(accountingTransaction.getTransIssAirline().orElse(""));
		exceptionTransactionModel.setStagingReferenceId(Long.valueOf(accountingTransaction.getAccountingTxnId()));
		exceptionTransactionModel.setMainDocument(accountingTransaction.getInvoiceNo().orElse(""));
		exceptionTransactionModel.setCreatedBy(ACCOUNTING_SYSTEM);
		exceptionTransactionModel.setCreatedDate(LocalDateTime.now());
		exceptionTransactionModel.setInvoiceUrn(accountingTransaction.getInvoiceNo().orElse(""));
		
		List<ExceptionParametersValueModel> parametersValueModelList = new ArrayList<>();
		if (parmValues != null) {
			parmValues.forEach((key, value) -> {
				final ExceptionParametersValueModel parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName(key);
				parametersValueModel.setParameterValue(value!=null?String.valueOf(value):"");
				parametersValueModelList.add(parametersValueModel);
			});
		}
		exceptionTransactionModel.setParametersValueList(parametersValueModelList);
		
		return exceptionTransactionModel;
	}
}
