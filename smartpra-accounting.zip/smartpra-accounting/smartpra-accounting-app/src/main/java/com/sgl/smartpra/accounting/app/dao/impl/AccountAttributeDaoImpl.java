package com.sgl.smartpra.accounting.app.dao.impl;

import com.sgl.smartpra.accounting.app.dao.AccountAttributeDao;
import com.sgl.smartpra.accounting.entity.AccountAttributeViewEntity;
import com.sgl.smartpra.accounting.repository.AccountAttributeViewRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class AccountAttributeDaoImpl implements AccountAttributeDao {

	@Autowired
	AccountAttributeViewRepository accountAttributeViewRepository;

	@Override
	public List<AccountAttributeViewEntity> fetchAccountAttributeView(Integer scenarionumber)
		 {
		log.info("Entering in fetchAccountAttributeView method");
		List<AccountAttributeViewEntity> accountAttributeViewEntityList = accountAttributeViewRepository
				.findByScenarioNumber(scenarionumber);

		return accountAttributeViewEntityList;
	}

	@Override
	public List<AccountAttributeViewEntity> fetchAccountAttributeViewByScenarioNumberAndClientId(Integer scenarioNumber,
			String clientId) {
		log.info("fetching in fetchAccountAttributeView method {}",scenarioNumber,clientId);
		return accountAttributeViewRepository.findByScenarioNumberAndClientId(scenarioNumber,clientId);
	}

}
