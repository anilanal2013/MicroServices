package com.sgl.smartpra.accounting.app.configuration;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@ConfigurationProperties
@Data
@Component
public class ConfigForExceptionCodes {

	private List<String>mastersExceptionCodes;
	private String transactionAccountMasterNotFound;
	private String scenarioMasterNotFound;
	private String ruleEngineNotFound;
	private String accountMasterNotFound;
	private String accountDefinitionMasterMotFound;
	private List<String>scenarioMasterNotFoundErrorCodes;
}
