package com.sgl.smartpra.accounting.app.configuration;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class ExceptionLoggingAopConfiguration {
	@Autowired
	private FeignClientConfiguration.TransactionExceptionFeignClient transactionExceptionFeignClient;
	@Before(value="execution(* com.sgl.smartpra.accounting.app.service.impl.ExceptionLoggingImpl.logException(..)) and  args(exceptionTransactionModel)")
	public void callBefore(ExceptionTransactionModel exceptionTransactionModel){
		log.info("calling the Exception service for logging the exception {}",exceptionTransactionModel);
		try{
		transactionExceptionFeignClient.initExceptionTrasaction(exceptionTransactionModel);
		}catch(Exception ex){
			log.error("Exception occured while calling exception logging service", ex);
		}
		
	}
}
