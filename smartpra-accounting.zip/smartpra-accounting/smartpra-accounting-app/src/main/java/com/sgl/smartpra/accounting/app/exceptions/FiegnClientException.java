package com.sgl.smartpra.accounting.app.exceptions;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author nacsanth
 *
 */
@Data
@AllArgsConstructor
public class FiegnClientException extends Exception {

	private static final long serialVersionUID = 1L;
	private int errorCode;
	private String errorMessage;
	private String requestParm;
	
	
}
