package com.sgl.smartpra.accounting.app.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import com.netflix.hystrix.exception.HystrixTimeoutException;
import com.sgl.smartpra.accounting.app.configuration.FeignClientConfiguration.MasterFeignClient;
import com.sgl.smartpra.accounting.model.AccountingTransactionModel;
import com.sgl.smartpra.master.model.AccountDefIdentifierResponse;
import com.sgl.smartpra.master.model.AccountModel;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.MasScenarioModel;
@Component
public class FeignClientExceptionServiceImpl implements MasterFeignClient{
	@Autowired
	 private  Throwable cause;

	public FeignClientExceptionServiceImpl(Throwable cause) {
		super();
		this.cause = cause;
	}
	public List<MasScenarioModel> fetchScenarioMaster(MasScenarioModel scenarioMaster){
			if(cause instanceof HystrixTimeoutException){
		throw new ResponseStatusException(HttpStatus.REQUEST_TIMEOUT);
			}
		return null;
		
	}
	@Override
	public FinancialMonthModel getCurrentOpenFinancialMonthForFinancialCalendar(String clientId) {
		if(cause instanceof HystrixTimeoutException){
			throw new ResponseStatusException(HttpStatus.REQUEST_TIMEOUT);
				}
			return null;
	}
	@Override
	public FinancialMonthModel getLatestClosedFinancialMonthForFinancialCalendar() {
		if(cause instanceof HystrixTimeoutException){
			throw new ResponseStatusException(HttpStatus.REQUEST_TIMEOUT);
				}
			return null;
	}
	@Override
	public List<AccountingTransactionModel> getMasTransactionAccountsModelsByScenaroNo(Integer scenarioNumber) {
		if(cause instanceof HystrixTimeoutException){
			throw new ResponseStatusException(HttpStatus.REQUEST_TIMEOUT);
				}
			return null;
	}
	@Override
	public List<AccountModel> getAccountModelsByAlphaCodes(List<String> accountAlphaCode) {
		if(cause instanceof HystrixTimeoutException){
			throw new ResponseStatusException(HttpStatus.REQUEST_TIMEOUT);
				}
			return null;
	}
	@Override
	public AccountDefIdentifierResponse getMasAccountDefModelsByAccDefIdAndAccAlphaCode(
			AccountDefIdentifierResponse accountDefIdentifierRequest) {
		if(cause instanceof HystrixTimeoutException){
			throw new ResponseStatusException(HttpStatus.REQUEST_TIMEOUT);
				}
			return null;
	}
	
}
