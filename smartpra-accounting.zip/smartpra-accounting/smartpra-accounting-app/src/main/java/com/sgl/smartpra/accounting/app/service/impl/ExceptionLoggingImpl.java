package com.sgl.smartpra.accounting.app.service.impl;

import static com.sgl.smartpra.accounting.app.utils.AccountsConstants.MISC_1126;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.accounting.app.service.ExceptionLoggingService;
import com.sgl.smartpra.accounting.app.utils.TxnExceptionUtil;
import com.sgl.smartpra.accounting.entity.AccountingExtractMappingEntity;
import com.sgl.smartpra.accounting.model.AccountingTransaction;
import com.sgl.smartpra.accounting.repository.AccountingExtractMappingRepository;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

import lombok.extern.slf4j.Slf4j;

/**
 * @author nacsanth
 *
 */
@Service
@Slf4j
public class ExceptionLoggingImpl implements ExceptionLoggingService {
	@Autowired
	private AccountingExtractMappingRepository accountingExtractMappingRepository;
	@Autowired
	private Environment environment;
	public static final String DEFAULT_MODULE="MA";
	@Override
	public void logException(ExceptionTransactionModel exceptionTransactionModel) {
		log.info("exception logging AOP is called");
	}
	public void logException1() {
		log.info("exception logging AOP is called");
	}
	@SuppressWarnings("unchecked")
	@Override
	public ExceptionTransactionModel getExceptionTransactionModel(AccountingTransaction accountingTransaction,
			String exception, Map<String, Object> scenarioMasterMap) {
		String exceptionCode=getModuleBasedExceptionCode(exception,accountingTransaction.getModule());
		List<AccountingExtractMappingEntity> accountExtractMappingLists=accountingExtractMappingRepository.findByClientIdAndModuleIdAndAccounttype(accountingTransaction.getClientId().orElse(""),accountingTransaction.getModule(),exceptionCode);
		Map<String,Object> parmValues =  accountExtractMappingLists.stream().filter(Objects::nonNull)
				.collect(Collectors.toMap(AccountingExtractMappingEntity::getKeyval, accountExtract -> scenarioMasterMap.getOrDefault(accountExtract.getValue(), accountExtract.getDefaultvalue())));
		return TxnExceptionUtil.prepareExceptionTransactionModelForMisc(accountingTransaction,MISC_1126,parmValues);
	}
	
	public String getModuleBasedExceptionCode(String exception,String module){
		String exceptionCode=environment.getProperty(exception+module);
		if(StringUtils.isBlank(exceptionCode)){
			exceptionCode=environment.getProperty(exception+DEFAULT_MODULE);
		}
		return exceptionCode;
	}
}
