package com.sgl.smartpra.accounting.app.configuration;

import org.springframework.context.annotation.Bean;

public class FeignDecoderConfiguration {

	@Bean
	public FeignErrorDecoder feignErrorDecoder() {
		return new FeignErrorDecoder();
	}
}
