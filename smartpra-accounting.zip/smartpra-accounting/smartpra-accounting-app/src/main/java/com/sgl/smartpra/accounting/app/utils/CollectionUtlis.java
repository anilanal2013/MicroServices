package com.sgl.smartpra.accounting.app.utils;

import java.util.Collection;

public class CollectionUtlis {

	public static <T> boolean isEmpty(Collection<T> collections) {
		if (collections == null || collections.isEmpty()) {
			return true;
		} else {
			return false;
		}

	}
}
